/* ---- from sci-01.js ---- */
/* SCIENCES FOUNDATIONS, part 1: Unit 1 How Science Works */
COURSES.sciences = { units: [] };
COURSES.sciences.units.push({ t:"How Science Works", ch:[

{ t:"What Is Science?", s:"A method for understanding nature",
  sec:[
  ["Knowledge from evidence",[
    "Science is a systematic way of learning about the natural world through observation, experiment, and reasoning, producing explanations that can be tested against evidence. The word comes from the Latin scientia, “knowledge.” What distinguishes science is not a particular subject but a method: claims must be testable, evidence must be shared and checkable, and conclusions remain open to revision when new evidence appears.",
    "The natural sciences are often divided into the physical sciences (physics, chemistry, astronomy, earth science) and the life sciences (biology and its branches). Mathematics, though not an experimental science, is the language in which much of science is written. The social sciences apply scientific methods to human behavior and society."]],
  ["Hypotheses, theories, and laws",[
    "A hypothesis is a proposed, testable explanation for an observation. A scientific law describes a regular pattern in nature, often as a mathematical relationship, such as Newton's law of gravitation or Boyle's law for gases; it tells us what happens. A scientific theory is a well-tested, comprehensive explanation of why things happen, supported by a large body of evidence, such as the theory of evolution, atomic theory, or the theory of plate tectonics.",
    "In everyday speech, “theory” means a guess, but in science it is the highest level of understanding. Theories do not “graduate” into laws; they do different jobs. Even well-established theories can be refined, as Einstein's relativity refined Newton's mechanics."]],
  ["Falsifiability",[
    "The philosopher Karl Popper argued in the 1930s that what makes a claim scientific is falsifiability: it must be possible, at least in principle, to imagine evidence that would prove it wrong. “All swans are white” is falsifiable, because finding one black swan disproves it, as happened when Europeans encountered black swans in Australia.",
    "Claims that cannot be tested, or that explain every possible outcome, are not scientific. Science therefore never proves theories with absolute certainty; it builds confidence by surviving repeated attempts to disprove them."]],
  ["Peer review and replication",[
    "Scientists share results by publishing papers in journals, after peer review, in which other experts evaluate the methods and conclusions. Results gain credibility when independent researchers can replicate them, obtaining the same results by repeating the work.",
    "In the 2010s, a “replication crisis” revealed that many published findings, especially in psychology and medicine, could not be reproduced, prompting reforms such as preregistering studies, sharing data, and larger sample sizes. Self-correction is a central strength of science."]],
  ["Paradigms and revolutions",[
    "The historian Thomas Kuhn, in The Structure of Scientific Revolutions (1962), argued that science usually proceeds as “normal science” within a paradigm, an accepted framework of theories and methods, until accumulating anomalies trigger a revolution and a paradigm shift, such as the change from an Earth-centered to a Sun-centered universe, or from Newtonian physics to relativity and quantum mechanics.",
    "Kuhn's ideas showed that science is a human activity shaped by communities, though its results are constrained by nature."]],
  ["Science and pseudoscience",[
    "Pseudoscience presents itself as scientific but lacks its methods: claims are untestable, evidence is anecdotal or cherry-picked, contrary evidence is ignored, and ideas never change. Astrology and homeopathy are common examples.",
    "Thinking scientifically means asking: What is the evidence? How was it gathered? Could it be explained another way? Has it been replicated? Extraordinary claims, as the astronomer Carl Sagan said, require extraordinary evidence. These habits of mind are the foundation for everything in this course."]]
  ],
  terms:[["Science","A systematic method of learning about nature through evidence."],["Hypothesis","A testable proposed explanation."],["Scientific law","A description of a regular pattern in nature."],["Scientific theory","A well-tested, comprehensive explanation."],["Falsifiability","The possibility of being proven wrong by evidence."],["Peer review","Evaluation of research by other experts."],["Paradigm shift","A fundamental change in scientific framework."]],
  w:"Understanding how science works lets you judge claims, understand discoveries, and see why scientific knowledge is reliable yet always open to improvement.",
  src:["Science","Scientific theory","Scientific law","Falsifiability","Peer review","Replication crisis","The Structure of Scientific Revolutions"],
  q:[["What does the Latin word scientia mean?","Knowledge","Experiment","Nature","Method"],
     ["What is a well-tested explanation supported by much evidence called?","A theory","A hypothesis","A guess","A law"],
     ["Who argued that scientific claims must be falsifiable?","Karl Popper","Thomas Kuhn","Francis Bacon","Carl Sagan"],
     ["Who wrote The Structure of Scientific Revolutions?","Thomas Kuhn","Karl Popper","Isaac Newton","Richard Feynman"],
     ["What does replication mean?","Independent researchers repeating work and getting the same results","Publishing a paper twice","Copying another scientist's data","Peer review"],
     ["Who said extraordinary claims require extraordinary evidence?","Carl Sagan","Albert Einstein","Galileo","Marie Curie"]]},

{ t:"The Scientific Method and Experiments", s:"How scientists test ideas",
  sec:[
  ["The steps",[
    "The scientific method is not a rigid recipe, but it usually involves observing a phenomenon, asking a question, forming a hypothesis, making a prediction, testing it through experiment or observation, analyzing the data, and drawing conclusions, which lead to new questions.",
    "Francis Bacon, in Novum Organum (1620), championed induction, building general conclusions from many observations, while René Descartes emphasized deduction and mathematics. Modern science combines both."]],
  ["Variables and controls",[
    "In a controlled experiment, the scientist changes one factor, the independent variable, and measures its effect on another, the dependent variable, while keeping all other conditions, the controlled variables, the same. A control group, which does not receive the treatment, provides a baseline for comparison.",
    "For example, to test whether a fertilizer increases plant growth, one group of plants gets fertilizer (the experimental group) and an identical group does not (the control), with the same light, water, and soil; plant height is the dependent variable."]],
  ["Avoiding bias",[
    "Scientists use techniques to avoid fooling themselves. Randomization assigns subjects to groups by chance, so that differences between groups are not due to selection. In a blind study, participants do not know whether they receive the real treatment; in a double-blind study, neither participants nor researchers know, preventing expectations from influencing results.",
    "The placebo effect, in which people improve because they believe they are being treated, is controlled by giving the control group an inactive placebo. Randomized controlled trials (RCTs) are the gold standard in medicine; one of the first, testing streptomycin for tuberculosis, was published in 1948."]],
  ["Correlation and causation",[
    "A correlation is a statistical association between two variables, but correlation does not prove causation. Ice cream sales and drowning deaths both rise in summer, not because ice cream causes drowning but because hot weather causes both; such a hidden factor is a confounding variable.",
    "Establishing causation requires controlled experiments or, when experiments are impossible or unethical, careful observational studies. The link between smoking and lung cancer was established in the 1950s through observational studies by Richard Doll and Austin Bradford Hill, among others, using criteria such as strength, consistency, and dose-response."]],
  ["Data and error",[
    "Every measurement has uncertainty. Random errors scatter measurements unpredictably and can be reduced by repeating measurements and averaging; systematic errors shift all measurements in the same direction, as with a miscalibrated instrument. Accuracy describes how close a measurement is to the true value; precision describes how consistent repeated measurements are.",
    "Larger samples generally give more reliable results. Scientists report results with error bars or confidence intervals and test whether results could have arisen by chance using statistics."]],
  ["Models and simulations",[
    "Scientists use models, simplified representations of reality, to understand and predict systems too complex, large, small, or slow to study directly. Models may be physical (a model of DNA), conceptual (the atom as a solar system), or mathematical and computational, such as climate models and epidemic models.",
    "As the statistician George Box said, “All models are wrong, but some are useful.” A good model captures the essential features of a system and makes testable predictions."]]
  ],
  terms:[["Independent variable","The factor changed in an experiment."],["Dependent variable","The factor measured in response."],["Control group","A group that does not receive the treatment."],["Double-blind","A study in which neither subjects nor researchers know who gets the treatment."],["Placebo","An inactive treatment used for comparison."],["Confounding variable","A hidden factor affecting both variables."],["Accuracy and precision","Closeness to the true value vs. consistency of measurements."]],
  w:"Knowing how good experiments are designed helps you evaluate studies, medical claims, and news headlines with a critical eye.",
  src:["Scientific method","Design of experiments","Randomized controlled trial","Placebo","Correlation does not imply causation","Accuracy and precision","Scientific modelling"],
  q:[["Which variable is deliberately changed in an experiment?","The independent variable","The dependent variable","The controlled variable","The confounding variable"],
     ["Who championed induction in Novum Organum?","Francis Bacon","René Descartes","Galileo","Aristotle"],
     ["In a double-blind study, who does not know who gets the treatment?","Both participants and researchers","Only the participants","Only the researchers","Only the statisticians"],
     ["What is a hidden factor that affects both variables called?","A confounding variable","A control","A placebo","A dependent variable"],
     ["Which describes the consistency of repeated measurements?","Precision","Accuracy","Bias","Validity"],
     ["Who said all models are wrong, but some are useful?","George Box","Karl Popper","Albert Einstein","Niels Bohr"]]},

{ t:"Measurement and Units", s:"The International System and the language of quantities",
  sec:[
  ["Why units matter",[
    "Science depends on precise, shared measurement. A number without a unit is meaningless in science: “5” could be 5 meters or 5 kilometers. Inconsistent units can be disastrous; NASA's Mars Climate Orbiter was lost in 1999 because one team used imperial units (pound-seconds) while another used metric units (newton-seconds).",
    "The metric system was created in France in the 1790s during the Revolution, based on decimal multiples. Today scientists worldwide use its modern form, the International System of Units (SI, from the French Système international), adopted in 1960."]],
  ["The seven base units",[
    "The SI has seven base units: the meter (m) for length, the kilogram (kg) for mass, the second (s) for time, the ampere (A) for electric current, the kelvin (K) for temperature, the mole (mol) for amount of substance, and the candela (cd) for luminous intensity.",
    "Since 2019, all seven are defined by fixing the values of fundamental constants of nature. The meter is defined by the speed of light (exactly 299,792,458 meters per second), the second by the frequency of radiation from cesium atoms, and the kilogram by the Planck constant, replacing the International Prototype Kilogram, a platinum-iridium cylinder kept near Paris since 1889."]],
  ["Derived units and prefixes",[
    "Other units are derived from the base units: the newton (N) for force (kg·m/s²), the joule (J) for energy, the watt (W) for power, the pascal (Pa) for pressure, the volt (V) for electric potential, and the hertz (Hz) for frequency. Many are named after scientists.",
    "Prefixes indicate powers of ten: kilo- (thousand, 10³), mega- (million, 10⁶), giga- (billion, 10⁹), tera- (10¹²); centi- (hundredth, 10⁻²), milli- (thousandth, 10⁻³), micro- (millionth, 10⁻⁶), nano- (billionth, 10⁻⁹), and pico- (10⁻¹²). In 2022 new prefixes were added for extremely large and small numbers: ronna (10²⁷), quetta (10³⁰), ronto, and quecto."]],
  ["Scientific notation",[
    "Science deals with enormous and tiny numbers. Scientific notation writes numbers as a value between 1 and 10 multiplied by a power of ten. The speed of light is about 3 × 10⁸ meters per second; the mass of an electron is about 9.11 × 10⁻³¹ kilograms; Avogadro's number is about 6.022 × 10²³.",
    "Each power of ten is called an order of magnitude. Estimating orders of magnitude, sometimes called Fermi estimation after the physicist Enrico Fermi, is a powerful scientific skill."]],
  ["Temperature scales",[
    "Three temperature scales are common. The Celsius scale sets water's freezing point at 0°C and boiling point at 100°C at sea-level pressure. The Fahrenheit scale, used in the United States, sets them at 32°F and 212°F. The Kelvin scale, used in science, starts at absolute zero, the lowest possible temperature, at 0 K, equal to −273.15°C; a change of one kelvin equals a change of one degree Celsius.",
    "To convert Celsius to Fahrenheit, multiply by 9/5 and add 32. Human body temperature is about 37°C or 98.6°F."]],
  ["Significant figures and dimensions",[
    "Significant figures express the precision of a measurement: 2.50 meters (three significant figures) is more precise than 2.5 meters. Calculations should not report more precision than the data justify.",
    "Dimensional analysis, checking that units are consistent on both sides of an equation, is a powerful tool for catching errors and converting units, for example from kilometers per hour to meters per second (divide by 3.6)."]]
  ],
  terms:[["SI","The International System of Units."],["Base units","The seven fundamental SI units."],["Derived unit","A unit built from base units, such as the newton."],["Scientific notation","Writing numbers as a value times a power of ten."],["Order of magnitude","A factor of ten."],["Absolute zero","The lowest possible temperature, 0 K."],["Significant figures","Digits expressing a measurement's precision."]],
  w:"Measurement and units are the shared language of science, and fluency with them makes every later topic clearer.",
  src:["International System of Units","SI base unit","2019 revision of the SI","Metric prefix","Scientific notation","Kelvin","Mars Climate Orbiter"],
  q:[["Why was the Mars Climate Orbiter lost in 1999?","A mix-up between imperial and metric units","An engine failure","A meteor strike","A software virus"],
     ["Which is NOT an SI base unit?","The newton","The kelvin","The mole","The ampere"],
     ["What constant now defines the kilogram?","The Planck constant","The speed of light","Avogadro's number","The gravitational constant"],
     ["What does the prefix micro- mean?","One millionth","One thousandth","One billionth","One hundredth"],
     ["What is absolute zero in Celsius?","−273.15°C","−100°C","0°C","−459.67°C"],
     ["What is the speed of light in scientific notation?","About 3 × 10⁸ m/s","About 3 × 10⁵ m/s","About 3 × 10¹⁰ m/s","About 3 × 10⁶ m/s"]]},

{ t:"The Scientific Revolution", s:"How modern science began, 1543–1687",
  sec:[
  ["Before the revolution",[
    "For centuries, European thinking about nature followed Aristotle, who taught that the Earth sat motionless at the center of the universe, that heavy objects fall faster than light ones, and that heavenly bodies were perfect and unchanging. The astronomer Ptolemy (2nd century CE) built an elaborate Earth-centered (geocentric) model using circles upon circles, called epicycles, to predict planetary motions.",
    "Medieval Islamic scholars preserved and advanced Greek science, in fields such as optics, where Ibn al-Haytham (about 965–1040) used experiments to study light and vision, and astronomy and mathematics; their work passed to Europe through translations."]],
  ["Copernicus",[
    "In 1543, the Polish astronomer Nicolaus Copernicus published On the Revolutions of the Heavenly Spheres, proposing a heliocentric (Sun-centered) model in which the Earth rotates daily and orbits the Sun with the other planets. His model explained the apparent backward (retrograde) motion of planets more naturally, though it still used circular orbits.",
    "The year 1543 also saw Andreas Vesalius's On the Fabric of the Human Body, which corrected ancient anatomy through careful dissection. These works are often taken as the start of the Scientific Revolution."]],
  ["Tycho and Kepler",[
    "The Danish astronomer Tycho Brahe made the most accurate naked-eye observations of planetary positions ever recorded. His assistant Johannes Kepler used Tycho's data on Mars to discover three laws of planetary motion (1609–1619): planets move in ellipses with the Sun at one focus; a line from the Sun to a planet sweeps out equal areas in equal times, so planets move faster when closer to the Sun; and the square of a planet's orbital period is proportional to the cube of its average distance from the Sun.",
    "Kepler's ellipses replaced the ancient belief in perfect circular orbits."]],
  ["Galileo",[
    "Galileo Galilei (1564–1642) combined experiment and mathematics. He showed that falling objects accelerate uniformly and, neglecting air resistance, fall at the same rate regardless of weight, and he studied pendulums and projectiles. In 1609–1610 he turned a telescope to the sky, discovering mountains on the Moon, four moons orbiting Jupiter, the phases of Venus, and countless stars in the Milky Way, evidence against the geocentric model.",
    "His support for Copernicus brought him into conflict with the Catholic Church; in 1633 the Inquisition forced him to recant and placed him under house arrest for the rest of his life. The Church formally acknowledged its error in 1992."]],
  ["Newton",[
    "Isaac Newton (1643–1727) unified the work of his predecessors in Mathematical Principles of Natural Philosophy (Principia, 1687), setting out three laws of motion and the law of universal gravitation, which showed that the same force that makes an apple fall keeps the Moon in orbit and explains Kepler's laws. He also developed calculus (independently of Gottfried Leibniz), showed that white light consists of a spectrum of colors, and built the first practical reflecting telescope.",
    "Newton's achievement demonstrated that the universe follows mathematical laws that humans can discover, a model for all later science."]],
  ["A new way of knowing",[
    "The Scientific Revolution established experiment, measurement, and mathematics as the path to knowledge, rather than ancient authority. Scientific societies such as the Royal Society of London (1660) and the French Academy of Sciences (1666) promoted research, and journals spread results.",
    "New instruments, the telescope, microscope, thermometer, barometer, and pendulum clock, extended the senses. Robert Boyle studied gases, and Robert Hooke and Antonie van Leeuwenhoek used microscopes to discover cells and microorganisms. The revolution laid the foundations of modern physics, astronomy, and biology."]]
  ],
  terms:[["Geocentric model","The Earth-centered universe of Aristotle and Ptolemy."],["Heliocentric model","The Sun-centered model of Copernicus."],["Kepler's laws","Three laws describing planetary orbits."],["Ellipse","An oval orbit shape with two foci."],["Principia","Newton's 1687 work on motion and gravity."],["Royal Society","Britain's scientific society founded in 1660."]],
  w:"The Scientific Revolution created the methods of modern science and replaced ancient authority with experiment, measurement, and mathematical law.",
  src:["Scientific Revolution","Nicolaus Copernicus","Tycho Brahe","Kepler's laws of planetary motion","Galileo Galilei","Philosophiæ Naturalis Principia Mathematica","Ibn al-Haytham"],
  q:[["Who proposed the heliocentric model in 1543?","Copernicus","Galileo","Kepler","Ptolemy"],
     ["Whose observations did Kepler use?","Tycho Brahe's","Galileo's","Copernicus's","Newton's"],
     ["What shape did Kepler show planetary orbits to be?","Ellipses","Circles","Spirals","Epicycles"],
     ["Which moons did Galileo discover?","Four moons of Jupiter","Saturn's rings","Mars's moons","The Moon's far side"],
     ["In what year was Newton's Principia published?","1687","1543","1610","1727"],
     ["Who used experiments to study light and vision around 1000 CE?","Ibn al-Haytham","Avicenna","Al-Khwarizmi","Ptolemy"]]}

]});


/* ---- from sci-02.js ---- */
/* SCIENCES FOUNDATIONS, part 2: Unit 2 Mathematics, chapters 1-4 */
COURSES.sciences.units.push({ t:"The Language of Mathematics", ch:[

{ t:"Numbers", s:"From counting to the real and complex numbers",
  sec:[
  ["Counting and number systems",[
    "Mathematics began with counting. Tally marks on bones, such as the Ishango bone from central Africa (perhaps 20,000 years old), may be early records of numbers. The Babylonians used a base-60 (sexagesimal) system, which survives in our 60 minutes, 60 seconds, and 360 degrees in a circle; the Maya used base 20; and the Romans used letters (I, V, X, L, C, D, M) that made arithmetic awkward.",
    "Our decimal place-value system, with ten digits including zero, was developed in India by the 5th–7th centuries CE; the mathematician Brahmagupta (628) gave rules for calculating with zero and negative numbers. It spread through the Islamic world, especially via the 9th-century Persian mathematician al-Khwarizmi, whose name gave us the word “algorithm,” and reached Europe through Leonardo of Pisa (Fibonacci) in 1202. We call the digits Hindu-Arabic numerals."]],
  ["Kinds of numbers",[
    "Natural numbers are the counting numbers 1, 2, 3, and so on (sometimes including 0). Integers add negative numbers and zero. Rational numbers can be written as fractions of integers, such as 3/4 or −2/5; their decimal forms either end or repeat.",
    "Irrational numbers cannot be written as fractions, and their decimals never end or repeat. The ancient Greeks discovered that the square root of 2, the diagonal of a unit square, is irrational, reportedly to the dismay of the Pythagoreans. Pi (π ≈ 3.14159), the ratio of a circle's circumference to its diameter, and e (≈ 2.71828), the base of natural logarithms, are famous irrational numbers. Together, rational and irrational numbers make up the real numbers, which fill the number line."]],
  ["Primes",[
    "A prime number is a natural number greater than 1 whose only divisors are 1 and itself: 2, 3, 5, 7, 11, 13, and so on. The Fundamental Theorem of Arithmetic states that every whole number greater than 1 can be written uniquely as a product of primes, so primes are the building blocks of numbers. Euclid proved around 300 BCE that there are infinitely many primes.",
    "Primes are vital in modern cryptography: RSA encryption, which secures internet communication, relies on the fact that multiplying two large primes is easy, but factoring the product back into primes is extremely hard. The Riemann Hypothesis, about the distribution of primes, is one of the greatest unsolved problems in mathematics."]],
  ["Complex numbers",[
    "Mathematicians found it useful to define the imaginary unit i as the square root of −1. Complex numbers have the form a + bi, combining real and imaginary parts, and can be pictured as points on a plane. Though once viewed with suspicion, they are essential in electrical engineering, signal processing, and quantum mechanics.",
    "Euler's identity, e^(iπ) + 1 = 0, connecting five fundamental constants, is often called the most beautiful equation in mathematics."]],
  ["Infinity",[
    "Infinity is not a number but a concept of endlessness. In the 1870s Georg Cantor showed that there are different sizes of infinity: the set of natural numbers can be put in one-to-one correspondence with the rational numbers, so they are the same size (countable), but the real numbers are uncountably infinite, a larger infinity.",
    "Paradoxes of infinity, such as Zeno's ancient paradoxes about motion, were resolved through the mathematics of limits."]],
  ["Number sense in science",[
    "Scientists work with ratios, percentages, rates, exponents, and logarithms. A logarithm answers the question “to what power must a base be raised to give this number?”: log₁₀(1000) = 3. Logarithmic scales compress huge ranges, as in the Richter and decibel scales and the pH scale.",
    "Exponential growth, in which a quantity grows by a fixed percentage over equal time periods, as in compound interest, populations, and epidemics, can be deceptively rapid: something doubling every day grows more than a thousandfold in ten days."]]
  ],
  terms:[["Place value","A system in which a digit's position determines its value."],["Rational number","A number that can be written as a fraction."],["Irrational number","A number whose decimal never ends or repeats."],["Prime number","A number divisible only by 1 and itself."],["Complex number","A number of the form a + bi."],["Logarithm","The power to which a base must be raised to produce a number."],["Exponential growth","Growth by a fixed percentage per time period."]],
  w:"Numbers are the foundation of all quantitative science, from measuring the universe to encrypting messages.",
  src:["Number","Hindu–Arabic numeral system","Irrational number","Prime number","Complex number","Euler's identity","Georg Cantor"],
  q:[["Which civilization used base 60?","The Babylonians","The Maya","The Romans","The Egyptians"],
     ["Whose name gave us the word algorithm?","Al-Khwarizmi","Brahmagupta","Fibonacci","Euclid"],
     ["Which of these is irrational?","The square root of 2","3/4","0.25","−7"],
     ["Who proved there are infinitely many primes?","Euclid","Pythagoras","Euler","Gauss"],
     ["What is i defined as?","The square root of −1","Infinity","Pi","Zero"],
     ["Who showed there are different sizes of infinity?","Georg Cantor","Leonhard Euler","Isaac Newton","Zeno"]]},

{ t:"Algebra and Functions", s:"Unknowns, equations, and relationships",
  sec:[
  ["What algebra is",[
    "Algebra uses symbols, usually letters, to represent unknown or variable quantities, allowing general rules and relationships to be expressed and solved. The word comes from the Arabic al-jabr, “restoration,” in the title of al-Khwarizmi's 9th-century treatise on solving equations.",
    "Modern symbolic notation developed gradually; the French mathematician François Viète used letters for quantities in the 1590s, and René Descartes popularized using x, y, and z for unknowns in 1637."]],
  ["Equations",[
    "An equation states that two expressions are equal. Solving an equation means finding the values of the unknown that make it true, by performing the same operation on both sides. A linear equation, such as 2x + 3 = 11, has variables raised only to the first power; its solution here is x = 4.",
    "A quadratic equation has the form ax² + bx + c = 0 and can be solved with the quadratic formula, x = (−b ± √(b² − 4ac)) / 2a, giving up to two solutions. Systems of equations involve several unknowns and several equations solved together."]],
  ["Functions",[
    "A function is a rule that assigns exactly one output to each input, written f(x). For example, f(x) = 2x + 1 doubles the input and adds one. Functions are the core tool for describing how one quantity depends on another in science: how distance depends on time, or how pressure depends on volume.",
    "Common types include linear functions (straight-line graphs), quadratic functions (parabolas, as in the path of a thrown ball), exponential functions (rapid growth or decay, as in radioactive decay), logarithmic functions, and periodic functions such as sine and cosine (waves and oscillations)."]],
  ["Graphs",[
    "Descartes and Pierre de Fermat developed coordinate geometry in the 17th century, linking algebra and geometry by plotting points on a plane with x and y axes (Cartesian coordinates). Every equation in x and y corresponds to a curve.",
    "The graph of a linear function y = mx + b is a straight line with slope m, the rate of change (rise over run), and y-intercept b. Reading graphs, their slopes, intercepts, and shapes, is one of the most important skills in science."]],
  ["Proportion and inverse relationships",[
    "Two quantities are directly proportional if one is a constant multiple of the other: double one and the other doubles, as with distance traveled at constant speed and time. They are inversely proportional if their product is constant: double one and the other halves, as in Boyle's law, where a gas's pressure doubles when its volume is halved at constant temperature.",
    "Inverse-square laws, in which a quantity decreases with the square of distance, describe gravity, electric force, and the intensity of light and sound: twice as far means one-quarter as strong."]],
  ["Vectors and matrices",[
    "Some quantities have only magnitude (size), such as mass, temperature, and speed; these are scalars. Others have both magnitude and direction, such as velocity, force, and displacement; these are vectors, often drawn as arrows. Vectors are added by placing them tip to tail.",
    "Matrices, rectangular arrays of numbers, represent systems of equations and transformations, and linear algebra, the mathematics of vectors and matrices, underlies computer graphics, quantum mechanics, statistics, and machine learning."]]
  ],
  terms:[["Variable","A symbol representing an unknown or changing quantity."],["Equation","A statement that two expressions are equal."],["Quadratic formula","The formula solving ax² + bx + c = 0."],["Function","A rule assigning one output to each input."],["Slope","The rate of change of a line."],["Inverse-square law","A quantity decreasing with the square of distance."],["Vector","A quantity with magnitude and direction."]],
  w:"Algebra and functions provide the language to describe relationships in nature, and graphs make those relationships visible.",
  src:["Algebra","Al-Khwarizmi","Quadratic formula","Function (mathematics)","Cartesian coordinate system","Inverse-square law","Euclidean vector"],
  q:[["What does al-jabr mean?","Restoration","Unknown","Balance","Number"],
     ["What is the solution of 2x + 3 = 11?","x = 4","x = 7","x = 5.5","x = 3"],
     ["What shape is the graph of a quadratic function?","A parabola","A straight line","A circle","A wave"],
     ["Who developed coordinate geometry with Fermat?","René Descartes","Isaac Newton","Euclid","Leibniz"],
     ["If a quantity follows an inverse-square law, what happens at twice the distance?","It becomes one-quarter as strong","It halves","It doubles","It stays the same"],
     ["Which is a vector quantity?","Velocity","Mass","Temperature","Time"]]},

{ t:"Geometry and Trigonometry", s:"Shapes, space, and angles",
  sec:[
  ["Euclid's geometry",[
    "Geometry (“earth measurement”) originated in practical surveying in Egypt and Mesopotamia. The Greeks made it a deductive science. Euclid's Elements (about 300 BCE), the most influential mathematics textbook in history, began with definitions and five postulates and logically proved hundreds of theorems about points, lines, angles, triangles, and circles.",
    "Euclid's fifth postulate, about parallel lines, puzzled mathematicians for centuries. In the 19th century, Gauss, Lobachevsky, Bolyai, and Riemann developed non-Euclidean geometries in which it does not hold, on curved surfaces; Einstein later used Riemannian geometry to describe curved spacetime."]],
  ["Triangles and angles",[
    "The angles of a triangle in a flat plane always add up to 180 degrees. A right triangle has one 90-degree angle. Similar triangles have the same shape but different sizes, with proportional sides, a principle used by Thales of Miletus, according to tradition, to measure the height of an Egyptian pyramid from its shadow.",
    "Angles are measured in degrees (360 in a full circle) or radians, where a full circle is 2π radians; one radian is the angle subtended by an arc equal in length to the radius. Scientists usually prefer radians."]],
  ["The Pythagorean theorem",[
    "The Pythagorean theorem states that in a right triangle, the square of the hypotenuse (the side opposite the right angle) equals the sum of the squares of the other two sides: a² + b² = c². A triangle with sides 3, 4, and 5 is a classic example. Named after the Greek Pythagoras, the relationship was known earlier to the Babylonians and also in ancient India and China.",
    "It is used to calculate distances in navigation, construction, physics, and computer graphics; the distance between two points on a coordinate plane follows directly from it."]],
  ["Circles, areas, and volumes",[
    "A circle's circumference is 2πr and its area is πr², where r is the radius. Archimedes (3rd century BCE) estimated π by inscribing polygons in circles and proved that a sphere's volume is two-thirds that of its enclosing cylinder, a result he was so proud of that he asked for it on his tomb.",
    "Key formulas include the area of a rectangle (length × width), a triangle (½ × base × height), the volume of a rectangular box (length × width × height), a cylinder (πr²h), and a sphere (4/3 πr³). Surface area and volume scale differently: doubling an object's size multiplies its area by four and its volume by eight, which explains why large animals have thick legs and small animals lose heat quickly."]],
  ["Trigonometry",[
    "Trigonometry studies the relationships between angles and side lengths of triangles. In a right triangle, the sine of an angle is the opposite side divided by the hypotenuse, the cosine is the adjacent side divided by the hypotenuse, and the tangent is opposite over adjacent, remembered by the mnemonic SOH-CAH-TOA.",
    "Trigonometry was developed by Greek astronomers such as Hipparchus, by Indian mathematicians, who introduced the sine, and by Islamic scholars. It allows measurement of inaccessible distances, such as mountain heights and the distance to the Moon and nearby stars (by parallax), and is essential for surveying, navigation, and engineering."]],
  ["Waves and symmetry",[
    "Sine and cosine functions repeat in regular cycles and describe waves and oscillations: sound, light, alternating current, pendulums, and tides. Joseph Fourier showed in the early 19th century that any complex periodic signal can be built from sums of simple sine waves, the basis of modern signal processing, music technology, and image compression.",
    "Symmetry, the property of remaining unchanged under transformations such as reflection or rotation, appears throughout nature, from snowflakes to crystals and the laws of physics, and is studied mathematically through group theory."]]
  ],
  terms:[["Euclid's Elements","The classic textbook of geometry, about 300 BCE."],["Non-Euclidean geometry","Geometry on curved surfaces."],["Radian","An angle measure; a full circle is 2π radians."],["Pythagorean theorem","a² + b² = c² in a right triangle."],["Pi","The ratio of circumference to diameter, about 3.14159."],["Sine, cosine, tangent","Ratios of sides in a right triangle."],["Fourier analysis","Breaking signals into sine waves."]],
  w:"Geometry and trigonometry let scientists measure the world and the heavens, and describe waves, shapes, and space itself.",
  src:["Euclid's Elements","Non-Euclidean geometry","Pythagorean theorem","Archimedes","Trigonometry","Radian","Fourier series"],
  q:[["Who wrote the Elements?","Euclid","Pythagoras","Archimedes","Thales"],
     ["What do the angles of a flat triangle add up to?","180 degrees","360 degrees","90 degrees","270 degrees"],
     ["What does the Pythagorean theorem state?","a² + b² = c²","a + b = c","a² = b² + c","c = 2πr"],
     ["What is the area of a circle?","πr²","2πr","4/3πr³","πd"],
     ["What is sine in a right triangle?","Opposite over hypotenuse","Adjacent over hypotenuse","Opposite over adjacent","Hypotenuse over opposite"],
     ["Who showed that complex signals can be built from sine waves?","Joseph Fourier","Archimedes","Hipparchus","Riemann"]]},

{ t:"Calculus", s:"The mathematics of change",
  sec:[
  ["Why calculus",[
    "Calculus is the mathematics of continuous change and accumulation. It was developed independently in the 1660s–1680s by Isaac Newton, who called it the method of fluxions, and Gottfried Wilhelm Leibniz, whose notation, including dy/dx and the integral sign ∫, is still used. A bitter priority dispute followed between their supporters.",
    "Calculus made it possible to describe motion, growth, and change precisely, and it became the essential tool of physics, engineering, economics, and biology."]],
  ["Limits",[
    "Calculus rests on the idea of a limit, the value a quantity approaches as another quantity gets closer and closer to some value. For example, the average speed over shorter and shorter time intervals approaches the instantaneous speed at a moment.",
    "Limits were made rigorous in the 19th century by mathematicians such as Augustin-Louis Cauchy and Karl Weierstrass, resolving earlier doubts about vanishingly small “infinitesimals.”"]],
  ["Derivatives",[
    "The derivative measures the instantaneous rate of change of a function, geometrically the slope of the tangent line to its graph at a point. If position changes with time, its derivative is velocity; the derivative of velocity is acceleration. For f(x) = x², the derivative is 2x.",
    "Derivatives are used to find maximum and minimum values, where the slope is zero, for problems such as maximizing profit, minimizing material, or finding the highest point of a projectile's path."]],
  ["Integrals",[
    "The integral measures accumulation, geometrically the area under a curve. If you know velocity at every moment, integrating it over time gives total distance traveled. Archimedes had approximated areas using thin slices, an idea calculus generalized.",
    "The Fundamental Theorem of Calculus states that differentiation and integration are inverse operations, linking rates of change and accumulation, one of the most powerful results in mathematics."]],
  ["Differential equations",[
    "Many laws of nature are expressed as differential equations, which relate a quantity to its rates of change. Newton's second law, Maxwell's equations of electromagnetism, the Schrödinger equation of quantum mechanics, equations of population growth, and models of epidemics and climate are all differential equations.",
    "Solving them predicts how systems evolve over time. Many cannot be solved exactly and are solved approximately with computers, through numerical methods."]],
  ["Calculus everywhere",[
    "Calculus is used to calculate planetary orbits and spacecraft trajectories, design bridges and aircraft, model the spread of diseases, price financial options, optimize machine learning algorithms, and analyze images.",
    "Even without doing calculations, understanding the ideas of rates of change and accumulation, how fast something is changing versus how much has built up, helps make sense of science, from speed and acceleration to carbon emissions and atmospheric carbon dioxide."]]
  ],
  terms:[["Calculus","The mathematics of change and accumulation."],["Limit","The value a quantity approaches."],["Derivative","The instantaneous rate of change, or slope."],["Integral","Accumulation, or area under a curve."],["Fundamental Theorem of Calculus","Differentiation and integration are inverses."],["Differential equation","An equation relating a quantity to its rates of change."]],
  w:"Calculus is the mathematical engine of physics and engineering, describing how everything from planets to populations changes over time.",
  src:["Calculus","Leibniz–Newton calculus controversy","Limit (mathematics)","Derivative","Integral","Fundamental theorem of calculus","Differential equation"],
  q:[["Who developed calculus independently of Newton?","Gottfried Wilhelm Leibniz","René Descartes","Leonhard Euler","Blaise Pascal"],
     ["What did Newton call calculus?","The method of fluxions","Infinitesimal analysis","The calculus of variations","Algebra"],
     ["What is the derivative of position with respect to time?","Velocity","Acceleration","Distance","Force"],
     ["What does an integral measure geometrically?","The area under a curve","The slope of a curve","A maximum","A limit"],
     ["What is the derivative of x²?","2x","x","x³/3","2"],
     ["What links differentiation and integration?","The Fundamental Theorem of Calculus","The Pythagorean theorem","Euler's identity","The quadratic formula"]]}

]});


/* ---- from sci-03.js ---- */
/* SCIENCES FOUNDATIONS, part 3: Unit 2 chapters 5-7 */
COURSES.sciences.units[1].ch.push(

{ t:"Probability", s:"The mathematics of chance",
  sec:[
  ["Origins in gambling",[
    "Probability theory began with gambling. In 1654 the French mathematicians Blaise Pascal and Pierre de Fermat exchanged letters solving the “problem of points,” how to divide the stakes fairly in an interrupted game of chance, laying the foundations of the field. Christiaan Huygens published the first book on probability in 1657, and Jacob Bernoulli proved the law of large numbers, published in 1713.",
    "Today probability underpins statistics, insurance, finance, genetics, quantum physics, weather forecasting, and artificial intelligence."]],
  ["Basic rules",[
    "The probability of an event is a number from 0 (impossible) to 1 (certain), often expressed as a percentage. For equally likely outcomes, probability equals the number of favorable outcomes divided by the total number of outcomes: the chance of rolling a 6 on a fair die is 1/6.",
    "For independent events, which do not affect each other, the probability that both occur is the product of their probabilities: two coin flips both landing heads has probability 1/2 × 1/2 = 1/4. For mutually exclusive events, the probability that one or the other occurs is the sum of their probabilities. The probability that an event does not occur is 1 minus its probability."]],
  ["The law of large numbers",[
    "The law of large numbers states that as an experiment is repeated many times, the average result gets closer to the expected value. Flip a fair coin ten times and you may get seven heads; flip it ten thousand times and the proportion will be very close to one half.",
    "The gambler's fallacy is the mistaken belief that past independent events affect future ones, for example that after five reds at roulette, black is “due.” Each spin is independent; the wheel has no memory."]],
  ["Conditional probability and Bayes",[
    "Conditional probability is the probability of an event given that another has occurred. Bayes' theorem, named after the 18th-century English minister Thomas Bayes, shows how to update the probability of a hypothesis in light of new evidence, combining prior probability with the likelihood of the evidence.",
    "Bayesian reasoning reveals surprising results. If a disease affects 1 in 1,000 people and a test is 99 percent accurate, a positive result still means only about a 9 percent chance of having the disease, because false positives among the many healthy people outnumber true positives. Ignoring the base rate is a common error, called the base rate fallacy."]],
  ["Distributions",[
    "A probability distribution describes how likely each possible outcome is. The normal distribution, or bell curve, described by Carl Friedrich Gauss and others, is symmetric around the mean and describes many natural measurements, such as heights and measurement errors. In a normal distribution, about 68 percent of values lie within one standard deviation of the mean and about 95 percent within two.",
    "The central limit theorem explains why the normal distribution is so common: the sum or average of many independent random factors tends to be normally distributed, whatever the underlying distribution. Other distributions describe waiting times, rare events, and extreme values."]],
  ["Risk and intuition",[
    "Human intuition about probability is often poor. People overestimate rare, dramatic risks such as plane crashes and shark attacks, and underestimate common ones such as car accidents and heart disease. In the birthday problem, only 23 people are needed for a better than even chance that two share a birthday.",
    "Understanding probability helps people make better decisions about health, money, and risk, and interpret statements such as a “30 percent chance of rain,” which means rain is expected on about 30 percent of days with similar conditions."]]
  ],
  terms:[["Probability","A number from 0 to 1 measuring likelihood."],["Independent events","Events that do not affect each other."],["Law of large numbers","Averages approach expected values over many trials."],["Gambler's fallacy","The false belief that past independent events affect future ones."],["Bayes' theorem","A rule for updating probabilities with evidence."],["Normal distribution","The symmetric bell curve."],["Central limit theorem","Sums of many random factors tend toward a normal distribution."]],
  w:"Probability is the mathematics of uncertainty, essential for interpreting scientific results, medical tests, and everyday risks.",
  src:["Probability theory","Problem of points","Law of large numbers","Gambler's fallacy","Bayes' theorem","Normal distribution","Birthday problem"],
  q:[["Which two mathematicians founded probability theory in 1654?","Pascal and Fermat","Newton and Leibniz","Gauss and Euler","Bernoulli and Bayes"],
     ["What is the probability of two fair coin flips both landing heads?","1/4","1/2","1/8","3/4"],
     ["What is the gambler's fallacy?","Believing past independent events affect future ones","Believing in luck","Betting too much","Ignoring probability"],
     ["Which theorem updates probabilities with new evidence?","Bayes' theorem","The central limit theorem","The law of large numbers","Fermat's theorem"],
     ["What share of values lie within one standard deviation in a normal distribution?","About 68 percent","About 50 percent","About 95 percent","About 99.7 percent"],
     ["How many people are needed for a better than even chance of a shared birthday?","23","183","50","365"]]},

{ t:"Statistics", s:"Making sense of data",
  sec:[
  ["Describing data",[
    "Statistics is the science of collecting, analyzing, and interpreting data. Descriptive statistics summarize data. Measures of central tendency include the mean (the average, sum divided by count), the median (the middle value when data are ordered), and the mode (the most common value).",
    "The median is often more representative than the mean when data are skewed by extreme values: in a room of nine people earning 50,000 dollars and one billionaire, the mean income is over 100 million dollars, but the median is 50,000. Measures of spread include the range and the standard deviation, which measures how far values typically lie from the mean."]],
  ["Samples and populations",[
    "Scientists usually cannot measure an entire population, so they study a sample and generalize. A sample must be representative; random sampling, in which every member has an equal chance of selection, reduces bias. Biased samples lead to wrong conclusions: the Literary Digest poll of 1936, using telephone and car owner lists, wrongly predicted Alf Landon would defeat Franklin Roosevelt.",
    "Larger samples give more precise estimates. Polls report a margin of error, often around plus or minus 3 percentage points for about 1,000 respondents."]],
  ["Inference and significance",[
    "Inferential statistics draws conclusions about populations from samples and tests hypotheses. A null hypothesis assumes no effect, such as a drug having no benefit. The p-value is the probability of observing results at least as extreme as those found if the null hypothesis were true; by convention, p < 0.05 has been called “statistically significant.”",
    "Statistical significance is often misunderstood: it does not measure the size or importance of an effect, and a p-value below 0.05 does not prove a hypothesis. Testing many hypotheses increases the chance of false positives, and “p-hacking,” manipulating analyses until results become significant, contributed to the replication crisis. Confidence intervals and effect sizes give more complete information."]],
  ["Correlation and regression",[
    "Correlation measures the strength and direction of a linear relationship between two variables, with the correlation coefficient r ranging from −1 (perfect negative) through 0 (none) to +1 (perfect positive). Regression fits a line or curve to data to describe and predict relationships; Francis Galton coined “regression to the mean” in the 1880s after noticing that the children of very tall parents tend to be less extremely tall.",
    "Regression to the mean explains many illusions: an athlete's exceptional season is often followed by a more ordinary one simply by chance, not because of a curse."]],
  ["How statistics mislead",[
    "Statistics can mislead through biased samples, cherry-picked data, misleading graphs with truncated axes, confusing relative and absolute risk, and ignoring confounding factors. A drug that reduces risk from 2 in 10,000 to 1 in 10,000 can be described as cutting risk by “50 percent,” though the absolute reduction is tiny.",
    "Simpson's paradox occurs when a trend in several groups reverses when the groups are combined, as in a famous 1973 study of graduate admissions at the University of California, Berkeley, where overall figures suggested bias against women but department-level data did not. Darrell Huff's 1954 book How to Lie with Statistics remains a classic warning."]],
  ["Big data",[
    "Modern science and business generate enormous data sets, analyzed with computational statistics and machine learning to find patterns, from genomics to astronomy and online behavior. Florence Nightingale pioneered persuasive statistical graphics in the 1850s with her polar area diagrams showing that more soldiers died from disease than wounds in the Crimean War.",
    "Statistical literacy, understanding averages, variation, samples, significance, and risk, is one of the most practical skills science offers."]]
  ],
  terms:[["Mean, median, mode","Measures of central tendency."],["Standard deviation","A measure of how spread out data are."],["Random sample","A sample in which each member has an equal chance of selection."],["Margin of error","The expected range of sampling error."],["P-value","The probability of results at least as extreme if there were no effect."],["Regression to the mean","Extreme results tend to be followed by more average ones."],["Simpson's paradox","A trend reversing when groups are combined."]],
  w:"Statistics turns data into knowledge, and understanding it protects you from misleading claims while revealing what evidence really shows.",
  src:["Statistics","Median","Standard deviation","Sampling (statistics)","P-value","Regression toward the mean","Simpson's paradox"],
  q:[["Which measure is the middle value of ordered data?","The median","The mean","The mode","The range"],
     ["Which 1936 poll wrongly predicted Roosevelt's defeat?","The Literary Digest poll","The Gallup poll","The Roper poll","The Harris poll"],
     ["What threshold has conventionally been called statistically significant?","p < 0.05","p > 0.5","p = 1","p < 0.5"],
     ["Who coined regression to the mean?","Francis Galton","Karl Pearson","Ronald Fisher","Florence Nightingale"],
     ["What is a trend reversing when groups are combined called?","Simpson's paradox","The gambler's fallacy","Regression","The base rate fallacy"],
     ["Who pioneered statistical graphics in the Crimean War?","Florence Nightingale","Francis Galton","John Snow","William Playfair"]]},

{ t:"Computing and Algorithms", s:"From logic to artificial intelligence",
  sec:[
  ["Logic and binary",[
    "Modern computing rests on logic and binary numbers. In 1854 the English mathematician George Boole developed Boolean algebra, in which variables are true or false, combined with operations such as AND, OR, and NOT. In 1937 Claude Shannon showed that Boolean logic could be implemented with electrical switching circuits, the foundation of digital electronics.",
    "Computers represent all information, numbers, text, images, sound, as binary digits (bits), 0s and 1s. Eight bits make a byte. In binary, the number 5 is written 101 (4 + 0 + 1)."]],
  ["Early machines",[
    "Charles Babbage designed mechanical computing engines in the 19th century, including the Analytical Engine, a general-purpose programmable machine never completed. Ada Lovelace, in notes published in 1843, described how it could calculate Bernoulli numbers, often considered the first computer program, and foresaw that such machines might manipulate symbols beyond numbers.",
    "In 1936 Alan Turing described an abstract “universal machine” that could compute anything computable, defining the limits of computation and proving that some problems, such as deciding in general whether any program will halt, cannot be solved by any algorithm. During World War II, Turing helped break German Enigma codes at Bletchley Park."]],
  ["Electronic computers",[
    "The first electronic digital computers appeared during and after World War II, such as Colossus in Britain (1943–1944) for codebreaking and ENIAC in the United States (1945), which used about 18,000 vacuum tubes. John von Neumann described the stored-program architecture still used today, in which instructions and data share memory.",
    "The transistor, invented at Bell Labs in 1947, and the integrated circuit (1958–1959) made computers smaller, faster, and cheaper. Gordon Moore observed in 1965 that the number of transistors on a chip doubled roughly every two years, a trend called Moore's law that held for decades; modern chips contain billions of transistors."]],
  ["Algorithms",[
    "An algorithm is a finite, step-by-step procedure for solving a problem, like a recipe. Euclid's algorithm for finding the greatest common divisor of two numbers is over 2,000 years old. Computer science studies the efficiency of algorithms: searching a sorted list by repeatedly halving it (binary search) is far faster than checking every item.",
    "Some problems appear to require impractically long computation as they grow. Whether every problem whose solution can be quickly checked can also be quickly solved, the “P versus NP” problem, is one of the great open questions of mathematics, with a million-dollar prize."]],
  ["Computers in science",[
    "Computers revolutionized science by enabling simulations of complex systems too difficult for experiments: weather and climate, galaxy formation, protein folding, nuclear reactions, and the spread of epidemics. Computational science is now considered a third pillar alongside theory and experiment.",
    "Big projects, such as the Human Genome Project and the Large Hadron Collider, generate data requiring vast computing power, and distributed and cloud computing allow scientists worldwide to share resources."]],
  ["Artificial intelligence",[
    "Artificial intelligence (AI), a term coined by John McCarthy for a 1956 Dartmouth workshop, seeks to make machines perform tasks requiring intelligence. Early AI used rules and logic; modern AI relies on machine learning, in which systems learn patterns from data, especially deep learning with artificial neural networks loosely inspired by the brain.",
    "Landmarks include IBM's Deep Blue defeating chess champion Garry Kasparov (1997), DeepMind's AlphaGo defeating Go champion Lee Sedol (2016), AlphaFold predicting protein structures (2020), recognized with a share of the 2024 Nobel Prize in Chemistry, and large language models such as ChatGPT (2022). AI raises questions about reliability, bias, jobs, and safety that society is actively debating."]]
  ],
  terms:[["Boolean algebra","Logic of true and false values."],["Bit","A binary digit, 0 or 1."],["Turing machine","An abstract model of computation."],["Transistor","An electronic switch invented in 1947."],["Moore's law","Transistor counts doubling about every two years."],["Algorithm","A step-by-step procedure for solving a problem."],["Machine learning","Systems that learn patterns from data."]],
  w:"Computing grew from logic and mathematics into the tool that powers modern science and is now reshaping society through artificial intelligence.",
  src:["Boolean algebra","Ada Lovelace","Alan Turing","ENIAC","Transistor","Moore's law","History of artificial intelligence"],
  q:[["Who developed the algebra of true and false?","George Boole","Claude Shannon","Alan Turing","Charles Babbage"],
     ["Who is often credited with the first computer program?","Ada Lovelace","Charles Babbage","Grace Hopper","John von Neumann"],
     ["What is the number 5 in binary?","101","110","111","100"],
     ["Where was the transistor invented in 1947?","Bell Labs","IBM","MIT","Bletchley Park"],
     ["Who coined the term artificial intelligence?","John McCarthy","Alan Turing","Marvin Minsky","Claude Shannon"],
     ["Which program defeated Go champion Lee Sedol in 2016?","AlphaGo","Deep Blue","Watson","AlphaFold"]]}

);


/* ---- from sci-04.js ---- */
/* SCIENCES FOUNDATIONS, part 4: Unit 3 Physics, chapters 1-5 */
COURSES.sciences.units.push({ t:"Physics", ch:[

{ t:"Describing Motion", s:"Position, velocity, and acceleration",
  sec:[
  ["Kinematics",[
    "Physics is the study of matter, energy, space, time, and the fundamental forces that govern them. Mechanics, its oldest branch, studies motion; kinematics describes motion without asking what causes it.",
    "To describe motion we need a reference frame, a point of view from which positions are measured. A passenger walking down the aisle of a moving train has one speed relative to the train and another relative to the ground; all motion is relative to some frame."]],
  ["Distance, displacement, speed, and velocity",[
    "Distance is the total length of a path traveled; displacement is the straight-line change in position, with a direction. A runner who completes one lap of a 400-meter track has run 400 meters but has zero displacement.",
    "Speed is distance divided by time; velocity is displacement divided by time and includes direction, so it is a vector. A car going around a curve at a constant 60 km/h has constant speed but changing velocity. Average speed differs from instantaneous speed, shown on a speedometer at a particular moment."]],
  ["Acceleration",[
    "Acceleration is the rate of change of velocity, measured in meters per second squared (m/s²). An object accelerates when it speeds up, slows down (sometimes called deceleration), or changes direction. A car going from 0 to 100 km/h in 5 seconds has an average acceleration of about 5.6 m/s².",
    "For constant acceleration, simple equations relate distance, velocity, acceleration, and time; for example, an object starting from rest travels a distance d = ½at² in time t."]],
  ["Free fall",[
    "Near the Earth's surface, in the absence of air resistance, all objects fall with the same acceleration, about 9.8 m/s², called g. Every second, a falling object's velocity increases by about 9.8 m/s. Galileo established this, contradicting Aristotle's claim that heavier objects fall faster; according to a story of uncertain truth, he dropped balls from the Leaning Tower of Pisa.",
    "In 1971 the Apollo 15 astronaut David Scott dropped a hammer and a feather on the airless Moon, and they hit the ground together. On Earth, air resistance slows light, broad objects; a falling object eventually reaches terminal velocity, when air resistance balances gravity, about 200 km/h for a skydiver in a belly-down position."]],
  ["Projectile motion",[
    "A projectile, such as a thrown ball or cannonball, moves in two independent ways at once: horizontally at constant velocity (ignoring air resistance) and vertically with constant downward acceleration due to gravity. The combination produces a curved path called a parabola.",
    "A bullet fired horizontally and one dropped from the same height at the same moment hit the ground at the same time, because their vertical motions are identical. Ignoring air resistance, a projectile travels farthest when launched at 45 degrees."]],
  ["Graphs of motion",[
    "Motion is often described with graphs. On a position-time graph, the slope gives velocity; a straight line means constant velocity and a curve means acceleration. On a velocity-time graph, the slope gives acceleration and the area under the line gives displacement, applications of calculus.",
    "Reading such graphs is a key skill for interpreting experiments, from car crash tests to the motion of planets."]]
  ],
  terms:[["Kinematics","The description of motion."],["Reference frame","A viewpoint for measuring motion."],["Displacement","Change in position with direction."],["Velocity","Speed with direction."],["Acceleration","Rate of change of velocity."],["g","Acceleration due to gravity, about 9.8 m/s²."],["Terminal velocity","Constant speed when air resistance balances gravity."],["Projectile","An object moving under gravity alone after launch."]],
  w:"Describing motion precisely is the first step in physics and explains everything from falling objects to the flight of a ball.",
  src:["Kinematics","Velocity","Acceleration","Free fall","Terminal velocity","Projectile motion","Galileo's Leaning Tower of Pisa experiment"],
  q:[["What is speed with direction called?","Velocity","Acceleration","Displacement","Momentum"],
     ["What is the acceleration due to gravity near Earth's surface?","About 9.8 m/s²","About 1.6 m/s²","About 98 m/s²","About 3 m/s²"],
     ["What did David Scott drop on the Moon?","A hammer and a feather","Two balls","A rock and a coin","A wrench and a glove"],
     ["What shape is a projectile's path?","A parabola","A circle","A straight line","A spiral"],
     ["Ignoring air resistance, what launch angle gives maximum range?","45 degrees","30 degrees","60 degrees","90 degrees"],
     ["On a velocity-time graph, what does the slope represent?","Acceleration","Displacement","Speed","Force"]]},

{ t:"Newton's Laws of Motion", s:"Force, mass, and acceleration",
  sec:[
  ["Force",[
    "A force is a push or pull that can change an object's motion. Forces are vectors, measured in newtons (N); one newton is roughly the weight of a small apple. When several forces act, the net force is their combined effect. If forces balance, the net force is zero.",
    "Common forces include gravity, the normal force from a surface pushing back, tension in ropes, friction, air resistance, and the electromagnetic forces that, at the atomic level, underlie most everyday contact forces."]],
  ["The first law: inertia",[
    "Newton's first law, the law of inertia, states that an object at rest stays at rest, and an object in motion continues in a straight line at constant speed, unless acted on by a net external force. Inertia is the tendency of objects to resist changes in motion; mass is a measure of inertia.",
    "Galileo had realized that, without friction, a ball rolling on a level surface would roll forever, overturning Aristotle's belief that objects naturally come to rest. Seat belts protect passengers because, when a car stops suddenly, their bodies keep moving forward."]],
  ["The second law: F = ma",[
    "Newton's second law states that an object's acceleration is proportional to the net force on it and inversely proportional to its mass: F = ma (force equals mass times acceleration). The same force gives a small mass a large acceleration and a large mass a small one, which is why it is easier to push an empty shopping cart than a full one.",
    "Weight is the force of gravity on an object: weight = mg. A 70-kilogram person weighs about 686 newtons on Earth, but only about one-sixth as much on the Moon, while their mass stays the same."]],
  ["The third law: action and reaction",[
    "Newton's third law states that for every action there is an equal and opposite reaction: when one object exerts a force on a second, the second exerts an equal and opposite force on the first. The two forces act on different objects, so they do not cancel.",
    "When you walk, your foot pushes back on the ground and the ground pushes you forward. A rocket expels exhaust gases backward, and the gases push the rocket forward, which is why rockets work in the vacuum of space. When you fire a gun, it recoils."]],
  ["Friction",[
    "Friction is a force that opposes the relative motion of surfaces in contact, caused by microscopic interactions between them. Static friction prevents objects from starting to slide and is usually greater than kinetic (sliding) friction, which is why it is harder to start pushing a heavy box than to keep it moving.",
    "Friction converts motion into heat, as when rubbing hands together. It can be reduced with lubricants, wheels, and ball bearings, and increased with tire treads and grips. Without friction, we could not walk or hold objects."]],
  ["Circular motion",[
    "An object moving in a circle constantly changes direction, so it is accelerating toward the center, even at constant speed. This centripetal acceleration requires a net force toward the center, called the centripetal force, provided by tension (a ball on a string), friction (a car on a curve), or gravity (a planet in orbit).",
    "The outward push passengers feel on a turning car is not a real force but the effect of inertia, their bodies trying to continue in a straight line; it is sometimes called centrifugal force. Newton's three laws, with his law of gravity, explained motion on Earth and in the heavens for over two centuries."]]
  ],
  terms:[["Force","A push or pull, measured in newtons."],["Inertia","Resistance to changes in motion."],["Newton's first law","Objects keep their state of motion unless acted on by a net force."],["F = ma","Newton's second law."],["Weight","The force of gravity on a mass."],["Action-reaction","Newton's third law of equal and opposite forces."],["Centripetal force","A force directed toward the center of a circular path."]],
  w:"Newton's laws explain how forces change motion, from walking and driving to launching rockets.",
  src:["Newton's laws of motion","Force","Inertia","Weight","Friction","Centripetal force","Newton (unit)"],
  q:[["What is the tendency to resist changes in motion called?","Inertia","Momentum","Friction","Weight"],
     ["What does Newton's second law state?","F = ma","E = mc²","For every action there is an equal and opposite reaction","Objects stay at rest"],
     ["How does a person's weight on the Moon compare with Earth?","About one-sixth","About half","The same","About double"],
     ["How does a rocket move in the vacuum of space?","By expelling exhaust backward, which pushes it forward","By pushing against air","By gravity alone","By magnetism"],
     ["Which is usually greater?","Static friction","Kinetic friction","They are always equal","Air resistance"],
     ["Which direction is centripetal force?","Toward the center","Outward","Forward","Backward"]]},

{ t:"Gravity and Orbits", s:"From falling apples to orbiting satellites",
  sec:[
  ["Universal gravitation",[
    "Newton's law of universal gravitation (1687) states that every mass attracts every other mass with a force proportional to the product of their masses and inversely proportional to the square of the distance between their centers: F = Gm₁m₂/r². G, the gravitational constant, is extremely small, about 6.67 × 10⁻¹¹ N·m²/kg², which is why gravity between everyday objects is imperceptible.",
    "Henry Cavendish first measured the force between lead spheres in a laboratory in 1798, an experiment often described as “weighing the Earth,” because it allowed calculation of Earth's mass, about 6 × 10²⁴ kilograms."]],
  ["Gravity on Earth and elsewhere",[
    "Surface gravity depends on a body's mass and radius. The Moon's surface gravity is about one-sixth of Earth's; Mars's about 38 percent; Jupiter's about 2.5 times. Gravity also weakens with altitude, though astronauts on the International Space Station, about 400 kilometers up, still experience about 90 percent of surface gravity.",
    "Astronauts float not because there is no gravity but because they and their spacecraft are in continuous free fall around the Earth, a state called weightlessness or microgravity."]],
  ["How orbits work",[
    "Newton imagined a cannon on a high mountain firing balls faster and faster; at a sufficient speed, the ball would fall toward Earth but the Earth's surface would curve away beneath it as fast as it fell, so it would circle the planet forever. An orbit is continuous falling around a body.",
    "Low Earth orbit requires a speed of about 7.8 kilometers per second (about 28,000 km/h); the ISS circles Earth about every 90 minutes. Escape velocity, the speed needed to break free of Earth's gravity entirely, is about 11.2 kilometers per second. Geostationary satellites, about 35,786 kilometers above the Equator, orbit once per day, staying above the same spot, ideal for communications and weather."]],
  ["Tides",[
    "Tides are caused mainly by the difference in the Moon's gravitational pull across the Earth: the side nearest the Moon is pulled more strongly than Earth's center, and Earth's center more strongly than the far side, producing two tidal bulges. As Earth rotates through them, most places experience two high tides a day. The Sun's pull also contributes, producing spring and neap tides.",
    "Tidal friction is gradually slowing Earth's rotation and pushing the Moon outward, by about 3.8 centimeters per year, measured with lasers bounced off reflectors left by Apollo astronauts. The Moon always shows the same face to Earth because tidal forces long ago locked its rotation to its orbit."]],
  ["Mass and weight, again",[
    "Mass is the amount of matter in an object and its resistance to acceleration; it is the same anywhere. Weight is the gravitational force on it and varies with location. Scales measure weight but are calibrated to display mass under Earth's gravity.",
    "Remarkably, the mass that resists acceleration (inertial mass) and the mass that feels gravity (gravitational mass) are exactly equal as far as experiments can tell, which is why all objects fall at the same rate. Einstein made this “equivalence principle” the foundation of general relativity."]],
  ["Beyond Newton",[
    "Newton's gravity explained the orbits of planets and comets, allowing Edmond Halley to predict the return of the comet named after him in 1758, and led to the discovery of Neptune in 1846 from irregularities in the orbit of Uranus.",
    "But Newton could not explain what gravity was or how it acted across empty space, and a tiny anomaly in the orbit of Mercury remained unexplained until Einstein's general theory of relativity (1915) reinterpreted gravity as the curvature of spacetime."]]
  ],
  terms:[["Law of universal gravitation","Gravity proportional to masses and inversely to distance squared."],["Gravitational constant","G, about 6.67 × 10⁻¹¹ N·m²/kg²."],["Orbit","Continuous free fall around a body."],["Escape velocity","Speed needed to escape a body's gravity."],["Geostationary orbit","An orbit matching Earth's rotation."],["Tidal locking","A body always showing the same face to another."],["Equivalence principle","Inertial and gravitational mass are equal."]],
  w:"Gravity shapes the universe from falling objects to galaxies, and understanding orbits makes satellites, space travel, and tides comprehensible.",
  src:["Newton's law of universal gravitation","Cavendish experiment","Orbit","Escape velocity","Geostationary orbit","Tide","Equivalence principle"],
  q:[["Who first measured gravity between objects in a laboratory?","Henry Cavendish","Isaac Newton","Galileo","Einstein"],
     ["Why do astronauts on the ISS float?","They are in continuous free fall","There is no gravity in space","They are beyond Earth's gravity","Their suits cancel gravity"],
     ["What is Earth's escape velocity?","About 11.2 km/s","About 7.8 km/s","About 300,000 km/s","About 1 km/s"],
     ["How often does a geostationary satellite orbit?","Once per day","Every 90 minutes","Once per month","Once per year"],
     ["How fast is the Moon moving away from Earth?","About 3.8 cm per year","About 1 meter per year","About 1 mm per century","It is moving closer"],
     ["Which planet's discovery came from irregularities in Uranus's orbit?","Neptune","Pluto","Saturn","Mars"]]},

{ t:"Energy and Work", s:"The currency of the physical world",
  sec:[
  ["What energy is",[
    "Energy is the capacity to do work or cause change. It comes in many forms: kinetic energy of motion, gravitational potential energy of position, elastic energy in stretched springs, chemical energy in fuels and food, thermal energy, electrical energy, radiant energy (light), and nuclear energy. Energy is measured in joules (J); a food Calorie (kilocalorie) is about 4,184 joules.",
    "Energy constantly changes form: in a hydroelectric dam, gravitational potential energy of water becomes kinetic energy, then electrical energy, which becomes light and heat in a home."]],
  ["Work",[
    "In physics, work is done when a force moves an object in the direction of the force: work equals force times distance (W = Fd). Lifting a 1-kilogram book 1 meter does about 10 joules of work against gravity. Holding a heavy object still, though tiring, does no physical work on it.",
    "Simple machines, levers, pulleys, wheels and axles, inclined planes, wedges, and screws, do not reduce the work needed but trade force for distance, making tasks easier. Archimedes reportedly said, “Give me a place to stand, and I will move the Earth.”"]],
  ["Kinetic and potential energy",[
    "Kinetic energy is ½mv², so it increases with the square of speed: a car at 100 km/h has four times the kinetic energy of one at 50 km/h, which is why high-speed crashes are so much more destructive. Gravitational potential energy near Earth is mgh, mass times g times height.",
    "A swinging pendulum or roller coaster continuously exchanges potential and kinetic energy: highest point, most potential energy and least speed; lowest point, most kinetic energy and greatest speed."]],
  ["Conservation of energy",[
    "The law of conservation of energy, one of the most fundamental principles in physics, states that energy cannot be created or destroyed, only transformed from one form to another or transferred; the total energy of an isolated system remains constant. It was established in the 1840s through the work of Julius Robert von Mayer, James Prescott Joule, who measured the mechanical equivalent of heat, and Hermann von Helmholtz.",
    "Perpetual motion machines that produce energy from nothing are therefore impossible. In real machines, some energy is always “lost” as heat through friction, which is still energy, but less useful."]],
  ["Power and efficiency",[
    "Power is the rate of doing work or transferring energy, measured in watts (W), one joule per second. James Watt, whose improved steam engine powered the Industrial Revolution, introduced the horsepower, about 746 watts. A 100-watt light bulb uses 100 joules each second; electricity bills measure energy in kilowatt-hours (1 kWh = 3.6 million joules).",
    "Efficiency is the fraction of input energy converted to useful output. Incandescent bulbs convert only about 5 percent of electricity to light, the rest to heat, while LEDs are several times more efficient. Car gasoline engines are typically 20–35 percent efficient; electric motors over 90 percent."]],
  ["Energy for society",[
    "Human civilization runs on energy. The average human body uses about 100 watts, while a person in a rich country uses, through society's machines, thousands of watts continuously. Most of the world's energy still comes from burning fossil fuels, releasing chemical energy stored from ancient sunlight.",
    "Understanding energy, its forms, conservation, and efficiency, is essential for thinking about technology, economics, and climate change."]]
  ],
  terms:[["Energy","The capacity to do work or cause change."],["Work","Force times distance in the direction of the force."],["Kinetic energy","Energy of motion, ½mv²."],["Potential energy","Stored energy of position or configuration."],["Conservation of energy","Energy is neither created nor destroyed."],["Power","The rate of energy transfer, in watts."],["Efficiency","The fraction of energy converted to useful output."]],
  w:"Energy is the unifying concept of physics, and its conservation underlies everything from machines to metabolism to the global economy.",
  src:["Energy","Work (physics)","Kinetic energy","Potential energy","Conservation of energy","Power (physics)","Energy conversion efficiency"],
  q:[["What is the unit of energy?","The joule","The watt","The newton","The volt"],
     ["How does kinetic energy change if speed doubles?","It quadruples","It doubles","It halves","It stays the same"],
     ["Who measured the mechanical equivalent of heat?","James Prescott Joule","James Watt","Isaac Newton","Hermann von Helmholtz"],
     ["Why are perpetual motion machines impossible?","Energy cannot be created from nothing","Machines are too heavy","Friction is too large in space","Gravity prevents them"],
     ["What is one watt?","One joule per second","One newton per meter","One volt per ampere","One calorie per hour"],
     ["About how efficient are incandescent bulbs at producing light?","About 5 percent","About 50 percent","About 90 percent","About 25 percent"]]},

{ t:"Momentum, Rotation, and Fluids", s:"Collisions, spinning, and pressure",
  sec:[
  ["Momentum",[
    "Momentum is mass times velocity (p = mv), a vector quantity. A truck has much more momentum than a bicycle at the same speed, which is why it is harder to stop. The law of conservation of momentum states that in an isolated system, total momentum stays constant: in a collision, momentum lost by one object is gained by the other.",
    "Impulse, force multiplied by the time over which it acts, equals the change in momentum. Airbags, crumple zones, and bending your knees when landing extend the stopping time, reducing the force on the body."]],
  ["Collisions",[
    "In an elastic collision, such as between billiard balls (approximately), both momentum and kinetic energy are conserved, and objects bounce apart. In an inelastic collision, such as a car crash, momentum is conserved but some kinetic energy is converted into heat, sound, and deformation; in a perfectly inelastic collision, the objects stick together.",
    "A Newton's cradle, a row of hanging steel balls, demonstrates conservation of momentum and energy: one ball striking one end sends one ball out from the other."]],
  ["Rotation and torque",[
    "Rotational motion has its own equivalents of force, mass, and momentum. Torque is the turning effect of a force, equal to force times the perpendicular distance from the pivot, which is why a long wrench makes it easier to loosen a bolt and why doorknobs are placed far from hinges.",
    "An object's resistance to rotational acceleration, its moment of inertia, depends on how its mass is distributed: mass far from the axis is harder to spin. An object is balanced when the torques around its pivot cancel, as on a seesaw, where a lighter child sitting farther out can balance a heavier one."]],
  ["Angular momentum",[
    "Angular momentum, the rotational equivalent of momentum, is also conserved. A spinning figure skater who pulls in her arms reduces her moment of inertia and spins faster; extending them slows her down. Collapsing clouds of gas spin faster as they shrink, which is why stars and planets rotate and why neutron stars can spin hundreds of times a second.",
    "Gyroscopes resist changes to their axis of rotation, keeping bicycles and spinning tops stable and helping guide spacecraft and smartphones."]],
  ["Pressure and fluids",[
    "Pressure is force per unit area, measured in pascals. A sharp knife cuts because its force is concentrated on a tiny area; snowshoes spread weight over a large area. Pressure in a fluid increases with depth: every 10 meters of seawater adds about one atmosphere of pressure, so at the bottom of the Mariana Trench pressure exceeds 1,000 atmospheres.",
    "Pascal's principle states that pressure applied to a confined fluid is transmitted equally throughout it, the basis of hydraulic brakes and lifts, which multiply force."]],
  ["Buoyancy and flight",[
    "Archimedes' principle states that an object immersed in a fluid experiences an upward buoyant force equal to the weight of the fluid it displaces. An object floats if it is less dense than the fluid; a steel ship floats because its hollow shape displaces enough water. According to legend, Archimedes discovered the principle in his bath and ran through the streets shouting “Eureka!”",
    "Bernoulli's principle, formulated by Daniel Bernoulli in 1738, states that in a moving fluid, faster flow corresponds to lower pressure. Airplane wings generate lift by deflecting air downward and creating lower pressure above the wing than below, a combination of Newton's third law and Bernoulli's principle."]]
  ],
  terms:[["Momentum","Mass times velocity."],["Impulse","Force times time, equal to change in momentum."],["Elastic collision","A collision conserving kinetic energy."],["Torque","The turning effect of a force."],["Angular momentum","Rotational momentum, conserved in isolated systems."],["Pressure","Force per unit area."],["Archimedes' principle","Buoyant force equals the weight of displaced fluid."],["Bernoulli's principle","Faster fluid flow means lower pressure."]],
  w:"Momentum, rotation, and fluid physics explain car safety, spinning skaters, floating ships, and flying airplanes.",
  src:["Momentum","Impulse (physics)","Elastic collision","Torque","Angular momentum","Archimedes' principle","Bernoulli's principle"],
  q:[["What is momentum?","Mass times velocity","Force times distance","Mass times acceleration","Energy per second"],
     ["Why do airbags reduce injury?","They extend stopping time, reducing force","They add momentum","They increase speed","They reduce mass"],
     ["Why does a skater spin faster when pulling in her arms?","Conservation of angular momentum","Gravity","Friction","Air resistance"],
     ["What is torque?","The turning effect of a force","A type of friction","Rotational speed","Pressure in a fluid"],
     ["What does Archimedes' principle state?","The buoyant force equals the weight of displaced fluid","Pressure increases with speed","Force equals mass times acceleration","Energy is conserved"],
     ["Which principle relates faster flow to lower pressure?","Bernoulli's principle","Pascal's principle","Archimedes' principle","Hooke's law"]]}

]});


/* ---- from sci-05.js ---- */
/* SCIENCES FOUNDATIONS, part 5: Unit 3 chapters 6-10 */
COURSES.sciences.units[2].ch.push(

{ t:"Heat and Thermodynamics", s:"Temperature, heat, and the laws of energy",
  sec:[
  ["Temperature and heat",[
    "Temperature measures the average kinetic energy of the particles in a substance, how fast its atoms and molecules are moving and vibrating. Heat is the transfer of thermal energy from a hotter object to a cooler one. A bathtub of warm water contains more thermal energy than a cup of boiling water, though its temperature is lower.",
    "In the 18th century, scientists thought heat was an invisible fluid called caloric. Benjamin Thompson (Count Rumford) observed in the 1790s that boring cannon barrels produced seemingly endless heat, suggesting heat is a form of motion, confirmed by Joule's experiments."]],
  ["Heat transfer",[
    "Heat moves in three ways. Conduction transfers heat through direct contact, as particles collide; metals are good conductors, while air, wool, and foam are insulators. Convection transfers heat by the movement of fluids, as warm air or water rises and cool fluid sinks, creating currents that drive weather and ocean circulation. Radiation transfers heat as electromagnetic waves, mainly infrared, which can cross empty space, as sunlight warms the Earth.",
    "A vacuum flask (thermos), invented by James Dewar in 1892, reduces all three: a vacuum between double walls blocks conduction and convection, and silvered surfaces reflect radiation."]],
  ["Specific heat and phase changes",[
    "Different substances need different amounts of energy to warm up. Water has a very high specific heat capacity, about 4,184 joules to raise one kilogram by one degree Celsius, which is why oceans moderate climate and why water is used for cooling.",
    "Changes of state, melting, boiling, freezing, condensing, require or release energy without changing temperature, called latent heat. Ice at 0°C must absorb energy to become water at 0°C. Evaporation of sweat cools the body by absorbing latent heat. Most substances expand when heated, which is why bridges have expansion joints; water is unusual, expanding when it freezes, so ice floats."]],
  ["The laws of thermodynamics",[
    "Thermodynamics, the study of heat, work, and energy, developed in the 19th century to understand steam engines. The first law is conservation of energy: the energy of a system changes only by heat added or work done. The second law states that heat flows spontaneously from hot to cold, never the reverse, and that the total entropy of an isolated system never decreases.",
    "The third law states that absolute zero cannot be reached in a finite number of steps. A “zeroth law” states that two systems each in equilibrium with a third are in equilibrium with each other, defining temperature. A popular summary: you can't win, you can't break even, and you can't get out of the game."]],
  ["Entropy",[
    "Entropy is a measure of disorder, or more precisely the number of microscopic arrangements consistent with a system's state. Ludwig Boltzmann connected entropy with probability in the 1870s: systems tend toward more probable, disordered states, just as a deck of cards becomes disordered when shuffled but never spontaneously orders itself.",
    "The second law explains why ice melts in a warm room, why perfume spreads through air, and why time seems to have a direction, the “arrow of time.” Living things maintain local order by consuming energy and increasing entropy in their surroundings."]],
  ["Heat engines and refrigerators",[
    "A heat engine converts heat into work by letting heat flow from a hot source to a cold sink, as in steam engines, car engines, and power plants. In 1824 the French engineer Sadi Carnot showed that no engine can be 100 percent efficient; the maximum efficiency depends on the temperatures of the hot and cold reservoirs, so some heat must always be wasted.",
    "Refrigerators, air conditioners, and heat pumps run the process in reverse, using work to move heat from cold to hot. Heat pumps can deliver several times more heat than the electrical energy they use, making them efficient for heating homes."]]
  ],
  terms:[["Temperature","A measure of the average kinetic energy of particles."],["Heat","Thermal energy transferred from hot to cold."],["Conduction, convection, radiation","The three methods of heat transfer."],["Specific heat capacity","Energy needed to raise a substance's temperature."],["Latent heat","Energy absorbed or released during a change of state."],["Entropy","A measure of disorder or probability of a state."],["Second law of thermodynamics","Entropy of an isolated system never decreases."]],
  w:"Thermodynamics explains engines, refrigerators, weather, and life itself, and its second law gives time its direction.",
  src:["Thermodynamics","Heat transfer","Specific heat capacity","Latent heat","Laws of thermodynamics","Entropy","Carnot cycle"],
  q:[["What does temperature measure?","The average kinetic energy of particles","Total thermal energy","Heat transfer","Pressure"],
     ["How does sunlight warm the Earth across space?","Radiation","Conduction","Convection","Evaporation"],
     ["Why does ice float?","Water expands when it freezes","Ice contains air","Ice is heavier","Salt in seawater"],
     ["What does the second law of thermodynamics state?","Entropy of an isolated system never decreases","Energy is conserved","Absolute zero can be reached","Heat flows from cold to hot"],
     ["Who connected entropy with probability?","Ludwig Boltzmann","Sadi Carnot","James Joule","Lord Kelvin"],
     ["Who showed no engine can be 100 percent efficient?","Sadi Carnot","James Watt","Rudolf Clausius","Count Rumford"]]},

{ t:"Waves and Sound", s:"Vibrations that carry energy",
  sec:[
  ["What waves are",[
    "A wave is a disturbance that transfers energy from place to place without transferring matter. When a wave passes through water, the water mostly moves up and down in place while the wave travels across. Mechanical waves, such as sound and ocean waves, need a medium; electromagnetic waves, such as light, do not.",
    "In transverse waves, such as waves on a string and light, the disturbance is perpendicular to the direction of travel. In longitudinal waves, such as sound, it is parallel, creating compressions and rarefactions."]],
  ["Describing waves",[
    "Waves are described by their wavelength (the distance between crests), frequency (the number of waves passing a point per second, measured in hertz, Hz), amplitude (the height of the wave, related to its energy), and speed. The wave equation links them: speed = frequency × wavelength.",
    "For a given speed, higher frequency means shorter wavelength. The period is the time for one complete wave, the inverse of frequency."]],
  ["Wave behavior",[
    "Waves reflect off surfaces, as echoes do; refract, or bend, when they change speed entering a new medium; and diffract, spreading around obstacles and through openings, which is why you can hear someone around a corner. When waves overlap, they interfere: crests meeting crests reinforce each other (constructive interference), while crests meeting troughs cancel (destructive interference), the principle of noise-canceling headphones.",
    "Standing waves form when waves reflect back and forth, as on guitar strings and in organ pipes, producing particular frequencies called harmonics. Resonance occurs when a system is driven at its natural frequency, building up large vibrations, as when a singer shatters a glass or wind made the Tacoma Narrows Bridge twist and collapse in 1940."]],
  ["Sound",[
    "Sound is a longitudinal mechanical wave of pressure traveling through air, liquids, or solids. In air at room temperature it travels about 343 meters per second; in water about 1,480 m/s; in steel about 5,900 m/s. It cannot travel through the vacuum of space.",
    "Pitch depends on frequency: humans hear roughly 20 to 20,000 Hz, with the upper limit declining with age. Sounds above that range are ultrasound, used by bats and dolphins for echolocation and in medical imaging; below it is infrasound, used by elephants and produced by earthquakes. Loudness depends on amplitude and is measured on the logarithmic decibel scale: every 10 decibels represents a tenfold increase in intensity. Prolonged exposure above about 85 dB can damage hearing."]],
  ["The Doppler effect",[
    "When a source of waves moves toward an observer, the waves are compressed, raising the frequency; when it moves away, the waves are stretched, lowering it. This is the Doppler effect, described by Christian Doppler in 1842, heard as the drop in pitch of a passing ambulance siren.",
    "The Doppler effect is used in radar speed guns, weather radar, and medical ultrasound to measure blood flow, and in astronomy, where the redshift of light from galaxies reveals that the universe is expanding. When an aircraft exceeds the speed of sound, sound waves pile up into a shock wave heard as a sonic boom; Chuck Yeager first broke the sound barrier in level flight in 1947."]],
  ["Music and hearing",[
    "Musical notes are sounds with definite frequencies; the A above middle C is standardized at 440 Hz. An octave doubles the frequency. Instruments sound different, even playing the same note, because of their mix of harmonics, called timbre.",
    "The ear converts sound waves into nerve signals: the eardrum vibrates, three tiny bones (the hammer, anvil, and stirrup, the smallest bones in the body) amplify the vibrations, and hair cells in the fluid-filled, snail-shaped cochlea respond to different frequencies."]]
  ],
  terms:[["Wave","A disturbance that transfers energy."],["Transverse and longitudinal","Disturbance perpendicular vs. parallel to travel."],["Frequency","Number of waves per second, in hertz."],["Wavelength","Distance between successive crests."],["Interference","The combining of overlapping waves."],["Resonance","Large vibrations at a natural frequency."],["Decibel","A logarithmic unit of sound intensity."],["Doppler effect","Frequency shift due to motion of source or observer."]],
  w:"Waves carry energy and information everywhere, and understanding them explains sound, music, hearing, and tools from sonar to medical imaging.",
  src:["Wave","Longitudinal wave","Frequency","Wave interference","Resonance","Sound","Doppler effect"],
  q:[["What does a wave transfer?","Energy","Matter","Mass","Air"],
     ["What kind of wave is sound?","Longitudinal","Transverse","Electromagnetic","Standing only"],
     ["What is the speed of sound in air at room temperature?","About 343 m/s","About 3,000 m/s","About 34 m/s","About 300,000 km/s"],
     ["What is the range of human hearing?","About 20 to 20,000 Hz","About 1 to 1,000 Hz","About 200 to 200,000 Hz","About 2 to 2,000 Hz"],
     ["What causes the drop in pitch of a passing siren?","The Doppler effect","Resonance","Interference","Refraction"],
     ["Who first broke the sound barrier in level flight?","Chuck Yeager","Neil Armstrong","Amelia Earhart","Yuri Gagarin"]]},

{ t:"Light and Optics", s:"Reflection, refraction, and color",
  sec:[
  ["What light is",[
    "Light is an electromagnetic wave that our eyes can detect. Its nature was long debated: Newton thought it consisted of particles, while Christiaan Huygens argued it was a wave. In 1801 Thomas Young's double-slit experiment showed that light passing through two narrow slits produces an interference pattern of bright and dark bands, demonstrating wave behavior.",
    "In the 20th century, quantum physics showed that light behaves both as a wave and as particles called photons. Light travels at about 299,792 kilometers per second in a vacuum, the universal speed limit; light from the Sun takes about 8 minutes 20 seconds to reach Earth."]],
  ["Reflection",[
    "When light hits a smooth surface such as a mirror, it reflects so that the angle of incidence equals the angle of reflection. A plane mirror forms a virtual image that appears as far behind the mirror as the object is in front, reversed left to right. Rough surfaces scatter light in all directions (diffuse reflection), which is how we see most objects.",
    "Curved mirrors focus or spread light: concave mirrors, used in reflecting telescopes and car headlights, can focus light to a point; convex mirrors, used as security and car side mirrors, give a wide field of view."]],
  ["Refraction and lenses",[
    "Light slows down when it enters a denser medium such as water or glass and bends, or refracts. This is why a straw in water looks broken and why pools look shallower than they are. The amount of bending depends on the refractive index of the material.",
    "Lenses use refraction to form images. Convex (converging) lenses focus light, used in magnifying glasses, cameras, and to correct farsightedness; concave (diverging) lenses spread light and correct nearsightedness. Total internal reflection, which traps light inside glass when it strikes the boundary at a shallow angle, makes optical fibers possible, carrying internet data as pulses of light."]],
  ["Color and the spectrum",[
    "In 1666 Newton showed with prisms that white light is a mixture of colors, which glass separates because each color refracts by a slightly different amount, a process called dispersion. The visible spectrum runs from red (longest wavelength, about 700 nanometers) through orange, yellow, green, blue, to violet (about 400 nm).",
    "Rainbows form when sunlight is refracted, reflected inside raindrops, and dispersed; you see one with the Sun behind you. Objects appear colored because they absorb some wavelengths and reflect others: a green leaf reflects green light. The sky is blue because air molecules scatter shorter blue wavelengths more than red, a process called Rayleigh scattering; sunsets are red because sunlight passes through more air, scattering away the blue."]],
  ["The eye",[
    "The human eye works like a camera: light enters through the cornea and pupil, is focused by the lens onto the retina, where light-sensitive cells convert it into nerve signals. Rods detect dim light and motion; cones, of three types sensitive to red, green, and blue light, detect color. Color blindness usually results from missing or faulty cones and affects about 8 percent of men of Northern European descent.",
    "The brain interprets the upside-down image formed on the retina and fills in the blind spot where the optic nerve leaves the eye."]],
  ["Optical instruments",[
    "Microscopes use lenses to magnify tiny objects; Antonie van Leeuwenhoek's single-lens microscopes in the 1670s revealed bacteria and other microorganisms. Telescopes gather and focus light from distant objects: refracting telescopes use lenses, as Galileo's did, while reflecting telescopes, invented by Newton, use mirrors and are used for all large modern telescopes.",
    "Lasers, invented in 1960 by Theodore Maiman, produce intense, coherent light of a single wavelength, used in surgery, barcode scanners, communications, and measuring distances, including the distance to the Moon."]]
  ],
  terms:[["Double-slit experiment","Young's demonstration of light's wave nature."],["Photon","A particle of light."],["Reflection","Light bouncing off a surface."],["Refraction","Bending of light when it changes speed."],["Total internal reflection","Light trapped inside a medium, used in optical fibers."],["Dispersion","Separation of white light into colors."],["Rayleigh scattering","Scattering of short wavelengths that makes the sky blue."]],
  w:"Optics explains how we see, why the sky is blue, and how lenses, fibers, and lasers shape modern technology.",
  src:["Light","Young's interference experiment","Reflection (physics)","Refraction","Total internal reflection","Rayleigh scattering","Laser"],
  q:[["Who demonstrated light's wave nature with a double-slit experiment?","Thomas Young","Isaac Newton","Christiaan Huygens","Albert Einstein"],
     ["How long does sunlight take to reach Earth?","About 8 minutes 20 seconds","About 8 seconds","About 1 hour","About 1 day"],
     ["What makes optical fibers possible?","Total internal reflection","Diffraction","Dispersion","Polarization"],
     ["Which color has the longest wavelength?","Red","Violet","Blue","Green"],
     ["Why is the sky blue?","Air scatters shorter blue wavelengths more","The ocean reflects blue","Oxygen is blue","Ozone absorbs red"],
     ["Who invented the laser in 1960?","Theodore Maiman","Charles Townes","Albert Einstein","Arthur Schawlow"]]},

{ t:"Electricity", s:"Charges, currents, and circuits",
  sec:[
  ["Electric charge",[
    "Electric charge is a fundamental property of matter. There are two kinds, positive and negative: protons carry positive charge and electrons negative. Like charges repel; opposite charges attract. Charge is conserved, and it is measured in coulombs.",
    "The ancient Greeks noticed that amber rubbed with fur attracts light objects; the word electricity comes from the Greek elektron, “amber.” Static electricity results from a buildup of charge, as when rubbing a balloon on hair transfers electrons. Lightning is a giant static discharge; Benjamin Franklin's famous kite experiment of 1752 showed that lightning is electrical."]],
  ["Coulomb's law and fields",[
    "Charles-Augustin de Coulomb showed in 1785 that the force between two charges is proportional to the product of the charges and inversely proportional to the square of the distance between them, similar in form to Newton's law of gravity but vastly stronger: the electric force between a proton and electron is about 10³⁹ times their gravitational attraction.",
    "Michael Faraday introduced the idea of a field, an invisible influence filling space around a charge, mapped with field lines. Conductors, such as metals, allow charges to move freely; insulators, such as rubber and glass, do not."]],
  ["Current, voltage, and resistance",[
    "Electric current is the flow of charge, measured in amperes (amps), one coulomb per second. In metal wires, current is carried by electrons. Voltage, or potential difference, measured in volts, is the push that drives current, like water pressure in a pipe. Resistance, measured in ohms, opposes current, like a narrow pipe.",
    "Ohm's law, published by Georg Ohm in 1827, states that voltage equals current times resistance (V = IR). Electrical power equals voltage times current (P = VI)."]],
  ["Circuits",[
    "A circuit is a closed path through which current flows, from a power source through components and back. In a series circuit, components are connected one after another, so the same current flows through each, and if one breaks, all stop, as in old strings of Christmas lights. In a parallel circuit, components are on separate branches, so each can work independently, as in household wiring.",
    "Fuses and circuit breakers protect circuits by breaking them when current is too high, preventing fires. Semiconductors such as silicon, whose conductivity can be controlled, form diodes and transistors, the building blocks of electronics."]],
  ["Batteries and AC/DC",[
    "In 1800 Alessandro Volta invented the electric battery, the voltaic pile, stacking zinc and copper discs separated by brine-soaked cardboard, producing a steady current through chemical reactions. Batteries produce direct current (DC), flowing in one direction.",
    "Power grids use alternating current (AC), which reverses direction many times a second, 60 times in North America and 50 in Europe, because its voltage can easily be changed by transformers for efficient long-distance transmission. In the “war of the currents” of the 1880s–1890s, George Westinghouse and Nikola Tesla's AC system defeated Thomas Edison's DC system."]],
  ["Electricity and safety",[
    "The human body conducts electricity, and current passing through the heart can be fatal; as little as about 0.1 amperes across the chest can cause cardiac arrest. Water greatly lowers skin resistance, making electricity near water especially dangerous. Grounding (earthing) and residual-current devices protect against shocks.",
    "Electricity transformed civilization, powering lights, motors, communication, and computing, and our nervous systems themselves work by electrical signals carried by ions across cell membranes."]]
  ],
  terms:[["Electric charge","A property of matter, positive or negative."],["Coulomb's law","The inverse-square law of electric force."],["Current","The flow of charge, in amperes."],["Voltage","The push driving current, in volts."],["Resistance","Opposition to current, in ohms."],["Ohm's law","V = IR."],["AC and DC","Alternating and direct current."]],
  w:"Electricity underlies modern technology and even our own nerves, and understanding charge, current, and circuits makes the electrical world comprehensible.",
  src:["Electric charge","Coulomb's law","Electric current","Ohm's law","Series and parallel circuits","Voltaic pile","War of the currents"],
  q:[["What does the Greek word elektron mean?","Amber","Spark","Lightning","Charge"],
     ["Who showed with a kite that lightning is electrical?","Benjamin Franklin","Alessandro Volta","Michael Faraday","Thomas Edison"],
     ["What is Ohm's law?","V = IR","F = ma","P = mv","E = mc²"],
     ["In which circuit do components work independently?","Parallel","Series","Closed","Short"],
     ["Who invented the electric battery?","Alessandro Volta","Luigi Galvani","Georg Ohm","André-Marie Ampère"],
     ["Whose AC system won the war of the currents?","Westinghouse and Tesla","Edison","Franklin","Faraday"]]},

{ t:"Magnetism and Electromagnetism", s:"How electricity and magnetism are one",
  sec:[
  ["Magnets",[
    "Magnetism was known in ancient times from lodestones, naturally magnetized pieces of the mineral magnetite. Every magnet has a north and a south pole; like poles repel and opposite poles attract. Cutting a magnet in half produces two smaller magnets, each with both poles.",
    "Magnetic materials such as iron, nickel, and cobalt contain regions called domains in which the magnetic fields of atoms, produced by the spin of electrons, line up. The compass, developed in China by the 11th century, transformed navigation."]],
  ["Earth's magnetic field",[
    "In 1600 William Gilbert, in De Magnete, proposed that the Earth itself is a giant magnet, explaining why compasses point north. Earth's magnetic field is generated by electric currents in its liquid iron outer core. The magnetic poles wander and do not coincide with the geographic poles, and the field has reversed many times over geological history, recorded in rocks on the ocean floor.",
    "The magnetic field shields Earth from the solar wind, charged particles streaming from the Sun; where these particles are funneled toward the poles, they create the aurora borealis and aurora australis."]],
  ["Electricity makes magnetism",[
    "In 1820 the Danish physicist Hans Christian Ørsted noticed that an electric current deflected a nearby compass needle, the first evidence that electricity and magnetism are linked. A current in a wire produces a circular magnetic field around it; coiling the wire concentrates the field, and adding an iron core creates an electromagnet that can be switched on and off.",
    "Electromagnets are used in scrapyard cranes, MRI scanners, loudspeakers, doorbells, and maglev trains. Electric motors, first demonstrated by Michael Faraday in 1821, use the force between currents and magnets to turn electrical energy into motion."]],
  ["Magnetism makes electricity",[
    "In 1831 Michael Faraday discovered electromagnetic induction: a changing magnetic field induces an electric current in a conductor. Moving a magnet in and out of a coil of wire produces current. This principle underlies the electric generator, which turns motion into electricity, and nearly all the world's electricity is generated this way, by turbines spun by steam, water, or wind.",
    "Transformers use induction to raise or lower AC voltages. Induction is also used in wireless phone chargers, induction cooktops, and card readers."]],
  ["Maxwell's equations",[
    "In the 1860s the Scottish physicist James Clerk Maxwell unified electricity and magnetism in four equations, one of the great achievements in science. They showed that changing electric fields create magnetic fields and vice versa, so electric and magnetic fields can sustain each other as waves traveling through space.",
    "Maxwell calculated that these electromagnetic waves travel at the speed of light and concluded that light itself is an electromagnetic wave. Einstein kept photographs of Faraday and Maxwell on his study wall."]],
  ["Radio and beyond",[
    "Maxwell's prediction of other electromagnetic waves was confirmed in 1887–1888 by Heinrich Hertz, who generated and detected radio waves; the unit of frequency is named after him. Guglielmo Marconi developed practical radio, sending signals across the Atlantic in 1901.",
    "Electromagnetism is one of the four fundamental forces of nature, responsible for chemistry, light, electronics, and the solidity of matter. Its unification by Maxwell inspired the quest to unify all the forces of nature."]]
  ],
  terms:[["Magnetic poles","The north and south ends of a magnet."],["Magnetic domain","A region where atomic magnetic fields align."],["Electromagnet","A magnet created by electric current."],["Electric motor","A device turning electricity into motion."],["Electromagnetic induction","A changing magnetic field producing current."],["Generator","A device turning motion into electricity."],["Maxwell's equations","Equations unifying electricity and magnetism."]],
  w:"The unification of electricity and magnetism produced motors, generators, radio, and the understanding that light is an electromagnetic wave.",
  src:["Magnetism","Earth's magnetic field","Hans Christian Ørsted","Electromagnet","Electromagnetic induction","Maxwell's equations","Heinrich Hertz"],
  q:[["What causes Earth's magnetic field?","Electric currents in the liquid outer core","A giant magnet in the crust","The Moon","The Sun's gravity"],
     ["Who wrote De Magnete proposing Earth is a magnet?","William Gilbert","Hans Christian Ørsted","Michael Faraday","James Clerk Maxwell"],
     ["Who first noticed a current deflecting a compass in 1820?","Hans Christian Ørsted","André-Marie Ampère","Michael Faraday","Alessandro Volta"],
     ["Who discovered electromagnetic induction in 1831?","Michael Faraday","Joseph Henry alone","Maxwell","Tesla"],
     ["What did Maxwell conclude about light?","It is an electromagnetic wave","It is made of particles","It is a sound wave","It travels instantly"],
     ["Who first generated and detected radio waves?","Heinrich Hertz","Guglielmo Marconi","Nikola Tesla","Thomas Edison"]]}

);


/* ---- from sci-06.js ---- */
/* SCIENCES FOUNDATIONS, part 6: Unit 3 chapters 11-16 */
COURSES.sciences.units[2].ch.push(

{ t:"The Electromagnetic Spectrum", s:"From radio waves to gamma rays",
  sec:[
  ["One family of waves",[
    "Visible light is only a tiny part of the electromagnetic spectrum, the full range of electromagnetic waves, which all travel at the speed of light in a vacuum but differ in wavelength and frequency. From longest wavelength and lowest energy to shortest wavelength and highest energy, the main bands are radio waves, microwaves, infrared, visible light, ultraviolet, X-rays, and gamma rays.",
    "The energy of each photon is proportional to its frequency, so gamma-ray photons carry far more energy than radio photons. High-energy radiation, ultraviolet, X-rays, and gamma rays, is ionizing: it can knock electrons from atoms and damage DNA."]],
  ["Radio and microwaves",[
    "Radio waves, with wavelengths from millimeters to kilometers, carry broadcasting, mobile phone, Wi-Fi, and GPS signals. Radio telescopes detect radio waves from space, revealing pulsars, galaxies, and the cosmic microwave background, the afterglow of the Big Bang.",
    "Microwaves, with wavelengths of about a millimeter to 30 centimeters, are used in radar, satellite communications, and microwave ovens, invented after Percy Spencer at Raytheon noticed in 1945 that radar equipment melted a chocolate bar in his pocket. Microwave ovens heat food mainly by making water molecules rotate."]],
  ["Infrared",[
    "Infrared radiation, discovered by the astronomer William Herschel in 1800 when a thermometer placed beyond the red end of a spectrum warmed up, is emitted by all warm objects; humans glow in infrared. Night-vision and thermal cameras detect it, TV remote controls use it, and it carries heat from fires and the Sun.",
    "Greenhouse gases absorb infrared radiation emitted by the Earth's surface, warming the planet. The James Webb Space Telescope, launched in 2021, observes in infrared to see the earliest galaxies, whose light has been stretched into infrared by the expansion of the universe."]],
  ["Ultraviolet",[
    "Ultraviolet (UV) light, discovered by Johann Ritter in 1801, has wavelengths shorter than violet. UV from the Sun causes sunburn and skin cancer but also helps the skin produce vitamin D. The ozone layer absorbs most harmful UV. Many insects, such as bees, see UV patterns on flowers invisible to us.",
    "UV is used to sterilize water and surfaces, and fluorescent materials absorb UV and emit visible light, as in highlighters and black-light posters."]],
  ["X-rays and gamma rays",[
    "X-rays were discovered by Wilhelm Röntgen in 1895, who made the first X-ray image of a human, his wife's hand with her wedding ring; he received the first Nobel Prize in Physics in 1901. X-rays pass through soft tissue but are absorbed by bone, making them invaluable in medicine; CT scans combine many X-ray images. X-ray crystallography revealed the structures of molecules, including DNA.",
    "Gamma rays, the most energetic electromagnetic waves, are produced by radioactive decay, nuclear reactions, and violent cosmic events such as supernovae and gamma-ray bursts. They are used in radiotherapy to kill cancer cells and to sterilize medical equipment. Earth's atmosphere blocks X-rays and gamma rays from space, so astronomers observe them with satellites."]],
  ["Seeing the invisible universe",[
    "Astronomers now observe the universe across the whole spectrum, each band revealing different phenomena: radio for cold gas and pulsars, infrared for dust-shrouded star formation and distant galaxies, visible light for stars, and X-rays and gamma rays for black holes, neutron stars, and exploding stars.",
    "Spectroscopy, splitting light into its component wavelengths, reveals what distant objects are made of, because each element absorbs and emits specific wavelengths, like a fingerprint. Helium was discovered in the Sun's spectrum in 1868, before it was found on Earth."]]
  ],
  terms:[["Electromagnetic spectrum","The full range of electromagnetic waves."],["Ionizing radiation","High-energy radiation that can knock electrons from atoms."],["Microwave","Radiation used in radar and ovens."],["Infrared","Radiation emitted by warm objects."],["Ultraviolet","Radiation beyond violet that causes sunburn."],["X-ray","Penetrating radiation used in medical imaging."],["Spectroscopy","Analyzing light to identify substances."]],
  w:"The electromagnetic spectrum underlies communication, medicine, and astronomy, revealing a universe far beyond what our eyes can see.",
  src:["Electromagnetic spectrum","Radio wave","Microwave oven","Infrared","Ultraviolet","X-ray","Spectroscopy"],
  q:[["Which has the longest wavelength?","Radio waves","Gamma rays","Visible light","X-rays"],
     ["Who discovered infrared in 1800?","William Herschel","Johann Ritter","Wilhelm Röntgen","Isaac Newton"],
     ["Who discovered X-rays in 1895?","Wilhelm Röntgen","Marie Curie","Henri Becquerel","Heinrich Hertz"],
     ["What does the ozone layer absorb?","Ultraviolet","Infrared","Radio waves","Visible light"],
     ["Which element was discovered in the Sun's spectrum before Earth?","Helium","Hydrogen","Neon","Oxygen"],
     ["Which telescope launched in 2021 observes in infrared?","James Webb Space Telescope","Hubble","Chandra","Spitzer"]]},

{ t:"Special Relativity", s:"Space, time, and the speed of light",
  sec:[
  ["A puzzle about light",[
    "By the late 19th century, physicists assumed light waves traveled through an invisible medium called the luminiferous ether. In 1887 Albert Michelson and Edward Morley tried to detect Earth's motion through the ether by measuring differences in the speed of light in different directions, but found none.",
    "In 1905, his “miracle year,” Albert Einstein, then a 26-year-old clerk at the Swiss patent office in Bern, published four groundbreaking papers, including the special theory of relativity, which dispensed with the ether."]],
  ["Two postulates",[
    "Special relativity rests on two postulates: the laws of physics are the same in all inertial (non-accelerating) reference frames, and the speed of light in a vacuum is the same for all observers, regardless of their motion or the motion of the source.",
    "The second postulate seems to defy common sense: if you chase a light beam at half the speed of light, you still measure it moving away from you at the full speed of light. To make this work, space and time themselves must change depending on the observer's motion."]],
  ["Time dilation and length contraction",[
    "Moving clocks run slow, an effect called time dilation: for an observer watching a fast-moving spaceship, time aboard passes more slowly. The effect is tiny at everyday speeds but large near light speed. It has been confirmed by flying atomic clocks on airplanes (the Hafele-Keating experiment, 1971) and by muons created in the upper atmosphere, which survive long enough to reach the ground only because their internal clocks run slow.",
    "Moving objects are also measured as shorter in their direction of motion, length contraction. The “twin paradox” describes a twin who travels near light speed and returns younger than the twin who stayed home. GPS satellites must correct for relativistic time effects to give accurate positions."]],
  ["Simultaneity and spacetime",[
    "Events that are simultaneous for one observer may not be for another moving relative to them; there is no universal “now.” In 1908 Einstein's former teacher Hermann Minkowski showed that space and time combine into a single four-dimensional spacetime.",
    "Nothing with mass can reach the speed of light, because its energy would become infinite; the speed of light is the ultimate speed limit for matter, energy, and information."]],
  ["E = mc²",[
    "In another 1905 paper, Einstein derived the most famous equation in physics, E = mc²: energy equals mass times the speed of light squared. Mass and energy are equivalent, and because c² is enormous, a tiny amount of mass corresponds to a vast amount of energy: one gram of mass is equivalent to about 90 trillion joules, roughly the energy of the atomic bomb dropped on Hiroshima.",
    "This equivalence explains the energy of nuclear reactions, the Sun's power, and particle accelerators where energy becomes new particles."]],
  ["Einstein's legacy",[
    "Einstein's other 1905 papers explained Brownian motion, providing evidence for atoms, and the photoelectric effect, showing that light comes in quanta (photons), for which he received the 1921 Nobel Prize in Physics. He became the most famous scientist in the world.",
    "Special relativity, though counterintuitive, has passed every experimental test and is essential to particle physics, astronomy, and technologies such as GPS. It applies to uniform motion; Einstein then spent ten years generalizing it to include acceleration and gravity."]]
  ],
  terms:[["Luminiferous ether","The hypothetical medium for light, disproved."],["Michelson-Morley experiment","The 1887 failure to detect the ether."],["Special relativity","Einstein's 1905 theory of space, time, and light."],["Time dilation","Moving clocks running slow."],["Length contraction","Moving objects measured as shorter."],["Spacetime","Space and time combined into four dimensions."],["E = mc²","The equivalence of mass and energy."]],
  w:"Special relativity overturned common sense about space and time and revealed that mass and energy are equivalent, reshaping physics and technology.",
  src:["Special relativity","Michelson–Morley experiment","Annus mirabilis papers","Time dilation","Twin paradox","Spacetime","Mass–energy equivalence"],
  q:[["Which 1887 experiment failed to detect the ether?","The Michelson-Morley experiment","The Hafele-Keating experiment","The double-slit experiment","The Cavendish experiment"],
     ["Where was Einstein working in 1905?","The Swiss patent office in Bern","Princeton","The University of Berlin","ETH Zurich as a professor"],
     ["What is constant for all observers in special relativity?","The speed of light","Time","Length","Mass"],
     ["What happens to moving clocks?","They run slow","They run fast","They stop","Nothing"],
     ["Who combined space and time into spacetime?","Hermann Minkowski","Hendrik Lorentz","Henri Poincaré","Max Planck"],
     ["For what did Einstein receive the Nobel Prize?","The photoelectric effect","Relativity","E = mc²","Brownian motion"]]},

{ t:"General Relativity", s:"Gravity as curved spacetime",
  sec:[
  ["The happiest thought",[
    "Einstein called it “the happiest thought of my life”: a person falling freely would not feel their own weight. In 1907 he formulated the equivalence principle: the effects of gravity are indistinguishable from the effects of acceleration. A person in a closed elevator accelerating upward in space would feel exactly as if standing on Earth.",
    "After years of struggle with difficult mathematics, Einstein completed the general theory of relativity in November 1915."]],
  ["Curved spacetime",[
    "General relativity describes gravity not as a force but as the curvature of spacetime caused by mass and energy. The physicist John Wheeler summarized it: “Spacetime tells matter how to move; matter tells spacetime how to curve.” A common analogy is a heavy ball on a stretched rubber sheet, causing smaller balls to roll toward it, though this picture is imperfect.",
    "Planets orbit the Sun because they follow the straightest possible paths through the curved spacetime around it. For weak gravity and low speeds, general relativity gives the same results as Newton's law, which is why Newton's physics works so well for most purposes."]],
  ["Classic tests",[
    "General relativity explained the long-standing anomaly in Mercury's orbit, whose closest point to the Sun shifts slightly more each orbit than Newton's theory predicts. It also predicted that starlight passing near the Sun would be bent by twice the amount Newtonian reasoning suggested.",
    "During a total solar eclipse in May 1919, expeditions led by Arthur Eddington photographed stars near the darkened Sun and found their positions shifted as Einstein predicted, making him world-famous overnight. Gravitational lensing, the bending of light by massive objects, is now a major tool in astronomy."]],
  ["Gravity and time",[
    "General relativity predicts that time runs more slowly in stronger gravity: clocks on the ground tick slightly slower than clocks on a mountain or in orbit. This gravitational time dilation has been measured with atomic clocks separated by just a fraction of a meter in height.",
    "GPS satellites' clocks run faster than ground clocks by about 45 microseconds per day due to weaker gravity, and slower by about 7 microseconds per day due to their speed; without correcting for the net 38 microseconds, GPS positions would drift by kilometers each day."]],
  ["Black holes",[
    "General relativity predicts black holes, regions where spacetime is so curved that nothing, not even light, can escape. The boundary is called the event horizon. Karl Schwarzschild found the first black-hole solution in 1916, while serving in the German army in World War I.",
    "Black holes form when massive stars collapse; supermassive black holes, millions to billions of times the Sun's mass, lie at the centers of galaxies, including Sagittarius A* in the Milky Way. In 2019 the Event Horizon Telescope released the first image of a black hole's shadow, in the galaxy M87, followed in 2022 by an image of Sagittarius A*."]],
  ["Gravitational waves and cosmology",[
    "Einstein predicted in 1916 that accelerating masses produce ripples in spacetime, gravitational waves, traveling at the speed of light. On 14 September 2015, the LIGO detectors in the United States first detected gravitational waves, from two black holes merging about 1.3 billion light-years away, stretching and squeezing the detectors' 4-kilometer arms by less than a thousandth of a proton's width. Rainer Weiss, Kip Thorne, and Barry Barish received the 2017 Nobel Prize.",
    "General relativity is also the foundation of modern cosmology, describing the expanding universe and the Big Bang. It has passed every test so far, but it does not fit with quantum mechanics, and unifying the two remains one of physics' greatest challenges."]]
  ],
  terms:[["Equivalence principle","Gravity and acceleration are indistinguishable."],["General relativity","Einstein's 1915 theory of gravity as curved spacetime."],["Gravitational lensing","The bending of light by mass."],["Gravitational time dilation","Time running slower in stronger gravity."],["Black hole","A region from which nothing can escape."],["Event horizon","The boundary of a black hole."],["Gravitational waves","Ripples in spacetime."]],
  w:"General relativity transformed our understanding of gravity, predicting black holes, gravitational waves, and the expanding universe, and is essential even for GPS.",
  src:["General relativity","Equivalence principle","Tests of general relativity","Eddington experiment","Black hole","Event Horizon Telescope","LIGO"],
  q:[["In what year did Einstein complete general relativity?","1915","1905","1919","1921"],
     ["What does general relativity describe gravity as?","The curvature of spacetime","A force between masses","Magnetic attraction","Pressure"],
     ["Who led the 1919 eclipse expedition confirming general relativity?","Arthur Eddington","Edwin Hubble","Karl Schwarzschild","Max Planck"],
     ["Which planet's orbit anomaly did general relativity explain?","Mercury","Mars","Venus","Uranus"],
     ["When were gravitational waves first detected?","2015","1916","1974","2019"],
     ["In which galaxy was the first black hole image made in 2019?","M87","The Milky Way","Andromeda","The Large Magellanic Cloud"]]},

{ t:"Quantum Mechanics", s:"The strange physics of the very small",
  sec:[
  ["Quanta",[
    "In 1900 the German physicist Max Planck, trying to explain the light emitted by hot objects, proposed that energy is emitted in discrete packets, quanta, with energy proportional to frequency (E = hf, where h is Planck's constant). In 1905 Einstein explained the photoelectric effect, in which light knocks electrons out of metal, by proposing that light itself consists of quanta, later called photons.",
    "These ideas launched quantum theory, which describes the behavior of matter and energy at the scale of atoms and subatomic particles, where everyday intuitions fail."]],
  ["Wave-particle duality",[
    "In 1924 Louis de Broglie proposed that particles such as electrons also behave like waves, confirmed when electrons were shown to produce interference patterns. Everything shows wave-particle duality: light and matter behave as waves in some experiments and particles in others.",
    "In the double-slit experiment with single electrons, each electron arrives at a single point, but over many electrons an interference pattern builds up, as if each passed through both slits. If detectors determine which slit each electron passes through, the pattern disappears."]],
  ["Uncertainty and probability",[
    "In 1925–1926 Werner Heisenberg and Erwin Schrödinger developed the mathematics of quantum mechanics. Schrödinger's equation describes a particle by a wave function, and Max Born interpreted its square as giving the probability of finding the particle in a particular place. Quantum mechanics predicts probabilities, not certainties.",
    "Heisenberg's uncertainty principle (1927) states that certain pairs of properties, such as position and momentum, cannot both be known precisely at the same time; the more precisely one is measured, the less precisely the other can be known. This is not a limit of instruments but a fundamental feature of nature."]],
  ["Superposition and entanglement",[
    "Quantum systems can exist in a superposition of states until measured. Schrödinger illustrated the strangeness with a thought experiment of a cat in a box whose life depends on a random quantum event, implying it is in some sense both alive and dead until observed. The interpretation of measurement remains debated; the Copenhagen interpretation, associated with Niels Bohr and Heisenberg, and the many-worlds interpretation are among the proposals.",
    "Entanglement links particles so that measuring one instantly affects the description of the other, however far apart. Einstein called it “spooky action at a distance” and doubted quantum mechanics was complete, but experiments by Alain Aspect, John Clauser, and Anton Zeilinger, honored with the 2022 Nobel Prize, confirmed it."]],
  ["Atoms explained",[
    "In 1913 Niels Bohr proposed a model of the hydrogen atom in which electrons occupy only certain allowed energy levels and emit or absorb light of specific frequencies when jumping between them, explaining the atom's spectral lines. Full quantum mechanics replaced fixed orbits with orbitals, clouds of probability.",
    "Wolfgang Pauli's exclusion principle (1925), that no two electrons can occupy the same quantum state, explains the structure of the periodic table and why matter is solid. Quantum tunneling allows particles to pass through barriers they classically could not cross, enabling nuclear fusion in the Sun."]],
  ["Quantum technology",[
    "Though strange, quantum mechanics is the most precisely tested theory in science and underlies much modern technology: transistors and computer chips, lasers, LEDs, MRI scanners, atomic clocks, solar cells, and digital cameras. It has been estimated that a large share of the modern economy depends on quantum-based technologies.",
    "Emerging quantum technologies include quantum computers, which use qubits in superposition to tackle certain problems, quantum cryptography, and ultra-sensitive sensors. Richard Feynman remarked, “I think I can safely say that nobody understands quantum mechanics,” but everyone uses it."]]
  ],
  terms:[["Quantum","A discrete packet of energy."],["Planck's constant","The constant linking energy and frequency."],["Wave-particle duality","Behavior as both waves and particles."],["Wave function","A mathematical description giving probabilities."],["Uncertainty principle","Limits on knowing pairs of properties precisely."],["Superposition","Existing in multiple states until measured."],["Entanglement","Correlation linking distant particles."]],
  w:"Quantum mechanics describes the strange behavior of the very small and underlies chemistry, electronics, and much of modern technology.",
  src:["Quantum mechanics","Max Planck","Photoelectric effect","Wave–particle duality","Uncertainty principle","Schrödinger's cat","Quantum entanglement"],
  q:[["Who proposed energy comes in quanta in 1900?","Max Planck","Albert Einstein","Niels Bohr","Werner Heisenberg"],
     ["Who proposed that particles behave like waves?","Louis de Broglie","Erwin Schrödinger","Max Born","Paul Dirac"],
     ["What does the uncertainty principle limit?","Knowing position and momentum precisely together","The speed of light","The number of electrons","The size of atoms"],
     ["Whose thought experiment involves a cat in a box?","Schrödinger","Heisenberg","Bohr","Einstein"],
     ["What did Einstein call entanglement?","Spooky action at a distance","Quantum magic","The uncertainty effect","Hidden variables"],
     ["Who proposed the model of electrons in fixed energy levels in 1913?","Niels Bohr","Ernest Rutherford","J. J. Thomson","Wolfgang Pauli"]]},

{ t:"The Atom and the Nucleus", s:"Radioactivity, fission, and fusion",
  sec:[
  ["Discovering the atom's parts",[
    "The idea that matter is made of indivisible atoms goes back to the Greek philosophers Leucippus and Democritus. In 1897 J. J. Thomson discovered the electron, showing atoms have smaller parts, and proposed a “plum pudding” model of electrons embedded in positive charge.",
    "In 1909–1911, Ernest Rutherford's team fired alpha particles at thin gold foil; most passed through, but a few bounced back, which Rutherford compared to firing a shell at tissue paper and having it bounce back. He concluded that atoms have a tiny, dense, positively charged nucleus, with electrons around it. The atom is mostly empty space: if the nucleus were the size of a marble, the atom would be the size of a football stadium."]],
  ["The nucleus",[
    "The nucleus contains protons, positively charged, identified by Rutherford in 1917–1919, and neutrons, neutral, discovered by James Chadwick in 1932. The number of protons, the atomic number, defines the element. Isotopes of an element have the same number of protons but different numbers of neutrons, such as carbon-12 and carbon-14.",
    "Protons repel each other electrically, but they are held together in the nucleus by the strong nuclear force, the strongest of the fundamental forces, which acts only over very short distances."]],
  ["Radioactivity",[
    "In 1896 Henri Becquerel discovered that uranium salts emit invisible radiation. Marie Curie, who coined the term radioactivity, and Pierre Curie discovered the elements polonium and radium in 1898. Marie Curie became the first woman to win a Nobel Prize and the only person to win in two different sciences, physics (1903) and chemistry (1911).",
    "Unstable nuclei decay by emitting alpha particles (two protons and two neutrons, stopped by paper), beta particles (electrons, stopped by aluminum), or gamma rays (high-energy photons, reduced by thick lead or concrete). Each radioactive isotope has a half-life, the time for half of a sample to decay, from fractions of a second to billions of years; carbon-14's half-life of about 5,730 years allows radiocarbon dating of organic material up to about 50,000 years old."]],
  ["Fission",[
    "In 1938 Otto Hahn and Fritz Strassmann found that bombarding uranium with neutrons produced barium; Lise Meitner and Otto Frisch explained that the uranium nucleus had split, nuclear fission, releasing energy and more neutrons. These neutrons can split more nuclei, a chain reaction.",
    "Enrico Fermi's team achieved the first controlled chain reaction in Chicago in December 1942. The Manhattan Project developed atomic bombs, used against Hiroshima and Nagasaki in 1945. Nuclear power plants use controlled fission to produce heat for electricity, with no carbon emissions but challenges of radioactive waste and accident risk, as at Chernobyl (1986) and Fukushima (2011)."]],
  ["Fusion",[
    "Nuclear fusion joins light nuclei into heavier ones, releasing even more energy per unit of mass. The Sun and stars shine by fusing hydrogen into helium in their cores, converting about 4 million tonnes of mass into energy every second, as described by E = mc². Hydrogen bombs use fusion.",
    "Controlled fusion for electricity would offer abundant fuel and little long-lived waste, but requires temperatures of over 100 million degrees, contained by magnetic fields or lasers. In December 2022 the U.S. National Ignition Facility achieved a fusion reaction producing more energy than the lasers delivered to the fuel, a milestone; the international ITER reactor is under construction in France."]],
  ["Radiation in life",[
    "We are constantly exposed to low levels of natural background radiation from cosmic rays, radon gas, rocks, and even our bodies, which contain radioactive potassium-40. Radiation dose is measured in sieverts.",
    "Radiation is used in medicine for imaging and cancer treatment, in smoke detectors, food irradiation, and power. High doses damage cells and DNA, so radiation protection relies on time, distance, and shielding."]]
  ],
  terms:[["Nucleus","The tiny dense center of an atom."],["Isotope","An atom with the same protons but different neutrons."],["Strong nuclear force","The force binding the nucleus."],["Radioactivity","Spontaneous emission of radiation by unstable nuclei."],["Half-life","Time for half a radioactive sample to decay."],["Fission","Splitting heavy nuclei."],["Fusion","Joining light nuclei."]],
  w:"Understanding the atom and nucleus explains radioactivity, nuclear power and weapons, radiocarbon dating, and why the stars shine.",
  src:["Atomic nucleus","Geiger–Marsden experiments","Radioactive decay","Marie Curie","Half-life","Nuclear fission","Nuclear fusion"],
  q:[["Who discovered the electron in 1897?","J. J. Thomson","Ernest Rutherford","James Chadwick","Niels Bohr"],
     ["What did Rutherford's gold foil experiment reveal?","A tiny dense nucleus","The electron","The neutron","Radioactivity"],
     ["Who discovered the neutron in 1932?","James Chadwick","Enrico Fermi","Marie Curie","Otto Hahn"],
     ["Who won Nobel Prizes in both physics and chemistry?","Marie Curie","Pierre Curie","Lise Meitner","Ernest Rutherford"],
     ["What is the half-life of carbon-14?","About 5,730 years","About 50 years","About 1 million years","About 4.5 billion years"],
     ["Who explained that uranium nuclei had split in 1938?","Lise Meitner and Otto Frisch","Enrico Fermi","Albert Einstein","Niels Bohr"]]},

{ t:"Particle Physics", s:"The Standard Model and the fundamental forces",
  sec:[
  ["The particle zoo",[
    "In the mid-20th century, cosmic-ray studies and particle accelerators revealed hundreds of new subatomic particles, a bewildering “particle zoo.” Physicists eventually organized them into a theory called the Standard Model, developed in the 1960s and 1970s, which describes the fundamental particles of matter and three of the four fundamental forces.",
    "Particle accelerators smash particles together at nearly the speed of light, converting energy into new particles according to E = mc². The largest is the Large Hadron Collider (LHC) at CERN near Geneva, a 27-kilometer ring that began operating in 2008."]],
  ["Quarks and leptons",[
    "Matter is made of two families of fundamental particles, quarks and leptons. Quarks come in six “flavors”: up, down, charm, strange, top, and bottom. Protons consist of two up quarks and one down quark; neutrons of one up and two down. Quarks were proposed independently by Murray Gell-Mann and George Zweig in 1964 and never appear alone.",
    "Leptons include the electron, its heavier cousins the muon and tau, and three kinds of neutrinos, nearly massless particles that interact so weakly that trillions pass through your body every second. Each particle has an antiparticle with opposite charge; when matter and antimatter meet, they annihilate into energy. Why the universe contains much more matter than antimatter remains a mystery."]],
  ["The four forces",[
    "Physicists recognize four fundamental forces. Gravity is the weakest but acts over infinite range and dominates at large scales. Electromagnetism acts between charges and holds atoms and molecules together. The strong nuclear force binds quarks into protons and neutrons and holds nuclei together. The weak nuclear force causes some radioactive decay, such as beta decay, and is essential to nuclear fusion in the Sun.",
    "In the Standard Model, forces are carried by particles called bosons: photons carry electromagnetism, gluons the strong force, and W and Z bosons the weak force. In the 1960s Sheldon Glashow, Abdus Salam, and Steven Weinberg unified electromagnetism and the weak force into the electroweak force."]],
  ["The Higgs boson",[
    "The Standard Model explains how particles acquire mass through interaction with an invisible field filling space, the Higgs field, proposed in 1964 by Peter Higgs and others, including François Englert and Robert Brout. The field is associated with a particle, the Higgs boson.",
    "On 4 July 2012, scientists at CERN announced the discovery of the Higgs boson at the LHC, completing the Standard Model's predicted particles. Higgs and Englert received the 2013 Nobel Prize in Physics."]],
  ["What the Standard Model doesn't explain",[
    "Despite its success, the Standard Model is incomplete. It does not include gravity, does not explain dark matter, which makes up about 85 percent of the matter in the universe, or dark energy, does not explain why neutrinos have mass or why there is more matter than antimatter, and contains many arbitrary constants.",
    "Physicists are searching for physics beyond the Standard Model, through theories such as supersymmetry and string theory, which proposes that particles are tiny vibrating strings in extra dimensions, though no experimental evidence yet supports them."]],
  ["A theory of everything?",[
    "A central dream of physics is a “theory of everything” unifying all four forces, including gravity, combining general relativity and quantum mechanics into a theory of quantum gravity. Such a theory would be needed to understand the first moments of the Big Bang and the interiors of black holes.",
    "The search continues at accelerators, neutrino observatories, telescopes, and in theoretical work. Particle physics shows how far human curiosity can reach, from the visible world to particles a billion billion times smaller than a grain of sand."]]
  ],
  terms:[["Standard Model","The theory of fundamental particles and three forces."],["Quark","A fundamental particle making up protons and neutrons."],["Lepton","A family of particles including electrons and neutrinos."],["Neutrino","A nearly massless, weakly interacting particle."],["Antimatter","Particles with opposite charges to ordinary matter."],["Boson","A force-carrying particle."],["Higgs boson","The particle associated with the field that gives mass."]],
  w:"Particle physics reveals the fundamental building blocks of matter and forces, and its open questions point toward the deepest mysteries of the universe.",
  src:["Particle physics","Standard Model","Quark","Lepton","Fundamental interaction","Higgs boson","Large Hadron Collider"],
  q:[["Where is the Large Hadron Collider?","CERN near Geneva","Fermilab near Chicago","Brookhaven","Tokyo"],
     ["What quarks make up a proton?","Two up and one down","Two down and one up","Three up","One up, one down, one strange"],
     ["Who proposed quarks in 1964 alongside George Zweig?","Murray Gell-Mann","Richard Feynman","Peter Higgs","Steven Weinberg"],
     ["Which is the weakest fundamental force?","Gravity","Electromagnetism","The weak force","The strong force"],
     ["Which particle carries the electromagnetic force?","The photon","The gluon","The W boson","The Higgs boson"],
     ["When was the Higgs boson discovery announced?","2012","2008","1964","2015"]]}

);


/* ---- from sci-07.js ---- */
/* SCIENCES FOUNDATIONS, part 7: Unit 4 Chemistry, chapters 1-5 */
COURSES.sciences.units.push({ t:"Chemistry", ch:[

{ t:"Matter and Its States", s:"Solids, liquids, gases, and mixtures",
  sec:[
  ["What chemistry studies",[
    "Chemistry is the study of matter, its composition, structure, and properties, and the changes it undergoes. It is sometimes called the central science, linking physics with biology, geology, medicine, and materials science. Matter is anything that has mass and takes up space.",
    "Modern chemistry grew out of alchemy, which sought to turn base metals into gold and find an elixir of life, but which also developed laboratory techniques. Robert Boyle's The Sceptical Chymist (1661) helped move chemistry toward experiment, and Antoine Lavoisier, often called the father of modern chemistry, established the law of conservation of mass in the 1780s: in a chemical reaction, matter is neither created nor destroyed."]],
  ["States of matter",[
    "Matter commonly exists in three states. In solids, particles are tightly packed in fixed positions, vibrating in place, so solids have a definite shape and volume. In liquids, particles are close together but can slide past each other, so liquids have a definite volume but take the shape of their container. In gases, particles are far apart and move freely and rapidly, so gases fill any container.",
    "A fourth state, plasma, consists of ionized gas, in which electrons have been stripped from atoms; it is the most common state of visible matter in the universe, found in stars, lightning, and neon signs. Exotic states such as Bose-Einstein condensates, first created in 1995 near absolute zero, also exist."]],
  ["Changes of state",[
    "Matter changes state when energy is added or removed: melting (solid to liquid), freezing, vaporization (liquid to gas, by boiling or evaporation), condensation, sublimation (solid directly to gas, as with dry ice, solid carbon dioxide), and deposition (gas to solid, as frost forms).",
    "The boiling point depends on pressure: at high altitude, where air pressure is lower, water boils at lower temperatures, around 70°C on Mount Everest, so cooking takes longer, while pressure cookers raise the boiling point to cook food faster."]],
  ["Gas laws",[
    "Gases follow simple laws relating pressure, volume, and temperature. Boyle's law (1662): at constant temperature, a gas's pressure and volume are inversely proportional. Charles's law: at constant pressure, volume is proportional to absolute temperature, which is why hot-air balloons rise. Gay-Lussac's law relates pressure and temperature, explaining why aerosol cans warn against heating.",
    "These combine into the ideal gas law, PV = nRT, where n is the amount of gas and R is a constant. Amedeo Avogadro proposed in 1811 that equal volumes of gases at the same temperature and pressure contain equal numbers of molecules. The kinetic theory explains these laws in terms of moving particles colliding with container walls."]],
  ["Elements, compounds, and mixtures",[
    "A pure substance has a fixed composition. Elements cannot be broken down into simpler substances by chemical means; there are 118 known elements. Compounds consist of two or more elements chemically combined in fixed proportions, such as water (H₂O) and table salt (NaCl), with properties very different from their elements: sodium is an explosive metal and chlorine a poisonous gas, yet together they make salt.",
    "Mixtures combine substances physically, without fixed proportions, and can be separated by physical means. Homogeneous mixtures, or solutions, such as salt water and air, are uniform; heterogeneous mixtures, such as sand in water or salad, are not."]],
  ["Physical and chemical properties",[
    "Physical properties can be observed without changing a substance's identity: color, density, melting point, boiling point, hardness, and solubility. Chemical properties describe how a substance reacts, such as flammability or reactivity with acids.",
    "Physical changes, such as melting ice or dissolving sugar, do not create new substances; chemical changes, such as burning wood, rusting iron, or baking a cake, do. Separation techniques such as filtration, distillation, evaporation, and chromatography use physical properties to separate mixtures."]]
  ],
  terms:[["Matter","Anything that has mass and takes up space."],["Conservation of mass","Mass is neither created nor destroyed in reactions."],["Plasma","Ionized gas, the fourth state of matter."],["Sublimation","Solid turning directly into gas."],["Ideal gas law","PV = nRT."],["Element","A substance that cannot be chemically broken down."],["Compound","Elements chemically combined in fixed proportions."],["Mixture","Substances physically combined."]],
  w:"Understanding matter, its states, and how substances combine is the foundation of all chemistry.",
  src:["Chemistry","Antoine Lavoisier","State of matter","Plasma (physics)","Gas laws","Chemical compound","Mixture"],
  q:[["Who is often called the father of modern chemistry?","Antoine Lavoisier","Robert Boyle","John Dalton","Dmitri Mendeleev"],
     ["What is the most common state of visible matter in the universe?","Plasma","Gas","Solid","Liquid"],
     ["What is a solid turning directly into gas called?","Sublimation","Condensation","Deposition","Evaporation"],
     ["What is the ideal gas law?","PV = nRT","F = ma","E = mc²","V = IR"],
     ["How many known elements are there?","118","92","100","150"],
     ["Which is a chemical change?","Iron rusting","Ice melting","Sugar dissolving","Water boiling"]]},

{ t:"Atomic Structure and Electrons", s:"Inside the atom",
  sec:[
  ["Dalton's atomic theory",[
    "In 1803–1808 the English chemist John Dalton proposed a modern atomic theory: all matter consists of tiny atoms; atoms of the same element are identical, with the same mass; atoms of different elements differ; and compounds form when atoms combine in simple whole-number ratios. He also explained the law of definite proportions, that a compound always contains the same elements in the same mass ratio.",
    "Later discoveries showed that atoms are not indivisible and that atoms of an element can differ in mass (isotopes), but Dalton's theory established chemistry on an atomic foundation."]],
  ["Subatomic particles",[
    "Atoms consist of a tiny nucleus containing protons (positive charge, mass about 1 atomic mass unit) and neutrons (no charge, similar mass), surrounded by electrons (negative charge, about 1/1836 the mass of a proton). A neutral atom has equal numbers of protons and electrons.",
    "The atomic number (Z) is the number of protons, defining the element: hydrogen has 1, carbon 6, oxygen 8, gold 79. The mass number is the total of protons and neutrons. Atoms are tiny: about a hundred million carbon atoms would fit across a centimeter."]],
  ["Electron shells and orbitals",[
    "Electrons occupy energy levels, or shells, around the nucleus. In the simple Bohr picture, the first shell holds up to 2 electrons, the second up to 8, and the third up to 18. Quantum mechanics describes electrons in orbitals, regions of probability with shapes labeled s (spherical), p (dumbbell), d, and f.",
    "The arrangement of electrons is called the electron configuration. Sodium, with 11 electrons, has the configuration 2, 8, 1: two in the first shell, eight in the second, and one in the third."]],
  ["Valence electrons",[
    "The electrons in the outermost shell, the valence electrons, largely determine an element's chemical behavior. Atoms tend to gain, lose, or share electrons to achieve a stable configuration, often a full outer shell of eight electrons, called the octet rule.",
    "Noble gases such as neon and argon already have full outer shells and are very unreactive. Sodium readily loses its single valence electron; chlorine, with seven, readily gains one; this is why they react so vigorously."]],
  ["Ions and isotopes",[
    "An ion is an atom or group of atoms with an electric charge because it has gained or lost electrons. Cations are positive ions, formed by losing electrons, such as Na⁺; anions are negative ions, formed by gaining electrons, such as Cl⁻. Ions are essential to life, carrying nerve signals and regulating fluids.",
    "Isotopes of an element have the same number of protons but different numbers of neutrons. Hydrogen has three: ordinary hydrogen (no neutrons), deuterium (one), and radioactive tritium (two). Isotopes have nearly identical chemistry but different masses, used in dating, medical tracers, and studying past climates."]],
  ["Spectra and flame tests",[
    "When atoms absorb energy, electrons jump to higher energy levels; when they fall back, they emit light of specific wavelengths, producing a unique line spectrum for each element. This is why fireworks have different colors: strontium produces red, copper blue-green, sodium yellow, and barium green.",
    "Flame tests and spectroscopy identify elements in laboratory samples and in distant stars, confirming that the same elements exist throughout the universe."]]
  ],
  terms:[["Atomic theory","Dalton's theory that matter consists of atoms."],["Proton, neutron, electron","The three main subatomic particles."],["Atomic number","The number of protons in an atom."],["Orbital","A region of probability where electrons are found."],["Valence electrons","Outer-shell electrons that determine reactivity."],["Octet rule","The tendency to achieve eight outer electrons."],["Ion","A charged atom or group of atoms."]],
  w:"The structure of the atom, especially its electrons, explains why elements behave as they do and how they combine.",
  src:["John Dalton","Atom","Atomic number","Atomic orbital","Electron configuration","Valence electron","Ion"],
  q:[["Who proposed a modern atomic theory in the early 1800s?","John Dalton","Democritus","Ernest Rutherford","Lavoisier"],
     ["What does the atomic number count?","Protons","Neutrons","Electrons plus neutrons","Isotopes"],
     ["How many electrons can the first shell hold?","2","8","18","1"],
     ["What are outer-shell electrons called?","Valence electrons","Core electrons","Ions","Orbitals"],
     ["What is a positive ion called?","A cation","An anion","An isotope","A neutron"],
     ["Which element produces red in fireworks?","Strontium","Sodium","Copper","Barium"]]},

{ t:"The Periodic Table", s:"Mendeleev's map of the elements",
  sec:[
  ["Mendeleev's insight",[
    "By the mid-19th century, about 60 elements were known, and chemists sought patterns among them. In 1869 the Russian chemist Dmitri Mendeleev arranged the elements by atomic weight in a table where elements with similar properties fell into the same columns. He boldly left gaps for undiscovered elements and predicted their properties.",
    "His predictions were confirmed when gallium (1875), scandium (1879), and germanium (1886) were discovered with properties remarkably close to those he forecast. Henry Moseley showed in 1913 that the table is properly ordered by atomic number rather than atomic weight. Element 101 is named mendelevium in his honor."]],
  ["Periods and groups",[
    "The modern periodic table has 7 horizontal rows, called periods, and 18 vertical columns, called groups. Elements in the same group have the same number of valence electrons and similar chemical properties. Moving across a period, the atomic number increases one at a time as electrons fill a shell.",
    "The table's shape reflects electron configurations: the s-block on the left, the p-block on the right, the d-block (transition metals) in the middle, and the f-block (lanthanides and actinides) usually shown separately below."]],
  ["Metals, nonmetals, and metalloids",[
    "About three-quarters of the elements are metals, on the left and center: shiny, good conductors of heat and electricity, malleable, and tending to lose electrons. Nonmetals, on the upper right, include gases such as oxygen and nitrogen and solids such as carbon and sulfur; they are generally poor conductors and tend to gain electrons.",
    "Metalloids, such as silicon and germanium, along the staircase line between them, have intermediate properties; silicon's semiconducting behavior makes it the basis of computer chips."]],
  ["Key groups",[
    "Group 1, the alkali metals (lithium, sodium, potassium, rubidium, cesium), are soft, highly reactive metals that react with water, sometimes explosively, increasingly so down the group. Group 2, the alkaline earth metals, include magnesium and calcium. Group 17, the halogens (fluorine, chlorine, bromine, iodine), are highly reactive nonmetals that form salts with metals; their name means “salt-former.”",
    "Group 18, the noble gases (helium, neon, argon, krypton, xenon, radon), have full outer shells and are very unreactive; neon glows red in signs and argon fills light bulbs. Transition metals, such as iron, copper, gold, and platinum, form colorful compounds and are used as catalysts."]],
  ["Periodic trends",[
    "Properties change in predictable ways across the table. Atomic radius generally decreases across a period, as more protons pull electrons closer, and increases down a group, as more shells are added. Electronegativity, an atom's tendency to attract shared electrons, increases across a period and decreases down a group; fluorine is the most electronegative element.",
    "Reactivity of metals increases down a group, while reactivity of nonmetals such as halogens decreases down a group. These trends allow chemists to predict how elements will behave."]],
  ["Elements of life and industry",[
    "Hydrogen is the most abundant element in the universe; oxygen is the most abundant in Earth's crust and in the human body by mass. About 96 percent of the human body's mass is just four elements: oxygen, carbon, hydrogen, and nitrogen.",
    "Elements beyond uranium (atomic number 92) are mostly synthetic, made in reactors and accelerators. The heaviest confirmed, oganesson (118), was named in 2016. The International Union of Pure and Applied Chemistry (IUPAC) approves element names. The periodic table remains one of science's great organizing achievements."]]
  ],
  terms:[["Periodic table","The table organizing elements by atomic number and properties."],["Period","A horizontal row."],["Group","A vertical column of similar elements."],["Alkali metals","Highly reactive Group 1 metals."],["Halogens","Reactive Group 17 nonmetals."],["Noble gases","Unreactive Group 18 gases."],["Electronegativity","An atom's tendency to attract shared electrons."]],
  w:"The periodic table organizes all known elements and lets chemists predict their properties, making it one of the most powerful tools in science.",
  src:["Periodic table","Dmitri Mendeleev","Henry Moseley","Alkali metal","Halogen","Noble gas","Periodic trends"],
  q:[["Who created the periodic table in 1869?","Dmitri Mendeleev","John Dalton","Henry Moseley","Lavoisier"],
     ["Which of these elements did Mendeleev predict?","Gallium","Oxygen","Gold","Carbon"],
     ["How many groups does the modern periodic table have?","18","7","8","32"],
     ["Which group are the noble gases?","Group 18","Group 1","Group 17","Group 2"],
     ["What is the most electronegative element?","Fluorine","Oxygen","Chlorine","Helium"],
     ["What is the most abundant element in the universe?","Hydrogen","Helium","Oxygen","Carbon"]]},

{ t:"Chemical Bonding", s:"How atoms stick together",
  sec:[
  ["Why atoms bond",[
    "Atoms bond to achieve more stable, lower-energy arrangements of electrons, typically full outer shells. The main types of chemical bonds are ionic, covalent, and metallic, depending on how electrons are transferred or shared.",
    "Whether atoms form ionic or covalent bonds depends largely on the difference in their electronegativities: large differences favor ionic bonds; small differences favor covalent bonds."]],
  ["Ionic bonds",[
    "Ionic bonds form when one atom transfers electrons to another, typically from a metal to a nonmetal, creating oppositely charged ions held together by electrostatic attraction. Sodium gives an electron to chlorine, forming Na⁺ and Cl⁻ ions, which arrange themselves in a repeating three-dimensional crystal lattice in table salt.",
    "Ionic compounds typically have high melting points, are hard and brittle, and conduct electricity when melted or dissolved in water, as their ions become free to move."]],
  ["Covalent bonds",[
    "Covalent bonds form when atoms share pairs of electrons, typically between nonmetals. In a hydrogen molecule (H₂), two atoms share one pair of electrons; in oxygen (O₂), a double bond shares two pairs; in nitrogen (N₂), a very strong triple bond shares three. The American chemist Gilbert N. Lewis described shared electron pairs in 1916, and Lewis structures diagram them with dots and lines.",
    "When electrons are shared unequally because one atom is more electronegative, the bond is polar, with slightly positive and negative ends. In water, oxygen pulls shared electrons more strongly than hydrogen, making the molecule polar."]],
  ["Metallic bonds",[
    "In metals, atoms release their valence electrons into a shared “sea” of delocalized electrons that move freely among positive metal ions. This metallic bonding explains why metals conduct electricity and heat so well, why they are shiny, and why they are malleable and ductile: layers of atoms can slide past each other without breaking bonds.",
    "Alloys are mixtures of metals, or metals with other elements, with improved properties: bronze (copper and tin), brass (copper and zinc), and steel (iron with a little carbon), which is far stronger than pure iron."]],
  ["Carbon's many bonds",[
    "Carbon, with four valence electrons, forms four covalent bonds and can bond with itself in chains, rings, and networks, giving rise to millions of compounds and to life itself. Pure carbon forms different structures called allotropes: diamond, in which each atom bonds to four others in a rigid 3D network, making it the hardest natural material; graphite, in which layers of hexagons slide over each other, used in pencils; fullerenes such as buckminsterfullerene (C₆₀), a soccer-ball-shaped molecule discovered in 1985; and graphene, a single layer of graphite, isolated in 2004, extraordinarily strong and conductive.",
    "The same atoms arranged differently produce completely different materials, a central lesson of chemistry."]],
  ["Linus Pauling",[
    "The American chemist Linus Pauling applied quantum mechanics to chemical bonding in The Nature of the Chemical Bond (1939), one of the most influential chemistry books ever written, and developed the electronegativity scale. He won the 1954 Nobel Prize in Chemistry and the 1962 Nobel Peace Prize for campaigning against nuclear weapons testing, the only person to win two unshared Nobel Prizes.",
    "Understanding bonding explains the properties of every material, from salt and water to steel, plastics, and DNA."]]
  ],
  terms:[["Ionic bond","Electrostatic attraction between ions formed by electron transfer."],["Covalent bond","A bond formed by sharing electron pairs."],["Polar bond","A covalent bond with unequal sharing."],["Metallic bond","Metal ions in a sea of delocalized electrons."],["Alloy","A mixture of metals or metal with other elements."],["Allotrope","A different structural form of the same element."],["Lewis structure","A diagram of bonding electrons."]],
  w:"Chemical bonding explains how atoms form all the substances around us and why materials have the properties they do.",
  src:["Chemical bond","Ionic bonding","Covalent bond","Metallic bonding","Alloy","Allotropes of carbon","Linus Pauling"],
  q:[["What type of bond holds table salt together?","Ionic","Covalent","Metallic","Hydrogen"],
     ["What type of bond involves sharing electrons?","Covalent","Ionic","Metallic","Electrostatic"],
     ["What explains metals' electrical conductivity?","A sea of delocalized electrons","Ionic lattices","Shared electron pairs","Hydrogen bonds"],
     ["Steel is mainly iron alloyed with what?","Carbon","Tin","Zinc","Copper"],
     ["Which carbon allotrope is the hardest natural material?","Diamond","Graphite","Graphene","Fullerene"],
     ["Who won two unshared Nobel Prizes?","Linus Pauling","Marie Curie","Frederick Sanger","John Bardeen"]]},

{ t:"Molecules and Intermolecular Forces", s:"Shapes, polarity, and the special case of water",
  sec:[
  ["Molecular shapes",[
    "Molecules have specific three-dimensional shapes that determine their properties. VSEPR theory (valence shell electron pair repulsion) predicts shapes by assuming electron pairs around a central atom repel each other and spread as far apart as possible.",
    "Carbon dioxide is linear; water is bent, with an angle of about 104.5 degrees; ammonia is pyramidal; and methane is tetrahedral, with bond angles of about 109.5 degrees. Shape determines how molecules interact, including how drugs fit into biological receptors and how enzymes recognize their targets."]],
  ["Polar and nonpolar molecules",[
    "A molecule is polar if it has polar bonds arranged asymmetrically, giving it a positive and a negative end, a dipole. Water is polar because of its bent shape. Carbon dioxide has polar bonds but is nonpolar overall because its linear shape cancels the dipoles.",
    "“Like dissolves like”: polar substances such as salt and sugar dissolve in polar water, while nonpolar substances such as oil and grease do not, but dissolve in nonpolar solvents. Soap molecules have a polar head and a nonpolar tail, allowing them to surround grease and wash it away in water."]],
  ["Intermolecular forces",[
    "Intermolecular forces are attractions between molecules, much weaker than chemical bonds within molecules, but they determine melting and boiling points, viscosity, and solubility. London dispersion forces, temporary attractions caused by fluctuating electrons, act between all molecules and grow stronger with molecular size. Dipole-dipole forces attract polar molecules.",
    "Hydrogen bonds, the strongest intermolecular forces, form when hydrogen bonded to a highly electronegative atom (nitrogen, oxygen, or fluorine) is attracted to another such atom. Geckos cling to walls through countless dispersion forces between their microscopic toe hairs and surfaces."]],
  ["Water's remarkable properties",[
    "Water's hydrogen bonds give it unusual properties essential to life. It has an unusually high boiling point for such a small molecule, so it is liquid at Earth's surface temperatures. It has a high specific heat, moderating temperatures, and high surface tension, which lets insects walk on water.",
    "Water expands when it freezes, because hydrogen bonds lock molecules into an open hexagonal lattice, so ice is less dense than liquid water and floats, insulating lakes so aquatic life survives winter. Water is called the universal solvent because it dissolves so many substances, making it the medium of life's chemistry."]],
  ["Solutions and concentration",[
    "A solution consists of a solute dissolved in a solvent. Concentration measures how much solute is present, often as molarity, moles of solute per liter of solution. Solubility usually increases with temperature for solids, but gases are less soluble in warm water, which is why warm soda goes flat and warm water holds less oxygen for fish.",
    "Dissolved substances change a solvent's properties: salt lowers water's freezing point, which is why salt is spread on icy roads, and raises its boiling point slightly. Osmosis, the movement of water across a membrane toward higher solute concentration, is vital in living cells."]],
  ["Hydrogen bonds in life",[
    "Hydrogen bonds hold together the two strands of the DNA double helix, weak enough to separate for copying yet collectively strong enough to keep it stable, and help fold proteins into their working shapes.",
    "Understanding molecular shape and intermolecular forces explains phenomena from why ice floats to how DNA works and why oil and water do not mix."]]
  ],
  terms:[["VSEPR theory","Predicting molecular shape from electron pair repulsion."],["Polar molecule","A molecule with positive and negative ends."],["Like dissolves like","Polar dissolves polar; nonpolar dissolves nonpolar."],["Dispersion forces","Weak attractions from fluctuating electrons."],["Hydrogen bond","A strong attraction involving hydrogen and N, O, or F."],["Solute and solvent","The dissolved substance and the dissolving medium."],["Osmosis","Water movement across a membrane toward higher solute concentration."]],
  w:"Molecular shape and intermolecular forces explain the properties of substances, from why oil and water separate to how water sustains life.",
  src:["VSEPR theory","Chemical polarity","Intermolecular force","Hydrogen bond","Properties of water","Solution (chemistry)","Osmosis"],
  q:[["What shape is a water molecule?","Bent","Linear","Tetrahedral","Pyramidal"],
     ["Why is carbon dioxide nonpolar overall?","Its linear shape cancels the dipoles","It has no bonds","It contains no oxygen","It is ionic"],
     ["What is the strongest intermolecular force?","Hydrogen bonding","Dispersion forces","Dipole-dipole forces","Ionic bonding"],
     ["Why does ice float?","Hydrogen bonds form an open lattice, making it less dense","It contains air bubbles","It is warmer","It is lighter in mass"],
     ["How do geckos cling to walls?","Dispersion forces from microscopic toe hairs","Suction cups","Glue","Magnetism"],
     ["What holds the two strands of DNA together?","Hydrogen bonds","Ionic bonds","Metallic bonds","Covalent bonds"]]}

]});


/* ---- from sci-08.js ---- */
/* SCIENCES FOUNDATIONS, part 8: Unit 4 chapters 6-10 */
COURSES.sciences.units[3].ch.push(

{ t:"Chemical Reactions", s:"Equations and types of reactions",
  sec:[
  ["What a reaction is",[
    "A chemical reaction rearranges atoms, breaking bonds in the starting substances, the reactants, and forming new bonds to make new substances, the products. Signs of a reaction include color change, gas bubbles, a precipitate (a solid forming in solution), light, and temperature change.",
    "No atoms are created or destroyed in a reaction, only rearranged, so mass is conserved, as Lavoisier showed by careful weighing in sealed containers."]],
  ["Chemical equations",[
    "Chemical equations represent reactions with formulas and an arrow from reactants to products. Because atoms are conserved, equations must be balanced, with the same number of each type of atom on both sides, by adding coefficients. Hydrogen and oxygen form water: 2H₂ + O₂ → 2H₂O, two molecules of hydrogen and one of oxygen produce two molecules of water.",
    "State symbols show whether substances are solid (s), liquid (l), gas (g), or dissolved in water (aq, aqueous)."]],
  ["Types of reactions",[
    "Common types include synthesis (combination), where substances join to form a more complex product, such as iron and sulfur forming iron sulfide; decomposition, where a compound breaks down, such as water splitting into hydrogen and oxygen by electrolysis; single replacement, where one element replaces another in a compound; and double replacement, where ions exchange partners, often forming a precipitate.",
    "Combustion is a rapid reaction with oxygen that releases heat and light. Burning hydrocarbon fuels such as methane produces carbon dioxide and water: CH₄ + 2O₂ → CO₂ + 2H₂O. Incomplete combustion, with too little oxygen, produces toxic carbon monoxide and soot."]],
  ["Fire",[
    "Fire requires three things, the fire triangle: fuel, oxygen, and heat. Removing any one extinguishes it: firefighters use water to remove heat, blankets or foam to cut off oxygen, and firebreaks to remove fuel. Grease and electrical fires should not be fought with water.",
    "Before Lavoisier, chemists explained burning with phlogiston theory, the idea that a fire-like substance escaped from burning materials. Lavoisier showed that combustion is combination with oxygen, which he named, demolishing phlogiston theory in the 1770s–1780s."]],
  ["Precipitation and everyday reactions",[
    "In precipitation reactions, two dissolved ionic compounds react to form an insoluble solid. Hard water, containing calcium and magnesium ions, forms limescale and soap scum.",
    "Everyday chemistry is full of reactions: baking soda and vinegar fizz as they produce carbon dioxide; cooking browns food through the Maillard reaction between amino acids and sugars; rusting is iron slowly reacting with oxygen and water; and photosynthesis and respiration are the reactions that sustain life."]],
  ["Catalysts and enzymes",[
    "A catalyst speeds up a reaction without being consumed, by providing an alternative pathway with lower activation energy. Catalytic converters in cars, introduced widely in the 1970s, use platinum, palladium, and rhodium to convert toxic exhaust gases into less harmful ones.",
    "The Haber-Bosch process uses an iron catalyst to make ammonia from nitrogen and hydrogen for fertilizer, feeding billions. Enzymes are biological catalysts, proteins that speed up reactions in living things by factors of millions or more; digestion, DNA copying, and metabolism all depend on them."]]
  ],
  terms:[["Reactants and products","Starting substances and the substances formed."],["Balanced equation","An equation with equal numbers of each atom on both sides."],["Combustion","Rapid reaction with oxygen releasing heat and light."],["Fire triangle","Fuel, oxygen, and heat."],["Precipitate","An insoluble solid formed in a solution."],["Catalyst","A substance that speeds a reaction without being consumed."],["Enzyme","A biological catalyst."]],
  w:"Chemical reactions transform substances everywhere, from fires and cooking to industry and the chemistry of life.",
  src:["Chemical reaction","Chemical equation","Combustion","Fire triangle","Phlogiston theory","Maillard reaction","Catalysis"],
  q:[["What are the starting substances in a reaction called?","Reactants","Products","Catalysts","Precipitates"],
     ["What is the balanced equation for forming water?","2H₂ + O₂ → 2H₂O","H₂ + O₂ → H₂O","H + O → HO","2H + O₂ → H₂O₂"],
     ["What does incomplete combustion produce?","Carbon monoxide and soot","Pure oxygen","Only water","Hydrogen"],
     ["What three things make up the fire triangle?","Fuel, oxygen, and heat","Fuel, water, and air","Heat, light, and smoke","Oxygen, carbon, and hydrogen"],
     ["Which theory did Lavoisier overturn?","Phlogiston theory","Atomic theory","Caloric theory","Vitalism"],
     ["What browns food during cooking?","The Maillard reaction","Oxidation of fat","Photosynthesis","Fermentation"]]},

{ t:"The Mole and Stoichiometry", s:"Counting atoms by weighing",
  sec:[
  ["Too small to count",[
    "Atoms and molecules are far too small to count individually, so chemists count them by weighing, using a unit called the mole. One mole contains exactly 6.02214076 × 10²³ particles, Avogadro's number, named after Amedeo Avogadro. A mole of grains of sand would cover a large country deeply.",
    "The mole is defined so that the mass of one mole of a substance in grams equals its average molecular or atomic mass in atomic mass units. One mole of carbon-12 atoms has a mass of 12 grams; one mole of water (H₂O, mass 18) has a mass of about 18 grams, about a tablespoon."]],
  ["Molar mass",[
    "The molar mass of a compound is the sum of the atomic masses of its atoms, in grams per mole. Carbon dioxide (CO₂) has a molar mass of 12 + 2 × 16 = 44 grams per mole. To find the number of moles in a sample, divide its mass by its molar mass: 88 grams of CO₂ is 2 moles.",
    "This conversion between mass and number of particles is the foundation of quantitative chemistry."]],
  ["Stoichiometry",[
    "Stoichiometry (from the Greek for “element measure”) is the calculation of quantities of reactants and products in reactions, based on balanced equations. In 2H₂ + O₂ → 2H₂O, 2 moles of hydrogen react with 1 mole of oxygen to produce 2 moles of water; by mass, 4 grams of hydrogen react with 32 grams of oxygen to make 36 grams of water.",
    "Stoichiometry allows chemists, pharmacists, and engineers to calculate exactly how much of each ingredient is needed and how much product will form."]],
  ["Limiting reactants and yield",[
    "In real reactions, one reactant often runs out first, limiting how much product can form; it is called the limiting reactant, and the others are in excess. If a sandwich needs two slices of bread and one slice of cheese, ten slices of bread and three of cheese make only three sandwiches; cheese is limiting.",
    "The theoretical yield is the maximum product possible; the actual yield is usually less because of side reactions and losses. Percent yield, actual divided by theoretical times 100, measures efficiency, important in industry. Green chemistry seeks to maximize efficiency and minimize waste."]],
  ["Concentration and gases",[
    "Concentrations of solutions are expressed in moles per liter (molarity, M). A 1 M solution of sodium chloride contains 58.5 grams of salt per liter. Diluting a solution adds solvent, reducing concentration while the amount of solute stays the same.",
    "At standard temperature and pressure, one mole of any ideal gas occupies about 22.4 liters, which allows gas volumes to be converted to moles."]],
  ["Chemistry by numbers",[
    "Quantitative methods transformed chemistry from a descriptive craft into an exact science. Lavoisier's careful weighing, Dalton's atomic weights, Avogadro's hypothesis, and Stanislao Cannizzaro's clarification of atomic weights in 1860 established the foundations.",
    "Today, analytical chemistry measures concentrations down to parts per trillion, essential for testing drugs, food safety, pollution, forensic evidence, and doping in sports."]]
  ],
  terms:[["Mole","6.022 × 10²³ particles."],["Avogadro's number","The number of particles in a mole."],["Molar mass","The mass of one mole of a substance."],["Stoichiometry","Calculating quantities in reactions."],["Limiting reactant","The reactant that runs out first."],["Percent yield","Actual yield as a percentage of theoretical yield."],["Molarity","Moles of solute per liter of solution."]],
  w:"The mole and stoichiometry let chemists count atoms by weighing them and predict exactly how much of each substance a reaction uses and makes.",
  src:["Mole (unit)","Avogadro constant","Molar mass","Stoichiometry","Limiting reagent","Yield (chemistry)","Molar concentration"],
  q:[["What is Avogadro's number approximately?","6.022 × 10²³","3 × 10⁸","6.67 × 10⁻¹¹","1.6 × 10⁻¹⁹"],
     ["What is the molar mass of water?","About 18 g/mol","About 10 g/mol","About 32 g/mol","About 44 g/mol"],
     ["What is the molar mass of CO₂?","44 g/mol","28 g/mol","32 g/mol","12 g/mol"],
     ["What is the reactant that runs out first called?","The limiting reactant","The catalyst","The excess reactant","The product"],
     ["What volume does one mole of ideal gas occupy at STP?","About 22.4 liters","About 1 liter","About 100 liters","About 6 liters"],
     ["What does molarity measure?","Moles of solute per liter of solution","Grams per milliliter","Atoms per molecule","Mass per mole"]]},

{ t:"Energy and Rates of Reaction", s:"Why reactions happen and how fast",
  sec:[
  ["Exothermic and endothermic",[
    "Chemical reactions involve energy changes because breaking bonds absorbs energy and forming bonds releases it. Exothermic reactions release more energy than they absorb, heating their surroundings; examples include combustion, respiration, and hand warmers. Endothermic reactions absorb energy, cooling their surroundings; examples include photosynthesis, cold packs (dissolving ammonium nitrate), and cooking an egg.",
    "The heat change of a reaction at constant pressure is called the enthalpy change (ΔH), negative for exothermic and positive for endothermic reactions. Energy diagrams show reactants and products at different energy levels."]],
  ["Activation energy",[
    "Even exothermic reactions usually need an initial push to start, called the activation energy, the energy needed to break bonds and reach an unstable transition state. A match must be struck before it burns; wood and paper do not spontaneously ignite at room temperature despite being able to release a lot of energy.",
    "The Swedish chemist Svante Arrhenius described in 1889 how reaction rates depend on temperature and activation energy. Catalysts work by lowering the activation energy."]],
  ["Collision theory",[
    "According to collision theory, molecules must collide with enough energy and the correct orientation to react. Anything that increases the number of effective collisions speeds up a reaction.",
    "Factors affecting reaction rate include temperature (higher temperature means faster, more energetic collisions; roughly, rates often double for each 10°C rise), concentration or pressure (more particles, more collisions), surface area (powders react faster than lumps, which is why flour dust and coal dust can explode), catalysts, and the nature of the reactants."]],
  ["Spontaneity and free energy",[
    "Whether a reaction can happen on its own depends not only on energy but on entropy, the tendency toward disorder. The American physicist Josiah Willard Gibbs combined them in the 1870s into free energy (ΔG = ΔH − TΔS): a reaction is spontaneous if free energy decreases.",
    "“Spontaneous” does not mean fast: diamond spontaneously turns into graphite at room temperature, but so slowly that it takes billions of years. Thermodynamics tells whether a reaction can occur; kinetics tells how fast."]],
  ["Fuels and food energy",[
    "Fuels store chemical energy released by combustion; the energy released per gram is the fuel's energy density. Hydrogen has very high energy per gram but low energy per volume, gasoline about 46 kilojoules per gram, and fats about 37 kilojoules (9 food Calories) per gram, compared with about 17 kilojoules (4 Calories) per gram for carbohydrates and proteins.",
    "Calorimetry measures energy released by reactions, by burning samples in a bomb calorimeter surrounded by water and measuring the temperature rise; nutritional Calorie values were originally determined this way."]],
  ["Explosions and controlling reactions",[
    "Explosions are extremely fast exothermic reactions that produce large volumes of hot gas. Alfred Nobel made nitroglycerin safer to handle by absorbing it into a porous material, inventing dynamite in 1867, and used his fortune to fund the Nobel Prizes.",
    "Chemical engineers control reaction rates in industry through temperature, pressure, catalysts, and mixing, balancing speed, yield, safety, and cost. Food preservation by refrigeration slows the chemical and biological reactions of spoilage."]]
  ],
  terms:[["Exothermic","A reaction releasing heat."],["Endothermic","A reaction absorbing heat."],["Enthalpy change","The heat change of a reaction, ΔH."],["Activation energy","The energy needed to start a reaction."],["Collision theory","Reactions require energetic, properly oriented collisions."],["Gibbs free energy","A measure combining enthalpy and entropy to predict spontaneity."],["Calorimetry","Measuring heat from reactions."]],
  w:"Understanding reaction energy and rates explains why fuels burn, food spoils, catalysts help, and some reactions happen while others do not.",
  src:["Exothermic reaction","Endothermic process","Activation energy","Collision theory","Reaction rate","Gibbs free energy","Alfred Nobel"],
  q:[["Which is an endothermic process?","Photosynthesis","Combustion","Respiration","A hand warmer"],
     ["What is the energy needed to start a reaction?","Activation energy","Enthalpy","Free energy","Kinetic energy"],
     ["Why can flour dust explode?","Its large surface area speeds reaction","It contains nitroglycerin","It is radioactive","It is a catalyst"],
     ["Who combined enthalpy and entropy into free energy?","Josiah Willard Gibbs","Svante Arrhenius","Lavoisier","Le Chatelier"],
     ["About how much energy per gram do fats provide?","9 Calories","4 Calories","2 Calories","20 Calories"],
     ["Who invented dynamite?","Alfred Nobel","Fritz Haber","Svante Arrhenius","Ascanio Sobrero"]]},

{ t:"Chemical Equilibrium", s:"Reactions that go both ways",
  sec:[
  ["Reversible reactions",[
    "Many reactions are reversible: products can react to re-form reactants. In a closed system, a reversible reaction eventually reaches dynamic equilibrium, when the forward and reverse reactions occur at the same rate, so the amounts of reactants and products remain constant, although molecules continue to react in both directions.",
    "An analogy is a crowded room with people moving in and out of two doors at the same rate: the numbers inside stay constant though individuals constantly change."]],
  ["The equilibrium constant",[
    "The position of equilibrium is described by the equilibrium constant (K), the ratio of product concentrations to reactant concentrations at equilibrium, each raised to the power of its coefficient. A large K means products are favored; a small K means reactants are favored.",
    "K depends only on temperature, not on starting amounts. The law of mass action, formulated by Cato Guldberg and Peter Waage in 1864, describes this relationship."]],
  ["Le Chatelier's principle",[
    "Le Chatelier's principle, formulated by the French chemist Henri Le Chatelier in 1884, states that if a system at equilibrium is disturbed, it shifts to counteract the disturbance. Adding reactant shifts equilibrium toward products; removing product does the same. Increasing pressure favors the side with fewer gas molecules.",
    "Raising temperature shifts equilibrium in the endothermic direction, absorbing the added heat; lowering it favors the exothermic direction. Catalysts speed up reaching equilibrium but do not change its position."]],
  ["The Haber process",[
    "The Haber-Bosch process, developed by Fritz Haber and Carl Bosch around 1909–1913, makes ammonia (NH₃) from nitrogen in the air and hydrogen: N₂ + 3H₂ ⇌ 2NH₃. The reaction is exothermic and reduces the number of gas molecules, so high pressure favors ammonia; low temperature favors it too but makes the reaction slow. Industry compromises at about 400–450°C and around 200 atmospheres with an iron catalyst, removing ammonia as it forms.",
    "Ammonia fertilizer made by this process supports roughly half of the world's food production. Haber, who received the 1918 Nobel Prize, also led Germany's chemical weapons program in World War I, a reminder of the moral complexity of science."]],
  ["Equilibrium in the body and the environment",[
    "Equilibria are everywhere in living systems. Hemoglobin in red blood cells binds oxygen in the lungs, where oxygen is plentiful, and releases it in tissues, where it is scarce, a shifting equilibrium. At high altitude, lower oxygen pressure shifts the equilibrium, and the body adapts by making more red blood cells.",
    "The oceans absorb carbon dioxide from the air, forming carbonic acid; as atmospheric CO₂ rises, the equilibrium shifts, increasing ocean acidity and reducing carbonate ions that shellfish and corals need for their shells and skeletons."]],
  ["Solubility equilibria",[
    "Even “insoluble” salts dissolve slightly, reaching equilibrium between solid and dissolved ions. Stalactites and stalagmites form as calcium carbonate dissolves in slightly acidic groundwater and then precipitates when carbon dioxide escapes in caves.",
    "Kidney stones form when certain salts exceed their solubility in urine. Understanding equilibrium helps chemists control reactions in industry, medicine, and nature."]]
  ],
  terms:[["Reversible reaction","A reaction that can proceed in both directions."],["Dynamic equilibrium","Forward and reverse rates equal, amounts constant."],["Equilibrium constant","The ratio describing equilibrium position."],["Le Chatelier's principle","Systems at equilibrium shift to counteract disturbances."],["Haber-Bosch process","Industrial ammonia synthesis."],["Law of mass action","The relationship defining equilibrium constants."]],
  w:"Equilibrium explains how reversible reactions balance, how industry makes fertilizer, and how blood carries oxygen and oceans absorb carbon dioxide.",
  src:["Chemical equilibrium","Dynamic equilibrium","Equilibrium constant","Le Chatelier's principle","Haber process","Fritz Haber","Ocean acidification"],
  q:[["What is true at dynamic equilibrium?","Forward and reverse reactions occur at the same rate","All reactions stop","Only products remain","Only reactants remain"],
     ["Who formulated the principle that equilibrium counteracts disturbances?","Henri Le Chatelier","Fritz Haber","Lavoisier","Josiah Gibbs"],
     ["What does a catalyst do to equilibrium?","Speeds reaching it without changing its position","Shifts it toward products","Shifts it toward reactants","Stops the reaction"],
     ["What does the Haber process make?","Ammonia","Sulfuric acid","Nitric acid","Methane"],
     ["About what share of world food production depends on Haber-Bosch fertilizer?","About half","About 5 percent","Almost none","All of it"],
     ["What does increasing pressure favor?","The side with fewer gas molecules","The side with more gas molecules","Neither side","Only solids"]]},

{ t:"Acids and Bases", s:"pH, neutralization, and buffers",
  sec:[
  ["Properties",[
    "Acids taste sour (as in lemons and vinegar), turn blue litmus paper red, react with many metals to produce hydrogen gas, and conduct electricity in solution. Bases taste bitter, feel slippery (soap), turn red litmus blue, and neutralize acids. Strong acids and bases are corrosive; tasting laboratory chemicals is dangerous.",
    "Common acids include hydrochloric acid in the stomach, citric acid in fruit, acetic acid in vinegar, carbonic acid in soda, and sulfuric acid in car batteries. Common bases include ammonia in cleaners, sodium hydroxide (lye) in drain cleaner, and sodium bicarbonate (baking soda)."]],
  ["Definitions",[
    "In 1884 Svante Arrhenius defined acids as substances that produce hydrogen ions (H⁺) in water and bases as substances that produce hydroxide ions (OH⁻). In 1923 Johannes Brønsted and Thomas Lowry broadened the definitions: an acid is a proton (H⁺) donor and a base is a proton acceptor. Gilbert Lewis defined acids even more broadly as electron-pair acceptors.",
    "Strong acids, such as hydrochloric, sulfuric, and nitric acid, ionize completely in water; weak acids, such as acetic and citric acid, ionize only partly."]],
  ["The pH scale",[
    "The pH scale, introduced by the Danish chemist Søren Sørensen in 1909 at the Carlsberg Laboratory, measures acidity from 0 to 14. Pure water is neutral at pH 7; lower values are acidic and higher values are basic (alkaline). The scale is logarithmic: each step represents a tenfold change in hydrogen ion concentration, so pH 3 is ten times more acidic than pH 4 and a thousand times more acidic than pH 6.",
    "Approximate values: stomach acid about 1.5–3.5, lemon juice about 2, vinegar about 2.5–3, coffee about 5, rain about 5.6, blood about 7.4, seawater about 8.1, baking soda solution about 8.3, ammonia about 11, and drain cleaner about 14. Indicators such as litmus, phenolphthalein, and red cabbage juice change color with pH."]],
  ["Neutralization",[
    "When an acid and a base react, they neutralize each other, producing water and a salt: hydrochloric acid plus sodium hydroxide gives water and sodium chloride. Antacids neutralize excess stomach acid, farmers add lime (calcium oxide or carbonate) to acidic soils, and bee stings (acidic) are traditionally treated with baking soda.",
    "Titration is a laboratory technique for finding the concentration of an acid or base by adding a solution of known concentration until neutralization is reached, shown by an indicator's color change."]],
  ["Buffers",[
    "A buffer is a solution that resists changes in pH when small amounts of acid or base are added, usually a mixture of a weak acid and its salt. Human blood is buffered, mainly by the carbonic acid–bicarbonate system, keeping its pH between about 7.35 and 7.45; departures outside this range, acidosis or alkalosis, can be life-threatening.",
    "Buffers are essential in medicine, biology experiments, and the oceans, which are buffered by carbonate chemistry."]],
  ["Acid rain and ocean acidification",[
    "Burning coal and oil releases sulfur dioxide and nitrogen oxides, which form sulfuric and nitric acids in the atmosphere, falling as acid rain that damaged forests, lakes, and buildings in Europe and North America in the 20th century. Laws such as the U.S. Clean Air Act amendments of 1990 greatly reduced it.",
    "Today, rising carbon dioxide is acidifying the oceans: average surface ocean pH has fallen from about 8.2 to about 8.1 since the Industrial Revolution, about a 30 percent increase in acidity, threatening corals, shellfish, and plankton."]]
  ],
  terms:[["Acid","A proton donor; produces H⁺ in water."],["Base","A proton acceptor; produces OH⁻ in water."],["pH","A logarithmic scale of acidity from 0 to 14."],["Indicator","A substance that changes color with pH."],["Neutralization","The reaction of an acid and a base forming water and a salt."],["Titration","Measuring concentration by neutralization."],["Buffer","A solution that resists pH changes."]],
  w:"Acids and bases are central to digestion, blood chemistry, cleaning, agriculture, and environmental problems such as acid rain and ocean acidification.",
  src:["Acid","Base (chemistry)","Brønsted–Lowry acid–base theory","PH","Neutralization (chemistry)","Buffer solution","Acid rain"],
  q:[["What color does an acid turn blue litmus paper?","Red","Blue","Green","Yellow"],
     ["How did Brønsted and Lowry define an acid?","A proton donor","A proton acceptor","An electron donor","A hydroxide producer"],
     ["What is the pH of pure water?","7","0","14","5.6"],
     ["How much more acidic is pH 3 than pH 4?","Ten times","Twice","A hundred times","The same"],
     ["What is the normal pH of human blood?","About 7.4","About 6.0","About 8.5","About 2.0"],
     ["What do an acid and a base produce when they neutralize?","Water and a salt","Hydrogen gas","Carbon dioxide only","A stronger acid"]]}

);


/* ---- from sci-09.js ---- */
/* SCIENCES FOUNDATIONS, part 9: Unit 4 chapters 11-13 */
COURSES.sciences.units[3].ch.push(

{ t:"Redox and Electrochemistry", s:"Electron transfer, batteries, and corrosion",
  sec:[
  ["Oxidation and reduction",[
    "Oxidation-reduction (redox) reactions involve the transfer of electrons. Oxidation is the loss of electrons; reduction is the gain of electrons. A common mnemonic is OIL RIG: Oxidation Is Loss, Reduction Is Gain. The two always occur together: when one substance is oxidized, another is reduced.",
    "The term oxidation originally meant combining with oxygen, as in burning and rusting, but it now refers to any loss of electrons. The substance that causes oxidation, by accepting electrons, is the oxidizing agent; the substance that donates electrons is the reducing agent."]],
  ["Redox everywhere",[
    "Redox reactions are among the most important in nature and technology. Combustion, cellular respiration, and photosynthesis are redox reactions. Bleach and hydrogen peroxide are oxidizing agents that kill microbes and remove stains. Extracting metals from ores, such as reducing iron oxide to iron in a blast furnace with carbon, is reduction.",
    "Antioxidants in foods, such as vitamins C and E, are reducing agents that protect cells from damage by reactive oxidizing molecules."]],
  ["Corrosion",[
    "Corrosion is the gradual destruction of metals by redox reactions with their environment. Rusting is the oxidation of iron in the presence of water and oxygen, forming hydrated iron oxide; salt water speeds it up. Corrosion costs economies vast sums each year in damaged bridges, pipes, cars, and ships.",
    "Corrosion is prevented by painting, oiling, coating iron with zinc (galvanizing), alloying it into stainless steel with chromium, which forms a protective oxide layer, or attaching a more reactive “sacrificial” metal such as zinc or magnesium to ships' hulls and pipelines. Aluminum resists corrosion because it forms a thin protective oxide layer."]],
  ["Batteries",[
    "A battery, or electrochemical cell, converts chemical energy into electrical energy through redox reactions in which electrons flow through an external circuit from the anode (where oxidation occurs) to the cathode (where reduction occurs). Volta's pile of 1800 was the first.",
    "Common types include alkaline batteries (zinc and manganese dioxide), lead-acid car batteries, and rechargeable lithium-ion batteries, developed by John Goodenough, M. Stanley Whittingham, and Akira Yoshino, who shared the 2019 Nobel Prize in Chemistry. Lithium-ion batteries power phones, laptops, and electric vehicles, and are central to storing renewable energy."]],
  ["Electrolysis",[
    "Electrolysis uses electrical energy to drive non-spontaneous redox reactions. Passing current through water splits it into hydrogen and oxygen; through molten salt, it produces sodium and chlorine. Humphry Davy used electrolysis in 1807–1808 to isolate sodium, potassium, calcium, and other elements for the first time, and his assistant Michael Faraday formulated the laws of electrolysis.",
    "Aluminum, once more precious than gold, became cheap after Charles Martin Hall and Paul Héroult independently invented an electrolysis process in 1886. Electroplating coats objects with thin layers of metals such as silver, gold, or chrome. Electrolysis of water using renewable electricity produces “green hydrogen” as a clean fuel."]],
  ["Fuel cells",[
    "A fuel cell generates electricity continuously from a fuel, typically hydrogen, reacting with oxygen, producing only water as a byproduct. Fuel cells powered the Apollo spacecraft and supplied astronauts' drinking water.",
    "Fuel cells are used in some vehicles, buses, and backup power systems. Electrochemistry also underlies sensors such as blood glucose meters and breathalyzers."]]
  ],
  terms:[["Oxidation","Loss of electrons."],["Reduction","Gain of electrons."],["OIL RIG","Oxidation Is Loss, Reduction Is Gain."],["Corrosion","Destruction of metal by redox reactions."],["Galvanizing","Coating iron with zinc to prevent rust."],["Electrolysis","Using electricity to drive chemical reactions."],["Fuel cell","A device generating electricity from fuel and oxygen."]],
  w:"Redox chemistry powers batteries and living cells, makes metals, and explains corrosion, making it central to energy and industry.",
  src:["Redox","Corrosion","Galvanization","Electrochemical cell","Lithium-ion battery","Electrolysis","Fuel cell"],
  q:[["What is oxidation?","Loss of electrons","Gain of electrons","Gain of protons","Loss of neutrons"],
     ["What does OIL RIG stand for?","Oxidation Is Loss, Reduction Is Gain","Oxygen In, Light Released In Gas","Oxidation Increases Light","Ores In Liquid, Reduced In Gas"],
     ["What is coating iron with zinc called?","Galvanizing","Electroplating","Anodizing","Tempering"],
     ["Who shared the 2019 Nobel Prize for lithium-ion batteries?","Goodenough, Whittingham, and Yoshino","Volta and Davy","Hall and Héroult","Faraday and Davy"],
     ["Who first isolated sodium and potassium by electrolysis?","Humphry Davy","Michael Faraday","Alessandro Volta","Lavoisier"],
     ["What is the byproduct of a hydrogen fuel cell?","Water","Carbon dioxide","Methane","Ammonia"]]},

{ t:"Organic Chemistry", s:"The chemistry of carbon",
  sec:[
  ["What organic chemistry is",[
    "Organic chemistry is the chemistry of carbon compounds. Early chemists believed organic compounds could only be made by living things, through a “vital force.” In 1828 Friedrich Wöhler synthesized urea, a compound found in urine, from inorganic starting materials, helping to overturn vitalism.",
    "Carbon's ability to form four bonds and long chains and rings allows millions of organic compounds, far more than all other elements combined. Organic chemistry underlies life, medicine, fuels, plastics, dyes, and food."]],
  ["Hydrocarbons",[
    "Hydrocarbons contain only carbon and hydrogen. Alkanes have single bonds: methane (CH₄, natural gas), ethane, propane (used in grills), butane (lighters), and octane, a component of gasoline. Alkenes contain carbon-carbon double bonds, such as ethene (ethylene), which ripens fruit and is the basis of polyethylene; alkynes contain triple bonds, such as acetylene, used in welding torches.",
    "Crude oil is a mixture of hydrocarbons separated by fractional distillation into fractions with different boiling points: gases, gasoline, kerosene, diesel, lubricating oils, and bitumen for roads."]],
  ["Benzene and aromatic compounds",[
    "Benzene (C₆H₆) is a ring of six carbon atoms with a special stability due to delocalized electrons. Its structure puzzled chemists until August Kekulé proposed a ring in 1865, reportedly after dreaming of a snake biting its own tail. Compounds containing benzene rings are called aromatic, many having distinctive smells.",
    "Aromatic compounds include aspirin, the explosive TNT, many dyes, and components of DNA."]],
  ["Functional groups",[
    "Organic molecules are classified by functional groups, specific groups of atoms that give characteristic properties. Alcohols contain an -OH group: ethanol is the alcohol in beverages and a fuel; methanol is toxic. Carboxylic acids contain -COOH: acetic acid gives vinegar its taste. Esters, formed from acids and alcohols, give fruits and perfumes their scents.",
    "Amines contain nitrogen and often have fishy odors; amino acids contain both amine and carboxylic acid groups. Aldehydes and ketones include formaldehyde and acetone, used in nail polish remover."]],
  ["Isomers",[
    "Isomers are molecules with the same molecular formula but different structures and properties. Butane and isobutane both have the formula C₄H₁₀ but different shapes. Some molecules exist as mirror-image forms, like left and right hands, called enantiomers, a property called chirality.",
    "Chirality matters enormously in biology: the two forms of the molecule carvone smell of spearmint and caraway, and in the 1950s–1960s, thalidomide, prescribed to pregnant women for morning sickness, caused severe birth defects in thousands of babies; one mirror form was linked to the harm. The disaster led to much stricter drug testing."]],
  ["Organic chemistry and medicine",[
    "Most drugs are organic molecules. Aspirin was developed from salicylic acid, found in willow bark, and synthesized in usable form by Felix Hoffmann at Bayer in 1897. Penicillin, discovered by Alexander Fleming in 1928 and developed into a drug by Howard Florey and Ernst Chain, is an organic molecule whose structure was determined by Dorothy Hodgkin using X-ray crystallography.",
    "Medicinal chemists design and synthesize new molecules to target diseases, and organic synthesis can now build extraordinarily complex natural products in the laboratory."]]
  ],
  terms:[["Organic chemistry","The chemistry of carbon compounds."],["Vitalism","The disproven idea that organic compounds need a life force."],["Hydrocarbon","A compound of only carbon and hydrogen."],["Fractional distillation","Separating crude oil by boiling point."],["Aromatic compound","A compound containing a benzene ring."],["Functional group","A group of atoms giving characteristic properties."],["Isomer","A molecule with the same formula but different structure."],["Chirality","Mirror-image forms of a molecule."]],
  w:"Organic chemistry, the chemistry of carbon, underlies life, medicine, fuels, and materials, making it one of the most practical branches of science.",
  src:["Organic chemistry","Wöhler synthesis","Hydrocarbon","Benzene","Functional group","Chirality (chemistry)","Thalidomide scandal"],
  q:[["Who synthesized urea in 1828, challenging vitalism?","Friedrich Wöhler","August Kekulé","Lavoisier","Justus von Liebig"],
     ["What is the main component of natural gas?","Methane","Propane","Octane","Ethylene"],
     ["Who proposed the ring structure of benzene?","August Kekulé","Friedrich Wöhler","Linus Pauling","Dmitri Mendeleev"],
     ["Which functional group defines alcohols?","-OH","-COOH","-NH₂","-CHO"],
     ["What are mirror-image molecules called?","Enantiomers","Isotopes","Polymers","Allotropes"],
     ["Who determined the structure of penicillin?","Dorothy Hodgkin","Alexander Fleming","Rosalind Franklin","Howard Florey"]]},

{ t:"Polymers and Materials", s:"Plastics, fibers, and the materials of modern life",
  sec:[
  ["What polymers are",[
    "Polymers are giant molecules made of many repeating units called monomers, linked in long chains, like beads on a string. Natural polymers include cellulose (in wood and cotton), starch, proteins such as silk and wool, rubber, and DNA. In the 1920s the German chemist Hermann Staudinger argued that polymers are long covalently bonded chains, an idea initially resisted, for which he won the 1953 Nobel Prize.",
    "Addition polymerization links monomers with double bonds, such as ethylene forming polyethylene. Condensation polymerization joins monomers while releasing small molecules such as water, as in nylon and polyester."]],
  ["The plastics age",[
    "Bakelite, invented by Leo Baekeland in 1907, was the first fully synthetic plastic. Wallace Carothers at DuPont invented nylon in 1935, first sold in women's stockings in 1939–1940 and used for parachutes in World War II. Polyethylene, discovered accidentally in 1933, PVC, polystyrene, and polyester followed.",
    "Plastics are cheap, light, durable, and moldable, transforming packaging, clothing, medicine, cars, and electronics. Global plastic production grew from about 2 million tonnes in 1950 to over 400 million tonnes a year in the 2020s."]],
  ["Thermoplastics and thermosets",[
    "Thermoplastics, such as polyethylene, PVC, and PET (used in drink bottles), soften when heated and can be remolded and recycled. Thermosets, such as Bakelite, epoxy resins, and vulcanized rubber, form permanent cross-links between chains when cured and cannot be remelted.",
    "Charles Goodyear discovered vulcanization in 1839, heating rubber with sulfur to cross-link it, making it durable for tires and many other uses."]],
  ["Plastic pollution",[
    "Plastics' durability is also a problem: most do not biodegrade, and much plastic waste ends up in landfills, rivers, and oceans, where it harms wildlife and breaks into tiny fragments called microplastics, now found from Arctic ice to human blood. Only a small fraction of plastic ever produced has been recycled.",
    "Solutions include reducing single-use plastics, better recycling, biodegradable and bio-based plastics, and chemical recycling that breaks plastics back into monomers. Negotiations on a global plastics treaty began in 2022."]],
  ["Materials science",[
    "Materials science studies how the structure of materials determines their properties and designs new ones. Major classes include metals and alloys, ceramics (hard, heat-resistant materials such as porcelain, glass, and the tiles that protected the Space Shuttle), polymers, and composites, which combine materials, such as fiberglass and carbon fiber, which is lighter than steel yet very strong, used in aircraft and sports equipment.",
    "Semiconductors such as silicon, purified and precisely doped with impurities, make modern electronics possible. Superconductors carry electricity with zero resistance at low temperatures, used in MRI magnets."]],
  ["New materials",[
    "Nanotechnology manipulates materials at the scale of billionths of a meter, where properties can change dramatically. Gold nanoparticles can appear red; carbon nanotubes are extraordinarily strong. Graphene, a single layer of carbon atoms isolated by Andre Geim and Konstantin Novoselov in 2004 using sticky tape, earned the 2010 Nobel Prize.",
    "Smart materials respond to their environment, such as shape-memory alloys that return to their original shape when heated, and self-healing polymers. Kevlar, a polymer invented by Stephanie Kwolek at DuPont in 1965, is five times stronger than steel by weight and used in bulletproof vests."]]
  ],
  terms:[["Polymer","A large molecule of repeating units."],["Monomer","A small molecule that links into polymers."],["Thermoplastic","A plastic that can be remelted."],["Thermoset","A plastic with permanent cross-links."],["Vulcanization","Cross-linking rubber with sulfur."],["Microplastics","Tiny plastic fragments in the environment."],["Composite","A material combining different materials."]],
  w:"Polymers and new materials shape almost everything we use, and managing their environmental impact is a major challenge for chemistry.",
  src:["Polymer","Bakelite","Nylon","Vulcanization","Plastic pollution","Materials science","Graphene"],
  q:[["What was the first fully synthetic plastic?","Bakelite","Nylon","Polyethylene","PVC"],
     ["Who invented nylon?","Wallace Carothers","Leo Baekeland","Hermann Staudinger","Stephanie Kwolek"],
     ["Who discovered vulcanization of rubber?","Charles Goodyear","John Dunlop","Leo Baekeland","Thomas Hancock"],
     ["What are tiny plastic fragments in the environment called?","Microplastics","Nanotubes","Monomers","Composites"],
     ["Who invented Kevlar?","Stephanie Kwolek","Wallace Carothers","Andre Geim","Charles Goodyear"],
     ["How was graphene first isolated?","Using sticky tape","Using lasers","In a particle accelerator","By electrolysis"]]}

);


/* ---- from sci-10.js ---- */
/* SCIENCES FOUNDATIONS, part 10: Unit 5 Biology, chapters 1-5 */
COURSES.sciences.units.push({ t:"Biology: Cells and Molecules", ch:[

{ t:"What Is Life?", s:"The characteristics of living things and the molecules of life",
  sec:[
  ["Defining life",[
    "Biology is the study of life. Defining life is surprisingly difficult, but living things share characteristic features: they are made of cells; they use energy through metabolism; they maintain stable internal conditions (homeostasis); they grow and develop; they respond to their environment; they reproduce; and they carry hereditary information in DNA that changes over generations through evolution.",
    "Viruses are a borderline case: they contain genetic material and evolve, but cannot reproduce or carry out metabolism on their own, only inside host cells, so many biologists do not consider them fully alive."]],
  ["Levels of organization",[
    "Life is organized in levels: atoms form molecules; molecules form organelles inside cells; cells form tissues; tissues form organs, such as the heart; organs form organ systems, such as the circulatory system; and organ systems make up an organism. Beyond the individual are populations, communities, ecosystems, and the biosphere.",
    "At each level, new properties emerge that are not present in the parts alone, so-called emergent properties."]],
  ["The elements and water",[
    "Living things are made mainly of six elements, often remembered as CHNOPS: carbon, hydrogen, nitrogen, oxygen, phosphorus, and sulfur. Water makes up about 60 percent of the human body and is the medium for nearly all life's chemistry.",
    "Carbon's versatility in forming chains and rings makes it the backbone of all biological molecules."]],
  ["Carbohydrates and lipids",[
    "Life depends on four main classes of large molecules (macromolecules). Carbohydrates, sugars and their polymers, provide energy and structure: glucose is the main fuel of cells; starch stores energy in plants and glycogen in animals; cellulose, in plant cell walls, is the most abundant organic molecule on Earth; chitin forms the exoskeletons of insects.",
    "Lipids, including fats, oils, phospholipids, and steroids, do not dissolve in water. Fats store energy compactly; phospholipids form cell membranes; and steroids include cholesterol and hormones such as testosterone and estrogen."]],
  ["Proteins",[
    "Proteins are chains of amino acids, of which 20 kinds are commonly used, folded into specific three-dimensional shapes that determine their functions. Proteins do most of the work in cells: enzymes catalyze reactions; structural proteins such as collagen and keratin build tissues; antibodies fight infection; hemoglobin carries oxygen; actin and myosin enable muscle contraction; and many hormones, such as insulin, are proteins.",
    "A protein's shape is so important that denaturing it, by heat or acid, destroys its function, as when egg whites turn solid when cooked. Frederick Sanger first sequenced a protein, insulin, in the early 1950s."]],
  ["Nucleic acids",[
    "Nucleic acids, DNA (deoxyribonucleic acid) and RNA (ribonucleic acid), store and transmit genetic information. They are polymers of nucleotides, each containing a sugar, a phosphate group, and a nitrogenous base.",
    "DNA uses four bases, adenine (A), thymine (T), guanine (G), and cytosine (C); RNA uses uracil (U) instead of thymine. The sequence of bases encodes the instructions for building proteins. Another nucleotide, ATP (adenosine triphosphate), serves as the cell's energy currency, releasing energy when a phosphate group is removed."]]
  ],
  terms:[["Homeostasis","Maintaining stable internal conditions."],["Metabolism","All the chemical reactions in an organism."],["Emergent property","A property arising at a higher level of organization."],["Carbohydrate","Sugars and their polymers."],["Lipid","Fats, oils, phospholipids, and steroids."],["Protein","A folded chain of amino acids."],["Nucleic acid","DNA and RNA."],["ATP","The cell's energy currency."]],
  w:"Understanding what life is and the molecules it is made of provides the foundation for all of biology.",
  src:["Life","Biological organisation","CHNOPS","Carbohydrate","Lipid","Protein","Nucleic acid"],
  q:[["Which of these is NOT a characteristic of life?","Being made of metal","Metabolism","Reproduction","Homeostasis"],
     ["What does CHNOPS stand for?","Carbon, hydrogen, nitrogen, oxygen, phosphorus, sulfur","Calcium, helium, neon, oxygen, potassium, sodium","Carbon, helium, nickel, osmium, platinum, silicon","Chlorine, hydrogen, nitrogen, oxygen, phosphorus, silver"],
     ["What is the most abundant organic molecule on Earth?","Cellulose","Glucose","DNA","Collagen"],
     ["What are proteins made of?","Amino acids","Nucleotides","Fatty acids","Sugars"],
     ["Which base is found in RNA but not DNA?","Uracil","Thymine","Adenine","Guanine"],
     ["What is the cell's energy currency?","ATP","DNA","Glucose","Insulin"]]},

{ t:"The Cell", s:"The basic unit of life",
  sec:[
  ["Cell theory",[
    "In 1665 Robert Hooke, looking at thin slices of cork through a microscope, saw tiny compartments he called “cells,” after the small rooms of monks. Antonie van Leeuwenhoek soon observed living single-celled organisms, which he called animalcules.",
    "In 1838–1839 Matthias Schleiden and Theodor Schwann proposed that all plants and animals are made of cells, and in 1855 Rudolf Virchow added that all cells come from pre-existing cells (“omnis cellula e cellula”). Cell theory states that all living things are made of cells, the cell is the basic unit of life, and all cells arise from other cells."]],
  ["Prokaryotes and eukaryotes",[
    "There are two basic cell types. Prokaryotic cells, found in bacteria and archaea, are small and simple, lacking a nucleus and membrane-bound organelles; their DNA floats in a region called the nucleoid. Eukaryotic cells, found in animals, plants, fungi, and protists, are larger and contain a nucleus and many specialized organelles.",
    "A typical bacterium is about 1–2 micrometers long; a typical animal cell about 10–30 micrometers. The human body contains roughly 30 trillion human cells and a comparable number of bacterial cells."]],
  ["Organelles",[
    "The nucleus, surrounded by a double membrane, contains DNA and controls the cell; the nucleolus inside makes ribosomes. Ribosomes build proteins. The endoplasmic reticulum, a network of membranes, makes proteins (rough ER, studded with ribosomes) and lipids (smooth ER). The Golgi apparatus modifies, packages, and ships proteins.",
    "Mitochondria are the powerhouses of the cell, producing ATP through cellular respiration. Lysosomes digest waste and worn-out parts. The cytoskeleton, a network of protein fibers, gives shape and enables movement, and the cytoplasm is the jelly-like fluid filling the cell."]],
  ["Plant cells",[
    "Plant cells have several features animal cells lack: a rigid cell wall made of cellulose, which supports the plant; chloroplasts, which carry out photosynthesis using the green pigment chlorophyll; and a large central vacuole filled with water, which keeps cells firm. When plants lack water, vacuoles shrink and plants wilt.",
    "Fungal cells have cell walls made of chitin rather than cellulose."]],
  ["Endosymbiosis",[
    "Mitochondria and chloroplasts have their own DNA and ribosomes resembling those of bacteria and divide independently. The American biologist Lynn Margulis championed the endosymbiotic theory in the 1960s: these organelles descend from free-living bacteria that were engulfed by ancestral cells over a billion years ago and lived inside them in a mutually beneficial partnership.",
    "Initially controversial, the theory is now widely accepted and explains how complex eukaryotic cells arose."]],
  ["Specialized cells",[
    "Multicellular organisms contain many specialized cell types: the human body has about 200, including red blood cells, which lack a nucleus to carry more hemoglobin; nerve cells, with long extensions to carry signals, some over a meter long; muscle cells, which contract; and sperm and egg cells.",
    "All develop from a single fertilized egg through cell division and differentiation. Stem cells are unspecialized cells that can become many types, offering hope for regenerative medicine."]]
  ],
  terms:[["Cell theory","All life is made of cells, which come from other cells."],["Prokaryote","A cell without a nucleus."],["Eukaryote","A cell with a nucleus and organelles."],["Mitochondrion","The organelle producing ATP."],["Chloroplast","The organelle of photosynthesis."],["Endosymbiotic theory","Mitochondria and chloroplasts descend from engulfed bacteria."],["Stem cell","An unspecialized cell able to become many types."]],
  w:"The cell is the basic unit of life, and understanding its parts explains how organisms grow, function, and evolve.",
  src:["Cell (biology)","Cell theory","Prokaryote","Eukaryote","Organelle","Endosymbiont","Stem cell"],
  q:[["Who named cells after observing cork in 1665?","Robert Hooke","Antonie van Leeuwenhoek","Theodor Schwann","Rudolf Virchow"],
     ["Who stated that all cells come from pre-existing cells?","Rudolf Virchow","Matthias Schleiden","Robert Hooke","Louis Pasteur"],
     ["Which cells lack a nucleus?","Prokaryotic cells","Plant cells","Animal cells","Fungal cells"],
     ["Which organelle produces ATP?","The mitochondrion","The ribosome","The Golgi apparatus","The nucleus"],
     ["What is the plant cell wall made of?","Cellulose","Chitin","Protein","Starch"],
     ["Who championed the endosymbiotic theory?","Lynn Margulis","Rosalind Franklin","Barbara McClintock","Rachel Carson"]]},

{ t:"Membranes and Transport", s:"How cells control what enters and leaves",
  sec:[
  ["The cell membrane",[
    "Every cell is surrounded by a plasma membrane that separates its interior from the environment and controls what passes in and out. It consists mainly of a phospholipid bilayer: phospholipid molecules have water-loving (hydrophilic) heads and water-fearing (hydrophobic) tails, so in water they spontaneously form two layers with tails facing inward.",
    "Embedded proteins act as channels, pumps, receptors, and identification tags. In 1972 S. J. Singer and Garth Nicolson described this structure as the fluid mosaic model: the membrane is fluid, with proteins floating in the lipid layer like icebergs."]],
  ["Diffusion and osmosis",[
    "Passive transport moves substances without using energy, from areas of high concentration to low concentration. Diffusion is the spreading of molecules down a concentration gradient, as when oxygen diffuses from the lungs into the blood. Small, nonpolar molecules such as oxygen and carbon dioxide pass directly through the membrane.",
    "Osmosis is the diffusion of water across a selectively permeable membrane toward the side with more dissolved solutes. Red blood cells placed in pure water swell and burst; in very salty water they shrivel. This is why intravenous fluids must have the right salt concentration, and why drinking seawater dehydrates you."]],
  ["Facilitated diffusion",[
    "Larger or charged molecules, such as glucose and ions, cannot easily cross the lipid bilayer. They pass through specific protein channels or carriers, still moving down their concentration gradient without energy, a process called facilitated diffusion.",
    "Aquaporins, water channels discovered by Peter Agre (Nobel Prize 2003), allow water to cross membranes rapidly."]],
  ["Active transport",[
    "Active transport moves substances against their concentration gradient, from low to high concentration, using energy, usually from ATP. The sodium-potassium pump, discovered by Jens Christian Skou in 1957, pumps sodium ions out of cells and potassium ions in, maintaining gradients essential for nerve signals and muscle contraction; it uses a large share of the body's energy.",
    "Plant roots use active transport to absorb mineral ions from soil where they are scarce."]],
  ["Bulk transport",[
    "Cells move large particles and quantities by enclosing them in membrane sacs called vesicles. In endocytosis, the membrane folds inward to take material in; phagocytosis (“cell eating”), used by white blood cells to engulf bacteria, is one form.",
    "In exocytosis, vesicles fuse with the membrane to release their contents, as when nerve cells release neurotransmitters or pancreatic cells secrete insulin."]],
  ["Cell communication",[
    "Cells communicate through chemical signals that bind to receptor proteins on their membranes, triggering responses inside the cell, a process called signal transduction. Hormones, neurotransmitters, and growth factors work this way.",
    "Many drugs act by binding to membrane receptors or channels. Cholera toxin, for example, disrupts membrane transport in intestinal cells, causing severe water loss; oral rehydration solutions of salt and sugar, which exploit glucose-sodium co-transport, have saved millions of lives."]]
  ],
  terms:[["Plasma membrane","The boundary controlling what enters and leaves a cell."],["Phospholipid bilayer","The double layer of lipids forming membranes."],["Fluid mosaic model","The membrane as fluid lipids with floating proteins."],["Diffusion","Movement from high to low concentration."],["Osmosis","Diffusion of water across a membrane."],["Active transport","Movement against a gradient using energy."],["Endocytosis and exocytosis","Taking in and releasing material via vesicles."]],
  w:"Membranes and transport control the traffic of every cell, explaining nerve signals, dehydration, and how many medicines work.",
  src:["Cell membrane","Lipid bilayer","Fluid mosaic model","Diffusion","Osmosis","Active transport","Na+/K+-ATPase"],
  q:[["What is the cell membrane mainly made of?","A phospholipid bilayer","Cellulose","Protein only","DNA"],
     ["Who described the fluid mosaic model?","Singer and Nicolson","Watson and Crick","Schleiden and Schwann","Margulis"],
     ["What is the diffusion of water across a membrane called?","Osmosis","Active transport","Endocytosis","Exocytosis"],
     ["What happens to red blood cells in pure water?","They swell and burst","They shrivel","Nothing","They divide"],
     ["Which process moves substances against a gradient using energy?","Active transport","Diffusion","Osmosis","Facilitated diffusion"],
     ["What is phagocytosis?","Cell eating","Cell drinking","Cell division","Cell death"]]},

{ t:"Enzymes and Metabolism", s:"The chemistry that keeps cells alive",
  sec:[
  ["Metabolism",[
    "Metabolism is the sum of all chemical reactions in an organism. It has two parts: catabolism, breaking down molecules to release energy, as in digestion and respiration, and anabolism, building complex molecules from simpler ones using energy, as in making proteins and DNA.",
    "Metabolic reactions are organized into pathways, sequences of steps each catalyzed by a specific enzyme. Basal metabolic rate is the energy used at rest; for an average adult it is roughly 1,200–1,800 Calories per day."]],
  ["How enzymes work",[
    "Enzymes are biological catalysts, mostly proteins, that speed up reactions by lowering activation energy, often by factors of millions or more. Each enzyme has an active site, a pocket shaped to fit its specific substrate. Emil Fischer proposed the lock-and-key model in 1894; Daniel Koshland's induced-fit model (1958) refined it, showing the active site changes shape slightly to grip the substrate.",
    "Enzymes are named with the suffix -ase: amylase digests starch, lipase digests fats, protease digests proteins, and DNA polymerase copies DNA. James Sumner showed in 1926 that enzymes are proteins by crystallizing urease."]],
  ["Factors affecting enzymes",[
    "Each enzyme works best at an optimum temperature and pH. Human enzymes generally work best near 37°C; at high temperatures, enzymes denature, losing their shape. Pepsin in the stomach works best at a very acidic pH of about 2, while enzymes in the small intestine prefer slightly alkaline conditions.",
    "Bacteria in hot springs have heat-stable enzymes; one, Taq polymerase from Thermus aquaticus, discovered in Yellowstone, made the PCR technique for copying DNA practical."]],
  ["Regulation and inhibition",[
    "Cells control metabolism by regulating enzymes. Inhibitors reduce enzyme activity: competitive inhibitors block the active site, and non-competitive inhibitors bind elsewhere, changing the enzyme's shape. In feedback inhibition, the end product of a pathway inhibits an early enzyme, preventing overproduction, like a thermostat.",
    "Many drugs and poisons are enzyme inhibitors: aspirin inhibits enzymes involved in inflammation; penicillin blocks a bacterial enzyme that builds cell walls; statins inhibit an enzyme in cholesterol production; and nerve agents such as sarin block an enzyme essential to nerve function."]],
  ["Cofactors and vitamins",[
    "Many enzymes need helpers: cofactors, such as metal ions like iron, zinc, and magnesium, and coenzymes, organic molecules often derived from vitamins. B vitamins, for example, form coenzymes in energy metabolism.",
    "Vitamin deficiencies cause diseases: scurvy from lack of vitamin C, which is needed for collagen formation, killed many sailors until the Scottish naval surgeon James Lind showed in 1747, in one of the first controlled trials, that citrus fruits cured it. Beriberi results from lack of thiamine (B1), and rickets from lack of vitamin D."]],
  ["Enzymes in everyday life",[
    "Enzymes are used in biological laundry detergents to break down stains, in baking and brewing, in making cheese (rennet curdles milk), in producing high-fructose corn syrup, and in medicine and diagnostics.",
    "Genetic disorders of metabolism, such as phenylketonuria (PKU), in which an enzyme to process the amino acid phenylalanine is missing, can be managed by diet; newborns in many countries are screened for PKU."]]
  ],
  terms:[["Catabolism and anabolism","Breaking down and building up molecules."],["Enzyme","A biological catalyst."],["Active site","The region where a substrate binds."],["Substrate","The molecule an enzyme acts on."],["Denaturation","Loss of a protein's shape and function."],["Feedback inhibition","An end product inhibiting its own pathway."],["Coenzyme","An organic helper molecule, often from vitamins."]],
  w:"Enzymes and metabolism are the chemical engine of life, explaining digestion, nutrition, disease, and how many drugs work.",
  src:["Metabolism","Enzyme","Active site","Enzyme inhibitor","Cofactor (biochemistry)","James Lind","Taq polymerase"],
  q:[["What is the building-up part of metabolism called?","Anabolism","Catabolism","Digestion","Respiration"],
     ["Who proposed the lock-and-key model?","Emil Fischer","Daniel Koshland","James Sumner","Louis Pasteur"],
     ["What does amylase digest?","Starch","Fats","Proteins","DNA"],
     ["At what pH does pepsin work best?","About 2","About 7","About 10","About 14"],
     ["Who showed citrus fruits cure scurvy in 1747?","James Lind","James Cook","Edward Jenner","Joseph Lister"],
     ["Which enzyme from a hot-spring bacterium made PCR practical?","Taq polymerase","Amylase","Pepsin","Lipase"]]},

{ t:"Photosynthesis and Respiration", s:"Capturing and releasing the Sun's energy",
  sec:[
  ["Energy flow in life",[
    "Almost all life on Earth runs on energy from the Sun, captured by photosynthesis and released by cellular respiration. Photosynthesis converts light energy into chemical energy stored in sugar, releasing oxygen; respiration breaks down sugar to release energy as ATP, consuming oxygen and releasing carbon dioxide. The two processes form a cycle linking plants and animals.",
    "Jan Ingenhousz showed in 1779 that plants produce oxygen only in light, building on Joseph Priestley's discovery that a plant could “restore” air in which a candle had burned out."]],
  ["Photosynthesis",[
    "The overall equation for photosynthesis is: 6CO₂ + 6H₂O + light energy → C₆H₁₂O₆ (glucose) + 6O₂. It takes place in chloroplasts, mainly in leaf cells. The green pigment chlorophyll absorbs red and blue light and reflects green, which is why plants look green.",
    "Photosynthesis has two stages. In the light-dependent reactions, in the thylakoid membranes, light energy splits water molecules, releasing oxygen, and produces ATP and NADPH. In the Calvin cycle, discovered by Melvin Calvin and colleagues using radioactive carbon in the 1950s, in the stroma, ATP and NADPH power the fixing of carbon dioxide into sugars, catalyzed by the enzyme RuBisCO, probably the most abundant protein on Earth."]],
  ["Why photosynthesis matters",[
    "Photosynthesis produces the oxygen we breathe and the food at the base of nearly every food chain, and it removes carbon dioxide from the atmosphere. Fossil fuels are ancient photosynthesis stored underground. Cyanobacteria began oxygenic photosynthesis billions of years ago, causing the Great Oxidation Event around 2.4 billion years ago, which transformed Earth's atmosphere.",
    "Some plants in hot, dry climates use adaptations called C4 (such as corn and sugarcane) and CAM photosynthesis (such as cacti and pineapples) to conserve water and capture carbon more efficiently."]],
  ["Cellular respiration",[
    "Cellular respiration releases energy from glucose: C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + energy (ATP). It occurs in three main stages. Glycolysis, in the cytoplasm, splits glucose into two molecules of pyruvate, producing a small amount of ATP. The Krebs (citric acid) cycle, described by Hans Krebs in 1937, in the mitochondria, breaks down the products further, releasing carbon dioxide.",
    "The electron transport chain, on the inner mitochondrial membrane, uses electrons from earlier stages to pump protons, and the flow of protons back through the enzyme ATP synthase produces most of the ATP, about 30–32 molecules per glucose in total. Oxygen is the final electron acceptor, forming water. Peter Mitchell's chemiosmotic theory explaining this won the 1978 Nobel Prize."]],
  ["Anaerobic respiration and fermentation",[
    "When oxygen is scarce, cells can produce a little ATP by glycolysis alone, regenerating the molecules it needs through fermentation. In human muscles during intense exercise, pyruvate is converted to lactate, which contributes to fatigue. In yeast, fermentation produces ethanol and carbon dioxide, used to make bread rise and to brew beer and wine.",
    "Louis Pasteur showed in the 1850s–1860s that fermentation is carried out by living microorganisms. Anaerobic respiration yields far less energy than aerobic respiration, about 2 ATP per glucose instead of about 30."]],
  ["The global carbon cycle",[
    "Photosynthesis and respiration are central to the global carbon cycle. Plants and phytoplankton take up about 120 billion tonnes of carbon a year through photosynthesis, and respiration and decomposition return similar amounts. Burning fossil fuels and clearing forests add extra carbon dioxide, disrupting the balance.",
    "Scientists are studying ways to improve the efficiency of photosynthesis in crops to increase food production, and to mimic it in “artificial photosynthesis” to produce fuels from sunlight."]]
  ],
  terms:[["Photosynthesis","Converting light energy into sugar, releasing oxygen."],["Chlorophyll","The green pigment that absorbs light."],["Calvin cycle","The stage fixing carbon dioxide into sugars."],["RuBisCO","The enzyme that fixes carbon dioxide."],["Cellular respiration","Releasing energy from glucose as ATP."],["Krebs cycle","The citric acid cycle in mitochondria."],["Fermentation","Energy release without oxygen."]],
  w:"Photosynthesis and respiration capture and release the Sun's energy, powering nearly all life and driving the global carbon cycle.",
  src:["Photosynthesis","Chlorophyll","Calvin cycle","RuBisCO","Cellular respiration","Citric acid cycle","Fermentation"],
  q:[["What are the products of photosynthesis?","Glucose and oxygen","Carbon dioxide and water","ATP and carbon dioxide","Lactate and ethanol"],
     ["Why do plants look green?","Chlorophyll reflects green light","Chlorophyll absorbs green light","Cells contain green water","Sunlight is green"],
     ["What is probably the most abundant protein on Earth?","RuBisCO","Hemoglobin","Collagen","Keratin"],
     ["Where does the Krebs cycle occur?","In the mitochondria","In the chloroplast","In the nucleus","In the cytoplasm"],
     ["What does yeast fermentation produce?","Ethanol and carbon dioxide","Lactate","Oxygen","Glucose"],
     ["Who showed fermentation is carried out by microorganisms?","Louis Pasteur","Hans Krebs","Melvin Calvin","Robert Koch"]]}

]});


/* ---- from sci-11.js ---- */
/* SCIENCES FOUNDATIONS, part 11: Unit 6 Genetics and Evolution, chapters 1-5 */
COURSES.sciences.units.push({ t:"Biology: Genetics and Evolution", ch:[

{ t:"DNA: The Molecule of Heredity", s:"Discovering the double helix",
  sec:[
  ["Finding the genetic material",[
    "By the early 20th century, scientists knew that hereditary information was carried on chromosomes, but not whether genes were made of protein or DNA. In 1928 Frederick Griffith found that a harmless strain of pneumonia bacteria could be “transformed” into a deadly one by material from dead deadly bacteria. In 1944 Oswald Avery, Colin MacLeod, and Maclyn McCarty showed the transforming substance was DNA.",
    "In 1952 Alfred Hershey and Martha Chase confirmed it using viruses labeled with radioactive markers: only the viruses' DNA, not their protein, entered bacteria to direct the making of new viruses."]],
  ["The double helix",[
    "In 1953 James Watson and Francis Crick, at the University of Cambridge, proposed the double-helix structure of DNA, published in Nature in April. Their model relied crucially on X-ray diffraction images, especially “Photo 51,” made by Rosalind Franklin and her student Raymond Gosling at King's College London, shown to Watson without her knowledge, and on data from Franklin and Maurice Wilkins.",
    "Watson, Crick, and Wilkins received the 1962 Nobel Prize in Physiology or Medicine. Franklin had died of cancer in 1958, at 37, and Nobel Prizes are not awarded posthumously; her essential contribution is now widely recognized. Erwin Chargaff's finding that DNA contains equal amounts of A and T and of G and C (Chargaff's rules) was also key."]],
  ["Structure",[
    "DNA consists of two long strands twisted around each other like a spiral staircase. Each strand has a backbone of alternating sugar (deoxyribose) and phosphate groups, with bases projecting inward. The bases pair specifically: adenine with thymine (A-T) and guanine with cytosine (G-C), held together by hydrogen bonds; these are complementary base pairs.",
    "The strands run in opposite directions. Because of base pairing, the sequence of one strand determines the other. Watson and Crick noted, with famous understatement, that this “immediately suggests a possible copying mechanism for the genetic material.”"]],
  ["Replication",[
    "Before a cell divides, its DNA is copied. The double helix unwinds, and each strand serves as a template for a new complementary strand, built by the enzyme DNA polymerase. Each new DNA molecule has one old and one new strand, called semiconservative replication, demonstrated by Matthew Meselson and Franklin Stahl in 1958.",
    "DNA replication is remarkably accurate, with about one error per billion bases after proofreading and repair. Errors that remain are mutations."]],
  ["Genes, chromosomes, and genomes",[
    "A gene is a segment of DNA that carries instructions, usually for making a protein or a functional RNA. Genes are arranged along chromosomes, long DNA molecules wrapped around proteins called histones. Humans have 23 pairs of chromosomes, 46 in total, one set from each parent; one pair, the sex chromosomes, are XX in typical females and XY in typical males.",
    "The complete set of DNA is the genome. If stretched out, the DNA in one human cell would be about 2 meters long. The human genome contains about 3 billion base pairs and roughly 20,000 protein-coding genes, which make up only about 1–2 percent of the DNA; much of the rest regulates genes or has unclear function."]],
  ["Mutations",[
    "Mutations are changes in DNA sequence. They can be caused by copying errors, radiation, or chemicals called mutagens. Point mutations change a single base: in sickle cell disease, one base change alters one amino acid in hemoglobin, causing red blood cells to deform. Insertions and deletions can shift the reading frame, often with severe effects.",
    "Most mutations are neutral or harmful, but some are beneficial, providing the variation on which natural selection acts. Mutations in body cells can cause cancer; mutations in sperm or egg cells can be inherited."]]
  ],
  terms:[["Double helix","The twisted two-strand structure of DNA."],["Photo 51","Rosalind Franklin's X-ray image of DNA."],["Complementary base pairing","A pairs with T, G pairs with C."],["Semiconservative replication","Each new DNA has one old and one new strand."],["Gene","A DNA segment carrying instructions."],["Chromosome","A long DNA molecule packaged with proteins."],["Genome","An organism's complete DNA."],["Mutation","A change in DNA sequence."]],
  w:"The discovery of DNA's structure revealed how heredity works and launched modern biology, medicine, and biotechnology.",
  src:["DNA","Avery–MacLeod–McCarty experiment","Hershey–Chase experiment","Rosalind Franklin","Photo 51","DNA replication","Mutation"],
  q:[["Who showed in 1944 that DNA is the transforming substance?","Avery, MacLeod, and McCarty","Watson and Crick","Hershey and Chase","Griffith"],
     ["Whose X-ray image Photo 51 was key to the double helix?","Rosalind Franklin's","Maurice Wilkins's","Linus Pauling's","Erwin Chargaff's"],
     ["Which base pairs with adenine in DNA?","Thymine","Guanine","Cytosine","Uracil"],
     ["How many chromosomes do humans have?","46","23","48","44"],
     ["Who demonstrated semiconservative replication?","Meselson and Stahl","Watson and Crick","Hershey and Chase","Chargaff"],
     ["What does a single base change cause in sickle cell disease?","An altered amino acid in hemoglobin","Loss of a chromosome","Extra DNA","Viral infection"]]},

{ t:"From Gene to Protein", s:"The genetic code and gene expression",
  sec:[
  ["The central dogma",[
    "In 1958 Francis Crick described the central dogma of molecular biology: genetic information flows from DNA to RNA to protein. DNA is transcribed into messenger RNA (mRNA), which is translated into a chain of amino acids that folds into a protein.",
    "There are exceptions: retroviruses such as HIV use the enzyme reverse transcriptase to copy RNA into DNA, a discovery by Howard Temin and David Baltimore in 1970."]],
  ["Transcription",[
    "In transcription, which takes place in the nucleus in eukaryotes, the enzyme RNA polymerase reads one strand of a gene's DNA and builds a complementary strand of mRNA, using uracil in place of thymine.",
    "In eukaryotes, the initial RNA is edited: noncoding segments called introns are cut out and coding segments called exons spliced together. Alternative splicing allows one gene to produce several different proteins. The processed mRNA then travels out of the nucleus to the ribosomes."]],
  ["The genetic code",[
    "The genetic code is read in three-letter “words” called codons, each specifying one amino acid. With four bases, there are 64 possible codons for 20 amino acids, so most amino acids have several codons; AUG signals “start,” and three codons signal “stop.”",
    "Marshall Nirenberg and Heinrich Matthaei cracked the first codon in 1961 (UUU codes for phenylalanine), and the whole code was deciphered by 1966 by Nirenberg, Har Gobind Khorana, and others. The code is nearly universal across all life, strong evidence that all organisms share a common ancestor."]],
  ["Translation",[
    "In translation, ribosomes read the mRNA codon by codon. Transfer RNA (tRNA) molecules, each carrying a specific amino acid and having an anticodon that pairs with a codon, bring amino acids in the correct order, and the ribosome links them into a chain. When a stop codon is reached, the finished chain is released and folds into a protein.",
    "A typical protein of a few hundred amino acids is built in about a minute. Many antibiotics, such as tetracycline and streptomycin, work by blocking bacterial ribosomes."]],
  ["Gene regulation",[
    "Every cell in the body contains the same DNA, yet a nerve cell differs from a skin cell because different genes are switched on and off. Gene regulation controls when, where, and how much each gene is expressed.",
    "In 1961 François Jacob and Jacques Monod described the lac operon in bacteria, a set of genes switched on only when the sugar lactose is present. In eukaryotes, transcription factors, enhancers, and chemical modifications of DNA and histones regulate genes. Epigenetics studies such changes in gene activity that do not alter the DNA sequence and can sometimes be passed on to daughter cells."]],
  ["RNA's many roles",[
    "RNA does far more than carry messages. Ribosomal RNA forms the core of ribosomes and actually catalyzes the joining of amino acids, and small RNAs regulate genes; Andrew Fire and Craig Mello received the 2006 Nobel Prize for discovering RNA interference.",
    "Because RNA can both store information and catalyze reactions, many scientists think early life may have been based on RNA, the “RNA world” hypothesis. mRNA vaccines, such as those against COVID-19, deliver mRNA instructing cells to make a harmless viral protein that trains the immune system; Katalin Karikó and Drew Weissman received the 2023 Nobel Prize for the modifications that made them possible."]]
  ],
  terms:[["Central dogma","Information flows from DNA to RNA to protein."],["Transcription","Copying DNA into mRNA."],["Codon","A three-base unit specifying an amino acid."],["Translation","Building a protein from mRNA at ribosomes."],["tRNA","RNA that carries amino acids to the ribosome."],["Gene regulation","Control of when and how genes are expressed."],["Epigenetics","Changes in gene activity without DNA sequence change."]],
  w:"The flow of information from gene to protein explains how DNA builds living things and underlies modern medicine, from antibiotics to mRNA vaccines.",
  src:["Central dogma of molecular biology","Transcription (biology)","Genetic code","Translation (biology)","Lac operon","Epigenetics","MRNA vaccine"],
  q:[["Who described the central dogma?","Francis Crick","James Watson","Marshall Nirenberg","Jacques Monod"],
     ["What enzyme builds mRNA from DNA?","RNA polymerase","DNA polymerase","Reverse transcriptase","Ligase"],
     ["How many bases make up a codon?","Three","Two","Four","One"],
     ["Which codon signals start?","AUG","UUU","UAA","GGG"],
     ["Who described the lac operon?","Jacob and Monod","Watson and Crick","Temin and Baltimore","Fire and Mello"],
     ["Who won the 2023 Nobel Prize for work enabling mRNA vaccines?","Katalin Karikó and Drew Weissman","Jennifer Doudna and Emmanuelle Charpentier","Fire and Mello","Temin and Baltimore"]]},

{ t:"Cell Division", s:"Mitosis, meiosis, and cancer",
  sec:[
  ["The cell cycle",[
    "Cells reproduce by dividing. The cell cycle consists of interphase, when the cell grows and copies its DNA, and the mitotic phase, when it divides. Checkpoints monitor the cycle, ensuring DNA is copied correctly before division proceeds.",
    "Leland Hartwell, Tim Hunt, and Paul Nurse received the 2001 Nobel Prize for discovering key regulators of the cell cycle, such as cyclins and cyclin-dependent kinases."]],
  ["Mitosis",[
    "Mitosis divides a cell's nucleus into two identical nuclei, producing two genetically identical daughter cells. It is used for growth, repair, and asexual reproduction. Its stages are prophase, when chromosomes condense and become visible; metaphase, when they line up at the center; anaphase, when sister copies are pulled apart by spindle fibers; and telophase, when new nuclei form. Cytokinesis then splits the cytoplasm.",
    "Walther Flemming first described mitosis in the 1880s, naming it from the Greek for “thread.” The human body produces millions of new cells every second through mitosis."]],
  ["Meiosis",[
    "Meiosis is a special division that produces sex cells (gametes), sperm and eggs, with half the normal number of chromosomes, 23 in humans. When sperm and egg fuse at fertilization, the full number of 46 is restored.",
    "Meiosis involves two divisions and produces four genetically different cells. Variation arises from crossing over, in which paired chromosomes exchange segments, and independent assortment, the random distribution of maternal and paternal chromosomes, which alone can produce over 8 million combinations in humans. This shuffling explains why siblings differ."]],
  ["When division goes wrong",[
    "Errors in meiosis can produce gametes with extra or missing chromosomes. Down syndrome results from an extra copy of chromosome 21 (trisomy 21), first identified by Jérôme Lejeune and colleagues in 1959; its likelihood increases with maternal age.",
    "Other chromosomal conditions include Turner syndrome (a single X chromosome) and Klinefelter syndrome (XXY). A karyotype, an image of an individual's chromosomes arranged in pairs, can reveal such differences."]],
  ["Cancer",[
    "Cancer is uncontrolled cell division caused by mutations in genes that regulate the cell cycle. Oncogenes, mutated versions of growth-promoting genes, act like a stuck accelerator; tumor suppressor genes, such as p53, often called the “guardian of the genome,” act like brakes, and their loss removes control. Cancer usually requires several mutations to accumulate, which is why risk rises with age.",
    "Cancer cells can invade other tissues and spread through the body (metastasis). Risk factors include smoking, UV radiation, certain viruses such as HPV, and inherited mutations such as in the BRCA1 and BRCA2 genes. Treatments include surgery, chemotherapy, radiotherapy, targeted drugs, and immunotherapy."]],
  ["Aging and immortal cells",[
    "Leonard Hayflick discovered in 1961 that normal human cells can divide only a limited number of times, about 40–60, the Hayflick limit, partly because telomeres, protective caps at the ends of chromosomes, shorten with each division. Elizabeth Blackburn, Carol Greider, and Jack Szostak won the 2009 Nobel Prize for discovering how telomeres and the enzyme telomerase protect chromosomes.",
    "Cancer cells often reactivate telomerase and divide indefinitely. HeLa cells, taken without consent from Henrietta Lacks, an African American woman treated for cervical cancer in 1951, became the first immortal human cell line, contributing to countless discoveries, including the polio vaccine, and raising lasting questions about consent and research ethics."]]
  ],
  terms:[["Cell cycle","The sequence of growth, DNA copying, and division."],["Mitosis","Division producing two identical cells."],["Meiosis","Division producing four varied sex cells with half the chromosomes."],["Crossing over","Exchange of segments between paired chromosomes."],["Trisomy 21","An extra chromosome 21, causing Down syndrome."],["Oncogene and tumor suppressor","Genes whose mutation can cause cancer."],["Telomere","A protective cap at chromosome ends."]],
  w:"Cell division explains growth, reproduction, genetic variation, and cancer, connecting basic biology to human health.",
  src:["Cell cycle","Mitosis","Meiosis","Down syndrome","Cancer","Telomere","HeLa"],
  q:[["What does mitosis produce?","Two genetically identical cells","Four varied sex cells","One cell","Gametes"],
     ["How many chromosomes do human gametes have?","23","46","92","12"],
     ["What process exchanges segments between paired chromosomes?","Crossing over","Replication","Translation","Cytokinesis"],
     ["What causes Down syndrome?","An extra chromosome 21","A missing X chromosome","A single gene mutation","A virus"],
     ["Which gene is called the guardian of the genome?","p53","BRCA1","HER2","Ras"],
     ["Whose cells became the first immortal human cell line?","Henrietta Lacks","Rosalind Franklin","Leonard Hayflick","Elizabeth Blackburn"]]},

{ t:"Mendel and the Laws of Inheritance", s:"Dominant, recessive, and the Punnett square",
  sec:[
  ["Gregor Mendel",[
    "Gregor Mendel (1822–1884), an Augustinian friar in Brno, in present-day Czech Republic, discovered the basic laws of heredity by breeding about 28,000 pea plants between 1856 and 1863. He studied seven traits with two clear forms, such as tall versus short plants, purple versus white flowers, and round versus wrinkled seeds, and counted the offspring carefully.",
    "He published his results in 1866, but they were largely ignored until 1900, when three botanists, Hugo de Vries, Carl Correns, and Erich von Tschermak, independently rediscovered them. Mendel is now considered the father of genetics."]],
  ["Dominant and recessive",[
    "Mendel found that when he crossed purebred tall and short plants, all the offspring were tall; when these were crossed with each other, the next generation had a ratio of about 3 tall to 1 short. He concluded that each trait is controlled by a pair of “factors,” now called genes, one inherited from each parent, and that one form, the dominant allele, can mask the other, the recessive allele.",
    "Alleles are different versions of a gene. An organism with two identical alleles is homozygous; with two different alleles, heterozygous. The genotype is the genetic makeup (such as Tt); the phenotype is the observable trait (tall)."]],
  ["Mendel's laws",[
    "The law of segregation states that the two alleles for a trait separate when gametes form, so each gamete carries only one. The law of independent assortment states that alleles for different traits are inherited independently of each other, which holds for genes on different chromosomes.",
    "The Punnett square, devised by Reginald Punnett around 1905, predicts offspring ratios. Crossing two heterozygous parents (Tt × Tt) gives 1 TT : 2 Tt : 1 tt, a 3:1 ratio of dominant to recessive phenotypes."]],
  ["Human inheritance",[
    "Some human conditions follow simple Mendelian patterns. Cystic fibrosis and sickle cell disease are recessive: a child must inherit two copies of the faulty allele, so two unaffected carrier parents have a 1 in 4 chance of an affected child. Huntington's disease is dominant: one copy causes it. Carriers of one sickle cell allele have some protection against malaria, which explains why the allele is common in regions where malaria has been widespread.",
    "Pedigree charts trace traits through families to determine inheritance patterns."]],
  ["Beyond simple dominance",[
    "Many traits do not follow Mendel's simple patterns. In incomplete dominance, heterozygotes show an intermediate phenotype, as when red and white snapdragons produce pink offspring. In codominance, both alleles are expressed, as in the AB blood type; human ABO blood groups involve three alleles, A, B, and O.",
    "Most human traits, such as height, skin color, and intelligence, are polygenic, influenced by many genes as well as the environment, producing continuous variation."]],
  ["Sex-linked traits",[
    "Genes on the X chromosome show sex-linked inheritance. Because males have only one X chromosome, recessive X-linked conditions such as red-green color blindness and hemophilia are much more common in men. Hemophilia, a blood-clotting disorder, spread through European royal families from Queen Victoria, a carrier, affecting descendants in the Spanish and Russian royal families, including Tsarevich Alexei.",
    "Thomas Hunt Morgan, studying fruit flies at Columbia University from about 1910, demonstrated that genes are located on chromosomes and discovered sex linkage, for which he won the 1933 Nobel Prize. The fruit fly Drosophila melanogaster became a key model organism in genetics."]]
  ],
  terms:[["Allele","A version of a gene."],["Dominant and recessive","An allele that masks another vs. one that is masked."],["Genotype and phenotype","Genetic makeup vs. observable trait."],["Homozygous and heterozygous","Two identical vs. two different alleles."],["Punnett square","A grid predicting offspring ratios."],["Codominance","Both alleles fully expressed."],["Sex-linked trait","A trait determined by a gene on a sex chromosome."]],
  w:"Mendel's laws explain how traits pass from parents to children, the basis for understanding inherited diseases, breeding, and evolution.",
  src:["Gregor Mendel","Mendelian inheritance","Dominance (genetics)","Punnett square","Cystic fibrosis","Hemophilia in European royalty","Thomas Hunt Morgan"],
  q:[["What plants did Mendel study?","Peas","Beans","Corn","Snapdragons"],
     ["What ratio did Mendel find in the second generation?","3 to 1","1 to 1","2 to 1","9 to 1"],
     ["What is an organism with two different alleles called?","Heterozygous","Homozygous","Dominant","Recessive"],
     ["Which human blood type shows codominance?","AB","O","A","B"],
     ["Why is color blindness more common in men?","It is X-linked and men have one X","Men have more cones","It is dominant","It is caused by a virus"],
     ["Who showed genes are on chromosomes using fruit flies?","Thomas Hunt Morgan","Gregor Mendel","Hugo de Vries","Reginald Punnett"]]},

{ t:"Genomics and Biotechnology", s:"Reading, copying, and editing DNA",
  sec:[
  ["Recombinant DNA",[
    "In the early 1970s, scientists learned to cut and paste DNA. Restriction enzymes, bacterial proteins that cut DNA at specific sequences, discovered by Werner Arber, Hamilton Smith, and Daniel Nathans, act as molecular scissors, and ligases glue fragments together. In 1973 Stanley Cohen and Herbert Boyer inserted foreign DNA into bacteria, creating the first genetically engineered organisms.",
    "In 1978 Genentech used engineered bacteria to produce human insulin, approved in 1982, replacing insulin from pigs and cattle. Many medicines, including growth hormone and clotting factors, are now made this way."]],
  ["PCR and sequencing",[
    "The polymerase chain reaction (PCR), invented by Kary Mullis in 1983, copies a specific DNA segment billions of times in a few hours by repeated cycles of heating and cooling, using heat-stable Taq polymerase. PCR revolutionized research, forensics, and diagnostics, including COVID-19 tests.",
    "Frederick Sanger developed a method to read DNA sequences in 1977, earning his second Nobel Prize. Next-generation sequencing technologies have since reduced the cost of sequencing a human genome from billions of dollars to a few hundred."]],
  ["The Human Genome Project",[
    "The Human Genome Project, an international effort launched in 1990, aimed to read all 3 billion bases of human DNA. A draft was announced in 2000–2001 and declared essentially complete in 2003, at a cost of about 3 billion dollars; a fully gapless sequence was published in 2022.",
    "It revealed that humans have far fewer genes than expected, about 20,000, and that any two people's DNA is about 99.9 percent identical. Genomics now allows personalized medicine, ancestry testing, and the study of human migration and evolution, including the discovery that many people carry DNA from Neanderthals."]],
  ["DNA fingerprinting and forensics",[
    "In 1984 Alec Jeffreys at the University of Leicester discovered that certain repetitive DNA regions vary greatly between individuals, enabling DNA fingerprinting. It was first used to convict a murderer, Colin Pitchfork, in 1988, after it exonerated an innocent suspect.",
    "DNA evidence has identified criminals, victims of disasters, and remains such as those of the Romanov family and Richard III, whose skeleton was found under a parking lot in Leicester in 2012. The Innocence Project has used DNA testing to exonerate hundreds of wrongly convicted people in the United States."]],
  ["CRISPR",[
    "CRISPR-Cas9, adapted from a bacterial immune system that cuts viral DNA, allows scientists to edit genes precisely, cheaply, and easily. Jennifer Doudna and Emmanuelle Charpentier, who published the key paper in 2012, received the 2020 Nobel Prize in Chemistry.",
    "CRISPR is used in research, agriculture, and medicine; in 2023 the first CRISPR-based therapy, Casgevy, was approved to treat sickle cell disease. In 2018 the Chinese scientist He Jiankui announced he had edited the genes of twin girls as embryos, provoking worldwide condemnation and a prison sentence, and intensifying debate about editing heritable human DNA."]],
  ["GMOs and cloning",[
    "Genetically modified (GM) crops, such as insect-resistant corn and herbicide-tolerant soybeans, have been widely grown since the 1990s, especially in the Americas. Golden Rice is engineered to produce beta-carotene to combat vitamin A deficiency. Major scientific bodies have concluded that approved GM foods are as safe to eat as conventional foods, though debates continue over ecology, corporate control, and labeling.",
    "In 1996 Ian Wilmut and colleagues at the Roslin Institute in Scotland cloned Dolly the sheep from an adult cell, the first mammal cloned this way. In 2006 Shinya Yamanaka showed that adult cells can be reprogrammed into stem cells (induced pluripotent stem cells), for which he shared the 2012 Nobel Prize."]]
  ],
  terms:[["Restriction enzyme","An enzyme cutting DNA at specific sequences."],["Recombinant DNA","DNA combined from different sources."],["PCR","A technique for copying DNA billions of times."],["Human Genome Project","The project to sequence human DNA, completed in 2003."],["DNA fingerprinting","Identifying individuals by DNA variation."],["CRISPR","A precise gene-editing tool."],["GMO","A genetically modified organism."]],
  w:"Biotechnology lets scientists read, copy, and edit DNA, transforming medicine, agriculture, forensics, and raising profound ethical questions.",
  src:["Recombinant DNA","Polymerase chain reaction","Human Genome Project","DNA profiling","CRISPR gene editing","Genetically modified food","Dolly (sheep)"],
  q:[["Who inserted foreign DNA into bacteria in 1973?","Cohen and Boyer","Watson and Crick","Doudna and Charpentier","Mullis and Sanger"],
     ["Who invented PCR?","Kary Mullis","Frederick Sanger","Alec Jeffreys","Herbert Boyer"],
     ["When was the Human Genome Project declared essentially complete?","2003","1990","2010","2022"],
     ["Who discovered DNA fingerprinting?","Alec Jeffreys","Kary Mullis","James Watson","Craig Venter"],
     ["Who won the 2020 Nobel Prize for CRISPR?","Doudna and Charpentier","Yamanaka and Gurdon","Karikó and Weissman","Mullis and Smith"],
     ["What was the first mammal cloned from an adult cell?","Dolly the sheep","A mouse","A frog","A cow"]]}

]});


/* ---- from sci-12.js ---- */
/* SCIENCES FOUNDATIONS, part 12: Unit 6 chapters 6-9 (Evolution) */
COURSES.sciences.units[5].ch.push(

{ t:"Darwin and Natural Selection", s:"The theory that unifies biology",
  sec:[
  ["Before Darwin",[
    "For centuries most Europeans believed species were fixed and separately created. In the late 18th and early 19th centuries, naturalists began to question this. Georges Cuvier established that species had gone extinct, from fossils such as mammoths. Jean-Baptiste Lamarck proposed in 1809 that species change over time, though he believed, wrongly, that organisms pass on characteristics acquired during their lives, such as giraffes stretching their necks.",
    "Geologists such as Charles Lyell showed that the Earth was very old, providing time for gradual change, and Thomas Malthus's essay on population, describing competition for limited resources, inspired both Darwin and Wallace."]],
  ["The voyage of the Beagle",[
    "Charles Darwin (1809–1882) sailed as a naturalist aboard HMS Beagle on a five-year voyage around the world (1831–1836). In South America he found fossils of giant extinct mammals resembling living species, and on the Galápagos Islands he observed that finches, mockingbirds, and tortoises varied from island to island.",
    "Back in England, Darwin developed his theory over two decades. In 1858 he received a letter from Alfred Russel Wallace, working in the Malay Archipelago, describing the same idea. Their papers were presented jointly to the Linnean Society, and in 1859 Darwin published On the Origin of Species."]],
  ["Natural selection",[
    "Darwin's theory of evolution by natural selection rests on observations: individuals in a population vary; much of this variation is inherited; more offspring are born than can survive; and those with traits better suited to their environment are more likely to survive and reproduce, passing on those traits. Over many generations, advantageous traits become more common and populations change, adapting to their environments.",
    "Darwin called this “descent with modification” and argued that all life shares common ancestors, forming a branching tree. The phrase “survival of the fittest” was coined by Herbert Spencer; “fitness” means reproductive success, not strength."]],
  ["Artificial and sexual selection",[
    "Darwin drew on artificial selection, the breeding of domesticated animals and plants: humans bred dogs from wolves into breeds as different as Chihuahuas and Great Danes, and wild mustard into cabbage, broccoli, kale, and cauliflower.",
    "He also proposed sexual selection, in which traits evolve because they help attract mates or compete for them, explaining features such as the peacock's tail and deer antlers, which may reduce survival but increase reproductive success."]],
  ["The modern synthesis",[
    "Darwin did not know how inheritance worked. In the 1930s–1940s, the modern evolutionary synthesis combined natural selection with Mendelian genetics and population genetics, through the work of Ronald Fisher, J. B. S. Haldane, Sewall Wright, Theodosius Dobzhansky, and Ernst Mayr. Evolution came to be defined as change in the frequency of alleles in a population over generations.",
    "Mechanisms of evolution include natural selection, mutation, gene flow (migration), and genetic drift, random changes in allele frequencies that are especially strong in small populations. Dobzhansky wrote in 1973 that “nothing in biology makes sense except in the light of evolution.”"]],
  ["Evolution in action",[
    "Evolution can be observed directly. Peter and Rosemary Grant documented changes in the beak size of Galápagos finches during droughts over decades. The peppered moth in England became mostly dark during the Industrial Revolution as soot darkened trees, then pale again as air cleaned up.",
    "Bacteria evolve resistance to antibiotics, insects to pesticides, and viruses such as influenza and SARS-CoV-2 continually evolve new variants. Richard Lenski's long-term experiment with E. coli, begun in 1988 and running over 75,000 generations, has observed bacteria evolving new abilities, including using citrate as food."]]
  ],
  terms:[["Natural selection","Differential survival and reproduction of individuals with advantageous traits."],["Adaptation","A trait that improves survival or reproduction."],["Descent with modification","Darwin's term for evolution from common ancestors."],["Fitness","Reproductive success."],["Sexual selection","Evolution of traits that help in mating."],["Modern synthesis","The union of natural selection and genetics."],["Genetic drift","Random change in allele frequencies."]],
  w:"Evolution by natural selection explains the diversity and adaptation of life and is the unifying theory of all biology.",
  src:["Charles Darwin","Second voyage of HMS Beagle","On the Origin of Species","Natural selection","Alfred Russel Wallace","Modern synthesis (20th century)","Peppered moth evolution"],
  q:[["Who proposed that organisms inherit acquired characteristics?","Jean-Baptiste Lamarck","Charles Darwin","Alfred Russel Wallace","Georges Cuvier"],
     ["On which ship did Darwin voyage?","HMS Beagle","HMS Endeavour","HMS Bounty","HMS Victory"],
     ["Who independently developed natural selection with Darwin?","Alfred Russel Wallace","Charles Lyell","Thomas Malthus","Gregor Mendel"],
     ["When was On the Origin of Species published?","1859","1831","1871","1900"],
     ["Who coined survival of the fittest?","Herbert Spencer","Charles Darwin","Thomas Huxley","Francis Galton"],
     ["Who wrote that nothing in biology makes sense except in the light of evolution?","Theodosius Dobzhansky","Ernst Mayr","Richard Dawkins","Stephen Jay Gould"]]},

{ t:"The Evidence for Evolution", s:"Fossils, anatomy, DNA, and biogeography",
  sec:[
  ["The fossil record",[
    "Fossils, the preserved remains or traces of ancient organisms, mostly in sedimentary rock, document the history of life. Older layers contain simpler organisms, and the order of appearance matches evolutionary predictions: fish before amphibians, amphibians before reptiles, reptiles before mammals and birds.",
    "Transitional fossils show intermediate forms. Archaeopteryx, discovered in Germany in 1861, just two years after the Origin, combines bird features (feathers, wings) with reptile features (teeth, a bony tail, clawed fingers). Tiktaalik, found in the Canadian Arctic in 2004 after scientists predicted where to look, is a fish with features of land animals, such as a neck and sturdy fins. Fossil whales such as Ambulocetus show the transition from land mammals to whales."]],
  ["Comparative anatomy",[
    "Homologous structures are similar in structure but may differ in function because they were inherited from a common ancestor. The forelimbs of humans, cats, whales, and bats all contain the same bones, the humerus, radius, ulna, and hand bones, adapted for grasping, walking, swimming, and flying.",
    "Vestigial structures are remnants of features that were functional in ancestors, such as the tiny pelvic bones in whales and snakes, wisdom teeth, and the human tailbone. Analogous structures, such as the wings of birds and insects, have similar functions but evolved independently, an example of convergent evolution."]],
  ["Embryology",[
    "Embryos of different vertebrates look strikingly similar in early stages, with features such as pharyngeal arches (gill slits in fish) and tails, reflecting shared ancestry.",
    "Developmental genes, such as the Hox genes, which control body plans, are shared across animals as different as flies and humans, showing deep common ancestry; this field, evolutionary developmental biology (evo-devo), has transformed understanding of how body forms evolve."]],
  ["Molecular evidence",[
    "DNA provides powerful evidence for evolution. All life uses the same genetic code and many of the same genes. Closely related species share more DNA: human and chimpanzee genomes are about 98–99 percent identical in comparable sequences. Comparing DNA sequences allows scientists to build family trees of life (phylogenies) that match those based on fossils and anatomy.",
    "Shared “mistakes” in DNA, such as broken genes and the remnants of ancient viral infections, appear in the same places in related species, which is hard to explain except by common descent. Humans, for example, share with other primates a broken gene for making vitamin C, which is why we must obtain it from food."]],
  ["Biogeography",[
    "The geographic distribution of species supports evolution. Islands often have unique species descended from mainland colonists, such as Darwin's finches and the honeycreepers of Hawaii. Australia's marsupials evolved in isolation after the continent separated from others, filling niches occupied elsewhere by placental mammals.",
    "Plate tectonics explains why related fossils and species are found on continents now far apart, such as the fossil reptile Mesosaurus in both South America and Africa."]],
  ["Evolution and society",[
    "The theory of evolution is supported by overwhelming evidence and accepted by virtually all biologists and major scientific organizations. It has been controversial for some religious groups; the 1925 Scopes “Monkey Trial” in Tennessee, where a teacher was tried for teaching evolution, became a famous clash, and debates over teaching evolution have continued.",
    "Many religious believers and organizations accept evolution, and the Catholic Church has said evolution is compatible with faith. Evolution has practical importance in medicine, agriculture, conservation, and understanding antibiotic resistance."]]
  ],
  terms:[["Fossil","Preserved remains or traces of ancient life."],["Transitional fossil","A fossil showing intermediate features."],["Homologous structures","Similar structures inherited from a common ancestor."],["Vestigial structure","A reduced remnant of an ancestral feature."],["Convergent evolution","Independent evolution of similar traits."],["Phylogeny","An evolutionary family tree."],["Hox genes","Genes controlling animal body plans."]],
  w:"Evidence from fossils, anatomy, embryos, DNA, and geography converges to show that all life shares common ancestry.",
  src:["Evidence of common descent","Transitional fossil","Archaeopteryx","Tiktaalik","Homology (biology)","Vestigiality","Scopes trial"],
  q:[["Which fossil combines bird and reptile features?","Archaeopteryx","Tiktaalik","Ambulocetus","Lucy"],
     ["Which fossil fish with land-animal features was found in 2004?","Tiktaalik","Coelacanth","Archaeopteryx","Mesosaurus"],
     ["What are similar structures from a common ancestor called?","Homologous","Analogous","Vestigial","Convergent"],
     ["What are bird and insect wings an example of?","Convergent evolution","Homology","Vestigial structures","Common ancestry of wings"],
     ["About how identical are human and chimpanzee genomes in comparable sequences?","98–99 percent","50 percent","75 percent","100 percent"],
     ["Where was the 1925 Scopes trial held?","Tennessee","Kentucky","Ohio","Texas"]]},

{ t:"The History of Life", s:"From the first cells to the age of mammals",
  sec:[
  ["The origin of life",[
    "Earth formed about 4.54 billion years ago, and the oldest widely accepted evidence of life, fossilized microbial mats called stromatolites, dates to about 3.5 billion years ago, with chemical hints possibly older. How life began, abiogenesis, remains one of science's great unsolved questions.",
    "In 1953 Stanley Miller and Harold Urey simulated early Earth conditions in a flask, passing sparks through gases, and produced amino acids, showing that life's building blocks can form naturally. Hypotheses about life's origin focus on deep-sea hydrothermal vents, shallow pools, and an early “RNA world.”"]],
  ["Microbes rule",[
    "For about the first 2 billion years, life consisted only of single-celled prokaryotes. Photosynthetic cyanobacteria gradually filled the atmosphere with oxygen in the Great Oxidation Event, about 2.4 billion years ago. Complex eukaryotic cells appeared around 2 billion years ago, likely through endosymbiosis, and multicellular life emerged later.",
    "The Ediacaran biota, strange soft-bodied organisms around 575–539 million years ago, are among the earliest complex animals."]],
  ["The Cambrian explosion",[
    "Beginning about 539 million years ago, the Cambrian explosion saw the rapid appearance of most major animal groups, with hard shells, eyes, and complex bodies, over some 20 million years. The Burgess Shale in Canada, discovered by Charles Walcott in 1909, preserves remarkable Cambrian creatures such as the five-eyed Opabinia and the predator Anomalocaris.",
    "Plants colonized land around 470 million years ago, followed by arthropods and, around 375 million years ago, the first four-legged vertebrates (tetrapods)."]],
  ["Mass extinctions",[
    "Life's history has been punctuated by five major mass extinctions. The largest, the end-Permian extinction about 252 million years ago, known as the Great Dying, wiped out about 90 percent of marine species, probably caused by massive volcanic eruptions in Siberia that caused extreme global warming and ocean acidification.",
    "The end-Cretaceous extinction, about 66 million years ago, killed the non-avian dinosaurs and about three-quarters of species. In 1980 Luis and Walter Alvarez proposed an asteroid impact, based on a worldwide layer rich in iridium; the Chicxulub crater, about 180 kilometers wide, under Mexico's Yucatán Peninsula, was identified in 1991."]],
  ["The age of dinosaurs",[
    "Dinosaurs dominated land during the Mesozoic Era, from about 230 to 66 million years ago, in the Triassic, Jurassic, and Cretaceous periods. They ranged from small feathered predators to giant long-necked sauropods such as Argentinosaurus, among the largest land animals ever. Tyrannosaurus rex lived at the very end of the Cretaceous.",
    "Birds are living dinosaurs, descended from small feathered theropods; many dinosaur fossils from China since the 1990s show feathers. Mammals appeared around the same time as dinosaurs but remained mostly small until the dinosaurs' extinction."]],
  ["The age of mammals",[
    "After the end-Cretaceous extinction, mammals diversified rapidly in the Cenozoic Era, filling niches left by dinosaurs, evolving into whales, bats, horses, elephants, and primates. Grasslands spread, and climate cooled, culminating in the ice ages of the last 2.6 million years.",
    "Today many scientists warn that human activity, through habitat destruction, overexploitation, pollution, invasive species, and climate change, is causing a sixth mass extinction. Studying the history of life shows both life's resilience and how dramatically environmental change can reshape it."]]
  ],
  terms:[["Abiogenesis","The origin of life from non-living matter."],["Stromatolite","Layered structures formed by microbial mats."],["Miller-Urey experiment","The 1953 synthesis of amino acids in simulated early conditions."],["Cambrian explosion","The rapid appearance of animal groups about 539 million years ago."],["Mass extinction","A rapid loss of a large share of species."],["Chicxulub crater","The impact crater linked to the dinosaurs' extinction."],["Cenozoic","The age of mammals, the last 66 million years."]],
  w:"The history of life reveals billions of years of evolution, catastrophe, and recovery, putting our own species and today's extinction crisis in perspective.",
  src:["Timeline of the evolutionary history of life","Miller–Urey experiment","Great Oxidation Event","Cambrian explosion","Permian–Triassic extinction event","Cretaceous–Paleogene extinction event","Dinosaur"],
  q:[["How old is the oldest widely accepted evidence of life?","About 3.5 billion years","About 500 million years","About 4.5 billion years","About 1 billion years"],
     ["What did the Miller-Urey experiment produce?","Amino acids","Living cells","DNA","Bacteria"],
     ["Which fossil site preserves Cambrian creatures in Canada?","The Burgess Shale","Ediacara","Solnhofen","La Brea"],
     ["What was the largest mass extinction?","The end-Permian","The end-Cretaceous","The end-Triassic","The Ordovician"],
     ["Who proposed the asteroid impact theory for the dinosaurs?","Luis and Walter Alvarez","Charles Walcott","Stephen Jay Gould","Georges Cuvier"],
     ["Which living animals are descended from dinosaurs?","Birds","Crocodiles","Lizards","Mammals"]]},

{ t:"Human Evolution", s:"Our place in the primate family",
  sec:[
  ["Primates",[
    "Humans are primates, a group of mammals that includes lemurs, monkeys, and apes, characterized by grasping hands, forward-facing eyes with depth perception, and large brains. Our closest living relatives are chimpanzees and bonobos, followed by gorillas and orangutans; DNA evidence suggests the human and chimpanzee lineages split roughly 6–7 million years ago.",
    "Humans did not evolve from chimpanzees; both evolved from a common ancestor. Humans and our extinct relatives since the split are called hominins."]],
  ["Walking upright",[
    "One of the earliest key changes was bipedalism, walking on two legs, which freed the hands. Early hominins include Sahelanthropus (about 7 million years ago) and Ardipithecus. The australopithecines, living about 4 to 2 million years ago in Africa, walked upright but had small, ape-sized brains.",
    "The most famous is “Lucy,” a 3.2-million-year-old partial skeleton of Australopithecus afarensis found in Ethiopia in 1974 by Donald Johanson's team, named after the Beatles song “Lucy in the Sky with Diamonds.” Footprints at Laetoli in Tanzania, about 3.66 million years old, discovered by Mary Leakey's team, show bipedal walking."]],
  ["The genus Homo",[
    "Our genus, Homo, appeared about 2.8–2.4 million years ago. Homo habilis (“handy man”), named by Louis Leakey and colleagues in 1964, was associated with early stone tools. Homo erectus, from about 1.9 million years ago, had a larger brain and body proportions like ours, used fire, made sophisticated hand axes, and was the first hominin to spread out of Africa, reaching as far as Java and China.",
    "The Turkana Boy, a nearly complete Homo erectus skeleton found in Kenya in 1984, is one of the most complete early human fossils."]],
  ["Our cousins",[
    "Several human species coexisted. Neanderthals (Homo neanderthalensis) lived in Europe and western Asia from about 400,000 to 40,000 years ago; they were strong, had large brains, made tools, buried their dead, and likely made art. Denisovans, known mainly from DNA extracted from a finger bone found in a Siberian cave in 2008, lived in Asia.",
    "Small species also existed, such as Homo floresiensis, nicknamed the “hobbit,” on the Indonesian island of Flores, about 1 meter tall. Svante Pääbo sequenced the Neanderthal genome, published in 2010, and received the 2022 Nobel Prize; it revealed that people of non-African descent carry about 1–2 percent Neanderthal DNA from interbreeding."]],
  ["Homo sapiens",[
    "Our species, Homo sapiens, evolved in Africa; the oldest known fossils, from Jebel Irhoud in Morocco, are about 300,000 years old. Modern humans spread out of Africa in a major migration roughly 60,000–70,000 years ago, reaching Australia by about 50,000–65,000 years ago, Europe by about 45,000 years ago, and the Americas by at least 15,000–20,000 years ago, crossing from Siberia via Beringia.",
    "The “Out of Africa” model is supported by fossils and genetics: genetic diversity is greatest in Africa, and all living humans share recent African ancestry. Mitochondrial DNA traces back to a common female ancestor in Africa, sometimes called “Mitochondrial Eve.”"]],
  ["What makes us human",[
    "Distinctive human traits evolved gradually: bipedalism, tool use, control of fire, larger brains (about three times the size of a chimpanzee's), language, symbolic thought, art, and complex culture. Cave paintings, carved figurines, and ornaments from at least 40,000 years ago show sophisticated symbolic behavior.",
    "Human biological variation is small: there is more genetic variation within any population than between populations, and the traditional concept of distinct biological races does not reflect human genetic diversity. Humans continue to evolve; for example, the ability to digest milk into adulthood (lactase persistence) spread in dairying populations over the last 10,000 years."]]
  ],
  terms:[["Primate","The mammal group including lemurs, monkeys, apes, and humans."],["Hominin","Humans and their extinct relatives since the split from chimpanzees."],["Bipedalism","Walking on two legs."],["Lucy","A 3.2-million-year-old Australopithecus skeleton."],["Homo erectus","The first hominin to spread out of Africa."],["Neanderthal","An extinct human species of Europe and western Asia."],["Out of Africa","The model of modern human origins in Africa."]],
  w:"Human evolution reveals our deep connection to other primates, our African origins, and how recent and shared our common ancestry is.",
  src:["Human evolution","Hominini","Lucy (Australopithecus)","Homo erectus","Neanderthal","Denisovan","Recent African origin of modern humans"],
  q:[["Roughly when did human and chimpanzee lineages split?","6–7 million years ago","1 million years ago","20 million years ago","300,000 years ago"],
     ["Where was Lucy found?","Ethiopia","Kenya","Tanzania","South Africa"],
     ["Which hominin first spread out of Africa?","Homo erectus","Homo habilis","Australopithecus","Homo floresiensis"],
     ["Who sequenced the Neanderthal genome?","Svante Pääbo","Louis Leakey","Donald Johanson","Mary Leakey"],
     ["Where are the oldest known Homo sapiens fossils?","Jebel Irhoud, Morocco","Olduvai Gorge","Laetoli","Java"],
     ["About how much Neanderthal DNA do people of non-African descent carry?","1–2 percent","20 percent","50 percent","None"]]}

);


/* ---- from sci-13.js ---- */
/* SCIENCES FOUNDATIONS, part 13: Unit 7 The Diversity of Life, chapters 1-4 */
COURSES.sciences.units.push({ t:"Biology: The Diversity of Life", ch:[

{ t:"Classifying Life", s:"Taxonomy and the tree of life",
  sec:[
  ["Linnaeus",[
    "Scientists have described about 2 million species, and many millions more likely remain undiscovered. To organize this diversity, the Swedish botanist Carl Linnaeus (1707–1778) devised a system of classification in Systema Naturae (1735) and introduced binomial nomenclature, giving each species a two-part Latin name: the genus and species, such as Homo sapiens (“wise man”) for humans and Panthera leo for lions.",
    "Scientific names are written in italics with the genus capitalized, and they allow scientists worldwide to refer to species unambiguously, whatever their common names."]],
  ["The hierarchy",[
    "Linnaeus grouped organisms in a hierarchy of increasingly specific ranks. Today the main ranks are domain, kingdom, phylum, class, order, family, genus, and species, remembered by mnemonics such as “Dear King Philip Came Over For Good Soup.”",
    "Humans, for example, belong to domain Eukarya, kingdom Animalia, phylum Chordata, class Mammalia, order Primates, family Hominidae, genus Homo, and species sapiens."]],
  ["What is a species?",[
    "The most common definition, the biological species concept championed by Ernst Mayr, defines a species as a group of organisms that can interbreed in nature and produce fertile offspring. Horses and donkeys can produce mules, but mules are almost always sterile, so horses and donkeys are separate species.",
    "The definition is hard to apply to organisms that reproduce asexually, such as bacteria, or to fossils, so biologists also use other criteria, such as physical features and DNA. New species form through speciation, often when populations are geographically separated and diverge."]],
  ["Three domains",[
    "In 1977 the American microbiologist Carl Woese, comparing ribosomal RNA sequences, discovered that prokaryotes include two fundamentally different groups. In 1990 he proposed dividing all life into three domains: Bacteria, Archaea, and Eukarya.",
    "Archaea, though resembling bacteria under a microscope, are genetically and biochemically distinct, and in some ways closer to eukaryotes; many live in extreme environments. Eukarya includes all organisms with nucleated cells: animals, plants, fungi, and protists."]],
  ["Cladistics",[
    "Modern classification aims to reflect evolutionary relationships. Cladistics, developed by the German entomologist Willi Hennig, groups organisms into clades, groups consisting of an ancestor and all its descendants, based on shared derived characteristics. Relationships are shown in branching diagrams called cladograms or phylogenetic trees.",
    "Cladistics has changed some traditional groupings: because birds descend from dinosaurs, birds are considered a group within reptiles in a cladistic sense, and fish are not a single natural group, since land vertebrates descend from lobe-finned fish."]],
  ["Discovering new species",[
    "Thousands of new species are described each year, mostly insects, but also mammals, such as the saola, a forest ox discovered in Vietnam and Laos in 1992, and the olinguito, a raccoon relative from the Andes described in 2013. DNA barcoding, using short genetic sequences, helps identify species rapidly.",
    "Many species may go extinct before they are ever described, making taxonomy an urgent science for conservation."]]
  ],
  terms:[["Taxonomy","The science of naming and classifying organisms."],["Binomial nomenclature","Two-part scientific names."],["Species","Organisms that can interbreed and produce fertile offspring."],["Three domains","Bacteria, Archaea, and Eukarya."],["Clade","An ancestor and all its descendants."],["Cladogram","A branching diagram of relationships."],["Speciation","The formation of new species."]],
  w:"Classification organizes the immense diversity of life and, through the tree of life, reveals how all organisms are related.",
  src:["Taxonomy (biology)","Carl Linnaeus","Binomial nomenclature","Species","Three-domain system","Carl Woese","Cladistics"],
  q:[["Who introduced binomial nomenclature?","Carl Linnaeus","Charles Darwin","Carl Woese","Ernst Mayr"],
     ["What is the scientific name of humans?","Homo sapiens","Homo erectus","Panthera leo","Homo habilis"],
     ["Which rank is directly above genus?","Family","Order","Species","Class"],
     ["Who proposed the three-domain system?","Carl Woese","Lynn Margulis","Linnaeus","Willi Hennig"],
     ["Why are horses and donkeys separate species?","Their offspring, mules, are usually sterile","They look different","They live in different places","They eat different food"],
     ["What is a group of an ancestor and all its descendants called?","A clade","A kingdom","A phylum","A domain"]]},

{ t:"Bacteria and Archaea", s:"The microbial majority",
  sec:[
  ["Everywhere",[
    "Bacteria and archaea are single-celled prokaryotes, the oldest and most abundant forms of life. They live everywhere: in soil, water, air, ice, hot springs, deep rock kilometers underground, and inside other organisms. A gram of soil can contain billions of bacteria.",
    "Bacteria come in shapes such as spheres (cocci), rods (bacilli), and spirals (spirilla). Many move with whip-like flagella. They reproduce rapidly by binary fission, splitting in two; under ideal conditions, E. coli can divide every 20 minutes."]],
  ["Extremophiles",[
    "Many archaea are extremophiles, thriving in conditions lethal to most life: in boiling hot springs and deep-sea vents (thermophiles), some above 120°C; in extremely salty lakes (halophiles); and in highly acidic or alkaline environments. Methanogens produce methane in swamps and the guts of cattle.",
    "Extremophiles expand our ideas about where life might exist on other worlds and provide heat-stable enzymes for industry."]],
  ["Essential roles",[
    "Bacteria are essential to life on Earth. Decomposers break down dead organisms, recycling nutrients. Nitrogen-fixing bacteria, some living in nodules on the roots of legumes such as peas and beans, convert nitrogen gas from the air into forms plants can use. Cyanobacteria produce oxygen through photosynthesis.",
    "Humans use bacteria to make yogurt, cheese, sauerkraut, and vinegar, to treat sewage, to clean oil spills, and, through genetic engineering, to produce medicines such as insulin."]],
  ["The microbiome",[
    "The human body hosts trillions of microbes, mostly in the gut, collectively called the microbiome. Gut bacteria help digest food, produce vitamins such as vitamin K, train the immune system, and protect against harmful microbes.",
    "Research since the 2000s suggests the microbiome influences health in many ways, possibly including obesity, allergies, and even mood. Antibiotics can disrupt it; fecal microbiota transplants are used to treat severe Clostridioides difficile infections."]],
  ["Disease and germ theory",[
    "Some bacteria cause disease (pathogens), such as tuberculosis, cholera, plague, typhoid, syphilis, strep throat, and pneumonia. The germ theory of disease, established in the 1860s–1880s by Louis Pasteur and Robert Koch, showed that specific microbes cause specific diseases, overturning the miasma theory that diseases came from bad air.",
    "Koch identified the bacteria causing anthrax (1876), tuberculosis (1882), and cholera (1883), and his postulates set criteria for linking a microbe to a disease. Pasteur developed pasteurization, heating liquids to kill microbes, and vaccines against anthrax and rabies."]],
  ["Antibiotics and resistance",[
    "Antibiotics kill bacteria or stop their growth. Alexander Fleming discovered penicillin in 1928 when mold contaminated a bacterial culture; Howard Florey and Ernst Chain developed it into a mass-produced drug during World War II. Antibiotics have saved hundreds of millions of lives.",
    "Overuse and misuse of antibiotics, in medicine and livestock farming, have driven the evolution of resistant bacteria, such as MRSA. Antimicrobial resistance was associated with an estimated 4.95 million deaths in 2019, and experts warn it could make routine infections deadly again. Antibiotics do not work against viruses."]]
  ],
  terms:[["Prokaryote","A single-celled organism without a nucleus."],["Binary fission","Reproduction by splitting in two."],["Extremophile","An organism thriving in extreme conditions."],["Nitrogen fixation","Converting atmospheric nitrogen into usable forms."],["Microbiome","The community of microbes living in and on a body."],["Germ theory","Specific microbes cause specific diseases."],["Antibiotic resistance","Bacteria evolving to survive antibiotics."]],
  w:"Bacteria and archaea dominate life on Earth, sustaining ecosystems and our bodies, while pathogens and antibiotic resistance remain major health challenges.",
  src:["Bacteria","Archaea","Extremophile","Nitrogen fixation","Human microbiome","Germ theory of disease","Antimicrobial resistance"],
  q:[["How do bacteria reproduce?","Binary fission","Mitosis and meiosis","Spores only","Budding"],
     ["What are organisms thriving in extreme heat called?","Thermophiles","Halophiles","Methanogens","Decomposers"],
     ["Which bacteria live in legume root nodules?","Nitrogen-fixing bacteria","Cyanobacteria","Methanogens","E. coli"],
     ["Who identified the bacteria causing tuberculosis?","Robert Koch","Louis Pasteur","Joseph Lister","Alexander Fleming"],
     ["Who discovered penicillin?","Alexander Fleming","Howard Florey","Ernst Chain","Selman Waksman"],
     ["What is MRSA?","An antibiotic-resistant bacterium","A virus","A vaccine","A type of fungus"]]},

{ t:"Viruses", s:"At the edge of life",
  sec:[
  ["What viruses are",[
    "Viruses are tiny infectious agents, typically 20–300 nanometers across, much smaller than bacteria and visible only with electron microscopes. A virus consists of genetic material, DNA or RNA, enclosed in a protein coat called a capsid, sometimes with an outer lipid envelope.",
    "Viruses cannot reproduce or carry out metabolism on their own; they must infect host cells and hijack their machinery. In 1892 Dmitri Ivanovsky showed that the agent causing tobacco mosaic disease passed through filters that trapped bacteria; Martinus Beijerinck called it a virus (Latin for “poison”). Wendell Stanley crystallized tobacco mosaic virus in 1935."]],
  ["How viruses replicate",[
    "A virus attaches to specific receptors on a host cell, enters or injects its genetic material, uses the cell's machinery to make copies of its genes and proteins, assembles new viruses, and releases them, often killing the cell. In the lytic cycle, this happens quickly; in the lysogenic cycle, viral DNA integrates into the host's DNA and remains dormant before becoming active.",
    "Retroviruses, such as HIV, use reverse transcriptase to make DNA from their RNA and insert it into the host genome. About 8 percent of the human genome consists of remnants of ancient retroviral infections."]],
  ["Viruses and disease",[
    "Viruses cause many human diseases, including the common cold, influenza, measles, mumps, chickenpox, polio, hepatitis, rabies, HIV/AIDS, Ebola, Zika, and COVID-19. Some viruses, such as human papillomavirus (HPV) and hepatitis B, can cause cancer.",
    "Many viral diseases are zoonoses, which jump from animals to humans, such as HIV (from chimpanzees), Ebola (likely from bats), and influenza (from birds and pigs). The 1918 influenza pandemic killed an estimated 50 million people or more worldwide."]],
  ["Pandemics",[
    "HIV, identified in 1983 by Françoise Barré-Sinoussi and Luc Montagnier, causes AIDS by destroying immune cells; it has killed over 40 million people. Antiretroviral therapy, developed from the 1990s, turned HIV into a manageable chronic condition.",
    "COVID-19, caused by the coronavirus SARS-CoV-2, was first identified in Wuhan, China, in late 2019 and declared a pandemic by the World Health Organization in March 2020. It caused millions of deaths worldwide; the WHO estimated excess deaths of about 15 million in 2020–2021. Vaccines developed in under a year, including new mRNA vaccines, saved millions of lives."]],
  ["Fighting viruses",[
    "Because viruses use host cells' machinery, they are hard to target without harming the host, and antibiotics do not work against them. Antiviral drugs, such as those for HIV, hepatitis C, and influenza, target specific viral enzymes or steps.",
    "Vaccines are the most powerful tool. Smallpox was declared eradicated in 1980 after a global vaccination campaign, and polio has been eliminated from most of the world. The body's immune system and vaccines are discussed further in the chapter on immunity."]],
  ["Useful viruses",[
    "Not all viruses are harmful. Bacteriophages (“bacteria eaters”) infect bacteria and are being explored as treatments for antibiotic-resistant infections, phage therapy. Viruses are used as vectors in gene therapy to deliver healthy genes to patients' cells, and in some vaccines.",
    "Viruses are the most abundant biological entities on Earth; there are estimated to be about 10³¹ virus particles, and in the oceans they kill a large share of bacteria daily, shaping global nutrient cycles."]]
  ],
  terms:[["Virus","An infectious agent that replicates only inside host cells."],["Capsid","The protein coat of a virus."],["Lytic and lysogenic cycles","Immediate replication vs. dormant integration."],["Retrovirus","An RNA virus that inserts DNA into the host genome."],["Zoonosis","A disease that jumps from animals to humans."],["Pandemic","A global epidemic."],["Bacteriophage","A virus that infects bacteria."]],
  w:"Viruses are at the edge of life, causing devastating diseases and pandemics yet also shaping evolution and offering tools for medicine.",
  src:["Virus","Tobacco mosaic virus","Retrovirus","Zoonosis","Spanish flu","HIV/AIDS","COVID-19 pandemic"],
  q:[["What is a virus's protein coat called?","A capsid","A cell wall","A membrane","A nucleus"],
     ["Who showed tobacco mosaic disease passed through bacterial filters?","Dmitri Ivanovsky","Louis Pasteur","Robert Koch","Edward Jenner"],
     ["What enzyme do retroviruses use?","Reverse transcriptase","DNA polymerase","Amylase","Ligase"],
     ["What is a disease that jumps from animals to humans called?","A zoonosis","A retrovirus","A pandemic","An endemic"],
     ["Who identified HIV in 1983?","Barré-Sinoussi and Montagnier","Fleming and Florey","Pasteur and Koch","Salk and Sabin"],
     ["When was smallpox declared eradicated?","1980","1950","2000","1918"]]},

{ t:"Fungi and Protists", s:"Mushrooms, molds, and single-celled eukaryotes",
  sec:[
  ["What fungi are",[
    "Fungi, including mushrooms, molds, and yeasts, form their own kingdom. Once grouped with plants, they are actually more closely related to animals. Fungi cannot photosynthesize; they absorb nutrients from their surroundings, secreting digestive enzymes onto food and absorbing the products. Their cell walls are made of chitin.",
    "Most of a fungus is a hidden network of thread-like filaments called hyphae, forming a mycelium in soil or wood; mushrooms are only the fruiting bodies that release spores. One honey fungus (Armillaria) in Oregon's Blue Mountains covers about 9 square kilometers and may be thousands of years old, among the largest organisms on Earth."]],
  ["Fungi in ecosystems",[
    "Fungi are major decomposers, breaking down dead wood and leaves and recycling nutrients; without them, forests would be buried in debris. White-rot fungi are among the few organisms that can break down lignin, the tough component of wood.",
    "About 90 percent of plant species form mycorrhizae, partnerships with fungi in which fungal hyphae help roots absorb water and minerals in exchange for sugars. Underground fungal networks connect trees, sometimes called the “wood wide web,” though the extent of resource sharing is debated. Lichens are partnerships between fungi and algae or cyanobacteria that can colonize bare rock."]],
  ["Fungi and people",[
    "Yeasts ferment sugars to make bread, beer, and wine. Fungi give flavor to blue cheese and soy sauce, and many mushrooms are eaten. Penicillin and other antibiotics come from fungi, as does cyclosporine, which prevents organ transplant rejection.",
    "Some fungi are harmful: athlete's foot and ringworm are fungal infections; Candida causes yeast infections; and deadly mushrooms such as the death cap (Amanita phalloides) cause most fatal mushroom poisonings. Fungal diseases devastate crops and wildlife: chytrid fungus has driven many amphibian species to extinction, and the Irish potato famine was caused by Phytophthora infestans, a funguslike water mold."]],
  ["Protists",[
    "Protists are a diverse collection of mostly single-celled eukaryotes that are not animals, plants, or fungi; the group is not a natural clade but a convenient category. They include animal-like protozoa, such as amoebas, which move with pseudopods, and paramecia, covered with hairlike cilia; plant-like algae, which photosynthesize; and fungus-like slime molds.",
    "Diatoms, single-celled algae with intricate glass-like silica shells, produce a significant share of Earth's oxygen. Seaweeds, such as giant kelp, which can grow up to about half a meter a day, are multicellular algae."]],
  ["Protists and disease",[
    "Some protists cause serious diseases. Malaria is caused by Plasmodium parasites transmitted by Anopheles mosquitoes; it still kills over 600,000 people a year, mostly young children in Africa. Ronald Ross showed in 1897 that mosquitoes transmit malaria. Quinine, from cinchona bark, and later artemisinin, discovered by the Chinese scientist Tu Youyou (Nobel Prize 2015), are key treatments, and malaria vaccines were approved in the 2020s.",
    "Other protist diseases include sleeping sickness (trypanosomes spread by tsetse flies), Chagas disease, giardiasis, and amoebic dysentery. Harmful algal blooms, “red tides,” produce toxins that kill fish and contaminate shellfish."]],
  ["Slime molds",[
    "Slime molds are remarkable organisms: the slime mold Physarum polycephalum, a single giant cell with many nuclei, can find the shortest path through a maze to food, and in 2010 researchers showed it could form networks similar in efficiency to the Tokyo rail system.",
    "Cellular slime molds such as Dictyostelium live as separate amoebas but aggregate into a multicellular slug when food runs out, offering clues to how multicellular life evolved."]]
  ],
  terms:[["Fungi","A kingdom of decomposers and symbionts with chitin walls."],["Hypha and mycelium","Fungal filaments and their network."],["Mycorrhiza","A partnership between fungi and plant roots."],["Lichen","A partnership of a fungus and an alga or cyanobacterium."],["Protist","A eukaryote that is not an animal, plant, or fungus."],["Diatom","A single-celled alga with a silica shell."],["Plasmodium","The protist that causes malaria."]],
  w:"Fungi and protists recycle nutrients, partner with plants, feed the oceans, give us food and medicines, and cause some of humanity's deadliest diseases.",
  src:["Fungus","Mycelium","Mycorrhiza","Lichen","Protist","Diatom","Malaria"],
  q:[["What are fungal cell walls made of?","Chitin","Cellulose","Peptidoglycan","Silica"],
     ["What are fungal filaments called?","Hyphae","Roots","Cilia","Pseudopods"],
     ["What share of plant species form mycorrhizae?","About 90 percent","About 10 percent","About 50 percent","None"],
     ["Which mushroom causes most fatal mushroom poisonings?","The death cap","The fly agaric","The chanterelle","The porcini"],
     ["What transmits malaria?","Anopheles mosquitoes","Tsetse flies","Ticks","Fleas"],
     ["Who discovered artemisinin?","Tu Youyou","Ronald Ross","Alexander Fleming","Louis Pasteur"]]}

]});


/* ---- from sci-14.js ---- */
/* SCIENCES FOUNDATIONS, part 14: Unit 7 chapters 5-9 */
COURSES.sciences.units[6].ch.push(

{ t:"How Plants Work", s:"Roots, stems, leaves, and transport",
  sec:[
  ["The plant kingdom",[
    "Plants are multicellular eukaryotes that make their own food by photosynthesis, with cell walls of cellulose. They evolved from green algae and colonized land around 470 million years ago. There are roughly 380,000 known plant species, and plants make up about 80 percent of Earth's biomass.",
    "Major groups include mosses and liverworts (nonvascular plants without true roots or veins), ferns (vascular plants that reproduce by spores), gymnosperms (“naked seeds,” such as conifers, cycads, and ginkgo), and angiosperms, the flowering plants, which make up about 90 percent of plant species."]],
  ["Roots and stems",[
    "Roots anchor plants and absorb water and minerals, greatly increasing their surface area with tiny root hairs. Taproots, such as carrots, go deep; fibrous roots, such as grasses, spread widely, holding soil. Some roots store food.",
    "Stems support leaves and flowers and transport materials. Vascular plants have two kinds of transport tissue: xylem carries water and minerals up from the roots, and phloem carries sugars from leaves to where they are needed. Woody stems add a new layer of xylem each year, forming annual growth rings used to date trees (dendrochronology). Bristlecone pines in California can live nearly 5,000 years."]],
  ["Leaves",[
    "Leaves are the main sites of photosynthesis, broad and thin to capture light and exchange gases. Tiny pores called stomata, mostly on the underside, open to let carbon dioxide in and oxygen out, controlled by guard cells; they also let water vapor escape.",
    "Transpiration, the evaporation of water from leaves, pulls water up through the xylem from roots, sometimes over 100 meters in the tallest trees, through the cohesion of water molecules. A large tree can transpire hundreds of liters of water a day. Leaves change color in autumn when chlorophyll breaks down, revealing yellow and orange carotenoids, while red anthocyanins are produced."]],
  ["Plant responses",[
    "Though they cannot move from place to place, plants respond to their environment through tropisms, growth toward or away from stimuli. Phototropism bends shoots toward light, and gravitropism sends roots downward and shoots upward. Charles Darwin and his son Francis studied phototropism in the 1880s, leading to the discovery of the hormone auxin.",
    "Plant hormones regulate growth, flowering, fruit ripening (ethylene makes fruit ripen, which is why a ripe banana speeds ripening of others), and dormancy. Some plants respond to touch: the sensitive plant Mimosa pudica folds its leaves, and the Venus flytrap snaps shut on insects."]],
  ["Plant defenses",[
    "Plants defend themselves against herbivores with thorns, spines, tough leaves, and an enormous array of chemicals, such as caffeine, nicotine, and toxins. Many of our medicines come from plant chemicals: aspirin from willow, morphine from opium poppies, quinine from cinchona, digoxin from foxglove, and the cancer drug taxol from the Pacific yew.",
    "Some plants release chemical signals when attacked that alert neighboring plants or attract predators of their attackers."]],
  ["Nutrients",[
    "Besides water and carbon dioxide, plants need mineral nutrients from soil, especially nitrogen, phosphorus, and potassium (N-P-K, the main components of fertilizers), along with calcium, magnesium, sulfur, and trace elements such as iron.",
    "Carnivorous plants, such as pitcher plants and sundews, grow in nutrient-poor bogs and obtain nitrogen by trapping insects. Hydroponics grows plants in nutrient solutions without soil."]]
  ],
  terms:[["Vascular plant","A plant with xylem and phloem."],["Xylem","Tissue carrying water and minerals upward."],["Phloem","Tissue carrying sugars."],["Stomata","Pores in leaves for gas exchange."],["Transpiration","Evaporation of water from leaves."],["Tropism","Growth toward or away from a stimulus."],["Auxin","A plant growth hormone."]],
  w:"Understanding how plants work explains how they feed the world, move water, respond to their environment, and provide many of our medicines.",
  src:["Plant","Xylem","Phloem","Stoma","Transpiration","Tropism","Auxin"],
  q:[["Which group makes up about 90 percent of plant species?","Flowering plants","Ferns","Conifers","Mosses"],
     ["Which tissue carries water up from the roots?","Xylem","Phloem","Stomata","Cambium"],
     ["What are pores in leaves called?","Stomata","Root hairs","Xylem","Chloroplasts"],
     ["What is the evaporation of water from leaves called?","Transpiration","Photosynthesis","Respiration","Osmosis"],
     ["Which hormone makes fruit ripen?","Ethylene","Auxin","Insulin","Gibberellin"],
     ["Which cancer drug comes from the Pacific yew?","Taxol","Morphine","Digoxin","Quinine"]]},

{ t:"Plant Reproduction and Importance", s:"Flowers, seeds, and feeding the world",
  sec:[
  ["Spores and seeds",[
    "Plants have life cycles that alternate between generations. Mosses and ferns reproduce by spores and need water for fertilization. Seed plants evolved seeds, which contain an embryo with a food supply inside a protective coat, allowing reproduction on dry land and dispersal over long distances; some seeds remain viable for centuries.",
    "In 2012 Russian scientists regenerated a plant from seed tissue about 32,000 years old found frozen in Siberian permafrost. The Svalbard Global Seed Vault in Norway, opened in 2008, stores over a million seed samples as insurance against crop loss."]],
  ["Flowers",[
    "Flowers are the reproductive organs of angiosperms, which appeared over 130 million years ago and rapidly diversified. The male parts, stamens, produce pollen in anthers; the female part, the carpel or pistil, includes the stigma, which catches pollen, and the ovary, which contains ovules.",
    "Pollination transfers pollen to the stigma, by wind (as in grasses and many trees, whose pollen causes hay fever), water, or animals. Fertilization occurs when a pollen tube grows to an ovule; the ovule becomes a seed and the ovary becomes a fruit."]],
  ["Pollinators",[
    "Many flowers coevolved with animal pollinators, offering nectar and pollen as rewards and attracting them with colors, scents, and shapes. Bees see ultraviolet patterns guiding them to nectar; hummingbirds favor red tubular flowers; bats and moths pollinate pale, fragrant night-blooming flowers. Some orchids mimic female insects to attract male pollinators.",
    "About three-quarters of leading food crops depend at least partly on animal pollination. Declines in bees and other pollinators due to habitat loss, pesticides, parasites, and disease are a serious concern."]],
  ["Fruits and dispersal",[
    "Fruits protect seeds and help disperse them. Fleshy fruits such as berries are eaten by animals, which spread seeds in their droppings; burrs hook onto fur; maple seeds spin like helicopters; dandelion seeds float on the wind; coconuts float across oceans.",
    "Botanically, a fruit is the ripened ovary of a flower, so tomatoes, cucumbers, peppers, and pea pods are fruits. Many plants also reproduce asexually through runners, bulbs, tubers such as potatoes, or cuttings, producing clones."]],
  ["Plants and people",[
    "Agriculture depends on domesticated plants. Just three, rice, wheat, and maize, provide about half of all human calories. Plant breeding, from ancient farmers selecting seeds to the Green Revolution led by Norman Borlaug, has dramatically increased yields.",
    "Plants also provide timber, paper, cotton, rubber, medicines, spices, coffee, tea, chocolate, and biofuels. Forests store carbon, regulate water cycles, prevent erosion, and harbor most land species."]],
  ["Plants in danger",[
    "Around 40 percent of plant species may be threatened with extinction, according to a 2020 assessment by the Royal Botanic Gardens, Kew, mainly due to habitat loss from agriculture and development. Botanic gardens, seed banks, and protected areas work to conserve plant diversity.",
    "Crop diversity is also important: the Irish potato famine of 1845–1852 was worsened by reliance on a single potato variety vulnerable to blight, a lesson for modern monoculture agriculture."]]
  ],
  terms:[["Seed","An embryo with food supply in a protective coat."],["Angiosperm","A flowering plant."],["Stamen and carpel","Male and female flower parts."],["Pollination","Transfer of pollen to a stigma."],["Fruit","The ripened ovary of a flower."],["Seed dispersal","Spreading seeds away from the parent plant."],["Svalbard Global Seed Vault","A Norwegian vault storing seed samples."]],
  w:"Plant reproduction, pollinators, and seeds sustain ecosystems and agriculture, making plants essential to human survival.",
  src:["Plant reproduction","Seed","Flower","Pollination","Fruit","Seed dispersal","Svalbard Global Seed Vault"],
  q:[["What do mosses and ferns reproduce by?","Spores","Seeds","Flowers","Fruits"],
     ["What part of the flower produces pollen?","The anther","The stigma","The ovary","The petal"],
     ["What does the ovary become after fertilization?","The fruit","The seed","The flower","The root"],
     ["Botanically, which is a fruit?","A tomato","A carrot","A potato","Lettuce"],
     ["What share of leading food crops depend partly on animal pollination?","About three-quarters","About 5 percent","About a quarter","All of them"],
     ["Where is the Global Seed Vault?","Svalbard, Norway","Kew, London","Siberia","Iceland"]]},

{ t:"Invertebrates", s:"Animals without backbones",
  sec:[
  ["What animals are",[
    "Animals are multicellular eukaryotes that obtain food by eating other organisms, lack cell walls, and are usually able to move at some stage of life. Most develop from an embryo called a blastula. There are about 35 major groups (phyla), and about 1.5 million animal species have been described.",
    "About 95 percent or more of animal species are invertebrates, animals without backbones."]],
  ["Simple animals",[
    "Sponges (phylum Porifera) are the simplest animals, filtering food from water through pores, without true tissues or organs. Cnidarians, including jellyfish, corals, and sea anemones, have radial symmetry and stinging cells called nematocysts. The box jellyfish is among the most venomous animals, and Turritopsis dohrnii, the “immortal jellyfish,” can revert to an earlier life stage.",
    "Flatworms, such as planarians and tapeworms, and roundworms (nematodes) are among the simplest animals with bilateral symmetry, having left and right sides. The nematode Caenorhabditis elegans, with exactly 959 body cells in adult hermaphrodites, is a key model organism in biology."]],
  ["Mollusks and annelids",[
    "Mollusks include snails, slugs, clams, oysters, mussels, squid, and octopuses, most with a soft body and a hard shell. Cephalopods, octopuses, squid, and cuttlefish, are the most intelligent invertebrates: octopuses can solve puzzles, use tools, and change color and texture for camouflage in an instant. The giant squid, which can exceed 12 meters, was first filmed alive in its habitat in 2012.",
    "Annelids, segmented worms, include earthworms, which Darwin showed in his last book (1881) to be crucial in turning and enriching soil, as well as leeches, still used in medicine to drain blood after some surgeries."]],
  ["Arthropods",[
    "Arthropods, the largest animal phylum, have jointed legs, segmented bodies, and hard exoskeletons made of chitin, which they molt to grow. They include insects, arachnids (spiders, scorpions, mites, ticks), crustaceans (crabs, lobsters, shrimp, barnacles), and myriapods (centipedes and millipedes).",
    "Insects are the most diverse group of animals, with about a million described species and perhaps several million more. Beetles alone account for about 400,000 species; the biologist J. B. S. Haldane reportedly quipped that the Creator must have “an inordinate fondness for beetles.” Many insects undergo metamorphosis, such as caterpillars becoming butterflies."]],
  ["Social insects",[
    "Ants, bees, wasps, and termites live in highly organized colonies with divisions of labor among queens, workers, and soldiers. A honeybee hive can contain tens of thousands of bees. Karl von Frisch discovered that honeybees communicate the direction and distance of food through a “waggle dance,” for which he shared the 1973 Nobel Prize.",
    "Ants are among the most abundant animals; a 2022 study estimated about 20 quadrillion ants on Earth. Leafcutter ants farm fungi, and some termites build towering mounds with ventilation systems."]],
  ["Echinoderms",[
    "Echinoderms, including sea stars (starfish), sea urchins, sand dollars, and sea cucumbers, have five-part radial symmetry as adults, a spiny skin, and a water vascular system that powers tube feet. Many sea stars can regenerate lost arms.",
    "Surprisingly, echinoderms are more closely related to vertebrates than to other invertebrates, sharing patterns of early embryonic development."]]
  ],
  terms:[["Invertebrate","An animal without a backbone."],["Cnidarian","Jellyfish, corals, and anemones with stinging cells."],["Bilateral symmetry","Having matching left and right sides."],["Mollusk","Soft-bodied animals such as snails and octopuses."],["Arthropod","Animals with jointed legs and exoskeletons."],["Metamorphosis","A dramatic change in body form during development."],["Echinoderm","Sea stars and relatives with five-part symmetry."]],
  w:"Invertebrates make up the vast majority of animal species and play essential roles in every ecosystem, from coral reefs to soil.",
  src:["Animal","Invertebrate","Cnidaria","Mollusca","Arthropod","Insect","Echinoderm"],
  q:[["What share of animal species are invertebrates?","About 95 percent or more","About 50 percent","About 10 percent","About 75 percent"],
     ["What are the simplest animals?","Sponges","Jellyfish","Worms","Insects"],
     ["Which invertebrates are the most intelligent?","Cephalopods","Insects","Sponges","Worms"],
     ["What is the largest animal phylum?","Arthropods","Mollusks","Chordates","Cnidarians"],
     ["Who discovered the honeybee waggle dance?","Karl von Frisch","Konrad Lorenz","E. O. Wilson","Niko Tinbergen"],
     ["Which group is most closely related to vertebrates?","Echinoderms","Insects","Mollusks","Cnidarians"]]},

{ t:"Vertebrates", s:"Fish, amphibians, reptiles, birds, and mammals",
  sec:[
  ["Chordates",[
    "Vertebrates belong to the phylum Chordata, animals that at some stage have a notochord (a flexible rod along the back), a hollow nerve cord, gill slits, and a tail. In vertebrates, the notochord is replaced by a backbone of vertebrae protecting the spinal cord. Vertebrates have an internal skeleton of bone or cartilage, allowing large body sizes.",
    "There are about 70,000 vertebrate species. The largest animal ever known is the blue whale, up to about 30 meters long and 150 tonnes or more."]],
  ["Fish",[
    "Fish were the first vertebrates, appearing over 500 million years ago, and they make up about half of vertebrate species. Jawless fish include lampreys and hagfish; cartilaginous fish, sharks, rays, and skates, have skeletons of cartilage; and bony fish, the largest group, include ray-finned fish such as salmon and tuna, and lobe-finned fish such as the coelacanth, thought extinct until a living one was caught off South Africa in 1938.",
    "Fish breathe through gills that extract oxygen from water. Lobe-finned fish gave rise to the first four-legged land animals about 375 million years ago."]],
  ["Amphibians and reptiles",[
    "Amphibians, frogs, toads, salamanders, and caecilians, typically lay eggs in water and undergo metamorphosis from aquatic larvae, such as tadpoles, to adults. They breathe partly through their moist skin, making them sensitive to pollution. Amphibians are the most threatened vertebrate group, with about 41 percent of species threatened, partly due to the chytrid fungus.",
    "Reptiles, lizards, snakes, turtles, and crocodilians, have dry, scaly skin and lay amniotic eggs with protective shells and membranes, allowing reproduction away from water, a key adaptation for life on land. Reptiles are ectotherms, relying on external heat to regulate body temperature."]],
  ["Birds",[
    "Birds are descendants of feathered dinosaurs. They have feathers, beaks without teeth, hollow bones, and lay hard-shelled eggs, and they are endotherms, generating their own body heat. There are about 11,000 bird species.",
    "Many birds migrate long distances; the Arctic tern flies from the Arctic to the Antarctic and back each year, about 70,000 kilometers or more, and the bar-tailed godwit flies over 11,000 kilometers nonstop from Alaska to New Zealand. Birds navigate using the Sun, stars, Earth's magnetic field, and landmarks."]],
  ["Mammals",[
    "Mammals have hair or fur, are endothermic, and feed their young with milk from mammary glands. There are about 6,500 species. Monotremes, such as the platypus and echidnas of Australia and New Guinea, lay eggs. Marsupials, such as kangaroos, koalas, and opossums, give birth to tiny young that develop in a pouch.",
    "Placental mammals, the largest group, nourish developing young through a placenta. They include rodents, the most numerous order, about 40 percent of mammal species; bats, the only mammals capable of true flight, about 20 percent; and whales, primates, carnivores, and hoofed mammals."]],
  ["Vertebrate adaptations",[
    "Vertebrates have adapted to every environment, from deep oceans to deserts and polar regions. Camels conserve water; Arctic animals have thick fur and fat; emperor penguins huddle through Antarctic winters; and echolocating bats and dolphins “see” with sound.",
    "Endothermy, maintaining a constant body temperature, allows birds and mammals to remain active in cold conditions but requires much more food than ectotherms of the same size need."]]
  ],
  terms:[["Chordate","An animal with a notochord at some stage."],["Vertebrate","An animal with a backbone."],["Cartilaginous fish","Sharks and rays with cartilage skeletons."],["Amniotic egg","An egg with membranes allowing reproduction on land."],["Ectotherm and endotherm","Animals relying on external vs. internal heat."],["Marsupial","A mammal whose young develop in a pouch."],["Placental mammal","A mammal nourishing young through a placenta."]],
  w:"Vertebrates, from fish to mammals, show how a single body plan diversified to conquer every environment on Earth, including our own lineage.",
  src:["Chordate","Vertebrate","Fish","Coelacanth","Amphibian","Bird migration","Mammal"],
  q:[["What is the largest animal ever known?","The blue whale","Argentinosaurus","The whale shark","The African elephant"],
     ["Which fish was thought extinct until 1938?","The coelacanth","The lamprey","The hagfish","The great white shark"],
     ["Which is the most threatened vertebrate group?","Amphibians","Birds","Mammals","Fish"],
     ["What adaptation allowed reptiles to reproduce on land?","The amniotic egg","Gills","Feathers","Fur"],
     ["Which bird makes the longest annual migration?","The Arctic tern","The albatross","The swallow","The goose"],
     ["Which mammals lay eggs?","Monotremes","Marsupials","Rodents","Bats"]]},

{ t:"Animal Behavior", s:"Instinct, learning, and social life",
  sec:[
  ["Studying behavior",[
    "Ethology is the scientific study of animal behavior in natural conditions. Niko Tinbergen proposed four questions for understanding any behavior: what causes it (mechanism), how it develops in the individual, what its function is (survival value), and how it evolved. Tinbergen, Konrad Lorenz, and Karl von Frisch shared the 1973 Nobel Prize for founding the field.",
    "Behaviors range from innate (instinctive), performed correctly the first time without learning, to learned, shaped by experience."]],
  ["Instinct and imprinting",[
    "Innate behaviors include reflexes and fixed action patterns, such as a spider spinning a web or a newly hatched sea turtle heading toward the sea. Lorenz showed that newly hatched geese follow the first moving object they see, normally their mother, a rapid learning process called imprinting that occurs during a critical period; famously, goslings imprinted on Lorenz himself.",
    "Many instincts are triggered by specific sign stimuli; Tinbergen showed male stickleback fish attack anything with a red underside, like a rival male."]],
  ["Learning",[
    "Animals learn in many ways. In habituation, they learn to ignore repeated harmless stimuli. In classical conditioning, demonstrated by Ivan Pavlov around 1900, dogs that heard a bell before receiving food began to salivate at the bell alone. In operant conditioning, studied by B. F. Skinner, behaviors followed by rewards become more frequent.",
    "Some animals show insight learning and problem-solving: chimpanzees use sticks to fish for termites, as observed by Jane Goodall in Tanzania in 1960, overturning the belief that only humans make tools. New Caledonian crows bend wires into hooks, and many animals learn by observing others."]],
  ["Communication",[
    "Animals communicate through sounds, visual displays, chemicals, and touch. Birds sing to attract mates and defend territories; whales sing complex songs that change over time; vervet monkeys give different alarm calls for leopards, eagles, and snakes. Ants and many other animals communicate with pheromones.",
    "Researchers have taught great apes to use sign language or symbols to some extent, though whether this amounts to language remains debated."]],
  ["Social behavior",[
    "Many animals live in groups for protection, cooperation in hunting, and raising young. Social structures range from wolf packs and elephant herds led by matriarchs to primate troops with complex hierarchies. Dominance hierarchies reduce conflict by establishing rank.",
    "Altruism, behavior that benefits others at a cost to oneself, puzzled Darwin. W. D. Hamilton's theory of kin selection (1964) explained that helping relatives can spread shared genes, which accounts for sterile worker ants and bees helping their queen. Reciprocal altruism, “you scratch my back and I'll scratch yours,” explains cooperation among non-relatives, as when vampire bats share blood meals."]],
  ["Migration, navigation, and intelligence",[
    "Migration allows animals to exploit seasonal resources: monarch butterflies travel up to about 4,000 kilometers from North America to Mexico over several generations; wildebeest follow the rains; salmon return to the rivers where they were born, guided partly by smell.",
    "Research has revealed remarkable intelligence in many species: dolphins, elephants, magpies, and great apes can recognize themselves in mirrors; crows and ravens plan ahead; and honeybees can learn abstract concepts. The study of animal minds raises important ethical questions about how humans treat animals."]]
  ],
  terms:[["Ethology","The study of animal behavior in natural conditions."],["Innate behavior","Instinctive behavior not requiring learning."],["Imprinting","Rapid learning during a critical period."],["Classical conditioning","Learning to associate a stimulus with a response."],["Operant conditioning","Learning through rewards and punishments."],["Kin selection","Helping relatives to spread shared genes."],["Pheromone","A chemical signal between animals."]],
  w:"Animal behavior reveals how instinct, learning, and social life help animals survive, and offers insights into our own minds.",
  src:["Ethology","Tinbergen's four questions","Imprinting (psychology)","Classical conditioning","Jane Goodall","Kin selection","Mirror test"],
  q:[["Which three scientists shared the 1973 Nobel Prize for founding ethology?","Tinbergen, Lorenz, and von Frisch","Pavlov, Skinner, and Watson","Darwin, Wallace, and Mendel","Goodall, Fossey, and Galdikas"],
     ["Who showed goslings imprint on the first moving object?","Konrad Lorenz","Ivan Pavlov","B. F. Skinner","Jane Goodall"],
     ["Who demonstrated classical conditioning with dogs?","Ivan Pavlov","B. F. Skinner","Konrad Lorenz","Niko Tinbergen"],
     ["Who observed chimpanzees using tools in 1960?","Jane Goodall","Dian Fossey","Biruté Galdikas","Frans de Waal"],
     ["Which theory explains altruism toward relatives?","Kin selection","Imprinting","Operant conditioning","Group selection"],
     ["Which animals can recognize themselves in mirrors?","Dolphins, elephants, and great apes","Most fish","Dogs and cats","All mammals"]]}

);


/* ---- from sci-15.js ---- */
/* SCIENCES FOUNDATIONS, part 15: Unit 8 The Human Body, chapters 1-5 */
COURSES.sciences.units.push({ t:"The Human Body and Health", ch:[

{ t:"Bones and Muscles", s:"The body's framework and engines",
  sec:[
  ["Organization of the body",[
    "The human body is organized into cells, tissues, organs, and organ systems. The four basic tissue types are epithelial tissue (covering surfaces and lining organs), connective tissue (bone, blood, cartilage, fat, and tendons), muscle tissue, and nervous tissue.",
    "Major organ systems include the skeletal, muscular, circulatory, respiratory, digestive, urinary, nervous, endocrine, immune, integumentary (skin, hair, nails), and reproductive systems, all working together. The skin is the largest organ, with an area of about 2 square meters in adults."]],
  ["The skeleton",[
    "The adult human skeleton has 206 bones (babies are born with around 270, some of which fuse). The skeleton supports the body, protects organs (the skull protects the brain, the ribs the heart and lungs), allows movement, stores calcium and phosphorus, and produces blood cells in the red bone marrow.",
    "The largest bone is the femur (thigh bone); the smallest is the stapes (stirrup) in the middle ear. Bone is living tissue, constantly remodeled; Andreas Vesalius's anatomy of 1543 first accurately depicted the skeleton. Osteoporosis, a loss of bone density, makes bones fragile, especially in older women; weight-bearing exercise, calcium, and vitamin D help keep bones strong."]],
  ["Joints",[
    "Joints connect bones. Ball-and-socket joints, such as the shoulder and hip, allow movement in many directions; hinge joints, such as the knee and elbow, allow movement in one plane; pivot joints allow rotation, as in the neck. Cartilage cushions joint surfaces, and ligaments connect bone to bone.",
    "Arthritis, inflammation of the joints, is a leading cause of disability. Osteoarthritis results from wear of cartilage; rheumatoid arthritis is an autoimmune disease. Damaged hips and knees are commonly replaced with artificial joints."]],
  ["Muscles",[
    "The body has about 600 skeletal muscles, making up roughly 40 percent of body weight. There are three types: skeletal muscle, attached to bones by tendons and under voluntary control; smooth muscle, in the walls of organs such as the stomach, intestines, and blood vessels, working involuntarily; and cardiac muscle, found only in the heart, which contracts rhythmically throughout life.",
    "The largest muscle is the gluteus maximus; the strongest by force relative to size is often said to be the masseter, the jaw muscle. Muscles can only pull, not push, so they work in antagonistic pairs: the biceps bends the elbow while the triceps straightens it."]],
  ["How muscles contract",[
    "Skeletal muscles are made of long fibers containing protein filaments of actin and myosin. In the sliding filament theory, proposed in 1954 by Andrew Huxley and Hugh Huxley (unrelated), nerve signals trigger the release of calcium, allowing myosin heads to pull actin filaments past them, shortening the muscle, powered by ATP.",
    "Exercise strengthens muscles and bones. Fast-twitch fibers provide quick, powerful bursts, as in sprinting; slow-twitch fibers resist fatigue, as in marathon running. Rigor mortis, the stiffening of muscles after death, occurs because ATP runs out and myosin remains locked to actin."]],
  ["Skin",[
    "The skin protects against injury, infection, and water loss, regulates temperature through sweating and blood flow, senses touch, heat, and pain, and makes vitamin D in sunlight. It has an outer layer, the epidermis, constantly renewed as dead cells flake off, and a deeper dermis containing blood vessels, nerves, sweat glands, and hair follicles.",
    "Melanin, a pigment produced by melanocytes, gives skin its color and protects against ultraviolet radiation. Variation in skin color among human populations evolved largely as an adaptation to different levels of UV light."]]
  ],
  terms:[["Tissue","A group of similar cells working together."],["Organ system","Organs working together for a function."],["Bone marrow","Tissue inside bones that makes blood cells."],["Ligament and tendon","Connecting bone to bone vs. muscle to bone."],["Antagonistic pair","Muscles working in opposition."],["Sliding filament theory","Muscle contraction by actin and myosin sliding."],["Melanin","The pigment giving skin its color."]],
  w:"The skeleton, joints, muscles, and skin give the body structure, movement, and protection, and keeping them healthy is key to lifelong well-being.",
  src:["Human body","Human skeleton","Joint","Muscle","Sliding filament theory","Skin","Human skin color"],
  q:[["How many bones are in the adult human skeleton?","206","300","186","250"],
     ["What is the largest bone?","The femur","The tibia","The humerus","The spine"],
     ["What connects muscle to bone?","Tendons","Ligaments","Cartilage","Joints"],
     ["Which muscle type is found only in the heart?","Cardiac","Smooth","Skeletal","Voluntary"],
     ["Which proteins slide past each other in muscle contraction?","Actin and myosin","Collagen and keratin","Hemoglobin and insulin","Elastin and fibrin"],
     ["What is the largest organ of the body?","The skin","The liver","The brain","The lungs"]]},

{ t:"The Heart and Circulation", s:"Blood, vessels, and the body's pump",
  sec:[
  ["Harvey's discovery",[
    "For centuries, people followed the ancient physician Galen, who believed blood was made in the liver and consumed by the body. In 1628 the English physician William Harvey, in De Motu Cordis, demonstrated that the heart pumps blood in a continuous circuit through arteries and veins, calculating that the heart pumps far more blood each hour than the body could possibly produce.",
    "Marcello Malpighi completed the picture in 1661 by observing capillaries, the tiny vessels connecting arteries and veins, through a microscope."]],
  ["The heart",[
    "The heart is a muscular pump about the size of a fist that beats about 100,000 times a day and about 2.5–3 billion times in a lifetime. It has four chambers: two upper atria, which receive blood, and two lower ventricles, which pump it out. Valves prevent backflow; their closing produces the “lub-dub” sound heard through a stethoscope, invented by René Laennec in 1816.",
    "Humans have a double circulation: the right side of the heart pumps oxygen-poor blood to the lungs, and the left side, with a thicker muscular wall, pumps oxygen-rich blood to the rest of the body. The heartbeat is triggered by a natural pacemaker, the sinoatrial node."]],
  ["Blood vessels",[
    "Arteries carry blood away from the heart under high pressure and have thick, elastic walls; the largest is the aorta. Veins carry blood back to the heart, have thinner walls, and contain valves to prevent backflow. Capillaries, only one cell thick, allow oxygen, nutrients, and wastes to pass between blood and tissues.",
    "Laid end to end, the blood vessels of an adult would stretch roughly 100,000 kilometers. Blood pressure is measured as two numbers: systolic (during heartbeats) over diastolic (between beats); around 120/80 mmHg is typical for a healthy adult."]],
  ["Blood",[
    "An adult has about 5 liters of blood. It consists of plasma, a yellowish liquid carrying nutrients, hormones, and wastes (about 55 percent), red blood cells, which carry oxygen bound to hemoglobin and give blood its color, white blood cells, which fight infection, and platelets, which help blood clot.",
    "Red blood cells live about 120 days, and the body makes millions every second. Karl Landsteiner discovered the ABO blood groups in 1901, making safe transfusions possible; type O negative blood can be given to almost anyone in emergencies, and the Rh factor was discovered in 1940."]],
  ["Cardiovascular disease",[
    "Cardiovascular diseases are the leading cause of death worldwide. Atherosclerosis, the buildup of fatty plaques in arteries, can block blood flow, causing heart attacks when coronary arteries are blocked and strokes when blood flow to the brain is interrupted. Risk factors include high blood pressure, high LDL cholesterol, smoking, diabetes, obesity, physical inactivity, and family history.",
    "The Framingham Heart Study, begun in 1948 in Massachusetts, identified many of these risk factors. Treatments include medications such as statins, angioplasty and stents to open arteries, bypass surgery, and pacemakers. CPR and defibrillators can save lives during cardiac arrest."]],
  ["The lymphatic system",[
    "The lymphatic system is a network of vessels that returns fluid leaking from capillaries back to the bloodstream and carries absorbed fats from the intestines. Lymph nodes along these vessels filter lymph and house immune cells; they swell during infections.",
    "The spleen, the largest lymphatic organ, filters blood and removes old red blood cells. The first successful human heart transplant was performed by Christiaan Barnard in Cape Town in 1967."]]
  ],
  terms:[["Circulatory system","The heart, blood vessels, and blood."],["Atrium and ventricle","Receiving and pumping chambers of the heart."],["Double circulation","Separate circuits to the lungs and the body."],["Artery, vein, capillary","Vessels away from, back to, and between."],["Hemoglobin","The oxygen-carrying protein in red blood cells."],["Blood pressure","The force of blood on vessel walls."],["Atherosclerosis","Fatty buildup in arteries."]],
  w:"The heart and circulation deliver oxygen and nutrients to every cell, and understanding them is key to preventing the world's leading cause of death.",
  src:["Circulatory system","William Harvey","Heart","Blood vessel","Blood","ABO blood group system","Cardiovascular disease"],
  q:[["Who demonstrated the circulation of blood in 1628?","William Harvey","Galen","Andreas Vesalius","Marcello Malpighi"],
     ["How many chambers does the human heart have?","Four","Two","Three","Six"],
     ["Which vessels carry blood away from the heart?","Arteries","Veins","Capillaries","Lymph vessels"],
     ["About how much blood does an adult have?","5 liters","1 liter","10 liters","20 liters"],
     ["Who discovered the ABO blood groups?","Karl Landsteiner","William Harvey","René Laennec","Louis Pasteur"],
     ["Who performed the first human heart transplant?","Christiaan Barnard","Michael DeBakey","Denton Cooley","Norman Shumway"]]},

{ t:"Breathing and the Lungs", s:"Getting oxygen in and carbon dioxide out",
  sec:[
  ["The respiratory system",[
    "The respiratory system takes in oxygen and removes carbon dioxide. Air enters through the nose or mouth, where it is warmed, moistened, and filtered by hairs and mucus, passes through the pharynx and the larynx (voice box), and travels down the trachea (windpipe), which divides into two bronchi and then into thousands of smaller bronchioles.",
    "The epiglottis, a flap of tissue, covers the trachea when swallowing so food goes down the esophagus instead; when it fails, food can go “down the wrong way.”"]],
  ["Alveoli and gas exchange",[
    "The bronchioles end in about 300–500 million tiny air sacs called alveoli, giving the lungs an enormous surface area, roughly 70 square meters, about the floor area of a small apartment. Each alveolus is surrounded by capillaries; oxygen diffuses from the air into the blood, and carbon dioxide diffuses from the blood into the air to be exhaled.",
    "Hemoglobin binds oxygen in the lungs and releases it in tissues. Carbon monoxide is dangerous because it binds hemoglobin about 200–250 times more strongly than oxygen, blocking oxygen transport."]],
  ["How we breathe",[
    "Breathing is driven by the diaphragm, a dome-shaped muscle below the lungs, and the muscles between the ribs. When the diaphragm contracts and flattens and the ribs move up and out, the chest cavity expands, lowering pressure inside the lungs so air flows in. Exhalation is usually passive, as the muscles relax.",
    "At rest, adults breathe about 12–20 times per minute, moving about half a liter of air per breath. Breathing is controlled automatically by the brainstem, which responds mainly to rising carbon dioxide levels in the blood, though it can also be controlled voluntarily."]],
  ["Respiratory diseases",[
    "Asthma causes airways to narrow and become inflamed, making breathing difficult; it is treated with inhalers. Chronic obstructive pulmonary disease (COPD), including emphysema, in which alveoli are destroyed, and chronic bronchitis, is mainly caused by smoking. Pneumonia is an infection filling alveoli with fluid.",
    "Tuberculosis, caused by a bacterium, has killed more people over history than perhaps any other infectious disease and still kills over a million people a year. Lung cancer is the leading cause of cancer death worldwide."]],
  ["Smoking",[
    "Tobacco smoke contains thousands of chemicals, including dozens of carcinogens, nicotine, which is highly addictive, tar, and carbon monoxide. Studies in the 1950s by Richard Doll and Austin Bradford Hill in Britain and Ernst Wynder and Evarts Graham in the United States linked smoking to lung cancer; the U.S. Surgeon General's report of 1964 officially recognized the danger.",
    "Smoking causes about 8 million deaths worldwide each year, including from heart disease, stroke, COPD, and many cancers. Quitting at any age brings substantial health benefits."]],
  ["Breathing at extremes",[
    "At high altitude, lower air pressure means less oxygen enters the blood with each breath. Climbers can suffer altitude sickness; the body adapts over days by breathing faster and making more red blood cells. Populations in the Andes, Tibet, and Ethiopia have evolved distinct genetic adaptations to high altitude.",
    "Free divers can hold their breath for many minutes, aided by the mammalian diving reflex, which slows the heart and conserves oxygen when the face is immersed in cold water."]]
  ],
  terms:[["Trachea","The windpipe."],["Bronchi and bronchioles","Branching airways in the lungs."],["Alveoli","Tiny air sacs where gas exchange occurs."],["Diaphragm","The dome-shaped breathing muscle."],["Gas exchange","Oxygen in and carbon dioxide out across alveoli."],["COPD","Chronic obstructive pulmonary disease."],["Carbon monoxide","A gas that blocks oxygen transport."]],
  w:"The lungs supply the oxygen every cell needs, and protecting them, especially from smoking, is one of the most important things for health.",
  src:["Respiratory system","Lung","Pulmonary alveolus","Thoracic diaphragm","Chronic obstructive pulmonary disease","Tuberculosis","Health effects of tobacco"],
  q:[["What is the windpipe called?","The trachea","The esophagus","The larynx","The bronchus"],
     ["Where does gas exchange occur in the lungs?","The alveoli","The bronchi","The trachea","The diaphragm"],
     ["Which muscle mainly drives breathing?","The diaphragm","The heart","The biceps","The abdominal muscles"],
     ["What does the brain mainly respond to in controlling breathing?","Rising carbon dioxide","Falling nitrogen","Blood sugar","Temperature"],
     ["Why is carbon monoxide dangerous?","It binds hemoglobin more strongly than oxygen","It burns the lungs","It is radioactive","It causes asthma"],
     ["In what year did the U.S. Surgeon General's report on smoking appear?","1964","1950","1980","1945"]]},

{ t:"Digestion and Nutrition", s:"Turning food into fuel",
  sec:[
  ["The digestive tract",[
    "The digestive system breaks food into molecules small enough to be absorbed. Digestion begins in the mouth, where teeth chew food and saliva, containing the enzyme amylase, begins breaking down starch. The tongue pushes food into the esophagus, where waves of muscle contraction called peristalsis move it to the stomach, even upside down.",
    "The digestive tract from mouth to anus is about 9 meters long in an adult. Food typically takes about one to three days to pass through."]],
  ["The stomach",[
    "The stomach is a muscular bag that churns food and secretes hydrochloric acid, which kills microbes, and the enzyme pepsin, which begins digesting proteins. A layer of mucus protects the stomach lining from its own acid.",
    "In the 1820s the U.S. Army surgeon William Beaumont studied digestion through a permanent opening in the stomach of a patient, Alexis St. Martin, who had been shot. Barry Marshall and Robin Warren showed in the 1980s that most stomach ulcers are caused by the bacterium Helicobacter pylori, not stress; Marshall drank a culture of the bacteria to prove it, and they won the 2005 Nobel Prize."]],
  ["The small and large intestines",[
    "Most digestion and absorption occur in the small intestine, about 6 meters long. The liver produces bile, stored in the gallbladder, which breaks fats into droplets, and the pancreas secretes enzymes that digest carbohydrates, proteins, and fats. The intestinal lining is covered with millions of finger-like villi and microvilli, giving a large surface area for absorbing nutrients into the blood.",
    "The large intestine (colon) absorbs water and salts and houses trillions of bacteria that ferment fiber and produce vitamins. What remains is eliminated as feces. The appendix, once considered useless, may serve as a reservoir for gut bacteria."]],
  ["The liver",[
    "The liver, the largest internal organ, has hundreds of functions: it processes nutrients absorbed from the intestines, stores glycogen and vitamins, produces bile and blood proteins, and detoxifies alcohol, drugs, and poisons. It can regenerate remarkably, regrowing after much of it is removed.",
    "Excessive alcohol, viral hepatitis, and fatty liver disease, linked to obesity, can damage the liver, leading to cirrhosis."]],
  ["Nutrients",[
    "A healthy diet provides macronutrients, carbohydrates, fats, and proteins, for energy and building materials, and micronutrients, vitamins and minerals, needed in small amounts. Proteins supply amino acids; nine are essential and must come from food. Fats include unsaturated fats (in olive oil, nuts, and fish), generally healthier, and saturated and trans fats, linked to heart disease.",
    "Fiber, from plant foods, aids digestion and feeds gut bacteria. Important minerals include calcium for bones, iron for hemoglobin (iron deficiency is the most common nutritional deficiency worldwide), and iodine for thyroid hormones; iodized salt, introduced in the 1920s, greatly reduced goiter."]],
  ["Diet and health",[
    "Energy balance, calories eaten versus calories used, determines body weight over time. Worldwide, obesity has roughly tripled since 1975, raising risks of type 2 diabetes, heart disease, and some cancers, while undernutrition persists in poorer regions.",
    "Nutrition science is complex and often misreported, but broad consensus favors diets rich in vegetables, fruits, whole grains, legumes, nuts, and fish, with limited processed meats, added sugars, and highly processed foods, such as the Mediterranean diet. Body mass index (BMI), weight in kilograms divided by height in meters squared, is a rough screening tool."]]
  ],
  terms:[["Peristalsis","Waves of muscle contraction moving food."],["Pepsin","A stomach enzyme digesting protein."],["Bile","A liver secretion that breaks up fats."],["Villi","Finger-like projections absorbing nutrients."],["Macronutrients","Carbohydrates, fats, and proteins."],["Micronutrients","Vitamins and minerals."],["Essential amino acids","Amino acids that must come from food."]],
  w:"Digestion turns food into the fuel and building blocks of the body, and understanding nutrition is essential for lifelong health.",
  src:["Human digestive system","Stomach","Helicobacter pylori","Small intestine","Liver","Nutrition","Mediterranean diet"],
  q:[["Which enzyme in saliva begins digesting starch?","Amylase","Pepsin","Lipase","Trypsin"],
     ["What causes most stomach ulcers?","The bacterium Helicobacter pylori","Stress","Spicy food","Acid alone"],
     ["Where does most absorption of nutrients occur?","The small intestine","The stomach","The large intestine","The esophagus"],
     ["Which organ produces bile?","The liver","The pancreas","The gallbladder","The stomach"],
     ["What is the most common nutritional deficiency worldwide?","Iron deficiency","Vitamin C deficiency","Protein deficiency","Iodine deficiency"],
     ["How is BMI calculated?","Weight in kg divided by height in meters squared","Height divided by weight","Waist divided by hips","Calories divided by weight"]]},

{ t:"Kidneys, Hormones, and Homeostasis", s:"Keeping the body in balance",
  sec:[
  ["Homeostasis",[
    "Homeostasis is the maintenance of stable internal conditions despite changes outside, a concept developed by Claude Bernard, who wrote of the “milieu intérieur,” and named by Walter Cannon in 1926. The body regulates temperature (about 37°C), blood sugar, water and salt balance, blood pH, and blood pressure.",
    "Most homeostatic control uses negative feedback: when a variable moves away from its set point, responses push it back, like a thermostat. When we are too hot, we sweat and blood vessels in the skin widen; when too cold, we shiver and blood vessels narrow. Fever is the body deliberately raising its set point to fight infection."]],
  ["The kidneys",[
    "The two kidneys filter about 180 liters of blood plasma a day, producing about 1–2 liters of urine. Each contains about a million filtering units called nephrons, which remove wastes such as urea (from protein breakdown), excess salts, and water, while reabsorbing useful substances such as glucose.",
    "The kidneys regulate water balance under the control of antidiuretic hormone (ADH): when we are dehydrated, more ADH makes the kidneys conserve water, producing darker urine. Kidney failure is treated with dialysis, developed by Willem Kolff in the 1940s, or transplant; the first successful kidney transplant, between identical twins, was performed by Joseph Murray in Boston in 1954."]],
  ["The endocrine system",[
    "The endocrine system uses hormones, chemical messengers released by glands into the blood, to regulate growth, metabolism, reproduction, and mood. The pituitary gland at the base of the brain, controlled by the hypothalamus, is called the master gland because it controls many others.",
    "Other glands include the thyroid, whose hormones regulate metabolic rate; the adrenal glands, which release adrenaline in the “fight or flight” response, raising heart rate and blood sugar, and cortisol in response to stress; and the gonads, which produce sex hormones. Hormonal effects are slower and longer-lasting than nerve signals."]],
  ["Blood sugar and diabetes",[
    "Blood glucose is regulated by two hormones from the pancreas: insulin, which lowers blood sugar by helping cells absorb glucose, and glucagon, which raises it by releasing stored glucose. In 1921–1922 Frederick Banting, Charles Best, James Collip, and John Macleod isolated insulin at the University of Toronto, turning type 1 diabetes from a death sentence into a manageable condition.",
    "In type 1 diabetes, the immune system destroys insulin-producing cells; in type 2 diabetes, far more common, cells become resistant to insulin, linked to obesity and inactivity. Diabetes affects over 500 million people worldwide and can damage the eyes, kidneys, nerves, and heart."]],
  ["Reproduction",[
    "Human reproduction is sexual. The male reproductive system produces sperm in the testes, driven by testosterone; the female reproductive system produces eggs in the ovaries, and the menstrual cycle, about 28 days on average, is regulated by hormones including estrogen and progesterone. Fertilization usually occurs in a fallopian tube, and the embryo implants in the uterus.",
    "Pregnancy lasts about 40 weeks. The placenta nourishes the fetus and removes wastes. In 1978 Louise Brown, the first baby conceived by in vitro fertilization (IVF), was born in England; Robert Edwards received the 2010 Nobel Prize for developing IVF, which has since led to over 10 million births."]],
  ["Hormones in everyday life",[
    "Hormones influence sleep (melatonin), hunger (ghrelin and leptin), growth (growth hormone), and bonding (oxytocin). Puberty is triggered by hormonal changes that produce secondary sexual characteristics.",
    "Hormonal contraceptive pills, first approved in the United States in 1960, transformed family planning and society. Disorders of hormones include hypothyroidism and hyperthyroidism, Cushing's syndrome, and growth disorders."]]
  ],
  terms:[["Homeostasis","Maintaining stable internal conditions."],["Negative feedback","A response reversing a change."],["Nephron","A filtering unit of the kidney."],["Hormone","A chemical messenger carried in the blood."],["Pituitary gland","The master gland of the endocrine system."],["Insulin","The hormone that lowers blood sugar."],["Diabetes","A disorder of blood sugar regulation."]],
  w:"Homeostasis, the kidneys, and hormones keep the body in balance, and their failures cause common diseases such as diabetes.",
  src:["Homeostasis","Kidney","Nephron","Endocrine system","Insulin","Diabetes","In vitro fertilisation"],
  q:[["Who named homeostasis?","Walter Cannon","Claude Bernard","William Harvey","Frederick Banting"],
     ["What kind of feedback does most homeostasis use?","Negative feedback","Positive feedback","No feedback","Random feedback"],
     ["About how much blood plasma do the kidneys filter daily?","About 180 liters","About 5 liters","About 20 liters","About 1,000 liters"],
     ["Which gland is called the master gland?","The pituitary","The thyroid","The adrenal","The pancreas"],
     ["Which hormone lowers blood sugar?","Insulin","Glucagon","Adrenaline","Cortisol"],
     ["Who was the first baby born through IVF?","Louise Brown","Dolly","Henrietta Lacks","Lesley Brown"]]}

]});


/* ---- from sci-16.js ---- */
/* SCIENCES FOUNDATIONS, part 16: Unit 8 chapters 6-10 */
COURSES.sciences.units[7].ch.push(

{ t:"The Nervous System and the Brain", s:"Neurons, signals, and the mind",
  sec:[
  ["Organization",[
    "The nervous system detects changes, processes information, and coordinates responses. The central nervous system (CNS) consists of the brain and spinal cord; the peripheral nervous system connects them to the rest of the body. The autonomic nervous system controls involuntary functions such as heartbeat and digestion, with the sympathetic division preparing the body for action (“fight or flight”) and the parasympathetic division promoting “rest and digest.”",
    "Reflexes, such as pulling a hand from a hot stove, are rapid automatic responses routed through the spinal cord before the brain is even aware."]],
  ["Neurons",[
    "The basic cells of the nervous system are neurons, of which the human brain contains about 86 billion. A neuron has dendrites that receive signals, a cell body, and a long axon that transmits signals, often insulated by a fatty myelin sheath that speeds transmission to over 100 meters per second. Glial cells support and protect neurons.",
    "In the 1880s–1900s, Santiago Ramón y Cajal, using Camillo Golgi's staining method, showed that the nervous system is made of separate cells; they shared the 1906 Nobel Prize, though Golgi disagreed with Cajal's interpretation."]],
  ["Nerve impulses and synapses",[
    "Neurons transmit electrical signals called action potentials, rapid changes in voltage caused by sodium and potassium ions moving across the membrane, explained by Alan Hodgkin and Andrew Huxley in 1952 from experiments on the giant axon of the squid.",
    "Neurons communicate across tiny gaps called synapses by releasing chemical neurotransmitters, such as acetylcholine, dopamine, serotonin, GABA, and glutamate, which bind to receptors on the next cell. Many drugs, including antidepressants, anesthetics, caffeine, nicotine, and opioids, act on synapses."]],
  ["The brain",[
    "The human brain weighs about 1.4 kilograms and uses about 20 percent of the body's energy. The cerebrum, the largest part, divided into left and right hemispheres connected by the corpus callosum, handles thought, memory, language, and voluntary movement; its wrinkled outer layer is the cerebral cortex. The cerebellum coordinates balance and movement, and the brainstem controls vital functions such as breathing and heart rate.",
    "The cortex has four lobes: frontal (planning, decision-making, personality), parietal (touch and spatial awareness), temporal (hearing and memory), and occipital (vision). The case of Phineas Gage, a railroad worker whose personality changed after an iron rod pierced his frontal lobe in 1848, offered early evidence that brain regions have specific roles. Paul Broca identified a region essential for speech production in 1861."]],
  ["Memory and learning",[
    "The hippocampus is crucial for forming new long-term memories. The patient Henry Molaison (known as H.M.), whose hippocampi were removed in 1953 to treat epilepsy, could no longer form new long-term memories, transforming the understanding of memory. Learning involves strengthening connections between neurons, synaptic plasticity, summarized as “neurons that fire together wire together.”",
    "The brain remains plastic throughout life, able to reorganize after injury and through learning. Sleep plays an important role in consolidating memories."]],
  ["Brain disorders and research",[
    "Brain and nervous system disorders include stroke, epilepsy, Alzheimer's disease (the most common cause of dementia, involving buildup of amyloid plaques and tau tangles), Parkinson's disease (loss of dopamine-producing neurons), multiple sclerosis (damage to myelin), and mental illnesses such as depression, anxiety disorders, and schizophrenia.",
    "Tools such as EEG, which records electrical activity, and functional MRI, which tracks blood flow, allow scientists to observe the living brain. Neuroscience is one of the fastest-growing sciences, but how the brain produces consciousness remains one of the deepest unsolved questions."]]
  ],
  terms:[["Central nervous system","The brain and spinal cord."],["Neuron","A nerve cell."],["Myelin","A fatty sheath speeding nerve signals."],["Action potential","An electrical nerve impulse."],["Synapse","The junction between neurons."],["Neurotransmitter","A chemical messenger between neurons."],["Cerebral cortex","The wrinkled outer layer of the cerebrum."],["Hippocampus","A brain region essential for forming memories."]],
  w:"The nervous system and brain make thought, feeling, memory, and movement possible, and understanding them is key to treating many diseases.",
  src:["Nervous system","Neuron","Santiago Ramón y Cajal","Action potential","Synapse","Human brain","Henry Molaison"],
  q:[["About how many neurons does the human brain contain?","86 billion","1 billion","1 trillion","100 million"],
     ["Who showed the nervous system is made of separate cells?","Santiago Ramón y Cajal","Camillo Golgi alone","Paul Broca","Hodgkin and Huxley"],
     ["What are the gaps between neurons called?","Synapses","Axons","Dendrites","Myelin"],
     ["Which part of the brain coordinates balance?","The cerebellum","The frontal lobe","The hippocampus","The occipital lobe"],
     ["Whose personality changed after an iron rod pierced his frontal lobe?","Phineas Gage","Henry Molaison","Paul Broca","Louis Leborgne"],
     ["Which brain region is crucial for forming new memories?","The hippocampus","The brainstem","The cerebellum","The corpus callosum"]]},

{ t:"The Senses", s:"How we perceive the world",
  sec:[
  ["Sensory receptors",[
    "Senses detect information from the environment through specialized receptor cells that convert stimuli, such as light, sound, pressure, chemicals, and temperature, into nerve signals, which the brain interprets as perception. Humans have more than the traditional five senses: we also sense balance (vestibular sense), body position (proprioception), temperature, pain, and internal states such as hunger.",
    "Perception is an active process of interpretation, which is why optical illusions can fool us and why the brain fills in gaps."]],
  ["Vision",[
    "Vision is the dominant human sense. Light passes through the cornea, pupil, and lens and is focused on the retina, where about 120 million rods (for dim light) and about 6 million cones (for color) convert it into signals sent along the optic nerve. The fovea, a small central area packed with cones, provides sharp detail.",
    "Common vision problems include nearsightedness (myopia), increasingly common worldwide, farsightedness, astigmatism, and age-related presbyopia, all correctable with lenses. Cataracts cloud the lens, glaucoma damages the optic nerve, and macular degeneration affects central vision."]],
  ["Hearing and balance",[
    "Sound waves enter the ear canal and vibrate the eardrum. Three tiny bones in the middle ear, the malleus, incus, and stapes, amplify the vibrations and pass them to the fluid-filled cochlea in the inner ear, where hair cells tuned to different frequencies generate nerve signals. Hair cells damaged by loud noise do not regenerate in humans, causing permanent hearing loss.",
    "The inner ear also contains the vestibular system, three semicircular canals and other organs that detect head movement and gravity, maintaining balance. Conflicts between vision and the vestibular system can cause motion sickness. Cochlear implants can restore some hearing to deaf people."]],
  ["Taste and smell",[
    "Taste buds on the tongue detect five basic tastes: sweet, sour, salty, bitter, and umami (savory), identified by the Japanese chemist Kikunae Ikeda in 1908 from seaweed broth, the source of MSG. The old “tongue map” assigning tastes to regions is a myth; all areas detect all tastes.",
    "Most of what we call flavor comes from smell (olfaction), which is why food seems bland with a cold. Humans have about 400 kinds of olfactory receptors and can distinguish a very large number of odors. Richard Axel and Linda Buck won the 2004 Nobel Prize for discovering the olfactory receptor genes. Loss of smell was a common symptom of COVID-19."]],
  ["Touch and pain",[
    "The skin contains receptors for light touch, pressure, vibration, heat, cold, and pain. Fingertips and lips have dense receptors and are very sensitive. David Julius and Ardem Patapoutian won the 2021 Nobel Prize for discovering receptors for temperature and touch; Julius used capsaicin, the chemical that makes chili peppers hot, to find a heat receptor.",
    "Pain warns of injury; people born unable to feel pain often suffer severe injuries. Chronic pain, persisting long after injury, affects many people and is a major medical challenge."]],
  ["Animal senses",[
    "Other animals perceive the world very differently. Bees and birds see ultraviolet light; snakes such as pit vipers sense infrared heat; bats and dolphins use echolocation; sharks detect electric fields; and many birds and sea turtles sense Earth's magnetic field for navigation.",
    "Dogs have up to around 300 million olfactory receptor cells, compared with about 5–6 million in humans, allowing them to detect drugs, explosives, and even some diseases. Each species lives in its own sensory world, which the biologist Jakob von Uexküll called the Umwelt."]]
  ],
  terms:[["Receptor","A cell that detects a stimulus."],["Retina","The light-sensitive layer of the eye."],["Rods and cones","Receptors for dim light and color."],["Cochlea","The inner-ear organ of hearing."],["Vestibular system","The inner-ear system for balance."],["Umami","The savory taste."],["Proprioception","The sense of body position."]],
  w:"The senses are our windows on the world, and understanding them explains perception, illusions, and how to protect our sight and hearing.",
  src:["Sense","Visual perception","Retina","Cochlea","Vestibular system","Umami","Olfaction"],
  q:[["Which receptor cells detect color?","Cones","Rods","Hair cells","Taste buds"],
     ["Which bones amplify sound in the middle ear?","Malleus, incus, and stapes","Femur, tibia, and fibula","Radius and ulna","Atlas and axis"],
     ["What does the vestibular system control?","Balance","Hearing","Taste","Vision"],
     ["Who identified umami?","Kikunae Ikeda","David Julius","Linda Buck","Ardem Patapoutian"],
     ["Is the tongue map of taste regions accurate?","No, all areas detect all tastes","Yes, exactly","Only for sweet","Only for bitter"],
     ["What chemical helped David Julius find a heat receptor?","Capsaicin","Menthol","Caffeine","Nicotine"]]},

{ t:"The Immune System and Vaccines", s:"How the body defends itself",
  sec:[
  ["Lines of defense",[
    "The immune system protects the body against pathogens: bacteria, viruses, fungi, and parasites. The first line of defense includes barriers such as skin, mucus, stomach acid, and tears containing antibacterial enzymes.",
    "If pathogens break through, the innate immune system responds quickly and generally: inflammation brings blood and immune cells to the site, causing redness, heat, swelling, and pain; white blood cells called phagocytes, such as neutrophils and macrophages, engulf invaders, a process discovered by Élie Metchnikoff in the 1880s; and fever may slow pathogens' growth."]],
  ["Adaptive immunity",[
    "The adaptive immune system mounts specific, targeted responses and remembers past invaders. Its main cells are lymphocytes: B cells produce antibodies, Y-shaped proteins that bind to specific molecules called antigens on pathogens, marking them for destruction or neutralizing them; T cells include helper T cells, which coordinate the response, and cytotoxic (killer) T cells, which destroy infected cells.",
    "After an infection, memory cells remain, allowing a faster, stronger response if the same pathogen returns. This is why people rarely get measles twice. The body can make an almost limitless variety of antibodies through the shuffling of gene segments, discovered by Susumu Tonegawa."]],
  ["Vaccines",[
    "Vaccines train the immune system by exposing it to harmless forms or parts of a pathogen, producing memory without causing disease. In 1796 the English physician Edward Jenner showed that inoculating people with cowpox protected them against smallpox; the word vaccine comes from the Latin vacca, “cow.” Louis Pasteur developed vaccines for chicken cholera, anthrax, and rabies in the 1880s.",
    "Jonas Salk's injected polio vaccine (1955) and Albert Sabin's oral vaccine nearly eliminated polio worldwide. Smallpox was declared eradicated in 1980, the first human disease wiped out. Vaccines prevent millions of deaths every year; herd immunity, when enough people are immune, protects those who cannot be vaccinated."]],
  ["Vaccine safety and hesitancy",[
    "Vaccines undergo extensive testing in clinical trials and continued monitoring. Serious side effects are rare, and the benefits far outweigh the risks. A fraudulent 1998 study by Andrew Wakefield claiming a link between the MMR vaccine and autism was retracted, and he lost his medical license; large studies of millions of children have found no link.",
    "Vaccine hesitancy has contributed to outbreaks of measles and other preventable diseases. The rapid development of COVID-19 vaccines in 2020 built on decades of research on mRNA and coronavirus proteins."]],
  ["When immunity goes wrong",[
    "Allergies are overreactions of the immune system to harmless substances such as pollen, peanuts, or dust mites; severe reactions (anaphylaxis) can be life-threatening and are treated with epinephrine. Autoimmune diseases occur when the immune system attacks the body's own tissues, as in type 1 diabetes, rheumatoid arthritis, multiple sclerosis, and lupus.",
    "Immunodeficiency leaves people vulnerable to infection, as in AIDS, caused by HIV destroying helper T cells. Organ transplants require drugs to suppress rejection by the immune system."]],
  ["Harnessing immunity",[
    "Modern medicine increasingly uses the immune system as a treatment. Monoclonal antibodies, laboratory-made antibodies developed by César Milstein and Georges Köhler in 1975, treat cancers, autoimmune diseases, and infections.",
    "Cancer immunotherapy unleashes the immune system against tumors: James Allison and Tasuku Honjo received the 2018 Nobel Prize for discovering checkpoint inhibitors, and CAR-T therapy engineers patients' own T cells to attack cancer."]]
  ],
  terms:[["Pathogen","A disease-causing organism."],["Innate immunity","Rapid, general defenses."],["Adaptive immunity","Specific responses with memory."],["Antibody","A protein that binds to a specific antigen."],["Antigen","A molecule recognized by the immune system."],["Vaccine","A preparation that trains immune memory."],["Herd immunity","Protection of a population when many are immune."]],
  w:"The immune system protects us from disease, and vaccines, which harness it, are among the greatest life-saving achievements in history.",
  src:["Immune system","Innate immune system","Adaptive immune system","Antibody","Vaccine","Edward Jenner","Smallpox"],
  q:[["Who discovered phagocytes?","Élie Metchnikoff","Edward Jenner","Louis Pasteur","Robert Koch"],
     ["Which cells produce antibodies?","B cells","Helper T cells","Red blood cells","Platelets"],
     ["Who developed the first vaccine against smallpox using cowpox?","Edward Jenner","Louis Pasteur","Jonas Salk","Robert Koch"],
     ["What does the Latin vacca mean?","Cow","Cure","Defense","Poison"],
     ["Who developed the injected polio vaccine in 1955?","Jonas Salk","Albert Sabin","Edward Jenner","Alexander Fleming"],
     ["What is it called when the immune system attacks the body's own tissues?","Autoimmune disease","Allergy","Immunodeficiency","Vaccination"]]},

{ t:"Medicine Through Time", s:"From Hippocrates to modern medicine",
  sec:[
  ["Ancient medicine",[
    "Ancient Egyptian medical papyri, such as the Edwin Smith Papyrus (about 1600 BCE, copying older texts), describe surgical treatments for wounds and fractures. In ancient Greece, Hippocrates (about 460–370 BCE) and his followers sought natural rather than supernatural causes of disease, emphasized observation, and promoted ethical principles; the Hippocratic Oath is still echoed by doctors today.",
    "Greek medicine taught that health depended on a balance of four humors, blood, phlegm, yellow bile, and black bile, a theory systematized by Galen (2nd century CE) that dominated Western medicine for over 1,500 years and justified treatments such as bloodletting. Traditional Chinese and Indian Ayurvedic medicine developed their own systems."]],
  ["Medieval and Islamic medicine",[
    "In the Islamic world, physicians advanced medicine significantly. Al-Razi (Rhazes) distinguished smallpox from measles around 900 CE, and Ibn Sina (Avicenna) wrote The Canon of Medicine (1025), a medical encyclopedia used in European universities for centuries. Hospitals (bimaristans) in Baghdad, Damascus, and Cairo provided care and teaching.",
    "In medieval Europe, monasteries preserved medical knowledge, and the medical school at Salerno in Italy became famous. The Black Death of 1347–1351 exposed medicine's helplessness against plague."]],
  ["Anatomy and the Renaissance",[
    "Andreas Vesalius's On the Fabric of the Human Body (1543), based on dissections, corrected many of Galen's errors. William Harvey described blood circulation in 1628. Ambroise Paré, a French barber-surgeon, improved wound treatment and amputation techniques.",
    "Yet until the 19th century, physicians had few effective treatments, and hospitals were often dangerous places."]],
  ["The 19th-century revolution",[
    "Several breakthroughs transformed medicine in the 19th century. Anesthesia, with ether demonstrated publicly by William Morton in Boston in 1846 and chloroform soon after, made painless surgery possible. Ignaz Semmelweis showed in 1847 that handwashing by doctors dramatically reduced deaths from childbed fever, though he was ridiculed.",
    "The germ theory of Pasteur and Koch identified the causes of infectious diseases. Joseph Lister introduced antiseptic surgery with carbolic acid in 1867, sharply reducing infections. Florence Nightingale reformed nursing and hospital sanitation during the Crimean War. John Snow's work on cholera founded epidemiology."]],
  ["The 20th century",[
    "The 20th century brought vitamins, insulin (1922), antibiotics beginning with penicillin, vaccines for polio, measles, and other diseases, blood transfusion, organ transplants, chemotherapy, and medical imaging from X-rays to CT and MRI scans. Life expectancy in wealthy countries rose from about 50 years in 1900 to about 80.",
    "The randomized controlled trial became the standard for testing treatments, and evidence-based medicine emphasized using the best research to guide care."]],
  ["Medicine today",[
    "Modern medicine includes minimally invasive and robotic surgery, targeted cancer therapies, immunotherapy, gene therapy, mRNA vaccines, and medicine personalized by genetic testing. Artificial intelligence is being applied to diagnosis and drug discovery.",
    "Challenges remain: chronic diseases of aging, antibiotic resistance, unequal access to care between and within countries, rising costs, mental health, and emerging infectious diseases. Medical ethics, from informed consent, a principle strengthened after the Nuremberg trials and the Tuskegee syphilis study scandal, to questions about genetic editing, remains central."]]
  ],
  terms:[["Hippocratic Oath","An ancient ethical code for physicians."],["Four humors","The ancient theory of bodily fluids governing health."],["The Canon of Medicine","Ibn Sina's influential medical encyclopedia."],["Anesthesia","Drugs that prevent pain during surgery."],["Antiseptic surgery","Surgery using chemicals to prevent infection."],["Evidence-based medicine","Basing care on the best research evidence."],["Informed consent","Patients' agreement after understanding risks."]],
  w:"The history of medicine shows how science replaced ancient theories with evidence, transforming human health and life expectancy.",
  src:["History of medicine","Hippocrates","Humorism","The Canon of Medicine","Ignaz Semmelweis","Joseph Lister","Tuskegee syphilis study"],
  q:[["Who is considered the father of Western medicine?","Hippocrates","Galen","Ibn Sina","Vesalius"],
     ["What were the four humors?","Blood, phlegm, yellow bile, and black bile","Earth, air, fire, and water","Heart, lungs, liver, and brain","Hot, cold, wet, and dry"],
     ["Who wrote The Canon of Medicine?","Ibn Sina (Avicenna)","Al-Razi","Galen","Maimonides"],
     ["Who showed handwashing reduced childbed fever?","Ignaz Semmelweis","Joseph Lister","Louis Pasteur","Florence Nightingale"],
     ["Who introduced antiseptic surgery with carbolic acid?","Joseph Lister","William Morton","Ambroise Paré","John Snow"],
     ["Who first publicly demonstrated ether anesthesia in 1846?","William Morton","Crawford Long","James Simpson","Horace Wells"]]},

{ t:"Public Health and Ecology of Disease", s:"Health for whole populations",
  sec:[
  ["What public health is",[
    "Public health focuses on preventing disease and promoting health across entire populations, rather than treating individuals. Its tools include clean water and sanitation, vaccination, disease surveillance, health education, food safety, workplace safety, and policies on tobacco, alcohol, and pollution.",
    "Many of the largest gains in life expectancy have come from public health measures. In the 19th century, sewer systems, such as Joseph Bazalgette's London sewers built after the “Great Stink” of 1858, and clean water supplies dramatically reduced cholera and typhoid."]],
  ["Epidemiology",[
    "Epidemiology studies the patterns, causes, and effects of disease in populations. John Snow's mapping of cholera cases around the Broad Street pump in London in 1854 is a founding example. Epidemiologists track outbreaks, identify risk factors, and evaluate interventions.",
    "Key concepts include incidence (new cases over time), prevalence (existing cases at a time), and the basic reproduction number R₀, the average number of people infected by one case in a fully susceptible population: about 12–18 for measles, and around 1–2 for seasonal flu. An epidemic grows when each case infects more than one other person."]],
  ["Global health",[
    "The World Health Organization, founded in 1948, coordinates international health efforts. Major achievements include smallpox eradication, the near-eradication of polio, and large reductions in child mortality: deaths of children under five fell from about 12.8 million in 1990 to about 5 million in the early 2020s, thanks to vaccines, oral rehydration therapy, bed nets against malaria, and better nutrition.",
    "Great inequalities remain: life expectancy varies from over 80 years in Japan and much of Europe to around 55–60 in some sub-Saharan African countries. Diseases of poverty, such as malaria, tuberculosis, and diarrheal disease, still kill millions."]],
  ["Non-communicable diseases",[
    "Today, non-communicable diseases, heart disease, stroke, cancer, chronic respiratory disease, and diabetes, cause about 70 percent of deaths worldwide. Major risk factors include tobacco, unhealthy diets, physical inactivity, harmful alcohol use, and air pollution, which causes several million premature deaths a year.",
    "Public health measures such as tobacco taxes and smoking bans, seat belt laws, and reducing salt and trans fats in food have saved many lives."]],
  ["One Health",[
    "The One Health approach recognizes that human health is connected to the health of animals and the environment. Most emerging infectious diseases are zoonotic, and factors such as deforestation, wildlife trade, intensive livestock farming, and climate change increase the risk of new diseases spilling over to humans.",
    "Climate change is expanding the range of disease-carrying mosquitoes, such as those transmitting dengue and malaria, and causing deadly heat waves."]],
  ["Pandemic preparedness",[
    "The COVID-19 pandemic showed both the power of modern science, with genomic sequencing within weeks and vaccines within a year, and the weaknesses of global preparedness, including shortages, misinformation, and unequal vaccine distribution.",
    "Preparing for future pandemics involves surveillance of emerging pathogens, stockpiles, rapid vaccine platforms, strong health systems, international cooperation, and public trust in science, lessons central to public health in the 21st century."]]
  ],
  terms:[["Public health","Protecting and improving the health of populations."],["Epidemiology","The study of disease patterns in populations."],["Incidence and prevalence","New cases vs. existing cases."],["R₀","The basic reproduction number of an infection."],["World Health Organization","The UN agency for health, founded in 1948."],["Non-communicable disease","A chronic disease not spread by infection."],["One Health","Linking human, animal, and environmental health."]],
  w:"Public health protects whole populations and has saved more lives than almost any other field, while new challenges such as pandemics and chronic disease demand continued effort.",
  src:["Public health","Epidemiology","Basic reproduction number","World Health Organization","Non-communicable disease","One Health","Great Stink"],
  q:[["Who built London's sewers after the Great Stink?","Joseph Bazalgette","John Snow","Edwin Chadwick","Florence Nightingale"],
     ["What does R₀ measure?","The average number of people infected by one case","The death rate","The number of vaccines","The incubation period"],
     ["What is the approximate R₀ of measles?","12–18","1–2","3–4","50"],
     ["When was the World Health Organization founded?","1948","1919","1980","1965"],
     ["What share of deaths worldwide are from non-communicable diseases?","About 70 percent","About 20 percent","About 40 percent","About 95 percent"],
     ["What does One Health link?","Human, animal, and environmental health","Doctors and nurses","Rich and poor countries","Mind and body"]]}

);


/* ---- from sci-17.js ---- */
/* SCIENCES FOUNDATIONS, part 17: Unit 9 Astronomy and Space, chapters 1-5 */
COURSES.sciences.units.push({ t:"Astronomy and Space", ch:[

{ t:"The Night Sky", s:"Stars, constellations, and celestial motions",
  sec:[
  ["The oldest science",[
    "Astronomy, the study of celestial objects and the universe, is one of the oldest sciences. Ancient peoples tracked the Sun, Moon, and stars to create calendars, time agricultural seasons, navigate, and practice religion. Monuments such as Stonehenge and the pyramids of Giza align with astronomical events. Babylonian astronomers kept detailed records and predicted eclipses; Chinese astronomers recorded supernovae, including one in 1054 that created the Crab Nebula.",
    "Astronomy is distinct from astrology, the belief that celestial positions influence human affairs, which has no scientific support."]],
  ["Constellations",[
    "Constellations are patterns of stars that cultures have named after mythological figures, animals, and objects. The International Astronomical Union officially recognizes 88 constellations, dividing the entire sky into regions, such as Orion, Ursa Major (containing the Big Dipper or Plough), Cassiopeia, and Scorpius. The stars in a constellation are usually at very different distances and unrelated; they only appear close from Earth.",
    "The zodiac is the band of 12 or 13 constellations through which the Sun appears to move during the year. Many bright stars have Arabic names from medieval Islamic astronomy, such as Aldebaran, Betelgeuse, and Rigel."]],
  ["Daily and yearly motions",[
    "Because Earth rotates west to east, the Sun, Moon, and stars appear to rise in the east and set in the west. Stars near the celestial poles circle them without setting. In the Northern Hemisphere, Polaris, the North Star, lies almost directly above the North Pole and barely moves, making it valuable for navigation; its altitude above the horizon equals the observer's latitude.",
    "As Earth orbits the Sun, different constellations are visible at night in different seasons: Orion dominates winter evenings in the Northern Hemisphere. Earth's axis also slowly wobbles like a spinning top, a motion called precession, taking about 26,000 years, so Polaris will not always be the pole star."]],
  ["Phases of the Moon",[
    "The Moon does not produce light; it reflects sunlight. As it orbits Earth about every 29.5 days, we see different portions of its sunlit half, producing phases: new moon (invisible), waxing crescent, first quarter, waxing gibbous, full moon, waning gibbous, last quarter, and waning crescent.",
    "The Moon always shows Earth the same face because it rotates once per orbit, tidal locking. The far side is not permanently dark; it simply faces away from Earth. It was first photographed by the Soviet probe Luna 3 in 1959, and China's Chang'e 4 made the first landing there in 2019."]],
  ["Eclipses",[
    "A solar eclipse occurs when the Moon passes between the Sun and Earth, casting its shadow on Earth. In a total solar eclipse, the Moon completely covers the Sun's disk, revealing the glowing outer atmosphere, the corona, for a few minutes along a narrow path; this happens because the Sun is about 400 times larger than the Moon but also about 400 times farther away, a remarkable coincidence.",
    "A lunar eclipse occurs when Earth passes between the Sun and Moon, and Earth's shadow falls on the Moon, often turning it coppery red, a “blood moon,” because Earth's atmosphere bends red light onto it. Eclipses do not happen every month because the Moon's orbit is tilted about 5 degrees relative to Earth's."]],
  ["Light pollution and stargazing",[
    "Under a truly dark sky, a person can see a few thousand stars with the naked eye and the band of the Milky Way. Light pollution from artificial lighting now hides the Milky Way from about a third of humanity and most people in Europe and North America.",
    "Dark-sky reserves protect natural darkness, which also benefits wildlife. Stargazing requires no equipment: with binoculars, one can see the Moon's craters, Jupiter's four largest moons, and star clusters such as the Pleiades."]]
  ],
  terms:[["Astronomy","The scientific study of celestial objects."],["Constellation","An officially defined region and pattern of stars."],["Polaris","The North Star."],["Precession","The slow wobble of Earth's axis."],["Lunar phases","The changing appearance of the Moon."],["Solar eclipse","The Moon blocking the Sun."],["Lunar eclipse","Earth's shadow falling on the Moon."]],
  w:"Understanding the night sky connects us to the oldest science and explains the motions of the Sun, Moon, and stars we see every day.",
  src:["Astronomy","Constellation","Polaris","Axial precession","Lunar phase","Solar eclipse","Light pollution"],
  q:[["How many official constellations are there?","88","12","48","100"],
     ["Which star lies almost above Earth's North Pole?","Polaris","Sirius","Betelgeuse","Vega"],
     ["How long does Earth's precession take?","About 26,000 years","About 1,000 years","About 100 years","About 1 million years"],
     ["Which probe first photographed the Moon's far side?","Luna 3","Apollo 8","Chang'e 4","Ranger 7"],
     ["What causes a solar eclipse?","The Moon passing between Sun and Earth","Earth passing between Sun and Moon","Clouds","Sunspots"],
     ["Why does the Moon turn red in a lunar eclipse?","Earth's atmosphere bends red light onto it","The Moon heats up","Dust on the Moon","Reflected ocean light"]]},

{ t:"Telescopes and the Tools of Astronomy", s:"Extending our vision",
  sec:[
  ["Galileo to Newton",[
    "The telescope was invented in the Netherlands around 1608; Hans Lippershey applied for a patent. Galileo built his own in 1609 and transformed astronomy with his discoveries. Refracting telescopes use lenses to gather and focus light, but large lenses are heavy and produce color fringes.",
    "Isaac Newton built the first practical reflecting telescope in 1668, using a curved mirror instead of a lens. All large research telescopes today are reflectors. A telescope's most important property is the size of its aperture, the diameter of its main lens or mirror: larger apertures gather more light and reveal fainter, more distant objects in greater detail."]],
  ["Great observatories",[
    "William Herschel, using large telescopes he built himself, discovered Uranus in 1781, the first planet discovered since ancient times. The 100-inch Hooker Telescope at Mount Wilson, California, completed in 1917, allowed Edwin Hubble to discover other galaxies and the expansion of the universe.",
    "Modern giant telescopes, such as the twin 10-meter Keck telescopes in Hawaii and the Very Large Telescope in Chile's Atacama Desert, use segmented mirrors and adaptive optics, which correct for atmospheric blurring. The Extremely Large Telescope, with a 39-meter mirror, is under construction in Chile. Observatories are placed on high, dry mountains far from city lights."]],
  ["Space telescopes",[
    "Earth's atmosphere blurs images and blocks much of the electromagnetic spectrum, so astronomers launch telescopes into space. The Hubble Space Telescope, launched in 1990, initially had a flawed mirror, corrected by astronauts in 1993, and went on to transform astronomy, measuring the expansion rate of the universe and capturing iconic images such as the Pillars of Creation and the Hubble Deep Field.",
    "The James Webb Space Telescope, launched on 25 December 2021 and orbiting about 1.5 million kilometers from Earth, has a 6.5-meter gold-coated segmented mirror and observes in infrared, seeing some of the earliest galaxies and studying exoplanet atmospheres. Other space observatories have studied X-rays (Chandra) and the cosmic microwave background (Planck)."]],
  ["Radio astronomy",[
    "In 1932 Karl Jansky discovered radio waves from the Milky Way, founding radio astronomy. Radio telescopes, giant dishes and arrays of antennas, detect cold gas, pulsars, quasars, and the cosmic microwave background. Linking telescopes across continents creates a virtual Earth-sized telescope, as the Event Horizon Telescope did to image black holes.",
    "The Arecibo Observatory in Puerto Rico had a 305-meter dish for over 50 years until its collapse in 2020; China's FAST telescope, with a 500-meter dish, completed in 2016, is now the largest single-dish radio telescope. The Square Kilometre Array is under construction in Australia and South Africa."]],
  ["Spectroscopy and distances",[
    "Spectroscopy, splitting light into its wavelengths, reveals the composition, temperature, motion, and magnetic fields of stars and galaxies. Astronomers measure distances with a “cosmic distance ladder”: parallax, the apparent shift of nearby stars as Earth orbits the Sun, first measured by Friedrich Bessel in 1838; standard candles such as Cepheid variable stars, whose brightness pulsations reveal their true luminosity, as Henrietta Swan Leavitt discovered in 1912; and Type Ia supernovae for the most distant galaxies.",
    "The European Gaia mission, launched in 2013, has measured the positions and motions of about 2 billion stars."]],
  ["New messengers",[
    "Astronomy now uses more than light. Neutrino detectors such as IceCube, buried in Antarctic ice, detect neutrinos from the Sun and distant cosmic events. Gravitational-wave observatories such as LIGO and Virgo detect ripples in spacetime from colliding black holes and neutron stars.",
    "In 2017, astronomers detected both gravitational waves and light from the same neutron star collision, beginning “multi-messenger astronomy,” and confirming that such collisions produce heavy elements such as gold."]]
  ],
  terms:[["Refracting telescope","A telescope using lenses."],["Reflecting telescope","A telescope using mirrors."],["Aperture","The diameter of a telescope's main lens or mirror."],["Adaptive optics","Technology correcting atmospheric blurring."],["Radio astronomy","Studying the universe through radio waves."],["Parallax","The apparent shift used to measure stellar distances."],["Cepheid variable","A pulsating star used to measure distances."]],
  w:"Telescopes and other tools let astronomers see across the spectrum and measure the universe, turning points of light into a detailed cosmic map.",
  src:["Telescope","Reflecting telescope","Hubble Space Telescope","James Webb Space Telescope","Radio astronomy","Stellar parallax","Henrietta Swan Leavitt"],
  q:[["Who built the first practical reflecting telescope?","Isaac Newton","Galileo","William Herschel","Hans Lippershey"],
     ["Who discovered Uranus in 1781?","William Herschel","Galileo","Johann Galle","Edmond Halley"],
     ["When was the Hubble Space Telescope launched?","1990","1977","2001","2021"],
     ["What does the James Webb Space Telescope mainly observe?","Infrared","X-rays","Radio waves","Ultraviolet"],
     ["Who discovered the period-luminosity relation of Cepheids?","Henrietta Swan Leavitt","Annie Jump Cannon","Edwin Hubble","Cecilia Payne"],
     ["Who first measured stellar parallax in 1838?","Friedrich Bessel","William Herschel","Tycho Brahe","Edwin Hubble"]]},

{ t:"The Sun", s:"Our star",
  sec:[
  ["A typical star",[
    "The Sun is a medium-sized, middle-aged star, a ball of hot plasma about 1.39 million kilometers across, roughly 109 times Earth's diameter, containing about 99.86 percent of the mass of the solar system. It is about 4.6 billion years old and composed of about 73 percent hydrogen and 25 percent helium by mass.",
    "Its light takes about 8 minutes 20 seconds to reach Earth. The Sun is classified as a G-type main-sequence star, a yellow dwarf, though it actually emits white light."]],
  ["The power source",[
    "In the 19th century, scientists could not explain how the Sun had shone for so long; chemical burning would exhaust it in thousands of years. The answer came from nuclear physics: in the 1920s Arthur Eddington suggested that the Sun is powered by fusion, and in 1938–1939 Hans Bethe worked out the details.",
    "In the core, at about 15 million °C and enormous pressure, hydrogen nuclei fuse into helium through the proton-proton chain, converting about 4 million tonnes of mass into energy every second, according to E = mc². Energy takes tens of thousands of years or more to work its way out from the core before escaping as sunlight."]],
  ["Layers",[
    "Energy moves outward through the radiative zone, where it is carried by light, and the convective zone, where hot plasma rises and cooler plasma sinks. The visible surface, the photosphere, about 5,500°C, has a granulated appearance from convection cells.",
    "Above it lie the chromosphere and the corona, the Sun's outer atmosphere, visible during total eclipses, which mysteriously reaches temperatures over a million degrees, far hotter than the surface. NASA's Parker Solar Probe, launched in 2018, has flown through the corona, becoming the closest and fastest human-made object."]],
  ["Sunspots and the solar cycle",[
    "Sunspots are cooler, darker regions on the photosphere caused by intense magnetic fields; Galileo and others observed them in the early 1600s. Their number rises and falls in an approximately 11-year solar cycle. During the Maunder Minimum (about 1645–1715), very few sunspots were seen, coinciding with part of the Little Ice Age.",
    "Solar flares are sudden bursts of energy, and coronal mass ejections hurl billions of tonnes of plasma into space. The Carrington Event of 1859, the most powerful geomagnetic storm on record, caused auroras visible near the tropics and sparks in telegraph systems."]],
  ["Space weather",[
    "The Sun continuously emits the solar wind, a stream of charged particles. When solar storms reach Earth, they interact with its magnetic field, producing auroras and geomagnetic storms that can disrupt satellites, GPS, radio communications, and power grids; a 1989 storm caused a blackout across Quebec. Space weather forecasting has become important for modern technology.",
    "The heliosphere, the bubble of solar wind around the solar system, extends far beyond Pluto; Voyager 1 crossed its boundary into interstellar space in 2012."]],
  ["The Sun's future",[
    "The Sun is gradually brightening, about 10 percent every billion years, which will make Earth uninhabitable in perhaps a billion years by causing the oceans to evaporate. In about 5 billion years, when the core runs out of hydrogen, the Sun will swell into a red giant, possibly engulfing Mercury, Venus, and perhaps Earth.",
    "It will then shed its outer layers as a glowing planetary nebula, leaving behind a white dwarf, a hot, dense remnant about the size of Earth, which will slowly cool over trillions of years. Never look directly at the Sun without proper protection, as it can cause permanent eye damage."]]
  ],
  terms:[["Main-sequence star","A star fusing hydrogen in its core."],["Fusion","Joining hydrogen nuclei into helium, powering the Sun."],["Photosphere","The Sun's visible surface."],["Corona","The Sun's hot outer atmosphere."],["Sunspot","A cooler, magnetically active region."],["Solar cycle","The approximately 11-year cycle of solar activity."],["Solar wind","The stream of charged particles from the Sun."]],
  w:"The Sun powers life on Earth, and understanding it explains how stars work, why auroras glow, and how space weather affects our technology.",
  src:["Sun","Stellar nucleosynthesis","Proton–proton chain","Corona","Sunspot","Solar cycle","Carrington Event"],
  q:[["What share of the solar system's mass is in the Sun?","About 99.86 percent","About 50 percent","About 90 percent","About 75 percent"],
     ["Who worked out how fusion powers the Sun?","Hans Bethe","Albert Einstein","Arthur Eddington alone","Enrico Fermi"],
     ["What is the temperature of the Sun's core?","About 15 million °C","About 5,500 °C","About 1 million °C","About 100,000 °C"],
     ["How long is the solar cycle?","About 11 years","About 1 year","About 100 years","About 26,000 years"],
     ["What was the most powerful geomagnetic storm on record?","The Carrington Event","The Maunder Minimum","The Tunguska event","The 1989 Quebec storm"],
     ["What will the Sun become at the end of its life?","A white dwarf","A black hole","A neutron star","A supernova"]]},

{ t:"The Solar System and the Inner Planets", s:"Mercury, Venus, Earth, the Moon, and Mars",
  sec:[
  ["Formation",[
    "The solar system formed about 4.6 billion years ago from a collapsing cloud of gas and dust, the solar nebula, as proposed in early forms by Immanuel Kant and Pierre-Simon Laplace in the 18th century. Most material fell to the center to form the Sun; the rest flattened into a spinning disk, in which dust and ice clumped into planetesimals and then planets.",
    "Near the hot Sun, only rock and metal could condense, forming the small, rocky terrestrial planets. Farther out, beyond the “frost line,” ices could also condense, allowing planets to grow large enough to capture vast amounts of gas, forming the giant planets. This is why all planets orbit in the same direction in nearly the same plane."]],
  ["The planets",[
    "The solar system has eight planets: the four inner, rocky planets, Mercury, Venus, Earth, and Mars, and the four outer giants, Jupiter, Saturn, Uranus, and Neptune. A mnemonic is “My Very Educated Mother Just Served Us Nachos.” Distances are measured in astronomical units (AU), the average Earth-Sun distance of about 150 million kilometers; Neptune orbits at about 30 AU.",
    "In 2006 the International Astronomical Union defined a planet as a body that orbits the Sun, is massive enough to be round, and has cleared its orbital neighborhood; Pluto, which shares its region with many other objects, was reclassified as a dwarf planet."]],
  ["Mercury and Venus",[
    "Mercury, the smallest planet and closest to the Sun, has a heavily cratered surface, almost no atmosphere, and extreme temperatures from about 430°C by day to about −180°C at night. Its year lasts 88 Earth days.",
    "Venus, nearly Earth's size, is the hottest planet, with surface temperatures around 465°C, hot enough to melt lead, because its thick carbon dioxide atmosphere creates a runaway greenhouse effect; surface pressure is about 90 times Earth's, and clouds of sulfuric acid cover it. Venus rotates backward and very slowly; its day is longer than its year. It is the brightest planet in our sky, often called the morning or evening star."]],
  ["Earth and the Moon",[
    "Earth is the only known planet with liquid water on its surface and life. Its magnetic field and atmosphere protect life from radiation, and plate tectonics recycles its crust.",
    "The Moon, about a quarter of Earth's diameter, is unusually large compared with its planet. The leading theory, the giant-impact hypothesis, proposes that it formed about 4.5 billion years ago when a Mars-sized body, sometimes called Theia, collided with the young Earth, ejecting debris that coalesced into the Moon. The Moon's dark plains, maria (“seas”), are ancient lava flows; its surface is covered with craters because it lacks atmosphere and erosion."]],
  ["Mars",[
    "Mars, the “Red Planet,” owes its color to iron oxide (rust) in its dust. It has a thin carbon dioxide atmosphere, polar ice caps of water and carbon dioxide ice, and two small moons, Phobos and Deimos. It hosts Olympus Mons, the tallest volcano in the solar system, about 22 kilometers high, and Valles Marineris, a canyon system over 4,000 kilometers long.",
    "Mars once had rivers, lakes, and possibly oceans; rovers such as Spirit, Opportunity, Curiosity (landed 2012), and Perseverance (landed 2021) have found ancient lakebeds and minerals formed in water. Perseverance is collecting samples to search for signs of ancient life, and the small helicopter Ingenuity made the first powered flight on another planet in 2021."]],
  ["Comparing worlds",[
    "Comparing the terrestrial planets helps scientists understand Earth. Venus shows how a runaway greenhouse effect can make a planet uninhabitable; Mars shows how a planet can lose its atmosphere and water, partly because it lost its global magnetic field.",
    "Earth's position in the habitable zone, where temperatures allow liquid water, its size, magnetic field, and plate tectonics may all contribute to its ability to sustain life."]]
  ],
  terms:[["Solar nebula","The cloud from which the solar system formed."],["Terrestrial planet","A small, rocky planet."],["Astronomical unit","The average Earth-Sun distance, about 150 million km."],["Dwarf planet","A round body that has not cleared its orbit, such as Pluto."],["Runaway greenhouse effect","Extreme warming as on Venus."],["Giant-impact hypothesis","The Moon formed from a collision with early Earth."],["Olympus Mons","The tallest volcano in the solar system, on Mars."]],
  w:"The inner planets show how worlds form and evolve, and comparing them reveals what makes Earth uniquely habitable.",
  src:["Solar System","Formation and evolution of the Solar System","IAU definition of planet","Venus","Giant-impact hypothesis","Mars","Perseverance (rover)"],
  q:[["How old is the solar system?","About 4.6 billion years","About 13.8 billion years","About 1 billion years","About 10,000 years"],
     ["Which is the hottest planet?","Venus","Mercury","Mars","Jupiter"],
     ["When was Pluto reclassified as a dwarf planet?","2006","1930","1999","2015"],
     ["What is the leading theory for the Moon's origin?","A giant impact","Capture by Earth's gravity","Formation alongside Earth","Ejection from the Sun"],
     ["What is the tallest volcano in the solar system?","Olympus Mons","Mauna Kea","Mount Everest","Maxwell Montes"],
     ["Which made the first powered flight on another planet?","Ingenuity","Curiosity","Perseverance","Sojourner"]]},

{ t:"The Outer Planets and Small Worlds", s:"Giants, moons, dwarf planets, asteroids, and comets",
  sec:[
  ["Jupiter",[
    "Jupiter is the largest planet, more than twice as massive as all the other planets combined, about 11 times Earth's diameter. A gas giant made mostly of hydrogen and helium, it has no solid surface. Its Great Red Spot is a giant storm larger than Earth that has raged for at least 190 years and possibly since the 1660s. Jupiter rotates in under 10 hours, the fastest of any planet.",
    "Jupiter has about 95 known moons. The four largest, discovered by Galileo in 1610, are Io, the most volcanically active body in the solar system; Europa, with an ice shell over a liquid water ocean, a prime target in the search for life; Ganymede, the largest moon in the solar system, larger than Mercury; and Callisto."]],
  ["Saturn",[
    "Saturn, the second-largest planet, is famous for its spectacular rings, made of countless pieces of ice and rock ranging from dust to house-sized chunks, extending hundreds of thousands of kilometers but typically only about 10 meters to a kilometer thick. Saturn is less dense than water. Christiaan Huygens first correctly described the rings in 1659.",
    "Saturn has well over 100 known moons. Titan, larger than Mercury, has a thick nitrogen atmosphere and lakes and rivers of liquid methane and ethane; the Huygens probe landed there in 2005. The Cassini spacecraft (2004–2017) discovered geysers of water ice erupting from Enceladus, revealing a subsurface ocean."]],
  ["Uranus and Neptune",[
    "Uranus and Neptune are ice giants, with interiors rich in water, ammonia, and methane ices beneath hydrogen-helium atmospheres; methane gives them their blue color. Uranus, discovered by William Herschel in 1781, is tipped on its side, with an axial tilt of about 98 degrees, possibly from an ancient collision, giving it extreme seasons.",
    "Neptune was the first planet found by mathematical prediction: Urbain Le Verrier and John Couch Adams calculated its position from irregularities in Uranus's orbit, and Johann Galle observed it in 1846. Neptune has the fastest winds in the solar system, over 2,000 km/h. Its large moon Triton orbits backward and may be a captured object. Voyager 2 is the only spacecraft to have visited both ice giants, in 1986 and 1989."]],
  ["Dwarf planets and the Kuiper Belt",[
    "Beyond Neptune lies the Kuiper Belt, a region of icy bodies, including Pluto, discovered by Clyde Tombaugh in 1930. NASA's New Horizons flew past Pluto in 2015, revealing mountains of water ice and a vast heart-shaped plain of nitrogen ice. Other dwarf planets include Eris, Haumea, Makemake, and Ceres, the largest object in the asteroid belt.",
    "Far beyond, the hypothetical Oort Cloud, a vast spherical shell of icy bodies extending perhaps a light-year or more from the Sun, is thought to be the source of long-period comets."]],
  ["Asteroids and meteors",[
    "Asteroids are rocky and metallic remnants from the formation of the solar system, most orbiting in the asteroid belt between Mars and Jupiter. Meteoroids are small fragments; when they enter Earth's atmosphere they burn up as meteors, “shooting stars”; pieces that reach the ground are meteorites. Meteor showers, such as the Perseids in August, occur when Earth passes through debris left by comets.",
    "Impacts have shaped Earth's history, from the dinosaur-killing Chicxulub impact to the 1908 Tunguska explosion in Siberia, which flattened about 2,000 square kilometers of forest, and the 2013 Chelyabinsk meteor, which injured over 1,000 people, mostly from broken glass. In 2022 NASA's DART spacecraft deliberately struck the asteroid moonlet Dimorphos, successfully changing its orbit, the first test of planetary defense."]],
  ["Comets",[
    "Comets are “dirty snowballs” of ice, dust, and rock, a description by Fred Whipple. When a comet approaches the Sun, its ice vaporizes, forming a glowing coma and tails that point away from the Sun, pushed by sunlight and the solar wind, sometimes millions of kilometers long.",
    "Halley's Comet returns about every 76 years, last in 1986 and next in 2061; Edmond Halley correctly predicted its return in 1758. The European Rosetta mission orbited Comet 67P/Churyumov–Gerasimenko from 2014 to 2016 and landed the Philae probe on its surface. Comets and asteroids may have delivered water and organic molecules to the early Earth."]]
  ],
  terms:[["Gas giant","A large planet mostly of hydrogen and helium."],["Ice giant","A giant planet rich in water, ammonia, and methane ices."],["Great Red Spot","Jupiter's giant storm."],["Europa","Jupiter's moon with a subsurface ocean."],["Titan","Saturn's moon with methane lakes."],["Kuiper Belt","The region of icy bodies beyond Neptune."],["Meteor and meteorite","A burning meteoroid vs. one reaching the ground."],["Comet","An icy body that develops a tail near the Sun."]],
  w:"The outer planets, moons, and small worlds reveal the solar system's history, potential habitats for life, and the impact hazards that have shaped Earth.",
  src:["Jupiter","Saturn","Uranus","Discovery of Neptune","Kuiper belt","Asteroid","Halley's Comet"],
  q:[["Which is the largest moon in the solar system?","Ganymede","Titan","Europa","Callisto"],
     ["Which moon has lakes of liquid methane?","Titan","Europa","Io","Enceladus"],
     ["Which planet is tipped on its side?","Uranus","Neptune","Saturn","Jupiter"],
     ["Who discovered Pluto in 1930?","Clyde Tombaugh","William Herschel","Johann Galle","Percival Lowell"],
     ["What did NASA's DART mission test in 2022?","Deflecting an asteroid","Landing on Mars","Sampling a comet","Visiting Pluto"],
     ["How often does Halley's Comet return?","About every 76 years","About every 10 years","About every 200 years","Every year"]]}

]});


/* ---- from sci-18.js ---- */
/* SCIENCES FOUNDATIONS, part 18: Unit 9 chapters 6-12 */
COURSES.sciences.units[8].ch.push(

{ t:"The Lives of Stars", s:"How stars are born and shine",
  sec:[
  ["What stars are",[
    "Stars are huge balls of hot plasma held together by gravity and powered by nuclear fusion in their cores. The nearest star after the Sun, Proxima Centauri, is about 4.2 light-years away; a light-year, the distance light travels in a year, is about 9.46 trillion kilometers. The Milky Way contains an estimated 100–400 billion stars.",
    "Stars twinkle because turbulence in Earth's atmosphere bends their light; planets, which appear as tiny disks, twinkle less."]],
  ["Star birth",[
    "Stars form in giant clouds of cold gas and dust called nebulae, such as the Orion Nebula, visible to the naked eye. When part of a cloud collapses under gravity, perhaps triggered by a nearby supernova, it heats up, forming a protostar surrounded by a spinning disk that may form planets.",
    "When the core reaches about 10 million °C, hydrogen fusion begins and a star is born. Stars often form in clusters, such as the Pleiades, a group of young stars about 444 light-years away."]],
  ["Properties of stars",[
    "Stars differ in mass, size, temperature, color, and brightness. Color indicates surface temperature: red stars are coolest (about 3,000°C), yellow stars like the Sun intermediate, and blue stars hottest (over 25,000°C). Betelgeuse, in Orion, is a red supergiant; Rigel, in the same constellation, is a blue supergiant.",
    "Annie Jump Cannon at Harvard classified hundreds of thousands of stars by their spectra into types O, B, A, F, G, K, M, from hottest to coolest. Cecilia Payne-Gaposchkin showed in her 1925 thesis that stars are made mostly of hydrogen and helium, a conclusion initially resisted. Apparent brightness depends on both luminosity and distance."]],
  ["The Hertzsprung-Russell diagram",[
    "Around 1910 Ejnar Hertzsprung and Henry Norris Russell independently plotted stars' luminosities against their temperatures, creating the Hertzsprung-Russell (H-R) diagram, one of astronomy's most important tools. Most stars, including the Sun, lie along a diagonal band called the main sequence, where they spend most of their lives fusing hydrogen.",
    "Other regions contain red giants and supergiants, large and luminous but cool, and white dwarfs, small, hot, and dim. A star's position reveals its stage of life."]],
  ["Mass is destiny",[
    "A star's mass determines its life. Massive stars burn their fuel much faster and live only a few million years; the Sun will live about 10 billion years; and small red dwarfs, the most common stars, can live for trillions of years, far longer than the current age of the universe.",
    "The smallest objects that form like stars but cannot sustain hydrogen fusion are brown dwarfs, intermediate between stars and giant planets."]],
  ["Stars make the elements",[
    "Stars are factories of the elements. The Big Bang produced mainly hydrogen and helium; heavier elements were forged inside stars by fusion, carbon, oxygen, and up to iron in massive stars, a process called stellar nucleosynthesis, described in a landmark 1957 paper by Margaret Burbidge, Geoffrey Burbidge, William Fowler, and Fred Hoyle.",
    "Elements heavier than iron are made in supernova explosions and neutron star collisions. Dying stars scatter these elements into space, where they form new stars, planets, and living things. As Carl Sagan put it, “We are made of star stuff”: the carbon in our cells and the iron in our blood were made in stars."]]
  ],
  terms:[["Light-year","The distance light travels in a year, about 9.46 trillion km."],["Nebula","A cloud of gas and dust where stars form."],["Protostar","A forming star before fusion begins."],["Spectral classes","O, B, A, F, G, K, M, hottest to coolest."],["Hertzsprung-Russell diagram","A plot of stellar luminosity against temperature."],["Main sequence","The stage of hydrogen fusion where stars spend most of their lives."],["Stellar nucleosynthesis","The creation of elements in stars."]],
  w:"The lives of stars explain the light in the night sky and the origin of the elements that make up planets and our own bodies.",
  src:["Star","Light-year","Star formation","Stellar classification","Hertzsprung–Russell diagram","Cecilia Payne-Gaposchkin","Stellar nucleosynthesis"],
  q:[["What is the nearest star after the Sun?","Proxima Centauri","Sirius","Alpha Centauri A","Barnard's Star"],
     ["Which color star is hottest?","Blue","Red","Yellow","Orange"],
     ["Who showed stars are made mostly of hydrogen and helium?","Cecilia Payne-Gaposchkin","Annie Jump Cannon","Henrietta Leavitt","Margaret Burbidge"],
     ["What plots luminosity against temperature?","The Hertzsprung-Russell diagram","The Hubble diagram","The cosmic distance ladder","The periodic table"],
     ["Which stars live longest?","Red dwarfs","Blue supergiants","Red giants","Yellow dwarfs"],
     ["Who said We are made of star stuff?","Carl Sagan","Fred Hoyle","Neil deGrasse Tyson","Edwin Hubble"]]},

{ t:"The Deaths of Stars", s:"White dwarfs, supernovae, neutron stars, and black holes",
  sec:[
  ["Running out of fuel",[
    "When a star exhausts the hydrogen in its core, gravity squeezes the core and it heats up, while the outer layers expand, turning the star into a red giant. The star begins fusing helium into carbon. What happens next depends on its mass.",
    "Stars like the Sun eventually shed their outer layers into space, forming a glowing shell of gas called a planetary nebula (a misleading name from early telescope views), such as the Ring Nebula and the Helix Nebula."]],
  ["White dwarfs",[
    "The leftover core becomes a white dwarf, about the size of Earth but with roughly the mass of the Sun, so dense that a teaspoon would weigh several tonnes. It no longer produces energy by fusion and slowly cools. Subrahmanyan Chandrasekhar calculated in 1930 that white dwarfs cannot exceed about 1.4 solar masses, the Chandrasekhar limit; above it, they collapse.",
    "Sirius B, a white dwarf companion of the brightest star Sirius, was among the first known. If a white dwarf in a binary system pulls enough matter from its companion to exceed the limit, it explodes as a Type Ia supernova, a standard candle used to measure cosmic distances."]],
  ["Supernovae",[
    "Stars more than about eight times the Sun's mass end their lives spectacularly. They fuse progressively heavier elements until the core becomes iron, which cannot release energy by fusion. The core collapses in under a second, and the star explodes as a core-collapse supernova, briefly outshining an entire galaxy.",
    "Supernova 1987A, in the Large Magellanic Cloud, was the nearest observed in centuries; detectors recorded neutrinos from it hours before its light was seen. The supernova recorded by Chinese astronomers in 1054 left the Crab Nebula; Tycho Brahe's supernova of 1572 showed that the heavens could change. Supernovae scatter heavy elements and trigger new star formation."]],
  ["Neutron stars and pulsars",[
    "A collapsing core of about 1.4 to 2–3 solar masses becomes a neutron star, compressed so that protons and electrons merge into neutrons, a sphere only about 20 kilometers across with more mass than the Sun; a teaspoon would weigh about a billion tonnes.",
    "In 1967 Jocelyn Bell Burnell, a graduate student at Cambridge, discovered regular radio pulses, at first jokingly labeled “LGM-1” for “little green men.” They came from a pulsar, a rapidly spinning neutron star sweeping beams of radiation like a lighthouse. Her supervisor Antony Hewish shared the 1974 Nobel Prize, a decision widely criticized for excluding her; she later received a 2018 Breakthrough Prize and donated it to support underrepresented physics students."]],
  ["Black holes",[
    "If the collapsing core is even more massive, nothing can stop its collapse, and it becomes a stellar black hole, whose gravity is so strong that not even light escapes from within the event horizon. The first strong candidate, Cygnus X-1, was identified in the early 1970s by its X-rays as it pulled gas from a companion star.",
    "Black holes are not cosmic vacuum cleaners: at a safe distance, a black hole's gravity is the same as any object of the same mass. Stephen Hawking predicted in 1974 that black holes slowly emit radiation, Hawking radiation, due to quantum effects, and may eventually evaporate, though for stellar black holes this would take far longer than the age of the universe."]],
  ["Supermassive black holes",[
    "Supermassive black holes, millions to billions of times the Sun's mass, lie at the centers of most large galaxies. The one at the center of the Milky Way, Sagittarius A*, about 4 million solar masses, was revealed by tracking stars orbiting it; Reinhard Genzel and Andrea Ghez shared the 2020 Nobel Prize for this work, with Roger Penrose, who showed black holes are a robust prediction of general relativity.",
    "When supermassive black holes devour gas, they can power quasars, the most luminous objects in the universe. How they grew so large so early in cosmic history is an active question."]]
  ],
  terms:[["Red giant","An expanded star in a late stage of life."],["Planetary nebula","The glowing shell shed by a dying Sun-like star."],["White dwarf","The dense remnant of a Sun-like star."],["Chandrasekhar limit","About 1.4 solar masses, the maximum for white dwarfs."],["Supernova","An exploding star."],["Neutron star","An ultra-dense stellar remnant made of neutrons."],["Pulsar","A spinning neutron star emitting beams."]],
  w:"The deaths of stars create the elements of life and the universe's most extreme objects, from neutron stars to black holes.",
  src:["Stellar evolution","White dwarf","Chandrasekhar limit","Supernova","SN 1987A","Pulsar","Sagittarius A*"],
  q:[["What do Sun-like stars become at the end of their lives?","White dwarfs","Black holes","Neutron stars","Pulsars"],
     ["Who calculated the maximum mass of white dwarfs?","Subrahmanyan Chandrasekhar","Stephen Hawking","Fritz Zwicky","Arthur Eddington"],
     ["Which supernova left the Crab Nebula?","The supernova of 1054","Tycho's supernova of 1572","SN 1987A","Kepler's supernova"],
     ["Who discovered pulsars in 1967?","Jocelyn Bell Burnell","Antony Hewish alone","Carl Sagan","Vera Rubin"],
     ["What did Hawking predict black holes emit?","Hawking radiation","X-rays only","Neutrinos","Gravitational waves only"],
     ["What is the black hole at the Milky Way's center called?","Sagittarius A*","Cygnus X-1","M87*","Andromeda X"]]},

{ t:"Galaxies", s:"Island universes",
  sec:[
  ["The Milky Way",[
    "The Milky Way is our home galaxy, a barred spiral about 100,000 light-years across containing hundreds of billions of stars, gas, dust, and dark matter. The Sun lies about 26,000 light-years from the center, in a minor spiral arm called the Orion Arm, and orbits the center once every 225–250 million years, a “galactic year.”",
    "The band of light we call the Milky Way is our edge-on view of the galaxy's disk. Galileo showed in 1610 that it consists of countless stars. Its center, in the direction of Sagittarius, is hidden by dust but observed in infrared and radio."]],
  ["The Great Debate",[
    "Until the 1920s, many astronomers believed the Milky Way was the entire universe and that fuzzy spiral nebulae were clouds within it. In the “Great Debate” of 1920, Harlow Shapley and Heber Curtis argued over the scale of the universe and the nature of spiral nebulae.",
    "In 1923–1925, Edwin Hubble used the Hooker Telescope to identify Cepheid variable stars in the Andromeda Nebula and, using Leavitt's relation, showed it was far outside the Milky Way, a separate galaxy. The universe suddenly became vastly larger."]],
  ["Types of galaxies",[
    "Hubble classified galaxies by shape in his “tuning fork” diagram. Spiral galaxies, like the Milky Way and Andromeda, have flat, rotating disks with spiral arms where new stars form, around a central bulge. Elliptical galaxies are smooth, rounded collections of mostly old stars with little gas, including the largest galaxies. Irregular galaxies have no clear shape, such as the Large and Small Magellanic Clouds, satellite galaxies of the Milky Way visible from the Southern Hemisphere.",
    "Observations suggest there are at least hundreds of billions of galaxies in the observable universe, perhaps up to two trillion."]],
  ["Groups, clusters, and collisions",[
    "Galaxies gather in groups and clusters. The Milky Way belongs to the Local Group, about 50 or more galaxies, dominated by the Milky Way and the Andromeda Galaxy, about 2.5 million light-years away, the most distant object easily visible to the naked eye. Clusters contain hundreds to thousands of galaxies, and clusters form superclusters; the Milky Way lies in the Laniakea Supercluster, defined in 2014.",
    "Galaxies collide and merge over billions of years. Andromeda and the Milky Way are approaching each other and may merge in roughly 4–5 billion years, though recent studies suggest the collision is less certain than once thought; stars are so far apart that they would rarely collide directly."]],
  ["The cosmic web",[
    "On the largest scales, galaxies are arranged in a vast cosmic web of filaments and sheets surrounding enormous empty regions called voids. Galaxy surveys, such as the Sloan Digital Sky Survey, have mapped millions of galaxies in three dimensions.",
    "This structure grew from tiny fluctuations in the early universe, amplified by gravity, especially that of dark matter."]],
  ["Active galaxies",[
    "Some galaxies have extremely bright, active cores powered by supermassive black holes devouring matter, called active galactic nuclei. Quasars, discovered in 1963 by Maarten Schmidt, are the most luminous, outshining their entire host galaxies from regions not much bigger than the solar system, and are seen at great distances, meaning we see them as they were billions of years ago.",
    "Looking deep into space is looking back in time: the light from distant galaxies left them billions of years ago, allowing astronomers to watch galaxies evolve over cosmic history."]]
  ],
  terms:[["Milky Way","Our home galaxy, a barred spiral."],["Galactic year","The time for the Sun to orbit the galaxy."],["Spiral, elliptical, irregular","The main galaxy shapes."],["Local Group","The galaxy group containing the Milky Way and Andromeda."],["Andromeda Galaxy","The nearest large spiral galaxy."],["Cosmic web","The large-scale structure of galaxies."],["Quasar","An extremely luminous active galactic nucleus."]],
  w:"Galaxies are the building blocks of the universe, and discovering that the Milky Way is one among billions transformed our sense of our place in the cosmos.",
  src:["Milky Way","Great Debate (astronomy)","Andromeda Galaxy","Galaxy morphological classification","Local Group","Laniakea Supercluster","Quasar"],
  q:[["About how far is the Sun from the galactic center?","About 26,000 light-years","About 2,600 light-years","About 100,000 light-years","About 4 light-years"],
     ["Who showed Andromeda is a separate galaxy?","Edwin Hubble","Harlow Shapley","Heber Curtis","Henrietta Leavitt"],
     ["What type of galaxy is the Milky Way?","A barred spiral","An elliptical","An irregular","A dwarf"],
     ["Which galaxies are satellites of the Milky Way visible from the south?","The Magellanic Clouds","Andromeda","Triangulum","M87"],
     ["What is the supercluster containing the Milky Way?","Laniakea","Virgo","Coma","Perseus"],
     ["Who discovered quasars in 1963?","Maarten Schmidt","Edwin Hubble","Fritz Zwicky","Jocelyn Bell Burnell"]]},

{ t:"The Big Bang", s:"The origin and evolution of the universe",
  sec:[
  ["An expanding universe",[
    "In 1922 the Russian physicist Alexander Friedmann found that Einstein's equations allow an expanding universe. In 1927 the Belgian priest and physicist Georges Lemaître proposed that the universe is expanding and later that it began from a “primeval atom.” In 1929 Edwin Hubble, building on measurements by Vesto Slipher, showed that distant galaxies are moving away from us, with speed proportional to distance, the Hubble-Lemaître law.",
    "The universe is not expanding into anything; space itself is stretching, carrying galaxies apart and stretching light to longer, redder wavelengths, cosmological redshift."]],
  ["The Big Bang theory",[
    "Running the expansion backward implies that the universe was once extremely hot and dense. The Big Bang theory describes how the universe has expanded and cooled from this state over about 13.8 billion years. The name was coined, somewhat mockingly, by Fred Hoyle in a 1949 radio broadcast; Hoyle favored a rival “steady state” theory in which the universe has no beginning.",
    "The Big Bang was not an explosion at a point in space but the rapid expansion of space everywhere. The theory describes what happened after the first tiny fraction of a second; what came before, if anything, remains unknown."]],
  ["The cosmic microwave background",[
    "The strongest evidence for the Big Bang came in 1964–1965, when Arno Penzias and Robert Wilson at Bell Labs detected a faint, uniform microwave noise from every direction, which they first suspected was caused by pigeon droppings in their antenna. It was the cosmic microwave background (CMB), the afterglow of the hot early universe, released about 380,000 years after the Big Bang when the universe cooled enough for atoms to form and light to travel freely.",
    "The CMB has a temperature of about 2.7 K. Satellites, COBE, WMAP, and Planck, mapped tiny temperature variations in it, the seeds of galaxies; John Mather and George Smoot won the 2006 Nobel Prize for COBE's results."]],
  ["The first elements",[
    "In the first few minutes, the universe was hot enough for nuclear fusion, producing the lightest elements: about 75 percent hydrogen and 25 percent helium by mass, with traces of lithium, a process called Big Bang nucleosynthesis, worked out by Ralph Alpher, George Gamow, and others in the late 1940s. The observed abundances match the predictions remarkably well.",
    "The first stars formed a few hundred million years later, ending the cosmic “dark ages,” and began making heavier elements. The James Webb Space Telescope has observed galaxies existing less than 300 million years after the Big Bang."]],
  ["Inflation",[
    "Puzzles about why the universe is so uniform and flat led Alan Guth to propose in 1980 the theory of cosmic inflation: in the first tiny fraction of a second, the universe expanded exponentially, by a factor of perhaps 10²⁶ or more, smoothing it out and stretching quantum fluctuations into the seeds of galaxies.",
    "Inflation is widely accepted by cosmologists as consistent with observations, but direct evidence remains elusive, and some versions suggest our universe may be one of many in a “multiverse.”"]],
  ["The observable universe",[
    "Because light has a finite speed and the universe has a finite age, we can see only the observable universe, a sphere about 93 billion light-years across, larger than 13.8 billion light-years because space has expanded while the light traveled. The whole universe may be much larger, perhaps infinite.",
    "Cosmology combines general relativity, particle physics, and observations to describe the universe's history, from a fraction of a second after the Big Bang to the present, one of the great intellectual achievements of science."]]
  ],
  terms:[["Expanding universe","Space stretching and carrying galaxies apart."],["Hubble-Lemaître law","Galaxies recede at speeds proportional to distance."],["Redshift","Stretching of light to longer wavelengths."],["Big Bang theory","The universe expanding from a hot, dense state 13.8 billion years ago."],["Cosmic microwave background","The afterglow of the early universe."],["Big Bang nucleosynthesis","Formation of light elements in the first minutes."],["Cosmic inflation","Extremely rapid expansion in the first instant."]],
  w:"The Big Bang theory tells the story of the universe from its first moments, supported by the expansion of space, the cosmic microwave background, and the abundance of light elements.",
  src:["Big Bang","Georges Lemaître","Hubble's law","Cosmic microwave background","Big Bang nucleosynthesis","Cosmic inflation","Observable universe"],
  q:[["Who first proposed that the universe began from a primeval atom?","Georges Lemaître","Edwin Hubble","Albert Einstein","Fred Hoyle"],
     ["How old is the universe?","About 13.8 billion years","About 4.6 billion years","About 100 billion years","About 6,000 years"],
     ["Who coined the term Big Bang?","Fred Hoyle","George Gamow","Edwin Hubble","Stephen Hawking"],
     ["Who discovered the cosmic microwave background?","Penzias and Wilson","Mather and Smoot","Hubble and Humason","Alpher and Gamow"],
     ["What is the temperature of the CMB?","About 2.7 K","About 270 K","About 0 K","About 27 K"],
     ["Who proposed cosmic inflation?","Alan Guth","Stephen Hawking","Roger Penrose","Andrei Linde alone"]]},

{ t:"Dark Matter and Dark Energy", s:"The invisible universe",
  sec:[
  ["Missing mass",[
    "In 1933 the Swiss astronomer Fritz Zwicky, studying the Coma galaxy cluster, found that its galaxies were moving so fast that the cluster should fly apart unless it contained far more mass than visible stars could account for; he called the missing mass “dunkle Materie,” dark matter.",
    "In the 1970s Vera Rubin and Kent Ford measured the rotation of spiral galaxies and found that stars in their outer regions orbit as fast as those near the center, instead of slowing down as expected. This implied that galaxies are embedded in massive halos of invisible matter."]],
  ["Evidence for dark matter",[
    "Further evidence comes from gravitational lensing, the bending of light by mass, which reveals more mass in clusters than is visible; from the Bullet Cluster, two colliding galaxy clusters where the mass mapped by lensing is separated from the hot gas, showing dark matter passing through; and from the pattern of fluctuations in the cosmic microwave background and the growth of cosmic structure.",
    "Dark matter makes up about 85 percent of all matter, about 27 percent of the universe's total energy content, while ordinary matter, everything made of atoms, is only about 5 percent."]],
  ["What is dark matter?",[
    "Dark matter does not emit, absorb, or reflect light and interacts with ordinary matter mainly, perhaps only, through gravity. It is not made of ordinary atoms. Leading candidates include unknown particles such as WIMPs (weakly interacting massive particles) and axions.",
    "Experiments deep underground, such as LUX-ZEPLIN, try to detect rare collisions of dark matter particles with atoms, while the Large Hadron Collider searches for them, but none has been confirmed. Some scientists explore alternatives, such as modifying the laws of gravity, though these struggle to explain all the evidence."]],
  ["The accelerating universe",[
    "Astronomers expected the expansion of the universe to be slowing down due to gravity. In 1998 two teams studying distant Type Ia supernovae, led by Saul Perlmutter, Brian Schmidt, and Adam Riess, found the opposite: the expansion is accelerating. They shared the 2011 Nobel Prize in Physics.",
    "The mysterious cause of this acceleration is called dark energy, making up about 68 percent of the universe's energy content. It may be the energy of empty space itself, the cosmological constant, which Einstein had introduced in 1917 and later abandoned, reportedly calling it his biggest blunder."]],
  ["The standard model of cosmology",[
    "The leading model of the universe, called Lambda-CDM (Lambda for the cosmological constant, CDM for cold dark matter), describes a universe of about 5 percent ordinary matter, 27 percent dark matter, and 68 percent dark energy, which began with a Big Bang about 13.8 billion years ago. It fits a wide range of observations remarkably well.",
    "However, tensions remain, such as the “Hubble tension,” a disagreement between measurements of the current expansion rate from the early universe and from nearby galaxies. In 2024–2025, results from the Dark Energy Spectroscopic Instrument (DESI) hinted that dark energy may change over time, which if confirmed would transform cosmology."]],
  ["The fate of the universe",[
    "The universe's fate depends on dark energy. If it remains constant, the universe will expand forever, galaxies beyond our local group will disappear from view, stars will burn out, and the universe will grow cold and dark, a “Big Freeze” or heat death over unimaginably long times.",
    "If dark energy grows stronger, it could eventually tear apart galaxies, stars, and atoms in a “Big Rip”; if it weakens or reverses, the universe might collapse in a “Big Crunch.” That we do not yet know what makes up 95 percent of the universe is one of the most humbling facts in science."]]
  ],
  terms:[["Dark matter","Invisible matter detected only by its gravity."],["Galaxy rotation curve","The speed of stars at different distances from a galaxy's center."],["WIMP","A hypothetical dark matter particle."],["Dark energy","The unknown cause of accelerating expansion."],["Cosmological constant","Einstein's term for energy of empty space."],["Lambda-CDM","The standard model of cosmology."],["Hubble tension","A disagreement in measurements of expansion rate."]],
  w:"Dark matter and dark energy make up about 95 percent of the universe yet remain mysterious, representing the greatest unsolved puzzle in cosmology.",
  src:["Dark matter","Fritz Zwicky","Vera Rubin","Bullet Cluster","Dark energy","Accelerating expansion of the universe","Lambda-CDM model"],
  q:[["Who first proposed dark matter in 1933?","Fritz Zwicky","Vera Rubin","Edwin Hubble","Albert Einstein"],
     ["Whose galaxy rotation measurements supported dark matter?","Vera Rubin and Kent Ford","Penzias and Wilson","Perlmutter and Riess","Hubble and Humason"],
     ["What share of the universe is ordinary matter?","About 5 percent","About 27 percent","About 68 percent","About 50 percent"],
     ["When was the accelerating expansion discovered?","1998","1929","1965","2015"],
     ["What does dark energy cause?","The accelerating expansion of the universe","Galaxy rotation","Black holes","Gravitational lensing"],
     ["What did Einstein reportedly call his biggest blunder?","The cosmological constant","Rejecting quantum mechanics","E = mc²","General relativity"]]},

{ t:"Exoplanets and the Search for Life", s:"Are we alone?",
  sec:[
  ["Worlds beyond",[
    "For centuries, people wondered whether other stars had planets. The first confirmed exoplanets were found orbiting a pulsar in 1992 by Aleksander Wolszczan and Dale Frail. In 1995 Michel Mayor and Didier Queloz discovered 51 Pegasi b, a giant planet orbiting a Sun-like star every four days, a “hot Jupiter,” and shared the 2019 Nobel Prize.",
    "By the mid-2020s, over 5,000 exoplanets had been confirmed, and estimates suggest most stars have planets, implying hundreds of billions in the Milky Way alone."]],
  ["Finding exoplanets",[
    "Most exoplanets are found indirectly. The radial velocity method detects the tiny wobble of a star as an orbiting planet tugs it. The transit method detects the slight dimming of a star when a planet passes in front of it. NASA's Kepler Space Telescope (2009–2018) used transits to discover thousands of planets, and TESS continues the search.",
    "Exoplanets come in great variety: hot Jupiters, “super-Earths” and “mini-Neptunes” (sizes absent from our solar system), and rocky worlds. The TRAPPIST-1 system, about 40 light-years away, has seven Earth-sized planets, several in the habitable zone. Proxima b orbits the nearest star."]],
  ["The habitable zone",[
    "The habitable zone, or “Goldilocks zone,” is the range of distances from a star where temperatures could allow liquid water on a planet's surface, not too hot and not too cold. Liquid water is considered essential for life as we know it.",
    "Being in the habitable zone does not guarantee habitability; a planet also needs a suitable atmosphere, and factors such as stellar flares, magnetic fields, and planet size matter. The James Webb Space Telescope is analyzing exoplanet atmospheres, searching for water, carbon dioxide, and possible biosignatures, gases such as oxygen and methane that might indicate life."]],
  ["Life in the solar system?",[
    "Astrobiology studies the origin, evolution, and distribution of life in the universe. In our solar system, the best places to search include Mars, which once had liquid water; Europa and Enceladus, moons with subsurface oceans and possible hydrothermal activity; and Titan, with its complex organic chemistry.",
    "Extremophiles on Earth, thriving in boiling vents, acid, ice, and deep rock, suggest life might survive in harsh environments elsewhere. NASA's Europa Clipper, launched in 2024, and ESA's JUICE mission will study Jupiter's icy moons, and Dragonfly will fly on Titan in the 2030s."]],
  ["SETI and the Drake equation",[
    "The Search for Extraterrestrial Intelligence (SETI) listens for radio or optical signals from other civilizations. Frank Drake conducted the first search, Project Ozma, in 1960, and devised the Drake equation (1961), which estimates the number of communicating civilizations in the galaxy by multiplying factors such as the rate of star formation, the fraction of stars with planets, the fraction of planets developing life and intelligence, and how long civilizations last; most factors remain highly uncertain.",
    "The 1977 “Wow! signal” remains unexplained but was never repeated. No confirmed evidence of extraterrestrial life has yet been found."]],
  ["The Fermi paradox",[
    "The physicist Enrico Fermi reportedly asked in 1950, “Where is everybody?” If the galaxy is old and vast and life is common, why have we seen no evidence of other civilizations? Proposed answers include that life or intelligence is very rare, that civilizations destroy themselves or do not last, that they are too far away or communicate in ways we cannot detect, or that we have not searched long enough.",
    "Discovering life elsewhere, even microbial, would be one of the most profound discoveries in human history, and for the first time, we have the tools to seriously look."]]
  ],
  terms:[["Exoplanet","A planet orbiting another star."],["Transit method","Detecting planets by the dimming of their star."],["Radial velocity method","Detecting planets by their star's wobble."],["Habitable zone","The region where liquid water could exist."],["Biosignature","A sign that may indicate life."],["Astrobiology","The study of life in the universe."],["Drake equation","An estimate of communicating civilizations."],["Fermi paradox","The puzzle of why we see no other civilizations."]],
  w:"The discovery of thousands of exoplanets and the search for life elsewhere address one of humanity's oldest questions: are we alone?",
  src:["Exoplanet","51 Pegasi b","Methods of detecting exoplanets","Habitable zone","Astrobiology","Drake equation","Fermi paradox"],
  q:[["Who discovered the first exoplanet around a Sun-like star?","Mayor and Queloz","Wolszczan and Frail","Drake and Sagan","Kepler and Brahe"],
     ["Which space telescope used transits to find thousands of planets?","Kepler","Hubble","Spitzer","Chandra"],
     ["How many Earth-sized planets does TRAPPIST-1 have?","Seven","Three","One","Twelve"],
     ["What is the habitable zone?","Where liquid water could exist on a planet's surface","Where stars form","The center of the galaxy","Where comets come from"],
     ["Who devised an equation estimating communicating civilizations?","Frank Drake","Enrico Fermi","Carl Sagan","Jill Tarter"],
     ["Who asked Where is everybody?","Enrico Fermi","Frank Drake","Carl Sagan","Stephen Hawking"]]},

{ t:"Space Exploration", s:"From Sputnik to the Moon and beyond",
  sec:[
  ["Rocket pioneers",[
    "The Russian schoolteacher Konstantin Tsiolkovsky worked out the mathematics of rocket travel around 1903 and imagined space colonies. The American Robert Goddard launched the first liquid-fueled rocket in 1926 in Massachusetts. In Germany, Wernher von Braun led development of the V-2 rocket, used as a weapon in World War II, which became the first human-made object to reach space in 1944.",
    "After the war, von Braun and other German engineers went to the United States, while the Soviet Union, under chief designer Sergei Korolev, built its own program."]],
  ["The Space Race",[
    "The Cold War rivalry between the United States and Soviet Union drove the Space Race. On 4 October 1957 the Soviet Union launched Sputnik 1, the first artificial satellite, and then Sputnik 2 carrying the dog Laika. On 12 April 1961 Yuri Gagarin became the first human in space, orbiting Earth in Vostok 1. Valentina Tereshkova became the first woman in space in 1963, and Alexei Leonov made the first spacewalk in 1965.",
    "The United States created NASA in 1958. Alan Shepard became the first American in space in May 1961, and John Glenn the first American to orbit Earth in 1962. President John F. Kennedy committed the nation in 1961 to landing a man on the Moon before the decade was out."]],
  ["Apollo",[
    "NASA's Apollo program used the giant Saturn V rocket, the most powerful rocket flown until the 2020s. Apollo 8 orbited the Moon in December 1968, producing the famous Earthrise photograph. On 20 July 1969, Apollo 11 astronauts Neil Armstrong and Buzz Aldrin landed in the Sea of Tranquility while Michael Collins orbited above; Armstrong declared, “That's one small step for [a] man, one giant leap for mankind.”",
    "Six missions landed 12 astronauts on the Moon between 1969 and 1972, returning 382 kilograms of lunar samples. Apollo 13 (1970) survived an oxygen tank explosion and returned safely. Thousands of engineers, including African American mathematicians such as Katherine Johnson, made the program possible."]],
  ["Robotic explorers",[
    "Robotic spacecraft have explored every planet. Mariner 4 sent the first close-up images of Mars in 1965; Venera 7 made the first successful landing on another planet, Venus, in 1970; the Viking landers reached Mars in 1976. Voyager 1 and 2, launched in 1977, toured the outer planets; Voyager 1 is the most distant human-made object, in interstellar space, carrying a Golden Record of sounds and images from Earth.",
    "Missions have orbited and landed on asteroids and comets, returned samples from asteroids (Japan's Hayabusa missions and NASA's OSIRIS-REx), and India's Chandrayaan-3 made the first landing near the lunar south pole in 2023."]],
  ["Living in space",[
    "Space stations allow long-term research. The Soviet Union's Mir operated from 1986 to 2001. The International Space Station, built by the United States, Russia, Europe, Japan, and Canada from 1998, has been continuously occupied since November 2000. China completed its Tiangong space station in 2022.",
    "Space travel is dangerous: the Space Shuttle Challenger disaster (1986) and Columbia disaster (2003) each killed seven astronauts. Long stays in microgravity weaken bones and muscles, and radiation poses risks for future missions to Mars."]],
  ["A new space age",[
    "Private companies have transformed spaceflight. SpaceX developed reusable rockets that land and fly again, and in 2020 its Crew Dragon became the first commercial spacecraft to carry astronauts to the ISS. Satellite constellations provide global internet, navigation, weather forecasting, and Earth observation.",
    "NASA's Artemis program aims to return humans to the Moon, beginning with Artemis II, the first crewed flight around the Moon since Apollo, and to prepare for Mars. China, India, and other nations have ambitious programs. Space exploration raises questions about space debris, the use of resources on other worlds, and the protection of other worlds from contamination."]]
  ],
  terms:[["Space Race","The Cold War competition in spaceflight."],["Sputnik 1","The first artificial satellite, 1957."],["Vostok 1","Yuri Gagarin's spacecraft."],["Apollo 11","The first crewed Moon landing, 1969."],["Saturn V","The rocket that took astronauts to the Moon."],["Voyager 1","The most distant human-made object."],["International Space Station","A continuously occupied orbiting laboratory since 2000."]],
  w:"Space exploration has taken humans to the Moon and robots across the solar system, transforming science, technology, and our view of Earth.",
  src:["Space exploration","Robert H. Goddard","Sputnik 1","Yuri Gagarin","Apollo 11","Voyager 1","International Space Station"],
  q:[["Who launched the first liquid-fueled rocket in 1926?","Robert Goddard","Wernher von Braun","Konstantin Tsiolkovsky","Sergei Korolev"],
     ["When was Sputnik 1 launched?","4 October 1957","12 April 1961","20 July 1969","1 January 1950"],
     ["Who was the first woman in space?","Valentina Tereshkova","Sally Ride","Svetlana Savitskaya","Mae Jemison"],
     ["Who stayed in orbit during Apollo 11?","Michael Collins","Buzz Aldrin","Neil Armstrong","Jim Lovell"],
     ["Which is the most distant human-made object?","Voyager 1","Voyager 2","Pioneer 10","New Horizons"],
     ["Which country first landed near the lunar south pole in 2023?","India","China","The United States","Japan"]]}

);


/* ---- from sci-19.js ---- */
/* SCIENCES FOUNDATIONS, part 19: Unit 10 Science, Earth, and Society */
COURSES.sciences.units.push({ t:"Science, Earth, and Society", ch:[

{ t:"Earth as a System", s:"Spheres, cycles, and planetary science",
  sec:[
  ["Four spheres",[
    "Earth system science studies the planet as an interconnected whole. It is often divided into four spheres: the geosphere (rock, soil, and the interior), the hydrosphere (water in oceans, ice, rivers, groundwater, and air), the atmosphere (the envelope of gases), and the biosphere (all living things). Some add the cryosphere (ice) and the anthroposphere (human activities).",
    "These spheres constantly exchange matter and energy: volcanoes release gases into the atmosphere; plants draw carbon from the air and water from the soil; rain weathers rock; and oceans absorb heat and carbon dioxide."]],
  ["Biogeochemical cycles",[
    "Elements essential to life cycle through the spheres. In the carbon cycle, carbon moves between the atmosphere, oceans, living things, soils, and rocks; slow processes such as weathering and volcanism regulate climate over millions of years, while burning fossil fuels has rapidly shifted carbon from rocks to the air.",
    "In the nitrogen cycle, bacteria convert atmospheric nitrogen into usable forms; fertilizer production has roughly doubled the amount of reactive nitrogen entering ecosystems, causing pollution and dead zones. The phosphorus cycle moves slowly through rocks and soils, and phosphate rock is a limited resource for fertilizer."]],
  ["Energy flow in ecosystems",[
    "Ecosystems are powered by energy flowing from the Sun through producers to consumers and decomposers, with about 90 percent lost as heat at each step, which limits food chains to a few links. Matter, by contrast, is recycled.",
    "Ecological pyramids show how energy, biomass, and numbers decrease at higher trophic levels. Keystone species have outsized effects on their ecosystems: when wolves were reintroduced to Yellowstone in 1995, they reduced elk overgrazing, allowing vegetation and other species to recover, an example of a trophic cascade, though its extent is debated."]],
  ["Gaia and feedbacks",[
    "In the 1970s James Lovelock and Lynn Margulis proposed the Gaia hypothesis, that life interacts with Earth's environment to form a self-regulating system that maintains conditions suitable for life. Though controversial in its strong form, it helped inspire Earth system science.",
    "Feedbacks can stabilize or amplify change. Negative feedbacks, such as faster rock weathering removing carbon dioxide in warmer climates, stabilize; positive feedbacks, such as melting ice reducing reflectivity, amplify change."]],
  ["Planetary boundaries",[
    "The concept of planetary boundaries, introduced in 2009, identifies nine Earth-system processes, including climate change, biodiversity loss, nitrogen and phosphorus flows, land-system change, freshwater use, ocean acidification, ozone depletion, aerosols, and novel chemicals, with thresholds beyond which humanity risks destabilizing the Earth system. A 2023 assessment concluded that six of the nine had been crossed.",
    "Earth observation satellites, ocean floats such as the Argo network, and ice cores allow scientists to monitor the planet as never before."]],
  ["Comparative planetology",[
    "Studying other planets illuminates Earth. Venus shows a runaway greenhouse, Mars shows the loss of an atmosphere and water, and Titan shows a world with weather of methane.",
    "Earth's long-term habitability depends on a delicate balance of plate tectonics, the carbon cycle, the magnetic field, the oceans, and life itself, a balance humans now influence on a planetary scale."]]
  ],
  terms:[["Earth system science","Studying Earth as interconnected spheres."],["Biogeochemical cycle","The cycling of elements through living and nonliving systems."],["Trophic level","A step in a food chain."],["Keystone species","A species with outsized ecological effects."],["Gaia hypothesis","The idea that life helps regulate Earth's environment."],["Positive and negative feedback","Processes that amplify or stabilize change."],["Planetary boundaries","Thresholds for a stable Earth system."]],
  w:"Seeing Earth as an interconnected system explains how life, rock, water, and air shape one another, and how humans now influence the whole planet.",
  src:["Earth system science","Biogeochemical cycle","Carbon cycle","Nitrogen cycle","Trophic cascade","Gaia hypothesis","Planetary boundaries"],
  q:[["Which sphere includes all living things?","The biosphere","The geosphere","The hydrosphere","The atmosphere"],
     ["About how much energy is lost at each step of a food chain?","About 90 percent","About 10 percent","About 50 percent","None"],
     ["Which predator was reintroduced to Yellowstone in 1995?","Wolves","Grizzly bears","Mountain lions","Bison"],
     ["Who proposed the Gaia hypothesis?","James Lovelock and Lynn Margulis","Charles Darwin","Rachel Carson","Johan Rockström"],
     ["How many planetary boundaries are there?","Nine","Five","Twelve","Three"],
     ["What does melting ice do to warming?","Amplifies it by reducing reflectivity","Stops it","Has no effect","Reverses it"]]},

{ t:"The Science of Climate", s:"Physics, evidence, and models",
  sec:[
  ["The physics of the greenhouse effect",[
    "In 1824 Joseph Fourier realized that Earth is warmer than it would be from sunlight alone, suggesting the atmosphere traps heat. In 1856 the American scientist Eunice Foote showed that carbon dioxide absorbs heat from sunlight, and in 1859 John Tyndall measured how gases such as carbon dioxide and water vapor absorb infrared radiation. In 1896 Svante Arrhenius calculated that doubling carbon dioxide would warm Earth by several degrees.",
    "Greenhouse gas molecules, such as carbon dioxide, methane, nitrous oxide, and water vapor, absorb and re-emit infrared radiation because of how their atoms vibrate, while nitrogen and oxygen, which make up most of the air, do not."]],
  ["Measuring change",[
    "Charles David Keeling began measuring atmospheric carbon dioxide at Mauna Loa, Hawaii, in 1958; the Keeling Curve shows a steady rise, with a seasonal sawtooth as Northern Hemisphere plants grow and decay. CO₂ has risen from about 280 parts per million before industrialization to over 420 ppm in the 2020s, higher than at any time in at least 800,000 years, based on ice cores, and probably millions of years.",
    "Thermometer records, satellites, ocean floats, and ice measurements show global warming of about 1.2–1.3°C since the late 19th century, rising seas, shrinking ice, and more extreme heat."]],
  ["How we know it's us",[
    "Multiple lines of evidence show the warming is caused by humans. The extra carbon dioxide carries the chemical signature of fossil fuels: it is depleted in carbon-13 and lacks carbon-14, as ancient carbon should. The upper atmosphere (stratosphere) is cooling while the lower atmosphere warms, the pattern expected from greenhouse gases rather than a brighter Sun; and solar output has been flat or slightly declining since the 1980s.",
    "The Intergovernmental Panel on Climate Change concluded in 2021 that it is unequivocal that human influence has warmed the atmosphere, ocean, and land."]],
  ["Climate models",[
    "Climate models divide the atmosphere, oceans, land, and ice into grid boxes and solve the equations of physics to simulate climate. Syukuro Manabe built pioneering models in the 1960s, and Klaus Hasselmann linked weather and climate and identified human fingerprints; they shared the 2021 Nobel Prize in Physics with Giorgio Parisi.",
    "Models are tested by how well they reproduce past climates, including ice ages and the observed 20th-century warming. Early model projections from the 1970s and 1980s have proved largely accurate. Climate sensitivity, the warming from doubling CO₂, is estimated at about 2.5–4°C, likely around 3°C."]],
  ["Impacts and tipping points",[
    "Impacts include more intense heat waves, heavier rainfall and flooding, droughts, wildfires, sea level rise, ocean acidification, coral bleaching, shifting species ranges, and threats to food and water security. Impacts fall hardest on the poor and vulnerable.",
    "Scientists warn of potential tipping points, thresholds beyond which changes become self-sustaining and difficult to reverse, such as the loss of the Greenland and West Antarctic ice sheets, the dieback of the Amazon rainforest, the thawing of permafrost, and a weakening of the Atlantic Meridional Overturning Circulation."]],
  ["Solutions",[
    "Limiting warming requires reducing greenhouse gas emissions to net zero, by shifting electricity to solar, wind, hydro, and nuclear power, electrifying transport and heating, improving efficiency, reducing deforestation and methane leaks, changing agricultural practices, and possibly removing carbon dioxide from the air. Adaptation, preparing for changes already underway, is also essential.",
    "Solar and wind power costs fell dramatically in the 2010s, and renewables became the cheapest source of new electricity in much of the world. The science of climate change is one of the most important applications of physics, chemistry, and biology to the human future."]]
  ],
  terms:[["Greenhouse gas","A gas absorbing infrared radiation."],["Keeling Curve","The record of rising atmospheric CO₂."],["Isotopic fingerprint","Evidence that extra CO₂ comes from fossil fuels."],["Climate model","A computer simulation of the climate system."],["Climate sensitivity","Warming from doubling CO₂."],["Tipping point","A threshold beyond which change becomes self-sustaining."],["Net zero","Balancing emissions with removals."]],
  w:"Climate science rests on basic physics and multiple lines of evidence, and understanding it is essential for the choices facing humanity this century.",
  src:["Greenhouse effect","Eunice Newton Foote","Keeling Curve","Attribution of recent climate change","Climate model","Climate sensitivity","Tipping points in the climate system"],
  q:[["Who first showed carbon dioxide absorbs heat in 1856?","Eunice Foote","John Tyndall","Svante Arrhenius","Joseph Fourier"],
     ["What was pre-industrial CO₂ concentration?","About 280 ppm","About 420 ppm","About 100 ppm","About 1,000 ppm"],
     ["What does stratospheric cooling indicate?","Warming from greenhouse gases rather than the Sun","A brighter Sun","Volcanic activity","Ozone recovery only"],
     ["Who built pioneering climate models and shared the 2021 Nobel Prize?","Syukuro Manabe","James Hansen","Charles Keeling","Michael Mann"],
     ["What is the likely climate sensitivity to doubled CO₂?","About 3°C","About 0.5°C","About 10°C","About 1°C"],
     ["Which is a potential climate tipping point?","Loss of the Greenland ice sheet","A solar eclipse","The ozone hole","Plate tectonics"]]},

{ t:"Energy Technologies", s:"Powering the future",
  sec:[
  ["Generating electricity",[
    "Most electricity is generated by spinning turbines connected to generators, using electromagnetic induction. Steam to spin turbines comes from burning coal, oil, gas, or biomass, or from nuclear fission or geothermal heat; water, wind, and tides spin turbines directly. Solar photovoltaic cells are the main exception, converting light directly to electricity.",
    "In the mid-2020s, fossil fuels still produced roughly 60 percent of global electricity, but renewables were the fastest-growing source."]],
  ["Solar power",[
    "Photovoltaic (PV) cells, usually made of silicon, use the photoelectric effect: light knocks electrons loose, creating a current. Bell Labs demonstrated the first practical silicon solar cell in 1954, first used on satellites. The cost of solar panels fell by about 90 percent in the 2010s, making solar the cheapest electricity in history in many places; China manufactures most of the world's panels.",
    "Concentrated solar power uses mirrors to focus sunlight to heat a fluid and drive turbines, and can store heat to generate power after sunset."]],
  ["Wind and hydro",[
    "Wind turbines convert the kinetic energy of wind into electricity; modern offshore turbines are taller than most skyscrapers, with single blades over 100 meters long. Denmark generates over half its electricity from wind.",
    "Hydroelectric dams are the largest renewable source of electricity worldwide; Norway, Brazil, and Canada rely heavily on them. Pumped-storage hydropower stores energy by pumping water uphill when power is abundant and releasing it when needed, providing most of the world's grid storage."]],
  ["Nuclear power",[
    "Nuclear power plants use heat from fission of uranium-235 to make steam, producing large amounts of low-carbon electricity reliably; France gets about two-thirds of its electricity this way. Concerns include accidents, such as Chernobyl and Fukushima, long-lived radioactive waste, costs, and weapons proliferation; per unit of energy, however, nuclear power has caused far fewer deaths than fossil fuels, largely due to air pollution from fossil fuels.",
    "New designs, such as small modular reactors, and fusion research aim to make nuclear energy safer, cheaper, and more abundant."]],
  ["Storage and grids",[
    "Because solar and wind are variable, electricity systems need storage, flexible backup, and better grids. Lithium-ion battery costs fell by about 90 percent between 2010 and 2020, enabling electric vehicles and grid-scale batteries. Other options include pumped hydro, hydrogen produced by electrolysis, and long-distance transmission lines connecting regions with different weather.",
    "Smart grids use digital technology to balance supply and demand, and demand response encourages users to shift electricity use to times of abundant power."]],
  ["Efficiency and electrification",[
    "Using energy more efficiently is often the cheapest way to cut emissions: LED lighting uses about 75–90 percent less electricity than incandescent bulbs; insulation reduces heating needs; and heat pumps can provide three to four units of heat for each unit of electricity.",
    "Electric vehicles, whose motors are far more efficient than combustion engines, are growing rapidly; by the mid-2020s, they made up a large share of new car sales in China and parts of Europe. The energy transition is one of the largest engineering projects in history."]]
  ],
  terms:[["Turbine","A rotating machine driving a generator."],["Photovoltaic cell","A device converting light directly into electricity."],["Pumped storage","Storing energy by pumping water uphill."],["Small modular reactor","A compact, factory-built nuclear reactor design."],["Smart grid","A digitally managed electricity network."],["Heat pump","A device moving heat efficiently using electricity."],["Energy transition","The shift from fossil fuels to clean energy."]],
  w:"Energy technologies determine how humanity powers its civilization, and the shift to clean energy is central to addressing climate change.",
  src:["Electricity generation","Photovoltaics","Wind power","Hydroelectricity","Nuclear power","Grid energy storage","Heat pump"],
  q:[["How do photovoltaic cells generate electricity?","Light knocks electrons loose in a semiconductor","By spinning turbines","By burning fuel","By magnetism alone"],
     ["When was the first practical silicon solar cell demonstrated?","1954","1905","1980","2000"],
     ["Which is the largest renewable source of electricity worldwide?","Hydroelectric power","Solar","Wind","Geothermal"],
     ["Which country gets about two-thirds of its electricity from nuclear power?","France","Germany","Japan","Canada"],
     ["By about how much did lithium-ion battery costs fall from 2010 to 2020?","About 90 percent","About 10 percent","About 50 percent","They rose"],
     ["How many units of heat can a heat pump provide per unit of electricity?","Three to four","One","Ten","Half"]]},

{ t:"Great Experiments", s:"Moments that changed science",
  sec:[
  ["Measuring the Earth",[
    "Around 240 BCE, Eratosthenes noticed that at noon on the summer solstice, the Sun shone directly down a well in Syene (Aswan) but cast a shadow of about 7 degrees in Alexandria. Knowing the distance between the cities, he calculated Earth's circumference with remarkable accuracy, an elegant use of geometry and observation.",
    "In 1798 Henry Cavendish used a delicate torsion balance to measure the tiny gravitational attraction between lead spheres, allowing the mass and density of the Earth to be calculated."]],
  ["Light and atoms",[
    "Newton's prism experiments (1666) showed that white light is a mixture of colors. Thomas Young's double-slit experiment (1801) showed light behaves as a wave. The Michelson-Morley experiment (1887), designed to detect the ether, produced a famous null result that paved the way for relativity.",
    "Ernest Rutherford's gold foil experiment (1909–1911), carried out by Hans Geiger and Ernest Marsden, revealed the atomic nucleus. Robert Millikan's oil drop experiment (1909) measured the charge of a single electron."]],
  ["Life's secrets",[
    "Louis Pasteur's swan-neck flask experiment (1859) showed that broth boiled in a flask with a curved neck, which let in air but trapped dust, did not grow microbes, disproving spontaneous generation, the idea that life arises from nonliving matter.",
    "Mendel's pea experiments revealed the laws of inheritance. The Meselson-Stahl experiment (1958), often called “the most beautiful experiment in biology,” showed how DNA replicates using heavy and light isotopes of nitrogen."]],
  ["Medicine and psychology",[
    "James Lind's scurvy trial (1747) aboard HMS Salisbury, giving different treatments to groups of sailors, was an early controlled trial that showed citrus fruit cures scurvy. Edward Jenner's 1796 test of cowpox inoculation, by today's standards ethically troubling because he exposed a boy to smallpox, launched vaccination.",
    "In psychology, Stanley Milgram's obedience experiments (1961) showed that many people would administer what they believed were dangerous electric shocks when instructed by an authority figure, raising both insights and serious ethical concerns that shaped modern research rules."]],
  ["Big science",[
    "Some modern experiments require enormous collaborations. The discovery of the Higgs boson at the Large Hadron Collider involved thousands of scientists from dozens of countries. LIGO's detection of gravitational waves required measuring changes smaller than a thousandth of a proton's width.",
    "The 1919 eclipse expeditions confirming general relativity and the detection of the cosmic microwave background also show how a single observation can confirm or overturn theories."]],
  ["What makes an experiment great",[
    "Great experiments often share features: a clear question, elegant design, careful controls, and results that decisively distinguish between competing ideas. Many were simple and cheap, while others pushed technology to its limits.",
    "They also show science as a human story of curiosity, persistence, luck, and sometimes ethical lessons. Replicating classic experiments remains one of the best ways to learn science."]]
  ],
  terms:[["Torsion balance","A sensitive instrument measuring tiny forces."],["Null result","An experiment finding no expected effect."],["Spontaneous generation","The disproven idea that life arises from nonliving matter."],["Controlled trial","An experiment comparing treated and untreated groups."],["Research ethics","Principles protecting subjects of research."],["Big science","Large, collaborative, expensive research projects."]],
  w:"Great experiments show how science actually advances, through clever questions and careful tests that reshape our understanding of the world.",
  src:["Eratosthenes","Cavendish experiment","Geiger–Marsden experiments","Oil drop experiment","Spontaneous generation","Meselson–Stahl experiment","Milgram experiment"],
  q:[["Who measured Earth's circumference using shadows?","Eratosthenes","Ptolemy","Archimedes","Aristotle"],
     ["Who measured the charge of the electron with oil drops?","Robert Millikan","J. J. Thomson","Ernest Rutherford","Niels Bohr"],
     ["What did Pasteur's swan-neck flask disprove?","Spontaneous generation","Germ theory","Evolution","Vaccination"],
     ["Which experiment is called the most beautiful in biology?","The Meselson-Stahl experiment","Mendel's peas","The Miller-Urey experiment","Griffith's experiment"],
     ["What did Milgram's experiments study?","Obedience to authority","Memory","Conditioning","Perception"],
     ["Who carried out Rutherford's gold foil experiment?","Geiger and Marsden","Millikan and Thomson","Bohr and Chadwick","Curie and Becquerel"]]},

{ t:"The People of Science", s:"Who does science, and who gets credit",
  sec:[
  ["Science as a human enterprise",[
    "Science is done by people, shaped by their societies, institutions, and opportunities. For much of history, access to scientific education and careers was limited by gender, race, class, and nationality, and many contributors were overlooked.",
    "Science has also been a global enterprise: mathematics from India and the Islamic world, Chinese inventions such as paper, printing, the compass, and gunpowder, and astronomical knowledge from Babylon and the Maya all contributed to modern science."]],
  ["Women in science",[
    "Women made important contributions despite exclusion. Hypatia of Alexandria (died 415 CE) taught mathematics and astronomy. Émilie du Châtelet translated Newton's Principia into French in the 18th century with influential commentary. Caroline Herschel discovered several comets. Ada Lovelace wrote the first published computer program. Marie Curie won two Nobel Prizes.",
    "Lise Meitner, who explained nuclear fission, was left out of the 1944 Nobel Prize awarded to Otto Hahn. Rosalind Franklin's X-ray images were essential to discovering DNA's structure. Barbara McClintock discovered “jumping genes” and won the 1983 Nobel Prize after decades of being overlooked. Women remain underrepresented in many fields, especially physics and engineering, though participation has grown greatly."]],
  ["Hidden figures",[
    "Many contributors worked behind the scenes. At Harvard Observatory in the late 19th and early 20th centuries, women “computers,” including Williamina Fleming, Annie Jump Cannon, and Henrietta Swan Leavitt, classified stars and made fundamental discoveries for low pay.",
    "At NASA, African American mathematicians Katherine Johnson, Dorothy Vaughan, and Mary Jackson made crucial contributions to the space program, celebrated in the 2016 book and film Hidden Figures. The chemist Alice Ball developed the first effective injectable treatment for leprosy in 1915 but died young, and her work was initially credited to someone else."]],
  ["Scientists across the world",[
    "Major scientists came from many backgrounds: the Indian mathematician Srinivasa Ramanujan, largely self-taught, produced extraordinary results; C. V. Raman won the 1930 Nobel Prize for discovering light scattering; Abdus Salam, from Pakistan, shared the 1979 Nobel Prize for electroweak unification; and Tu Youyou discovered artemisinin.",
    "The Black American scientist George Washington Carver promoted crop rotation and peanut-based products, and Charles Drew pioneered blood banking during World War II. Increasing diversity in science broadens the questions asked and the talent available."]],
  ["Collaboration and credit",[
    "Modern science is highly collaborative; papers in particle physics can have thousands of authors. Credit has often been unevenly assigned, a pattern the sociologist Robert Merton called the “Matthew effect,” in which famous scientists receive disproportionate credit. The Nobel Prize, limited to three people per prize, does not always reflect how discoveries are made.",
    "Fair attribution, open sharing of data, and mentoring of young scientists from all backgrounds are now widely seen as essential to good science."]],
  ["You and science",[
    "Citizen science allows anyone to contribute: volunteers classify galaxies on Galaxy Zoo, count birds in the Christmas Bird Count, run in the Audubon tradition since 1900, record observations on iNaturalist, and fold proteins in the game Foldit. Amateur astronomers discover comets and supernovae.",
    "Science is not only a body of knowledge but a way of thinking that anyone can practice: curiosity, careful observation, skepticism, and openness to evidence."]]
  ],
  terms:[["Hidden figures","Overlooked contributors to science."],["Harvard computers","Women who analyzed astronomical data at Harvard."],["Matthew effect","Disproportionate credit to famous scientists."],["Citizen science","Public participation in research."],["Jumping genes","Transposable elements discovered by McClintock."]],
  w:"Knowing the people of science, including those long overlooked, shows that science is a global human endeavor open to anyone curious.",
  src:["Women in science","Émilie du Châtelet","Lise Meitner","Barbara McClintock","Harvard Computers","Katherine Johnson","Citizen science"],
  q:[["Who translated Newton's Principia into French?","Émilie du Châtelet","Caroline Herschel","Ada Lovelace","Hypatia"],
     ["Who explained nuclear fission but was left out of the Nobel Prize?","Lise Meitner","Marie Curie","Irène Joliot-Curie","Chien-Shiung Wu"],
     ["Who discovered jumping genes?","Barbara McClintock","Rosalind Franklin","Gertrude Elion","Dorothy Hodgkin"],
     ["Which NASA mathematician was featured in Hidden Figures?","Katherine Johnson","Grace Hopper","Sally Ride","Mae Jemison"],
     ["Who developed the first effective injectable leprosy treatment in 1915?","Alice Ball","Charles Drew","George Washington Carver","Percy Julian"],
     ["What is public participation in research called?","Citizen science","Big science","Peer review","Open access"]]},

{ t:"Science, Ethics, and Misinformation", s:"Using science wisely",
  sec:[
  ["Science and values",[
    "Science tells us how the world works, but deciding what to do with that knowledge involves values. Nuclear physics gave both power plants and bombs; genetics offers cures and raises questions about designer babies; chemistry produces medicines and pollutants. Scientists such as Joseph Rotblat, who left the Manhattan Project and later won the 1995 Nobel Peace Prize, have campaigned for responsible use of science.",
    "Bioethics addresses questions about human research, genetic engineering, end-of-life care, animal experimentation, and the fair distribution of medical resources."]],
  ["Research ethics",[
    "Abuses in the past led to strict research rules. Nazi doctors performed atrocious experiments on concentration camp prisoners, leading to the Nuremberg Code (1947), which requires voluntary informed consent. In the Tuskegee syphilis study (1932–1972), U.S. Public Health Service researchers withheld treatment from hundreds of Black men to observe the disease's progression, even after penicillin became standard; its exposure led to the Belmont Report (1979) and modern ethics review boards.",
    "Today, research on humans requires informed consent, independent ethical review, and protection of vulnerable groups, and research on animals follows principles of replacement, reduction, and refinement."]],
  ["Misinformation",[
    "Misinformation, false or misleading claims, spreads rapidly online. Examples include claims that vaccines cause autism, that climate change is a hoax, and false cures during the COVID-19 pandemic. Disinformation is deliberately false information. Some industries have deliberately sown doubt: tobacco companies for decades disputed the link between smoking and cancer, a strategy later used against climate science, as documented by historians Naomi Oreskes and Erik Conway in Merchants of Doubt (2010).",
    "Misinformation exploits cognitive biases such as confirmation bias, the tendency to favor information that confirms existing beliefs."]],
  ["Evaluating claims",[
    "Useful questions for judging a scientific claim include: Who is making it, and what is their expertise and interest? Is it published in a peer-reviewed source? Does it reflect the consensus of experts or a lone contrarian? Is the evidence anecdotal or from large, controlled studies? Has it been replicated? Does the headline match the study? Correlation or causation?",
    "Scientific consensus, the collective judgment of experts based on evidence, is not infallible but is the most reliable guide available; it can change when strong new evidence emerges, as it should."]],
  ["Uncertainty and trust",[
    "Science always involves uncertainty, which is honestly reported through error bars and confidence levels. Uncertainty does not mean ignorance: we may not know exactly how much sea level will rise, but we know it is rising and why.",
    "Public trust in science depends on transparency, honesty about uncertainty and mistakes, and communication that respects people's questions. Scientists also have a responsibility to avoid overstating results."]],
  ["Scientific literacy",[
    "Scientific literacy, understanding key concepts and how science works, helps people make decisions about health, technology, and the environment, and participate in public debates. It includes understanding probability and risk, the difference between hypotheses and theories, and the importance of evidence.",
    "Richard Feynman's advice applies broadly: “The first principle is that you must not fool yourself, and you are the easiest person to fool.”"]]
  ],
  terms:[["Bioethics","Ethics of biology and medicine."],["Informed consent","Agreement to participate after understanding risks."],["Nuremberg Code","The 1947 principles for ethical human research."],["Misinformation and disinformation","False claims vs. deliberately false claims."],["Confirmation bias","Favoring information that confirms beliefs."],["Scientific consensus","The collective judgment of experts based on evidence."],["Scientific literacy","Understanding science and how it works."]],
  w:"Using science wisely requires ethics, critical thinking, and the ability to separate reliable evidence from misinformation.",
  src:["Bioethics","Nuremberg Code","Tuskegee syphilis study","Belmont Report","Misinformation","Merchants of Doubt","Scientific consensus"],
  q:[["Which 1947 code requires informed consent?","The Nuremberg Code","The Belmont Report","The Hippocratic Oath","The Geneva Convention"],
     ["Which study withheld syphilis treatment from Black men?","The Tuskegee study","The Milgram experiment","The Stanford prison experiment","The Framingham study"],
     ["Who wrote Merchants of Doubt?","Naomi Oreskes and Erik Conway","Rachel Carson","Carl Sagan","Richard Dawkins"],
     ["What is the tendency to favor information confirming beliefs?","Confirmation bias","Peer review","Consensus","Replication"],
     ["Who said you must not fool yourself, and you are the easiest person to fool?","Richard Feynman","Albert Einstein","Carl Sagan","Karl Popper"],
     ["Which physicist left the Manhattan Project and won the Nobel Peace Prize?","Joseph Rotblat","J. Robert Oppenheimer","Leo Szilard","Niels Bohr"]]},

{ t:"The Frontiers of Science", s:"The great open questions",
  sec:[
  ["Physics and the cosmos",[
    "Despite enormous progress, deep questions remain. What are dark matter and dark energy, which make up about 95 percent of the universe? How can quantum mechanics and general relativity be unified into a theory of quantum gravity? Why is there more matter than antimatter? What happened at or before the Big Bang?",
    "Why do the fundamental constants of nature have the values they do, values that seem finely tuned for complex structures and life? Is our universe one of many?"]],
  ["Life and the mind",[
    "How did life begin from non-living chemistry? Is there life elsewhere in the universe? How does the brain produce consciousness, the subjective experience of being aware, what the philosopher David Chalmers called the “hard problem”?",
    "How exactly do genes and environment interact to shape development, behavior, and disease? Can aging be slowed significantly? How do complex ecosystems maintain stability?"]],
  ["Mathematics and computing",[
    "Famous unsolved mathematical problems include the Riemann Hypothesis and the P versus NP problem, two of the Millennium Prize Problems announced in 2000 with a million-dollar prize each; only one, the Poincaré conjecture, has been solved, by Grigori Perelman, who declined the prize.",
    "Quantum computers may solve certain problems far faster than classical computers. Artificial intelligence is advancing rapidly, raising questions about its capabilities, limits, and safe development."]],
  ["Technologies on the horizon",[
    "Emerging technologies include gene therapies and CRISPR-based treatments, mRNA vaccines for cancer and other diseases, practical fusion power, room-temperature superconductors (long sought, not yet achieved), brain-computer interfaces, synthetic biology that designs new organisms, and advanced materials.",
    "Each brings potential benefits and risks that society must weigh."]],
  ["Global challenges",[
    "Science is central to humanity's greatest challenges: climate change, biodiversity loss, pandemics, antibiotic resistance, feeding a population approaching 10 billion, clean water, and sustainable energy. Solving them requires not only discovery but cooperation, wise policy, and public engagement.",
    "International scientific cooperation, from the International Space Station to CERN and the IPCC, shows what nations can achieve together."]],
  ["Where to go next",[
    "These foundations have covered how science works, mathematics, physics, chemistry, biology, the human body, Earth, and the universe. Each field opens branches for deeper study: quantum physics, organic chemistry, genetics, neuroscience, ecology, astronomy, and more.",
    "As Isaac Newton reportedly said, he seemed to himself “like a boy playing on the sea-shore… whilst the great ocean of truth lay all undiscovered before me.” Science never finishes; every answer reveals new questions, which is exactly what makes it endlessly rewarding."]]
  ],
  terms:[["Quantum gravity","A hoped-for theory unifying quantum mechanics and gravity."],["Hard problem of consciousness","Explaining subjective experience."],["Millennium Prize Problems","Seven famous unsolved mathematical problems."],["Quantum computer","A computer using quantum superposition."],["Synthetic biology","Designing and building new biological systems."]],
  w:"The frontiers of science remind us how much remains unknown and invite each of us to keep learning and questioning.",
  src:["List of unsolved problems in physics","Hard problem of consciousness","Millennium Prize Problems","Grigori Perelman","Quantum computing","Synthetic biology","Abiogenesis"],
  q:[["What share of the universe is dark matter and dark energy?","About 95 percent","About 50 percent","About 5 percent","About 25 percent"],
     ["Who named the hard problem of consciousness?","David Chalmers","Daniel Dennett","René Descartes","Francis Crick"],
     ["Which Millennium Prize Problem has been solved?","The Poincaré conjecture","The Riemann Hypothesis","P versus NP","Navier-Stokes"],
     ["Who solved the Poincaré conjecture and declined the prize?","Grigori Perelman","Andrew Wiles","Terence Tao","John Nash"],
     ["Which technology uses superposition to compute?","Quantum computers","Classical computers","Abacuses","Calculators"],
     ["Who compared himself to a boy playing on the seashore?","Isaac Newton","Albert Einstein","Charles Darwin","Galileo"]]}

]});
