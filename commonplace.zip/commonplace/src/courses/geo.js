/* ---- from geo-01.js ---- */
/* GEOGRAPHY FOUNDATIONS, part 1: Unit 1 The Geographer's Toolkit */
COURSES.geography = { units: [] };
COURSES.geography.units.push({ t:"The Geographer's Toolkit", ch:[

{ t:"What Is Geography?", s:"The study of places, spaces, and the relationships between people and environments",
  sec:[
  ["Writing the Earth",[
    "The word geography comes from Greek words meaning “earth writing” or “describing the Earth.” The Greek scholar Eratosthenes, who led the Library of Alexandria in the 3rd century BCE, is often credited with coining the term, and he famously estimated the circumference of the Earth by comparing the angle of the Sun's rays at Syene and Alexandria. His estimate was remarkably close to the true figure of about 40,000 kilometers.",
    "Today geography is the study of the Earth's surface: its physical features, its climates and ecosystems, the people who live on it, and the ways all of these interact across space. Geographers ask three basic questions: Where is something? Why is it there? And why does that location matter?"]],
  ["Physical and human geography",[
    "The discipline has two great branches. Physical geography studies natural systems: landforms, rivers, oceans, weather, climate, soils, vegetation, and the processes that shape them. It overlaps with geology, meteorology, hydrology, and ecology.",
    "Human geography studies people and their activities in space: population, migration, cities, cultures, languages, religions, economies, agriculture, and political boundaries. It overlaps with economics, sociology, history, and political science. A third area, environmental geography, focuses on the interactions between people and nature, such as deforestation, water use, and natural hazards."]],
  ["The five themes of geography",[
    "In 1984 American geography educators summarized the field in five themes. Location describes where a place is, either absolutely (with coordinates) or relatively (in relation to other places). Place describes what a location is like, its physical and human characteristics.",
    "Human-environment interaction describes how people adapt to, modify, and depend on their environment. Movement describes the flow of people, goods, and ideas between places. Region describes areas that share common characteristics, such as a climate region, a language region, or a political unit. These themes remain a useful checklist for analyzing any place."]],
  ["Space, scale, and region",[
    "Geographers think carefully about scale, the level at which something is studied: local, regional, national, or global. Patterns can look very different at different scales; a country may be wealthy on average while containing very poor regions.",
    "Regions come in several types. Formal regions share a measurable characteristic, such as the Corn Belt or a country. Functional regions are organized around a central node, such as a city and the suburbs whose people commute to it. Perceptual (or vernacular) regions exist in people's minds, such as “the South” in the United States or “the Midwest,” with fuzzy and debated borders."]],
  ["A brief history of the discipline",[
    "Ancient geographers such as Strabo, whose Geography described the Roman world, and Claudius Ptolemy, who in the 2nd century CE compiled coordinates for thousands of places, laid the foundations. Medieval Islamic scholars such as al-Idrisi, who made a famous world map for King Roger II of Sicily in 1154, and travelers such as Ibn Battuta greatly expanded geographical knowledge.",
    "Modern academic geography began in the 19th century with the Germans Alexander von Humboldt, who studied how climate, altitude, and vegetation are related, and Carl Ritter. Since then geography has developed new approaches, from quantitative spatial analysis to the study of culture and inequality, and today relies heavily on satellite data and computer mapping."]],
  ["Why geography matters",[
    "Geography helps explain why cities grow where they do, why some regions are rich and others poor, why wars are fought over particular borders and rivers, why diseases spread along certain routes, and why disasters strike particular places.",
    "It is also a practical skill: reading maps, understanding climate and terrain, knowing where countries and resources are, and seeing how local events connect to global systems. The rest of this course builds the essential knowledge: the tools of geography, the physical Earth, the human world, and the regions of the planet."]]
  ],
  terms:[["Geography","The study of the Earth's surface, its features, people, and their relationships."],["Physical geography","The study of natural systems such as landforms and climate."],["Human geography","The study of people and their activities in space."],["Scale","The level at which a phenomenon is studied, from local to global."],["Formal region","An area sharing a measurable characteristic."],["Functional region","An area organized around a central node."],["Perceptual region","A region defined by people's shared ideas."]],
  w:"Geography is the framework for understanding where things are and why, connecting the natural world to every human activity.",
  src:["Geography","Eratosthenes","Five themes of geography","Region","Alexander von Humboldt","Human geography","Physical geography"],
  q:[["What does the word geography originally mean?","Earth writing","Land measuring","World travel","Map drawing"],
     ["Which Greek scholar estimated the Earth's circumference?","Eratosthenes","Ptolemy","Strabo","Herodotus"],
     ["Which of these is one of the five themes of geography?","Movement","Chronology","Demography","Cartography"],
     ["A city and the suburbs whose residents commute to it form what kind of region?","Functional","Formal","Perceptual","Vernacular"],
     ["Which medieval geographer made a world map for King Roger II of Sicily?","Al-Idrisi","Ibn Battuta","Ibn Khaldun","Al-Biruni"],
     ["Which 19th-century German studied links between climate, altitude, and vegetation?","Alexander von Humboldt","Carl Ritter","Friedrich Ratzel","Gerardus Mercator"]]},

{ t:"Maps and Projections", s:"How we flatten a round world",
  sec:[
  ["What a map is",[
    "A map is a simplified, scaled representation of part of the Earth's surface. All maps select, simplify, and symbolize; no map shows everything. Reference maps, such as road atlases and topographic maps, show the locations of features. Thematic maps show the distribution of a particular subject, such as population density, rainfall, or election results.",
    "Every good map has essential elements: a title, a legend (or key) explaining symbols, a scale, an orientation indicator such as a north arrow, and information about the source and date. Reading a map critically means asking what it shows, what it leaves out, and why."]],
  ["Scale",[
    "Map scale is the relationship between distance on the map and distance on the ground. It can be shown as a ratio or representative fraction, such as 1:50,000, meaning one unit on the map equals 50,000 of the same units on the ground; as a written statement, such as “one centimeter equals one kilometer”; or as a graphic bar scale.",
    "A large-scale map (such as 1:10,000) shows a small area in great detail, such as a town. A small-scale map (such as 1:10,000,000) shows a large area, such as a continent, with little detail. The terms can be confusing: “large scale” means the fraction is larger, so features appear larger."]],
  ["The projection problem",[
    "Because the Earth is a sphere (more precisely, a slightly flattened sphere called an oblate spheroid), it cannot be flattened onto paper without distortion, just as an orange peel cannot be flattened without tearing or stretching. A map projection is a systematic method of transferring the curved surface to a flat plane.",
    "Every projection distorts at least one of four properties: shape, area, distance, or direction. Conformal projections preserve local shapes and angles; equal-area projections preserve relative sizes; equidistant projections preserve distances from certain points; azimuthal projections preserve directions from a central point. No flat map can preserve all of these at once."]],
  ["Famous projections",[
    "The Mercator projection, created by the Flemish cartographer Gerardus Mercator in 1569, is conformal and shows lines of constant compass bearing as straight lines, which made it invaluable for navigation. But it greatly exaggerates areas near the poles: Greenland appears about as large as Africa, although Africa is roughly fourteen times bigger. Web maps use a variant called Web Mercator.",
    "Equal-area projections, such as the Gall-Peters projection promoted in the 1970s, show true relative sizes but distort shapes. Compromise projections balance distortions: the Robinson projection (1963) and the Winkel tripel projection, adopted by the National Geographic Society in 1998, are widely used for world maps. Polar maps often use azimuthal projections, and the United Nations emblem uses an azimuthal equidistant projection centered on the North Pole."]],
  ["Showing terrain and data",[
    "Topographic maps show the shape of the land using contour lines, lines connecting points of equal elevation. Closely spaced contours indicate steep slopes; widely spaced contours indicate gentle slopes. The contour interval is the difference in elevation between adjacent lines. Shaded relief and color tints also help show terrain.",
    "Thematic maps use several techniques. Choropleth maps shade areas such as countries by a value, such as income per person. Dot density maps use dots to represent quantities. Proportional symbol maps use symbols sized by value. Isoline maps connect points of equal value, such as isotherms for temperature and isobars for air pressure. Flow maps show movement, such as migration or trade."]],
  ["Maps and power",[
    "Maps have always been tools of power: for taxation, war, colonization, and claiming territory. European powers drew borders across Africa at the Berlin Conference of 1884–1885 with little regard for the people who lived there. Maps can also mislead through choices of projection, color, classification, or what is left out.",
    "Mental maps, the images of places that people carry in their heads, shape how they understand the world; many people overestimate the size of their own country and underestimate distant regions. Learning to read maps critically is one of the most useful skills in geography."]]
  ],
  terms:[["Thematic map","A map showing the distribution of a particular subject."],["Map scale","The ratio of map distance to ground distance."],["Map projection","A method of representing the curved Earth on a flat surface."],["Mercator projection","A 1569 conformal projection used for navigation that distorts area."],["Contour line","A line joining points of equal elevation."],["Choropleth map","A map shading areas by a data value."],["Isoline","A line connecting points of equal value."]],
  w:"Maps are the geographer's most important tool, and understanding scale, projection, and symbolization lets you read them accurately and critically.",
  src:["Map","Scale (map)","Map projection","Mercator projection","Contour line","Choropleth map","Winkel tripel projection"],
  q:[["What does a map scale of 1:50,000 mean?","One unit on the map equals 50,000 units on the ground","The map covers 50,000 square kilometers","The map is 50,000 years old","One centimeter equals 50 kilometers"],
     ["Which kind of map shows a small area in great detail?","Large-scale","Small-scale","Choropleth","Azimuthal"],
     ["Which property does the Mercator projection preserve?","Shape and direction","Area","Distance from all points","All properties"],
     ["On a Mercator map, which landmass looks misleadingly as large as Africa?","Greenland","Australia","Antarctica","South America"],
     ["What do closely spaced contour lines indicate?","A steep slope","Flat land","A river","A lake"],
     ["Which projection did National Geographic adopt in 1998?","Winkel tripel","Robinson","Mercator","Gall-Peters"]]},

{ t:"Location: Latitude, Longitude, and Time", s:"The global grid and how we tell time across it",
  sec:[
  ["Absolute and relative location",[
    "Absolute location identifies a precise point using a coordinate system, such as latitude and longitude. Relative location describes a place in relation to other places: for example, Chicago is on the southwestern shore of Lake Michigan, about 1,150 kilometers west of New York.",
    "Geographers also distinguish site, the physical characteristics of a place itself (such as a defensible hill, a harbor, or a river crossing), from situation, its location relative to other places and networks. Singapore's site is a small island, but its situation at the southern end of the Strait of Malacca, on one of the world's busiest shipping routes, made it a global hub."]],
  ["Latitude",[
    "Latitude measures distance north or south of the Equator, from 0 degrees at the Equator to 90 degrees at the North and South Poles. Lines of latitude, called parallels, run east-west and are parallel to one another. Each degree of latitude is about 111 kilometers. Degrees are divided into 60 minutes and each minute into 60 seconds.",
    "Several parallels are especially important. The Tropic of Cancer (about 23.4° N) and the Tropic of Capricorn (about 23.4° S) mark the farthest points north and south where the Sun can be directly overhead. The Arctic Circle (about 66.6° N) and Antarctic Circle (about 66.6° S) mark where at least one day a year has 24 hours of daylight or darkness. These lines result from the tilt of Earth's axis."]],
  ["Longitude",[
    "Longitude measures distance east or west of the Prime Meridian, from 0 to 180 degrees. Lines of longitude, called meridians, run from pole to pole and converge at the poles, so the distance between them shrinks from about 111 kilometers at the Equator to zero at the poles.",
    "The Prime Meridian runs through the Royal Observatory at Greenwich, London, and was adopted internationally at the International Meridian Conference in Washington in 1884. Finding longitude at sea was a major problem for navigators until John Harrison's accurate marine chronometers in the 18th century allowed sailors to compare local time with Greenwich time. Coordinates are written with latitude first: for example, the Eiffel Tower is at about 48.86° N, 2.29° E."]],
  ["Hemispheres and the global grid",[
    "The Equator divides the Earth into the Northern and Southern Hemispheres; the Prime Meridian and the 180th meridian divide it into the Eastern and Western Hemispheres. About 90 percent of the world's population lives in the Northern Hemisphere, which also contains most of the land.",
    "The network of parallels and meridians forms the graticule, or global grid. Great circles, such as the Equator and every meridian paired with its opposite, divide the Earth into two equal halves; the shortest route between two points on a sphere follows a great circle, which is why long-distance flights from North America to Asia pass over the Arctic."]],
  ["Time zones",[
    "Because the Earth rotates 360 degrees in 24 hours, it turns 15 degrees each hour. In principle this divides the world into 24 time zones, each about 15 degrees of longitude wide. Standard time zones were introduced by railroads in the 1880s, since every town had kept its own local solar time, which made train schedules chaotic.",
    "In practice, time-zone boundaries follow political borders. China, though it spans about five geographic time zones, uses a single time zone. Some places use half-hour or 45-minute offsets, such as India (UTC+5:30) and Nepal (UTC+5:45). The world's reference time is Coordinated Universal Time (UTC), essentially the successor to Greenwich Mean Time. Many countries use daylight saving time in summer."]],
  ["The International Date Line and GPS",[
    "The International Date Line, roughly following the 180° meridian through the Pacific Ocean, is where the calendar date changes. Crossing it westward, travelers jump forward a day; crossing eastward, they go back a day. It zigzags to avoid splitting countries; Kiribati moved it in 1995 so that all its islands share the same date.",
    "Today, location is usually determined by satellite navigation. The U.S. Global Positioning System (GPS), fully operational since the mid-1990s, uses a constellation of satellites broadcasting precise time signals; a receiver calculates its position from the signals of at least four satellites. Other systems include Russia's GLONASS, Europe's Galileo, and China's BeiDou."]]
  ],
  terms:[["Latitude","Angular distance north or south of the Equator."],["Longitude","Angular distance east or west of the Prime Meridian."],["Prime Meridian","The 0° meridian through Greenwich, London."],["Site and situation","A place's own physical traits vs. its location relative to others."],["Great circle","A circle dividing a sphere into equal halves; the shortest route between points."],["UTC","Coordinated Universal Time, the world's reference time."],["International Date Line","The line, near 180°, where the calendar date changes."]],
  w:"Latitude, longitude, and time zones form the coordinate system that lets anyone locate any place on Earth and understand how time varies around the globe.",
  src:["Latitude","Longitude","Prime meridian","Tropic of Cancer","Time zone","International Date Line","Global Positioning System"],
  q:[["What is the latitude of the Equator?","0°","90°","23.4°","180°"],
     ["Where does the Prime Meridian run?","Greenwich, London","Paris","Washington, D.C.","Rome"],
     ["Roughly how far is one degree of latitude?","111 kilometers","15 kilometers","1,000 kilometers","60 kilometers"],
     ["How many degrees does the Earth rotate each hour?","15","24","30","360"],
     ["Who solved the longitude problem with accurate marine clocks?","John Harrison","Isaac Newton","James Cook","Gerardus Mercator"],
     ["What happens when you cross the International Date Line traveling west?","You move forward one day","You move back one day","Nothing changes","You gain one hour"]]},

{ t:"GIS, Remote Sensing, and Fieldwork", s:"Modern tools for studying the Earth",
  sec:[
  ["Geographic information systems",[
    "A geographic information system (GIS) is a computer system for capturing, storing, analyzing, and displaying data tied to locations. GIS organizes information in layers, such as roads, rivers, land use, population, and elevation, which can be overlaid and analyzed together. The Canadian geographer Roger Tomlinson developed the first major GIS in the 1960s for the Canada Land Inventory.",
    "GIS is used everywhere: city planners choose sites for schools, epidemiologists map disease outbreaks, businesses decide where to open stores, emergency services route ambulances, and conservationists track habitats. Spatial data comes in two main forms: vector data, which uses points, lines, and polygons, and raster data, which uses a grid of cells, like pixels in a photograph."]],
  ["Remote sensing",[
    "Remote sensing is the collection of information about the Earth from a distance, usually from aircraft or satellites. Aerial photography began with cameras on balloons in the 1850s and became vital for military reconnaissance in World War I.",
    "Satellites changed everything. The U.S. Landsat program, begun in 1972, has produced the longest continuous satellite record of the Earth's land surface. Sensors measure not only visible light but also infrared and other wavelengths, revealing vegetation health, water, heat, and land use. Radar can see through clouds and at night, and LiDAR, which uses laser pulses, can map terrain in fine detail, even beneath forest canopies."]],
  ["Uses of remote sensing",[
    "Satellite data allow scientists to monitor deforestation in the Amazon, the melting of glaciers and sea ice, crop conditions, urban growth, droughts, wildfires, and the paths of hurricanes. Weather satellites have transformed forecasting since the first, TIROS-1, launched in 1960.",
    "Remote sensing has also revealed hidden archaeological sites, such as large settlements and road networks beneath the forests of Central America and the Amazon, mapped with LiDAR. Free tools such as Google Earth, launched in 2005, put satellite imagery in the hands of anyone with an internet connection."]],
  ["Fieldwork and observation",[
    "Despite advanced technology, geographers still rely on fieldwork: observing, measuring, interviewing, and sampling in the real world. Physical geographers measure river flows, collect soil and ice cores, and map landforms. Human geographers conduct surveys and interviews, observe how people use spaces, and study archives.",
    "Fieldwork provides “ground truth” to check what remote data suggests. A classic example of geographic analysis is the London physician John Snow's map of cholera deaths in Soho in 1854, which showed deaths clustered around a water pump on Broad Street and helped establish that cholera was spread through contaminated water."]],
  ["Data and statistics",[
    "Geographers use many data sources: national censuses, which most countries carry out every ten years; surveys; economic statistics; and big data from mobile phones and social media. They analyze spatial patterns using statistics, asking whether features are clustered, dispersed, or random, and how strongly one variable is related to another across space.",
    "Waldo Tobler's “first law of geography,” stated in 1970, is that “everything is related to everything else, but near things are more related than distant things.” This simple principle underlies much of spatial analysis."]],
  ["Thinking critically about geographic data",[
    "Data can mislead. The modifiable areal unit problem means that results can change depending on how areas are drawn and grouped, such as whether data are reported by county, state, or district. Averages hide variation, and correlation across places does not prove causation.",
    "Privacy is another concern, since location data from phones can reveal intimate details of people's lives. Good geographers combine data, maps, fieldwork, and critical thinking, and remember that every map and dataset reflects choices made by people."]]
  ],
  terms:[["GIS","A computer system for storing and analyzing location-based data in layers."],["Vector and raster data","Spatial data as points, lines, and polygons vs. a grid of cells."],["Remote sensing","Gathering information about the Earth from a distance."],["Landsat","The U.S. satellite program imaging Earth's land since 1972."],["LiDAR","Laser-based remote sensing that maps terrain in fine detail."],["Ground truth","Field observation used to verify remote data."],["Tobler's first law","Near things are more related than distant things."]],
  w:"GIS, satellites, and fieldwork give geographers powerful ways to see and analyze the world, and they underlie everything from weather forecasts to the maps on your phone.",
  src:["Geographic information system","Remote sensing","Landsat program","Lidar","1854 Broad Street cholera outbreak","Tobler's first law of geography"],
  q:[["Who developed the first major GIS in the 1960s?","Roger Tomlinson","Waldo Tobler","John Snow","Alexander von Humboldt"],
     ["What kind of spatial data uses a grid of cells?","Raster","Vector","Polygon","Choropleth"],
     ["Which satellite program began imaging Earth's land in 1972?","Landsat","TIROS","GPS","Sputnik"],
     ["Which technology uses laser pulses to map terrain beneath forests?","LiDAR","Sonar","Radar altimetry","Infrared photography"],
     ["Whose 1854 map linked cholera deaths to a water pump?","John Snow","Florence Nightingale","Louis Pasteur","Edwin Chadwick"],
     ["What does Tobler's first law of geography state?","Near things are more related than distant things","Maps always distort area","Population grows exponentially","Cities form in hierarchies"]]}

]});


/* ---- from geo-02.js ---- */
/* GEOGRAPHY FOUNDATIONS, part 2: Unit 2 The Solid Earth, chapters 1-5 */
COURSES.geography.units.push({ t:"The Solid Earth", ch:[

{ t:"Earth in Space: Seasons, Day, and Night", s:"How Earth's motions shape life on the surface",
  sec:[
  ["Our planet",[
    "Earth is the third planet from the Sun, at an average distance of about 150 million kilometers, a distance called one astronomical unit. It formed about 4.54 billion years ago from the disk of gas and dust around the young Sun. Its diameter is about 12,742 kilometers, and it bulges slightly at the Equator because of its rotation.",
    "About 71 percent of Earth's surface is covered by water, almost all of it in the oceans, and about 29 percent is land. Earth's single natural satellite, the Moon, stabilizes the tilt of its axis and raises the tides."]],
  ["Rotation: day and night",[
    "Earth rotates on its axis from west to east, which is why the Sun appears to rise in the east and set in the west. One rotation relative to the Sun takes 24 hours, a solar day. At the Equator, the surface moves at about 1,670 kilometers per hour.",
    "The circle dividing the lit half of the Earth from the dark half is called the circle of illumination, or terminator. Rotation also causes the Coriolis effect: moving air and water are deflected to the right in the Northern Hemisphere and to the left in the Southern Hemisphere, which shapes global winds and ocean currents and gives hurricanes their spin."]],
  ["Revolution and the tilted axis",[
    "Earth revolves around the Sun in about 365.25 days, which is why a leap day is added every four years (with some exceptions). Its orbit is slightly elliptical; surprisingly, Earth is closest to the Sun (perihelion) in early January, during the Northern Hemisphere's winter.",
    "Seasons are caused not by distance but by the tilt of Earth's axis, about 23.4 degrees from perpendicular to its orbit. The axis always points in the same direction in space, toward the North Star, Polaris. As Earth orbits, first one hemisphere and then the other is tilted toward the Sun, receiving more direct rays and longer days."]],
  ["Solstices and equinoxes",[
    "Around 21 June, the June solstice, the North Pole is tilted most toward the Sun. The Sun is directly overhead at noon on the Tropic of Cancer, the Northern Hemisphere has its longest day, and areas north of the Arctic Circle have 24-hour daylight. Around 21 December, the December solstice, the situation is reversed: the Sun is overhead at the Tropic of Capricorn, and the Southern Hemisphere has summer.",
    "Around 20 March and 22 September are the equinoxes, when the Sun is directly overhead at the Equator and day and night are roughly equal everywhere. Seasons in the Southern Hemisphere are opposite to those in the Northern: Christmas falls in summer in Australia, Argentina, and South Africa."]],
  ["Insolation and latitude",[
    "Insolation, incoming solar radiation, is strongest where the Sun's rays strike most directly. Near the Equator, the Sun is always high in the sky, so the tropics are warm year-round and day length changes little. Toward the poles, rays strike at a low angle, spreading the same energy over a larger area, and seasonal differences in day length become extreme.",
    "This uneven heating, with an energy surplus in the tropics and a deficit near the poles, drives the circulation of the atmosphere and oceans, which carry heat poleward. It is the starting point for understanding weather and climate."]],
  ["The Moon and tides",[
    "The Moon orbits Earth in about 27.3 days, and its cycle of phases, from new moon to full moon and back, takes about 29.5 days. The gravitational pull of the Moon, and to a lesser extent the Sun, creates tides, the regular rise and fall of sea level. Most coasts have two high and two low tides roughly every 24 hours and 50 minutes.",
    "When the Sun, Moon, and Earth are aligned at new and full moon, the tidal range is greatest; these are spring tides. When the Sun and Moon are at right angles, at the quarter moons, the range is smallest; these are neap tides. The Bay of Fundy in Canada has the world's highest tides, with ranges up to about 16 meters."]]
  ],
  terms:[["Rotation","Earth's spin on its axis, causing day and night."],["Revolution","Earth's orbit around the Sun, taking about 365.25 days."],["Axial tilt","The 23.4° tilt of Earth's axis that causes seasons."],["Solstice","The time when the Sun is overhead at a tropic, giving the longest or shortest day."],["Equinox","The time when the Sun is overhead at the Equator."],["Coriolis effect","The deflection of moving objects caused by Earth's rotation."],["Insolation","Incoming solar radiation."],["Spring and neap tides","The largest and smallest tidal ranges."]],
  w:"Earth's rotation, orbit, and tilt create day and night, the seasons, and the uneven heating that drives the planet's weather and climate.",
  src:["Earth","Axial tilt","Season","Solstice","Equinox","Coriolis force","Tide"],
  q:[["What causes the seasons?","The tilt of Earth's axis","Earth's changing distance from the Sun","The Moon's orbit","Ocean currents"],
     ["When is Earth closest to the Sun?","Early January","Late June","Late March","Late September"],
     ["Where is the Sun directly overhead at noon on the June solstice?","The Tropic of Cancer","The Equator","The Tropic of Capricorn","The Arctic Circle"],
     ["In the Northern Hemisphere, the Coriolis effect deflects moving air to the:","Right","Left","North","Upward"],
     ["Which tides occur when the Sun, Moon, and Earth are aligned?","Spring tides","Neap tides","Ebb tides","Red tides"],
     ["Where are the world's highest tides?","The Bay of Fundy","The English Channel","The Gulf of Mexico","The Mediterranean"]]},

{ t:"Inside the Earth and Plate Tectonics", s:"The theory that explains continents, mountains, and oceans",
  sec:[
  ["Earth's layers",[
    "Earth has a layered structure. At the center is the core: a solid inner core of iron and nickel, about as hot as the surface of the Sun, surrounded by a liquid outer core whose churning motion generates Earth's magnetic field. Around the core lies the mantle, about 2,900 kilometers thick, made of hot rock that, though solid, flows extremely slowly over long periods.",
    "The outermost layer is the crust. Oceanic crust is thin (about 5–10 kilometers), dense, and made largely of basalt. Continental crust is thicker (typically 30–50 kilometers, more under mountains), less dense, and rich in granite-like rocks. Scientists learned about the interior mainly by studying how earthquake waves travel through it."]],
  ["Lithosphere and asthenosphere",[
    "Geologists also divide the outer Earth by how it behaves. The lithosphere, consisting of the crust and the uppermost rigid mantle, is broken into large pieces called tectonic plates. Beneath it lies the asthenosphere, a hotter, weaker zone of the mantle on which the plates move.",
    "There are about seven major plates, including the Pacific, North American, South American, Eurasian, African, Antarctic, and Indo-Australian (sometimes divided into Indian and Australian), plus many smaller ones such as the Nazca, Cocos, Philippine Sea, Caribbean, and Arabian plates. Plates move a few centimeters per year, about as fast as fingernails grow."]],
  ["From continental drift to plate tectonics",[
    "In 1912 the German scientist Alfred Wegener proposed continental drift: that the continents had once been joined in a supercontinent he called Pangaea and had since drifted apart. His evidence included the jigsaw fit of South America and Africa, matching fossils and rock formations across oceans, and evidence of past glaciers in now-tropical regions. But he could not explain what moved the continents, and most geologists rejected his idea.",
    "In the 1950s and 1960s, mapping of the ocean floor revealed long mid-ocean ridges and symmetrical stripes of magnetic reversals on either side, showing that new seafloor forms at the ridges and spreads outward. This seafloor spreading, described by Harry Hess and others, led to the theory of plate tectonics, which by the late 1960s had revolutionized the earth sciences. Pangaea began breaking apart about 200 million years ago."]],
  ["Divergent boundaries",[
    "At divergent boundaries, plates move apart. In the oceans, magma rises at mid-ocean ridges to create new crust; the Mid-Atlantic Ridge runs down the center of the Atlantic, which widens by a few centimeters a year. Iceland sits atop this ridge and a hotspot, which is why it has so many volcanoes.",
    "On land, divergence creates rift valleys. The East African Rift, stretching from the Afar region through Kenya and Tanzania, is slowly splitting the African plate; over millions of years it may form a new ocean, as the Red Sea is already doing between Africa and Arabia."]],
  ["Convergent and transform boundaries",[
    "At convergent boundaries, plates collide. When oceanic crust meets continental crust, the denser oceanic plate sinks beneath in a process called subduction, creating deep ocean trenches and chains of volcanoes, such as the Andes, where the Nazca plate subducts beneath South America. When two oceanic plates converge, subduction creates trenches and volcanic island arcs such as Japan; the Mariana Trench, the deepest point in the ocean at about 11,000 meters, lies where the Pacific plate subducts.",
    "When two continents collide, neither sinks easily, so the crust crumples upward into great mountain ranges. The Himalayas, including Mount Everest (8,849 meters), formed as the Indian plate collided with Eurasia, beginning about 50 million years ago, and are still rising. At transform boundaries, plates slide past each other horizontally, as along the San Andreas Fault in California, causing earthquakes but little volcanism."]],
  ["Hotspots and the Ring of Fire",[
    "Some volcanoes form far from plate boundaries, above hotspots, plumes of hot material rising from deep in the mantle. As a plate moves over a stationary hotspot, a chain of volcanoes forms. The Hawaiian Islands are the classic example: the Big Island is active, while islands to the northwest are older and extinct. Yellowstone sits above a continental hotspot.",
    "The Pacific Ocean is ringed by subduction zones, creating the Ring of Fire, a horseshoe of volcanoes and earthquake zones from New Zealand through Indonesia, Japan, Alaska, and down the west coast of the Americas. It contains roughly three-quarters of the world's active volcanoes and generates most of the largest earthquakes."]]
  ],
  terms:[["Core, mantle, crust","Earth's three main compositional layers."],["Lithosphere","The rigid outer shell broken into tectonic plates."],["Pangaea","The supercontinent that began breaking apart about 200 million years ago."],["Seafloor spreading","The creation of new oceanic crust at mid-ocean ridges."],["Subduction","The sinking of one plate beneath another."],["Transform boundary","Where plates slide past one another."],["Hotspot","A plume of mantle heat creating volcanoes away from plate edges."],["Ring of Fire","The zone of volcanoes and earthquakes around the Pacific."]],
  w:"Plate tectonics is the unifying theory of geology, explaining the shape of continents and oceans, the locations of mountains, volcanoes, and earthquakes, and the slow reshaping of the planet.",
  src:["Structure of Earth","Plate tectonics","Alfred Wegener","Pangaea","Seafloor spreading","Subduction","Ring of Fire"],
  q:[["Which layer generates Earth's magnetic field?","The liquid outer core","The inner core","The mantle","The crust"],
     ["Who proposed continental drift in 1912?","Alfred Wegener","Harry Hess","Charles Lyell","James Hutton"],
     ["What runs down the center of the Atlantic Ocean?","The Mid-Atlantic Ridge","A subduction zone","A transform fault","A hotspot chain"],
     ["What kind of boundary formed the Himalayas?","Continental-continental collision","Divergent","Transform","Hotspot"],
     ["The San Andreas Fault is an example of what kind of boundary?","Transform","Divergent","Convergent","Subduction"],
     ["What formed the Hawaiian Islands?","A hotspot","A subduction zone","A rift valley","A continental collision"]]},

{ t:"Earthquakes and Volcanoes", s:"When the Earth shakes and erupts",
  sec:[
  ["What causes earthquakes",[
    "An earthquake is the shaking of the ground caused by the sudden release of energy when rocks break and slip along a fault. Stress builds up as plates move, until the rocks rupture. The point underground where the rupture begins is the focus (or hypocenter); the point on the surface directly above it is the epicenter.",
    "Energy travels as seismic waves. Primary (P) waves are compressional and fastest; secondary (S) waves shake side to side and cannot pass through liquids, which is how scientists discovered the liquid outer core. Surface waves arrive last and cause most of the damage. Seismographs record these waves, and by comparing arrival times at several stations, scientists locate the epicenter."]],
  ["Measuring earthquakes",[
    "Magnitude measures the energy released. The Richter scale, devised by Charles Richter in 1935, has been largely replaced by the moment magnitude scale, but both are logarithmic: each whole number step represents about ten times greater ground motion and about 32 times more energy. A magnitude 8 releases roughly a thousand times the energy of a magnitude 6.",
    "Intensity measures the effects at a particular place, using scales such as the Modified Mercalli scale. The largest earthquake ever recorded was the magnitude 9.5 Valdivia earthquake in Chile in 1960. Most of the strongest earthquakes, called megathrust earthquakes, occur at subduction zones."]],
  ["Earthquake hazards",[
    "Most earthquake deaths are caused not by shaking itself but by collapsing buildings. Other hazards include landslides, fires, and liquefaction, in which waterlogged soil behaves like a liquid. Underwater earthquakes can displace the ocean and cause tsunamis, which travel across oceans at the speed of a jet airliner and rise to great heights in shallow water.",
    "The 2004 Indian Ocean earthquake and tsunami killed about 230,000 people in a dozen countries. The 2011 Tōhoku earthquake and tsunami in Japan killed about 18,000 and caused the Fukushima nuclear disaster. Earthquakes cannot yet be predicted precisely, but risk is reduced through building codes, early warning systems, tsunami warnings, and education."]],
  ["How volcanoes work",[
    "A volcano is an opening in the crust through which molten rock, gases, and debris erupt. Molten rock underground is called magma; when it reaches the surface it is lava. Volcanoes form mainly at subduction zones, at divergent boundaries, and over hotspots.",
    "The style of eruption depends largely on the magma's silica content and gas. Runny, low-silica basaltic magma, as in Hawaii and Iceland, lets gases escape easily, producing gentle effusive eruptions with lava flows. Sticky, high-silica magma, typical of subduction zones, traps gases and produces violent explosive eruptions."]],
  ["Types of volcanoes",[
    "Shield volcanoes, built by fluid lava flows, are broad with gentle slopes; Mauna Loa in Hawaii is the largest active volcano on Earth. Stratovolcanoes (composite volcanoes) are steep cones built of alternating layers of lava and ash, such as Mount Fuji, Mount Rainier, and Mount St. Helens. Cinder cones are small, steep hills of volcanic fragments.",
    "Calderas are huge depressions formed when a volcano collapses after emptying its magma chamber. Supervolcanoes, such as Yellowstone and Toba in Sumatra, whose eruption about 74,000 years ago was one of the largest known, can eject more than 1,000 cubic kilometers of material."]],
  ["Volcanic hazards and benefits",[
    "The deadliest volcanic hazard is the pyroclastic flow, a fast-moving avalanche of hot gas, ash, and rock that can exceed 100 kilometers per hour; such flows destroyed Pompeii and Herculaneum in the eruption of Mount Vesuvius in 79 CE. Lahars, volcanic mudflows, can bury towns far from the volcano. Ash clouds disrupt air travel, and gases can affect global climate: the 1815 eruption of Tambora in Indonesia caused the “Year Without a Summer” in 1816.",
    "Volcanoes also bring benefits: fertile soils, which is why many people live on their slopes, geothermal energy (used extensively in Iceland), minerals, and, over geological time, the atmosphere and oceans themselves. Volcanologists monitor earthquakes, gas emissions, and ground swelling to forecast eruptions."]]
  ],
  terms:[["Fault","A fracture along which rocks have moved."],["Epicenter","The point on the surface above an earthquake's focus."],["Seismic waves","Waves of energy released by earthquakes."],["Moment magnitude","A logarithmic measure of earthquake energy."],["Tsunami","Ocean waves caused by displacement of water, often by an earthquake."],["Pyroclastic flow","A fast-moving current of hot gas and volcanic debris."],["Stratovolcano","A steep volcano built of layers of lava and ash."],["Caldera","A large depression formed by volcanic collapse."]],
  w:"Earthquakes and volcanoes are the most dramatic expressions of plate tectonics, posing serious risks to hundreds of millions of people while also enriching soils and shaping landscapes.",
  src:["Earthquake","Seismic wave","Moment magnitude scale","Tsunami","Volcano","Pyroclastic flow","1815 eruption of Mount Tambora"],
  q:[["What is the point on the surface above an earthquake's focus called?","The epicenter","The hypocenter","The fault","The caldera"],
     ["Which seismic waves cannot pass through liquids?","S waves","P waves","Surface waves","Rayleigh waves"],
     ["How much more energy is released by each whole-number step in magnitude?","About 32 times","About 2 times","About 10 times","About 100 times"],
     ["Where was the largest earthquake ever recorded?","Chile","Japan","Alaska","Indonesia"],
     ["What kind of volcano is Mauna Loa?","Shield volcano","Stratovolcano","Cinder cone","Caldera"],
     ["Which eruption caused the 1816 'Year Without a Summer'?","Tambora","Krakatoa","Vesuvius","Pinatubo"]]},

{ t:"Rocks, Minerals, and Geologic Time", s:"The materials and timescale of the Earth",
  sec:[
  ["Minerals",[
    "A mineral is a naturally occurring, inorganic solid with a definite chemical composition and an ordered crystal structure. Thousands are known, but a few dozen make up most rocks. The most abundant in the crust are feldspars and quartz. Minerals are identified by properties such as hardness, luster, color, streak, cleavage, and crystal shape.",
    "The Mohs scale of hardness, devised by Friedrich Mohs in 1812, ranks minerals from 1 (talc) to 10 (diamond) by which can scratch which. Quartz is 7. Many minerals are economically important ores, such as hematite for iron, bauxite for aluminum, and chalcopyrite for copper."]],
  ["Igneous rocks",[
    "Rocks are aggregates of minerals, classified into three great families by how they form. Igneous rocks form when magma or lava cools and solidifies. Intrusive (plutonic) igneous rocks cool slowly underground, forming large crystals; granite is the most familiar example.",
    "Extrusive (volcanic) igneous rocks cool quickly at the surface, forming small crystals or glass. Basalt, which makes up the ocean floor, is the most common extrusive rock; obsidian is volcanic glass, and pumice is so full of gas bubbles that it can float."]],
  ["Sedimentary rocks",[
    "Sedimentary rocks form from sediments, fragments of other rocks or the remains of organisms, that are deposited in layers, compacted, and cemented. Clastic sedimentary rocks include sandstone, shale, and conglomerate. Limestone forms mostly from the shells and skeletons of marine organisms; coal forms from compressed plant material.",
    "Sedimentary rocks cover most of the continents' surface and are arranged in layers called strata. They contain almost all fossils and hold most of the world's oil, natural gas, and groundwater. The principle of superposition states that in undisturbed layers, the oldest are at the bottom."]],
  ["Metamorphic rocks and the rock cycle",[
    "Metamorphic rocks form when existing rocks are transformed by heat, pressure, or chemically active fluids without melting. Limestone becomes marble; shale becomes slate and then schist; sandstone becomes quartzite; granite can become gneiss. Metamorphism often occurs deep in mountain belts where plates collide.",
    "The rock cycle describes how rocks change from one type to another over geological time: igneous rocks are weathered into sediments that form sedimentary rocks, which can be buried and metamorphosed, or melted to form magma that cools into new igneous rock. Plate tectonics and the water cycle drive this continual recycling."]],
  ["Deep time",[
    "The Scottish geologist James Hutton argued in the 1780s that the Earth was shaped by slow processes still operating today, such as erosion and deposition, requiring vast stretches of time; he wrote that he found “no vestige of a beginning, no prospect of an end.” Charles Lyell popularized this idea, called uniformitarianism, in his Principles of Geology (1830–1833), which influenced Charles Darwin.",
    "Radiometric dating, developed in the early 20th century, uses the steady decay of radioactive isotopes such as uranium to measure the age of rocks. It established that Earth is about 4.54 billion years old. The oldest known minerals, zircon crystals from Western Australia, are about 4.4 billion years old."]],
  ["The geologic time scale",[
    "Geologists divide Earth's history into eons, eras, periods, and epochs. The Precambrian, covering nearly 90 percent of Earth's history, saw the formation of the crust, oceans, and atmosphere and the origin of life at least 3.5 billion years ago. The Phanerozoic eon, beginning about 539 million years ago with the Cambrian explosion of animal life, is divided into three eras.",
    "The Paleozoic (“ancient life”) saw life spread onto land and ended with the largest mass extinction, at the end of the Permian about 252 million years ago. The Mesozoic (“middle life”), the age of dinosaurs, ended about 66 million years ago when an asteroid struck near Chicxulub, in Mexico's Yucatán Peninsula. The Cenozoic (“recent life”) is the age of mammals. Our species, Homo sapiens, appeared about 300,000 years ago, a tiny fraction of Earth's history."]]
  ],
  terms:[["Mineral","A natural inorganic solid with a definite composition and crystal structure."],["Mohs scale","A 1–10 scale of mineral hardness."],["Igneous rock","Rock formed from cooled magma or lava."],["Sedimentary rock","Rock formed from compacted and cemented sediments."],["Metamorphic rock","Rock transformed by heat and pressure."],["Rock cycle","The continual transformation of rocks between types."],["Uniformitarianism","The principle that present processes explain the past."],["Radiometric dating","Dating rocks using radioactive decay."]],
  w:"Rocks record the history of the Earth, and understanding them and deep time explains landscapes, resources, fossils, and our own brief place in the planet's story.",
  src:["Mineral","Mohs scale","Igneous rock","Sedimentary rock","Metamorphic rock","Rock cycle","Geologic time scale"],
  q:[["What is the hardest mineral on the Mohs scale?","Diamond","Quartz","Corundum","Topaz"],
     ["Which igneous rock forms from slowly cooled magma underground?","Granite","Basalt","Obsidian","Pumice"],
     ["Which rock contains almost all fossils?","Sedimentary","Igneous","Metamorphic","Volcanic"],
     ["What does limestone become when metamorphosed?","Marble","Slate","Quartzite","Gneiss"],
     ["Who proposed that Earth was shaped by slow processes over vast time?","James Hutton","Charles Darwin","Alfred Wegener","Georges Cuvier"],
     ["How old is the Earth?","About 4.54 billion years","About 6,000 years","About 540 million years","About 13.8 billion years"]]},

{ t:"Weathering, Erosion, and Landforms", s:"How landscapes are worn down and built",
  sec:[
  ["Building up and wearing down",[
    "The shape of the land reflects a contest between internal forces, such as tectonic uplift and volcanism, that build up the land, and external forces, driven by the Sun's energy and gravity, that wear it down. The study of landforms and the processes that shape them is called geomorphology.",
    "The main external processes are weathering, the breakdown of rock in place; mass movement, the downslope movement of material under gravity; erosion, the removal and transport of material by water, wind, and ice; and deposition, where the material is laid down."]],
  ["Mechanical weathering",[
    "Mechanical (physical) weathering breaks rock into smaller pieces without changing its chemistry. In frost wedging, water seeps into cracks, freezes, and expands by about 9 percent, prying the rock apart; it is powerful in mountains and cold climates where temperatures cycle around freezing.",
    "Other processes include exfoliation, in which outer layers peel off as rock buried deep underground is exposed and expands, forming rounded domes such as Half Dome in Yosemite; salt crystal growth; and the action of plant roots and burrowing animals."]],
  ["Chemical weathering",[
    "Chemical weathering changes the minerals in rock. Rainwater absorbs carbon dioxide and becomes a weak carbonic acid that dissolves limestone. Oxidation, the reaction with oxygen, turns iron-bearing minerals to rust, giving many soils their red color. Hydrolysis turns feldspar into clay.",
    "Chemical weathering is fastest in warm, wet climates, which is why tropical regions have deeply weathered rock and soil, while mechanical weathering dominates in cold and dry regions. Weathering produces the raw material for soil."]],
  ["Mass movement",[
    "Gravity constantly pulls material downhill. Slow mass movement includes soil creep, the gradual downhill movement of soil that tilts fences and trees. Faster forms include slumps, rockfalls, landslides, and mudflows or debris flows.",
    "Water is usually the trigger, as heavy rain adds weight and reduces friction; earthquakes, deforestation, and construction on steep slopes also increase risk. Landslides kill thousands of people each year, especially in mountainous regions with heavy monsoon rains."]],
  ["Karst landscapes",[
    "Where limestone is common, dissolution creates distinctive karst landscapes, named after a region of Slovenia. Water dissolves the rock along cracks to form caves, underground rivers, and sinkholes. In caves, dripping water deposits calcite to form stalactites, which hang from ceilings, and stalagmites, which grow from floors.",
    "Famous karst landscapes include the tower karst of Guilin in southern China and Ha Long Bay in Vietnam, Mammoth Cave in Kentucky, the longest known cave system in the world, and Florida's many sinkholes. The Yucatán Peninsula has few surface rivers but thousands of water-filled sinkholes called cenotes."]],
  ["Wind and arid landforms",[
    "In deserts, where vegetation is sparse, wind plays a larger role. It removes fine particles (deflation), leaving behind stony surfaces called desert pavement, and sandblasts rocks (abrasion). Sand dunes form where wind deposits sand; their shapes, such as crescent-shaped barchans and long linear dunes, depend on wind direction and sand supply. Only about 20 percent of the world's deserts are covered by sand.",
    "Surprisingly, water is still the main sculptor of deserts, because rare but intense storms cause flash floods. Characteristic landforms include mesas and buttes, flat-topped hills capped by resistant rock, as in Monument Valley; alluvial fans at the mouths of canyons; and dry streambeds called wadis or arroyos. Loess, fine wind-blown dust, forms thick fertile deposits in China's Loess Plateau and the American Midwest."]]
  ],
  terms:[["Geomorphology","The study of landforms and the processes that shape them."],["Weathering","The breakdown of rock in place."],["Erosion","The removal and transport of material by water, wind, or ice."],["Frost wedging","Rock breakage caused by water freezing in cracks."],["Mass movement","The downslope movement of material under gravity."],["Karst","Landscapes formed by the dissolution of limestone."],["Mesa and butte","Flat-topped hills capped by resistant rock."],["Loess","Fine wind-blown sediment forming fertile deposits."]],
  w:"Weathering, erosion, and deposition carve every landscape, producing the soils we farm and the canyons, caves, and dunes that make places distinctive.",
  src:["Geomorphology","Weathering","Erosion","Mass wasting","Karst","Sand dune","Loess"],
  q:[["What is the study of landforms called?","Geomorphology","Hydrology","Pedology","Seismology"],
     ["Water expanding as it freezes in cracks causes what?","Frost wedging","Oxidation","Exfoliation","Deflation"],
     ["In which climates is chemical weathering fastest?","Warm and wet","Cold and dry","Cold and wet","Hot and dry"],
     ["Which rock dissolves to form karst landscapes?","Limestone","Granite","Basalt","Sandstone"],
     ["What are water-filled sinkholes in the Yucatán called?","Cenotes","Wadis","Mesas","Fjords"],
     ["What is the main sculptor of desert landscapes despite their dryness?","Water","Wind","Ice","Plants"]]}

]});


/* ---- from geo-03.js ---- */
/* GEOGRAPHY FOUNDATIONS, part 3: Unit 2 chapters 6-9 */
COURSES.geography.units[1].ch.push(

{ t:"Rivers and Drainage Basins", s:"How running water shapes the land",
  sec:[
  ["The river system",[
    "Running water is the most important agent of erosion on land. A river begins at its source, often in mountains or hills, and flows to its mouth at a sea, lake, or larger river. Smaller streams that join a river are tributaries; the point where they join is a confluence. The entire area drained by a river and its tributaries is its drainage basin or watershed, and the boundary between basins is a drainage divide.",
    "The Continental Divide of the Americas, running along the Rocky Mountains and Andes, separates rivers flowing to the Pacific from those flowing to the Atlantic and Arctic. The Amazon basin, about 7 million square kilometers, is the largest in the world, and the Amazon carries about one-fifth of all the river water flowing into the world's oceans."]],
  ["Discharge and the work of rivers",[
    "A river's discharge is the volume of water passing a point per second. It varies with rainfall, snowmelt, and season; a graph of discharge over time is a hydrograph. Rivers do three kinds of work: erosion, transportation, and deposition.",
    "Rivers erode by the force of moving water, by abrasion as sediment grinds the bed and banks, and by dissolving rock. They transport their load as dissolved material, as suspended fine particles that make water muddy, and as bed load rolled and bounced along the bottom. When the river slows, it deposits its load, coarsest first."]],
  ["Upper course landforms",[
    "In the upper course, rivers are typically steep and erode downward, cutting V-shaped valleys with interlocking spurs. Where a river flows over a band of hard rock above softer rock, waterfalls form, slowly retreating upstream as the soft rock is undercut; Niagara Falls has retreated about 11 kilometers since the last ice age.",
    "Where land is uplifted while a river continues to cut down, deep canyons can form. The Grand Canyon, carved by the Colorado River into layers of rock spanning nearly two billion years of history, is about 1.8 kilometers deep."]],
  ["Middle and lower course landforms",[
    "As the gradient decreases, rivers erode sideways and develop meanders, sweeping bends. Water flows fastest on the outside of a bend, eroding the bank, and slowest on the inside, depositing sand. Over time, meanders migrate, and when a river cuts through the narrow neck of a loop, it leaves behind a crescent-shaped oxbow lake.",
    "In the lower course, rivers flow across broad, flat floodplains built from sediment deposited during floods, often bordered by natural levees. At the mouth, a river may form a delta, a fan of sediment, as at the Nile, Mississippi, and Ganges-Brahmaputra, the world's largest delta. Where tides are strong and sediment is removed, the mouth forms an estuary, a funnel where fresh and salt water mix, such as the Thames or the Río de la Plata."]],
  ["Great rivers of the world",[
    "The Nile, about 6,650 kilometers long, is traditionally considered the longest river, though some measurements give the title to the Amazon, which is by far the largest by volume. Other great rivers include the Yangtze, the longest in Asia; the Mississippi-Missouri system in North America; the Yenisei, Ob, and Lena in Siberia, flowing north to the Arctic; the Congo, the world's deepest river; the Niger; the Ganges; the Mekong; and the Danube, which flows through or along ten countries.",
    "Rivers have always been central to human life, providing water, food, transport, fertile soils, and, today, hydroelectric power. The first civilizations arose along the Tigris and Euphrates, Nile, Indus, and Yellow rivers."]],
  ["Floods and river management",[
    "Floods occur when discharge exceeds a channel's capacity. They deposit fertile silt but can also be catastrophic; the Yellow River floods of 1931 in China were among the deadliest natural disasters in history. Urbanization increases flooding, as pavement prevents water from soaking into the ground.",
    "People manage rivers with dams, levees, channel straightening, and flood plains set aside for overflow. Dams such as the Three Gorges Dam on the Yangtze, the world's largest hydroelectric plant, and the Aswan High Dam on the Nile provide power and flood control but displace people, trap sediment, and alter ecosystems. Many rivers flow through several countries, making water sharing a source of international tension."]]
  ],
  terms:[["Drainage basin","The area drained by a river and its tributaries."],["Tributary","A stream that flows into a larger river."],["Discharge","The volume of water flowing past a point per second."],["Meander","A sweeping bend in a river."],["Oxbow lake","A crescent-shaped lake formed from a cut-off meander."],["Floodplain","Flat land beside a river built from flood deposits."],["Delta","A deposit of sediment at a river's mouth."],["Estuary","A river mouth where fresh and salt water mix."]],
  w:"Rivers carve valleys, build plains and deltas, and have supported human civilization from its beginnings, making them central to both physical and human geography.",
  src:["River","Drainage basin","Meander","Oxbow lake","River delta","Amazon River","Nile"],
  q:[["What is the area drained by a river and its tributaries called?","A drainage basin","A delta","A floodplain","An estuary"],
     ["Which river carries the most water?","The Amazon","The Nile","The Yangtze","The Mississippi"],
     ["What forms when a river cuts through the neck of a meander?","An oxbow lake","A delta","A waterfall","A levee"],
     ["Which river carved the Grand Canyon?","The Colorado","The Snake","The Rio Grande","The Missouri"],
     ["Which is the world's largest delta?","The Ganges-Brahmaputra delta","The Nile delta","The Mississippi delta","The Mekong delta"],
     ["Which dam on the Yangtze is the world's largest hydroelectric plant?","Three Gorges","Aswan High","Itaipu","Hoover"]]},

{ t:"Glaciers and Ice Ages", s:"Rivers of ice and the landscapes they leave",
  sec:[
  ["What glaciers are",[
    "A glacier is a large, long-lasting mass of ice that moves under its own weight. Glaciers form where more snow falls in winter than melts in summer, so that snow accumulates, compacts into granular firn, and eventually becomes dense glacial ice. Today about 10 percent of Earth's land is covered by ice, and glaciers and ice sheets hold about 69 percent of the world's fresh water.",
    "There are two main types. Alpine (valley) glaciers form in mountains and flow down valleys, found in the Alps, Himalayas, Andes, Rockies, and Alaska. Ice sheets are continent-sized masses of ice; only two exist today, covering Antarctica and Greenland. The Antarctic ice sheet is up to about 4.8 kilometers thick; if it all melted, sea level would rise by roughly 58 meters."]],
  ["How glaciers move and erode",[
    "Glaciers move by internal deformation of the ice and by sliding over meltwater at their base, typically from a few centimeters to a few meters a day, though some outlet glaciers move much faster. A glacier's budget balances accumulation in its upper zone against ablation, melting and calving, in its lower zone. If accumulation exceeds ablation, the glacier advances; if not, it retreats, although the ice within it is always flowing downhill.",
    "Glaciers are powerful agents of erosion. They pluck blocks of rock from the bed and use them, like sandpaper, to abrade the rock beneath, leaving scratches called striations that show the direction of ice flow."]],
  ["Erosional landforms",[
    "Glaciers transform V-shaped river valleys into broad U-shaped valleys with steep sides. Tributary valleys left high above the main valley become hanging valleys, often with waterfalls, as in Yosemite. Where glaciers carved valleys below sea level, the sea later flooded them to form fjords, the long, deep inlets of Norway, Chile, New Zealand, and Alaska.",
    "In the mountains, glaciers carve armchair-shaped hollows called cirques, often holding small lakes called tarns. When cirques erode back from several sides, they leave sharp ridges called arêtes and pyramid-shaped peaks called horns; the Matterhorn in the Alps is the classic horn."]],
  ["Depositional landforms",[
    "Glaciers deposit unsorted material called till. Ridges of till deposited at the edges and snouts of glaciers are moraines; terminal moraines mark a glacier's farthest advance. Long Island in New York is largely made of glacial moraines. Drumlins are smooth, egg-shaped hills shaped by moving ice.",
    "Meltwater streams deposit sorted sand and gravel in outwash plains and winding ridges called eskers. Large boulders carried far from their source are called erratics. Kettle lakes form where blocks of buried ice melted, leaving depressions; Minnesota's “10,000 lakes” and many Canadian and Finnish lakes are glacial in origin."]],
  ["The ice ages",[
    "Earth's climate has repeatedly cycled between colder glacial periods and warmer interglacials. During the past 2.6 million years, the Quaternary period, ice sheets have advanced and retreated dozens of times. At the Last Glacial Maximum, about 20,000 years ago, ice sheets covered most of Canada, the northern United States, Scandinavia, and the British Isles, and sea level was about 120 meters lower than today.",
    "Lower sea levels exposed land bridges such as Beringia, linking Siberia and Alaska, which allowed people to migrate into the Americas. The Serbian scientist Milutin Milanković showed that the glacial cycles are paced by regular variations in Earth's orbit and axial tilt, now called Milankovitch cycles, amplified by changes in greenhouse gases and ice reflectivity. The current interglacial, the Holocene, began about 11,700 years ago."]],
  ["Ice today",[
    "Permafrost, ground that stays frozen for at least two years, underlies about a quarter of the Northern Hemisphere's land, in Siberia, Alaska, and northern Canada. As it thaws, buildings tilt, and stored carbon is released.",
    "Most of the world's mountain glaciers are retreating rapidly as the climate warms, threatening water supplies for hundreds of millions of people in Asia and South America who depend on glacial meltwater; the glaciers of the Himalayas and Tibetan Plateau, sometimes called the “Third Pole,” feed rivers such as the Indus, Ganges, and Yangtze. Melting ice sheets in Greenland and Antarctica are contributing to rising sea levels."]]
  ],
  terms:[["Glacier","A large, moving mass of ice."],["Ice sheet","A continent-sized glacier, now found only in Antarctica and Greenland."],["U-shaped valley","A valley widened and deepened by a glacier."],["Fjord","A glacial valley flooded by the sea."],["Cirque","A bowl-shaped hollow carved by a glacier."],["Moraine","A ridge of glacial till."],["Milankovitch cycles","Orbital variations that pace the ice ages."],["Permafrost","Ground that remains frozen for at least two years."]],
  w:"Glaciers shaped much of the landscape of North America and Europe, the ice ages shaped human migration, and today's shrinking ice affects water supplies and sea levels worldwide.",
  src:["Glacier","Ice sheet","Fjord","Moraine","Last Glacial Maximum","Milankovitch cycles","Permafrost"],
  q:[["What share of the world's fresh water is stored in glaciers and ice sheets?","About 69 percent","About 10 percent","About 30 percent","About 97 percent"],
     ["Where are the world's two remaining ice sheets?","Antarctica and Greenland","Antarctica and Siberia","Greenland and Canada","Alaska and Antarctica"],
     ["What kind of valley do glaciers carve?","U-shaped","V-shaped","Rift","Hanging delta"],
     ["What is a glacial valley flooded by the sea called?","A fjord","An estuary","A cirque","An esker"],
     ["The Matterhorn is an example of what landform?","A horn","An arête","A drumlin","A moraine"],
     ["Who explained the orbital cycles that pace the ice ages?","Milutin Milanković","Louis Agassiz","Alfred Wegener","James Croll"]]},

{ t:"Coasts", s:"Where land meets sea",
  sec:[
  ["Waves",[
    "Coasts are shaped mainly by waves, which are generated by wind blowing over the sea. Their size depends on wind speed, duration, and fetch, the distance of open water over which the wind blows. Waves crossing a vast ocean such as the Pacific can be very powerful.",
    "As waves approach the shore, they slow down, steepen, and break. Constructive waves, low and gentle, push sediment up the beach and build it. Destructive waves, tall and frequent, drag material back down the beach and erode it. Waves approaching at an angle bend as they enter shallower water, a process called refraction, concentrating energy on headlands."]],
  ["Coastal erosion",[
    "Waves erode the coast through hydraulic action, the force of water compressing air in cracks; abrasion, as rocks are hurled against cliffs; and solution. Wave-cut notches undermine cliffs until they collapse, and as cliffs retreat they leave a wave-cut platform at their base.",
    "Where bands of hard and soft rock alternate, the soft rock erodes into bays and the hard rock remains as headlands. Erosion of headlands produces a classic sequence: cracks widen into caves, caves cut through to form arches, arches collapse to leave sea stacks, and stacks wear down into stumps. The Twelve Apostles in Australia and Old Harry Rocks in England are famous examples."]],
  ["Coastal deposition",[
    "Beaches form where sand and pebbles accumulate. When waves approach at an angle, they move sediment along the shore in a zigzag pattern called longshore drift. Where the coastline changes direction, drift builds spits, long ridges of sand extending into the sea, sometimes curving at their tips. A spit that connects two headlands becomes a bar, enclosing a lagoon; a bar connecting an island to the mainland is a tombolo.",
    "Barrier islands are long, narrow islands parallel to the coast, separated from the mainland by lagoons. The Atlantic and Gulf coasts of the United States are lined with them, including the Outer Banks of North Carolina and Padre Island in Texas, the world's longest barrier island."]],
  ["Coastal ecosystems",[
    "Coasts host some of the world's most productive ecosystems. Salt marshes in temperate regions and mangrove forests in the tropics trap sediment, shelter young fish, and protect shores from storms. The Sundarbans, in the Ganges-Brahmaputra delta of India and Bangladesh, is the world's largest mangrove forest.",
    "Coral reefs, built by tiny animals in warm, clear, shallow tropical waters, support about a quarter of all marine species while covering less than 1 percent of the ocean floor. The Great Barrier Reef off Queensland, Australia, is the largest reef system in the world. Reefs are threatened by coral bleaching, caused by marine heatwaves, as well as pollution and overfishing."]],
  ["Sea level change",[
    "Coastlines change with sea level. When sea level rises or land sinks, the sea floods river valleys to form rias, such as Chesapeake Bay, or glacial valleys to form fjords. When land rises or sea level falls, raised beaches are left above the present shore. Parts of Scandinavia and Scotland are still rising after the weight of ice-age glaciers was removed.",
    "Today global sea level is rising, by about 20 centimeters since 1900 and at an accelerating rate, because of melting ice and the expansion of warming seawater. This threatens low-lying nations such as the Maldives, Tuvalu, and Bangladesh and coastal cities from Miami to Jakarta."]],
  ["People on the coast",[
    "Roughly 40 percent of the world's population lives within 100 kilometers of a coast, and many of the largest cities are ports. Coasts attract trade, fishing, tourism, and settlement, but they face erosion, storm surges, and flooding.",
    "Coastal management involves hard engineering, such as sea walls, groynes that trap drifting sand, and breakwaters, and soft engineering, such as replenishing beaches with sand, restoring dunes and wetlands, and managed retreat, allowing some land to flood. The Netherlands, about a quarter of which lies below sea level, is famous for its dikes, polders reclaimed from the sea, and the Delta Works storm barriers built after a deadly flood in 1953."]]
  ],
  terms:[["Fetch","The distance of open water over which wind blows to form waves."],["Longshore drift","The movement of sediment along a coast by angled waves."],["Sea stack","A pillar of rock left by the collapse of an arch."],["Spit","A ridge of sand extending from the coast into the sea."],["Barrier island","A long sandy island parallel to the mainland."],["Mangrove","A salt-tolerant tropical tree forming coastal forests."],["Ria","A drowned river valley."],["Polder","Low land reclaimed from the sea and protected by dikes."]],
  w:"Coasts are dynamic landscapes where many of the world's people and cities are concentrated, and their changes, especially rising seas, are among the great challenges of this century.",
  src:["Coast","Wind wave","Coastal erosion","Longshore drift","Spit (landform)","Coral reef","Sea level rise"],
  q:[["What is the distance of open water over which wind blows called?","Fetch","Swash","Refraction","Drift"],
     ["What is the correct order of headland erosion?","Cave, arch, stack, stump","Arch, cave, stump, stack","Stack, arch, cave, stump","Stump, stack, arch, cave"],
     ["What process moves sediment along a coast in a zigzag?","Longshore drift","Abrasion","Hydraulic action","Refraction"],
     ["What is the world's largest mangrove forest?","The Sundarbans","The Everglades","The Mekong Delta","The Okavango"],
     ["What is a drowned river valley called?","A ria","A fjord","A lagoon","A tombolo"],
     ["Which country is famous for polders and the Delta Works?","The Netherlands","Denmark","Bangladesh","Belgium"]]},

{ t:"Soils and the World's Major Landform Regions", s:"The living skin of the Earth and the great shapes of the continents",
  sec:[
  ["What soil is",[
    "Soil is a mixture of weathered mineral particles, organic matter (humus), water, air, and living organisms. It takes hundreds to thousands of years to form a few centimeters, which makes it effectively a non-renewable resource on human timescales. Soil supports nearly all food production.",
    "Soil formation depends on five factors: parent material (the underlying rock or sediment), climate, organisms, topography, and time. Soil texture depends on the proportions of sand, silt, and clay; loam, a balanced mix, is ideal for most crops."]],
  ["Soil profiles and types",[
    "Soils develop layers called horizons. The O horizon is surface organic matter; the A horizon, or topsoil, is dark and rich in humus; the B horizon, or subsoil, accumulates minerals washed down from above; and the C horizon is weathered parent material above the bedrock.",
    "Major soil types reflect climate. The deep, black, fertile chernozems of the grasslands of Ukraine and Russia, and the similar mollisols of the American prairies, are among the world's best farmland. Tropical rainforests often have heavily leached, nutrient-poor red oxisols, despite their lush vegetation, because nutrients are stored mainly in the plants. Podzols, acidic and gray, form under northern coniferous forests."]],
  ["Soil degradation",[
    "Soils are threatened by erosion, which is accelerated by deforestation, overgrazing, and plowing; by salinization, the buildup of salts from irrigation in dry regions; and by compaction and pollution. In the 1930s, drought and poor farming practices on the American Great Plains caused the Dust Bowl, when topsoil blew away in giant dust storms.",
    "Desertification, the degradation of land in dry regions, affects areas such as the Sahel south of the Sahara. Conservation methods include terracing, contour plowing, cover crops, crop rotation, reduced tillage, and windbreaks."]],
  ["Mountains and plateaus",[
    "At the largest scale, the continents contain several kinds of landform regions. Young fold mountains, formed at convergent boundaries, are high and rugged: the Himalayas, Alps, Andes, and Rockies. Older mountains, such as the Appalachians and Urals, have been worn down to rounded ranges. Mountains create their own climates, block winds, and often form borders.",
    "Plateaus are high, relatively flat areas. The Tibetan Plateau, averaging over 4,500 meters, is the highest and largest; it is often called the “Roof of the World.” Others include the Colorado Plateau, the Deccan Plateau of India, the Anatolian Plateau, and much of southern and eastern Africa."]],
  ["Plains, shields, and basins",[
    "Plains are broad, low, flat lands, often built of river or glacial sediment, and they hold most of the world's farmland and population. Great examples include the North European Plain, the Great Plains and Interior Lowlands of North America, the Indo-Gangetic Plain, the North China Plain, the Pampas of Argentina, and the West Siberian Plain, one of the flattest large regions on Earth.",
    "Shields are the ancient, stable cores of continents, made of very old igneous and metamorphic rocks, such as the Canadian Shield and the Baltic Shield, often rich in minerals. Basins are low areas surrounded by higher land, such as the Congo Basin and the Great Basin of the western United States, which has no outlet to the sea."]],
  ["Extremes of the Earth",[
    "The highest point on Earth is Mount Everest, 8,849 meters above sea level, on the border of Nepal and China. The lowest point on land is the shore of the Dead Sea, about 430 meters below sea level, and the deepest point in the oceans is the Challenger Deep in the Mariana Trench, nearly 11,000 meters down.",
    "The highest peaks of each continent, called the Seven Summits, are Everest (Asia), Aconcagua (South America), Denali (North America), Kilimanjaro (Africa), Elbrus (Europe), Vinson (Antarctica), and either Puncak Jaya or Kosciuszko for Oceania or Australia. Measured from base to peak, Mauna Kea in Hawaii, mostly underwater, is taller than Everest."]]
  ],
  terms:[["Soil horizon","A distinct layer in a soil profile."],["Humus","Decomposed organic matter in soil."],["Loam","Soil with a balanced mix of sand, silt, and clay."],["Chernozem","Very fertile black grassland soil."],["Salinization","The buildup of salts in soil."],["Plateau","A high, relatively flat area."],["Shield","An ancient, stable core of a continent."],["Seven Summits","The highest mountains on each continent."]],
  w:"Soils feed humanity and the great mountains, plateaus, and plains of the continents determine where people farm, live, travel, and draw borders.",
  src:["Soil","Soil horizon","Chernozem","Dust Bowl","Plateau","Tibetan Plateau","Seven Summits"],
  q:[["Which layer of a soil profile is the topsoil?","The A horizon","The B horizon","The C horizon","The O horizon"],
     ["Which very fertile black soil is found in Ukraine?","Chernozem","Oxisol","Podzol","Laterite"],
     ["What 1930s disaster blew away topsoil on the American Great Plains?","The Dust Bowl","The Sahel drought","The Great Flood","Salinization"],
     ["Which plateau is called the Roof of the World?","The Tibetan Plateau","The Deccan Plateau","The Colorado Plateau","The Anatolian Plateau"],
     ["What is the lowest point on land?","The shore of the Dead Sea","Death Valley","The Caspian Sea shore","The Mariana Trench"],
     ["What is the highest mountain in Africa?","Kilimanjaro","Mount Kenya","Ras Dashen","Mount Stanley"]]}

);


/* ---- from geo-04.js ---- */
/* GEOGRAPHY FOUNDATIONS, part 4: Unit 3 Weather and Climate, chapters 1-5 */
COURSES.geography.units.push({ t:"Weather and Climate", ch:[

{ t:"The Atmosphere", s:"The thin envelope of air that sustains life",
  sec:[
  ["Weather and climate",[
    "Weather is the state of the atmosphere at a particular place and time: its temperature, humidity, cloud cover, precipitation, air pressure, and wind. Climate is the long-term pattern of weather in a region, usually averaged over at least 30 years. As a saying puts it, climate is what you expect; weather is what you get.",
    "The scientific study of the atmosphere and weather is meteorology; the study of climate is climatology. Both are central to physical geography because climate shapes vegetation, soils, water resources, agriculture, and where people live."]],
  ["Composition",[
    "Dry air is about 78 percent nitrogen and 21 percent oxygen, with about 0.9 percent argon. Carbon dioxide makes up only about 0.04 percent (around 420 parts per million in the 2020s), up from about 280 ppm before the Industrial Revolution. Water vapor varies from almost zero to about 4 percent.",
    "Though present in small amounts, water vapor, carbon dioxide, methane, and other greenhouse gases are vital because they absorb heat radiated by the Earth's surface. Tiny particles called aerosols, such as dust, sea salt, and smoke, help clouds form and affect how much sunlight reaches the ground."]],
  ["Layers of the atmosphere",[
    "The atmosphere is divided into layers by how temperature changes with height. The troposphere, the lowest layer, extends from the surface to about 8 kilometers at the poles and 16–18 kilometers at the Equator. It contains about 75 to 80 percent of the atmosphere's mass and nearly all its water vapor, and almost all weather happens here. Temperature falls with height, on average about 6.5°C per kilometer.",
    "Above lies the stratosphere, up to about 50 kilometers, where temperature rises with height because ozone absorbs ultraviolet radiation. Jet airliners cruise near its base to avoid turbulence. Higher still are the mesosphere, where meteors burn up, and the thermosphere, where auroras glow and the International Space Station orbits. The boundary of space is often placed at 100 kilometers, the Kármán line."]],
  ["The ozone layer",[
    "The ozone layer, concentrated in the stratosphere, absorbs most of the Sun's harmful ultraviolet radiation, which causes skin cancer and damages living things. In the 1970s scientists discovered that chlorofluorocarbons (CFCs), used in refrigerators and aerosol sprays, destroy ozone, and in 1985 British scientists reported a dramatic seasonal ozone hole over Antarctica.",
    "The Montreal Protocol of 1987 phased out CFCs and is considered one of the most successful environmental treaties. The ozone layer is slowly recovering and is expected to return to 1980 levels around the middle of the century."]],
  ["The energy balance",[
    "The Sun's energy arrives mainly as visible light. Some is reflected back to space by clouds, ice, and bright surfaces; the fraction reflected is called albedo, about 30 percent for the Earth as a whole. Snow has a high albedo; dark oceans and forests have a low one. The rest is absorbed and warms the surface, which then radiates energy as infrared heat.",
    "Greenhouse gases absorb much of this outgoing infrared radiation and re-radiate it, some back toward the surface. This natural greenhouse effect keeps Earth's average temperature at about 15°C instead of about −18°C. Adding more greenhouse gases strengthens the effect, warming the planet."]],
  ["Temperature patterns",[
    "Temperature varies with latitude, altitude, distance from the sea, ocean currents, and prevailing winds. Because water heats and cools more slowly than land, coastal places have milder, more maritime climates, while places deep in continents have extreme continental climates with hot summers and cold winters. Siberian towns such as Verkhoyansk and Oymyakon can range from about −50°C in winter to above 30°C in summer.",
    "The highest air temperature officially recorded is 56.7°C at Death Valley, California, in 1913, though some scientists question that reading; the lowest is −89.2°C at Vostok Station in Antarctica in 1983. Cities are often several degrees warmer than surrounding countryside, an effect called the urban heat island, because pavement and buildings absorb heat."]]
  ],
  terms:[["Weather","The state of the atmosphere at a given time and place."],["Climate","The long-term average pattern of weather."],["Troposphere","The lowest atmospheric layer, where weather occurs."],["Stratosphere","The layer above the troposphere containing the ozone layer."],["Ozone layer","Stratospheric ozone that absorbs ultraviolet radiation."],["Albedo","The fraction of sunlight a surface reflects."],["Greenhouse effect","The warming of Earth by gases that absorb infrared radiation."],["Urban heat island","The extra warmth of cities compared with surroundings."]],
  w:"The atmosphere's composition, layers, and energy balance explain why Earth is habitable and set the stage for all weather and climate.",
  src:["Atmosphere of Earth","Troposphere","Stratosphere","Ozone layer","Montreal Protocol","Albedo","Greenhouse effect"],
  q:[["What is the most abundant gas in the atmosphere?","Nitrogen","Oxygen","Carbon dioxide","Argon"],
     ["In which layer does nearly all weather occur?","Troposphere","Stratosphere","Mesosphere","Thermosphere"],
     ["Which layer contains the ozone layer?","Stratosphere","Troposphere","Mesosphere","Thermosphere"],
     ["Which treaty phased out ozone-destroying CFCs?","The Montreal Protocol","The Kyoto Protocol","The Paris Agreement","The Rio Convention"],
     ["What is the fraction of sunlight a surface reflects called?","Albedo","Insolation","Emissivity","Lapse rate"],
     ["Without the natural greenhouse effect, Earth's average temperature would be about:","−18°C","0°C","15°C","−50°C"]]},

{ t:"Air Pressure, Wind, and Global Circulation", s:"How the atmosphere moves heat around the planet",
  sec:[
  ["Air pressure",[
    "Air pressure is the weight of the air above a point. At sea level it averages about 1013 millibars (hectopascals), and it decreases rapidly with height; at the summit of Everest it is about one-third of sea-level pressure. Pressure is measured with a barometer, invented by Evangelista Torricelli in 1643.",
    "Warm air expands, becomes less dense, and rises, creating low pressure at the surface; low-pressure systems are associated with clouds and rain because rising air cools. Cool, dense air sinks, creating high pressure, usually associated with clear, dry weather. On weather maps, lines of equal pressure are called isobars."]],
  ["Why wind blows",[
    "Wind is air moving from areas of high pressure to areas of low pressure. The greater the pressure difference over a distance, the pressure gradient, the stronger the wind; closely spaced isobars mean strong winds. Winds are named for the direction they come from: a westerly blows from the west.",
    "The Coriolis effect deflects winds, so in the Northern Hemisphere air circulates counterclockwise around low-pressure systems and clockwise around highs; the reverse is true in the Southern Hemisphere. Friction with the surface slows winds near the ground. Wind speed is described by the Beaufort scale, from 0 (calm) to 12 (hurricane force)."]],
  ["Local winds",[
    "Local winds result from local differences in heating. On sunny days, land heats faster than the sea, so a cool sea breeze blows onshore; at night, a land breeze blows offshore. In mountains, valley breezes blow uphill by day and mountain breezes downhill at night.",
    "Some local winds have famous names. The chinook in the Rocky Mountains and the foehn in the Alps are warm, dry winds descending the lee side of mountains that can melt snow rapidly. The mistral is a cold wind funneling down France's Rhône Valley; the sirocco brings hot, dusty air from the Sahara to southern Europe; and the Santa Ana winds of Southern California spread wildfires."]],
  ["The three-cell model",[
    "Because the tropics receive more energy than the poles, the atmosphere circulates to carry heat poleward. Near the Equator, intense heating causes air to rise in a belt of low pressure called the Intertropical Convergence Zone (ITCZ), producing heavy rain. The air flows poleward at high altitude, cools, and sinks around 30° latitude, creating subtropical high-pressure belts, where most of the world's great deserts lie. This loop is the Hadley cell, named after George Hadley, who described it in 1735.",
    "Two other cells complete the pattern: the Ferrel cell in the mid-latitudes and the Polar cell near the poles, where cold, dense air sinks to form polar highs. Where cold polar air meets warmer air around 60° latitude, the polar front forms, a zone of rising air and stormy weather."]],
  ["Global wind belts",[
    "Surface winds blowing from the subtropical highs toward the Equator are deflected by the Coriolis effect to become the trade winds, blowing from the northeast in the Northern Hemisphere and from the southeast in the Southern. They carried sailing ships across the Atlantic. Near the Equator, where trade winds converge and winds are weak, sailors spoke of the doldrums.",
    "Between about 30° and 60° latitude, the prevailing westerlies blow from west to east, which is why weather in the United States and Europe generally moves from west to east. In the Southern Hemisphere, with little land to slow them, the westerlies are fierce; sailors called these latitudes the Roaring Forties, Furious Fifties, and Screaming Sixties. Near the poles, polar easterlies blow."]],
  ["Jet streams and monsoons",[
    "Jet streams are fast, narrow rivers of air near the top of the troposphere, blowing from west to east at speeds that can exceed 300 kilometers per hour. The polar jet stream, which meanders in large waves, steers storm systems and separates cold polar air from warmer air; airplanes flying east use it to save time and fuel.",
    "Monsoons are seasonal reversals of wind. The South Asian monsoon is the most important: in summer, the land heats up, low pressure forms over the Indian subcontinent, and moist winds from the Indian Ocean bring torrential rains from June to September; in winter, dry winds blow from the land. Over a billion people depend on the monsoon rains for agriculture. Cherrapunji and Mawsynram in northeastern India are among the wettest places on Earth."]]
  ],
  terms:[["Air pressure","The weight of the air above a point."],["Isobar","A line of equal air pressure on a map."],["Pressure gradient","The change in pressure over distance that drives wind."],["ITCZ","The equatorial low-pressure zone where trade winds converge."],["Hadley cell","The tropical circulation loop between the Equator and about 30°."],["Trade winds","Steady winds blowing toward the Equator."],["Westerlies","Prevailing mid-latitude winds blowing from the west."],["Monsoon","A seasonal reversal of winds bringing wet and dry seasons."]],
  w:"Global circulation and wind belts explain where the world's rainforests and deserts are, why weather moves as it does, and how monsoons sustain billions of people.",
  src:["Atmospheric pressure","Wind","Atmospheric circulation","Hadley cell","Trade winds","Jet stream","Monsoon"],
  q:[["What kind of weather is usually associated with high pressure?","Clear and dry","Rainy and stormy","Foggy","Snowy"],
     ["Which way does air circulate around a low in the Northern Hemisphere?","Counterclockwise","Clockwise","Straight inward","Upward only"],
     ["What is a warm, dry wind descending the Rocky Mountains called?","Chinook","Mistral","Sirocco","Bora"],
     ["Around what latitude do most great deserts lie?","30°","0°","60°","90°"],
     ["Which winds blow toward the Equator from the subtropical highs?","The trade winds","The westerlies","The polar easterlies","The jet streams"],
     ["What causes the South Asian summer monsoon?","Heating of the land creating low pressure","Ocean currents from Antarctica","The jet stream reversing","Volcanic activity"]]},

{ t:"Water in the Air: Clouds and Precipitation", s:"Humidity, clouds, rain, and snow",
  sec:[
  ["Humidity",[
    "Water vapor enters the air by evaporation from oceans, lakes, and soil and by transpiration from plants, together called evapotranspiration. Humidity is the amount of water vapor in the air. Warm air can hold much more water vapor than cold air; roughly, the capacity rises about 7 percent per degree Celsius.",
    "Relative humidity is the amount of water vapor in the air compared with the maximum it could hold at that temperature, expressed as a percentage. When air cools, its relative humidity rises; when it reaches 100 percent, the air is saturated. The temperature at which this happens is the dew point."]],
  ["Condensation and clouds",[
    "When saturated air cools further, water vapor condenses into tiny droplets around particles called condensation nuclei, forming clouds, fog, or dew. Most clouds form when air rises and cools as it expands in lower pressure.",
    "In 1802 the English chemist Luke Howard devised the cloud classification still used today, with Latin names. Cirrus clouds are high, thin, and wispy, made of ice crystals. Cumulus clouds are puffy, with flat bases, often seen on fair days. Stratus clouds are flat, gray layers covering the sky. Cumulonimbus are towering thunderstorm clouds that can reach the top of the troposphere, often with an anvil-shaped top. Nimbostratus are thick gray rain clouds."]],
  ["Three ways air rises",[
    "Convectional rainfall occurs when the Sun heats the ground, warm air rises, cools, and forms cumulus and cumulonimbus clouds, often producing afternoon thunderstorms. It is typical of the tropics and of summer afternoons inland.",
    "Orographic (relief) rainfall occurs when moist air is forced up over mountains, cools, and drops rain on the windward side. The descending air on the leeward side warms and dries, creating a rain shadow. The western slopes of the Cascades are very wet, while eastern Washington is dry; the Atacama Desert in Chile and the Gobi are partly rain shadows. Frontal (cyclonic) rainfall occurs when warm air is forced up over colder, denser air along a front."]],
  ["Forms of precipitation",[
    "Precipitation is water falling from clouds. Cloud droplets are too small to fall; they must grow, either by colliding and merging or, in cold clouds, through the growth of ice crystals at the expense of droplets, which then fall as snow and may melt into rain.",
    "Forms include rain, drizzle, snow, sleet (ice pellets), freezing rain, which freezes on contact with cold surfaces and causes ice storms, and hail, balls of ice built up in layers as they are carried up and down in strong thunderstorm updrafts. Fog is a cloud at ground level, common in valleys on still nights and along cold-current coasts such as San Francisco's."]],
  ["Thunderstorms and tornadoes",[
    "Thunderstorms form in cumulonimbus clouds where warm, moist, unstable air rises rapidly. Lightning is a giant electrical discharge; it heats the air to around 30,000°C, causing the rapid expansion we hear as thunder. Because light travels faster than sound, counting the seconds between flash and thunder and dividing by three gives the approximate distance in kilometers.",
    "Tornadoes are violently rotating columns of air extending from thunderstorms to the ground, with winds that can exceed 400 kilometers per hour. They are most common in the United States, especially “Tornado Alley” in the Great Plains, where cold dry air from Canada, warm moist air from the Gulf of Mexico, and dry air from the Southwest meet. Tornado strength is rated on the Enhanced Fujita scale from EF0 to EF5."]],
  ["The distribution of precipitation",[
    "Precipitation varies enormously around the world. It is heavy near the Equator, where air rises in the ITCZ, and on windward coasts and mountains; it is low in the subtropical highs, in rain shadows, deep in continental interiors, and in polar regions, which are technically deserts.",
    "The driest place on Earth outside Antarctica is the Atacama Desert, where some weather stations have recorded almost no rain for years. Among the wettest are Mawsynram in India and parts of the Colombian Pacific coast, which receive more than 10 meters of rain a year."]]
  ],
  terms:[["Relative humidity","Water vapor in the air as a percentage of the maximum possible."],["Dew point","The temperature at which air becomes saturated."],["Cumulonimbus","A towering thunderstorm cloud."],["Orographic rainfall","Rain caused by air rising over mountains."],["Rain shadow","A dry area on the leeward side of mountains."],["Convectional rainfall","Rain caused by rising heated air."],["Hail","Layered balls of ice formed in thunderstorm updrafts."],["Tornado","A violently rotating column of air reaching the ground."]],
  w:"Understanding how air rises, cools, and condenses explains clouds, rain, deserts, and storms, and why some places are lush and others barren.",
  src:["Humidity","Dew point","Cloud","Precipitation","Rain shadow","Thunderstorm","Tornado"],
  q:[["What is the temperature at which air becomes saturated called?","The dew point","The lapse rate","The freezing point","The boiling point"],
     ["Who devised the modern system of cloud names?","Luke Howard","Benjamin Franklin","George Hadley","Anders Celsius"],
     ["Which clouds are high, thin, and made of ice crystals?","Cirrus","Cumulus","Stratus","Nimbostratus"],
     ["What is the dry area on the leeward side of mountains called?","A rain shadow","A monsoon","A front","A doldrum"],
     ["What causes thunder?","Rapid expansion of air heated by lightning","Clouds colliding","Hail hitting the ground","Wind shear"],
     ["Where are tornadoes most common?","The United States","India","Australia","Brazil"]]},

{ t:"Air Masses, Fronts, and Storms", s:"The weather systems that bring change",
  sec:[
  ["Air masses",[
    "An air mass is a huge body of air with fairly uniform temperature and humidity, acquired from the region where it formed, its source region. Air masses are classified by latitude, polar (P), arctic (A), or tropical (T), and by surface, continental (c), which is dry, or maritime (m), which is moist.",
    "For example, continental polar air from northern Canada brings cold, dry weather to the central United States in winter; maritime tropical air from the Gulf of Mexico brings warm, humid weather; and maritime polar air from the North Atlantic brings cool, damp weather to Britain."]],
  ["Fronts",[
    "A front is the boundary between two air masses of different temperature and humidity, a concept developed by the Norwegian meteorologists Vilhelm and Jacob Bjerknes and their colleagues in Bergen around World War I, borrowing the military term. At a cold front, cold air advances and pushes warm air sharply upward, causing a narrow band of heavy showers or thunderstorms, followed by cooler, clearer weather.",
    "At a warm front, warm air rides gradually up over retreating cold air, producing a broad area of layered clouds and steady rain or snow ahead of it. A stationary front shows little movement, and an occluded front forms when a cold front overtakes a warm front. On weather maps, cold fronts are drawn with blue triangles and warm fronts with red semicircles."]],
  ["Mid-latitude cyclones",[
    "Most weather in the mid-latitudes, including the United States, Europe, and China, comes from mid-latitude cyclones (also called depressions or extratropical cyclones), large low-pressure systems that form along the polar front, often steered by the jet stream. They have a warm front and a cold front and bring a characteristic sequence of weather: thickening clouds and rain ahead of the warm front, a milder interlude, and then showers and colder air behind the cold front.",
    "Anticyclones, high-pressure systems, bring settled weather: warm sunny days in summer and cold, clear, sometimes foggy conditions in winter. A blocking high can stay in place for weeks, causing heat waves or droughts."]],
  ["Tropical cyclones",[
    "Tropical cyclones are intense low-pressure systems that form over warm tropical oceans, typically with sea temperatures above about 26.5°C. They are called hurricanes in the Atlantic and northeastern Pacific, typhoons in the northwestern Pacific, and cyclones in the Indian Ocean and South Pacific. They do not form within about 5° of the Equator, where the Coriolis effect is too weak to start them spinning.",
    "A mature tropical cyclone has a calm, clear eye surrounded by the eyewall, where winds and rain are most intense, and spiraling rain bands. The Saffir-Simpson scale rates Atlantic hurricanes from Category 1 to Category 5 (winds of 252 km/h or more). Storms weaken over land or cold water because they lose their source of warm, moist air."]],
  ["Hurricane hazards",[
    "The deadliest hurricane hazard is usually storm surge, a rise in sea level pushed ashore by winds, along with flooding from heavy rain. Hurricane Katrina in 2005 caused levee failures in New Orleans and killed about 1,400 people. The 1970 Bhola cyclone in East Pakistan (now Bangladesh) killed perhaps 300,000 or more people, and Cyclone Nargis killed about 140,000 in Myanmar in 2008.",
    "Improved forecasting, satellite tracking, evacuation plans, and cyclone shelters have greatly reduced deaths in many countries; Bangladesh's shelters and warning systems are a notable success."]],
  ["Forecasting",[
    "Modern weather forecasting began with the telegraph, which allowed observations to be gathered quickly, and advanced with weather balloons, radar, and satellites. Today, numerical weather prediction uses supercomputers to solve the equations of atmospheric physics, an approach first attempted by Lewis Fry Richardson in the 1920s and achieved with early computers in 1950.",
    "Because the atmosphere is chaotic, as the meteorologist Edward Lorenz showed in the 1960s, small uncertainties grow, limiting detailed forecasts to about one to two weeks. Forecast accuracy has improved steadily: a five-day forecast today is about as accurate as a one-day forecast was in 1980."]]
  ],
  terms:[["Air mass","A large body of air with uniform temperature and humidity."],["Front","The boundary between two air masses."],["Cold front","Where cold air advances, causing sharp uplift and showers."],["Warm front","Where warm air rises gradually over cold air."],["Mid-latitude cyclone","A large low-pressure system bringing most mid-latitude weather."],["Tropical cyclone","A hurricane, typhoon, or cyclone forming over warm oceans."],["Storm surge","A rise in sea level pushed ashore by a storm."],["Saffir-Simpson scale","The 1–5 scale for hurricane wind strength."]],
  w:"Air masses, fronts, and cyclones explain the day-to-day changes in weather and the hazards of hurricanes, while forecasting saves countless lives.",
  src:["Air mass","Weather front","Extratropical cyclone","Tropical cyclone","Saffir–Simpson scale","Storm surge","Numerical weather prediction"],
  q:[["What does the code mT stand for?","Maritime tropical air","Mountain temperate air","Mid-level turbulence","Moist temperate air"],
     ["Which meteorologists developed the concept of fronts?","The Bergen school led by the Bjerknes","Luke Howard","Edward Lorenz","George Hadley"],
     ["What kind of front brings a narrow band of heavy showers?","A cold front","A warm front","A stationary front","No front"],
     ["What are tropical cyclones called in the northwestern Pacific?","Typhoons","Hurricanes","Cyclones","Willy-willies"],
     ["What is usually the deadliest hurricane hazard?","Storm surge","Lightning","Hail","Tornadoes"],
     ["Who showed that the atmosphere is chaotic, limiting forecasts?","Edward Lorenz","Lewis Fry Richardson","Vilhelm Bjerknes","John von Neumann"]]},

{ t:"Climates of the World", s:"The Köppen system and the world's climate zones",
  sec:[
  ["Classifying climates",[
    "The most widely used climate classification was created by the German-Russian climatologist Wladimir Köppen around 1900 and later refined with Rudolf Geiger. It groups climates mainly by temperature and precipitation and their seasonal patterns, chosen because they correspond closely to natural vegetation.",
    "Köppen's five main groups are labeled with letters: A (tropical), B (dry), C (temperate or mild mid-latitude), D (continental or cold mid-latitude), and E (polar). Additional letters describe rainfall seasons and temperature details. Highland climates, which change rapidly with altitude, are often added as a separate category, H."]],
  ["Tropical climates (A)",[
    "Tropical climates have every month averaging above 18°C. The tropical rainforest climate (Af), near the Equator in the Amazon, Congo Basin, and Indonesia, is hot and wet all year, with almost daily afternoon thunderstorms. The tropical monsoon climate (Am), as in parts of India and Southeast Asia, has a short dry season but huge total rainfall.",
    "The tropical savanna climate (Aw), found in much of Africa, Brazil, India, and northern Australia, has a distinct wet season when the ITCZ is overhead and a long dry season, supporting grasslands with scattered trees."]],
  ["Dry climates (B)",[
    "Dry climates are those where potential evaporation exceeds precipitation. Hot deserts (BWh), such as the Sahara, Arabian, Kalahari, and Australian deserts, lie mainly under the subtropical highs; days are scorching and nights can be cool because dry air loses heat quickly. Cold deserts (BWk), such as the Gobi and Great Basin, lie in continental interiors or rain shadows.",
    "Semi-arid steppe climates (BS) border the deserts and receive enough rain for grasslands; they include the Sahel, the Great Plains, and the steppes of Central Asia. Cold-current coastal deserts, such as the Atacama and the Namib, are extremely dry but often foggy."]],
  ["Temperate climates (C)",[
    "The Mediterranean climate (Cs), with hot dry summers and mild wet winters, occurs on the western sides of continents around 30–40° latitude: around the Mediterranean, in California, central Chile, the Cape region of South Africa, and southwestern Australia. It favors olives, grapes, and citrus, and is prone to summer wildfires.",
    "The humid subtropical climate (Cfa, Cwa), with hot humid summers and mild winters, covers the southeastern United States, southern China, southern Brazil, and eastern Australia. The marine west coast or oceanic climate (Cfb), with mild temperatures and rain spread through the year, covers western Europe, the Pacific Northwest, New Zealand, and southern Chile; the warm North Atlantic Current extends it far north in Europe."]],
  ["Continental and polar climates (D, E)",[
    "Continental climates (D), found only in the Northern Hemisphere because the Southern Hemisphere lacks large landmasses at the right latitudes, have warm or hot summers and cold, snowy winters. Humid continental climates cover the northeastern United States, much of eastern Europe, and northeastern China. The subarctic climate (Dfc), with long, very cold winters and brief summers, covers vast areas of Canada, Alaska, Scandinavia, and Siberia, the realm of the boreal forest.",
    "Polar climates (E) have no month averaging above 10°C. Tundra climates (ET), along the Arctic coasts, have brief summers allowing low shrubs, mosses, and lichens; ice cap climates (EF), in Antarctica and interior Greenland, have every month below freezing. Highland climates change with altitude, so that a mountain in the tropics can pass from rainforest at its base to permanent snow at its summit, as on Kilimanjaro."]],
  ["Controls of climate",[
    "Several factors combine to determine a place's climate. Latitude controls the amount of solar energy. Altitude lowers temperatures; Quito, almost on the Equator but at about 2,850 meters, has spring-like weather all year. Distance from the sea determines whether climate is maritime or continental.",
    "Ocean currents warm or cool coasts: the North Atlantic Current keeps Norway's ports ice-free, while the cold Humboldt Current helps keep coastal Peru and Chile dry. Prevailing winds, mountain barriers, and global pressure belts complete the picture. Understanding these controls lets you predict the climate of a place just by knowing its location on the map."]]
  ],
  terms:[["Köppen classification","The most widely used system for classifying climates."],["Tropical rainforest climate","A hot climate with heavy rain all year."],["Savanna climate","A tropical climate with distinct wet and dry seasons."],["Steppe","A semi-arid grassland climate."],["Mediterranean climate","Hot dry summers and mild wet winters."],["Marine west coast climate","Mild temperatures with rain throughout the year."],["Subarctic climate","Long, very cold winters and short summers."],["Tundra","A polar climate with brief summers and no trees."]],
  w:"The world's climate zones determine vegetation, agriculture, and ways of life, and knowing their causes lets you understand any place on Earth.",
  src:["Köppen climate classification","Tropical rainforest climate","Tropical savanna climate","Desert climate","Mediterranean climate","Oceanic climate","Subarctic climate"],
  q:[["Who created the most widely used climate classification?","Wladimir Köppen","Alexander von Humboldt","Luke Howard","Charles Thornthwaite"],
     ["Which Köppen letter represents dry climates?","B","A","C","E"],
     ["Which climate has hot dry summers and mild wet winters?","Mediterranean","Humid subtropical","Oceanic","Savanna"],
     ["Why are continental (D) climates found only in the Northern Hemisphere?","The Southern Hemisphere lacks large landmasses at those latitudes","The Southern Hemisphere is warmer","Ocean currents prevent them","The ozone hole prevents them"],
     ["What keeps Norway's ports ice-free?","The North Atlantic Current","The Humboldt Current","The jet stream","Volcanic heat"],
     ["Which climate type supports the boreal forest?","Subarctic","Tundra","Savanna","Mediterranean"]]}

]});


/* ---- from geo-05.js ---- */
/* GEOGRAPHY FOUNDATIONS, part 5: climate change; Unit 4 Water and Life begins */
COURSES.geography.units[2].ch.push(
{ t:"Climate Change", s:"Past climates, present warming, and future choices",
  sec:[
  ["Climate has always changed",[
    "Earth's climate has changed throughout its history, from “Snowball Earth” episodes hundreds of millions of years ago, when ice may have reached the tropics, to hothouse periods such as the time of the dinosaurs, when there was little or no polar ice. Over the past 2.6 million years, ice ages and warm interglacials have alternated.",
    "Scientists reconstruct past climates using proxies: ice cores from Antarctica and Greenland, whose trapped air bubbles record greenhouse gas levels going back about 800,000 years; tree rings; corals; ocean sediments; and pollen. These records show that carbon dioxide and temperature have risen and fallen together."]],
  ["Natural causes",[
    "Natural drivers of climate change include variations in Earth's orbit (Milankovitch cycles), changes in the Sun's output, large volcanic eruptions, which cool the planet temporarily by injecting reflective particles into the stratosphere, and, over millions of years, the movement of continents and changes in ocean circulation.",
    "Feedbacks amplify changes. As ice melts, darker land and ocean absorb more sunlight (the ice-albedo feedback); warmer air holds more water vapor, itself a greenhouse gas. Recent centuries also saw smaller natural fluctuations, such as the Medieval Warm Period and the Little Ice Age (roughly 1300–1850), which were regional and modest compared with today's change."]],
  ["Human-caused warming",[
    "Since the Industrial Revolution, humans have increased the concentration of carbon dioxide in the atmosphere by about 50 percent, mainly by burning coal, oil, and natural gas, and by deforestation. Methane, from livestock, rice paddies, landfills, and fossil fuel production, has more than doubled. The physicist John Tyndall showed in 1859 that carbon dioxide traps heat, and Svante Arrhenius estimated in 1896 that doubling it would warm the planet several degrees.",
    "Charles David Keeling's measurements at Mauna Loa, Hawaii, begun in 1958, revealed the steady rise of carbon dioxide, known as the Keeling Curve. The Intergovernmental Panel on Climate Change (IPCC), founded in 1988, concluded in its 2021 report that it is unequivocal that human influence has warmed the atmosphere, ocean, and land. By the mid-2020s the world was roughly 1.2–1.3°C warmer than in the late 19th century, and 2024 was the first calendar year to exceed 1.5°C above pre-industrial levels."]],
  ["Observed effects",[
    "The effects are already visible: more frequent and intense heat waves, heavier downpours, more severe droughts and wildfires in many regions, shrinking Arctic sea ice, retreating mountain glaciers, melting ice sheets, and sea level rise. The ocean has absorbed over 90 percent of the extra heat and about a quarter to a third of the carbon dioxide emitted, making seawater more acidic, which threatens corals and shellfish.",
    "Ecosystems are shifting: species are moving toward the poles and to higher altitudes, spring is arriving earlier, and coral reefs are suffering repeated bleaching. The Arctic is warming roughly three to four times faster than the global average."]],
  ["Risks and inequality",[
    "Future warming depends on future emissions. Higher warming increases risks to food and water supplies, health, coastal cities, and ecosystems, and raises the possibility of tipping points, such as the collapse of parts of the West Antarctic or Greenland ice sheets or dieback of the Amazon rainforest.",
    "Climate change is deeply unequal. Wealthy industrialized countries have produced most historical emissions, while poorer countries and small island states, which contributed least, are often the most vulnerable, a central issue in climate negotiations about fairness and finance."]],
  ["Responses",[
    "Responses fall into two categories. Mitigation reduces emissions: shifting to renewable energy such as solar and wind, improving efficiency, electrifying transport, protecting forests, and capturing carbon. Solar and wind power became dramatically cheaper in the 2010s and are now the fastest-growing sources of electricity. Adaptation reduces harm: sea walls, drought-resistant crops, heat warning systems, and better water management.",
    "International agreements include the U.N. Framework Convention on Climate Change (1992), the Kyoto Protocol (1997), and the Paris Agreement (2015), under which nearly all countries pledged to limit warming to well below 2°C, and to pursue efforts to limit it to 1.5°C, through national emissions pledges. Meeting these goals requires reaching net-zero carbon dioxide emissions around mid-century."]]
  ],
  terms:[["Proxy data","Natural records used to reconstruct past climates."],["Little Ice Age","A cooler period from about 1300 to 1850."],["Keeling Curve","The record of rising atmospheric CO₂ measured since 1958."],["IPCC","The U.N. scientific body assessing climate change, founded in 1988."],["Ocean acidification","The lowering of seawater pH by absorbed CO₂."],["Mitigation and adaptation","Reducing emissions vs. reducing harm from climate change."],["Paris Agreement","The 2015 global climate agreement."]],
  w:"Climate change is reshaping every region on Earth, and understanding its causes, effects, and solutions is essential geography for this century.",
  src:["Climate change","Paleoclimatology","Keeling Curve","Intergovernmental Panel on Climate Change","Ocean acidification","Paris Agreement","Climate change mitigation"],
  q:[["Which records preserve air bubbles going back about 800,000 years?","Antarctic ice cores","Tree rings","Corals","Pollen"],
     ["Who showed in 1859 that carbon dioxide traps heat?","John Tyndall","Svante Arrhenius","Charles Keeling","Joseph Fourier"],
     ["Where has the Keeling Curve been measured since 1958?","Mauna Loa, Hawaii","Antarctica","Greenland","Geneva"],
     ["Roughly how much has atmospheric CO₂ increased since pre-industrial times?","About 50 percent","About 5 percent","About 200 percent","It has not changed"],
     ["How much of the extra heat has the ocean absorbed?","Over 90 percent","About 10 percent","About half","Almost none"],
     ["Which 2015 agreement aims to limit warming to well below 2°C?","The Paris Agreement","The Kyoto Protocol","The Montreal Protocol","The Rio Declaration"]]}
);

COURSES.geography.units.push({ t:"Water and Life", ch:[

{ t:"The World Ocean", s:"Oceans, seas, and the ocean floor",
  sec:[
  ["One world ocean",[
    "The oceans cover about 71 percent of Earth's surface and hold about 97 percent of its water. Though they are all connected in a single world ocean, geographers traditionally recognize five oceans: the Pacific, the largest and deepest, which covers about a third of the Earth's surface, larger than all the land combined; the Atlantic, the second largest; the Indian; the Southern Ocean, surrounding Antarctica, officially recognized by many bodies in the 2000s; and the Arctic, the smallest and shallowest.",
    "Seas are smaller bodies of salt water, often partly enclosed by land, such as the Mediterranean, Caribbean, South China, Arabian, Baltic, and North Seas. The Caspian Sea, between Europe and Asia, is actually the world's largest lake, and the Dead Sea is a salt lake."]],
  ["The ocean floor",[
    "Beyond the shore lies the continental shelf, a gently sloping, shallow extension of the continent, usually less than 200 meters deep. It is the most productive part of the ocean, rich in fish and holding much offshore oil and gas. The shelf ends at the continental slope, which drops steeply to the deep ocean floor.",
    "The deep ocean floor includes vast flat abyssal plains, around 4,000–6,000 meters deep; the mid-ocean ridge system, a chain of underwater mountains over 60,000 kilometers long, the longest mountain range on Earth; deep trenches at subduction zones; and seamounts, underwater volcanoes. More of the Moon's surface has been mapped in detail than the floor of Earth's oceans."]],
  ["Seawater",[
    "Seawater has an average salinity of about 35 parts per thousand, mostly dissolved sodium chloride. Salt comes from minerals washed from the land by rivers and from undersea volcanic vents. Salinity is higher where evaporation is strong and there is little fresh water, as in the Red Sea, and lower where rivers or melting ice add fresh water, as in the Baltic.",
    "Ocean temperature decreases with depth. Sunlight penetrates only the upper 200 meters or so, the sunlit zone where photosynthesis occurs; below lies a dark, cold world where temperatures are near freezing. A layer of rapid temperature change, the thermocline, separates warm surface water from cold deep water."]],
  ["Life in the sea",[
    "The base of the marine food web is phytoplankton, microscopic algae that produce roughly half of the oxygen made by photosynthesis on Earth. They are eaten by zooplankton, which feed fish, whales, and seabirds. Marine life is concentrated on continental shelves and in areas of upwelling, where cold, nutrient-rich water rises to the surface, such as off Peru, California, and Namibia, which support huge fisheries.",
    "In the deep sea, hydrothermal vents, discovered in 1977 near the Galápagos, support communities of tube worms, clams, and bacteria that live on chemical energy rather than sunlight. The open ocean far from land is largely nutrient-poor, an oceanic desert."]],
  ["The law of the sea and resources",[
    "The U.N. Convention on the Law of the Sea (1982) sets rules for the oceans. Coastal states control territorial seas extending 12 nautical miles from shore, and exclusive economic zones (EEZs) of up to 200 nautical miles, where they have rights to fish and minerals. Beyond lie the high seas, open to all.",
    "Oceans provide food, energy, transport for about 80 percent of world trade by volume, and tourism. They face serious threats: overfishing, which has depleted many fish stocks; plastic pollution, including the Great Pacific Garbage Patch; nutrient runoff causing oxygen-poor dead zones, such as one in the Gulf of Mexico; warming; and acidification. A High Seas Treaty to protect marine biodiversity beyond national jurisdiction was agreed in 2023."]],
  ["Strategic waterways",[
    "A few narrow passages carry a large share of world shipping. The Strait of Malacca, between Malaysia and Sumatra, links the Indian Ocean and the Pacific. The Strait of Hormuz, at the mouth of the Persian Gulf, carries about a fifth of the world's oil. The Bab-el-Mandeb links the Red Sea and the Gulf of Aden.",
    "The two great artificial waterways are the Suez Canal (opened 1869), linking the Mediterranean and Red Sea, and the Panama Canal (opened 1914), linking the Atlantic and Pacific. The Strait of Gibraltar, the Bosporus and Dardanelles, the English Channel, and the Danish straits are also vital. Disruptions at these chokepoints, such as when the ship Ever Given blocked the Suez Canal in 2021, ripple through the global economy."]]
  ],
  terms:[["Continental shelf","The shallow submerged edge of a continent."],["Abyssal plain","The flat deep ocean floor."],["Salinity","The concentration of dissolved salts in water."],["Thermocline","The layer of rapid temperature change in the ocean."],["Phytoplankton","Microscopic marine algae at the base of the food web."],["Upwelling","The rise of cold, nutrient-rich deep water."],["Exclusive economic zone","Waters up to 200 nautical miles where a coastal state controls resources."],["Chokepoint","A narrow strategic waterway."]],
  w:"The ocean covers most of the planet, regulates its climate, produces much of its oxygen, and carries most of its trade, making it essential to understand.",
  src:["Ocean","Pacific Ocean","Continental shelf","Seawater","Phytoplankton","United Nations Convention on the Law of the Sea","Strait of Hormuz"],
  q:[["Which is the largest ocean?","The Pacific","The Atlantic","The Indian","The Southern"],
     ["Which is the smallest and shallowest ocean?","The Arctic","The Southern","The Indian","The Atlantic"],
     ["What is the average salinity of seawater?","About 35 parts per thousand","About 3.5 parts per thousand","About 350 parts per thousand","About 1 part per thousand"],
     ["What produces roughly half of the oxygen from photosynthesis on Earth?","Phytoplankton","Rainforests","Grasslands","Coral reefs"],
     ["How far does an exclusive economic zone extend?","200 nautical miles","12 nautical miles","50 nautical miles","500 nautical miles"],
     ["Which strait carries about a fifth of the world's oil?","Hormuz","Malacca","Gibraltar","Dover"]]},

{ t:"Ocean Currents and El Niño", s:"The ocean's great conveyor belts",
  sec:[
  ["Surface currents",[
    "Ocean currents are continuous flows of seawater. Surface currents are driven mainly by the prevailing winds and deflected by the Coriolis effect and the shape of the continents. They form great circular systems called gyres, which turn clockwise in the Northern Hemisphere and counterclockwise in the Southern. There are five major gyres: the North and South Pacific, the North and South Atlantic, and the Indian Ocean.",
    "Around Antarctica, with no continents to block it, the Antarctic Circumpolar Current flows eastward around the globe; it is the largest ocean current, carrying more than 100 times the flow of all the world's rivers."]],
  ["Warm and cold currents",[
    "Currents flowing from the tropics toward the poles along the western sides of ocean basins are warm. The Gulf Stream, flowing from the Gulf of Mexico along the U.S. East Coast and across the Atlantic as the North Atlantic Current, carries enormous amounts of heat, helping give western Europe its mild climate. The Kuroshio Current off Japan is its Pacific counterpart.",
    "Currents flowing toward the Equator along the western coasts of continents are cold, such as the California, Humboldt (Peru), Canary, and Benguela currents. They cool coastal climates, cause frequent fog, stabilize the air, and contribute to coastal deserts such as the Atacama and the Namib. Often they are associated with upwelling and rich fisheries."]],
  ["The global conveyor belt",[
    "Deep ocean currents are driven by differences in water density, which depends on temperature and salinity, a process called thermohaline circulation. In the North Atlantic near Greenland and around Antarctica, cold, salty water becomes dense and sinks, flowing slowly through the deep ocean basins before eventually rising elsewhere.",
    "This global conveyor belt links all the oceans and takes roughly a thousand years for a parcel of water to complete. Its Atlantic portion, the Atlantic Meridional Overturning Circulation (AMOC), carries heat northward. Scientists are concerned that freshwater from melting Greenland ice could weaken it, with major consequences for climate around the Atlantic."]],
  ["El Niño and La Niña",[
    "Normally, trade winds push warm surface water westward across the tropical Pacific toward Indonesia and Australia, while cold water upwells off South America. Every two to seven years, the trade winds weaken and warm water spreads back east toward Peru. Peruvian fishermen called this event El Niño, “the child,” because it often appeared around Christmas.",
    "El Niño is part of a larger cycle called the El Niño–Southern Oscillation (ENSO). Its opposite phase, La Niña, brings stronger trade winds and cooler-than-normal water in the eastern Pacific. ENSO is the most important source of year-to-year climate variability on Earth."]],
  ["Global effects of ENSO",[
    "El Niño affects weather around the world. It typically brings heavy rain and flooding to Peru and Ecuador, drought to Indonesia, Australia, and southern Africa, weaker Indian monsoons, milder winters in the northern United States, and fewer Atlantic hurricanes. It also collapses Peru's anchovy fishery as nutrient-rich upwelling weakens, and it raises global average temperatures temporarily.",
    "La Niña tends to produce the opposite effects, such as more Atlantic hurricanes and drought in the southwestern United States. Major El Niño events, such as those of 1982–1983, 1997–1998, and 2015–2016, caused billions of dollars in damage, and forecasting ENSO helps farmers and governments prepare."]],
  ["Currents and history",[
    "Currents shaped exploration and trade. Sailing ships rode the Canary Current and trade winds west to the Americas and the Gulf Stream and westerlies back to Europe; Benjamin Franklin published a chart of the Gulf Stream in the 1770s to speed mail ships. Polynesian navigators read currents and swells to cross the Pacific.",
    "Currents also distribute plastic debris, which accumulates in the centers of gyres, and they carry marine larvae, nutrients, and heat that shape ecosystems around the world."]]
  ],
  terms:[["Gyre","A large circular system of ocean currents."],["Gulf Stream","A warm Atlantic current that warms western Europe."],["Cold current","A current flowing toward the Equator that cools coasts."],["Thermohaline circulation","Deep ocean circulation driven by temperature and salinity."],["AMOC","The Atlantic Meridional Overturning Circulation."],["El Niño","Periodic warming of the eastern tropical Pacific."],["La Niña","Periodic cooling of the eastern tropical Pacific."]],
  w:"Ocean currents move heat around the planet, shape regional climates and fisheries, and through El Niño influence weather worldwide.",
  src:["Ocean current","Ocean gyre","Gulf Stream","Humboldt Current","Thermohaline circulation","El Niño–Southern Oscillation","Atlantic meridional overturning circulation"],
  q:[["Which way do gyres turn in the Northern Hemisphere?","Clockwise","Counterclockwise","Eastward only","They do not turn"],
     ["What is the largest ocean current?","The Antarctic Circumpolar Current","The Gulf Stream","The Kuroshio","The Humboldt"],
     ["Which current helps give western Europe its mild climate?","The Gulf Stream and North Atlantic Current","The Canary Current","The Labrador Current","The Benguela Current"],
     ["What drives deep thermohaline circulation?","Differences in temperature and salinity","Surface winds","Tides","The Moon"],
     ["What does El Niño mean?","The child","The wind","The warm one","The storm"],
     ["What does El Niño typically bring to Indonesia and Australia?","Drought","Floods","Hurricanes","Snow"]]},

{ t:"Fresh Water", s:"The water cycle, rivers, lakes, and groundwater",
  sec:[
  ["The water cycle",[
    "The water (hydrological) cycle is the continuous movement of water between the oceans, atmosphere, and land, powered by the Sun. Water evaporates from oceans and land, transpires from plants, condenses into clouds, and falls as precipitation. On land it may run off into rivers, infiltrate the soil, percolate down to groundwater, be stored in ice, or return to the air.",
    "Water's residence time varies enormously: water vapor stays in the atmosphere for about nine days, water in rivers for weeks, in large lakes for decades, in deep groundwater for thousands of years, and in the Antarctic ice sheet for hundreds of thousands of years."]],
  ["How much fresh water?",[
    "Only about 2.5 percent of Earth's water is fresh. Of that, about 69 percent is locked in glaciers and ice caps and about 30 percent is groundwater. Less than 1 percent of fresh water is in lakes, rivers, soil, and the atmosphere, readily available for use.",
    "Yet this small share sustains all land ecosystems and human civilization. Water availability is very uneven: Brazil, Russia, Canada, and the United States have abundant fresh water, while the Middle East and North Africa are the most water-scarce regions on Earth."]],
  ["Groundwater",[
    "Groundwater fills the pores and cracks in soil and rock below the water table, the upper surface of the saturated zone. Rock layers that hold and transmit water well, such as sandstone and gravel, are aquifers. Springs occur where the water table meets the surface; wells tap aquifers. In artesian aquifers, water is under pressure and may rise without pumping.",
    "Groundwater supplies drinking water to about half the world's people and much of its irrigation. Many aquifers are being depleted faster than they recharge. The Ogallala Aquifer under the U.S. Great Plains, the aquifers of northern India, and the North China Plain have all seen falling water tables. Overpumping can also cause land to sink (subsidence), as in Mexico City and Jakarta."]],
  ["Lakes",[
    "Lakes form in many ways: in glacial basins, as in the Great Lakes, Finland, and Canada; in rift valleys, as in the deep lakes of East Africa and Lake Baikal; in volcanic craters, such as Crater Lake in Oregon; behind dams; and in river oxbows. Lakes without outlets, in dry regions, become salty, such as the Great Salt Lake and the Dead Sea.",
    "Lake Baikal in Siberia is the world's deepest lake (about 1,640 meters) and oldest (about 25 million years), holding roughly a fifth of the world's unfrozen surface fresh water. Lake Superior is the largest freshwater lake by area. The Caspian Sea is the largest lake overall. Lake Victoria, shared by Uganda, Kenya, and Tanzania, is Africa's largest lake and a source of the White Nile. Lake Titicaca on the Peru-Bolivia border is the largest lake in South America and among the highest navigable lakes."]],
  ["Wetlands",[
    "Wetlands, including marshes, swamps, bogs, and floodplains, are areas saturated with water for much of the year. They filter pollutants, store floodwater, recharge groundwater, store carbon (especially peatlands), and support rich wildlife. The Pantanal in Brazil is the largest tropical wetland; the Everglades in Florida and the Okavango Delta in Botswana are famous examples.",
    "About a third or more of the world's wetlands have been lost since 1970, drained for agriculture and development. The Ramsar Convention of 1971, named after the Iranian city where it was signed, protects wetlands of international importance."]],
  ["Water use and scarcity",[
    "Agriculture accounts for about 70 percent of global freshwater withdrawals, industry about 20 percent, and households about 10 percent. Irrigation allows farming in dry lands but can deplete rivers and aquifers. The Aral Sea in Central Asia, once the fourth-largest lake in the world, shrank dramatically after the Soviet Union diverted its feeder rivers, the Amu Darya and Syr Darya, to irrigate cotton, one of the worst environmental disasters of the 20th century.",
    "Billions of people lack safely managed drinking water. Responses include conservation, efficient drip irrigation, recycling wastewater, desalination of seawater, used heavily in Israel and the Gulf states, and international agreements over shared rivers such as the Nile, Indus, Mekong, and Colorado."]]
  ],
  terms:[["Water cycle","The continuous movement of water between oceans, air, and land."],["Water table","The upper surface of saturated ground."],["Aquifer","An underground layer of rock that stores and transmits water."],["Subsidence","The sinking of land, often from groundwater pumping."],["Wetland","Land saturated with water for much of the year."],["Ramsar Convention","The 1971 treaty protecting important wetlands."],["Desalination","Removing salt from seawater to make fresh water."]],
  w:"Fresh water is a tiny and unevenly distributed share of Earth's water, and managing it wisely is one of humanity's most important challenges.",
  src:["Water cycle","Fresh water","Groundwater","Aquifer","Lake Baikal","Aral Sea","Ramsar Convention"],
  q:[["What share of Earth's water is fresh?","About 2.5 percent","About 25 percent","About 50 percent","About 10 percent"],
     ["Where is most fresh water stored?","Glaciers and ice caps","Lakes","Rivers","The atmosphere"],
     ["What is an underground rock layer holding usable water called?","An aquifer","A water table","An estuary","A watershed"],
     ["Which is the world's deepest lake?","Lake Baikal","Lake Tanganyika","Lake Superior","Crater Lake"],
     ["What share of freshwater withdrawals goes to agriculture?","About 70 percent","About 10 percent","About 30 percent","About 90 percent"],
     ["Which Central Asian lake shrank after its rivers were diverted for cotton?","The Aral Sea","The Caspian Sea","Lake Balkhash","Issyk-Kul"]]}

]});


/* ---- from geo-06.js ---- */
/* GEOGRAPHY FOUNDATIONS, part 6: Unit 4 chapters 4-7 */
COURSES.geography.units[3].ch.push(

{ t:"Forest Biomes", s:"Rainforests, temperate forests, and the taiga",
  sec:[
  ["What a biome is",[
    "A biome is a large region characterized by its climate and dominant vegetation, along with the animals adapted to it. Biomes are determined mainly by temperature and precipitation, so they correspond closely to climate zones. The main terrestrial biomes are tropical rainforest, tropical savanna, desert, temperate grassland, Mediterranean shrubland, temperate deciduous forest, boreal forest (taiga), and tundra, plus mountain zones.",
    "Forests cover about 31 percent of the world's land area. They store huge amounts of carbon, regulate rainfall, protect soils, provide timber and food, and harbor most land species."]],
  ["Tropical rainforests",[
    "Tropical rainforests grow near the Equator where it is hot and wet all year. The largest is the Amazon, covering about 5.5 million square kilometers across nine countries, mostly Brazil; others are in the Congo Basin and Southeast Asia, including Borneo, Sumatra, and New Guinea. Rainforests cover about 6 percent of the land but contain perhaps half or more of all land species.",
    "Rainforests have distinct layers: the forest floor, dark and humid; the understory; the dense canopy, 30–45 meters up, where most life is found; and emergent trees rising above it. Plants show adaptations such as buttress roots, drip-tip leaves that shed water, and epiphytes, plants such as orchids and bromeliads that grow on other plants. Nutrients cycle rapidly, so soils are poor once trees are removed."]],
  ["Deforestation",[
    "Tropical rainforests are being cleared for cattle ranching (the largest driver in the Amazon), soybean and palm oil plantations, logging, mining, roads, and small-scale farming. Indonesia and Malaysia have lost large areas to oil palm. Deforestation releases carbon, reduces rainfall regionally, destroys habitats, and displaces Indigenous peoples.",
    "Scientists warn that if enough of the Amazon is lost, parts of it could pass a tipping point and turn into drier savanna. Protection measures include parks, Indigenous land rights, which have proved effective in slowing deforestation, satellite monitoring, and certification of sustainable products."]],
  ["Temperate forests",[
    "Temperate deciduous forests grow in mid-latitude regions with warm summers, cold winters, and rain throughout the year, in the eastern United States, western and central Europe, and eastern China and Japan. Trees such as oak, maple, beech, and hickory shed their leaves in autumn to conserve water during winter, producing famous fall colors.",
    "These forests have fertile brown soils, which is why so many of them were cleared long ago for farming; much of Europe's original forest disappeared centuries ago. Temperate rainforests grow in very wet, mild coastal regions such as the Pacific Northwest, southern Chile, and New Zealand; coast redwoods in California are the tallest trees on Earth, exceeding 115 meters."]],
  ["The boreal forest",[
    "The boreal forest, or taiga, is the largest land biome, stretching in a belt across Canada, Alaska, Scandinavia, and Russia. Winters are long and bitterly cold, and summers short. It is dominated by coniferous evergreen trees such as spruce, fir, pine, and larch, whose needle-shaped leaves and conical shapes help them conserve water and shed snow.",
    "Soils are acidic and poor, and much of the ground is waterlogged or underlain by permafrost, with many bogs and lakes. The taiga stores enormous amounts of carbon in its trees, soils, and peat. It is home to moose, bears, wolves, lynx, and migrating birds, and faces threats from logging, wildfires, and warming."]],
  ["Mountains and vertical zonation",[
    "On mountains, climate changes with altitude much as it does with latitude, producing vertical zones of vegetation. Climbing a tropical mountain such as those in the Andes, one passes from rainforest through cloud forest, montane forest, alpine grassland (called páramo or puna in the Andes), and finally to bare rock and snow.",
    "The tree line marks the elevation above which trees cannot grow. Latin Americans traditionally describe altitude zones as tierra caliente (hot land), tierra templada (temperate land), tierra fría (cold land), and tierra helada (frozen land), each suited to different crops: bananas and sugar low, coffee in the middle, potatoes and grazing higher."]]
  ],
  terms:[["Biome","A large region defined by climate and dominant vegetation."],["Canopy","The dense upper layer of a forest."],["Epiphyte","A plant that grows on another plant without harming it."],["Deforestation","The permanent removal of forest."],["Deciduous","Trees that shed their leaves seasonally."],["Taiga","The boreal coniferous forest of the far north."],["Tree line","The elevation or latitude beyond which trees cannot grow."],["Vertical zonation","Changes in vegetation with altitude."]],
  w:"Forests store carbon, regulate climate and water, and hold most of Earth's land species, and their fate is one of the central environmental questions of our time.",
  src:["Biome","Tropical rainforest","Deforestation of the Amazon rainforest","Temperate deciduous forest","Taiga","Tree line","Altitudinal zonation"],
  q:[["What share of land species may live in tropical rainforests?","Perhaps half or more","About 5 percent","About 10 percent","Nearly all"],
     ["What is the largest driver of deforestation in the Amazon?","Cattle ranching","Logging","Mining","Urban growth"],
     ["Why are rainforest soils often poor?","Nutrients are stored mainly in the plants","They are too cold","They are frozen","They are too salty"],
     ["What is the largest land biome?","The boreal forest (taiga)","Tropical rainforest","Desert","Savanna"],
     ["Which are the tallest trees on Earth?","Coast redwoods","Giant sequoias","Douglas firs","Mountain ash"],
     ["What is the elevation beyond which trees cannot grow called?","The tree line","The snow line","The timber zone","The páramo"]]},

{ t:"Grasslands, Deserts, and Tundra", s:"Biomes of open land",
  sec:[
  ["Tropical savannas",[
    "Savannas are tropical grasslands with scattered trees, found where there is a long dry season and a wet season. They cover much of sub-Saharan Africa, as well as parts of Brazil (the Cerrado), Venezuela (the Llanos), India, and northern Australia. Trees such as the baobab and acacia are adapted to drought, and grasses survive by regrowing from their roots after fire.",
    "Fire, grazing, and seasonal rain maintain savannas. The African savannas support the world's greatest concentrations of large mammals: elephants, giraffes, zebras, wildebeest, and predators such as lions, leopards, and hyenas. The annual migration of over a million wildebeest across Tanzania's Serengeti and Kenya's Maasai Mara is one of the great wildlife spectacles."]],
  ["Temperate grasslands",[
    "Temperate grasslands grow in the interiors of continents where rainfall is too low for forests but enough for grasses. They are known as prairies in North America, steppes in Eurasia, pampas in Argentina and Uruguay, and veld in South Africa. Summers are hot, winters cold, and fires and grazing animals such as bison once maintained them.",
    "Their deep, fertile soils made temperate grasslands the world's breadbaskets. The prairies of North America and the steppes of Ukraine and Russia produce much of the world's wheat and corn. As a result, most original grassland has been plowed; the tallgrass prairie of the United States survives in only a few percent of its former area."]],
  ["Deserts",[
    "Deserts are regions that receive very little precipitation, generally less than 250 millimeters a year, and cover about one-third of the land surface. They form under subtropical high-pressure belts, as the Sahara, Arabian, and Australian deserts; in rain shadows; deep in continents, as the Gobi and Taklamakan; and along cold-current coasts, as the Atacama and Namib. The Sahara is the largest hot desert, about the size of the United States; Antarctica is technically the largest desert of all.",
    "Desert plants and animals have remarkable adaptations. Cacti store water in thick stems, and their spines are modified leaves; many plants have deep or wide roots and complete their life cycles quickly after rare rains. Animals are often nocturnal, and camels can go days without drinking. People have long lived in deserts through nomadic herding, oasis agriculture, and underground irrigation channels called qanats."]],
  ["Mediterranean shrublands",[
    "In regions with Mediterranean climates, hot dry summers favor evergreen shrubs and small trees with hard, waxy leaves that resist water loss. These shrublands are called maquis or garrigue around the Mediterranean, chaparral in California, matorral in Chile, fynbos in South Africa, and mallee in Australia.",
    "Although they cover only a small share of the Earth, these regions are very rich in plant species; South Africa's tiny Cape Floristic Region has about 9,000 plant species, most found nowhere else. Many plants are adapted to fire, with seeds that germinate only after burning."]],
  ["Tundra",[
    "The tundra lies north of the boreal forest across the Arctic coasts of North America, Europe, and Asia, and on high mountains as alpine tundra. Winters are long and dark, summers short and cool, and the ground beneath the surface is permafrost. Only the top layer thaws in summer, creating boggy ground dotted with ponds.",
    "Trees cannot grow, so vegetation consists of mosses, lichens, sedges, grasses, and dwarf shrubs. In summer, the tundra bursts into life with flowers, insects, and millions of migrating birds. Caribou (called reindeer in Eurasia), musk oxen, Arctic foxes, and lemmings live there, and the Arctic is home to Indigenous peoples such as the Inuit and Sámi. The tundra is warming rapidly, and thawing permafrost may release large amounts of carbon."]],
  ["Biomes and people",[
    "Humans have transformed nearly every biome. Today, roughly half of the world's habitable land is used for agriculture, mostly for grazing livestock and growing animal feed. Grasslands have been plowed, forests cleared, and deserts expanded by overgrazing.",
    "Recognizing biomes helps explain how people live: herding on dry grasslands, grain farming on temperate prairies, plantation agriculture in the tropics, and reindeer herding in the tundra. It also helps identify which ecosystems most need protection."]]
  ],
  terms:[["Savanna","Tropical grassland with scattered trees."],["Steppe","Temperate grassland of Eurasia."],["Prairie","Temperate grassland of North America."],["Pampas","Temperate grassland of Argentina and Uruguay."],["Desert","A region with very little precipitation."],["Chaparral","Mediterranean shrubland in California."],["Tundra","Treeless Arctic or alpine land with permafrost."]],
  w:"Grasslands feed the world, deserts cover a third of the land, and the tundra is changing fastest of all, so knowing these biomes explains where food is grown and how life adapts.",
  src:["Savanna","Grassland","Prairie","Desert","Sahara","Mediterranean forests, woodlands, and scrub","Tundra"],
  q:[["What is the name of tropical grassland with scattered trees?","Savanna","Steppe","Tundra","Chaparral"],
     ["What are the temperate grasslands of Argentina called?","The pampas","The llanos","The veld","The cerrado"],
     ["What share of the land surface is desert?","About one-third","About one-tenth","About half","About 5 percent"],
     ["Which is the largest hot desert?","The Sahara","The Arabian","The Gobi","The Kalahari"],
     ["What is South Africa's Mediterranean shrubland called?","Fynbos","Maquis","Matorral","Mallee"],
     ["What lies beneath the surface of the tundra?","Permafrost","Laterite","Limestone","Groundwater lakes"]]},

{ t:"Ecosystems and Biodiversity", s:"How living systems work and why diversity matters",
  sec:[
  ["Ecosystems",[
    "An ecosystem is a community of living organisms interacting with each other and with their physical environment. Ecosystems can be as small as a pond or as large as an ocean. The term was coined by the British ecologist Arthur Tansley in 1935.",
    "Every ecosystem has biotic (living) and abiotic (non-living) components, such as sunlight, temperature, water, soil, and nutrients. A habitat is the place where an organism lives; its niche is its role in the ecosystem, including what it eats and how it interacts with others."]],
  ["Energy flow and food webs",[
    "Energy enters most ecosystems as sunlight, captured by producers, plants, algae, and some bacteria, through photosynthesis. Primary consumers (herbivores) eat producers; secondary and tertiary consumers (carnivores) eat other animals. Decomposers such as fungi and bacteria break down dead matter and return nutrients to the soil.",
    "These feeding relationships form food chains and interconnected food webs. At each step, only about 10 percent of energy passes to the next level; the rest is used or lost as heat. This is why there are far fewer top predators than herbivores, and why producing meat requires much more land than producing plant food."]],
  ["Nutrient cycles and succession",[
    "Unlike energy, matter cycles. In the carbon cycle, carbon moves between the atmosphere, plants, animals, soils, oceans, and rocks; burning fossil fuels moves carbon from long-term storage into the air. In the nitrogen cycle, bacteria convert atmospheric nitrogen into forms plants can use.",
    "Ecosystems change over time through ecological succession. Primary succession begins on bare rock, such as new volcanic land, where lichens and mosses colonize first, slowly building soil for grasses, shrubs, and eventually trees. Secondary succession occurs after a disturbance such as fire, where soil remains, as when an abandoned field reverts to forest."]],
  ["What biodiversity is",[
    "Biodiversity is the variety of life at three levels: genetic diversity within species, species diversity, and ecosystem diversity. About 2 million species have been scientifically described, but estimates of the total range from about 8 million to many more, most of them insects and microorganisms.",
    "Biodiversity is concentrated in the tropics and in biodiversity hotspots, regions with many endemic species (found nowhere else) that are also under severe threat, such as Madagascar, the tropical Andes, Sundaland, and the Atlantic Forest of Brazil. Islands such as Madagascar and the Galápagos, where Charles Darwin made observations that helped inspire his theory of evolution, often have unique species."]],
  ["The biodiversity crisis",[
    "Species are disappearing at rates far above natural background levels, leading many scientists to speak of a sixth mass extinction. A 2019 global assessment by the U.N. biodiversity panel estimated that about a million species face extinction. Wildlife populations monitored by scientists have declined steeply on average since 1970.",
    "The main drivers are habitat loss from agriculture and development, overexploitation through hunting and fishing, pollution, invasive species, such as rats on islands and the brown tree snake on Guam, and climate change. Losses matter because ecosystems provide services such as pollination, clean water, fertile soil, flood protection, fisheries, and medicines."]],
  ["Conservation",[
    "Conservation strategies include protected areas, beginning with Yellowstone, established in 1872 as the world's first national park; wildlife corridors connecting habitats; restoration of damaged ecosystems; laws against trade in endangered species, such as the CITES treaty (1973); and captive breeding and reintroduction, which saved species such as the California condor and the Arabian oryx.",
    "The International Union for Conservation of Nature (IUCN) maintains the Red List of threatened species. In 2022, the world's governments agreed on the Kunming-Montreal Global Biodiversity Framework, including a target to protect 30 percent of land and sea by 2030. Successful conservation increasingly works with local and Indigenous communities."]]
  ],
  terms:[["Ecosystem","A community of organisms and their physical environment."],["Producer","An organism that makes food by photosynthesis."],["Food web","The interconnected feeding relationships in an ecosystem."],["Ecological succession","The gradual change of an ecosystem over time."],["Biodiversity","The variety of life at genetic, species, and ecosystem levels."],["Endemic species","A species found in only one place."],["Biodiversity hotspot","A region rich in endemic species and under threat."],["IUCN Red List","The global inventory of species' conservation status."]],
  w:"Ecosystems sustain all life, including ours, and protecting biodiversity is essential for food, water, health, and a stable planet.",
  src:["Ecosystem","Food web","Ecological succession","Biodiversity","Biodiversity hotspot","Holocene extinction","IUCN Red List"],
  q:[["Who coined the term ecosystem?","Arthur Tansley","Charles Darwin","Rachel Carson","Ernst Haeckel"],
     ["About how much energy passes from one feeding level to the next?","About 10 percent","About 50 percent","About 90 percent","About 1 percent"],
     ["What is succession that begins on bare rock called?","Primary succession","Secondary succession","Climax succession","Pioneer decay"],
     ["What is a species found in only one place called?","Endemic","Invasive","Keystone","Native"],
     ["About how many species did a 2019 U.N. assessment say face extinction?","About a million","About a thousand","About 100 million","About ten thousand"],
     ["What was the world's first national park?","Yellowstone","Yosemite","Kruger","Banff"]]},

{ t:"Natural Hazards and Disasters", s:"Risk, vulnerability, and resilience",
  sec:[
  ["Hazard, risk, and disaster",[
    "A natural hazard is a natural event that threatens people and property, such as an earthquake, flood, drought, or storm. A disaster occurs when a hazard seriously disrupts a community, causing deaths, damage, or economic loss beyond its ability to cope. A massive earthquake in an empty desert is a hazard but not a disaster.",
    "Geographers express risk as a combination of the hazard, people's exposure to it, and their vulnerability, their susceptibility to harm, which depends on factors such as poverty, building quality, health, governance, and preparedness. Capacity to cope reduces risk."]],
  ["Types of hazards",[
    "Geophysical hazards include earthquakes, volcanic eruptions, tsunamis, and landslides. Hydrological hazards include floods; meteorological hazards include tropical cyclones, tornadoes, blizzards, and heat waves; climatological hazards include droughts and wildfires. Biological hazards include epidemics and pandemics, and locust swarms.",
    "Floods affect more people than any other hazard, while droughts and famines have historically been among the deadliest. Heat waves are often underestimated: the European heat wave of 2003 is estimated to have killed around 70,000 people."]],
  ["Why the same hazard has different effects",[
    "Comparing disasters shows the importance of vulnerability. The magnitude 7.0 Haiti earthquake of 2010 killed perhaps 100,000 to over 200,000 people, the estimates being widely disputed, in one of the poorest countries in the Americas with weak building standards. The magnitude 8.8 Chile earthquake just weeks later, far stronger, killed about 500 people, thanks to strict building codes and preparedness.",
    "Wealthier countries tend to suffer greater economic losses but fewer deaths, while poorer countries suffer more deaths. Within countries, the poor, elderly, disabled, and marginalized are typically most vulnerable, as the effects of Hurricane Katrina in New Orleans showed."]],
  ["The disaster cycle",[
    "Disaster management is often described as a cycle. Mitigation reduces risk in advance, through land-use planning, building codes, levees, and reforestation. Preparedness includes warning systems, evacuation plans, drills, and stockpiles of supplies.",
    "Response covers the immediate rescue, medical care, shelter, and relief after a disaster. Recovery involves rebuilding, ideally “building back better” to reduce future risk. International frameworks such as the Sendai Framework for Disaster Risk Reduction (2015) guide countries' efforts."]],
  ["Success stories",[
    "Deaths from natural disasters have fallen dramatically over the past century, even as population has grown, thanks to better forecasting, warning systems, building standards, and humanitarian aid. Bangladesh, where cyclones once killed hundreds of thousands, now evacuates millions of people to cyclone shelters, and death tolls have fallen sharply.",
    "Japan's earthquake engineering and early warning systems, which can halt bullet trains seconds before shaking arrives, and the Pacific Tsunami Warning Center, established in 1949, show how knowledge saves lives. The Indian Ocean had no such warning system in 2004; one was created afterward."]],
  ["Hazards in a changing world",[
    "Disaster losses are rising because more people and property are located in hazardous places, such as coasts, floodplains, and the edges of wildland where fires spread, and because climate change is intensifying heat waves, heavy rains, droughts, and wildfires.",
    "Rapid urbanization in developing countries often concentrates poor people in informal settlements on steep slopes or floodplains. Reducing disaster risk is therefore closely linked to sustainable development, good governance, and fighting poverty."]]
  ],
  terms:[["Natural hazard","A natural event that threatens people and property."],["Disaster","A hazard event that overwhelms a community's ability to cope."],["Vulnerability","Susceptibility to harm from a hazard."],["Exposure","The presence of people and assets in hazard zones."],["Mitigation","Actions taken in advance to reduce disaster risk."],["Resilience","The ability to resist, absorb, and recover from hazards."],["Sendai Framework","The 2015 global framework for disaster risk reduction."]],
  w:"Natural hazards become disasters through human vulnerability, so understanding risk helps explain why disasters hit some places harder and how lives can be saved.",
  src:["Natural hazard","Disaster","Vulnerability","2010 Haiti earthquake","2010 Chile earthquake","Emergency management","Sendai Framework for Disaster Risk Reduction"],
  q:[["What turns a natural hazard into a disaster?","Serious disruption of a community beyond its ability to cope","Any earthquake over magnitude 5","Any storm","The involvement of the military"],
     ["Which hazard affects the most people?","Floods","Volcanoes","Tsunamis","Tornadoes"],
     ["Why did the 2010 Chile earthquake kill far fewer than the Haiti earthquake?","Strict building codes and preparedness","It was much weaker","It struck at sea","It happened at night"],
     ["Which phase of the disaster cycle includes warning systems and drills?","Preparedness","Response","Recovery","Relief"],
     ["Which country uses cyclone shelters to evacuate millions?","Bangladesh","Haiti","Chile","Iceland"],
     ["Which 2015 framework guides disaster risk reduction?","The Sendai Framework","The Paris Agreement","The Hyogo Protocol","The Kyoto Framework"]]}

);


/* ---- from geo-07.js ---- */
/* GEOGRAPHY FOUNDATIONS, part 7: Unit 5 Human Geography, chapters 1-5 */
COURSES.geography.units.push({ t:"Human Geography", ch:[

{ t:"Where People Live", s:"Population distribution and density",
  sec:[
  ["Eight billion people",[
    "The world's population passed 8 billion in November 2022, according to the United Nations. For most of human history population grew very slowly; it reached 1 billion only around 1800. It then accelerated: 2 billion by 1927, 3 billion by 1960, 4 billion by 1974, 5 billion by 1987, 6 billion by 1999, and 7 billion by 2011.",
    "The two most populous countries, India and China, each have over 1.4 billion people, together over a third of humanity; India overtook China in 2023. They are followed by the United States, Indonesia, Pakistan, Nigeria, Brazil, and Bangladesh. Asia is home to about 60 percent of the world's people."]],
  ["Distribution",[
    "Population is very unevenly distributed. About 90 percent of people live in the Northern Hemisphere, and most live on a small share of the land. The four great clusters are East Asia (China, Japan, Korea), South Asia (India, Pakistan, Bangladesh), Europe, and, to a lesser extent, the northeastern United States and southeastern Canada. Other notable concentrations include the Nile Valley, West Africa, the island of Java, and the region around the African Great Lakes.",
    "People are concentrated on fertile river plains and deltas, along coasts, and in temperate and moist tropical climates. Sparsely populated regions include deserts, high mountains, dense rainforests, and cold polar lands. The Egyptian population, for example, is crowded into the narrow Nile Valley and Delta, about 5 percent of the country's area."]],
  ["Density",[
    "Arithmetic density is the number of people per unit of land area. Some small territories, such as Monaco, Singapore, and Hong Kong, have extremely high densities; among larger countries, Bangladesh is one of the most densely populated, with over 1,000 people per square kilometer. Mongolia, Australia, Canada, and Namibia are among the least dense.",
    "Physiological density, the number of people per unit of arable land, better shows pressure on farmland; Egypt's is very high because so little of its land can be farmed. Agricultural density, the number of farmers per unit of arable land, tends to be high in poorer countries where farming is less mechanized."]],
  ["The ecumene",[
    "The ecumene is the portion of the Earth's surface permanently inhabited by humans. It has expanded over time as people have adapted to more environments, through irrigation, air conditioning, heating, and technology.",
    "Still, large areas remain sparsely settled. About three-quarters of Canada's population lives within about 160 kilometers of the U.S. border, and most Australians live along the southeastern and southwestern coasts, leaving the vast interior, the Outback, thinly populated."]],
  ["Censuses and data",[
    "Population data come mainly from censuses, counts of the population carried out by governments, typically every ten years. The United States has held a census every ten years since 1790, as required by its Constitution. Censuses also gather data on age, sex, housing, education, and more, and are used to allocate political representation and resources.",
    "Other sources include vital registration of births and deaths, sample surveys, and estimates by the United Nations and World Bank. In poorer countries, data can be incomplete, and censuses can be politically controversial, as in Nigeria and Lebanon, where population counts affect the balance of power."]],
  ["Thinking about population",[
    "In 1798 the English economist Thomas Malthus argued that population tends to grow geometrically while food supply grows only arithmetically, so that population growth would inevitably be checked by famine, disease, and war. For two centuries, however, technological advances in agriculture have allowed food production to keep ahead of population growth.",
    "Debates continue between those who fear overpopulation and resource exhaustion, often called neo-Malthusians, and those who emphasize human ingenuity and point out that consumption by wealthy populations affects the environment more than numbers alone. The United Nations projects that world population will peak at roughly 10.3 billion in the 2080s and then slowly decline."]]
  ],
  terms:[["Population distribution","The pattern of where people live."],["Arithmetic density","People per unit of land area."],["Physiological density","People per unit of arable land."],["Ecumene","The permanently inhabited portion of the Earth."],["Census","An official count of a population."],["Malthusian theory","The idea that population growth outstrips food supply."]],
  w:"Knowing where people live and why explains patterns of cities, agriculture, and pressure on resources across the world.",
  src:["World population","Population density","Ecumene","Census","Thomas Robert Malthus","List of countries and dependencies by population"],
  q:[["When did world population pass 8 billion?","2022","2011","1999","2030"],
     ["Which country became the world's most populous in 2023?","India","China","The United States","Indonesia"],
     ["About what share of the world's people live in Asia?","About 60 percent","About 30 percent","About 80 percent","About 45 percent"],
     ["What does physiological density measure?","People per unit of arable land","People per unit of land","Farmers per unit of farmland","People per city"],
     ["Who argued that population would outgrow food supply?","Thomas Malthus","Adam Smith","Charles Darwin","David Ricardo"],
     ["Roughly when do U.N. projections show world population peaking?","The 2080s","The 2030s","The 2150s","It already peaked"]]},

{ t:"Population Change", s:"Births, deaths, and the demographic transition",
  sec:[
  ["Measuring change",[
    "Population changes through births, deaths, and migration. The crude birth rate is the number of births per 1,000 people per year; the crude death rate is deaths per 1,000. The difference between them is the rate of natural increase, usually expressed as a percentage. A growth rate of 2 percent a year doubles a population in about 35 years.",
    "The total fertility rate (TFR) is the average number of children a woman would have in her lifetime at current rates. A TFR of about 2.1 is called replacement level, enough to keep a population stable in the long run without migration. The world TFR fell from about 5 in 1950 to about 2.3 in the early 2020s."]],
  ["The demographic transition",[
    "The demographic transition model describes how populations change as societies develop. In Stage 1, birth and death rates are both high, and population grows slowly, as in most of human history. In Stage 2, death rates fall sharply thanks to better food, sanitation, and medicine, while birth rates stay high, so population grows rapidly; Europe entered this stage in the 18th and 19th centuries and much of Africa in the 20th.",
    "In Stage 3, birth rates fall as societies urbanize, children become more expensive than helpful, women gain education and work opportunities, and contraception spreads; growth slows. In Stage 4, both rates are low and population is stable. Some suggest a Stage 5, in which birth rates fall below death rates and population declines, as is happening in Japan, Italy, South Korea, and much of Eastern Europe."]],
  ["Population pyramids",[
    "A population pyramid is a graph showing the age and sex structure of a population, with males on one side and females on the other. A wide base and narrow top, like Niger's, indicates a young, rapidly growing population with high fertility. A column or inverted shape, like Japan's, shows an aging population with low fertility.",
    "Pyramids reveal history: bulges for baby booms, such as the American baby boom of 1946–1964, and dents for wars, famines, or policies such as China's one-child policy. The dependency ratio compares the number of children and elderly to the working-age population."]],
  ["High fertility and youthful populations",[
    "Sub-Saharan Africa has the world's highest fertility rates, with women in Niger, Chad, and Somalia averaging around six children. Africa's population, about 1.5 billion in the 2020s, is projected to nearly double by 2050; Nigeria may become one of the most populous countries in the world. About 40 percent of Africans are under 15.",
    "A large young population can be an asset, a demographic dividend, if young people find education and jobs, as happened in East Asia from the 1960s to the 1990s. Without jobs, it can lead to unemployment and instability. Girls' education and access to family planning are the strongest factors in reducing fertility."]],
  ["Aging and shrinking populations",[
    "Much of the world now has fertility below replacement level, including East Asia, Europe, North America, and much of Latin America. South Korea's TFR has fallen below 1, the lowest in the world. Japan's population has been shrinking since around 2010, and about 29 percent of Japanese are 65 or older.",
    "Aging populations face labor shortages, rising pension and healthcare costs, and fewer workers per retiree. Responses include encouraging births through childcare and parental leave, raising retirement ages, automation, and immigration. Life expectancy at birth worldwide rose from about 46 years in 1950 to over 73 in the 2020s."]],
  ["The epidemiological transition",[
    "Accompanying the demographic transition is the epidemiological transition, a shift in the main causes of death. In early stages, infectious diseases, famine, and high infant mortality dominate. As societies develop, deaths from infections fall, and chronic diseases of older age, such as heart disease, cancer, and stroke, become the leading causes.",
    "Infant mortality, the number of deaths of infants under one per 1,000 live births, is a powerful indicator of a country's health and development. It has fallen dramatically worldwide, but remains much higher in the poorest countries. Pandemics such as HIV/AIDS, which sharply reduced life expectancy in southern Africa in the 1990s and 2000s, and COVID-19 show that progress can be reversed."]]
  ],
  terms:[["Crude birth rate","Births per 1,000 people per year."],["Natural increase","Birth rate minus death rate."],["Total fertility rate","The average number of children per woman."],["Replacement level","A fertility rate of about 2.1."],["Demographic transition","The shift from high to low birth and death rates."],["Population pyramid","A graph of a population's age and sex structure."],["Dependency ratio","Children and elderly compared with working-age people."],["Infant mortality rate","Infant deaths per 1,000 live births."]],
  w:"Population change shapes economies, politics, and societies, from Africa's youthful boom to the aging of Europe and East Asia.",
  src:["Demographic transition","Total fertility rate","Population pyramid","Demographic dividend","Population ageing","Epidemiological transition"],
  q:[["What total fertility rate is called replacement level?","About 2.1","About 1.0","About 3.0","About 4.5"],
     ["In which stage of the demographic transition does population grow fastest?","Stage 2","Stage 1","Stage 4","Stage 5"],
     ["What does a population pyramid with a wide base indicate?","A young, rapidly growing population","An aging population","A shrinking population","High life expectancy"],
     ["Which region has the highest fertility rates?","Sub-Saharan Africa","South Asia","Latin America","Eastern Europe"],
     ["Which country has the world's lowest fertility rate, below 1?","South Korea","Japan","Italy","China"],
     ["What is the strongest factor in reducing fertility?","Girls' education and access to family planning","Urban pollution","Higher taxes","Religious change"]]},

{ t:"Migration", s:"Why and how people move",
  sec:[
  ["Types of migration",[
    "Migration is the permanent or semi-permanent movement of people from one place to another. International migration crosses national borders; internal migration occurs within a country, most often from rural areas to cities. Emigration is leaving a country; immigration is arriving. Net migration is the difference.",
    "Migration may be voluntary, when people choose to move for work, family, or opportunity, or forced, when people flee war, persecution, or disaster or are moved by force, as in the Atlantic slave trade. About 280 million people, roughly 3.6 percent of the world's population, lived outside their country of birth in 2020."]],
  ["Push and pull factors",[
    "Migration is often explained by push factors, which drive people from a place, such as poverty, unemployment, conflict, persecution, and environmental disasters, and pull factors, which attract them to another, such as jobs, higher wages, safety, freedom, and family. Intervening obstacles, such as distance, cost, borders, and immigration laws, affect whether people move.",
    "In the 1880s the geographer Ernst Ravenstein proposed “laws of migration,” including that most migrants move only a short distance, that migration often proceeds in steps, and that each migration stream produces a counter-stream. Chain migration occurs when migrants follow relatives and friends who moved before them, creating communities such as Chinatowns and Little Italys."]],
  ["Major migration flows",[
    "The largest international flows today include movements from Latin America to the United States, from South Asia and Southeast Asia to the oil-rich Gulf states, where migrants make up the majority of the population in countries such as the United Arab Emirates and Qatar, and from Africa, the Middle East, and Eastern Europe to Western Europe. The United States has the largest immigrant population of any country.",
    "Historic migrations reshaped the world: the movement of some 50 to 60 million Europeans to the Americas, Australia, and elsewhere between 1815 and 1930; the forced transport of over 12 million Africans across the Atlantic; and the movement of millions of Chinese and Indian laborers across the British Empire and beyond."]],
  ["Refugees and displacement",[
    "A refugee, under the 1951 Refugee Convention, is someone who has fled their country because of a well-founded fear of persecution for reasons of race, religion, nationality, membership of a social group, or political opinion. Internally displaced persons (IDPs) are forced to flee but remain within their own country. Asylum seekers are people seeking refugee protection whose claims have not yet been decided.",
    "By the mid-2020s, more than 120 million people worldwide had been forcibly displaced, the highest number on record, driven by conflicts in Syria, Ukraine, Afghanistan, Sudan, South Sudan, Myanmar, and elsewhere. Most refugees live in neighboring developing countries; Turkey, Iran, Colombia, Germany, and Pakistan have hosted some of the largest numbers. The U.N. High Commissioner for Refugees (UNHCR) leads international protection efforts."]],
  ["Internal migration and urbanization",[
    "The largest migration in history has been internal: the movement of hundreds of millions of rural Chinese to cities since the 1980s, largely to coastal factory regions. China's hukou (household registration) system has limited migrants' access to urban services.",
    "In the United States, the Great Migration saw about 6 million African Americans move from the rural South to Northern and Western cities between about 1910 and 1970. More recently, Americans have moved from the Northeast and Midwest to the Sun Belt states of the South and West."]],
  ["Effects of migration",[
    "Migration affects both sending and receiving places. Migrants send money home, called remittances, which exceed foreign aid many times over and are a major source of income for countries such as India, Mexico, the Philippines, and Egypt. Sending countries may also lose skilled workers, a brain drain, as when doctors and nurses emigrate.",
    "Receiving countries gain workers, entrepreneurs, and cultural diversity, which can be especially important for aging populations, but migration can also generate political controversy over jobs, wages, public services, culture, and integration. Climate change is expected to become an increasingly important driver of migration in coming decades."]]
  ],
  terms:[["Emigration and immigration","Leaving a country vs. arriving in one."],["Push and pull factors","Forces driving people from or attracting them to places."],["Chain migration","Migration following earlier migrants from the same place."],["Refugee","A person who flees their country due to persecution."],["Internally displaced person","Someone forced from home who remains in their country."],["Remittances","Money sent home by migrants."],["Brain drain","The emigration of highly skilled people."]],
  w:"Migration has built nations, reshaped cultures, and transformed economies, and it remains one of the most important and contested issues in the world today.",
  src:["Human migration","Push and pull factors","Ravenstein's laws of migration","Refugee","Remittance","Great Migration (African American)","Brain drain"],
  q:[["Roughly how many people lived outside their country of birth in 2020?","About 280 million","About 28 million","About 1 billion","About 50 million"],
     ["What are factors that drive people away from a place called?","Push factors","Pull factors","Intervening obstacles","Remittances"],
     ["Who proposed laws of migration in the 1880s?","Ernst Ravenstein","Thomas Malthus","Friedrich Ratzel","Walter Christaller"],
     ["Which treaty defines a refugee?","The 1951 Refugee Convention","The Geneva Convention of 1864","The Universal Declaration of Human Rights","The Schengen Agreement"],
     ["What is money sent home by migrants called?","Remittances","Foreign aid","Tariffs","Dividends"],
     ["What was the movement of African Americans from the South to Northern cities called?","The Great Migration","The Exodus","The Long March","The Dust Bowl migration"]]},

{ t:"Urbanization", s:"The rise of an urban world",
  sec:[
  ["An urban planet",[
    "Urbanization is the increase in the share of a population living in cities and towns. In 1800, only about 3 percent of the world's people lived in cities; in 1950, about 30 percent; and in 2007, for the first time, more than half. By the mid-2020s the share was about 57 percent, and the U.N. projects about 68 percent by 2050.",
    "Developed regions are highly urbanized: about 80 percent or more of people in North America, Western Europe, Japan, Australia, and much of Latin America live in urban areas. Africa and South Asia are less urbanized but are urbanizing fastest, and nearly all future urban growth will occur in developing countries."]],
  ["Why cities grow",[
    "Cities grow through natural increase and, above all, through migration from the countryside, driven by the prospect of jobs, higher wages, education, and services, and by rural push factors such as poverty, mechanization of agriculture, and lack of land.",
    "Cities offer economies of agglomeration: when businesses, workers, and ideas cluster together, productivity rises, which is why cities generate most of the world's economic output. They also allow efficient provision of services such as schools, hospitals, and transport."]],
  ["Megacities and urban hierarchies",[
    "A megacity is an urban area with more than 10 million people. In 1950 there were only two, New York and Tokyo; by the 2020s there were more than 30. Greater Tokyo, with about 37 million people, has long been the largest urban area; others include Delhi, Shanghai, Dhaka, São Paulo, Mexico City, Cairo, Beijing, Mumbai, Osaka, Lagos, and Karachi, with rankings varying by definition.",
    "A primate city is one that is far larger than the country's second city and dominates its economy and culture, such as Bangkok, Lima, Paris, and London. The rank-size rule suggests that in some countries the second-largest city is about half the size of the largest, the third about a third, and so on, as roughly in the United States. Central place theory, developed by Walter Christaller in 1933, explains how settlements of different sizes are spaced to provide goods and services to surrounding areas."]],
  ["Global cities",[
    "Global (world) cities are command centers of the world economy, home to corporate headquarters, financial markets, international organizations, and cultural influence. The sociologist Saskia Sassen popularized the term in 1991, highlighting New York, London, and Tokyo. Others include Paris, Singapore, Hong Kong, Shanghai, and Dubai.",
    "Global cities are linked more closely to one another than to their own hinterlands, through flows of money, people, and information."]],
  ["Informal settlements",[
    "Rapid urban growth in developing countries often outpaces the supply of housing, jobs, and infrastructure. About a billion people live in slums or informal settlements, areas lacking secure tenure, durable housing, clean water, or sanitation, such as the favelas of Rio de Janeiro, Dharavi in Mumbai, Kibera in Nairobi, and Orangi Town in Karachi.",
    "Many residents work in the informal economy, such as street vending and casual labor, without legal protections. Informal settlements are also places of enterprise and community. Successful approaches include upgrading settlements with water, sanitation, and legal title rather than demolishing them."]],
  ["Suburbs, sprawl, and sustainable cities",[
    "In wealthier countries, especially the United States after World War II, cars, highways, and cheap mortgages fueled suburbanization, the growth of residential areas outside city centers. Low-density urban sprawl consumes land, increases car dependence, and raises energy use. Edge cities, clusters of offices and malls at highway junctions, emerged.",
    "Urban planners now promote smart growth and sustainable cities, with mixed land use, public transit, walkable neighborhoods, green spaces, and energy-efficient buildings. Cities such as Copenhagen, with its cycling culture, Curitiba in Brazil, a pioneer of bus rapid transit, and Singapore, with its dense planning and greenery, are often cited as models."]]
  ],
  terms:[["Urbanization","The growth in the share of people living in cities."],["Agglomeration","The clustering of economic activity in cities."],["Megacity","An urban area of more than 10 million people."],["Primate city","A city far larger than any other in its country."],["Central place theory","Christaller's theory of settlement size and spacing."],["Global city","A city that is a command center of the world economy."],["Informal settlement","An area of unplanned housing lacking services and secure tenure."],["Urban sprawl","Low-density spread of cities into surrounding land."]],
  w:"Most of humanity now lives in cities, and how cities grow will shape the economy, environment, and quality of life for billions.",
  src:["Urbanization","Megacity","Primate city","Central place theory","Global city","Slum","Urban sprawl"],
  q:[["In what year did more than half the world's people first live in cities?","2007","1950","1990","2020"],
     ["What is an urban area of more than 10 million people called?","A megacity","A primate city","A global city","A conurbation"],
     ["Which urban area has long been the world's largest?","Greater Tokyo","Delhi","Shanghai","New York"],
     ["Who developed central place theory?","Walter Christaller","Saskia Sassen","Ernest Burgess","Jane Jacobs"],
     ["What are informal settlements in Rio de Janeiro called?","Favelas","Barrios","Townships","Bidonvilles"],
     ["Which Brazilian city pioneered bus rapid transit?","Curitiba","São Paulo","Brasília","Recife"]]},

{ t:"Inside Cities", s:"Urban structure, land use, and urban life",
  sec:[
  ["Why cities are where they are",[
    "Cities grow at favorable sites and situations: river crossings and confluences, such as Pittsburgh and Khartoum; natural harbors, such as Sydney, Rio de Janeiro, and New York; defensible hills, such as Athens and Edinburgh; oases and crossroads of trade routes; and points where goods must change from one mode of transport to another, called break-of-bulk points.",
    "Many capitals were deliberately planned, such as Washington, D.C., designed by Pierre L'Enfant in 1791; Canberra; Brasília, built in the late 1950s to develop Brazil's interior; and Abuja, which replaced Lagos as Nigeria's capital in 1991."]],
  ["Models of urban structure",[
    "Geographers have proposed models of how land use is arranged in cities. The concentric zone model, developed by Ernest Burgess for Chicago in the 1920s, describes rings around a central business district (CBD): a zone in transition with factories and poor housing, then working-class housing, then middle-class and commuter zones.",
    "Homer Hoyt's sector model (1939) proposed that cities grow in wedges along transport routes, with high-income sectors extending outward in one direction. Chauncy Harris and Edward Ullman's multiple nuclei model (1945) recognized that large cities have several centers, such as airports, universities, and suburban business districts. Models for Latin American, African, and Southeast Asian cities show different patterns, such as wealthy spines extending from the center and peripheral informal settlements."]],
  ["The central business district",[
    "The CBD is typically the center of commerce, finance, government, and entertainment, with the highest land values, which is why buildings there rise upward. The bid-rent theory explains that land users compete for central locations: businesses that gain most from accessibility, such as offices and shops, can pay the highest rents, while land uses needing more space locate farther out.",
    "Skyscrapers emerged in Chicago and New York in the late 19th century with steel frames and elevators. Today the tallest building is the Burj Khalifa in Dubai, at 828 meters, completed in 2010."]],
  ["Urban change",[
    "Cities constantly change. Deindustrialization left many former factory cities, such as Detroit, with declining populations and abandoned buildings, a phenomenon called urban decay. Urban renewal programs in the mid-20th century often demolished poor neighborhoods for highways and new housing, displacing communities.",
    "Gentrification is the process by which wealthier residents move into lower-income neighborhoods, renovating housing and raising property values; it brings investment but can displace long-time residents. Waterfront redevelopments, such as London's Docklands and Baltimore's Inner Harbor, have transformed former industrial areas."]],
  ["Segregation and inequality",[
    "Cities often display stark spatial inequalities. Residential segregation by race, ethnicity, or income can result from discrimination, housing markets, and policy. In the United States, the practice of redlining in the 1930s marked minority neighborhoods as risky for mortgage lending, with effects that persist; under apartheid, South African cities were legally divided by race.",
    "Gated communities in many cities wall off the wealthy, while poor neighborhoods may lack services. Geographers study access to food (“food deserts”), transport, parks, and jobs, and how environmental hazards such as pollution are often concentrated in poorer areas, an issue known as environmental justice."]],
  ["Smart and resilient cities",[
    "Twenty-first-century cities face challenges of housing affordability, congestion, pollution, and climate change. Many coastal cities, from Jakarta, which is sinking so fast that Indonesia is building a new capital, Nusantara, on Borneo, to Miami and Shanghai, face rising seas and flooding.",
    "Cities respond with green infrastructure such as parks and wetlands that absorb floodwater, urban trees to cool streets, transit investment, and “smart city” technologies that use data to manage traffic and energy. The urbanist Jane Jacobs's The Death and Life of Great American Cities (1961) remains influential in arguing for lively, mixed-use, walkable neighborhoods."]]
  ],
  terms:[["Break-of-bulk point","A place where goods change from one transport mode to another."],["CBD","The central business district."],["Concentric zone model","Burgess's model of cities as rings around the center."],["Sector model","Hoyt's model of cities growing in wedges."],["Bid-rent theory","The idea that land value and use change with distance from the center."],["Gentrification","The movement of wealthier people into poorer neighborhoods."],["Redlining","Denying mortgage lending to minority neighborhoods."]],
  w:"Understanding how cities are structured explains urban land values, neighborhoods, inequality, and the challenges of making cities livable.",
  src:["Concentric zone model","Sector model","Multiple nuclei model","Central business district","Bid rent theory","Gentrification","Redlining"],
  q:[["Who designed Washington, D.C.?","Pierre L'Enfant","Lúcio Costa","Walter Burley Griffin","Baron Haussmann"],
     ["Which model describes cities as rings around the center?","The concentric zone model","The sector model","The multiple nuclei model","Central place theory"],
     ["Who developed the sector model?","Homer Hoyt","Ernest Burgess","Chauncy Harris","Walter Christaller"],
     ["What is the tallest building in the world?","The Burj Khalifa","Shanghai Tower","One World Trade Center","Taipei 101"],
     ["What is the movement of wealthier residents into poorer neighborhoods called?","Gentrification","Suburbanization","Redlining","Urban renewal"],
     ["Who wrote The Death and Life of Great American Cities?","Jane Jacobs","Robert Moses","Lewis Mumford","Saskia Sassen"]]}

]});


/* ---- from geo-08.js ---- */
/* GEOGRAPHY FOUNDATIONS, part 8: Unit 5 chapters 6-10 */
COURSES.geography.units[4].ch.push(

{ t:"Culture and Its Geography", s:"How ways of life spread and differ across space",
  sec:[
  ["What is culture?",[
    "Culture is the shared way of life of a group of people: their beliefs, values, customs, language, religion, food, dress, music, architecture, and technology. Cultural geography studies how culture varies from place to place, how it spreads, and how it shapes and is shaped by landscapes.",
    "A culture hearth is a place where cultural traits originated and spread, such as the river valleys of Mesopotamia, Egypt, the Indus, and China, and Mesoamerica. A culture region is an area where people share certain traits, such as the Islamic world, Latin America, or the Anglophone world."]],
  ["Cultural diffusion",[
    "Cultural traits spread through diffusion. Relocation diffusion occurs when people move and carry their culture with them, as when migrants brought languages, religions, and foods to new lands. Expansion diffusion occurs when a trait spreads outward from its hearth while remaining strong there.",
    "Expansion diffusion has three forms. Contagious diffusion spreads rapidly from person to person, like a disease or a viral video. Hierarchical diffusion spreads from important people or large places down to smaller ones, as fashions often move from major cities to smaller towns. Stimulus diffusion occurs when the underlying idea spreads but the specific trait changes, as when the Cherokee leader Sequoyah, inspired by English writing, created a syllabary for the Cherokee language in the 1820s."]],
  ["Folk and popular culture",[
    "Folk culture is traditionally practiced by small, often rural, homogeneous groups, passed down through generations, and varies greatly from place to place, as in distinctive house types, crafts, music, and foods. Groups such as the Amish in the United States maintain strong folk cultures.",
    "Popular culture is widespread across large, diverse societies, spreads rapidly through mass media and the internet, and changes quickly, as in fashion, pop music, sports, and fast food. Globalization has spread popular culture, especially from the United States, Japan, and South Korea, whose pop music and dramas became globally popular in the 2010s, raising concerns about cultural homogenization and the loss of local traditions."]],
  ["Cultural landscapes",[
    "The cultural landscape, a concept developed by the American geographer Carl Sauer in the 1920s, is the visible imprint of human activity on the natural landscape: fields, fences, buildings, roads, place names, and sacred sites. Reading a landscape reveals the culture that created it.",
    "Examples include the rice terraces of the Philippine Cordilleras and Bali, the patchwork of hedged fields in England, the grid-like townships of the American Midwest created by the Land Ordinance of 1785, and the minarets, steeples, and temples that mark religious landscapes. UNESCO designates many cultural landscapes as World Heritage Sites."]],
  ["Ethnicity and identity",[
    "An ethnic group shares a common ancestry, culture, and sense of identity, often including language and religion. Ethnic groups may be concentrated in particular regions or neighborhoods, called ethnic enclaves. Many countries contain numerous ethnic groups; Nigeria has more than 250 and Indonesia hundreds.",
    "Ethnic diversity can enrich societies but has also been a source of conflict, especially where political borders cut across ethnic groups or combine rivals, as in the breakup of Yugoslavia, the Rwandan genocide, and conflicts in Myanmar and Sudan. The Kurds, numbering perhaps 30 million or more across Turkey, Iraq, Iran, and Syria, are often described as one of the largest ethnic groups without a state of their own."]],
  ["Gender and space",[
    "Geographers also study how gender shapes the use of space: access to public spaces, work, mobility, property, and safety. In many societies, women have historically been associated with domestic spaces and men with public ones, and women's access to land and inheritance remains limited in some regions.",
    "The UN's Gender Inequality Index and other measures show large regional differences in women's health, education, and political and economic participation. Changing gender roles, as women enter paid work and higher education, transform cities, families, and fertility patterns."]]
  ],
  terms:[["Culture","The shared way of life of a group of people."],["Culture hearth","A place where cultural traits originated."],["Relocation diffusion","Spread of culture through migration."],["Hierarchical diffusion","Spread from important people or places downward."],["Stimulus diffusion","Spread of an idea that changes as it is adopted."],["Folk culture","Traditional culture of small, homogeneous groups."],["Popular culture","Widespread, rapidly changing mass culture."],["Cultural landscape","The visible imprint of human activity on the land."]],
  w:"Culture explains much of what makes places distinctive, and understanding how it spreads helps explain globalization and identity.",
  src:["Cultural geography","Trait diffusion","Folk culture","Popular culture","Cultural landscape","Ethnic group","Kurds"],
  q:[["What is a place where cultural traits originated called?","A culture hearth","A culture region","A cultural landscape","An enclave"],
     ["A fashion moving from big cities to small towns is an example of what?","Hierarchical diffusion","Contagious diffusion","Relocation diffusion","Stimulus diffusion"],
     ["Sequoyah's Cherokee syllabary is an example of what?","Stimulus diffusion","Relocation diffusion","Contagious diffusion","Hierarchical diffusion"],
     ["Who developed the concept of the cultural landscape?","Carl Sauer","Friedrich Ratzel","Carl Ritter","Ellen Semple"],
     ["Which ethnic group is often described as one of the largest without a state?","The Kurds","The Basques","The Catalans","The Tamils"],
     ["Which kind of culture changes quickly and spreads through mass media?","Popular culture","Folk culture","Material culture","Subculture"]]},

{ t:"The Geography of Language", s:"How the world's languages are distributed",
  sec:[
  ["Languages of the world",[
    "About 7,000 languages are spoken in the world today, but they are very unevenly used: a few dozen languages are spoken by the majority of people, while about 40 percent of languages are endangered, many with only a few speakers left. Papua New Guinea alone has more than 800 languages, the most of any country.",
    "By total number of speakers (including second-language speakers), English is the most widely spoken language, followed by Mandarin Chinese, Hindi, and Spanish. By native speakers, Mandarin is the largest, followed by Spanish and English. Other major languages include Arabic, French, Bengali, Portuguese, Russian, Urdu, Indonesian, and Japanese."]],
  ["Language families",[
    "Languages are grouped into families descended from a common ancestor. The Indo-European family, the largest by speakers, includes most languages of Europe, Iran, and northern India, spoken by nearly half of humanity. Its branches include Germanic (English, German, Dutch, Scandinavian languages), Romance (Spanish, Portuguese, French, Italian, Romanian, all descended from Latin), Slavic (Russian, Polish, Ukrainian, Czech, Serbian), and Indo-Iranian (Hindi, Bengali, Urdu, Persian, Punjabi).",
    "Other major families include Sino-Tibetan (Chinese languages, Tibetan, Burmese); Afro-Asiatic (Arabic, Hebrew, Amharic, Hausa, Somali); Niger-Congo, the largest family by number of languages, including Swahili, Yoruba, Igbo, and Zulu; Austronesian (Malay, Indonesian, Tagalog, Malagasy, Hawaiian, Māori), spread across a vast area from Madagascar to Easter Island; Dravidian (Tamil, Telugu) in southern India; Turkic; and Uralic (Finnish, Hungarian, Estonian). Some languages, such as Basque, Japanese, and Korean, are isolates or belong to small families."]],
  ["How languages spread",[
    "Languages spread through migration, conquest, trade, and religion. Latin spread with the Roman Empire and evolved into the Romance languages. Arabic spread with Islam across the Middle East and North Africa. Spanish, Portuguese, English, and French spread through colonization; today there are more Spanish speakers in Mexico than in Spain, and more Portuguese speakers in Brazil than in Portugal.",
    "The spread of Indo-European languages from a homeland probably on the steppes north of the Black and Caspian seas, according to the most widely accepted hypothesis, occurred between about 4000 and 1000 BCE; a rival hypothesis places the homeland in Anatolia with the spread of farming."]],
  ["Lingua francas and official languages",[
    "A lingua franca is a language used for communication between people with different native languages. Greek and Latin served this role in the ancient Mediterranean; Arabic in the medieval Islamic world; French in diplomacy; Swahili across East Africa; and today English is the global lingua franca of science, business, aviation, and the internet.",
    "Many countries have more than one official language: Switzerland has four (German, French, Italian, and Romansh), Canada two (English and French), and South Africa twelve, including sign language. India's constitution recognizes 22 scheduled languages, with Hindi and English used by the central government. Pidgins are simplified languages that develop for contact between groups, and creoles are pidgins that become native languages, such as Haitian Creole."]],
  ["Dialects and place names",[
    "Dialects are regional varieties of a language with distinctive vocabulary, pronunciation, and grammar, such as the differences between American, British, Australian, and Indian English, or between regions within countries. Geographers map dialect boundaries using lines called isoglosses. The distinction between a language and a dialect is often political; a famous saying holds that a language is a dialect with an army and a navy.",
    "Toponymy, the study of place names, reveals history: names such as Los Angeles and San Francisco record Spanish settlement; many American place names, such as Massachusetts, Chicago, and Mississippi, come from Indigenous languages; and renaming, such as Bombay to Mumbai or Rhodesia to Zimbabwe, often reflects political change."]],
  ["Endangered languages",[
    "Languages die when children stop learning them, often because a dominant language offers economic opportunity or because of past policies of suppression, such as boarding schools that punished Indigenous children for speaking their languages. When a language dies, unique knowledge, oral literature, and ways of seeing the world are lost.",
    "Revitalization efforts include immersion schools, recordings, and official recognition. Hebrew is the most successful case: revived as a spoken everyday language in the late 19th and 20th centuries, it is now the native language of millions in Israel. Welsh, Māori, and Hawaiian have also seen revival efforts."]]
  ],
  terms:[["Language family","A group of languages descended from a common ancestor."],["Indo-European","The language family with the most speakers."],["Romance languages","Languages descended from Latin."],["Lingua franca","A common language between speakers of different languages."],["Creole","A pidgin that has become a native language."],["Isogloss","A boundary line marking a dialect feature."],["Toponymy","The study of place names."],["Language isolate","A language with no known relatives."]],
  w:"Language is the core of culture and identity, and its geography reveals the history of migration, conquest, and contact across the world.",
  src:["Language","Language family","Indo-European languages","Niger–Congo languages","Austronesian languages","Lingua franca","Endangered language"],
  q:[["Roughly how many languages are spoken today?","About 7,000","About 700","About 70,000","About 2,000"],
     ["Which country has the most languages?","Papua New Guinea","India","Nigeria","Indonesia"],
     ["Which language family includes Spanish, Hindi, and Russian?","Indo-European","Afro-Asiatic","Sino-Tibetan","Uralic"],
     ["Which family is the largest by number of languages?","Niger-Congo","Indo-European","Austronesian","Sino-Tibetan"],
     ["Which European language is a language isolate?","Basque","Finnish","Hungarian","Welsh"],
     ["Which language was successfully revived as an everyday spoken language?","Hebrew","Latin","Sanskrit","Cornish"]]},

{ t:"The Geography of Religion", s:"Where the world's faiths are and how they spread",
  sec:[
  ["Universalizing and ethnic religions",[
    "Geographers distinguish universalizing religions, which seek converts and aim to be global, such as Christianity, Islam, and Buddhism, from ethnic religions, which are tied to a particular group and place and rarely seek converts, such as Hinduism, Judaism, Shinto, and many traditional religions.",
    "Christianity is the largest religion, with about 2.4 billion followers (about 31 percent of the world), followed by Islam, with about 2 billion (about 25 percent) and growing fastest. Hinduism has about 1.2 billion followers, Buddhism about 500 million, and about 1.2 billion people are religiously unaffiliated. Smaller religions include Sikhism, Judaism, Baha'i, Jainism, and Shinto."]],
  ["Christianity",[
    "Christianity originated in the 1st century CE in Roman Judea and spread through the Roman Empire, then with European colonization to the Americas, Africa, and Oceania. Its three main branches are Roman Catholicism, the largest, dominant in southern Europe, Latin America, the Philippines, and parts of Africa; Protestantism, dominant in northern Europe, the United States, and growing rapidly in Africa and Latin America through Pentecostal and evangelical churches; and Eastern Orthodoxy, dominant in Russia, Greece, and much of Eastern Europe.",
    "Christianity's center of gravity has shifted south: today more Christians live in sub-Saharan Africa and Latin America than in Europe, and Nigeria, Brazil, and the Philippines have some of the largest Christian populations."]],
  ["Islam",[
    "Islam originated in the 7th century in Mecca and Medina, in Arabia, and spread rapidly through conquest and trade across the Middle East, North Africa, Central Asia, South Asia, and later Southeast Asia and sub-Saharan Africa. About 85–90 percent of Muslims are Sunni; Shia Muslims are a majority in Iran, Iraq, Azerbaijan, and Bahrain and large minorities elsewhere.",
    "Contrary to common assumption, most Muslims are not Arabs: the countries with the largest Muslim populations are Indonesia, Pakistan, India, and Bangladesh. Mecca, the destination of the annual Hajj pilgrimage, is Islam's holiest city."]],
  ["Hinduism, Buddhism, and others",[
    "Hinduism, with roots going back more than 3,000 years in South Asia, is concentrated in India and Nepal, with communities in Bangladesh, Sri Lanka, Bali, Mauritius, and the diaspora. The Ganges River and the city of Varanasi are especially sacred. Buddhism, founded by Siddhartha Gautama in northern India around the 5th century BCE, declined in India but spread across Asia: Theravada Buddhism in Sri Lanka, Myanmar, Thailand, Laos, and Cambodia; Mahayana in China, Vietnam, Korea, and Japan; and Vajrayana in Tibet, Bhutan, and Mongolia.",
    "Judaism, the oldest of the Abrahamic religions, has about 15 million adherents, mostly in Israel and the United States. Sikhism, founded by Guru Nanak in Punjab around 1500, centers on the Golden Temple in Amritsar. In East Asia, Confucianism, Daoism, Shinto, and folk traditions are often practiced alongside Buddhism."]],
  ["Sacred spaces and landscapes",[
    "Religions shape landscapes through places of worship, cemeteries, sacred mountains and rivers, and pilgrimage sites. Jerusalem is sacred to Judaism, Christianity, and Islam, and the Old City's holy places have been contested for centuries. Other major pilgrimage sites include Mecca, Varanasi, Lourdes, Santiago de Compostela, Bodh Gaya, where the Buddha attained enlightenment, and the Kumbh Mela gatherings in India, among the largest human gatherings on Earth.",
    "Religious rules shape diets, such as Hindu avoidance of beef and Islamic and Jewish prohibitions on pork, as well as calendars, architecture, and the use of land."]],
  ["Religion and conflict",[
    "Religious differences have contributed to conflicts, often intertwined with ethnicity, territory, and politics: the partition of India in 1947, the Troubles in Northern Ireland between mostly Catholic nationalists and Protestant unionists, wars in the former Yugoslavia, the Israeli-Palestinian conflict, and sectarian violence between Sunni and Shia in Iraq and elsewhere.",
    "At the same time, religion has inspired movements for peace and justice, and many regions have long histories of coexistence. Secularization has advanced in Western Europe, East Asia, and among younger people in many countries, while religion remains central in much of Africa, the Middle East, and South Asia."]]
  ],
  terms:[["Universalizing religion","A religion that seeks converts worldwide."],["Ethnic religion","A religion tied to a particular people and place."],["Sunni and Shia","The two main branches of Islam."],["Theravada and Mahayana","The two main branches of Buddhism."],["Pilgrimage","A journey to a sacred place."],["Secularization","The decline of religion's role in society."]],
  w:"Religion shapes values, laws, landscapes, diets, and conflicts across the world, so its geography is key to understanding societies everywhere.",
  src:["Major religious groups","Christianity","Islam by country","Hinduism","Buddhism","Sacred space","Secularization"],
  q:[["What is the world's largest religion?","Christianity","Islam","Hinduism","Buddhism"],
     ["Which country has the largest Muslim population?","Indonesia","Saudi Arabia","Pakistan","Egypt"],
     ["Which branch of Buddhism dominates Thailand and Sri Lanka?","Theravada","Mahayana","Vajrayana","Zen"],
     ["Which city on the Ganges is especially sacred to Hindus?","Varanasi","Amritsar","Bodh Gaya","Mumbai"],
     ["Where is Sikhism's Golden Temple?","Amritsar","Delhi","Lahore","Varanasi"],
     ["Which kind of religion rarely seeks converts?","Ethnic","Universalizing","Monotheistic","Missionary"]]},

{ t:"Agriculture and Food", s:"How the world feeds itself",
  sec:[
  ["Origins of agriculture",[
    "Agriculture began independently in several hearths after the last ice age, about 12,000–10,000 years ago, in what is called the Neolithic or First Agricultural Revolution. The Fertile Crescent of the Middle East domesticated wheat, barley, lentils, sheep, goats, and cattle; China, rice and millet; Mesoamerica, maize, beans, and squash; the Andes, potatoes and llamas; New Guinea, taro and bananas; and sub-Saharan Africa, sorghum and yams.",
    "The Second Agricultural Revolution, beginning in 17th- and 18th-century Britain, introduced crop rotation, selective breeding, enclosure, and later machinery, freeing labor for industry. The Third Agricultural Revolution, the Green Revolution of the mid-20th century, spread high-yield crop varieties, fertilizers, pesticides, and irrigation, greatly increasing harvests in Asia and Latin America."]],
  ["Subsistence and commercial agriculture",[
    "Subsistence agriculture produces food mainly for the farmer's family. It includes shifting cultivation (slash-and-burn) in tropical forests, where farmers clear and burn plots, grow crops for a few years, and move on as soil fertility declines; pastoral nomadism in dry lands, where herders move animals such as camels, goats, and cattle seasonally; and intensive subsistence farming, such as wet-rice cultivation in the crowded river valleys of East, South, and Southeast Asia.",
    "Commercial agriculture produces crops and livestock for sale. It includes large mechanized grain farms in the Great Plains, Canadian Prairies, Ukraine, and Argentina; livestock ranching in dry regions; dairy farming near cities; mixed crop and livestock farming in the U.S. Corn Belt and Europe; Mediterranean agriculture producing grapes, olives, and citrus; and plantations in the tropics growing export crops such as coffee, tea, sugar, bananas, cocoa, rubber, and palm oil."]],
  ["Von Thünen's model",[
    "In 1826 the German landowner Johann Heinrich von Thünen developed a model of agricultural land use around a city. He showed that, on a uniform plain, farmers would arrange activities in rings according to transport costs and perishability: market gardening and dairying closest to the city, then timber (heavy and needed for fuel), then grain crops, and ranching farthest away.",
    "Though real landscapes are more complex, the model's insight, that distance to market shapes land use, still applies, as in the concentration of dairy and vegetable farms near large cities."]],
  ["World food production",[
    "Three crops, rice, wheat, and maize (corn), provide about half of the calories humans consume. China and India are the largest producers of rice and wheat; the United States is the largest producer of maize, much of it used for animal feed and ethanol. Soybeans, grown mainly in the United States, Brazil, and Argentina, are a major source of animal feed and vegetable oil.",
    "Livestock occupy about three-quarters of agricultural land, including pasture and land for feed crops, yet provide less than a fifth of the world's calories. Diets shift toward more meat and dairy as incomes rise, increasing demand for land and water. Fishing and aquaculture provide protein for billions; aquaculture now produces about as much seafood as wild fishing."]],
  ["Food security",[
    "Food security means that all people at all times have access to sufficient, safe, and nutritious food. The world produces enough calories to feed everyone, yet hundreds of millions of people suffer from hunger, mainly because of poverty, conflict, and poor infrastructure. Famines in modern times, such as those in Ethiopia in the 1980s and Somalia in 2011, have been closely linked to war and political failure; the economist Amartya Sen argued that democracies with a free press rarely experience famines.",
    "At the same time, obesity has become a global health problem. Around a third of food produced is lost or wasted. Food deserts, areas with limited access to affordable nutritious food, exist even in wealthy countries."]],
  ["Agriculture and the environment",[
    "Agriculture is the largest human use of land, uses about 70 percent of fresh water withdrawals, and contributes roughly a quarter of greenhouse gas emissions when land-use change is included. It causes deforestation, soil erosion, water pollution from fertilizer runoff, and biodiversity loss.",
    "Responses include sustainable practices such as conservation tillage, agroforestry, integrated pest management, and organic farming; precision agriculture using GPS and sensors; reducing food waste; and genetically modified crops, which are widely grown in the Americas but controversial in Europe. Feeding a population approaching 10 billion while protecting the environment is one of the central challenges of geography."]]
  ],
  terms:[["Neolithic Revolution","The origin of farming about 12,000–10,000 years ago."],["Green Revolution","The mid-20th-century spread of high-yield agriculture."],["Subsistence agriculture","Farming to feed the farmer's own family."],["Shifting cultivation","Clearing plots, farming them briefly, and moving on."],["Pastoral nomadism","Moving herds seasonally in search of pasture."],["Plantation","A large farm producing cash crops, often for export."],["Von Thünen model","A model of agricultural land use in rings around a city."],["Food security","Reliable access to sufficient, nutritious food."]],
  w:"Agriculture is humanity's largest use of land and water, and the geography of food explains landscapes, economies, hunger, and environmental change.",
  src:["Neolithic Revolution","Green Revolution","Subsistence agriculture","Shifting cultivation","Von Thünen model","Food security","Environmental impact of agriculture"],
  q:[["Which hearth domesticated maize, beans, and squash?","Mesoamerica","The Fertile Crescent","China","The Andes"],
     ["What is slash-and-burn farming also called?","Shifting cultivation","Intensive subsistence","Pastoral nomadism","Plantation agriculture"],
     ["Who developed a model of farming rings around a city?","Johann Heinrich von Thünen","Walter Christaller","Thomas Malthus","Ernest Burgess"],
     ["Which three crops provide about half of human calories?","Rice, wheat, and maize","Potatoes, soybeans, and rice","Wheat, barley, and oats","Maize, cassava, and sorghum"],
     ["Who argued that democracies with a free press rarely have famines?","Amartya Sen","Norman Borlaug","Thomas Malthus","Esther Boserup"],
     ["Roughly what share of food produced is lost or wasted?","About a third","About 5 percent","About two-thirds","About 1 percent"]]},

{ t:"Economic Development", s:"Why some places are rich and others poor",
  sec:[
  ["Measuring development",[
    "Development is the process of improving people's material conditions and well-being. The most common economic measure is gross domestic product (GDP), the value of goods and services produced in a country in a year, usually expressed per person. Gross national income (GNI) also counts income from abroad. Purchasing power parity (PPP) adjusts for differences in living costs between countries.",
    "Because income alone misses much, the United Nations created the Human Development Index (HDI) in 1990, inspired by Amartya Sen and the economist Mahbub ul Haq. It combines life expectancy, education, and income. Other indicators include literacy, infant mortality, access to clean water, and the Gini coefficient, which measures inequality within a country."]],
  ["The development gap",[
    "The world is sharply divided between rich and poor. High-income countries include the United States, Canada, Western Europe, Japan, South Korea, Australia, and the oil-rich Gulf states; low-income countries are concentrated in sub-Saharan Africa, along with Afghanistan, Yemen, and Haiti. This division is sometimes described as the Global North and Global South, after the Brandt Line drawn in 1980, though the categories are imperfect.",
    "The gap is narrowing for many: extreme poverty, defined by the World Bank as living on less than about 2 to 3 dollars a day, fell from over a third of humanity in 1990 to under a tenth by the late 2010s, largely due to growth in China, India, and Southeast Asia. Extreme poverty is now increasingly concentrated in sub-Saharan Africa and in fragile and conflict-affected states."]],
  ["Economic sectors",[
    "Economies are divided into sectors. The primary sector extracts natural resources: farming, fishing, forestry, and mining. The secondary sector processes and manufactures goods. The tertiary sector provides services such as retail, transport, health, and education. Some geographers add a quaternary sector for knowledge and information services, such as research and finance, and a quinary sector for top-level decision making.",
    "As countries develop, employment shifts from primary to secondary and then to tertiary activities. In poor countries, most people work in agriculture; in the United States, less than 2 percent do, and around 80 percent work in services."]],
  ["Theories of development",[
    "Walt Rostow's modernization model (1960) proposed that all countries pass through five stages of growth: traditional society, preconditions for take-off, take-off, the drive to maturity, and high mass consumption. Critics argued it assumed all countries could follow the Western path.",
    "Dependency theory, popular in Latin America in the 1960s and 1970s, argued that poor countries were kept poor by unequal relationships with rich countries, exporting cheap raw materials and importing expensive manufactured goods. Immanuel Wallerstein's world-systems theory divided the world into a wealthy core, a poor periphery, and an intermediate semi-periphery. Later explanations emphasize institutions such as secure property rights and the rule of law, geography (such as access to the sea and the disease burden of the tropics), history including colonialism, education, and governance."]],
  ["Paths to development",[
    "Countries have pursued different strategies. Import substitution aimed to build domestic industries behind trade barriers, as in Latin America and India for decades. Export-oriented industrialization, pursued by the East Asian Tigers and then China, proved more successful at generating rapid growth.",
    "International institutions such as the World Bank and International Monetary Fund lend money and advise governments; their structural adjustment programs of the 1980s and 1990s, requiring market reforms and spending cuts, were controversial. Other tools include foreign aid, microfinance, pioneered by Muhammad Yunus and the Grameen Bank in Bangladesh, fair trade, and remittances. The United Nations' Sustainable Development Goals (2015) set 17 goals for 2030, from ending poverty and hunger to clean energy and climate action."]],
  ["Uneven development within countries",[
    "Development is uneven not only between but within countries. In many countries a core region, often around the capital or major port, is far wealthier than the periphery: southeastern England versus the north, northern versus southern Italy, coastal versus inland China, and the industrial south versus the poorer north and east of Brazil.",
    "Inequality between rural and urban areas, between ethnic groups, and between men and women is also significant. Geographers study these patterns at many scales to understand how place shapes opportunity."]]
  ],
  terms:[["GDP per capita","The value of a country's output per person."],["Purchasing power parity","An adjustment for differences in living costs."],["Human Development Index","A U.N. measure combining health, education, and income."],["Gini coefficient","A measure of income inequality."],["Economic sectors","Primary, secondary, tertiary, and quaternary activities."],["Dependency theory","The view that poor countries are kept poor by rich ones."],["World-systems theory","Wallerstein's division of the world into core, periphery, and semi-periphery."],["Sustainable Development Goals","The U.N.'s 17 goals for 2030."]],
  w:"Understanding development explains the vast differences in wealth and well-being across the world and the debates over how to reduce poverty.",
  src:["Economic development","Human Development Index","Gini coefficient","Economic sector","Rostow's stages of growth","World-systems theory","Sustainable Development Goals"],
  q:[["Which index combines life expectancy, education, and income?","The Human Development Index","GDP","The Gini coefficient","The Brandt Index"],
     ["What does the Gini coefficient measure?","Income inequality","Population density","Literacy","Life expectancy"],
     ["Which sector includes manufacturing?","Secondary","Primary","Tertiary","Quaternary"],
     ["Who proposed five stages of economic growth?","Walt Rostow","Immanuel Wallerstein","Amartya Sen","Mahbub ul Haq"],
     ["Who pioneered microfinance with the Grameen Bank?","Muhammad Yunus","Amartya Sen","Jeffrey Sachs","Mahbub ul Haq"],
     ["How many Sustainable Development Goals are there?","17","8","10","25"]]}

);


/* ---- from geo-09.js ---- */
/* GEOGRAPHY FOUNDATIONS, part 9: Unit 5 chapters 11-15 */
COURSES.geography.units[4].ch.push(

{ t:"Industry and Globalization", s:"Where things are made and why",
  sec:[
  ["The Industrial Revolution and location",[
    "Industrialization began in Britain in the late 18th century, with textile mills, steam engines, and iron and coal industries. Early industry clustered near coalfields, water power, ports, and raw materials: the English Midlands and North, Germany's Ruhr Valley, Belgium, and later the American Manufacturing Belt from New England to Chicago.",
    "In 1909 the German economist Alfred Weber proposed a theory of industrial location: firms seek the site that minimizes transport and labor costs. Bulk-reducing industries, such as steel and copper smelting, in which raw materials weigh more than the product, locate near resources; bulk-gaining industries, such as soft-drink bottling, locate near markets."]],
  ["Fordism and the factory era",[
    "The 20th century saw mass production on assembly lines, pioneered by Henry Ford at Highland Park, Michigan, in 1913, along with large factories, strong unions, and mass consumption, a system called Fordism. Industrial regions such as Detroit, Pittsburgh, Manchester, and the Ruhr became symbols of this era.",
    "The Soviet Union and other planned economies built vast industrial complexes, and Japan rose as an industrial power after World War II, pioneering lean production methods, such as Toyota's just-in-time system, which reduced inventory and waste."]],
  ["Deindustrialization and the new international division of labor",[
    "From the 1970s, manufacturing employment declined in many older industrial regions of North America and Europe, a process called deindustrialization. Factories closed or moved, creating “Rust Belts.” Causes included automation, competition from lower-cost countries, and the shift of investment abroad.",
    "Multinational corporations increasingly divided production across countries, placing research and headquarters in rich countries and assembly in lower-wage ones, a new international division of labor. Export processing zones, such as the maquiladoras along Mexico's northern border and China's Special Economic Zones, offered tax breaks and cheap labor. China became the “world's factory,” producing about 30 percent of global manufacturing output by the 2020s."]],
  ["Global value chains",[
    "Today many products are made through global value chains. A smartphone may be designed in California, use chips made in Taiwan or South Korea, minerals mined in Africa and South America, and be assembled in China, India, or Vietnam. Containerization, cheap communication, and lower tariffs made this possible.",
    "The COVID-19 pandemic and rising geopolitical tensions exposed the risks of long supply chains, prompting some firms and governments to pursue reshoring, nearshoring to nearby countries such as Mexico, and “friend-shoring” to allied countries. Semiconductor manufacturing, dominated by Taiwan's TSMC, became a strategic concern."]],
  ["Clusters and the knowledge economy",[
    "High-technology industries cluster in regions with universities, skilled workers, investors, and networks of firms. Silicon Valley in California, built around Stanford University and the semiconductor and computer industries, is the most famous. Others include Boston's Route 128, Bangalore (Bengaluru) in India, Shenzhen in China, Tel Aviv, and Cambridge in England.",
    "The economist Michael Porter emphasized how such clusters foster innovation through competition and cooperation. In the knowledge economy, ideas, skills, and connectivity matter more than proximity to raw materials."]],
  ["What is globalization?",[
    "Globalization is the increasing interconnection of the world's economies, cultures, and peoples through trade, investment, migration, technology, and communication. It accelerated after 1980 with trade liberalization, the end of the Cold War, the rise of China, and the internet. Global trade has grown much faster than world output.",
    "Globalization has lifted hundreds of millions out of poverty and lowered prices for consumers, but critics point to job losses in some regions, exploitation of workers in low-wage factories, as highlighted by the collapse of the Rana Plaza garment factory in Bangladesh in 2013, which killed over 1,100 workers, environmental harm, and the power of multinational corporations. Debates over globalization shape politics across the world."]]
  ],
  terms:[["Weber's least-cost theory","Industry locates where transport and labor costs are lowest."],["Fordism","Mass production on assembly lines with mass consumption."],["Deindustrialization","The decline of manufacturing in a region."],["New international division of labor","The spread of production across countries by cost."],["Maquiladora","A foreign-owned assembly plant in northern Mexico."],["Global value chain","Production of a good spread across many countries."],["Industrial cluster","A concentration of related firms in one region."],["Globalization","The growing interconnection of the world's economies and societies."]],
  w:"The geography of industry explains the rise and fall of regions, the global supply chains behind everyday products, and the debates over globalization.",
  src:["Industrial Revolution","Alfred Weber","Fordism","Deindustrialization","Maquiladora","Global value chain","Globalization"],
  q:[["Where did the Industrial Revolution begin?","Britain","Germany","The United States","Belgium"],
     ["Who proposed the least-cost theory of industrial location?","Alfred Weber","Max Weber","Johann von Thünen","Walter Christaller"],
     ["Who pioneered the moving assembly line in 1913?","Henry Ford","Frederick Taylor","Thomas Edison","Andrew Carnegie"],
     ["What are foreign-owned assembly plants in northern Mexico called?","Maquiladoras","Haciendas","Ejidos","Favelas"],
     ["Which Indian city is a major technology cluster?","Bangalore (Bengaluru)","Varanasi","Jaipur","Patna"],
     ["Which 2013 disaster in Bangladesh drew attention to garment workers' conditions?","The Rana Plaza collapse","The Bhopal disaster","The Sundarbans fire","Cyclone Sidr"]]},

{ t:"Energy and Natural Resources", s:"Fuels, minerals, and the geography of power",
  sec:[
  ["Renewable and non-renewable resources",[
    "A natural resource is anything from the environment that people use: soil, water, forests, fish, minerals, and energy. Renewable resources, such as sunlight, wind, water, and forests, can be replenished naturally if managed well. Non-renewable resources, such as fossil fuels and minerals, exist in finite amounts and form over geological time.",
    "Resources are unevenly distributed, which shapes trade, wealth, and conflict. Some countries rich in resources have nonetheless suffered poor growth, corruption, and conflict, a pattern economists call the resource curse; Norway, which saved its oil wealth in a sovereign wealth fund, is often cited as a counterexample."]],
  ["Fossil fuels",[
    "Fossil fuels, coal, oil, and natural gas, formed from the remains of ancient organisms and still supply about 80 percent of the world's primary energy. Coal powered the Industrial Revolution and remains the largest source of electricity in China and India, the world's largest producers and consumers. It is also the most polluting fuel.",
    "Oil is the main transport fuel. The largest proven oil reserves are in Venezuela, Saudi Arabia, Iran, Canada (mostly oil sands), and Iraq. The United States became the world's largest oil producer in the 2010s thanks to hydraulic fracturing (fracking) of shale, followed by Saudi Arabia and Russia. OPEC, the Organization of the Petroleum Exporting Countries, founded in 1960, coordinates production among major exporters. Natural gas, cleaner-burning than coal, is traded by pipeline and as liquefied natural gas (LNG); Russia, Iran, and Qatar hold the largest reserves."]],
  ["Nuclear and hydro power",[
    "Nuclear power generates about a tenth of the world's electricity without carbon emissions. France gets around two-thirds of its electricity from nuclear plants; the United States has the most reactors. Concerns include accidents, such as Chernobyl in 1986 and Fukushima in 2011, radioactive waste, and cost.",
    "Hydroelectric power is the largest renewable source of electricity. The largest plants include the Three Gorges Dam in China and the Itaipu Dam on the Brazil-Paraguay border. Norway, Brazil, and Canada generate large shares of their electricity from hydropower. Dams, however, displace communities and disrupt rivers."]],
  ["The renewable energy transition",[
    "Solar and wind power have grown dramatically as costs fell by roughly 90 percent and 70 percent respectively over the 2010s. China is by far the world's largest producer of solar panels, wind turbines, and batteries, and installs the most renewable capacity. Countries such as Denmark get over half their electricity from wind, and Iceland uses geothermal power and hydropower for nearly all its electricity.",
    "The best locations for solar power are sunny, dry regions such as deserts; for wind, coasts, plains, and offshore areas. Challenges include variability, which requires storage, grid upgrades, and backup, and the land and materials needed."]],
  ["Critical minerals",[
    "Modern technologies depend on minerals. Copper is essential for electrical wiring; Chile and Peru are the largest producers. Lithium, used in batteries, comes mainly from Australia and the “lithium triangle” of Chile, Argentina, and Bolivia. Cobalt comes largely from the Democratic Republic of the Congo, where mining has raised concerns about child labor. Rare earth elements, vital for magnets in wind turbines and electric motors, are mined and especially processed overwhelmingly in China.",
    "Other key resources include iron ore (Australia, Brazil), bauxite for aluminum (Australia, Guinea), gold (China, Australia, Russia), and diamonds (Russia, Botswana, Canada, the DRC). Control over critical mineral supply chains has become a matter of national security for many countries."]],
  ["Energy and geopolitics",[
    "Energy shapes international relations. The 1973 oil embargo showed the power of oil exporters; the Persian Gulf's oil has drawn foreign military involvement for decades. Russia used natural gas supplies as leverage over Europe, which sharply reduced its dependence after Russia's 2022 invasion of Ukraine.",
    "Energy consumption per person is highly unequal: an average American uses many times as much energy as an average person in sub-Saharan Africa, where hundreds of millions still lack electricity. Providing clean, affordable energy to all while reducing emissions is a central goal of sustainable development."]]
  ],
  terms:[["Renewable resource","A resource that can be naturally replenished."],["Non-renewable resource","A resource that exists in finite amounts."],["Resource curse","Poor development in resource-rich countries."],["Fossil fuels","Coal, oil, and natural gas."],["OPEC","The Organization of the Petroleum Exporting Countries."],["Fracking","Hydraulic fracturing to extract oil and gas from shale."],["Critical minerals","Minerals essential to modern technology with vulnerable supply chains."]],
  w:"The geography of energy and resources shapes national wealth, global politics, and the transition to a low-carbon economy.",
  src:["Natural resource","Resource curse","Fossil fuel","OPEC","Nuclear power","Renewable energy","Critical mineral raw materials"],
  q:[["What share of world primary energy do fossil fuels supply?","About 80 percent","About 40 percent","About 95 percent","About 60 percent"],
     ["Which country has the largest proven oil reserves?","Venezuela","Saudi Arabia","The United States","Russia"],
     ["Which country gets about two-thirds of its electricity from nuclear power?","France","Japan","The United States","Germany"],
     ["Which country produces most of the world's cobalt?","The Democratic Republic of the Congo","Chile","Australia","China"],
     ["Which country dominates rare earth processing?","China","The United States","Brazil","India"],
     ["Which country is often cited as escaping the resource curse with a sovereign wealth fund?","Norway","Venezuela","Nigeria","Angola"]]},

{ t:"Transport, Trade, and Communication", s:"The networks that connect the world",
  sec:[
  ["Shrinking the world",[
    "Improvements in transport and communication have dramatically reduced the time and cost of moving people, goods, and information, a process geographers call time-space compression. A journey across the Atlantic took about two months by sailing ship, about a week by steamship by the late 19th century, and takes about seven hours by jet today; information now crosses the world instantly.",
    "Distance decay describes how interaction between places declines as distance increases. Better transport weakens but does not eliminate distance decay; most trade still occurs between neighboring countries."]],
  ["Shipping and containers",[
    "Sea transport carries about 80 percent of world trade by volume because it is by far the cheapest way to move heavy goods over long distances. The shipping container, introduced by the American entrepreneur Malcom McLean in 1956, revolutionized trade by allowing goods to move seamlessly between ships, trains, and trucks, slashing loading costs and time.",
    "The world's busiest container ports are concentrated in East Asia, led by Shanghai, Singapore, Ningbo-Zhoushan, Shenzhen, and Qingdao; Rotterdam is Europe's largest port. Giant container ships can carry over 20,000 containers."]],
  ["Land and air transport",[
    "Railways transformed the 19th century, binding nations together and opening continental interiors; the U.S. transcontinental railroad was completed in 1869 and the Trans-Siberian Railway in 1916. High-speed rail began with Japan's Shinkansen in 1964; China now has the world's largest high-speed network, over 40,000 kilometers.",
    "Roads and trucks dominate short-distance freight and personal travel. The U.S. Interstate Highway System, authorized in 1956, reshaped American cities and suburbs. Air transport carries a small share of freight by weight but a large share by value, such as electronics and pharmaceuticals; major hub airports include Atlanta, Dubai, London Heathrow, and Tokyo Haneda."]],
  ["Patterns of world trade",[
    "World trade is dominated by a few large economies and blocs. China is the world's largest exporter of goods, followed by the United States and Germany. Countries trade because of comparative advantage, the principle described by David Ricardo in 1817 that countries benefit by specializing in what they produce relatively most efficiently.",
    "Regional trade agreements reduce barriers among members: the European Union's single market; the United States–Mexico–Canada Agreement (USMCA), which replaced NAFTA in 2020; Mercosur in South America; ASEAN in Southeast Asia; the African Continental Free Trade Area (2018); and the Regional Comprehensive Economic Partnership (RCEP) in Asia-Pacific, the largest by population. The World Trade Organization sets global trade rules, though trade disputes and tariffs increased in the late 2010s and 2020s."]],
  ["Communication networks",[
    "The telegraph, beginning in the 1840s, and the first transatlantic cable, which worked briefly in 1858 and permanently from 1866, allowed near-instant communication across oceans. The telephone, radio, and television followed.",
    "Today the internet depends on a physical geography: over 95 percent of intercontinental data travels through hundreds of undersea fiber-optic cables, and huge data centers cluster where electricity is cheap and climates cool. Access is unequal; the digital divide separates those with fast internet access from the roughly a third of humanity still offline, mostly in poorer and rural areas."]],
  ["Networks and hubs",[
    "Transport and communication form networks of nodes (cities, ports, airports) and links (routes). Hubs, such as Singapore, Dubai, Panama, and Rotterdam, gain wealth and influence by concentrating flows. Gateway cities connect regions to the wider world.",
    "Infrastructure projects can reshape regional geography; China's Belt and Road Initiative, launched in 2013, has financed ports, railways, and roads across Asia, Africa, and Europe. Transport also has environmental costs: it accounts for roughly a fifth of global carbon dioxide emissions."]]
  ],
  terms:[["Time-space compression","The shrinking of effective distance through faster transport and communication."],["Distance decay","Declining interaction with increasing distance."],["Containerization","Shipping goods in standardized containers."],["Comparative advantage","Specializing in what a country produces relatively most efficiently."],["Free trade agreement","A pact reducing trade barriers among members."],["Digital divide","Unequal access to the internet and digital technology."],["Hub","A node that concentrates flows in a network."]],
  w:"Transport and communication networks shape where economic activity happens and bind the world together, explaining patterns of trade and connectivity.",
  src:["Time–space compression","Distance decay","Containerization","Comparative advantage","List of busiest container ports","Submarine communications cable","Digital divide"],
  q:[["What share of world trade by volume goes by sea?","About 80 percent","About 30 percent","About 50 percent","About 95 percent"],
     ["Who introduced the modern shipping container?","Malcom McLean","Henry Ford","Isambard Brunel","Cyrus Field"],
     ["Which is the world's busiest container port?","Shanghai","Rotterdam","Los Angeles","Singapore"],
     ["Which country opened the first high-speed rail line in 1964?","Japan","France","China","Germany"],
     ["Who described the principle of comparative advantage?","David Ricardo","Adam Smith","John Maynard Keynes","Alfred Weber"],
     ["How does most intercontinental internet data travel?","Undersea fiber-optic cables","Satellites","Radio waves","Overland copper wires"]]},

{ t:"States, Nations, and Borders", s:"Political geography",
  sec:[
  ["States and nations",[
    "Political geography studies how space is organized politically. A state (country) is a political unit with a defined territory, a permanent population, a government, and sovereignty, the recognized authority to govern itself without outside interference. There are 193 member states of the United Nations, plus observer states such as the Vatican and Palestine, and territories with disputed status such as Taiwan and Kosovo.",
    "A nation is a group of people who share a common culture, history, and identity and often desire self-government. A nation-state is a state whose people largely share a single national identity, such as Japan, Iceland, or Poland. Multinational states, such as the United Kingdom, Belgium, India, and Russia, contain several nations. Stateless nations include the Kurds, Palestinians, Basques, and Tibetans."]],
  ["The modern state system",[
    "The modern system of sovereign territorial states is often traced to the Peace of Westphalia (1648), which ended the Thirty Years' War in Europe. Nationalism in the 19th century, the breakup of empires after World War I, decolonization after World War II, and the collapse of the Soviet Union and Yugoslavia in the 1990s greatly increased the number of states. The newest UN member is South Sudan, which became independent in 2011.",
    "Microstates are very small states, such as Monaco, San Marino, Liechtenstein, Singapore, and many Caribbean and Pacific island nations. The largest countries by area are Russia, Canada, China, the United States, and Brazil."]],
  ["Shapes and situations of states",[
    "A state's shape can affect its unity and communication. Compact states, such as Poland, are efficient to govern. Elongated states, such as Chile and Vietnam, may struggle to connect distant regions. Fragmented states, such as Indonesia, the Philippines, and Japan, consist of separate pieces. Prorupted states have a long extension, such as Thailand and Namibia's Caprivi Strip. Perforated states surround another state, as South Africa surrounds Lesotho and Italy surrounds San Marino and Vatican City.",
    "Landlocked states lack a seacoast and depend on neighbors for access to ports. There are over 40, including Switzerland, Austria, Bolivia, Paraguay, Ethiopia, Uganda, Mongolia, Kazakhstan, the largest, and Afghanistan. Many landlocked countries, especially in Africa and Central Asia, are among the poorest. An enclave is territory entirely surrounded by another state; an exclave is part of a state separated from the main territory, such as Russia's Kaliningrad and Alaska."]],
  ["Borders",[
    "Boundaries are invisible lines marking the edges of state territory. Physical boundaries follow natural features: mountains, such as the Pyrenees between France and Spain; rivers, such as the Rio Grande between the United States and Mexico; and lakes. Geometric boundaries follow straight lines, often lines of latitude or longitude, such as the 49th parallel between the United States and Canada; many African and Middle Eastern borders were drawn this way by colonial powers.",
    "Cultural boundaries follow ethnic, linguistic, or religious divisions, such as the 1947 partition of India. Boundaries can be antecedent (drawn before settlement), subsequent (drawn after settlement), superimposed (imposed by outside powers), or relic (no longer functioning, like the Berlin Wall). The Schengen Area allows passport-free travel across most of the European Union, while other borders, like that between North and South Korea, are among the most fortified on Earth."]],
  ["Internal organization",[
    "States distribute power differently. Unitary states, such as France, Japan, and China, concentrate power in the central government. Federal states, such as the United States, Germany, India, Brazil, Canada, Australia, Nigeria, and Russia, divide power between the national government and states or provinces, often to accommodate large size or diverse populations.",
    "Devolution is the transfer of power from the central government to regions, as when the United Kingdom created parliaments for Scotland and Wales in 1999. Separatist movements seek independence for regions, such as Catalonia in Spain, Scotland, Quebec in Canada, which narrowly voted against independence in 1995, and many others. Electoral geography studies how districts are drawn; gerrymandering is the manipulation of district boundaries for political advantage."]],
  ["Territorial disputes",[
    "Many conflicts involve disputes over territory and resources: Kashmir between India and Pakistan; the Golan Heights and West Bank; the South China Sea, where China's claims overlap with those of Vietnam, the Philippines, Malaysia, Brunei, and Taiwan; Crimea and eastern Ukraine; the Falkland (Malvinas) Islands between Britain and Argentina; and Western Sahara.",
    "Disputes can be positional (over where a boundary lies), territorial (over who owns land), resource-based (over water, oil, or fish), or functional (over how a border is managed). As the Arctic ice melts, competition over Arctic shipping routes and seabed resources is growing."]]
  ],
  terms:[["State","A sovereign political unit with territory, population, and government."],["Nation","A people sharing culture and identity."],["Nation-state","A state whose people share a single national identity."],["Sovereignty","Supreme authority over a territory."],["Landlocked state","A country without a seacoast."],["Exclave","Part of a state separated from its main territory."],["Federal state","A state that divides power between national and regional governments."],["Gerrymandering","Drawing electoral districts for political advantage."]],
  w:"Political geography explains why the world map looks as it does and why borders, sovereignty, and territory remain at the heart of conflict and cooperation.",
  src:["Political geography","Sovereign state","Nation state","Peace of Westphalia","Landlocked country","Border","Federation"],
  q:[["How many member states does the United Nations have?","193","195","150","206"],
     ["Which treaty is often seen as the origin of the modern state system?","The Peace of Westphalia","The Treaty of Versailles","The Congress of Vienna","The Treaty of Tordesillas"],
     ["Which is the newest UN member state?","South Sudan","Kosovo","Montenegro","East Timor"],
     ["Which country is the largest landlocked country?","Kazakhstan","Mongolia","Bolivia","Ethiopia"],
     ["Which country is completely surrounded by South Africa?","Lesotho","Eswatini","Botswana","Namibia"],
     ["Which parallel forms much of the U.S.-Canada border?","The 49th","The 38th","The 54th","The 45th"]]},

{ t:"Geopolitics and International Cooperation", s:"Power, alliances, and global governance",
  sec:[
  ["Classical geopolitics",[
    "Geopolitics is the study of how geography influences international power and politics. In 1890 the American naval officer Alfred Thayer Mahan argued that sea power was the key to national greatness. In 1904 the British geographer Halford Mackinder proposed the heartland theory: whoever controlled the vast interior of Eurasia, the “heartland,” could dominate the world.",
    "Nicholas Spykman countered in the 1940s with the rimland theory, arguing that the coastal fringes of Eurasia were more important. German geopolitics, drawing on Friedrich Ratzel's idea of the state as an organism needing “living space,” was misused by the Nazis, which discredited the field for decades. Today geopolitics is again widely studied."]],
  ["Supranational organizations",[
    "Supranational organizations are alliances of three or more states that cooperate for common goals. The United Nations, founded in 1945 with headquarters in New York, aims to maintain peace and promote cooperation. Its Security Council has five permanent members with veto power, the United States, Russia, China, the United Kingdom, and France, and ten rotating members. UN agencies include the World Health Organization, UNICEF, UNESCO, and the World Food Programme.",
    "The European Union is the most integrated regional organization, with 27 members after Britain's departure in 2020, a single market, common laws, and, for 20 members, the euro. Other regional groups include the African Union (55 members), ASEAN, the Organization of American States, the Arab League, and Mercosur."]],
  ["Military alliances",[
    "The North Atlantic Treaty Organization (NATO), founded in 1949, is a collective defense alliance in which an attack on one member is considered an attack on all (Article 5). It expanded from 12 founding members to 32 by 2024, as Finland (2023) and Sweden (2024) joined after Russia's invasion of Ukraine. Other security arrangements include U.S. alliances with Japan, South Korea, and Australia.",
    "The Shanghai Cooperation Organisation, led by China and Russia, and the BRICS grouping, originally Brazil, Russia, India, China, and South Africa, later expanded with new members, reflect efforts by emerging powers to build alternatives to Western-led institutions."]],
  ["The shifting balance of power",[
    "After the Cold War, the United States was the sole superpower in a unipolar world. In the 21st century, many analysts describe a more multipolar world, with the rise of China as an economic, technological, and military power, the resurgence of Russia as a military power, and the growing influence of India, Brazil, Turkey, Saudi Arabia, and others.",
    "Rivalry between the United States and China, over trade, technology, Taiwan, and the South China Sea, is widely seen as the defining geopolitical relationship of the century. Russia's full-scale invasion of Ukraine in 2022 reshaped European security."]],
  ["Global commons",[
    "Some areas lie beyond any state's sovereignty, the global commons: the high seas, the atmosphere, outer space, and Antarctica. The Antarctic Treaty of 1959 set aside the continent for peaceful scientific research, froze territorial claims by seven countries, and banned military activity; a 1991 protocol banned mining.",
    "Managing the commons requires cooperation, as in climate agreements, the Law of the Sea, and the Outer Space Treaty (1967), which bans claims of sovereignty over celestial bodies. The ecologist Garrett Hardin's “tragedy of the commons” (1968) described how shared resources can be overused when individuals act in their own interest, while the political economist Elinor Ostrom showed how communities often successfully manage common resources."]],
  ["Non-state actors",[
    "International politics also involves non-state actors: multinational corporations, some wealthier than many states; non-governmental organizations (NGOs) such as the Red Cross, Doctors Without Borders, and Amnesty International; religious organizations; and terrorist and criminal networks.",
    "Globalization has led some to argue that the power of states is declining, while others note that states remain the central actors, controlling borders, armies, and laws, as the pandemic and recent conflicts demonstrated."]]
  ],
  terms:[["Geopolitics","The study of how geography shapes international power."],["Heartland theory","Mackinder's idea that controlling inner Eurasia brings world power."],["Supranational organization","An alliance of states cooperating for shared goals."],["Security Council","The UN body with five permanent veto-holding members."],["NATO","The North Atlantic collective defense alliance."],["Global commons","Areas beyond national sovereignty, such as the high seas."],["Tragedy of the commons","Overuse of shared resources by self-interested users."]],
  w:"Geopolitics and international organizations shape war and peace, trade, and global cooperation on shared problems like climate and pandemics.",
  src:["Geopolitics","The Geographical Pivot of History","United Nations","European Union","NATO","Antarctic Treaty System","Tragedy of the commons"],
  q:[["Who proposed the heartland theory?","Halford Mackinder","Alfred Thayer Mahan","Nicholas Spykman","Friedrich Ratzel"],
     ["Which country is NOT a permanent member of the UN Security Council?","Germany","France","China","Russia"],
     ["How many member states does the EU have after Brexit?","27","28","25","30"],
     ["Which countries joined NATO in 2023 and 2024?","Finland and Sweden","Ukraine and Georgia","Austria and Ireland","Serbia and Moldova"],
     ["Which 1959 treaty reserved Antarctica for peaceful research?","The Antarctic Treaty","The Outer Space Treaty","The Law of the Sea","The Madrid Protocol"],
     ["Who showed that communities can successfully manage common resources?","Elinor Ostrom","Garrett Hardin","Amartya Sen","Jane Jacobs"]]}

);


/* ---- from geo-10.js ---- */
/* GEOGRAPHY FOUNDATIONS, part 10: Unit 6 The Americas and Europe, chapters 1-5 */
COURSES.geography.units.push({ t:"Regions: The Americas and Europe", ch:[

{ t:"The United States: Land and Regions", s:"The physical geography of a continental nation",
  sec:[
  ["A continental country",[
    "The United States is the third or fourth largest country by area (depending on how waters are counted), about 9.8 million square kilometers, and the third most populous, with over 335 million people. Its 48 contiguous states stretch about 4,500 kilometers from the Atlantic to the Pacific, and it also includes Alaska, the largest state, purchased from Russia in 1867, and Hawaii, a Pacific archipelago annexed in 1898 and admitted as the 50th state in 1959.",
    "The country also has territories, including Puerto Rico, Guam, the U.S. Virgin Islands, American Samoa, and the Northern Mariana Islands. Washington, D.C., the capital, is a federal district outside any state."]],
  ["Physical regions of the East",[
    "Along the Atlantic and Gulf coasts lies the Coastal Plain, low and flat, with barrier islands, swamps, and good harbors; it widens in the South and includes Florida. Inland, the Piedmont, a rolling plateau, rises to the Appalachian Mountains, an ancient, worn-down range running from Alabama to Maine and on into Canada. Mount Mitchell in North Carolina is its highest peak. Where rivers drop from the Piedmont to the Coastal Plain, the Fall Line provided water power for early mill towns such as Richmond and Philadelphia.",
    "West of the Appalachians lie the Interior Lowlands and the Great Lakes, shaped by ice-age glaciers; the five lakes, Superior, Michigan, Huron, Erie, and Ontario, hold about a fifth of the world's fresh surface water. The Mississippi River, with its great tributaries the Missouri and Ohio, drains about 40 percent of the contiguous states into the Gulf of Mexico."]],
  ["The Great Plains and the West",[
    "The Great Plains rise gradually westward from the Mississippi to the Rocky Mountains, a vast grassland that is now one of the world's great farming regions. Their dividing line is often placed near the 100th meridian, west of which annual rainfall is generally too low for crops without irrigation.",
    "The Rocky Mountains, young and rugged, run from New Mexico to Alaska and contain the Continental Divide. Between the Rockies and the Pacific ranges lie the Intermountain region of basins and plateaus, including the Colorado Plateau, with the Grand Canyon, and the Great Basin, whose rivers drain to no ocean. Along the Pacific are the Sierra Nevada, the Cascade Range with volcanoes such as Mount Rainier and Mount St. Helens, and the Coast Ranges, with the fertile Central Valley of California between. Denali in Alaska, at 6,190 meters, is North America's highest peak, while Death Valley is its lowest point."]],
  ["Climates",[
    "The United States spans almost every climate type. The Northeast and Midwest have humid continental climates with cold winters; the Southeast is humid subtropical; southern Florida is tropical. The Great Plains are semi-arid, and the Southwest contains deserts such as the Mojave, Sonoran, and Chihuahuan. California has a Mediterranean climate, the Pacific Northwest a marine west coast climate, Alaska subarctic and tundra, and Hawaii tropical.",
    "The country experiences more tornadoes than any other, hurricanes along the Gulf and Atlantic coasts, blizzards, droughts, and wildfires in the West."]],
  ["Cultural regions",[
    "Americans commonly divide the country into regions. The U.S. Census Bureau uses four: the Northeast, the Midwest, the South, and the West. New England, the Mid-Atlantic, the South, the Midwest or Heartland, the Southwest, the Mountain West, and the Pacific Coast are familiar vernacular regions, each with distinct histories, economies, and cultures.",
    "The Sun Belt, stretching across the South and Southwest, has grown rapidly since the 1960s thanks to air conditioning, lower costs, and new industries, while the Rust Belt of the Great Lakes region lost manufacturing jobs. The Bible Belt describes a region of the South where evangelical Protestantism is especially strong."]],
  ["Resources and environment",[
    "The United States is richly endowed with fertile soil, fresh water, forests, coal, oil, natural gas, and minerals. The Midwest's Corn Belt and the wheat fields of the Plains make it one of the world's largest food exporters. The Ogallala Aquifer supports irrigation across the Plains but is being depleted.",
    "The national park system, beginning with Yellowstone in 1872, protects landscapes such as Yosemite, the Grand Canyon, and the Everglades. Environmental challenges include water scarcity in the West, especially along the overallocated Colorado River, wildfires, coastal erosion, and the effects of climate change."]]
  ],
  terms:[["Appalachian Mountains","An old, worn range in the eastern United States."],["Fall Line","Where Piedmont rivers drop to the Coastal Plain."],["Great Plains","The semi-arid grasslands east of the Rockies."],["100th meridian","The approximate dividing line between humid and dry America."],["Continental Divide","The line separating rivers flowing to the Pacific from those flowing to the Atlantic."],["Great Basin","A region of the West with no drainage to the sea."],["Sun Belt","The fast-growing southern and southwestern states."],["Rust Belt","The deindustrialized Great Lakes and Northeast region."]],
  w:"The physical geography of the United States, from its fertile interior to its varied climates, underpins its agriculture, settlement, and power.",
  src:["Geography of the United States","Appalachian Mountains","Great Plains","Rocky Mountains","Mississippi River","Great Lakes","Sun Belt"],
  q:[["From which country did the United States buy Alaska?","Russia","Canada","Britain","Spain"],
     ["Which river system drains about 40 percent of the contiguous states?","The Mississippi","The Colorado","The Columbia","The Ohio"],
     ["Which meridian roughly divides humid and dry America?","The 100th","The 90th","The 110th","The 80th"],
     ["What is the highest peak in North America?","Denali","Mount Whitney","Mount Rainier","Mount Elbert"],
     ["Which range contains volcanoes such as Mount St. Helens?","The Cascades","The Sierra Nevada","The Rockies","The Appalachians"],
     ["Which fast-growing region stretches across the South and Southwest?","The Sun Belt","The Rust Belt","The Corn Belt","The Bible Belt"]]},

{ t:"The United States: People and Economy", s:"A nation of immigrants and the world's largest economy",
  sec:[
  ["Peopling the country",[
    "Native Americans had lived in North America for at least 15,000 years before European arrival, in hundreds of nations. Today there are 574 federally recognized tribes, and the largest reservation is that of the Navajo Nation in the Southwest. European colonization, beginning with the Spanish in Florida (St. Augustine, 1565), the English at Jamestown (1607) and Plymouth (1620), the Dutch in New Amsterdam (later New York), and the French along the Mississippi, displaced Indigenous peoples.",
    "Enslaved Africans were brought in large numbers until 1808, and their descendants shaped the culture of the South and the nation. Waves of immigration followed: Irish and Germans in the mid-19th century; Italians, Poles, Jews, and others from southern and eastern Europe around 1900; and, since the 1965 Immigration Act, mostly Latin Americans and Asians."]],
  ["Population patterns today",[
    "About 80 percent of Americans live in urban areas. The largest metropolitan areas are New York, Los Angeles, Chicago, Dallas–Fort Worth, Houston, Washington, Philadelphia, Atlanta, and Miami. The most populous states are California, Texas, Florida, New York, and Pennsylvania; the least populous is Wyoming. The population center of the country has moved steadily west and south since 1790.",
    "The Northeast Corridor from Boston to Washington, a continuous urbanized region the geographer Jean Gottmann called a megalopolis in 1961, is home to over 50 million people. The United States is increasingly diverse: Hispanic and Latino Americans are the largest minority group, about a fifth of the population, followed by Black Americans and Asian Americans."]],
  ["The world's largest economy",[
    "The United States has had the world's largest economy since the late 19th century, accounting for about a quarter of global GDP. Its strengths include abundant resources, a large internal market, leading universities, deep financial markets centered on New York, and global technology companies concentrated in Silicon Valley and Seattle.",
    "Services dominate employment. Major industrial regions include the Great Lakes auto industry, aerospace in Washington State and the South, oil and petrochemicals in Texas and Louisiana, and entertainment in Los Angeles. Agriculture, though employing few people, makes the country a leading exporter of corn, soybeans, wheat, and meat."]],
  ["Regional economies",[
    "Each region has distinctive economic strengths. The Northeast is a center of finance, education, health care, and government. The Midwest combines manufacturing with agriculture. The South has grown through manufacturing, including foreign car plants, energy, and services; Texas is the leading oil and gas producer. The West includes California, which alone would rank among the world's largest economies, with technology, entertainment, agriculture in the Central Valley, and trade through the ports of Los Angeles and Long Beach.",
    "Alaska relies on oil, fishing, and federal spending; Hawaii on tourism and military bases."]],
  ["Political geography",[
    "The United States is a federal republic of 50 states, each with its own government. Representation in the House of Representatives is allocated by population after each census, while each state has two senators regardless of size. The Electoral College, through which presidents are elected, gives weight to states and makes a handful of swing states decisive.",
    "Political divisions have a strong geographic pattern: densely populated urban areas tend to vote Democratic, while rural areas tend to vote Republican, an urban-rural divide visible within nearly every state."]],
  ["Challenges",[
    "Geographic challenges include regional inequality between thriving metropolitan areas and struggling rural regions and former industrial towns; housing affordability in coastal cities; water scarcity in the Southwest; vulnerability of coastal areas to hurricanes and rising seas; and debates over immigration across the roughly 3,100-kilometer southern border with Mexico.",
    "The country's long border with Canada, about 8,900 kilometers including Alaska, is the longest international border in the world, largely undefended, reflecting close ties between the two countries."]]
  ],
  terms:[["Federally recognized tribe","A Native American nation with a government-to-government relationship with the U.S."],["Megalopolis","A chain of connected metropolitan areas, such as Boston to Washington."],["Population center","The point at which a country's population would balance."],["Electoral College","The system of state electors that chooses the U.S. president."],["Urban-rural divide","Differences in politics and economy between cities and countryside."]],
  w:"The geography of American people and economy explains its diversity, regional differences, and political divisions, and its outsized role in the world.",
  src:["Demographics of the United States","Immigration to the United States","Megalopolis","Economy of the United States","Northeast megalopolis","Canada–United States border"],
  q:[["What was the first permanent English settlement in North America?","Jamestown","Plymouth","St. Augustine","New Amsterdam"],
     ["Which is the largest Native American reservation?","The Navajo Nation","Pine Ridge","Cherokee Nation","Standing Rock"],
     ["Who coined the term megalopolis for the Boston-Washington corridor?","Jean Gottmann","Walter Christaller","Jane Jacobs","Lewis Mumford"],
     ["What is the largest minority group in the United States?","Hispanic and Latino Americans","Black Americans","Asian Americans","Native Americans"],
     ["Which state is the leading U.S. producer of oil and gas?","Texas","Alaska","California","North Dakota"],
     ["What is the longest international border in the world?","Canada–United States","Russia–Kazakhstan","Argentina–Chile","China–Mongolia"]]},

{ t:"Canada", s:"A vast northern nation",
  sec:[
  ["Size and land",[
    "Canada is the second-largest country in the world by area, about 10 million square kilometers, yet it has only about 40 million people. It has the world's longest coastline, bordering the Atlantic, Pacific, and Arctic oceans, and more lakes than any other country. Ottawa is the capital; Toronto, Montreal, and Vancouver are the largest cities.",
    "The heart of Canada is the Canadian Shield, a vast region of ancient rock, lakes, and forest surrounding Hudson Bay, scraped bare by glaciers and rich in minerals. To the west lie the Interior Plains (the Prairies), then the Rocky Mountains and Coast Mountains of British Columbia. In the east are the Appalachian region of the Maritime provinces and the fertile Great Lakes–St. Lawrence Lowlands. The Arctic Archipelago stretches toward the North Pole; Canada's highest peak is Mount Logan in the Yukon."]],
  ["Climate and settlement",[
    "Most of Canada has subarctic or tundra climates, with long, very cold winters. As a result, about three-quarters of Canadians live within about 160 kilometers of the U.S. border, and over half live in the corridor from Quebec City to Windsor along the St. Lawrence River and Great Lakes. Vancouver, with a mild marine climate, is the major Pacific city.",
    "The North, comprising Yukon, the Northwest Territories, and Nunavut, covers about 40 percent of the country but has only around 130,000 people. Nunavut, created in 1999, has an Inuit majority and its own government."]],
  ["Provinces and peoples",[
    "Canada is a federation of ten provinces and three territories. The provinces are, from west to east, British Columbia, Alberta, Saskatchewan, Manitoba, Ontario, Quebec, New Brunswick, Nova Scotia, Prince Edward Island, and Newfoundland and Labrador. Ontario is the most populous; Quebec is the largest by area.",
    "Indigenous peoples, the First Nations, Inuit, and Métis, make up about 5 percent of the population. Canada is officially bilingual; about a fifth of Canadians speak French as their first language, most of them in Quebec, whose distinct culture and history have fueled a sovereignty movement; independence referendums failed in 1980 and, very narrowly, in 1995. Canada has one of the highest immigration rates in the world, and Toronto and Vancouver are among the most diverse cities on Earth."]],
  ["Economy",[
    "Canada has a high-income economy built on services, manufacturing, and natural resources. It is a major producer of oil, especially from the oil sands of Alberta, which give it one of the world's largest oil reserves; natural gas; hydroelectric power, particularly in Quebec and British Columbia; uranium; potash; timber; and metals. The Prairies are a great wheat and canola region.",
    "Manufacturing, including automobiles, is concentrated in southern Ontario, closely integrated with the U.S. industry. About three-quarters of Canada's exports go to the United States, under the USMCA trade agreement."]],
  ["Environment and the Arctic",[
    "Canada holds about a quarter of the world's remaining boreal forest and some of its largest freshwater reserves. Climate change is warming northern Canada about three times faster than the global average, thawing permafrost and opening the Northwest Passage, the sea route through the Arctic Archipelago that explorers sought for centuries.",
    "Canada claims the Northwest Passage as internal waters, while the United States and others consider it an international strait. Wildfires, such as the record-breaking fires of 2023, have become a growing concern."]],
  ["History in brief",[
    "Canada grew from French colonies in New France and British colonies. Britain gained New France in 1763. Confederation in 1867 created the Dominion of Canada, which expanded to the Pacific, with British Columbia joining in 1871 on the promise of a transcontinental railway, completed in 1885. Newfoundland joined only in 1949.",
    "Canada gained full legislative independence through the Statute of Westminster (1931) and patriated its constitution, adding the Charter of Rights and Freedoms, in 1982. It remains a constitutional monarchy within the Commonwealth."]]
  ],
  terms:[["Canadian Shield","Ancient rock region surrounding Hudson Bay."],["Prairies","The grasslands of Alberta, Saskatchewan, and Manitoba."],["Nunavut","Canada's Inuit-majority territory created in 1999."],["Oil sands","Deposits of bitumen in Alberta."],["Northwest Passage","The Arctic sea route through Canada's archipelago."],["Confederation","The 1867 union forming the Dominion of Canada."]],
  w:"Canada's vast territory, cold climate, and resource wealth shape a population concentrated in the south, closely tied to the United States, and increasingly diverse.",
  src:["Canada","Geography of Canada","Canadian Shield","Provinces and territories of Canada","Quebec","Athabasca oil sands","Northwest Passage"],
  q:[["What is the capital of Canada?","Ottawa","Toronto","Montreal","Vancouver"],
     ["What rocky region surrounds Hudson Bay?","The Canadian Shield","The Prairies","The Cordillera","The Laurentians"],
     ["Which territory, created in 1999, has an Inuit majority?","Nunavut","Yukon","Northwest Territories","Labrador"],
     ["Which province is the most populous?","Ontario","Quebec","British Columbia","Alberta"],
     ["Where are Canada's oil sands?","Alberta","Saskatchewan","Ontario","Newfoundland"],
     ["What is Canada's highest peak?","Mount Logan","Mount Robson","Denali","Mount Waddington"]]},

{ t:"Mexico", s:"Mountains, plateaus, and a megacity",
  sec:[
  ["Land",[
    "Mexico, with about 130 million people, is the world's most populous Spanish-speaking country. Its landscape is dominated by the Mexican Plateau, a high central region framed by two mountain ranges, the Sierra Madre Occidental in the west and the Sierra Madre Oriental in the east. To the south, the Trans-Mexican Volcanic Belt includes Pico de Orizaba (Citlaltépetl), the country's highest peak at about 5,600 meters, and the active Popocatépetl.",
    "Other regions include the long, narrow Baja California peninsula, the arid north with the Sonoran and Chihuahuan deserts, the Gulf Coastal Plain, and the flat limestone Yucatán Peninsula, which has no surface rivers but thousands of cenotes. The Chicxulub crater, linked to the extinction of the dinosaurs, lies buried beneath it."]],
  ["Climate and vertical zones",[
    "The Tropic of Cancer crosses Mexico, which has climates ranging from desert in the north to tropical rainforest in the south. Altitude moderates temperatures: Mexico City, at about 2,240 meters, has a mild climate despite its tropical latitude.",
    "Mexicans traditionally describe altitude zones: tierra caliente in the hot lowlands, tierra templada where most people live and coffee grows, and tierra fría at higher elevations. Hurricanes strike both coasts."]],
  ["People and culture",[
    "Mexico's population is predominantly mestizo, of mixed Indigenous and European ancestry, with large Indigenous communities speaking languages such as Nahuatl, the language of the Aztecs, and Maya, especially in the south. The country is rich in pre-Columbian heritage, from Teotihuacan to Chichén Itzá, and colonial cities such as Puebla, Guanajuato, and Oaxaca.",
    "Mexico City, built on the site of the Aztec capital Tenochtitlan on a former lake bed, is the heart of one of the largest urban areas in the Western Hemisphere, with over 21 million people. Its location on soft lake sediments makes it vulnerable to earthquakes and subsidence. Other major cities are Guadalajara and Monterrey, an industrial center in the north."]],
  ["Economy",[
    "Mexico has the second-largest economy in Latin America. Oil, nationalized in 1938 and managed by the state company Pemex, was long central to the economy. Since the 1990s, manufacturing has boomed, especially in the north, where maquiladoras assemble cars, electronics, and appliances for export to the United States. Mexico became the largest trading partner of the United States in the 2020s, a trend strengthened by nearshoring.",
    "Tourism is a major industry, centered on beach resorts such as Cancún and on cultural sites. Agriculture produces maize, which originated in Mexico, as well as avocados, tomatoes, and other crops exported north. Remittances from Mexicans in the United States are a major source of income."]],
  ["Regions and inequality",[
    "Mexico shows strong regional contrasts. The north, near the U.S. border, is more industrialized and prosperous; the center around Mexico City is the political and economic core; the south, including Chiapas, Oaxaca, and Guerrero, is poorer, more rural, and more Indigenous. The Zapatista uprising in Chiapas in 1994 drew attention to Indigenous rights and poverty.",
    "Challenges include inequality, violence linked to drug trafficking cartels, water shortages in Mexico City and the north, and migration through Mexico from Central America toward the United States."]],
  ["The border",[
    "The U.S.-Mexico border, about 3,100 kilometers long, follows the Rio Grande (called the Río Bravo in Mexico) from the Gulf of Mexico to El Paso–Ciudad Juárez and then mostly straight lines across the desert to the Pacific near Tijuana–San Diego. It is the most frequently crossed international border in the world.",
    "Twin cities along the border, linked by trade, commuting, and family ties, form a distinctive borderland region. The border's location reflects the Mexican-American War (1846–1848), after which Mexico lost about half its territory, including California, Texas, and much of the Southwest, and the Gadsden Purchase of 1853."]]
  ],
  terms:[["Mexican Plateau","The high central region between the Sierra Madres."],["Sierra Madre","Mexico's two great mountain ranges."],["Mestizo","A person of mixed Indigenous and European ancestry."],["Tenochtitlan","The Aztec capital beneath Mexico City."],["Maquiladora","An export assembly plant in northern Mexico."],["Nearshoring","Moving production closer to consumer markets."]],
  w:"Mexico's mountains, plateaus, and border with the United States shape its people, economy, and its deep ties to its northern neighbor.",
  src:["Mexico","Geography of Mexico","Mexican Plateau","Mexico City","Economy of Mexico","Mexico–United States border"],
  q:[["What is Mexico's highest peak?","Pico de Orizaba","Popocatépetl","Iztaccíhuatl","Nevado de Toluca"],
     ["Which ranges frame the Mexican Plateau?","The Sierra Madre Occidental and Oriental","The Andes and Rockies","The Sierra Nevada and Cascades","The Appalachians"],
     ["On the site of which Aztec city was Mexico City built?","Tenochtitlan","Teotihuacan","Tula","Texcoco"],
     ["Which crop originated in Mexico?","Maize","Wheat","Rice","Potatoes"],
     ["Which northern Mexican city is a major industrial center?","Monterrey","Oaxaca","Mérida","Acapulco"],
     ["What is the Rio Grande called in Mexico?","Río Bravo","Río Lerma","Río Balsas","Río Usumacinta"]]},

{ t:"Central America and the Caribbean", s:"Isthmus and islands",
  sec:[
  ["The isthmus",[
    "Central America is the narrow land bridge, or isthmus, linking North and South America. It consists of seven countries: Guatemala, Belize, Honduras, El Salvador, Nicaragua, Costa Rica, and Panama. Its formation about 3 million years ago allowed animals to migrate between the continents and changed ocean currents.",
    "A volcanic mountain chain runs down the Pacific side, with frequent earthquakes and eruptions; volcanic soils in the highlands are fertile. The Caribbean side has lowlands, rainforests, and the Mosquito Coast. Lake Nicaragua is the largest lake in Central America."]],
  ["People and history",[
    "The Maya civilization flourished in Guatemala, Belize, Honduras, and southern Mexico, and millions of Maya people still live in Guatemala. Spain colonized most of the region; Belize was British Honduras until its independence in 1981, and English is its official language.",
    "In the 20th century, banana companies such as the United Fruit Company dominated economies, and the region suffered dictatorships and civil wars in Guatemala, El Salvador, and Nicaragua. Costa Rica abolished its army in 1948 and became a stable democracy known for ecotourism and conservation, with about a quarter of its land protected."]],
  ["The Panama Canal",[
    "Panama, which separated from Colombia in 1903 with U.S. support, is home to the Panama Canal, completed by the United States in 1914 after a failed French attempt. The canal uses locks to lift ships over the isthmus through the artificial Gatun Lake, saving the long voyage around South America.",
    "The United States controlled the Canal Zone until it was handed over to Panama on 31 December 1999. An expanded set of locks opened in 2016 for larger ships. Droughts in 2023 lowered water levels and restricted shipping, highlighting the canal's dependence on rainfall."]],
  ["The Caribbean islands",[
    "The Caribbean includes the Greater Antilles, the large islands of Cuba, Hispaniola (shared by Haiti and the Dominican Republic), Jamaica, and Puerto Rico; the Lesser Antilles, a chain of smaller islands, many volcanic, from the Virgin Islands to Trinidad; and the Bahamas, low coral islands in the Atlantic. Cuba is the largest island.",
    "The islands have tropical climates moderated by trade winds and lie in the path of Atlantic hurricanes. Many have mountainous interiors; Pico Duarte in the Dominican Republic is the highest point in the Caribbean."]],
  ["A colonial legacy",[
    "After Columbus's arrival in 1492, the Indigenous Taíno and Carib populations were devastated by disease and violence. Europeans, Spanish, British, French, Dutch, and Danish, turned the islands into sugar plantation colonies worked by millions of enslaved Africans, so most Caribbean populations today are of African or mixed descent. Indentured laborers from India later came to Trinidad and Guyana.",
    "Haiti became the first independent Black republic in 1804 after a successful slave revolution. Languages reflect colonial history: Spanish in Cuba, the Dominican Republic, and Puerto Rico; English in Jamaica, the Bahamas, Barbados, and Trinidad; French and Haitian Creole in Haiti; Dutch and Papiamento in Aruba and Curaçao. Several islands remain dependencies of France, the Netherlands, Britain, and the United States."]],
  ["Economies and challenges",[
    "Tourism dominates many Caribbean economies, along with offshore finance in places such as the Cayman Islands and the Bahamas. Agriculture, including sugar, bananas, and rum, has declined. Trinidad and Tobago has oil and gas, and Guyana, on the South American mainland but culturally Caribbean, became a major oil producer in the 2020s.",
    "Challenges include hurricanes, such as Hurricane Maria, which devastated Puerto Rico and Dominica in 2017; earthquakes, notably in Haiti in 2010; dependence on imported food and fuel; and sea level rise. Haiti remains the poorest country in the Americas. In Central America, poverty, violence, and drought have driven migration north."]]
  ],
  terms:[["Isthmus","A narrow strip of land connecting two larger landmasses."],["Panama Canal","The canal across Panama completed in 1914."],["Greater Antilles","The large Caribbean islands: Cuba, Hispaniola, Jamaica, Puerto Rico."],["Lesser Antilles","The chain of smaller eastern Caribbean islands."],["Hispaniola","The island shared by Haiti and the Dominican Republic."],["Plantation economy","An economy based on large export-crop estates."]],
  w:"Central America and the Caribbean are shaped by volcanoes, hurricanes, the Panama Canal, and a colonial legacy of plantations and slavery that still defines their cultures.",
  src:["Central America","Panama Canal","Caribbean","Greater Antilles","Lesser Antilles","Costa Rica","Haiti"],
  q:[["How many countries are in Central America?","Seven","Five","Nine","Six"],
     ["Which Central American country has English as its official language?","Belize","Honduras","Costa Rica","Panama"],
     ["Which country abolished its army in 1948?","Costa Rica","Panama","Nicaragua","El Salvador"],
     ["When was the Panama Canal handed over to Panama?","1999","1914","1977","2016"],
     ["Which two countries share Hispaniola?","Haiti and the Dominican Republic","Cuba and Jamaica","Puerto Rico and the Dominican Republic","Haiti and Jamaica"],
     ["What is the largest Caribbean island?","Cuba","Hispaniola","Jamaica","Puerto Rico"]]}

]});


/* ---- from geo-11.js ---- */
/* GEOGRAPHY FOUNDATIONS, part 11: Unit 6 chapters 6-10 */
COURSES.geography.units[5].ch.push(

{ t:"South America: The Physical Continent", s:"Andes, Amazon, and plains",
  sec:[
  ["Shape and setting",[
    "South America is the fourth-largest continent, stretching from the Caribbean coast of Colombia and Venezuela, north of the Equator, to Cape Horn at about 56° S, the southernmost tip of its mainland region. It has twelve independent countries plus French Guiana, an overseas department of France, and the British-controlled Falkland Islands, which Argentina claims as the Malvinas.",
    "The continent has three great physical regions: the Andes mountains along the west; the vast lowland river basins of the Orinoco, Amazon, and Paraná–Paraguay in the center; and the old highlands of the Guiana Shield and Brazilian Highlands in the east."]],
  ["The Andes",[
    "The Andes are the longest continental mountain range in the world, about 7,000 kilometers, formed by the subduction of the Nazca plate beneath South America. They contain many active volcanoes and are prone to earthquakes. Aconcagua in Argentina, at about 6,960 meters, is the highest mountain outside Asia. Ojos del Salado, on the Chile–Argentina border, is the highest active volcano on Earth.",
    "In Bolivia and Peru, the Andes widen into the Altiplano, a high plateau averaging about 3,750 meters, home to Lake Titicaca and La Paz, the world's highest seat of government at about 3,640 meters. The Andes create sharp contrasts: the Atacama Desert lies in their rain shadow on the Pacific side."]],
  ["The Amazon",[
    "The Amazon River flows about 6,400 kilometers from the Peruvian Andes to the Atlantic and has the largest drainage basin and discharge of any river, about a fifth of all river water entering the oceans. It has over 1,100 tributaries; at its mouth it can be many kilometers wide, and it has no bridges along its main channel.",
    "The Amazon rainforest, the largest tropical rainforest on Earth, covers parts of nine countries, about 60 percent of it in Brazil. It contains roughly 10 percent of the world's known species and stores vast amounts of carbon. Its trees release so much moisture that they generate “flying rivers” that bring rain to southern Brazil and beyond."]],
  ["Plains, highlands, and wetlands",[
    "The Llanos are tropical grasslands in the Orinoco basin of Venezuela and Colombia. The Gran Chaco is a hot, dry lowland shared by Paraguay, Bolivia, and Argentina. The Pantanal, mostly in Brazil, is the world's largest tropical wetland, famous for jaguars and caimans. The Pampas of Argentina and Uruguay are among the most fertile grasslands on Earth.",
    "The Guiana Highlands contain tepuis, flat-topped table mountains, and Angel Falls in Venezuela, the world's tallest uninterrupted waterfall at about 979 meters. Iguazú Falls, on the Argentina–Brazil border, is one of the largest waterfall systems in the world. Patagonia, in southern Argentina and Chile, is a windswept land of steppes, glaciers, and fjords."]],
  ["Climates",[
    "South America has every major climate type. Equatorial regions are hot and wet; savannas lie to the north and south of the Amazon; the Atacama, cooled by the Humboldt Current and lying in the rain shadow of the Andes, is the driest non-polar desert on Earth. Central Chile has a Mediterranean climate; southern Chile has a wet marine climate with temperate rainforests; and Patagonia is cold and dry.",
    "El Niño strongly affects the Pacific coast, bringing heavy rains and floods to normally dry northern Peru and Ecuador."]],
  ["Settlement patterns",[
    "Most South Americans live near the coasts, a pattern established in colonial times when settlements faced the sea for trade with Europe. The interior, especially the Amazon basin, is sparsely populated, though roads and agriculture have pushed settlement inland. In the Andean countries, many people live in highland valleys and basins, where the climate is mild, as in Bogotá and Quito.",
    "South America is one of the most urbanized regions of the world, with about 80 percent of people living in cities, including the megacities of São Paulo, Buenos Aires, Rio de Janeiro, Lima, and Bogotá."]]
  ],
  terms:[["Andes","The longest continental mountain range, along South America's west."],["Altiplano","The high Andean plateau of Bolivia and Peru."],["Amazon basin","The largest river basin in the world."],["Pantanal","The world's largest tropical wetland."],["Pampas","The fertile grasslands of Argentina and Uruguay."],["Tepui","A flat-topped table mountain of the Guiana Highlands."],["Patagonia","The cold, windswept south of Argentina and Chile."]],
  w:"South America's Andes, Amazon, and great plains create extraordinary environmental diversity and shape where its people live and how they make a living.",
  src:["South America","Andes","Altiplano","Amazon River","Amazon rainforest","Angel Falls","Patagonia"],
  q:[["What is the highest mountain outside Asia?","Aconcagua","Chimborazo","Huascarán","Ojos del Salado"],
     ["Which is the world's highest seat of government?","La Paz","Quito","Bogotá","Cusco"],
     ["Which plate subducts beneath South America to form the Andes?","The Nazca plate","The Pacific plate","The Cocos plate","The Caribbean plate"],
     ["Which is the world's tallest uninterrupted waterfall?","Angel Falls","Iguazú Falls","Victoria Falls","Niagara Falls"],
     ["What is the world's largest tropical wetland?","The Pantanal","The Llanos","The Okavango","The Everglades"],
     ["Which desert is the driest non-polar desert?","The Atacama","The Patagonian","The Sechura","The Sahara"]]},

{ t:"Brazil", s:"Latin America's giant",
  sec:[
  ["Size and land",[
    "Brazil is the fifth-largest country in the world by area and the seventh most populous, with about 215 million people, covering nearly half of South America. It borders every South American country except Chile and Ecuador. It is the largest Portuguese-speaking country, a legacy of Portuguese colonization beginning in 1500.",
    "Brazil's landscapes include the Amazon basin in the north; the Brazilian Highlands, a vast plateau covering much of the center and south; the Cerrado, a tropical savanna in the center that is one of the most biodiverse savannas on Earth; the Pantanal wetland; the semi-arid Sertão of the northeast, prone to drought; and the Atlantic Forest along the coast, of which only a small fraction remains."]],
  ["Regions",[
    "Brazil is divided into five regions. The Southeast, including São Paulo, Rio de Janeiro, and Minas Gerais, is the economic core, with nearly half the population. The South, settled by many European immigrants including Germans and Italians, is relatively prosperous and agricultural. The Northeast, the first area colonized, built on sugar and slavery, has a strong Afro-Brazilian culture, with cities such as Salvador and Recife, and is the poorest region.",
    "The Center-West, including Brasília and the agricultural frontier of Mato Grosso, has grown rapidly. The North, dominated by the Amazon, is the largest but least populated region, with Manaus, a city in the middle of the rainforest, as its largest city."]],
  ["People",[
    "Brazil's population reflects Indigenous peoples, Portuguese colonists, about 4 to 5 million enslaved Africans brought by the slave trade, the most of any country in the Americas, and later immigrants from Italy, Germany, Spain, Japan, Lebanon, and elsewhere. São Paulo has the largest Japanese community outside Japan. In recent censuses, a majority of Brazilians identified as Black or mixed race (pardo).",
    "Brazil abolished slavery in 1888, the last country in the Americas to do so. It is a highly urbanized country; São Paulo is the largest city in the Southern Hemisphere and the Americas by some measures, and Rio de Janeiro, the former capital, is famous for its setting between mountains and sea and for Carnival."]],
  ["Brasília and the interior",[
    "In 1960 Brazil moved its capital from Rio de Janeiro to Brasília, a planned city built from scratch on the central plateau to encourage development of the interior. Designed by the urban planner Lúcio Costa and the architect Oscar Niemeyer, it is shaped like an airplane or bird and is a UNESCO World Heritage Site.",
    "Roads such as the Trans-Amazonian Highway, begun in the 1970s, opened the Amazon to settlement, logging, ranching, and mining, bringing rapid deforestation."]],
  ["Economy",[
    "Brazil has the largest economy in Latin America. It is an agricultural superpower: the world's largest producer and exporter of coffee, soybeans, sugar, and orange juice, and a leading exporter of beef and chicken. The Cerrado was transformed into a major soybean region from the 1970s through soil improvement and new crop varieties.",
    "Brazil is also a major producer of iron ore, from mines such as Carajás in the Amazon, and of oil, especially from deep offshore “pre-salt” fields. Its industries include aircraft (Embraer), automobiles, and steel. About 80 percent of its electricity comes from renewable sources, especially hydropower, and it is a pioneer of sugarcane ethanol for fuel."]],
  ["Challenges",[
    "Brazil has long been among the most unequal countries in the world, with wealthy neighborhoods next to favelas. Social programs such as Bolsa Família, launched in 2003, reduced poverty. Other challenges include urban violence, corruption, and political polarization.",
    "Deforestation of the Amazon, driven by cattle ranching and soy, rises and falls with government policy and enforcement. As the steward of most of the Amazon, Brazil's choices matter for global climate and biodiversity; it hosted the U.N. climate conference COP30 in Belém in 2025."]]
  ],
  terms:[["Cerrado","Brazil's central tropical savanna."],["Sertão","The drought-prone semi-arid interior of northeastern Brazil."],["Atlantic Forest","The coastal rainforest of Brazil, largely cleared."],["Brasília","Brazil's planned capital, inaugurated in 1960."],["Pardo","A Brazilian census category for mixed-race people."],["Pre-salt","Deep offshore oil deposits beneath salt layers."]],
  w:"Brazil's size, resources, diversity, and stewardship of the Amazon make it central to Latin America and to global food, energy, and climate.",
  src:["Brazil","Regions of Brazil","Cerrado","Brasília","Economy of Brazil","São Paulo","Deforestation of the Amazon rainforest"],
  q:[["What language is spoken in Brazil?","Portuguese","Spanish","French","Italian"],
     ["Which South American countries do NOT border Brazil?","Chile and Ecuador","Peru and Bolivia","Uruguay and Paraguay","Colombia and Venezuela"],
     ["Which Brazilian region is the economic core?","The Southeast","The Northeast","The North","The Center-West"],
     ["When did Brazil move its capital to Brasília?","1960","1888","1922","1985"],
     ["Who designed Brasília's plan?","Lúcio Costa","Oscar Niemeyer","Le Corbusier","Roberto Burle Marx"],
     ["Of which crop is Brazil the world's largest producer?","Coffee","Rice","Wheat","Cocoa"]]},

{ t:"The Andean Countries", s:"Colombia, Venezuela, Ecuador, Peru, and Bolivia",
  sec:[
  ["Mountain nations",[
    "The Andean countries share the Andes Mountains, which divide each into coastal lowlands, highlands, and Amazonian interior. Altitude shapes life: the Andes were home to the Inca Empire, centered on Cusco, and today Indigenous peoples speaking Quechua and Aymara form large shares of the population of Peru, Bolivia, and Ecuador.",
    "Andean farmers developed potatoes, of which thousands of varieties exist, quinoa, and the domestication of llamas and alpacas, and built terraces on steep slopes. Vertical zonation allows farmers to grow tropical crops in the valleys and potatoes and grazing at high elevations."]],
  ["Colombia",[
    "Colombia, with about 52 million people, is the only South American country with coasts on both the Pacific and the Caribbean. The Andes split into three ranges there, with the Magdalena and Cauca river valleys between them. Bogotá, the capital, sits at about 2,640 meters; Medellín and Cali are other major cities.",
    "Colombia is famous for coffee grown in its mild highlands, flowers, emeralds, oil, and coal. It suffered decades of armed conflict involving guerrillas such as the FARC, paramilitaries, and drug cartels; a peace agreement with the FARC was signed in 2016. Colombia is one of the most biodiverse countries on Earth, with the most bird species of any country."]],
  ["Venezuela",[
    "Venezuela, on the Caribbean coast, has the world's largest proven oil reserves, concentrated around Lake Maracaibo and in the Orinoco Belt. Its landscapes include the Andes, the Llanos grasslands, the Orinoco River, and the Guiana Highlands with Angel Falls. Caracas is the capital.",
    "Oil wealth made Venezuela one of the richest Latin American countries in the mid-20th century, but dependence on oil, mismanagement, and political crisis under the governments of Hugo Chávez and Nicolás Maduro led to economic collapse in the 2010s. Over 7 million Venezuelans have emigrated, one of the largest displacement crises in the world."]],
  ["Ecuador",[
    "Ecuador takes its name from the Equator, which passes just north of its capital, Quito, one of the highest capitals at about 2,850 meters. The country's “Avenue of the Volcanoes” includes Cotopaxi and Chimborazo; because of the Earth's equatorial bulge, Chimborazo's summit is the point on Earth's surface farthest from its center.",
    "The Galápagos Islands, about 1,000 kilometers offshore, belong to Ecuador. Their unique wildlife, including giant tortoises, marine iguanas, and finches, helped inspire Charles Darwin's theory of evolution after his 1835 visit. Ecuador exports oil, bananas (it is the world's largest banana exporter), shrimp, and cut flowers, and uses the U.S. dollar as its currency. Guayaquil is its largest city and main port."]],
  ["Peru",[
    "Peru, with about 34 million people, has three regions: the costa, a narrow desert coast where Lima, the capital, and most people live; the sierra, the Andean highlands with Cusco and Machu Picchu; and the selva, the Amazon rainforest, where the city of Iquitos can be reached only by river or air. The cold Humboldt Current makes the coast dry and supports one of the world's richest fisheries, especially anchovies.",
    "Peru is a major producer of copper, gold, silver, and zinc, and its cuisine is internationally celebrated. It was the center of the Inca Empire and earlier civilizations such as Caral, the Nazca, known for their giant ground drawings, and the Moche."]],
  ["Bolivia",[
    "Bolivia is landlocked, having lost its coastline to Chile in the War of the Pacific (1879–1884), a loss still mourned. It has a constitutional capital, Sucre, and a seat of government, La Paz; the largest city is Santa Cruz in the eastern lowlands. About half the population is Indigenous, and in 2006 Evo Morales became the country's first Indigenous president.",
    "The Altiplano holds Lake Titicaca, shared with Peru, and the Salar de Uyuni, the world's largest salt flat, which contains huge lithium reserves. Bolivia has long exported silver, from the colonial mines of Potosí, once one of the largest cities in the world, as well as tin and natural gas. It is among the poorest countries in South America."]]
  ],
  terms:[["Quechua","The language of the Inca, still spoken by millions."],["FARC","A Colombian guerrilla group that signed a peace deal in 2016."],["Galápagos Islands","Ecuadorian islands that inspired Darwin."],["Costa, sierra, selva","Peru's three regions: coast, highlands, and jungle."],["War of the Pacific","The 1879–1884 war in which Bolivia lost its coast."],["Salar de Uyuni","The world's largest salt flat, in Bolivia."]],
  w:"The Andean countries combine mountain environments, Indigenous heritage, and resource wealth, with sharp contrasts between coasts, highlands, and rainforest.",
  src:["Andean states","Colombia","Venezuela","Ecuador","Peru","Bolivia","Galápagos Islands"],
  q:[["Which South American country has coasts on both the Pacific and Caribbean?","Colombia","Venezuela","Peru","Panama"],
     ["Which country has the world's largest proven oil reserves?","Venezuela","Ecuador","Colombia","Bolivia"],
     ["Which islands belong to Ecuador?","The Galápagos","The Falklands","Easter Island","The Juan Fernández Islands"],
     ["Where do most Peruvians live?","The desert coast","The Amazon","The Altiplano","The sierra"],
     ["How did Bolivia lose its coastline?","The War of the Pacific","The Chaco War","Independence from Spain","A treaty with Peru"],
     ["Which is the world's largest salt flat?","Salar de Uyuni","Salar de Atacama","Bonneville Salt Flats","Etosha Pan"]]},

{ t:"The Southern Cone", s:"Argentina, Chile, Uruguay, and Paraguay",
  sec:[
  ["A temperate region",[
    "The Southern Cone is the southern, cone-shaped part of South America: Argentina, Chile, and Uruguay, often with Paraguay included. Lying mostly in the mid-latitudes, it has temperate climates and was settled heavily by European immigrants in the late 19th and early 20th centuries, especially Spaniards and Italians, giving it a strongly European-influenced culture.",
    "These countries are among the most developed in Latin America, with high urbanization and literacy, though they have experienced economic crises and, in the 1970s and 1980s, harsh military dictatorships."]],
  ["Argentina",[
    "Argentina is the eighth-largest country in the world by area and the second-largest in South America, with about 46 million people. Its regions include the Pampas, the fertile heartland; the Gran Chaco in the north; the Andes in the west, with Aconcagua; and Patagonia in the south, extending to Tierra del Fuego, shared with Chile, with Ushuaia often called the southernmost city in the world.",
    "About a third of Argentines live in Greater Buenos Aires, a primate city on the Río de la Plata estuary. The Pampas made Argentina one of the world's great exporters of beef, wheat, and soybeans; around 1900 it was one of the richest countries in the world. Since then it has suffered repeated economic crises, inflation, and debt defaults. Argentina also has large shale oil and gas reserves at Vaca Muerta and lithium in the northwest."]],
  ["Chile",[
    "Chile is one of the world's most elongated countries, about 4,300 kilometers long but on average less than 180 kilometers wide, squeezed between the Andes and the Pacific. Its climates range from the Atacama Desert in the north, through a Mediterranean central valley where most people live, including in Santiago, the capital, to rainy forests, fjords, and glaciers in the south.",
    "Chile is the world's largest producer of copper, from mines such as Chuquicamata and Escondida in the Atacama, and a major producer of lithium. It also exports fruit, wine, salmon, and wood. Chile lies on the Ring of Fire and experiences powerful earthquakes, including the 1960 Valdivia earthquake, the strongest ever recorded. It also controls Easter Island (Rapa Nui), famous for its moai statues, in the Pacific."]],
  ["Uruguay and Paraguay",[
    "Uruguay, a small country of about 3.4 million people between Argentina and Brazil, is mostly rolling grassland used for cattle and sheep ranching. About half its people live in Montevideo, the capital. Uruguay is known for political stability, a strong welfare state, and progressive policies, and it generates almost all its electricity from renewable sources.",
    "Paraguay, landlocked, is divided by the Paraguay River into a more populated, humid eastern region, with the capital Asunción, and the dry, sparsely populated Gran Chaco to the west. Guaraní, an Indigenous language, is an official language alongside Spanish and is spoken by most of the population. The Itaipu Dam on the Paraná River, shared with Brazil, is one of the world's largest hydroelectric plants, making Paraguay a major electricity exporter."]],
  ["The Río de la Plata system",[
    "The Paraná, Paraguay, and Uruguay rivers form the second-largest river basin in South America, draining into the Río de la Plata, a broad estuary between Buenos Aires and Montevideo. The system is a vital route for exporting grain and soybeans from the interior.",
    "Iguazú Falls, on the Iguazú River at the border of Argentina and Brazil, near Paraguay, consists of about 275 cascades and is one of the natural wonders of the world."]],
  ["Antarctica and the islands",[
    "Argentina and Chile both claim overlapping sectors of Antarctica, as does Britain, and both maintain research stations there. The Falkland Islands (Islas Malvinas), a British overseas territory in the South Atlantic claimed by Argentina, were the scene of the Falklands War in 1982, in which Britain defeated an Argentine invasion; the dispute remains unresolved.",
    "The Strait of Magellan and the Drake Passage, between Cape Horn and Antarctica, are among the stormiest waters in the world; before the Panama Canal, ships traveling between the Atlantic and Pacific had to round Cape Horn."]]
  ],
  terms:[["Southern Cone","Argentina, Chile, Uruguay, and often Paraguay."],["Pampas","Argentina's fertile grasslands."],["Tierra del Fuego","The archipelago at the southern tip of South America."],["Río de la Plata","The estuary between Buenos Aires and Montevideo."],["Guaraní","An Indigenous language official in Paraguay."],["Falklands War","The 1982 war between Britain and Argentina."]],
  w:"The Southern Cone's temperate lands, European immigrant heritage, and resources such as beef, grain, and copper make it one of Latin America's most developed regions.",
  src:["Southern Cone","Argentina","Chile","Uruguay","Paraguay","Río de la Plata","Falklands War"],
  q:[["What share of Argentines live in Greater Buenos Aires?","About a third","About a tenth","About two-thirds","About half"],
     ["Of which mineral is Chile the world's largest producer?","Copper","Gold","Iron ore","Silver"],
     ["Which island famous for moai statues belongs to Chile?","Easter Island","Chiloé","Tierra del Fuego","The Galápagos"],
     ["Which Indigenous language is official in Paraguay?","Guaraní","Quechua","Aymara","Mapudungun"],
     ["Which dam do Paraguay and Brazil share?","Itaipu","Three Gorges","Guri","Yacyretá"],
     ["What was the 1982 war between Britain and Argentina called?","The Falklands War","The War of the Pacific","The Chaco War","The Paraguayan War"]]},

{ t:"Europe: Land, Climate, and Peoples", s:"A peninsula of peninsulas",
  sec:[
  ["A small, crowded continent",[
    "Europe is the second-smallest continent by area, about 10 million square kilometers, but the third most populous, with about 745 million people. Its eastern boundary with Asia is conventionally drawn along the Ural Mountains and Ural River, the Caspian Sea, and the Caucasus Mountains, though this is a cultural convention rather than a clear physical divide; Europe and Asia together form Eurasia.",
    "Europe is often called a “peninsula of peninsulas”: the Scandinavian, Iberian, Italian, Balkan, and Jutland peninsulas, among others, give it an exceptionally long, indented coastline. No part of western and central Europe is very far from the sea, which encouraged trade, fishing, and maritime exploration."]],
  ["Landforms",[
    "Europe's landforms run in broad belts. In the north, the Northwest Highlands include the old mountains of Scandinavia, Scotland, and Iceland, carved by glaciers into fjords. The North European Plain sweeps from western France across the Netherlands, Germany, and Poland into Russia; it is fertile, densely populated, and historically an easy invasion route.",
    "South of the plain lie the Central Uplands, old, worn hills and plateaus such as the Massif Central in France and the Bohemian Massif. The young Alpine mountain system, formed by the collision of Africa and Europe, includes the Alps, whose highest peak is Mont Blanc (about 4,806 meters), the Pyrenees, the Apennines, the Carpathians, and the Balkan mountains. Mount Elbrus in the Caucasus, at 5,642 meters, is often considered Europe's highest mountain."]],
  ["Rivers and seas",[
    "Europe's navigable rivers have long been highways of trade. The Rhine flows from the Alps through Germany to the Netherlands, where it reaches the sea at Rotterdam, Europe's largest port. The Danube, Europe's second-longest river, flows east from Germany through or along ten countries, including four capitals (Vienna, Bratislava, Budapest, and Belgrade), to the Black Sea. The Volga, entirely in Russia, is Europe's longest river, flowing to the Caspian Sea.",
    "Other important rivers include the Seine, Loire, Rhône, Elbe, Oder, Vistula, Thames, Po, and Dnieper. Seas surrounding Europe include the Mediterranean, the North Sea, the Baltic, the Black Sea, and the Atlantic."]],
  ["Climate",[
    "Western Europe enjoys a mild marine west coast climate far farther north than similar climates elsewhere, thanks to the North Atlantic Current and prevailing westerly winds; London is farther north than Calgary but much milder in winter. Because Europe's main mountains run east-west, maritime air penetrates far inland.",
    "Moving east, climates become more continental, with colder winters and hotter summers. Southern Europe has a Mediterranean climate, while northern Scandinavia and Russia have subarctic and tundra climates. Europe has been warming faster than the global average, with severe heat waves and droughts in recent summers."]],
  ["Peoples and languages",[
    "Europe is home to dozens of nations and languages, mostly Indo-European: Germanic languages in the north and northwest (German, English, Dutch, Swedish, Danish, Norwegian, Icelandic); Romance languages in the south and west (Spanish, Portuguese, French, Italian, Romanian); and Slavic languages in the east (Russian, Ukrainian, Polish, Czech, Slovak, Serbian, Croatian, Bulgarian, and others). Exceptions include Greek, Albanian, the Baltic languages Lithuanian and Latvian, the Celtic languages, and the non-Indo-European Finnish, Estonian, Hungarian, and Basque.",
    "Religious divisions historically separated Catholic southern and central Europe, Protestant northern Europe, and Orthodox eastern and southeastern Europe, with Muslim communities in the Balkans and, through immigration, across Western Europe. Europe is among the most secular regions of the world."]],
  ["Demographics and integration",[
    "Europe has the oldest population of any continent, with low fertility and high life expectancy; many countries' populations would shrink without immigration. Italy, Spain, and much of eastern Europe face declining populations, while immigration from Africa, the Middle East, and Asia has made Western European cities increasingly diverse.",
    "European integration, through the European Union, has created a single market, common currency for most members, and freedom of movement across much of the continent. Europe is one of the world's wealthiest regions, though with a gap between richer western and northern Europe and poorer eastern and southeastern areas."]]
  ],
  terms:[["Eurasia","The combined landmass of Europe and Asia."],["Peninsula of peninsulas","A description of Europe's highly indented shape."],["North European Plain","The fertile lowland from France to Russia."],["Alpine system","The young mountains of southern Europe, including the Alps."],["Rhine and Danube","Europe's great trade rivers."],["North Atlantic Current","The warm current that moderates Europe's climate."]],
  w:"Europe's indented coastline, rivers, mild climate, and many peoples help explain its long history of trade, rivalry, and integration.",
  src:["Europe","Geography of Europe","North European Plain","Alps","Danube","Rhine","Languages of Europe"],
  q:[["Which mountains conventionally separate Europe from Asia?","The Urals","The Alps","The Carpathians","The Pyrenees"],
     ["What is Europe's longest river?","The Volga","The Danube","The Rhine","The Dnieper"],
     ["Which river flows through four capital cities?","The Danube","The Rhine","The Elbe","The Seine"],
     ["What is the highest peak in the Alps?","Mont Blanc","The Matterhorn","Monte Rosa","The Eiger"],
     ["Which of these is NOT an Indo-European language?","Hungarian","Polish","Greek","Lithuanian"],
     ["What makes western Europe's climate mild for its latitude?","The North Atlantic Current and westerlies","The Mediterranean Sea","The Alps","The jet stream blocking Arctic air"]]}

);


/* ---- from geo-12.js ---- */
/* GEOGRAPHY FOUNDATIONS, part 12: Unit 6 chapters 11-15 (Europe) */
COURSES.geography.units[5].ch.push(

{ t:"The British Isles", s:"The United Kingdom and Ireland",
  sec:[
  ["Islands and countries",[
    "The British Isles consist of two large islands, Great Britain and Ireland, and thousands of smaller ones, including the Hebrides, Orkney, Shetland, the Isle of Man, and Anglesey. Politically they contain two sovereign states: the United Kingdom of Great Britain and Northern Ireland, and the Republic of Ireland. The term “British Isles” is disliked by many in Ireland, and some prefer “Britain and Ireland.”",
    "The United Kingdom consists of four countries: England, Scotland, Wales, and Northern Ireland, with about 68 million people. Its capital, London, is one of the world's leading global cities. Since 1999, Scotland, Wales, and Northern Ireland have had devolved parliaments or assemblies. Scotland held an independence referendum in 2014, in which 55 percent voted to remain in the UK."]],
  ["Landscapes",[
    "A rough line from the mouth of the River Tees to the River Exe divides Great Britain into a highland zone in the north and west, with older, harder rocks, and a lowland zone in the south and east, with younger rocks, gentler hills, and better farmland. The Scottish Highlands contain Ben Nevis (1,345 meters), the highest point in the British Isles; other uplands include the Pennines, the “backbone of England,” the Lake District, and Snowdonia in Wales.",
    "The Thames, flowing through London, and the Severn, the longest river in Britain, are the major rivers. Ireland has a central lowland of farmland and bogs ringed by coastal mountains; the River Shannon is its longest river. The famous Giant's Causeway in Northern Ireland consists of thousands of basalt columns formed by ancient lava flows."]],
  ["Climate",[
    "The British Isles have a mild, wet, changeable marine climate, warmed by the North Atlantic Current and dominated by westerly winds that bring frequent depressions from the Atlantic. Western areas, especially mountains, are wettest; parts of the Scottish Highlands receive over 3,000 millimeters of rain a year, while eastern England receives under 600.",
    "Winters are mild for the latitude and summers cool. Ireland's green landscape, which earned it the nickname the Emerald Isle, reflects its abundant rainfall."]],
  ["The UK economy",[
    "Britain was the birthplace of the Industrial Revolution, with industrial regions built on coalfields in the Midlands, northern England, South Wales, and central Scotland, centered on cities such as Manchester, Birmingham, Leeds, Sheffield, Newcastle, and Glasgow. Deindustrialization from the 1970s hit these regions hard.",
    "Today the UK economy is dominated by services, especially finance, centered on the City of London, along with education, creative industries, pharmaceuticals, and aerospace. North Sea oil and gas, developed from the 1970s, were important, and offshore wind is now a major energy source. A persistent North-South divide separates the prosperous South East around London from poorer northern regions. The UK left the European Union in January 2020 following a 2016 referendum."]],
  ["Ireland",[
    "The Republic of Ireland, with about 5.3 million people, won independence from the UK in 1922 after a war of independence, while six counties in the northeast, with a Protestant majority, remained part of the UK as Northern Ireland. The Troubles, a conflict from the late 1960s to 1998 between mainly Catholic nationalists seeking a united Ireland and mainly Protestant unionists, killed over 3,500 people and ended with the Good Friday Agreement of 1998.",
    "The Great Famine of 1845–1852, caused by potato blight and worsened by British policy, killed about a million people and drove another million to emigrate, and Ireland's population has still not returned to its pre-famine level. Once poor and agricultural, Ireland became one of Europe's richest countries after the 1990s as the “Celtic Tiger,” attracting technology and pharmaceutical multinationals with low corporate taxes. Dublin is the capital and largest city."]],
  ["Culture and connections",[
    "English, which spread worldwide through the British Empire, is the main language, while Welsh, Scottish Gaelic, and Irish (Gaeilge) are being revived; Irish is the first official language of the Republic. The UK's island position long protected it from invasion and encouraged sea power.",
    "Since 1994, the Channel Tunnel, about 50 kilometers long, has linked England and France by rail. The UK and Ireland maintain a Common Travel Area, and the open border between Northern Ireland and the Republic was a central issue in Brexit negotiations."]]
  ],
  terms:[["United Kingdom","England, Scotland, Wales, and Northern Ireland."],["Devolution","The transfer of powers to Scotland, Wales, and Northern Ireland."],["Highland and lowland Britain","The geological divide between the north and west and the south and east."],["North-South divide","Economic differences between southern and northern England."],["Good Friday Agreement","The 1998 peace accord for Northern Ireland."],["Great Famine","The 1845–1852 Irish famine caused by potato blight."],["Celtic Tiger","Ireland's economic boom from the 1990s."]],
  w:"The British Isles' island position, mild climate, and industrial history explain their global influence, regional divides, and the complex politics of the UK and Ireland.",
  src:["British Isles","United Kingdom","Geography of the United Kingdom","Ireland","Good Friday Agreement","Great Famine (Ireland)","Brexit"],
  q:[["Which four countries make up the United Kingdom?","England, Scotland, Wales, and Northern Ireland","England, Scotland, Wales, and Ireland","England, Scotland, Wales, and Cornwall","Britain, Ireland, Wales, and Scotland"],
     ["What is the highest point in the British Isles?","Ben Nevis","Snowdon","Scafell Pike","Carrauntoohil"],
     ["What is the longest river in Britain?","The Severn","The Thames","The Trent","The Shannon"],
     ["When did the Republic of Ireland's predecessor state win independence?","1922","1801","1949","1998"],
     ["Which agreement ended the Troubles?","The Good Friday Agreement","The Treaty of Union","The Act of Union","The Anglo-Irish Treaty of 1921"],
     ["What caused the Great Irish Famine?","Potato blight","Drought","War","Locusts"]]},

{ t:"France and the Low Countries", s:"France, Belgium, the Netherlands, and Luxembourg",
  sec:[
  ["France: the hexagon",[
    "France is the largest country in the European Union by area, often called l'Hexagone for its roughly six-sided shape, with coasts on the English Channel, the Atlantic, and the Mediterranean. It has about 68 million people. Its varied landscapes include the Paris Basin, a large, fertile lowland; the Massif Central, an old upland with extinct volcanoes; the Alps, with Mont Blanc on the Italian border; the Pyrenees on the Spanish border; the Jura and Vosges; and the island of Corsica.",
    "Its major rivers are the Seine, flowing through Paris; the Loire, the longest, famous for its châteaux; the Garonne, with Bordeaux; and the Rhône, flowing south from Lake Geneva past Lyon to the Mediterranean. France also includes overseas departments such as Guadeloupe, Martinique, French Guiana, Réunion, and Mayotte, which are fully part of France and of the EU."]],
  ["Paris and the regions",[
    "France is famously centralized. Paris, with about 12 million people in its metropolitan area, dominates the country's politics, economy, and culture, a classic primate city. Roads and railways radiate from Paris, and its high-speed TGV network, opened in 1981, links it to the regions.",
    "Other major cities include Lyon, Marseille, the main Mediterranean port, Toulouse, a center of the aerospace industry with Airbus, Lille, Bordeaux, Nice, and Strasbourg, seat of the European Parliament. France has worked to decentralize, strengthening regions since the 1980s."]],
  ["The French economy",[
    "France has one of the world's largest economies. It is the EU's leading agricultural producer, famous for wheat, dairy, cheese, and wine from regions such as Bordeaux, Burgundy, Champagne, and the Rhône valley; the concept of terroir links the qualities of food and wine to the specific place of production. It is also a leader in aerospace, luxury goods, nuclear energy, automobiles, pharmaceuticals, and tourism; France is the most visited country in the world.",
    "About two-thirds of France's electricity comes from nuclear power. France is a founding member of the European Union and a permanent member of the UN Security Council."]],
  ["The Netherlands",[
    "The Netherlands, meaning “low lands,” is one of the most densely populated countries in Europe, with about 18 million people. About a quarter of its land lies below sea level and much of the rest is flood-prone. For centuries the Dutch have reclaimed land from the sea, creating polders protected by dikes and drained, originally by windmills and now by pumps; the IJsselmeer was created by enclosing the Zuiderzee in 1932.",
    "After the catastrophic North Sea flood of 1953, which killed over 1,800 people, the Dutch built the Delta Works, a system of dams and storm surge barriers. Amsterdam is the capital, while the government sits in The Hague; Rotterdam, at the mouth of the Rhine, is Europe's largest port. Despite its size, the Netherlands is one of the world's largest agricultural exporters, thanks to intensive greenhouse farming."]],
  ["Belgium and Luxembourg",[
    "Belgium, with about 11.8 million people, is divided linguistically between Dutch-speaking Flanders in the north and French-speaking Wallonia in the south, with a small German-speaking community in the east; Brussels, the capital, is officially bilingual. These divisions have made Belgium a federal state with complex institutions. Brussels hosts the main institutions of the European Union and NATO's headquarters, earning it the title of the capital of Europe.",
    "Belgium was an early industrial nation, with coal and steel in Wallonia, but economic weight has shifted to Flanders, with the port of Antwerp, a center of the world diamond trade. Luxembourg, a tiny landlocked grand duchy, is one of the world's richest countries per person, a center of finance and home to EU institutions."]],
  ["The Benelux and Europe",[
    "Belgium, the Netherlands, and Luxembourg formed the Benelux customs union in 1944–1948, a forerunner of European integration, and all three were founding members of the European Coal and Steel Community and European Economic Community along with France, West Germany, and Italy.",
    "Their location at the mouths of the Rhine, Meuse, and Scheldt rivers, near the heart of Europe's industrial and consumer markets, has made them gateways for trade into the continent."]]
  ],
  terms:[["Hexagon","A nickname for France based on its shape."],["Paris Basin","The large fertile lowland around Paris."],["Terroir","The idea that a place's environment shapes its food and wine."],["Polder","Land reclaimed from the sea and protected by dikes."],["Delta Works","The Dutch system of storm barriers built after 1953."],["Flanders and Wallonia","Belgium's Dutch- and French-speaking regions."],["Benelux","Belgium, the Netherlands, and Luxembourg."]],
  w:"France and the Low Countries form the heart of western Europe, with France's agriculture and centralization and the Dutch struggle against the sea offering classic lessons in geography.",
  src:["France","Geography of France","Paris","Netherlands","Delta Works","Belgium","Benelux"],
  q:[["What is France's longest river?","The Loire","The Seine","The Rhône","The Garonne"],
     ["Which French city is a center of the aerospace industry?","Toulouse","Lyon","Marseille","Lille"],
     ["What is the most visited country in the world?","France","Spain","The United States","Italy"],
     ["What were the Delta Works built to prevent?","Flooding from the sea","Droughts","Earthquakes","River pollution"],
     ["Which city hosts the main EU institutions and NATO headquarters?","Brussels","Luxembourg","Strasbourg","The Hague"],
     ["Where does the Dutch government sit?","The Hague","Amsterdam","Rotterdam","Utrecht"]]},

{ t:"Germany and the Alpine Countries", s:"Germany, Switzerland, Austria, and Liechtenstein",
  sec:[
  ["Germany's land",[
    "Germany, with about 84 million people, is the most populous country entirely in Europe after Russia and the economic heart of the European Union. Its landscape rises from north to south in three zones: the North German Plain, low, sandy, and dotted with glacial lakes, bordering the North and Baltic Seas; the Central Uplands, a belt of forested hills and plateaus, including the Harz and the Black Forest; and in the far south, the Bavarian Alps, with Zugspitze (2,962 meters), Germany's highest peak.",
    "Germany's rivers are major trade routes: the Rhine, the most important; the Elbe, flowing past Dresden to Hamburg, Germany's largest port; the Danube in the south; and the Weser, Main, and Oder, which forms part of the border with Poland."]],
  ["A federal nation of cities",[
    "Germany is a federal republic of 16 states (Länder), a structure reflecting its history as a patchwork of independent kingdoms, duchies, and cities until unification in 1871. Unlike France, it has no single dominant city: Berlin, the capital and largest city, is joined by major centers such as Hamburg, Munich, Cologne, and Frankfurt, a financial center and home of the European Central Bank.",
    "Germany was divided after World War II into West Germany and communist East Germany, and reunified in 1990. Despite massive investment, the former East still has lower incomes and an older, shrinking population than the West."]],
  ["Europe's industrial powerhouse",[
    "Germany has the largest economy in Europe and is one of the world's leading exporters, known for automobiles, made by firms such as Volkswagen, BMW, and Mercedes-Benz, machinery, chemicals, and electrical equipment. Much of its strength lies in the Mittelstand, thousands of medium-sized, often family-owned, highly specialized manufacturing firms.",
    "The Ruhr, built on coal and steel, was once Europe's greatest industrial region and has transformed toward services. Today southern Germany, in Bavaria and Baden-Württemberg, is the most prosperous. Germany's Energiewende (energy transition) has expanded wind and solar power; it closed its last nuclear power plants in 2023."]],
  ["Switzerland",[
    "Switzerland, a landlocked, mountainous country of about 9 million people, is famous for the Alps, which cover about 60 percent of its area, and the Jura Mountains. Most people live on the Swiss Plateau between them, in cities such as Zurich, the financial center, Geneva, and the capital, Bern. Lake Geneva and Lake Constance are on its borders.",
    "Switzerland has four national languages, German, French, Italian, and Romansh, and a decentralized federal system of 26 cantons with frequent direct democracy through referendums. It has a long tradition of neutrality, and it is not a member of the European Union. Geneva hosts many international organizations, including the Red Cross and UN agencies. Its economy is based on finance, pharmaceuticals, precision instruments, watches, and tourism, and it is one of the richest countries in the world."]],
  ["Austria and Liechtenstein",[
    "Austria, with about 9 million people, is dominated by the Eastern Alps, with Grossglockner as its highest peak, while the Danube flows through the north past Linz and Vienna, the capital, where about a fifth of Austrians live. Once the center of the vast Habsburg Empire, Vienna remains a center of music and culture and hosts UN agencies and the headquarters of OPEC. Austria is neutral and joined the EU in 1995.",
    "Liechtenstein, a tiny principality between Switzerland and Austria, is one of only two doubly landlocked countries in the world, surrounded entirely by landlocked countries; the other is Uzbekistan."]],
  ["The Alps",[
    "The Alps, Europe's highest mountains, stretch about 1,200 kilometers in an arc through France, Italy, Switzerland, Liechtenstein, Germany, Austria, Slovenia, and Monaco. Formed by the collision of the African and Eurasian plates, they were sculpted by glaciers into sharp peaks, U-shaped valleys, and lakes. They are the source of major rivers including the Rhine, Rhône, Po, and tributaries of the Danube, earning them the name “water tower of Europe.”",
    "Traditional Alpine life involved transhumance, moving livestock to high summer pastures. Today tourism, especially skiing, dominates. Tunnels such as the Gotthard Base Tunnel in Switzerland, the world's longest railway tunnel at 57 kilometers, opened in 2016, carry trade across the mountains. Alpine glaciers are retreating rapidly as the climate warms."]]
  ],
  terms:[["North German Plain","The lowland of northern Germany."],["Länder","Germany's 16 federal states."],["Mittelstand","Germany's medium-sized specialized firms."],["Energiewende","Germany's transition to renewable energy."],["Canton","One of Switzerland's 26 self-governing states."],["Neutrality","A policy of not joining military alliances or wars."],["Transhumance","The seasonal movement of livestock to mountain pastures."]],
  w:"Germany's industrial might and the Alpine countries' mountains, wealth, and neutrality place them at the economic and geographic heart of Europe.",
  src:["Germany","Geography of Germany","Economy of Germany","Switzerland","Austria","Alps","Gotthard Base Tunnel"],
  q:[["What is Germany's highest peak?","Zugspitze","Watzmann","Feldberg","Brocken"],
     ["What is Germany's largest port?","Hamburg","Bremen","Rostock","Kiel"],
     ["Which German city is home to the European Central Bank?","Frankfurt","Berlin","Munich","Bonn"],
     ["How many national languages does Switzerland have?","Four","Three","Two","Five"],
     ["Which countries are doubly landlocked?","Liechtenstein and Uzbekistan","Switzerland and Austria","Andorra and San Marino","Mongolia and Bolivia"],
     ["What is the world's longest railway tunnel?","The Gotthard Base Tunnel","The Channel Tunnel","The Seikan Tunnel","The Simplon Tunnel"]]},

{ t:"Northern Europe", s:"The Nordic and Baltic countries",
  sec:[
  ["The Nordic countries",[
    "The Nordic countries are Norway, Sweden, Denmark, Finland, and Iceland, along with the self-governing Faroe Islands and Greenland (both part of the Kingdom of Denmark) and Finland's Åland Islands. Scandinavia, strictly, refers to Norway, Sweden, and Denmark, whose languages are closely related North Germanic tongues; Finnish, by contrast, is a Uralic language related to Estonian.",
    "Despite their northern location, with large areas north of the Arctic Circle, these countries are among the most prosperous, equal, and highly rated in the world for quality of life, with extensive welfare states, often called the Nordic model."]],
  ["Norway and Sweden",[
    "Norway occupies the western side of the Scandinavian Peninsula, with a long, rugged coastline of fjords, the most famous being Sognefjord and Geirangerfjord. Mountains cover most of the land, so its 5.5 million people live mainly along the coast; Oslo is the capital. The warm North Atlantic Current keeps its ports ice-free. Norway's wealth comes from North Sea oil and gas, managed through the world's largest sovereign wealth fund, as well as fishing, salmon farming, and shipping. Almost all its electricity comes from hydropower. Norway is not in the EU.",
    "Sweden, the largest Nordic country with about 10.5 million people, has forests, lakes, and lowlands, with most people in the south around Stockholm, the capital, Gothenburg, and Malmö. It is known for industries such as forestry, iron ore mining at Kiruna in the far north, automobiles, telecommunications, and design. Sweden joined NATO in 2024."]],
  ["Denmark, Finland, and Iceland",[
    "Denmark consists of the Jutland peninsula and over 400 islands, the largest being Zealand, where the capital, Copenhagen, lies. It is flat and fertile, with intensive dairy and pork farming, and a world leader in wind power, which supplies over half its electricity. The Øresund Bridge links Copenhagen with Malmö in Sweden. Greenland, the world's largest island, is an autonomous territory of Denmark.",
    "Finland, “the land of a thousand lakes” (it has nearly 188,000), is mostly forested and low, shaped by glaciers. Helsinki is its capital. It was part of Sweden for centuries and then of the Russian Empire until independence in 1917; it shares a long border with Russia and joined NATO in 2023. Its economy rests on forestry, technology, and engineering. Iceland, a volcanic island on the Mid-Atlantic Ridge, has glaciers, geysers, and hot springs, and uses geothermal and hydro power for nearly all its electricity. Reykjavík is the world's northernmost capital of a sovereign state."]],
  ["The Baltic States",[
    "Estonia, Latvia, and Lithuania lie on the eastern shore of the Baltic Sea. They are low-lying, with forests, lakes, and bogs. Their capitals are Tallinn, Riga, the largest Baltic city, and Vilnius. Lithuanian and Latvian are Baltic languages, among the oldest surviving Indo-European languages, while Estonian is related to Finnish.",
    "Ruled for centuries by Germans, Swedes, Poles, and Russians, they became independent in 1918, were annexed by the Soviet Union in 1940, and regained independence in 1991, joining the EU and NATO in 2004. Estonia is known as a highly digital society. Large Russian-speaking minorities live in Estonia and Latvia."]],
  ["The Baltic Sea and the Arctic",[
    "The Baltic Sea is a shallow, brackish sea, less salty than the ocean because of the many rivers flowing into it and its narrow connection to the North Sea through the Danish straits. It suffers from pollution and oxygen-poor dead zones caused by agricultural runoff. Russia's Kaliningrad exclave and St. Petersburg give it access to the Baltic.",
    "In the far north, the Sámi, the Indigenous people of northern Norway, Sweden, Finland, and Russia's Kola Peninsula, traditionally herded reindeer. North of the Arctic Circle, the midnight sun shines in summer, while in winter there are weeks of polar night and frequent displays of the aurora borealis."]],
  ["Living in the north",[
    "Nordic societies have adapted to long, dark winters and short summers with strong social institutions, high taxes, and generous public services. They consistently rank near the top of indexes for happiness, gender equality, low corruption, and human development.",
    "The region's renewable energy resources, hydropower, wind, and geothermal, and its commitment to sustainability make it a model in debates on climate policy, though Norway's oil exports present a contradiction."]]
  ],
  terms:[["Nordic countries","Norway, Sweden, Denmark, Finland, and Iceland."],["Scandinavia","Norway, Sweden, and Denmark."],["Nordic model","A combination of market economies with extensive welfare states."],["Sovereign wealth fund","A state investment fund, such as Norway's oil fund."],["Baltic States","Estonia, Latvia, and Lithuania."],["Sámi","The Indigenous people of northern Scandinavia."],["Midnight sun","Continuous summer daylight north of the Arctic Circle."]],
  w:"Northern Europe shows how countries in harsh northern environments became among the world's most prosperous and equal societies.",
  src:["Nordic countries","Norway","Sweden","Denmark","Finland","Iceland","Baltic states"],
  q:[["Which Nordic language is NOT closely related to Swedish?","Finnish","Norwegian","Danish","Icelandic"],
     ["What is the source of most of Norway's electricity?","Hydropower","Nuclear","Coal","Wind"],
     ["Which island is an autonomous territory of Denmark?","Greenland","Iceland","Svalbard","Åland"],
     ["What is the largest Baltic city?","Riga","Tallinn","Vilnius","Kaliningrad"],
     ["When did the Baltic States join the EU and NATO?","2004","1991","1995","2007"],
     ["Who are the Indigenous people of northern Scandinavia?","The Sámi","The Inuit","The Basques","The Karelians"]]},

{ t:"Southern Europe", s:"Iberia, Italy, Greece, and the Mediterranean",
  sec:[
  ["The Mediterranean world",[
    "Southern Europe consists of three great peninsulas jutting into the Mediterranean Sea, the Iberian, Italian, and Balkan, along with islands such as Sicily, Sardinia, Corsica, Crete, Cyprus, and Malta. The Mediterranean climate of hot, dry summers and mild, wet winters, rugged mountains, and thin soils shaped a distinctive way of life based on wheat, olives, and grapes, the “Mediterranean triad,” along with sheep and goats.",
    "The Mediterranean was the cradle of ancient Greek and Roman civilization and a crossroads of trade, religions, and empires. Today its beaches and historic cities make it the world's leading tourist region."]],
  ["Spain and Portugal",[
    "The Iberian Peninsula is separated from France by the Pyrenees. Its interior is dominated by the Meseta, a high, dry plateau crossed by mountain ranges, where Madrid, Spain's capital, lies near the center. The Sierra Nevada in the south rises near Granada, and the highest point in Spain is Mount Teide on Tenerife in the Canary Islands. Major rivers include the Tagus (Tajo/Tejo), the longest, flowing to Lisbon, the Ebro, the Douro, and the Guadalquivir.",
    "Spain, with about 48 million people, has strong regional identities and languages: Catalan in Catalonia, whose capital is Barcelona and where an independence movement is strong; Basque (Euskara) in the Basque Country; and Galician in the northwest. It is a major producer of olive oil, wine, fruit, and vegetables, grown in greenhouses in Almería, and one of the world's most visited countries. Portugal, with about 10 million people, faces the Atlantic, with Lisbon and Porto as its main cities; it is famous for port wine, cork (it produces about half the world's supply), and its seafaring history. Gibraltar, at the southern tip of Iberia, is a British Overseas Territory claimed by Spain."]],
  ["Italy",[
    "Italy, with about 59 million people, is a boot-shaped peninsula with the large islands of Sicily and Sardinia. The Alps form its northern border, and the Apennines run down its spine. Between them lies the Po Valley, Italy's largest lowland and agricultural and industrial heartland. Italy has active volcanoes: Vesuvius near Naples, Etna on Sicily, the tallest active volcano in Europe, and Stromboli.",
    "Italy shows a stark North-South divide. The industrial North, centered on the triangle of Milan, Turin, and Genoa, is wealthy, with fashion, design, machinery, and automobiles. The South, the Mezzogiorno, is poorer, with higher unemployment and emigration. Rome is the capital; within it lies Vatican City, the world's smallest country and center of the Catholic Church. Italy has more UNESCO World Heritage Sites than almost any country. San Marino is a small independent republic within Italy."]],
  ["Greece, Cyprus, and Malta",[
    "Greece, at the southern end of the Balkan Peninsula, is mountainous, with Mount Olympus as its highest peak, and has thousands of islands in the Aegean and Ionian seas, including Crete, the largest, and the Cyclades. Athens, the capital, is home to about a third of Greeks. The economy relies on shipping, Greece having one of the world's largest merchant fleets, tourism, and agriculture. Greece was hit hard by the debt crisis of 2009–2018.",
    "Cyprus, an island in the eastern Mediterranean, has been divided since 1974 between the Greek Cypriot Republic of Cyprus, an EU member, and a Turkish Cypriot north recognized only by Turkey. Malta, a small island nation south of Sicily, is the EU's smallest member by area and population."]],
  ["Tectonics and hazards",[
    "Southern Europe lies along the boundary where the African plate pushes into Eurasia, making it the most earthquake- and volcano-prone part of Europe. Major earthquakes include the Lisbon earthquake of 1755, which with its tsunami and fires killed tens of thousands and shook European thought, and the Messina earthquake of 1908 in Sicily, which killed perhaps 75,000 or more.",
    "The region also faces drought, water scarcity, wildfires, and heat waves, which are becoming more frequent and intense as the Mediterranean warms faster than the global average."]],
  ["Migration across the Mediterranean",[
    "For decades, southern Europe was a region of emigration, sending workers to northern Europe and the Americas. It is now a destination and transit region for migrants and refugees from Africa and the Middle East, many crossing the Mediterranean in dangerous boats to reach Italy, Greece, Malta, or Spain; thousands have died at sea.",
    "Low fertility rates, among the lowest in the world in Italy and Spain, mean aging and in some areas shrinking populations, with abandoned villages in the interior."]]
  ],
  terms:[["Mediterranean triad","Wheat, olives, and grapes, the traditional Mediterranean crops."],["Meseta","The high central plateau of Spain."],["Catalonia","A region of Spain with its own language and independence movement."],["Po Valley","Italy's largest lowland and economic heartland."],["Mezzogiorno","The poorer south of Italy."],["Vatican City","The world's smallest country."],["Divided Cyprus","The island split since 1974."]],
  w:"Southern Europe's Mediterranean environment, ancient heritage, and regional divides make it a crossroads of history, tourism, and migration.",
  src:["Southern Europe","Iberian Peninsula","Spain","Portugal","Italy","Greece","Cyprus problem"],
  q:[["What are the three traditional Mediterranean crops?","Wheat, olives, and grapes","Rice, olives, and citrus","Barley, figs, and dates","Maize, grapes, and almonds"],
     ["What is Spain's high central plateau called?","The Meseta","The Pampa","The Altiplano","The Massif"],
     ["Which country produces about half of the world's cork?","Portugal","Spain","Italy","Greece"],
     ["What is Italy's largest lowland?","The Po Valley","The Campania plain","The Tuscan basin","The Apulian plain"],
     ["What is the world's smallest country?","Vatican City","Monaco","San Marino","Malta"],
     ["Which tallest active volcano in Europe is on Sicily?","Etna","Vesuvius","Stromboli","Vulcano"]]}

);


/* ---- from geo-13.js ---- */
/* GEOGRAPHY FOUNDATIONS, part 13: Unit 6 chapters 16-19 (Eastern Europe and Russia) */
COURSES.geography.units[5].ch.push(

{ t:"Central Europe", s:"Poland, Czechia, Slovakia, Hungary, and Slovenia",
  sec:[
  ["Between East and West",[
    "Central Europe, sometimes called East-Central Europe, lies between Germany and Russia. Its location has made it a crossroads and frequent battleground; its borders have shifted many times. Poland, for example, was partitioned out of existence by Russia, Prussia, and Austria from 1795 until 1918, and its borders moved dramatically westward after World War II.",
    "After 1945 the region fell under Soviet-dominated communist rule. The revolutions of 1989 restored independence and democracy, and Poland, the Czech Republic, Slovakia, Hungary, and Slovenia joined the European Union in 2004. The Visegrád Group, formed in 1991, links Poland, Czechia, Slovakia, and Hungary."]],
  ["Poland",[
    "Poland, with about 37 million people, is the largest country in the region. Most of it lies on the North European Plain, with lakes in the north, a Baltic coastline with the port of Gdańsk, and mountains, the Sudetes and the Tatras, part of the Carpathians, along its southern border. The Vistula, flowing past Kraków and Warsaw, is its longest river.",
    "Warsaw, the capital, was almost completely destroyed in World War II and rebuilt. Kraków, the old royal capital, preserves a medieval center. Poland has been one of Europe's fastest-growing economies since 1990, with manufacturing, services, and agriculture; it still relies heavily on coal from Silesia. It is predominantly Catholic, and the Solidarity movement that began in Gdańsk in 1980 helped bring down communism."]],
  ["Czechia and Slovakia",[
    "The Czech Republic (Czechia) consists of Bohemia, a basin ringed by mountains drained by the Vltava and Elbe, and Moravia to the east. Prague, the capital, on the Vltava, is one of Europe's best-preserved historic cities. Czechia is one of the most industrialized countries in Europe, with a large automobile industry and a famous brewing tradition; the original Pilsner was brewed in Plzeň in 1842.",
    "Czechoslovakia, created in 1918, split peacefully into the Czech Republic and Slovakia in 1993, the “Velvet Divorce.” Slovakia is mountainous, dominated by the Carpathians, including the High Tatras, with its capital Bratislava on the Danube; it produces more cars per person than any other country in the world."]],
  ["Hungary",[
    "Hungary occupies much of the Pannonian (Carpathian) Basin, a large fertile plain surrounded by the Carpathians and Alps. The Danube divides it and flows through Budapest, the capital, formed in 1873 from Buda and Pest. Lake Balaton is the largest lake in Central Europe. The Great Hungarian Plain (Alföld) is a major farming region.",
    "Hungarians descend partly from the Magyars, who arrived from the east in the late 9th century; Hungarian is a Uralic language, unrelated to its neighbors' languages. After the Treaty of Trianon (1920), Hungary lost about two-thirds of its territory, leaving millions of ethnic Hungarians in neighboring countries such as Romania, Slovakia, and Serbia."]],
  ["Slovenia and the Carpathians",[
    "Slovenia, a small country of about 2.1 million people, was the first republic to leave Yugoslavia, in 1991, and is one of the region's most prosperous. Its landscape ranges from the Julian Alps, with Triglav, to the karst plateau that gave karst landscapes their name, with spectacular caves such as Postojna and Škocjan, and a short Adriatic coast. Ljubljana is its capital.",
    "The Carpathian Mountains form a great arc about 1,500 kilometers long through Czechia, Slovakia, Poland, Ukraine, Romania, and Serbia. They contain some of Europe's largest remaining old-growth forests and populations of bears, wolves, and lynx."]],
  ["Transformation",[
    "Since 1989 Central Europe has undergone rapid transformation from planned to market economies, attracting foreign investment, especially from Germany, whose automobile and machinery industries built factories in the region. Living standards have converged significantly with Western Europe.",
    "Challenges include emigration of young workers to Western Europe after EU accession, aging populations, regional inequality between capitals and rural areas, and political debates over democracy and the rule of law. Russia's 2022 invasion of Ukraine brought millions of Ukrainian refugees to the region, especially Poland."]]
  ],
  terms:[["Partitions of Poland","The 18th-century division of Poland among its neighbors."],["Visegrád Group","An alliance of Poland, Czechia, Slovakia, and Hungary."],["Bohemia","The western, historic core of the Czech lands."],["Velvet Divorce","The peaceful 1993 split of Czechoslovakia."],["Pannonian Basin","The large plain surrounded by the Carpathians and Alps."],["Treaty of Trianon","The 1920 treaty that greatly reduced Hungary's territory."],["Carpathians","The mountain arc of Central and Eastern Europe."]],
  w:"Central Europe's position between Germany and Russia explains its turbulent history, shifting borders, and remarkable transformation since 1989.",
  src:["Central Europe","Poland","Czech Republic","Slovakia","Hungary","Slovenia","Carpathian Mountains"],
  q:[["Which is Poland's longest river?","The Vistula","The Oder","The Warta","The Bug"],
     ["What was the peaceful 1993 split of Czechoslovakia called?","The Velvet Divorce","The Velvet Revolution","The Prague Spring","The Partition"],
     ["Which country produces the most cars per person?","Slovakia","Germany","Czechia","Japan"],
     ["Which two cities joined to form Budapest?","Buda and Pest","Buda and Óbuda","Pest and Szeged","Buda and Győr"],
     ["Hungarian belongs to which language family?","Uralic","Slavic","Germanic","Romance"],
     ["Which country's karst plateau gave karst landscapes their name?","Slovenia","Croatia","Hungary","Slovakia"]]},

{ t:"The Balkans and Southeastern Europe", s:"Mountains, diversity, and conflict",
  sec:[
  ["The Balkan Peninsula",[
    "The Balkan Peninsula, named after the Balkan Mountains of Bulgaria, lies between the Adriatic, Ionian, Aegean, and Black Seas. It is largely mountainous: the Dinaric Alps run parallel to the Adriatic coast, with spectacular karst landscapes; the Balkan Mountains and Rhodopes cross Bulgaria. The Danube forms much of its northern edge.",
    "Countries usually included in the Balkans are Slovenia, Croatia, Bosnia and Herzegovina, Serbia, Montenegro, Kosovo, North Macedonia, Albania, Bulgaria, Greece, and the European part of Turkey; Romania is often included in Southeastern Europe."]],
  ["A crossroads of peoples",[
    "The rugged terrain and the region's position between empires produced great diversity. Peoples include South Slavs (Slovenes, Croats, Bosniaks, Serbs, Montenegrins, Macedonians, and Bulgarians), Albanians, Greeks, Romanians, Turks, Roma, and Hungarians. Religions include Orthodox Christianity, Catholicism, and Islam, a legacy of nearly five centuries of Ottoman rule.",
    "Serbian and Croatian are mutually intelligible but use different scripts, Serbian often Cyrillic and Croatian the Latin alphabet. The term “balkanization,” meaning the fragmentation of a region into small, often hostile units, comes from the region's history."]],
  ["Yugoslavia and its breakup",[
    "After World War I, the South Slavs were united in a kingdom that became Yugoslavia. After World War II, the communist leader Josip Broz Tito held together a federation of six republics, Slovenia, Croatia, Bosnia and Herzegovina, Serbia, Montenegro, and Macedonia, independent of the Soviet bloc. After Tito's death in 1980 and the end of communism, nationalism tore the country apart.",
    "The wars of 1991–2001 were the deadliest in Europe since World War II. The Bosnian War (1992–1995) killed about 100,000 people and included the siege of Sarajevo and the Srebrenica genocide of 1995, in which Bosnian Serb forces killed about 8,000 Bosniak men and boys. The Dayton Agreement of 1995 ended it, dividing Bosnia into two entities. Kosovo, with an ethnic Albanian majority, declared independence from Serbia in 2008, recognized by many but not all countries."]],
  ["Croatia, Albania, and the Adriatic",[
    "Croatia's long Adriatic coastline, with over a thousand islands and historic cities such as Dubrovnik and Split, makes tourism vital; Zagreb is its capital. It joined the EU in 2013 and the eurozone and Schengen Area in 2023. Montenegro (“Black Mountain”) has a dramatic coast at the Bay of Kotor.",
    "Albania, isolated under the hardline communist ruler Enver Hoxha until 1991, was one of Europe's poorest countries and has since opened up; Tirana is its capital. Albanians speak a language forming its own branch of Indo-European."]],
  ["Romania and Bulgaria",[
    "Romania, with about 19 million people, is shaped by the Carpathian arc, which encloses the Transylvanian Plateau, and by the Danube, which forms its border with Serbia and Bulgaria and reaches the Black Sea in the Danube Delta, Europe's best-preserved delta and a haven for birds. Bucharest is the capital. Romanian is a Romance language, a legacy of the Roman province of Dacia. Romania has oil, gas, and agriculture and a growing technology sector.",
    "Bulgaria, south of the Danube, is crossed by the Balkan Mountains, with the Rose Valley, famous for rose oil, and the Thracian Plain. Sofia is its capital. Bulgarians use the Cyrillic alphabet, developed in the First Bulgarian Empire in the 9th–10th centuries. Romania and Bulgaria joined the EU in 2007 and are among its poorer members."]],
  ["The region today",[
    "Southeastern Europe remains a patchwork of EU members (Slovenia, Croatia, Greece, Romania, Bulgaria) and candidate or aspiring countries (Serbia, Montenegro, North Macedonia, Albania, Bosnia and Herzegovina, Kosovo). North Macedonia adopted its name in 2019 to resolve a long dispute with Greece.",
    "Challenges include emigration, which has shrunk the populations of Bulgaria, Bosnia, and others; corruption; and unresolved ethnic tensions. The region is also an important route for migrants traveling from the Middle East to Western Europe."]]
  ],
  terms:[["Balkan Peninsula","The mountainous peninsula of southeastern Europe."],["Dinaric Alps","Mountains running parallel to the Adriatic coast."],["Balkanization","The fragmentation of a region into hostile units."],["Yugoslavia","The South Slav federation that broke apart in the 1990s."],["Srebrenica genocide","The 1995 massacre of about 8,000 Bosniak men and boys."],["Dayton Agreement","The 1995 treaty ending the Bosnian War."],["Danube Delta","Europe's best-preserved river delta, in Romania."]],
  w:"The Balkans' rugged terrain, diversity, and imperial past explain the region's rich cultures, its fragmentation, and the wars of the 1990s.",
  src:["Balkans","Yugoslavia","Yugoslav Wars","Srebrenica massacre","Dayton Agreement","Romania","Bulgaria"],
  q:[["Which mountains run parallel to the Adriatic coast?","The Dinaric Alps","The Balkan Mountains","The Rhodopes","The Carpathians"],
     ["Who held Yugoslavia together after World War II?","Josip Broz Tito","Slobodan Milošević","Enver Hoxha","Nicolae Ceaușescu"],
     ["Which agreement ended the Bosnian War in 1995?","The Dayton Agreement","The Ohrid Agreement","The Treaty of Trianon","The Prespa Agreement"],
     ["Which territory declared independence from Serbia in 2008?","Kosovo","Montenegro","North Macedonia","Vojvodina"],
     ["Which Romanian language is a legacy of the Roman province of Dacia?","Romanian","Bulgarian","Albanian","Hungarian"],
     ["When did Romania and Bulgaria join the EU?","2007","2004","2013","1995"]]},

{ t:"Ukraine, Belarus, and Moldova", s:"Europe's eastern borderlands",
  sec:[
  ["Ukraine's land",[
    "Ukraine is the largest country entirely within Europe, about 604,000 square kilometers, with a pre-war population of about 41 million. Most of it is flat or gently rolling steppe and forest-steppe with some of the most fertile soils in the world, the black chernozems. The Carpathians cross the far west, and the Crimean Mountains rise along the southern coast of the Crimean peninsula.",
    "The Dnieper (Dnipro) River flows south through the middle of the country, past Kyiv, the capital, to the Black Sea, dividing it into left-bank and right-bank Ukraine. Ukraine borders the Black Sea and the Sea of Azov."]],
  ["Breadbasket and industry",[
    "Ukraine's fertile soils made it the “breadbasket of Europe.” Before 2022 it was one of the world's leading exporters of wheat, corn, barley, and sunflower oil, of which it was the largest exporter, feeding countries across the Middle East, Africa, and Asia through its Black Sea ports, especially Odesa.",
    "The Donbas region in the east developed heavy industry based on coal and steel during the Russian Empire and Soviet era. Ukraine also has a large technology sector. The 1986 Chernobyl disaster, at a nuclear plant north of Kyiv, left an exclusion zone that remains largely uninhabited."]],
  ["History and identity",[
    "Kyiv was the center of Kievan Rus', the medieval state from which Ukrainians, Belarusians, and Russians all trace cultural roots. Over the centuries Ukrainian lands were divided among Poland-Lithuania, Russia, Austria-Hungary, and the Ottomans and Crimean Khanate. Under Soviet rule, the famine of 1932–1933, the Holodomor, killed millions.",
    "Ukraine became independent in 1991. Ukrainian is the state language, while Russian has been widely spoken, especially in the east and south. In 2014, after protests that ousted a pro-Russian president, Russia annexed Crimea and backed separatists in the Donbas. In February 2022 Russia launched a full-scale invasion, the largest war in Europe since 1945, causing enormous casualties and destruction and displacing millions of people."]],
  ["Belarus",[
    "Belarus, with about 9 million people, is a landlocked, flat country of forests, lakes, and marshes, including part of the Pripet Marshes, one of Europe's largest wetlands, and Białowieża Forest, one of Europe's last primeval forests, shared with Poland and home to the European bison. Minsk is its capital.",
    "Belarus suffered terrible losses in World War II, perhaps a quarter of its population. Since 1994 it has been ruled by Alexander Lukashenko, often called Europe's last dictator, and remains closely allied with Russia, maintaining a large state-run economy. Russian is more widely spoken than Belarusian."]],
  ["Moldova",[
    "Moldova, a small landlocked country between Romania and Ukraine, is one of the poorest in Europe. It has fertile soils and a long tradition of wine-making. Its capital is Chișinău. Moldovan is essentially the same language as Romanian, and the country was part of Romania between the world wars.",
    "Transnistria, a narrow strip east of the Dniester River with a large Russian-speaking population, broke away after a brief war in 1992 and remains an unrecognized state hosting Russian troops. Moldova became an EU candidate country in 2022, alongside Ukraine."]],
  ["A contested borderland",[
    "The name Ukraine is often interpreted as meaning “borderland,” and these countries lie between the European Union and NATO to the west and Russia to the east. Their geography, open plains with few natural barriers, has made them a route for invasions throughout history.",
    "The war in Ukraine has reshaped European security, energy, and food markets, and raised questions about the future of borders and sovereignty in Europe."]]
  ],
  terms:[["Chernozem","Very fertile black soil of the steppe."],["Dnieper","The great river flowing through Kyiv to the Black Sea."],["Kievan Rus'","The medieval East Slavic state centered on Kyiv."],["Donbas","The industrial region of eastern Ukraine."],["Chernobyl","The site of the 1986 nuclear disaster."],["Transnistria","A breakaway region of Moldova."],["Białowieża Forest","A primeval forest on the Belarus-Poland border."]],
  w:"Ukraine, Belarus, and Moldova sit on the open plains between the EU and Russia, making them a fertile breadbasket and a contested borderland at the center of Europe's greatest current war.",
  src:["Ukraine","Geography of Ukraine","Dnieper","Kievan Rus'","Russian invasion of Ukraine","Belarus","Moldova"],
  q:[["What is the largest country entirely within Europe?","Ukraine","France","Spain","Germany"],
     ["Which river flows through Kyiv?","The Dnieper","The Dniester","The Don","The Volga"],
     ["Of which product was Ukraine the world's largest exporter before 2022?","Sunflower oil","Wheat","Coffee","Rice"],
     ["In which year did Russia annex Crimea?","2014","2008","2022","1991"],
     ["Which forest on the Belarus-Poland border is home to European bison?","Białowieża Forest","The Black Forest","The Pripet Forest","Tatra Forest"],
     ["Which breakaway region lies east of the Dniester in Moldova?","Transnistria","Abkhazia","Gagauzia","Donbas"]]},

{ t:"Russia", s:"The world's largest country",
  sec:[
  ["A country of extremes",[
    "Russia is by far the largest country in the world, about 17 million square kilometers, more than a ninth of the Earth's land, spanning eleven time zones from the Baltic Sea to the Pacific. Yet its population, about 146 million, is smaller than that of Bangladesh. About three-quarters of its territory lies in Asia, but about three-quarters of its people live in the European part, west of the Urals.",
    "Moscow, the capital, with over 13 million people, is the largest city in Europe, and St. Petersburg, founded by Peter the Great in 1703 as a “window to the West,” is the second. Russia is a federation of many republics and regions, home to over 190 ethnic groups, including Tatars, Bashkirs, Chechens, Chuvash, and Yakuts, though ethnic Russians form about 80 percent of the population."]],
  ["Physical regions",[
    "West of the Urals lies the East European (Russian) Plain, a vast lowland drained by the Volga, Europe's longest river, which flows to the Caspian Sea and is the historic heart of Russia. The Ural Mountains, low and old, rich in minerals, divide Europe and Asia. East of them is the West Siberian Plain, one of the world's largest and flattest lowlands, crossed by the Ob and Irtysh and full of swamps.",
    "Farther east lie the Central Siberian Plateau, drained by the Yenisei and Lena rivers, which flow north to the Arctic Ocean, and the mountainous Russian Far East, with the volcanic Kamchatka Peninsula and the island of Sakhalin. Lake Baikal, in southern Siberia, is the world's deepest and oldest lake. In the south, the Caucasus Mountains contain Mount Elbrus, Europe's highest peak."]],
  ["Climate and biomes",[
    "Most of Russia has a harsh continental climate with long, very cold winters; Oymyakon in Siberia is often called the coldest inhabited place on Earth, with recorded temperatures around −68°C. Much of the country is underlain by permafrost. The north has tundra along the Arctic coast, then a vast belt of taiga, the largest forest on Earth.",
    "To the south lie mixed forests and then the steppe, where the best farmland, with chernozem soils, is found in southern European Russia. Russia's northern ports freeze for much of the year, which has historically driven a quest for warm-water ports; Murmansk, warmed by the North Atlantic Current, remains ice-free."]],
  ["Resources and economy",[
    "Russia possesses enormous natural resources: it is one of the world's top producers of natural gas, oil, coal, nickel, palladium, diamonds, gold, aluminum, and timber, and has the largest natural gas reserves. Much of this wealth lies in remote Siberia, especially the oil and gas fields of Western Siberia. Energy exports have funded the state, making the economy vulnerable to price swings.",
    "Russia is also a major wheat exporter and has a large defense industry. Since its 2022 invasion of Ukraine, Western sanctions have cut much trade with Europe, and Russia has redirected exports to China, India, and other countries."]],
  ["Settling a vast land",[
    "Russia expanded from the Grand Duchy of Moscow across Siberia, reaching the Pacific by the mid-17th century, much as the United States expanded westward. The Trans-Siberian Railway, completed in 1916, about 9,300 kilometers from Moscow to Vladivostok, is the longest railway line in the world, and most Siberian cities, such as Novosibirsk, Omsk, and Irkutsk, lie along it.",
    "Siberia and the Far East have been losing population since the Soviet collapse, as people moved to European Russia. The Soviet Union used forced labor in the Gulag to build infrastructure and mines in remote regions."]],
  ["Russia in the world",[
    "Russia borders 14 countries, more than almost any other, and its long, open borders and history of invasion, by Mongols, Swedes, Napoleon, and Hitler, have shaped a strong concern with security. It has the largest nuclear arsenal in the world and a permanent seat on the UN Security Council.",
    "As Arctic ice melts, the Northern Sea Route along Russia's Arctic coast is becoming more navigable, offering a shorter shipping route between Europe and Asia. Russia's demographic decline, dependence on resources, and confrontation with the West are central issues for its future."]]
  ],
  terms:[["East European Plain","The vast lowland of western Russia."],["Ural Mountains","The range dividing European and Asian Russia."],["West Siberian Plain","One of the world's largest, flattest lowlands."],["Siberia","The vast Asian part of Russia east of the Urals."],["Warm-water port","A port that stays ice-free year-round."],["Trans-Siberian Railway","The world's longest railway line, Moscow to Vladivostok."],["Northern Sea Route","The Arctic shipping route along Russia's coast."]],
  w:"Russia's immense size, harsh climate, and vast resources explain its settlement patterns, its economy, and its outlook on security and the world.",
  src:["Russia","Geography of Russia","Siberia","Volga","Ural Mountains","Trans-Siberian Railway","Northern Sea Route"],
  q:[["How many time zones does Russia span?","Eleven","Seven","Nine","Fifteen"],
     ["Where do most Russians live?","West of the Urals","In Siberia","In the Far East","In the Caucasus"],
     ["Who founded St. Petersburg?","Peter the Great","Ivan the Terrible","Catherine the Great","Alexander I"],
     ["Which Siberian village is often called the coldest inhabited place?","Oymyakon","Norilsk","Yakutsk","Murmansk"],
     ["Which Russian Arctic port stays ice-free?","Murmansk","Arkhangelsk","Vladivostok","Tiksi"],
     ["Where does the Trans-Siberian Railway end in the east?","Vladivostok","Irkutsk","Khabarovsk","Magadan"]]}

);


/* ---- from geo-14.js ---- */
/* GEOGRAPHY FOUNDATIONS, part 14: Unit 7 Africa, Asia, and Oceania, chapters 1-5 */
COURSES.geography.units.push({ t:"Regions: Asia, Africa, and Oceania", ch:[

{ t:"Southwest Asia: Land, Water, and Oil", s:"The physical geography of the Middle East",
  sec:[
  ["Defining the region",[
    "The Middle East is a term coined from a European perspective; geographers often prefer Southwest Asia and North Africa (sometimes shortened to MENA). The core of Southwest Asia includes Turkey, Iran, Iraq, Syria, Lebanon, Israel, the Palestinian territories, Jordan, Saudi Arabia, Yemen, Oman, the United Arab Emirates, Qatar, Bahrain, and Kuwait. It sits at the meeting point of Europe, Asia, and Africa.",
    "This location made it a cradle of civilization, where agriculture, cities, and writing first developed, and the birthplace of Judaism, Christianity, and Islam. It remains a crossroads of trade routes and a strategic region because of its oil and its waterways."]],
  ["Landforms",[
    "The Arabian Peninsula, the largest peninsula in the world, is a tilted block of ancient rock, rising to mountains in the west along the Red Sea and in Yemen and Oman, and sloping gently east toward the Persian Gulf. Its interior includes the Rub' al Khali (Empty Quarter), the largest continuous sand desert in the world.",
    "To the north, the collision of the Arabian and Eurasian plates raised the Zagros Mountains of Iran and the Taurus Mountains of Turkey. Turkey's Anatolian Plateau and Iran's Plateau, ringed by mountains including the Elburz, with Mount Damavand, are high, dry interiors. The Jordan Rift Valley, part of the Great Rift system, contains the Sea of Galilee and the Dead Sea. The region is earthquake-prone; the 2023 Turkey–Syria earthquake killed over 50,000 people."]],
  ["Climate",[
    "Most of Southwest Asia is desert or steppe, lying under the subtropical high-pressure belt. Summer temperatures in the Gulf regularly exceed 45°C, and the combination of heat and humidity along the Gulf coast is among the most extreme on Earth. Rain falls mainly in winter along the Mediterranean coast, in the mountains of Turkey and Iran, and in the highlands of Yemen, which receive monsoon rains.",
    "The Fertile Crescent, an arc of better-watered land from the eastern Mediterranean through Syria to Mesopotamia, was where farming began about 11,000 years ago."]],
  ["Water: the scarcest resource",[
    "The Middle East and North Africa is the most water-scarce region in the world. The great exotic rivers, the Tigris and Euphrates, rise in the mountains of Turkey and flow through Syria and Iraq to the Persian Gulf, joining as the Shatt al-Arab. Turkey's dams on these rivers, part of the Southeastern Anatolia Project, have caused tension with downstream Syria and Iraq. The Jordan River is shared by Israel, Jordan, Syria, and the Palestinians.",
    "People have long used ingenious methods, such as Persia's qanats, underground channels carrying water from mountains. Today the Gulf states rely heavily on desalination, Saudi Arabia has pumped fossil groundwater to grow wheat in the desert, and Israel is a leader in drip irrigation and water recycling."]],
  ["Oil and gas",[
    "The region around the Persian Gulf holds about half of the world's proven oil reserves and a large share of its natural gas. Oil was discovered in Iran in 1908, Iraq in 1927, Bahrain in 1932, and Saudi Arabia and Kuwait in 1938. Saudi Arabia's Ghawar field is the largest conventional oil field in the world, and the state oil company Saudi Aramco is one of the most valuable companies in the world. Qatar and Iran share the world's largest natural gas field.",
    "Oil transformed small desert societies into wealthy states and made the region central to world politics. The Strait of Hormuz, between Iran and Oman, carries about a fifth of the world's oil, and the Suez Canal and Bab-el-Mandeb link the region's trade to Europe and Asia."]],
  ["Seas and waterways",[
    "Southwest Asia is bordered by the Mediterranean, the Black Sea, the Caspian Sea, the Red Sea, the Arabian Sea, and the Persian Gulf (called the Arabian Gulf by Arab states). Turkey controls the Bosporus and Dardanelles, the straits linking the Black Sea and the Mediterranean; Istanbul straddles the Bosporus, with parts in Europe and Asia.",
    "The Dead Sea, a salt lake about 430 meters below sea level, is shrinking rapidly as the Jordan River's water is diverted. Its water is about ten times saltier than the ocean, allowing people to float easily."]]
  ],
  terms:[["MENA","The Middle East and North Africa."],["Arabian Peninsula","The world's largest peninsula."],["Rub' al Khali","The Empty Quarter, the largest sand desert."],["Fertile Crescent","The arc of fertile land where farming began."],["Exotic river","A river that flows from a wet area through a dry one."],["Qanat","An underground irrigation channel."],["Strait of Hormuz","The chokepoint at the mouth of the Persian Gulf."]],
  w:"Southwest Asia's deserts, scarce water, and vast oil reserves explain its ancient civilizations, modern wealth, and strategic importance.",
  src:["Middle East","Arabian Peninsula","Rub' al Khali","Fertile Crescent","Tigris–Euphrates river system","Petroleum industry in the Middle East","Strait of Hormuz"],
  q:[["Which is the largest peninsula in the world?","The Arabian Peninsula","The Indian subcontinent","Scandinavia","The Iberian Peninsula"],
     ["What is the Rub' al Khali?","The largest sand desert","A mountain range","A river","An oil field"],
     ["Which mountains of Iran formed from the Arabian-Eurasian collision?","The Zagros","The Atlas","The Pontic","The Hindu Kush"],
     ["Which two rivers join to form the Shatt al-Arab?","The Tigris and Euphrates","The Jordan and Litani","The Nile and Jordan","The Karun and Tigris"],
     ["What is the largest conventional oil field?","Ghawar","Burgan","Kirkuk","Safaniya"],
     ["Which city straddles Europe and Asia?","Istanbul","Ankara","Baku","Tbilisi"]]},

{ t:"The Countries of the Middle East", s:"Peoples, states, and economies",
  sec:[
  ["Peoples and religions",[
    "The region's three largest ethnic and linguistic groups are Arabs, speaking Arabic, a Semitic language; Turks, speaking Turkish; and Persians, speaking Persian (Farsi), an Indo-European language. Other groups include Kurds, Jews, Armenians, Azeris, Assyrians, Baluch, and many others.",
    "Islam is the majority religion in every country except Israel. Most Muslims in the region are Sunni, but Shia Muslims form majorities in Iran, Iraq, and Bahrain and large communities in Lebanon, Saudi Arabia's Eastern Province, and Yemen. Christians are a significant minority in Lebanon and smaller ones elsewhere, and Judaism is the majority religion in Israel. Jerusalem is sacred to all three Abrahamic faiths."]],
  ["Turkey and Iran",[
    "Turkey (officially Türkiye), with about 85 million people, bridges Europe and Asia. Its capital is Ankara, but Istanbul, the former Byzantine and Ottoman capital Constantinople, is its largest city and economic center. Turkey has a diversified economy with manufacturing, textiles, agriculture, and tourism, and is a NATO member.",
    "Iran, with about 90 million people, is a large, mountainous country on the Iranian Plateau, with Tehran as its capital. Heir to ancient Persian empires, it became an Islamic Republic after the 1979 revolution. It has huge oil and gas reserves, but international sanctions over its nuclear program have hampered its economy."]],
  ["The Levant and Iraq",[
    "The Levant is the eastern Mediterranean region including Syria, Lebanon, Israel, the Palestinian territories, and Jordan. Syria has been devastated by civil war since 2011, which killed hundreds of thousands and displaced about half its population; the Assad government fell in December 2024. Lebanon, a small mountainous country with Beirut as its capital, divides political power among religious communities.",
    "Israel, founded in 1948, has a technologically advanced economy; its conflict with the Palestinians over land, including the West Bank and Gaza Strip, remains unresolved, and the war that began in Gaza in October 2023 caused immense loss of life. Jordan is resource-poor and hosts large refugee populations. Iraq, the ancient Mesopotamia, with Baghdad as its capital, has major oil reserves but has suffered decades of war since 1980."]],
  ["Saudi Arabia and the Gulf states",[
    "Saudi Arabia, the largest country on the Arabian Peninsula, is an absolute monarchy and home to Islam's holiest cities, Mecca and Medina. Riyadh is its capital. As one of the world's largest oil exporters and a leader of OPEC, it is trying to diversify its economy through its Vision 2030 program, including tourism and new cities such as NEOM.",
    "The smaller Gulf states, Kuwait, Bahrain, Qatar, the United Arab Emirates, and Oman, have become wealthy from oil and gas. Dubai, in the UAE, has transformed into a global hub for trade, aviation, finance, and tourism, home to the world's tallest building. In several Gulf states, foreign workers, mostly from South Asia, make up the majority of the population. Qatar hosted the 2022 FIFA World Cup."]],
  ["Yemen",[
    "Yemen, in the mountainous southwest of the Arabian Peninsula, is the poorest country in the Middle East. Its highlands receive monsoon rains and were known in ancient times as Arabia Felix (“Fortunate Arabia”) for their agriculture and trade in frankincense; the port of Mocha gave its name to a coffee once exported from there.",
    "Since 2014, a civil war between the Houthi movement and the internationally recognized government, backed by a Saudi-led coalition, has caused one of the world's worst humanitarian crises. Yemen controls the Bab-el-Mandeb strait, where Houthi attacks on shipping since late 2023 disrupted Red Sea trade."]],
  ["Patterns and challenges",[
    "The region combines great oil wealth with poverty and conflict. Rapid population growth, high youth unemployment, water scarcity, and authoritarian governments contributed to the Arab Spring uprisings of 2010–2011. Rivalry between Saudi Arabia and Iran has fueled proxy conflicts in Yemen, Syria, Lebanon, and Iraq.",
    "Climate change threatens to make parts of the Gulf dangerously hot and to worsen water scarcity. Yet the region also has dynamic, young, and increasingly urban populations, with cities such as Istanbul, Tehran, Riyadh, Baghdad, and Dubai among the largest and fastest-changing in the world."]]
  ],
  terms:[["Levant","The eastern Mediterranean lands, from Syria to Israel and Jordan."],["Semitic languages","A language group including Arabic and Hebrew."],["Persian (Farsi)","The Indo-European language of Iran."],["Sunni and Shia","The two main branches of Islam."],["Vision 2030","Saudi Arabia's plan to diversify its economy."],["Gulf states","The oil-rich monarchies of the Persian Gulf."]],
  w:"Understanding the peoples, states, and resources of the Middle East is essential to understanding world religion, energy, and conflict.",
  src:["Middle East","Turkey","Iran","Levant","Saudi Arabia","Gulf Cooperation Council","Yemen"],
  q:[["What language do most Iranians speak?","Persian (Farsi)","Arabic","Turkish","Kurdish"],
     ["What is the capital of Turkey?","Ankara","Istanbul","Izmir","Bursa"],
     ["Which countries have Shia majorities?","Iran, Iraq, and Bahrain","Saudi Arabia, Iraq, and Syria","Turkey, Iran, and Jordan","Egypt, Iran, and Oman"],
     ["Which cities are Islam's holiest?","Mecca and Medina","Jerusalem and Damascus","Riyadh and Jeddah","Baghdad and Cairo"],
     ["Which Gulf city has become a global hub for aviation and finance?","Dubai","Kuwait City","Muscat","Manama"],
     ["Which is the poorest country in the Middle East?","Yemen","Jordan","Syria","Oman"]]},

{ t:"The Caucasus and Central Asia", s:"The heart of Eurasia",
  sec:[
  ["The Caucasus",[
    "The Caucasus lies between the Black and Caspian seas. The Greater Caucasus range, with Mount Elbrus, forms a wall between Russia and the South Caucasus countries: Georgia, Armenia, and Azerbaijan, all former Soviet republics independent since 1991. The region is one of the most linguistically diverse on Earth, with dozens of languages in a small area.",
    "Georgia, with its capital Tbilisi, has an ancient Christian tradition, its own alphabet, and a winemaking history going back about 8,000 years; Russia occupies its breakaway regions of Abkhazia and South Ossetia. Armenia, landlocked and mountainous, with its capital Yerevan in view of Mount Ararat (now in Turkey), was the first state to adopt Christianity as its official religion, in 301 CE by tradition. Azerbaijan, with its capital Baku on the Caspian, is a mostly Shia Muslim, Turkic-speaking country rich in oil and gas; Baku was one of the world's first major oil centers. Armenia and Azerbaijan fought over Nagorno-Karabakh, which Azerbaijan fully retook in 2023, causing its Armenian population to flee."]],
  ["Central Asia's land",[
    "Central Asia usually refers to five former Soviet republics: Kazakhstan, Uzbekistan, Turkmenistan, Kyrgyzstan, and Tajikistan, often with Afghanistan and western China included in broader definitions. It is the most landlocked region on Earth, far from any ocean, which gives it an extreme continental climate with very hot summers and cold winters.",
    "Vast steppes stretch across northern Kazakhstan, and deserts, the Karakum and Kyzylkum, cover much of Turkmenistan and Uzbekistan. In the southeast rise great mountain ranges: the Tian Shan and the Pamirs, called the “Roof of the World,” where several of the world's great ranges meet. Rivers from these mountains, the Amu Darya and Syr Darya, flow toward the Aral Sea."]],
  ["The Silk Road heritage",[
    "Central Asia was the heart of the Silk Roads. Oasis cities such as Samarkand, Bukhara, and Khiva in Uzbekistan grew rich from trade and became centers of Islamic learning and architecture; Samarkand was the capital of Timur (Tamerlane) in the 14th century. The region was conquered by Alexander the Great, Arabs, Mongols, and others, and from the 19th century by Russia.",
    "Most Central Asians speak Turkic languages (Kazakh, Uzbek, Turkmen, Kyrgyz), while Tajiks speak a form of Persian. Islam is the main religion, and Russian remains widely used, especially in Kazakhstan. Nomadic herding traditions remain strong in Kazakhstan, Kyrgyzstan, and Mongolia."]],
  ["Kazakhstan",[
    "Kazakhstan is the world's largest landlocked country and ninth-largest country overall, but has only about 20 million people. It has huge resources: oil from the Caspian region, including the giant Kashagan and Tengiz fields, natural gas, coal, and the world's largest production of uranium. Its capital moved from Almaty, still the largest city, to Astana in 1997.",
    "The Soviet Union used Kazakhstan for its space program, at the Baikonur Cosmodrome, from which Yuri Gagarin became the first human in space in 1961, and for nuclear testing at Semipalatinsk, which left a legacy of radiation-related illness. The Virgin Lands campaign of the 1950s plowed vast steppes for wheat."]],
  ["The southern republics",[
    "Uzbekistan, the most populous Central Asian country with about 36 million people, is doubly landlocked; its capital is Tashkent. The Soviet Union made it a major cotton producer by diverting the Amu Darya and Syr Darya for irrigation, causing the Aral Sea to shrink to a fraction of its former size, one of the worst environmental disasters of the 20th century.",
    "Turkmenistan, mostly desert, has some of the world's largest natural gas reserves and has been one of the world's most isolated and authoritarian states. Kyrgyzstan and Tajikistan are mountainous, poorer, and heavily dependent on remittances from migrants working in Russia; Tajikistan has among the highest share of remittances in GDP in the world. Their mountain rivers offer great hydropower potential."]],
  ["Afghanistan and the Great Game",[
    "Afghanistan, mountainous and landlocked, is dominated by the Hindu Kush. Its location between Central Asia, South Asia, and Iran has made it a crossroads and a battleground. In the 19th century, Britain and Russia competed for influence in Central Asia in what was called the Great Game, and Afghanistan became a buffer state; the narrow Wakhan Corridor was drawn to keep the two empires apart.",
    "Afghanistan has endured decades of war since the Soviet invasion in 1979. The Taliban returned to power in 2021. Today Central Asia is again a zone of competition, as Russia, China, through its Belt and Road Initiative, Turkey, and others seek influence over its energy resources and trade routes."]]
  ],
  terms:[["Caucasus","The mountainous region between the Black and Caspian seas."],["Nagorno-Karabakh","A region contested by Armenia and Azerbaijan."],["Central Asia","Kazakhstan, Uzbekistan, Turkmenistan, Kyrgyzstan, and Tajikistan."],["Pamirs","The high mountain knot called the Roof of the World."],["Samarkand","A great Silk Road city in Uzbekistan."],["Great Game","The 19th-century British-Russian rivalry in Central Asia."],["Buffer state","A country between rival powers that keeps them apart."]],
  w:"The Caucasus and Central Asia lie at the heart of Eurasia, shaped by mountains, deserts, the Silk Roads, Soviet rule, and competition for their resources.",
  src:["Caucasus","Georgia (country)","Armenia","Azerbaijan","Central Asia","Kazakhstan","Aral Sea","The Great Game"],
  q:[["Which was the first state to adopt Christianity officially?","Armenia","Georgia","Rome","Ethiopia"],
     ["Which Caucasus capital lies on the Caspian Sea?","Baku","Tbilisi","Yerevan","Grozny"],
     ["What is the world's largest landlocked country?","Kazakhstan","Mongolia","Chad","Bolivia"],
     ["Which mountain range is called the Roof of the World in Central Asia?","The Pamirs","The Tian Shan","The Altai","The Hindu Kush"],
     ["What caused the Aral Sea to shrink?","Diversion of rivers to irrigate cotton","Climate change alone","An earthquake","Oil drilling"],
     ["From where did Yuri Gagarin launch in 1961?","Baikonur","Plesetsk","Kapustin Yar","Vostochny"]]},

{ t:"Africa: The Physical Continent", s:"Plateaus, rifts, rivers, and climates",
  sec:[
  ["A vast continent",[
    "Africa is the second-largest continent, about 30 million square kilometers, large enough to contain the United States, China, India, and much of Europe combined; the Mercator projection makes it look much smaller than it is. It has 54 countries recognized by the UN, more than any other continent, and about 1.5 billion people, the fastest-growing population in the world.",
    "The Equator crosses Africa near its middle, so its climates and biomes are arranged roughly symmetrically north and south: rainforest at the center, then savanna, then steppe and desert, and Mediterranean climates at the far north and south."]],
  ["A plateau continent",[
    "Much of Africa is a high plateau, made of ancient rocks of the African shield, generally higher in the south and east (High Africa) and lower in the north and west (Low Africa). Plateaus drop steeply to narrow coastal plains through escarpments, such as the Great Escarpment of southern Africa, with the Drakensberg.",
    "Because of these escarpments, many African rivers plunge over rapids and falls near the coast, which long made them difficult to navigate from the sea, one reason Europeans did not penetrate the interior until the 19th century. Africa has relatively few good natural harbors and a smooth coastline."]],
  ["The Great Rift Valley",[
    "The East African Rift, part of the Great Rift Valley system, runs about 3,000 kilometers or more from the Afar region of Ethiopia through Kenya and Tanzania to Mozambique, with a western branch along the Congo's eastern border. Here the African plate is slowly splitting apart.",
    "The rift contains deep, long lakes such as Tanganyika, the world's second-deepest lake, and Malawi, as well as volcanoes, including Kilimanjaro, Africa's highest mountain at 5,895 meters, and Mount Kenya. Lake Victoria, the largest lake in Africa and the largest tropical lake in the world, lies in a basin between the rift's two branches. The rift is also a key region for human origins; fossils such as “Lucy” (about 3.2 million years old) were found in Ethiopia's Afar region."]],
  ["Great rivers",[
    "The Nile, flowing north to the Mediterranean, is formed by the White Nile, from the Lake Victoria region, and the Blue Nile, from Lake Tana in the Ethiopian Highlands, which supplies most of its water and silt; they join at Khartoum. The Congo River, the world's second-largest river by discharge and its deepest, drains the rainforest of central Africa and crosses the Equator twice.",
    "The Niger flows in a great arc through West Africa, from Guinea's highlands northeast toward the Sahara, forming the Inner Niger Delta in Mali, then southeast to the Gulf of Guinea. The Zambezi, in southern Africa, plunges over Victoria Falls (Mosi-oa-Tunya), on the Zambia–Zimbabwe border, and is dammed at Kariba and Cahora Bassa. The Okavango River ends in an inland delta in Botswana's Kalahari."]],
  ["Climates and biomes",[
    "The Congo Basin holds the world's second-largest tropical rainforest. Surrounding it, savannas cover the largest share of the continent, home to famous wildlife. North of the savanna lies the Sahel, a semi-arid belt, and then the Sahara, the world's largest hot desert, about 9 million square kilometers. In the southwest are the Namib, one of the oldest deserts on Earth, and the semi-arid Kalahari.",
    "The Ethiopian Highlands and East African highlands, cooled by altitude, have mild climates and dense populations. Rainfall in much of Africa is highly seasonal and variable, making droughts a recurring hazard, especially in the Sahel and Horn of Africa."]],
  ["Resources",[
    "Africa is rich in natural resources: about 30 percent of the world's mineral reserves, including most of its platinum, cobalt, chromium, and manganese, large shares of diamonds, gold, and bauxite, and significant oil and gas in Nigeria, Angola, Libya, Algeria, and elsewhere. It also has about 60 percent of the world's uncultivated arable land and huge solar and hydropower potential.",
    "Yet many African economies remain dependent on exporting raw materials, a legacy of colonial economies, and resource wealth has sometimes fueled conflict and corruption. Africa's biodiversity, including the great mammals of the savanna, gorillas in the rainforest, and lemurs on Madagascar, is a global treasure."]]
  ],
  terms:[["African shield","The ancient rock foundation of the continent."],["Escarpment","A steep slope separating a plateau from lowland."],["Great Rift Valley","The rift system where the African plate is splitting."],["Blue and White Nile","The two main branches of the Nile, joining at Khartoum."],["Sahel","The semi-arid belt south of the Sahara."],["Inland delta","A delta formed where a river spreads out on land, like the Okavango."]],
  w:"Africa's plateaus, rift valleys, great rivers, and climate belts shape its biodiversity, its resources, and the lives of its fast-growing population.",
  src:["Africa","Geography of Africa","East African Rift","Nile","Congo River","Niger River","Sahel"],
  q:[["How many UN-recognized countries are in Africa?","54","48","60","45"],
     ["What is Africa's highest mountain?","Kilimanjaro","Mount Kenya","Mount Stanley","Ras Dashen"],
     ["Which branch of the Nile supplies most of its water?","The Blue Nile","The White Nile","The Atbara","The Sobat"],
     ["Where do the Blue and White Nile join?","Khartoum","Cairo","Aswan","Juba"],
     ["Which river crosses the Equator twice?","The Congo","The Nile","The Niger","The Zambezi"],
     ["Which river plunges over Victoria Falls?","The Zambezi","The Limpopo","The Orange","The Congo"]]},

{ t:"North Africa and the Sahara", s:"The Maghreb, Egypt, and the great desert",
  sec:[
  ["The region",[
    "North Africa includes Morocco, Algeria, Tunisia, Libya, and Egypt, and often Sudan and the disputed territory of Western Sahara. It is closely tied to the Middle East by the Arabic language and Islam, which spread there in the 7th century, and to Europe across the Mediterranean.",
    "The western part, Morocco, Algeria, and Tunisia, is called the Maghreb, Arabic for “the west” or “where the sun sets.” Its original inhabitants are the Amazigh (Berber) peoples, whose languages are still spoken by millions, especially in Morocco and Algeria."]],
  ["The Sahara",[
    "The Sahara, the world's largest hot desert, covers about a third of Africa, stretching about 4,800 kilometers from the Atlantic to the Red Sea. Only about a quarter of it is sand seas (ergs); most is rocky plateau (hamada), gravel plains, and mountains such as the Ahaggar in Algeria and the Tibesti in Chad.",
    "The Sahara was not always a desert: during the African Humid Period, roughly 14,500 to 5,000 years ago, it was largely green savanna with lakes, as rock art of giraffes, cattle, and swimmers shows. Trade caravans of camels crossed it for centuries, carrying gold, salt, and slaves between West Africa and the Mediterranean. Nomadic peoples such as the Tuareg still live there."]],
  ["The Atlas and the Maghreb",[
    "The Atlas Mountains, formed by the collision of Africa and Europe, run through Morocco, Algeria, and Tunisia, with Toubkal in Morocco as the highest peak. They catch rain from the Atlantic and Mediterranean, so the coastal strip north of them has a Mediterranean climate where most people live and farm olives, citrus, wheat, and grapes.",
    "Morocco, a monarchy with major cities including Casablanca, its economic capital, Rabat, the capital, Fez, and Marrakesh, exports phosphates, of which it holds about 70 percent of the world's reserves, and attracts many tourists. Algeria, the largest country in Africa by area, has a population concentrated on the coast around Algiers and exports oil and gas. Tunisia, the smallest, with its capital Tunis near the site of ancient Carthage, was the birthplace of the Arab Spring in 2010–2011."]],
  ["Egypt and the Nile",[
    "Egypt, with over 110 million people, is the most populous Arab country. About 95 percent of Egyptians live on about 5 percent of the land, in the narrow Nile Valley and the Nile Delta, surrounded by desert. The ancient Greek historian Herodotus called Egypt “the gift of the Nile.” Cairo, near the head of the delta, is one of the largest cities in Africa and the Middle East.",
    "The Aswan High Dam, completed in 1970, ended the Nile's annual floods, provided hydroelectricity and year-round irrigation, and created Lake Nasser, but also trapped the fertile silt that once renewed the soil and is causing the delta to erode. The Suez Canal, opened in 1869, is a major source of revenue. Ethiopia's Grand Ethiopian Renaissance Dam on the Blue Nile, completed in the 2020s, has caused tension with Egypt, which depends on the river for almost all its water."]],
  ["Libya and Sudan",[
    "Libya is mostly desert, with its population along the coast around Tripoli and Benghazi. It has Africa's largest proven oil reserves. Muammar Gaddafi ruled it from 1969 until his overthrow and death in 2011, and the country has since been divided among rival governments. Its Great Man-Made River project pumps fossil groundwater from beneath the Sahara to coastal cities.",
    "Sudan, where the Blue and White Niles meet at Khartoum, was the largest country in Africa until South Sudan seceded in 2011 after decades of civil war. Sudan has more ancient pyramids than Egypt, built by the Kingdom of Kush at sites such as Meroë. Since 2023 a war between rival military forces has caused one of the world's largest displacement crises."]],
  ["Challenges",[
    "North Africa faces water scarcity, rapid urbanization, youth unemployment, and the effects of climate change, including drought and rising temperatures. Its countries are both sources of and transit routes for migration to Europe across the Mediterranean.",
    "Renewable energy offers opportunities: Morocco's Noor Ouarzazate complex is one of the world's largest concentrated solar power plants, and the Sahara's sunshine has prompted plans to export solar power and green hydrogen to Europe."]]
  ],
  terms:[["Maghreb","Morocco, Algeria, and Tunisia."],["Amazigh (Berbers)","The Indigenous peoples of North Africa."],["Erg","A sand sea in the desert."],["African Humid Period","When the Sahara was green, about 14,500–5,000 years ago."],["Atlas Mountains","The mountain range of northwestern Africa."],["Aswan High Dam","The dam that ended the Nile's annual floods."],["Great Man-Made River","Libya's project to pipe groundwater to the coast."]],
  w:"North Africa's desert, the Nile, and the Mediterranean coast explain where its people live, its ancient civilizations, and its ties to both Europe and the Middle East.",
  src:["North Africa","Maghreb","Sahara","Atlas Mountains","Egypt","Aswan Dam","Sudan"],
  q:[["What does Maghreb mean?","The west","The desert","The coast","The mountains"],
     ["Roughly what share of the Sahara is sand seas?","About a quarter","About three-quarters","Almost all","About a tenth"],
     ["Which is the largest country in Africa by area?","Algeria","Sudan","The DRC","Libya"],
     ["Of which mineral does Morocco hold about 70 percent of world reserves?","Phosphates","Gold","Uranium","Cobalt"],
     ["Who called Egypt the gift of the Nile?","Herodotus","Plato","Alexander the Great","Strabo"],
     ["Which country has more ancient pyramids than Egypt?","Sudan","Libya","Ethiopia","Mexico"]]}

]});


/* ---- from geo-15.js ---- */
/* GEOGRAPHY FOUNDATIONS, part 15: Unit 7 chapters 6-10 */
COURSES.geography.units[6].ch.push(

{ t:"West Africa", s:"From the Sahel to the Gulf of Guinea",
  sec:[
  ["Belts of climate",[
    "West Africa, the bulge of the continent south of the Sahara, includes about 16 countries, from Senegal and Mauritania in the west to Nigeria and Niger in the east. Climate and vegetation run in east-west belts: the Sahara in the north, then the semi-arid Sahel, the savanna, and the humid forest zone along the Gulf of Guinea coast. Rainfall increases from north to south and comes mainly with the summer monsoon.",
    "In winter, the harmattan, a dry, dusty wind from the Sahara, blows across the region. The Sahel suffered severe droughts and famines in the 1970s and 1980s, and desertification, driven by drought, overgrazing, and population pressure, remains a concern. The Great Green Wall initiative aims to restore land across the Sahel."]],
  ["Peoples and history",[
    "West Africa has a long history of states and cities. The empires of Ghana, Mali, and Songhai grew rich from trans-Saharan trade in gold and salt; Mali's ruler Mansa Musa made a famous pilgrimage to Mecca in 1324, and Timbuktu became a center of Islamic scholarship. Forest kingdoms such as Benin, Oyo, Asante, and Dahomey flourished to the south.",
    "From the 15th to the 19th centuries, the Atlantic slave trade took millions of people from West Africa's coast, devastating societies. Colonial rule followed, mainly by France and Britain, leaving French and English as official languages. Hundreds of languages are spoken, including Hausa, Yoruba, Igbo, Wolof, Fula, Akan, and Mandinka. Islam predominates in the north and Christianity in much of the south."]],
  ["Nigeria",[
    "Nigeria is Africa's most populous country, with over 220 million people, and one of its largest economies. It has more than 250 ethnic groups; the largest are the Hausa-Fulani in the mostly Muslim north, the Yoruba in the southwest, and the Igbo in the southeast. The Niger and its tributary the Benue meet at Lokoja and form a Y dividing the country into regions.",
    "Lagos, the former capital and economic center, is one of Africa's largest cities; Abuja, in the center, became the capital in 1991. Oil from the Niger Delta dominates exports and government revenue but has caused pollution and conflict. Nigeria's film industry, Nollywood, and music, including Afrobeats, are globally influential. The Biafran War (1967–1970) followed an attempt by the southeast to secede."]],
  ["Ghana, Senegal, and the coast",[
    "Ghana, formerly the Gold Coast, became the first sub-Saharan colony to gain independence from Britain, in 1957; its capital is Accra. It exports gold, cocoa, and oil. Côte d'Ivoire (Ivory Coast) is the world's largest producer of cocoa, and together with Ghana produces about 60 percent of the world's supply; Abidjan is its economic capital.",
    "Senegal, with its capital Dakar on the westernmost point of mainland Africa, is known for political stability. Liberia, founded in the 1820s by freed African Americans, and Sierra Leone, with its capital Freetown founded for freed slaves, both suffered civil wars in the 1990s. Guinea has some of the world's largest bauxite reserves."]],
  ["The Sahel states",[
    "The landlocked Sahel countries, Mali, Burkina Faso, and Niger, are among the poorest in the world, with fast-growing populations; Niger has the world's highest fertility rate. Most people depend on farming millet and sorghum and herding cattle, goats, and camels, vulnerable to drought.",
    "Since 2012, jihadist insurgencies have spread across the Sahel, displacing millions, and military coups took place in Mali, Burkina Faso, and Niger in 2020–2023. Lake Chad, shared by Chad, Niger, Nigeria, and Cameroon, shrank dramatically from the 1960s due to drought and irrigation."]],
  ["Economies and urbanization",[
    "West African economies rely heavily on exports of raw materials: oil (Nigeria), cocoa and coffee (Côte d'Ivoire, Ghana), gold (Ghana, Mali, Burkina Faso), and uranium (Niger). Informal trade and markets are central to daily life.",
    "The region is urbanizing rapidly. A coastal urban corridor stretching from Abidjan through Accra, Lomé, and Cotonou to Lagos, about 1,000 kilometers, is becoming one of the world's great megaregions. The Economic Community of West African States (ECOWAS), founded in 1975, promotes trade and free movement."]]
  ],
  terms:[["Sahel","The semi-arid belt between the Sahara and the savanna."],["Harmattan","The dry, dusty winter wind from the Sahara."],["Great Green Wall","An initiative to restore land across the Sahel."],["Mali Empire","The medieval empire of Mansa Musa and Timbuktu."],["Niger Delta","Nigeria's oil-rich delta region."],["ECOWAS","The Economic Community of West African States."]],
  w:"West Africa's climate belts, ancient empires, and fast-growing cities make it one of the world's most dynamic and populous regions.",
  src:["West Africa","Sahel","Mali Empire","Nigeria","Lagos","Ghana","Economic Community of West African States"],
  q:[["What is the dry dusty wind from the Sahara called?","The harmattan","The sirocco","The khamsin","The simoom"],
     ["Which ruler made a famous pilgrimage to Mecca in 1324?","Mansa Musa","Sundiata Keita","Askia Muhammad","Sonni Ali"],
     ["What is Africa's most populous country?","Nigeria","Ethiopia","Egypt","DR Congo"],
     ["What became Nigeria's capital in 1991?","Abuja","Lagos","Kano","Ibadan"],
     ["Which country is the world's largest cocoa producer?","Côte d'Ivoire","Ghana","Nigeria","Brazil"],
     ["Which country was founded by freed African Americans?","Liberia","Sierra Leone","Ghana","Senegal"]]},

{ t:"East Africa and the Horn", s:"Highlands, rift lakes, and savannas",
  sec:[
  ["The region",[
    "East Africa includes Kenya, Tanzania, Uganda, Rwanda, Burundi, and South Sudan, and the Horn of Africa, the peninsula jutting into the Arabian Sea, includes Ethiopia, Eritrea, Djibouti, and Somalia. The region is dominated by highlands and the Great Rift Valley, with its lakes and volcanoes.",
    "Swahili, a Bantu language with many Arabic loanwords that developed along the trading coast, is a lingua franca across much of East Africa and an official language of Kenya, Tanzania, and the African Union. The region has been shaped by Indian Ocean trade for over a thousand years."]],
  ["Ethiopia and the Horn",[
    "Ethiopia, with about 125 million people, is Africa's second most populous country and the largest landlocked country by population in the world. Its high plateau, the Ethiopian Highlands, sometimes called the Roof of Africa, has a mild climate and fertile soils and is the source of the Blue Nile. Addis Ababa, the capital, hosts the African Union. Ethiopia is the birthplace of coffee.",
    "Ethiopia was never colonized, apart from a brief Italian occupation (1936–1941), and its Orthodox Christian tradition dates to the 4th century; the rock-hewn churches of Lalibela are famous. Eritrea gained independence from Ethiopia in 1993, leaving Ethiopia landlocked. Somalia, with Africa's longest mainland coastline, has suffered state collapse and civil war since 1991; Somaliland in the north functions as a self-declared but unrecognized state. Djibouti, at the Bab-el-Mandeb, hosts military bases of several powers."]],
  ["Kenya and Tanzania",[
    "Kenya, straddling the Equator, has highlands in the southwest, where Nairobi, the capital and a major regional hub, lies, and arid lands in the north. The Kenyan Highlands are important for tea, coffee, and cut flowers. Kenya is famous for its wildlife and parks such as the Maasai Mara, and is a technology hub; its mobile-money system, M-Pesa, launched in 2007, transformed banking.",
    "Tanzania contains Kilimanjaro, the Serengeti, the Ngorongoro Crater, and Zanzibar, an island once the center of the Swahili coast and the Indian Ocean slave and spice trade. Its largest city is Dar es Salaam; the official capital is Dodoma. Olduvai Gorge, in Tanzania, has yielded many early human fossils."]],
  ["The Great Lakes region",[
    "Uganda, Rwanda, and Burundi lie in the African Great Lakes region around Lakes Victoria, Albert, Edward, Kivu, and Tanganyika. Uganda's capital Kampala is near Lake Victoria, where the White Nile begins. Rwanda, densely populated and mountainous, the “land of a thousand hills,” suffered the 1994 genocide against the Tutsi and has since rebuilt with rapid growth. The Virunga Mountains, shared with Uganda and the DRC, shelter endangered mountain gorillas.",
    "South Sudan became independent from Sudan in 2011, the world's newest country, but has suffered civil war. The Sudd, a vast swamp on the White Nile, is one of the largest wetlands in Africa."]],
  ["Wildlife and tourism",[
    "East Africa's savannas host the greatest concentrations of large mammals on Earth. The annual Great Migration of over a million wildebeest, with zebras and gazelles, moves between Tanzania's Serengeti and Kenya's Maasai Mara following the rains. Pastoralist peoples such as the Maasai have long shared these lands with wildlife.",
    "Tourism is a major industry, and conservation efforts protect elephants and rhinos from poaching. Tensions arise between conservation, the needs of growing farming populations, and the land rights of pastoralists."]],
  ["Challenges",[
    "The Horn of Africa is prone to recurrent droughts; the 2011 famine in Somalia killed about a quarter of a million people, and a severe drought from 2020 to 2023 was the worst in decades. Conflicts, such as the Tigray War in northern Ethiopia (2020–2022), have caused great suffering.",
    "At the same time, East Africa has some of the continent's fastest-growing economies, investing in railways, ports, and energy, including geothermal power in Kenya's Rift Valley and hydropower such as Ethiopia's Grand Ethiopian Renaissance Dam."]]
  ],
  terms:[["Horn of Africa","The peninsula including Ethiopia, Eritrea, Djibouti, and Somalia."],["Swahili","A Bantu language and lingua franca of East Africa."],["Ethiopian Highlands","The high plateau called the Roof of Africa."],["M-Pesa","Kenya's mobile-money system."],["Great Migration","The annual wildebeest migration in the Serengeti and Mara."],["African Great Lakes","The lakes of the rift region, including Victoria and Tanganyika."]],
  w:"East Africa's highlands, rift lakes, and savannas make it a cradle of humanity and wildlife, with rapidly growing economies and recurring challenges of drought and conflict.",
  src:["East Africa","Horn of Africa","Ethiopia","Kenya","Tanzania","Swahili language","Serengeti"],
  q:[["Which East African language is a lingua franca with many Arabic loanwords?","Swahili","Amharic","Somali","Luganda"],
     ["Which city hosts the African Union?","Addis Ababa","Nairobi","Kampala","Dar es Salaam"],
     ["Which crop originated in Ethiopia?","Coffee","Tea","Cocoa","Tobacco"],
     ["Which Kenyan system transformed mobile banking?","M-Pesa","Safaricom Pay","Kipochi","Equitel"],
     ["Which country is called the land of a thousand hills?","Rwanda","Burundi","Uganda","Ethiopia"],
     ["Which country became independent in 2011?","South Sudan","Eritrea","Somaliland","Djibouti"]]},

{ t:"Central and Southern Africa", s:"The Congo Basin to the Cape",
  sec:[
  ["The Congo Basin",[
    "Central Africa is dominated by the Congo Basin, a vast, shallow depression drained by the Congo River and covered by the world's second-largest tropical rainforest. The Democratic Republic of the Congo (DRC), the second-largest country in Africa by area with over 100 million people, occupies most of it; its capital, Kinshasa, faces Brazzaville, capital of the Republic of the Congo, across the river, the closest pair of capitals in the world apart from Rome and Vatican City.",
    "Other countries of the region include Cameroon, Gabon, Equatorial Guinea, the Central African Republic, and Chad. Peoples include Bantu-speaking farmers and forest-dwelling peoples such as the Mbuti and Baka."]],
  ["The DRC's riches and troubles",[
    "The DRC is among the richest countries in the world in mineral resources: it produces about 70 percent of the world's cobalt, essential for batteries, as well as copper, from the Katanga region, diamonds, gold, tin, and coltan, used in electronics. The Inga Falls on the lower Congo have enormous hydropower potential.",
    "Yet it is one of the poorest countries. Its history includes brutal exploitation under King Leopold II's Congo Free State (1885–1908), Belgian colonial rule, the Mobutu dictatorship, and the Congo Wars of 1996–2003, the deadliest conflicts since World War II, with millions of deaths, mostly from disease and hunger. Armed groups still fight over minerals in the east."]],
  ["Southern Africa's land",[
    "Southern Africa is largely a high plateau bounded by the Great Escarpment, which drops to narrow coastal plains; the Drakensberg mountains form its highest part. The interior includes the Highveld grasslands of South Africa, the Kalahari Desert, and, along the Atlantic coast, the Namib Desert, one of the world's oldest, with some of the tallest sand dunes.",
    "The Zambezi and Limpopo rivers flow to the Indian Ocean, and the Orange River to the Atlantic. Climates range from Mediterranean at the Cape to subtropical in the east, desert in the west, and savanna in the north."]],
  ["South Africa",[
    "South Africa is the most industrialized country in Africa and one of its largest economies. It has three capitals: Pretoria (executive), Cape Town (legislative), and Bloemfontein (judicial); Johannesburg, built on the gold of the Witwatersrand discovered in 1886, is the largest city and economic center. It is a leading producer of platinum, gold, chromium, manganese, and coal, which generates most of its electricity.",
    "After apartheid ended in 1994, South Africa became a multiracial democracy, the “Rainbow Nation,” with twelve official languages, including Zulu, Xhosa, Afrikaans, and English. It remains one of the most unequal countries in the world, with high unemployment and spatial divides inherited from apartheid's townships. The Cape Floristic Region is one of the world's richest areas for plants. Lesotho and Eswatini are small kingdoms within or beside it."]],
  ["Other southern African countries",[
    "Botswana, mostly covered by the Kalahari, became one of Africa's success stories after independence in 1966, using diamond wealth to build infrastructure and stable democratic institutions; the Okavango Delta is a wildlife haven. Namibia, with deserts and the Skeleton Coast, has uranium and diamonds. Zimbabwe, with the ancient stone city of Great Zimbabwe, which gave the country its name, suffered economic collapse and hyperinflation in the 2000s.",
    "Zambia's economy depends on copper from the Copperbelt. Angola is a major oil producer, and Mozambique, with a long Indian Ocean coast, has large gas reserves. Malawi, centered on Lake Malawi, is densely populated and poor. Madagascar, the world's fourth-largest island, split from Africa and India millions of years ago; about 90 percent of its wildlife, including lemurs, is found nowhere else, but much of its forest has been cleared."]],
  ["Shared challenges",[
    "Southern Africa was severely affected by HIV/AIDS, which in the 2000s reduced life expectancy in Botswana, Zimbabwe, Eswatini, and South Africa by more than a decade; treatment has since restored much of the loss. Drought, worsened by El Niño, threatens food and hydropower, as at the Kariba Dam.",
    "The Southern African Development Community promotes regional cooperation. Migration to South Africa from neighboring countries is large and sometimes contentious. The region's mineral wealth, wildlife tourism, and growing cities offer great potential."]]
  ],
  terms:[["Congo Basin","The rainforest-covered basin of the Congo River."],["Coltan","An ore used in electronics, mined in the DRC."],["Congo Free State","King Leopold II's brutal private colony."],["Great Escarpment","The steep edge of southern Africa's plateau."],["Witwatersrand","The gold-bearing ridge around Johannesburg."],["Rainbow Nation","A name for post-apartheid South Africa."],["Okavango Delta","An inland delta in Botswana."]],
  w:"Central and southern Africa hold enormous mineral and natural wealth, from the Congo rainforest to South Africa's gold, alongside deep legacies of exploitation and inequality.",
  src:["Central Africa","Congo Basin","Democratic Republic of the Congo","Southern Africa","South Africa","Botswana","Madagascar"],
  q:[["Which two capitals face each other across the Congo River?","Kinshasa and Brazzaville","Kinshasa and Luanda","Brazzaville and Libreville","Kinshasa and Kigali"],
     ["What share of the world's cobalt does the DRC produce?","About 70 percent","About 10 percent","About 30 percent","Almost none"],
     ["Who ruled the Congo Free State as a private colony?","King Leopold II","Cecil Rhodes","Henry Morton Stanley","Mobutu Sese Seko"],
     ["Which South African city was built on gold discovered in 1886?","Johannesburg","Pretoria","Durban","Kimberley"],
     ["Which country used diamond wealth to become a stable success story?","Botswana","Angola","Zimbabwe","Namibia"],
     ["Which island's wildlife, including lemurs, is about 90 percent endemic?","Madagascar","Mauritius","Zanzibar","Comoros"]]},

{ t:"India", s:"The world's most populous country",
  sec:[
  ["The subcontinent",[
    "India dominates the Indian subcontinent, a landmass that broke from Gondwana and collided with Asia, raising the Himalayas. With over 1.4 billion people, India became the world's most populous country in 2023. It is the seventh-largest country by area, a federal republic of 28 states and 8 union territories, and the world's largest democracy. New Delhi is the capital.",
    "India has three main physical regions: the Himalayas and other mountains in the north; the Indo-Gangetic Plain, a vast fertile lowland; and the Deccan Plateau in the peninsula, an old plateau bordered by the Western Ghats and Eastern Ghats and coastal plains. The Thar Desert lies in the northwest."]],
  ["Rivers and the monsoon",[
    "The Ganges (Ganga), flowing from the Himalayas across the northern plain to the Bay of Bengal, is India's most sacred and important river; its basin supports hundreds of millions of people. The Brahmaputra flows through Assam, and the Indus, which gave India its name, flows mainly through Pakistan. Peninsular rivers include the Godavari, Krishna, and Kaveri.",
    "Life in India revolves around the southwest monsoon, which brings about three-quarters of the annual rain from June to September. The timing and strength of the monsoon affect harvests, water supplies, and the economy. The Western Ghats and northeast receive very heavy rain; Mawsynram and Cherrapunji in Meghalaya are among the wettest places on Earth."]],
  ["Diversity",[
    "India is extraordinarily diverse. Its constitution recognizes 22 scheduled languages; Hindi, spoken mainly in the north, is the most widespread, while Dravidian languages such as Tamil, Telugu, Kannada, and Malayalam dominate the south, and English is widely used in government, business, and higher education. Many states were organized along linguistic lines after 1956.",
    "About 80 percent of Indians are Hindu, about 14 percent Muslim, giving India one of the world's largest Muslim populations, with Christians, Sikhs, Buddhists, and Jains. The caste system, though legally abolished as a basis for discrimination, still influences society, and the constitution provides reserved places in education and jobs for disadvantaged groups."]],
  ["Cities",[
    "India's largest urban areas are Delhi, Mumbai, the financial and film capital, home of Bollywood, Kolkata, Bengaluru, the technology hub, Chennai, Hyderabad, Ahmedabad, and Pune. India is urbanizing rapidly, though about two-thirds of its people still live in rural areas.",
    "Cities face severe challenges: slums, inadequate water and sanitation, traffic, and air pollution; Delhi often has some of the worst air quality in the world, especially in winter when crop-residue burning adds to smoke and smog."]],
  ["Economy",[
    "India has one of the world's fastest-growing major economies and became the fifth-largest economy in the 2020s. After economic liberalization in 1991, it became a global center for information technology and business services, and it has growing manufacturing in automobiles, pharmaceuticals, often called the “pharmacy of the world” for generic drugs, and electronics.",
    "Agriculture still employs over 40 percent of workers, though it produces a much smaller share of output. India is a leading producer of rice, wheat, milk, sugarcane, cotton, tea, and spices. The Green Revolution, centered on Punjab and Haryana in the 1960s and 1970s, made India self-sufficient in grain, but has depleted groundwater."]],
  ["Challenges",[
    "Despite great progress in reducing extreme poverty, India still faces widespread poverty, malnutrition, unemployment among young people, and inequality between richer southern and western states and poorer northern and eastern ones. Water scarcity, air pollution, heat waves, and the effects of climate change on the monsoon and Himalayan glaciers are major concerns.",
    "India's location gives it a central role in the Indian Ocean. Its borders with Pakistan and China are disputed, especially in Kashmir and along the Himalayan frontier, where clashes occurred in 2020."]]
  ],
  terms:[["Indian subcontinent","The landmass of South Asia south of the Himalayas."],["Indo-Gangetic Plain","The vast fertile lowland of northern India."],["Deccan Plateau","The plateau of peninsular India."],["Western Ghats","The mountains along India's west coast."],["Southwest monsoon","The summer rains that bring most of India's precipitation."],["Bollywood","Mumbai's Hindi film industry."]],
  w:"India's size, diversity, monsoon-dependent agriculture, and rapid growth make it one of the most important countries for the world's future.",
  src:["India","Geography of India","Indo-Gangetic Plain","Deccan Plateau","Monsoon of South Asia","Languages of India","Economy of India"],
  q:[["When did India become the world's most populous country?","2023","2000","2010","2030"],
     ["What is the plateau of peninsular India called?","The Deccan","The Thar","The Malwa","The Chota Nagpur"],
     ["What share of India's rain comes with the southwest monsoon?","About three-quarters","About a quarter","About half","Almost none"],
     ["Which Indian city is the technology hub?","Bengaluru","Kolkata","Jaipur","Lucknow"],
     ["Which states led India's Green Revolution?","Punjab and Haryana","Kerala and Tamil Nadu","Bihar and Odisha","Gujarat and Rajasthan"],
     ["Which language family includes Tamil and Telugu?","Dravidian","Indo-European","Sino-Tibetan","Austroasiatic"]]},

{ t:"South Asia beyond India", s:"Pakistan, Bangladesh, Nepal, Bhutan, Sri Lanka, and the Maldives",
  sec:[
  ["The Himalayas",[
    "The Himalayas, the world's highest mountains, form South Asia's northern wall, stretching about 2,400 kilometers. They contain ten of the world's fourteen peaks above 8,000 meters; the other four, including K2, the second-highest mountain, are in the neighboring Karakoram. Mount Everest (8,849 meters), called Sagarmatha in Nepali and Chomolungma in Tibetan, lies on the Nepal-China border; it was first climbed by Edmund Hillary and Tenzing Norgay in 1953.",
    "The Himalayas block cold air from Central Asia and force monsoon winds to rise and drop rain, and their glaciers and snow feed the Indus, Ganges, and Brahmaputra, sustaining hundreds of millions of people."]],
  ["Pakistan",[
    "Pakistan, with about 240 million people, is the fifth most populous country. It was created in 1947 as a homeland for South Asia's Muslims. Its core is the Indus River valley, irrigated by one of the world's largest canal systems, especially in Punjab, the agricultural heartland. In the north rise the Karakoram and Hindu Kush; in the west, the arid plateaus of Balochistan.",
    "Karachi, on the Arabian Sea, is the largest city and port; Lahore is the cultural center of Punjab; Islamabad is the planned capital. Urdu is the national language, though Punjabi is most widely spoken. Pakistan's economy depends on agriculture, especially cotton and textiles. The 2022 floods, which submerged about a third of the country, showed its vulnerability to climate change. The dispute with India over Kashmir has caused several wars."]],
  ["Bangladesh",[
    "Bangladesh, formerly East Pakistan, became independent in 1971 after a war with Pakistan. With about 170 million people in an area smaller than Florida, it is among the most densely populated countries in the world. Most of it lies on the world's largest delta, formed by the Ganges (Padma), Brahmaputra (Jamuna), and Meghna rivers, with the Sundarbans mangrove forest along the coast. Dhaka is the capital and one of the world's largest and densest cities.",
    "Bangladesh is extremely vulnerable to floods, cyclones, and sea level rise, but it has made remarkable progress in reducing poverty and improving health and girls' education. It is the world's second-largest exporter of garments after China."]],
  ["Nepal and Bhutan",[
    "Nepal, landlocked between India and China, rises from the Terai lowlands to the high Himalayas, including eight of the world's ten highest peaks. Kathmandu is the capital. Nepal is the birthplace of the Buddha, at Lumbini. It became a republic in 2008 after abolishing its monarchy. Its economy relies on agriculture, tourism, trekking, and remittances; the 2015 earthquake killed about 9,000 people.",
    "Bhutan, a small Himalayan Buddhist kingdom, is famous for measuring progress through Gross National Happiness, a concept introduced in the 1970s, and for being carbon-negative, thanks to forests covering over 70 percent of its land and exports of hydroelectricity to India."]],
  ["Sri Lanka and the Maldives",[
    "Sri Lanka, a teardrop-shaped island south of India, has a mountainous center with tea plantations, a legacy of British rule, and coastal plains. Its majority Sinhalese are mostly Buddhist, while Tamils, mostly Hindu, live mainly in the north and east. A civil war between the government and the Tamil Tigers lasted from 1983 to 2009. The commercial capital is Colombo. Sri Lanka is a leading exporter of tea and suffered a severe economic crisis in 2022.",
    "The Maldives, a chain of about 1,200 coral islands in the Indian Ocean, is the lowest-lying country in the world, with an average elevation of about 1.5 meters, making it extremely vulnerable to sea level rise. Its economy depends on luxury tourism and fishing."]],
  ["A shared region",[
    "South Asia is home to about a quarter of humanity on about 3 percent of the world's land. Its countries share histories under the Mughal and British empires, overlapping cultures, the monsoon, and Himalayan rivers, yet regional cooperation, through the South Asian Association for Regional Cooperation (SAARC), has been limited by India-Pakistan rivalry.",
    "Sharing rivers is a key issue: the Indus Waters Treaty of 1960 divided the Indus system between India and Pakistan, and the Ganges and Brahmaputra are shared by China, India, Nepal, Bhutan, and Bangladesh."]]
  ],
  terms:[["Himalayas","The world's highest mountain range."],["Karakoram","The range containing K2."],["Indus Valley","Pakistan's irrigated agricultural core."],["Ganges-Brahmaputra delta","The world's largest delta, in Bangladesh and India."],["Gross National Happiness","Bhutan's measure of progress."],["Indus Waters Treaty","The 1960 India-Pakistan treaty dividing the Indus rivers."]],
  w:"South Asia's mountains, rivers, and monsoon support a quarter of humanity, and its countries face shared challenges of population, water, and climate.",
  src:["South Asia","Himalayas","Pakistan","Bangladesh","Nepal","Bhutan","Sri Lanka","Maldives"],
  q:[["Who first climbed Everest in 1953?","Edmund Hillary and Tenzing Norgay","George Mallory and Andrew Irvine","Reinhold Messner and Peter Habeler","Junko Tabei"],
     ["In which range is K2?","The Karakoram","The Himalayas","The Hindu Kush","The Pamirs"],
     ["What is Pakistan's largest city?","Karachi","Lahore","Islamabad","Rawalpindi"],
     ["What was Bangladesh called before 1971?","East Pakistan","East Bengal Republic","Assam","West Bengal"],
     ["Which country measures Gross National Happiness?","Bhutan","Nepal","Sri Lanka","Maldives"],
     ["Which is the lowest-lying country in the world?","The Maldives","Bangladesh","The Netherlands","Tuvalu"]]}

);


/* ---- from geo-16.js ---- */
/* GEOGRAPHY FOUNDATIONS, part 16: Unit 7 chapters 11-15 (East and Southeast Asia) */
COURSES.geography.units[6].ch.push(

{ t:"China", s:"Land, people, and the world's factory",
  sec:[
  ["A vast and varied land",[
    "China is the fourth-largest country by area, about 9.6 million square kilometers, and the second most populous, with about 1.41 billion people. Its land descends in three great steps from west to east. The highest is the Tibetan Plateau, averaging over 4,500 meters, bordered by the Himalayas, Kunlun, and other ranges. The second step includes the deserts and basins of the northwest, such as the Taklamakan Desert in the Tarim Basin and the Gobi, and plateaus such as the Loess Plateau.",
    "The lowest step, in the east, contains the great plains and river valleys where most Chinese live: the North China Plain, the Yangtze valley, and the Pearl River Delta. A rough line from Heihe in the northeast to Tengchong in the southwest, drawn by the geographer Hu Huanyong in 1935, divides China into a densely settled east, with over 90 percent of the population, and a sparsely settled west."]],
  ["Rivers and climate",[
    "China's two great rivers flow east from the Tibetan Plateau. The Yellow River (Huang He), named for the loess silt it carries, nurtured early Chinese civilization on the North China Plain but has flooded catastrophically, earning the name “China's Sorrow.” The Yangtze (Chang Jiang), the longest river in Asia and third-longest in the world, flows through Chongqing, Wuhan, and Nanjing to Shanghai; the Three Gorges Dam spans it. The Pearl River reaches the sea near Guangzhou and Hong Kong.",
    "The Qinling Mountains and Huai River form a traditional dividing line between north China, with cold dry winters, wheat and millet farming, and less rain, and south China, warmer and wetter with rice paddies, influenced by the East Asian monsoon. Northern China faces water scarcity, addressed by the vast South–North Water Transfer Project."]],
  ["People",[
    "About 91 percent of Chinese belong to the Han ethnic group; the government recognizes 55 minority nationalities, including Zhuang, Uyghurs, Hui, Manchu, Tibetans, and Mongols, concentrated in the border regions. Tibet and Xinjiang are autonomous regions with large non-Han populations, and government policies there, including mass detention of Uyghurs, have drawn international criticism.",
    "Mandarin (Putonghua) is the official language, but other Chinese languages, such as Cantonese, Wu (Shanghainese), and Min, are widely spoken. China's population began to decline in 2022 after decades of low fertility shaped partly by the one-child policy (1980–2015), and it is aging rapidly."]],
  ["Urbanization",[
    "China has undergone the fastest large-scale urbanization in history: its urban share rose from under 20 percent in 1980 to over 65 percent by the 2020s. Hundreds of millions migrated from the countryside to cities. China has dozens of cities with more than 5 million people. Beijing is the capital; Shanghai is the largest city and financial center; Guangzhou and Shenzhen anchor the Pearl River Delta, one of the world's largest urban regions.",
    "Shenzhen grew from a small town into a city of over 17 million after becoming China's first Special Economic Zone in 1980. Hong Kong and Macau are Special Administrative Regions."]],
  ["The world's factory",[
    "Since reforms began in 1978, China has become the world's second-largest economy and largest manufacturer and exporter, producing much of the world's electronics, textiles, steel, ships, and solar panels. Growth was led first by coastal provinces and export zones, then spread inland. China is the world's largest producer of rice, wheat, pork, and many other foods, and the largest consumer of coal and emitter of carbon dioxide, while also leading the world in installing solar and wind power and producing electric vehicles.",
    "China has built the world's largest high-speed rail and expressway networks. Its Belt and Road Initiative finances infrastructure across Asia, Africa, and beyond."]],
  ["Challenges",[
    "China faces air and water pollution, though air quality improved after 2013; water scarcity in the north; inequality between the rich coast and poorer interior and between urban and rural residents, reinforced by the hukou household registration system; an aging population; and slowing growth.",
    "Geopolitically, China's claims in the South China Sea, its stance on Taiwan, and its rivalry with the United States are central issues in world affairs. China borders 14 countries, tied with Russia for the most of any country."]]
  ],
  terms:[["Tibetan Plateau","The vast high plateau of western China."],["Hu Line","The line dividing China's dense east from its sparse west."],["Yellow River","The silt-laden river called China's Sorrow."],["Yangtze","Asia's longest river."],["Qinling–Huai line","The traditional divide between north and south China."],["Han Chinese","China's majority ethnic group."],["Hukou","China's household registration system."]],
  w:"China's geography explains its ancient civilization, its dense eastern population, and its rise as the world's factory and a superpower.",
  src:["China","Geography of China","Hu Line","Yellow River","Yangtze","Urbanization in China","Economy of China"],
  q:[["Which line divides China's dense east from its sparse west?","The Hu Line","The Qinling–Huai line","The Great Wall","The 30th parallel"],
     ["Which river is called China's Sorrow?","The Yellow River","The Yangtze","The Pearl River","The Mekong"],
     ["What is Asia's longest river?","The Yangtze","The Yellow River","The Mekong","The Ganges"],
     ["What share of Chinese belong to the Han group?","About 91 percent","About 50 percent","About 75 percent","About 99 percent"],
     ["Which city grew from a small town after becoming the first Special Economic Zone?","Shenzhen","Shanghai","Guangzhou","Xiamen"],
     ["In which year did China's population begin to decline?","2022","2000","2015","2030"]]},

{ t:"Japan", s:"An island nation on the Ring of Fire",
  sec:[
  ["Islands and mountains",[
    "Japan is an archipelago of about 14,000 islands, dominated by four main islands: Honshu, the largest, Hokkaido in the north, Kyushu in the south, and Shikoku. The Ryukyu Islands, including Okinawa, stretch southwest toward Taiwan. About three-quarters of Japan is mountainous and forested, so its 124 million people are crowded onto coastal plains and valleys.",
    "Japan lies where four tectonic plates meet, making it one of the most earthquake- and volcano-prone countries on Earth. Mount Fuji, a stratovolcano and Japan's highest peak at 3,776 meters, last erupted in 1707. The Great Kantō earthquake of 1923 devastated Tokyo and Yokohama, and the 2011 Tōhoku earthquake and tsunami killed about 18,000 people and caused the Fukushima nuclear disaster. The word tsunami is Japanese."]],
  ["Climate",[
    "Japan stretches about 3,000 kilometers from north to south, so its climates range from snowy humid continental in Hokkaido to subtropical in Okinawa. The East Asian monsoon brings humid summers, and a rainy season (tsuyu) in June and July. Typhoons strike in late summer and autumn.",
    "In winter, cold northwest winds from Siberia pick up moisture over the Sea of Japan and drop some of the world's heaviest snowfalls on the western side of Honshu, while the Pacific side is dry and sunny."]],
  ["People and cities",[
    "Japan is one of the most ethnically homogeneous large countries, though it includes the Indigenous Ainu of Hokkaido and the Ryukyuan people of Okinawa. Most people live in a densely urbanized belt along the Pacific coast called the Taiheiyō Belt or Tokaido megalopolis, stretching from Tokyo through Nagoya, Kyoto, and Osaka to Kobe and on to northern Kyushu.",
    "Greater Tokyo, with about 37 million people, is the world's largest metropolitan area, renowned for its efficient public transport. Kyoto, the imperial capital for over a thousand years until 1868, preserves many temples and shrines. Shinto and Buddhism coexist in Japanese religious life."]],
  ["Economy",[
    "With few natural resources, Japan imports most of its energy, food, and raw materials. After World War II it became an economic powerhouse, the world's second-largest economy from 1968 until China overtook it around 2010, through manufacturing excellence in automobiles (Toyota, Honda), electronics, machinery, robotics, and steel, and high-quality production methods.",
    "Its Shinkansen, the first high-speed railway, opened in 1964. Since the bursting of a financial bubble around 1990, growth has been slow, but Japan remains one of the world's largest and most technologically advanced economies. Agriculture is intensive and focused on rice, which is protected and culturally important."]],
  ["An aging society",[
    "Japan has the oldest population of any major country: about 29 percent of people are 65 or older, and life expectancy is among the world's highest. Its population peaked around 2008 and is declining by several hundred thousand a year. Rural areas are emptying, with abandoned homes (akiya) and villages.",
    "Japan has relied on automation, increased women's employment, and, cautiously, more foreign workers to address labor shortages. Its experience is closely watched by other aging societies."]],
  ["Japan and its neighbors",[
    "Japan's island position protected it from invasion; Mongol attempts in 1274 and 1281 were wrecked partly by storms remembered as kamikaze, “divine winds.” During the Tokugawa period it largely isolated itself until 1853, when U.S. ships forced it open, leading to rapid modernization after the Meiji Restoration of 1868.",
    "Territorial disputes remain with Russia over the southern Kuril Islands, called the Northern Territories in Japan; with China over the Senkaku (Diaoyu) Islands; and with South Korea over Dokdo (Takeshima). Japan is a close ally of the United States, which maintains bases in Okinawa."]]
  ],
  terms:[["Archipelago","A chain or group of islands."],["Honshu","Japan's largest island."],["Mount Fuji","Japan's highest peak, a stratovolcano."],["Taiheiyō Belt","Japan's urban-industrial corridor along the Pacific coast."],["Ainu","The Indigenous people of Hokkaido."],["Shinkansen","Japan's high-speed rail network."],["Akiya","Abandoned houses in Japan's shrinking countryside."]],
  w:"Japan shows how a mountainous, resource-poor, hazard-prone island nation became an economic power, and now faces the challenges of an aging society.",
  src:["Japan","Geography of Japan","Mount Fuji","2011 Tōhoku earthquake and tsunami","Taiheiyō Belt","Aging of Japan","Kuril Islands dispute"],
  q:[["What is Japan's largest island?","Honshu","Hokkaido","Kyushu","Shikoku"],
     ["When did Mount Fuji last erupt?","1707","1923","1854","1991"],
     ["Which disaster struck Japan in 2011?","The Tōhoku earthquake and tsunami","The Great Kantō earthquake","The Kobe earthquake","The Unzen eruption"],
     ["Who are the Indigenous people of Hokkaido?","The Ainu","The Ryukyuans","The Emishi","The Jōmon"],
     ["Which city was Japan's imperial capital until 1868?","Kyoto","Nara","Osaka","Kamakura"],
     ["What share of Japanese are 65 or older?","About 29 percent","About 10 percent","About 45 percent","About 18 percent"]]},

{ t:"Korea, Taiwan, and Mongolia", s:"East Asia beyond China and Japan",
  sec:[
  ["The Korean Peninsula",[
    "The Korean Peninsula extends south from northeast China between the Yellow Sea and the Sea of Japan (called the East Sea in Korea). It is mountainous, about 70 percent hills and mountains, with plains along the west and south coasts. Mount Paektu on the Chinese border, a volcano, is sacred to Koreans, and the Han River flows through Seoul.",
    "Koreans share a common language and culture with a history going back thousands of years; the Korean alphabet, Hangul, was created in 1443 under King Sejong. Korea was annexed by Japan in 1910 and divided after 1945 along the 38th parallel. The Korean War (1950–1953) ended in an armistice, not a peace treaty, and the Demilitarized Zone (DMZ), about 4 kilometers wide, remains one of the world's most heavily fortified borders."]],
  ["South Korea",[
    "South Korea, with about 52 million people, transformed from one of the world's poorest countries in the 1950s into a wealthy, high-tech democracy, a story called the “Miracle on the Han River.” Its economy is led by large conglomerates (chaebol) such as Samsung, Hyundai, and LG, producing semiconductors, smartphones, ships, and cars.",
    "About half of South Koreans live in the Seoul Capital Area, one of the world's largest metropolitan areas; Busan is the main port. South Korean popular culture, including K-pop and television dramas, spread worldwide in the 2010s, a phenomenon called the Korean Wave (Hallyu). The country has the lowest fertility rate in the world, below 1 child per woman."]],
  ["North Korea",[
    "North Korea, with about 26 million people, is one of the world's most isolated and repressive states, ruled by the Kim family since 1948 under the ideology of Juche (self-reliance). Its capital is Pyongyang. It is more mountainous than the South, with less farmland, though it has coal and minerals.",
    "A famine in the 1990s killed hundreds of thousands. North Korea has developed nuclear weapons and missiles, conducting its first nuclear test in 2006, and is subject to international sanctions. Satellite images at night show South Korea brightly lit and North Korea almost completely dark, a striking illustration of the divide."]],
  ["Taiwan",[
    "Taiwan is an island about 160 kilometers off the coast of southeastern China, across the Taiwan Strait. Its eastern two-thirds are steep mountains, with Yushan (Jade Mountain) rising to about 3,950 meters, and most of its 23 million people live on the western plains, in cities such as Taipei, Taichung, and Kaohsiung.",
    "The Nationalist government retreated to Taiwan in 1949 after losing the Chinese civil war; Taiwan democratized in the late 1980s and 1990s. The People's Republic of China claims Taiwan, and few countries formally recognize it, though it has its own government, military, and economy. Taiwan is crucial to the world economy: TSMC manufactures most of the world's most advanced semiconductor chips."]],
  ["Mongolia",[
    "Mongolia, landlocked between Russia and China, is the most sparsely populated sovereign country in the world, with about 3.5 million people in an area larger than western Europe; nearly half live in the capital, Ulaanbaatar, the coldest national capital. Its landscapes include the Altai Mountains, the Gobi Desert in the south, and vast steppes.",
    "Mongolia was the heart of the Mongol Empire of Genghis Khan in the 13th century, the largest contiguous land empire in history. Nomadic herding of horses, sheep, goats, cattle, and camels, with families living in round felt tents called gers (yurts), remains important. Mining of copper, coal, and gold, much of it exported to China, now drives the economy. Severe winter disasters called dzud kill millions of livestock."]],
  ["East Asia as a region",[
    "East Asia, China, Japan, the Koreas, Taiwan, and Mongolia, shares historical influences from Chinese civilization, including writing systems, Confucianism, and Mahayana Buddhism, and the rice-based agriculture of the monsoon lands.",
    "It is now one of the world's three great economic regions, alongside North America and Europe, and its manufacturing supply chains connect to the whole world. It is also an area of geopolitical tension, from the Korean Peninsula to the Taiwan Strait and the East and South China Seas."]]
  ],
  terms:[["Hangul","The Korean alphabet, created in 1443."],["38th parallel","The line along which Korea was divided."],["DMZ","The Demilitarized Zone between North and South Korea."],["Chaebol","South Korea's large family-controlled conglomerates."],["Juche","North Korea's ideology of self-reliance."],["Taiwan Strait","The waters between Taiwan and mainland China."],["Ger (yurt)","The round felt tent of Mongolian nomads."]],
  w:"The Koreas, Taiwan, and Mongolia show East Asia's sharpest contrasts, from high-tech democracies to an isolated dictatorship and the world's emptiest country.",
  src:["Korean Peninsula","South Korea","North Korea","Korean Demilitarized Zone","Taiwan","Mongolia","Hallyu"],
  q:[["When was Hangul created?","1443","1910","1592","1948"],
     ["What is South Korea's rapid development often called?","The Miracle on the Han River","The Asian Tiger Leap","The Korean Wave","The Seoul Boom"],
     ["What is North Korea's ideology of self-reliance called?","Juche","Songun","Hallyu","Chaebol"],
     ["Which Taiwanese company makes most of the world's advanced chips?","TSMC","Samsung","Intel","Foxconn"],
     ["Which is the most sparsely populated sovereign country?","Mongolia","Australia","Canada","Namibia"],
     ["What is a severe Mongolian winter disaster that kills livestock called?","Dzud","Buran","Sukhovey","Haboob"]]},

{ t:"Mainland Southeast Asia", s:"Myanmar, Thailand, Laos, Cambodia, and Vietnam",
  sec:[
  ["Rivers and mountains",[
    "Mainland Southeast Asia, also called the Indochinese Peninsula, lies between India and China. Mountain ranges and great rivers run north to south from the Tibetan Plateau, separating fertile valleys and deltas where most people live. The Irrawaddy flows through Myanmar; the Chao Phraya through central Thailand and Bangkok; the Red River through northern Vietnam to Hanoi.",
    "The Mekong, about 4,900 kilometers long, flows from Tibet through China, along the borders of Myanmar, Laos, and Thailand, through Cambodia, and into southern Vietnam, where it forms a vast delta. It supports one of the world's largest inland fisheries and feeds about 60 million people; Cambodia's Tonlé Sap lake reverses its flow each wet season as the Mekong floods. Dams in China and Laos threaten fish and sediment flows."]],
  ["Climate and rice",[
    "The region has a tropical monsoon climate, with a wet season from about May to October and a dry season. Rice, grown in flooded paddies in deltas, valleys, and on terraces, is the staple food and central to culture. Thailand and Vietnam are among the world's largest rice exporters.",
    "Tropical forests once covered most of the region but have been extensively cleared for agriculture, logging, and plantations of rubber and other crops."]],
  ["Peoples and religions",[
    "The region's peoples include Burmese, Thai, Lao, Khmer, and Vietnamese, along with many highland minorities. Theravada Buddhism, which spread from Sri Lanka, is the main religion of Myanmar, Thailand, Laos, and Cambodia, and Buddhist temples (wats) dominate their landscapes. Vietnam, long influenced by China, follows Mahayana Buddhism mixed with Confucianism and folk religion.",
    "The great Khmer Empire built Angkor in Cambodia, whose temple Angkor Wat, from the 12th century, is the largest religious monument in the world and appears on Cambodia's flag."]],
  ["Colonialism and war",[
    "Britain colonized Burma (Myanmar), and France colonized Vietnam, Laos, and Cambodia as French Indochina. Thailand (Siam) was the only Southeast Asian country never colonized, serving as a buffer between British and French territories.",
    "After World War II, the region was torn by conflict: the wars in Vietnam (1946–1975), which also engulfed Laos and Cambodia, where Laos became one of the most heavily bombed countries per person in history, and the Khmer Rouge genocide in Cambodia (1975–1979). Myanmar has suffered decades of military rule and ethnic conflict, including the 2017 expulsion of the Rohingya Muslims and civil war after a 2021 coup."]],
  ["Thailand and Vietnam",[
    "Thailand, a constitutional monarchy with about 70 million people, has a primate city, Bangkok, many times larger than any other Thai city. It is a major manufacturer of automobiles and electronics, a leading exporter of rice, rubber, and seafood, and one of the world's most visited countries. Bangkok, built on the low-lying Chao Phraya delta, is sinking and vulnerable to flooding.",
    "Vietnam, about 100 million people, is long and narrow, S-shaped along the South China Sea, with two rice-growing deltas, the Red River in the north and the Mekong in the south, linked by a narrow coastal strip, often compared to two baskets on a carrying pole. Since the Đổi Mới reforms of 1986, it has become one of the world's fastest-growing economies and a manufacturing hub, while remaining a one-party communist state. Ho Chi Minh City (Saigon) is the largest city; Hanoi is the capital."]],
  ["Laos, Cambodia, and Myanmar",[
    "Laos is the only landlocked country in Southeast Asia, mountainous and sparsely populated, with Vientiane on the Mekong as its capital; it aims to be the “battery of Southeast Asia” by exporting hydropower. Cambodia's capital is Phnom Penh; its economy relies on garments, agriculture, and tourism.",
    "Myanmar, the largest country on the mainland, has fertile valleys, jade and gem mines, timber, and natural gas, but has been impoverished by conflict and military rule. Its capital moved from Yangon to the new city of Naypyidaw in 2005-2006."]]
  ],
  terms:[["Indochinese Peninsula","Mainland Southeast Asia."],["Mekong","Southeast Asia's longest river."],["Tonlé Sap","Cambodia's lake whose flow reverses seasonally."],["Paddy","A flooded field for growing rice."],["Angkor Wat","The largest religious monument in the world."],["French Indochina","France's colony of Vietnam, Laos, and Cambodia."],["Đổi Mới","Vietnam's 1986 market reforms."]],
  w:"Mainland Southeast Asia's rivers, monsoon, and rice paddies sustain dense populations, while its turbulent 20th century gave way to rapid growth in several countries.",
  src:["Mainland Southeast Asia","Mekong","Tonlé Sap","Angkor Wat","Thailand","Vietnam","Myanmar"],
  q:[["Which lake in Cambodia reverses its flow each wet season?","Tonlé Sap","Inle Lake","Lake Toba","Songkhla Lake"],
     ["Which is the only Southeast Asian country never colonized?","Thailand","Vietnam","Myanmar","Laos"],
     ["What is the largest religious monument in the world?","Angkor Wat","Borobudur","Bagan","Shwedagon Pagoda"],
     ["Which branch of Buddhism predominates in Thailand and Myanmar?","Theravada","Mahayana","Vajrayana","Zen"],
     ["Which is the only landlocked country in Southeast Asia?","Laos","Cambodia","Myanmar","Thailand"],
     ["Which two deltas are Vietnam's rice baskets?","The Red River and Mekong","The Mekong and Chao Phraya","The Irrawaddy and Red River","The Pearl and Mekong"]]},

{ t:"Maritime Southeast Asia", s:"Indonesia, the Philippines, Malaysia, Singapore, Brunei, and Timor-Leste",
  sec:[
  ["A world of islands",[
    "Maritime (insular) Southeast Asia consists of thousands of islands and the Malay Peninsula. Indonesia, with over 17,000 islands, is the world's largest archipelagic country, stretching about 5,000 kilometers along the Equator; the Philippines has over 7,000 islands. The largest islands include Borneo, the third-largest island in the world, shared by Indonesia, Malaysia, and Brunei; Sumatra; and New Guinea, shared by Indonesia and Papua New Guinea.",
    "The region lies on the Ring of Fire, with many active volcanoes and frequent earthquakes. The 1815 eruption of Tambora was the largest in recorded history, and the 1883 eruption of Krakatoa was heard thousands of kilometers away. The 2004 Indian Ocean tsunami devastated Aceh in Sumatra."]],
  ["Climate and biodiversity",[
    "The region has a hot, humid equatorial climate with rain throughout the year, supporting tropical rainforests among the richest in species on Earth, home to orangutans, Sumatran tigers, rhinoceroses, and Komodo dragons. The Wallace Line, identified by the naturalist Alfred Russel Wallace in the 1850s, runs between Bali and Lombok and between Borneo and Sulawesi, marking a sharp divide between Asian and Australian animal species.",
    "These forests have been cleared at high rates for timber and for oil palm plantations; Indonesia and Malaysia produce about 85 percent of the world's palm oil. Peat fires set to clear land create choking haze that spreads across the region."]],
  ["Indonesia",[
    "Indonesia, with about 280 million people, is the world's fourth most populous country and has the largest Muslim population of any country. More than half its people live on Java, one of the most densely populated islands on Earth, whose fertile volcanic soils support intensive rice farming. Jakarta, on Java, is the capital, but it is sinking rapidly due to groundwater pumping, and the government is building a new capital, Nusantara, on Borneo.",
    "Indonesia has hundreds of ethnic groups and languages, united by the national language, Bahasa Indonesia, a form of Malay. Bali remains predominantly Hindu. Indonesia is rich in coal, nickel, tin, palm oil, and natural gas, and is the largest economy in Southeast Asia."]],
  ["The Philippines",[
    "The Philippines, with about 115 million people, consists of three main island groups: Luzon in the north, with Manila, the capital, Visayas in the center, and Mindanao in the south. Colonized by Spain from 1565 to 1898 and then by the United States until 1946, it is the largest Christian, mostly Catholic, country in Asia, while Mindanao has a significant Muslim population.",
    "The Philippines is one of the most disaster-prone countries in the world, struck by about 20 typhoons a year, including Typhoon Haiyan (2013), one of the strongest ever recorded. Remittances from millions of Filipinos working abroad and business process outsourcing, such as call centers, are vital to its economy."]],
  ["Malaysia, Singapore, and Brunei",[
    "Malaysia has two parts: Peninsular Malaysia, with the capital Kuala Lumpur, and Sabah and Sarawak on Borneo. Its population includes Malays, Chinese, and Indians, a legacy of colonial labor migration for tin mines and rubber plantations. It has developed from exporting rubber and tin to manufacturing electronics, as well as oil and palm oil.",
    "Singapore, a city-state on an island at the tip of the Malay Peninsula, became independent in 1965 after leaving Malaysia. Thanks to its location on the Strait of Malacca, it became one of the world's busiest ports, a global financial center, and one of the richest countries in the world, with a multicultural population of Chinese, Malays, and Indians. Brunei, a small sultanate on Borneo, is wealthy from oil and gas."]],
  ["Timor-Leste and regional cooperation",[
    "Timor-Leste (East Timor), a former Portuguese colony occupied by Indonesia in 1975, became independent in 2002 after a UN-supervised referendum and violence; it is one of the world's newest countries and is predominantly Catholic.",
    "The Association of Southeast Asian Nations (ASEAN), founded in 1967, links the countries of Southeast Asia, eleven since Timor-Leste joined in 2025, promoting trade and cooperation. Overlapping claims in the South China Sea, where China asserts rights to most of the sea, contested by the Philippines, Vietnam, Malaysia, Brunei, and Indonesia, are a major source of tension."]]
  ],
  terms:[["Archipelagic state","A country made up of many islands."],["Borneo","The world's third-largest island, shared by three countries."],["Wallace Line","The boundary between Asian and Australian fauna."],["Java","Indonesia's most populous island."],["Strait of Malacca","The vital waterway between Sumatra and the Malay Peninsula."],["City-state","An independent country consisting of a single city, like Singapore."],["ASEAN","The Association of Southeast Asian Nations."]],
  w:"Maritime Southeast Asia's islands, volcanoes, and strategic straits make it a biodiversity hotspot, a crossroads of cultures, and a center of global trade.",
  src:["Maritime Southeast Asia","Indonesia","Wallace Line","Philippines","Malaysia","Singapore","ASEAN"],
  q:[["Which is the world's largest archipelagic country?","Indonesia","The Philippines","Japan","Malaysia"],
     ["Which island is shared by Indonesia, Malaysia, and Brunei?","Borneo","Sumatra","New Guinea","Sulawesi"],
     ["What does the Wallace Line separate?","Asian and Australian animal species","Muslim and Christian regions","Indonesian and Malaysian territory","Rainforest and savanna"],
     ["Which country has the largest Muslim population?","Indonesia","Malaysia","Pakistan","Saudi Arabia"],
     ["Which is the largest Christian country in Asia?","The Philippines","Timor-Leste","South Korea","Indonesia"],
     ["When did Singapore become independent?","1965","1957","1946","1975"]]}

);


/* ---- from geo-17.js ---- */
/* GEOGRAPHY FOUNDATIONS, part 17: Unit 7 chapters 16-19 (Oceania, the poles, and the future) */
COURSES.geography.units[6].ch.push(

{ t:"Australia", s:"The island continent",
  sec:[
  ["An ancient, flat, dry continent",[
    "Australia is both a country and the smallest continent, about 7.7 million square kilometers, roughly the size of the contiguous United States, but with only about 27 million people. It is the flattest and, apart from Antarctica, the driest inhabited continent. Its ancient, weathered landscapes have poor soils, and much of the interior, the Outback, is desert or semi-arid scrub.",
    "Its main regions are the Western Plateau, covering about two-thirds of the continent, with deserts such as the Great Sandy and Great Victoria and the famous sandstone monolith Uluru (Ayers Rock), sacred to its Aboriginal owners; the Central Lowlands, including the Great Artesian Basin, one of the largest underground water reserves in the world; and the Great Dividing Range along the east coast, with Mount Kosciuszko (2,228 meters) as the highest point."]],
  ["Climate and water",[
    "The Tropic of Capricorn crosses the middle of Australia. The north has a tropical savanna climate with a wet summer monsoon and cyclones; the interior is arid; the southeast and southwest have temperate and Mediterranean climates; and Tasmania is cool and wet. Rainfall is highly variable, strongly affected by El Niño, which brings drought, and La Niña, which brings floods.",
    "The Murray–Darling Basin in the southeast is the country's most important agricultural region and longest river system, but overuse of its water for irrigation has caused environmental damage, leading to a national plan to share water. Australia regularly experiences severe droughts and bushfires; the 2019–2020 “Black Summer” fires burned over 18 million hectares."]],
  ["Unique life",[
    "Australia separated from Antarctica and the rest of Gondwana tens of millions of years ago, so its plants and animals evolved in isolation. Most of its mammals are marsupials, such as kangaroos, koalas, and wombats; it also has monotremes, egg-laying mammals, the platypus and echidnas. Eucalyptus trees and acacias (wattles) dominate its forests and woodlands.",
    "The Great Barrier Reef, stretching about 2,300 kilometers off Queensland, is the world's largest coral reef system and can be seen from space. Introduced species such as rabbits, foxes, cats, and cane toads have caused many extinctions, and the reef suffers repeated mass bleaching from marine heatwaves."]],
  ["People",[
    "Aboriginal and Torres Strait Islander peoples have lived in Australia for at least 50,000–65,000 years, with hundreds of distinct languages and deep spiritual connections to the land. British colonization from 1788 brought dispossession, violence, and disease. A 1967 referendum included Aboriginal people in the national census, the 1992 Mabo decision recognized native title, and in 2008 the government formally apologized to the Stolen Generations, children removed from their families.",
    "Australia is highly urbanized: about 86 percent of people live in cities, mostly along the southeast and southwest coasts. Sydney and Melbourne each have about 5 million people; others include Brisbane, Perth, and Adelaide. Canberra was purpose-built as the capital as a compromise between Sydney and Melbourne. Since the end of the White Australia policy in the 1970s, immigration, especially from Asia, has made Australia very multicultural; about 30 percent of residents were born overseas."]],
  ["Economy",[
    "Australia is a wealthy country whose exports are dominated by minerals and energy: it is the world's largest exporter of iron ore, mainly from the Pilbara region of Western Australia, and a leading exporter of coal, liquefied natural gas, gold, lithium, and bauxite. China is its largest trading partner.",
    "Agriculture, though limited by water, produces wheat, beef, and wool; Australia has more sheep than people. Services, including education for international students and tourism, are major industries."]],
  ["Australia in the world",[
    "Australia's location, close to Asia but culturally tied to Britain and the United States, shapes its identity and foreign policy. It is a member of the Commonwealth, and the British monarch is its head of state; a 1999 referendum to become a republic failed.",
    "Australia's role in the Indo-Pacific has grown, through alliances such as AUKUS with the United States and the United Kingdom, and ties with Pacific Island nations. Climate change, with worsening heat, drought, fire, and reef damage, poses major challenges for a country so dependent on fossil fuel exports."]]
  ],
  terms:[["Outback","Australia's remote, arid interior."],["Uluru","The sandstone monolith sacred to Aboriginal people."],["Great Artesian Basin","A vast underground water reserve."],["Great Dividing Range","The mountains along Australia's east coast."],["Murray–Darling Basin","Australia's main farming river system."],["Marsupial","A mammal that carries its young in a pouch."],["Stolen Generations","Aboriginal children removed from their families."]],
  w:"Australia's isolation, aridity, unique wildlife, and resource wealth shape a highly urban, multicultural nation with a deep Indigenous heritage.",
  src:["Australia","Geography of Australia","Uluru","Murray–Darling basin","Great Barrier Reef","Aboriginal Australians","Economy of Australia"],
  q:[["What is Australia's remote interior called?","The Outback","The Bush","The Top End","The Never Never"],
     ["What is Australia's highest mountain?","Mount Kosciuszko","Mount Townsend","Uluru","Mount Bogong"],
     ["What are egg-laying mammals called?","Monotremes","Marsupials","Placentals","Echidnids"],
     ["Which city is Australia's capital?","Canberra","Sydney","Melbourne","Brisbane"],
     ["Of which commodity is Australia the world's largest exporter?","Iron ore","Oil","Copper","Rice"],
     ["Which 1992 decision recognized native title?","Mabo","Wik","Waitangi","Yorta Yorta"]]},

{ t:"New Zealand and the Pacific Islands", s:"Oceania's islands and peoples",
  sec:[
  ["Oceania",[
    "Oceania includes Australia, New Zealand, and the thousands of islands of the Pacific Ocean, traditionally divided into three cultural regions. Melanesia (“black islands”), in the southwest, includes New Guinea, the Solomon Islands, Vanuatu, Fiji, and New Caledonia. Micronesia (“small islands”), north of the Equator, includes Guam, Palau, the Marshall Islands, and Kiribati. Polynesia (“many islands”) forms a vast triangle with corners at Hawaii, New Zealand, and Easter Island, including Samoa, Tonga, Tahiti, and the Cook Islands.",
    "Polynesian navigators were among the greatest seafarers in history, settling remote islands across thousands of kilometers of open ocean in double-hulled canoes, using stars, swells, winds, and birds to navigate, between about 1000 BCE and 1300 CE."]],
  ["High and low islands",[
    "Pacific islands are of two main types. High islands are volcanic or continental, mountainous, with fertile soils and more fresh water, such as Hawaii, Tahiti, Fiji, and Samoa. Low islands are coral atolls, rings of coral reef and sandy islets around a lagoon, typically only a few meters above sea level, with poor soils and limited fresh water, such as Tuvalu, the Marshall Islands, and most of Kiribati.",
    "Charles Darwin explained atoll formation: a coral reef grows around a volcanic island, and as the island slowly sinks and erodes, the reef keeps growing upward, leaving a ring of coral around a lagoon."]],
  ["New Zealand's land",[
    "New Zealand, about 2,000 kilometers southeast of Australia, consists of two main islands. The North Island is volcanic, with active volcanoes, geysers, and hot springs around Rotorua and Lake Taupō, a giant caldera. The South Island is dominated by the Southern Alps, formed along the Alpine Fault where the Pacific and Australian plates meet, with Aoraki/Mount Cook (3,724 meters) as the highest peak, glaciers, and the fjords of Fiordland.",
    "New Zealand has a mild, wet marine climate. Isolated for about 80 million years, it had no native land mammals except bats, and its birds, such as the flightless kiwi and the extinct giant moa, evolved to fill their roles. Earthquakes are a serious hazard; the 2011 Christchurch earthquake killed 185 people."]],
  ["New Zealand's people and economy",[
    "The Māori arrived from eastern Polynesia around 1250–1300 CE, making New Zealand one of the last major landmasses settled by humans. They call it Aotearoa. The Treaty of Waitangi (1840) between the British Crown and Māori chiefs remains the founding document of the nation. Today Māori make up about 17 percent of the population, and te reo Māori is an official language.",
    "New Zealand has about 5.3 million people, with Auckland, the largest city, and Wellington, the capital. Its economy relies on agriculture, especially dairy, of which it is one of the world's largest exporters, meat, wool, kiwifruit, and wine, along with tourism. It was the first self-governing country to grant women the vote, in 1893."]],
  ["Pacific Island nations",[
    "Papua New Guinea, sharing the island of New Guinea with Indonesia, is the largest and most populous Pacific Island nation, with about 10 million people and over 800 languages, the most of any country; its rugged mountains kept communities isolated. Fiji is a hub for the South Pacific, with a population of Indigenous Fijians and Indo-Fijians descended from indentured laborers.",
    "Many Pacific islands remain linked to outside powers: Hawaii is a U.S. state, Guam a U.S. territory, French Polynesia and New Caledonia French territories, and the Cook Islands and Niue in free association with New Zealand. Small island states have huge exclusive economic zones, making fisheries, especially tuna, vital to their economies, along with tourism, aid, and remittances."]],
  ["Small islands, big challenges",[
    "Pacific Island nations are among the most vulnerable to climate change. Rising seas, storm surges, saltwater intrusion into fresh water, and coral bleaching threaten low-lying atolls; Tuvalu, Kiribati, and the Marshall Islands could become largely uninhabitable. In 2023 Australia agreed to offer residency to Tuvaluans affected by climate change.",
    "The Pacific also bears the legacy of nuclear testing by the United States in the Marshall Islands, including at Bikini Atoll, and by Britain and France. Today the region is an arena of competition between China, the United States, and Australia for influence."]]
  ],
  terms:[["Melanesia, Micronesia, Polynesia","The three cultural regions of the Pacific Islands."],["High island","A mountainous volcanic or continental island."],["Atoll","A ring-shaped coral island around a lagoon."],["Southern Alps","The mountain chain of New Zealand's South Island."],["Aotearoa","The Māori name for New Zealand."],["Polynesian navigation","Traditional wayfinding that settled the Pacific."]],
  w:"The Pacific Islands and New Zealand show how people settled the world's most remote places and how small island nations now face some of the gravest threats from climate change.",
  src:["Oceania","Polynesia","Atoll","New Zealand","Geography of New Zealand","Māori people","Papua New Guinea"],
  q:[["Which Pacific region forms a triangle of Hawaii, New Zealand, and Easter Island?","Polynesia","Melanesia","Micronesia","Australasia"],
     ["What is a ring-shaped coral island around a lagoon called?","An atoll","A high island","A cay","A fjord"],
     ["Who explained how atolls form?","Charles Darwin","Alfred Russel Wallace","James Cook","Alexander von Humboldt"],
     ["What is New Zealand's highest peak?","Aoraki/Mount Cook","Mount Ruapehu","Mount Taranaki","Mount Aspiring"],
     ["What is the Māori name for New Zealand?","Aotearoa","Rapa Nui","Te Ika","Hawaiki"],
     ["Which Pacific nation has over 800 languages?","Papua New Guinea","Fiji","Vanuatu","Solomon Islands"]]},

{ t:"The Polar Regions", s:"The Arctic and Antarctica",
  sec:[
  ["Two very different poles",[
    "The Arctic and Antarctic are both cold, icy, and dominated by long polar days and nights, but they are geographic opposites. The Arctic is an ocean, the Arctic Ocean, mostly covered by floating sea ice and surrounded by the northern coasts of North America, Europe, Asia, and Greenland. Antarctica is a continent, a landmass larger than the United States and Mexico combined, buried under an ice sheet averaging about 2 kilometers thick and surrounded by the Southern Ocean.",
    "Antarctica is the coldest, windiest, highest on average, and driest continent; much of its interior receives less precipitation than the Sahara, making it the largest desert on Earth. The lowest natural temperature recorded on Earth's surface, −89.2°C, was measured at Vostok Station in 1983."]],
  ["The Arctic environment and peoples",[
    "The Arctic region is often defined as the area north of the Arctic Circle or where the average July temperature is below 10°C. Its lands are covered by tundra and permafrost. Wildlife includes polar bears, which depend on sea ice to hunt seals, walruses, Arctic foxes, caribou, and huge seabird colonies; in summer the region bursts into life.",
    "About 4 million people live in the Arctic, including Indigenous peoples such as the Inuit of Canada, Alaska, and Greenland, the Sámi of northern Europe, and the Nenets and other peoples of Siberia, who traditionally lived by hunting, fishing, and reindeer herding. Large Arctic cities include Murmansk and Norilsk in Russia."]],
  ["A warming Arctic",[
    "The Arctic is warming about three to four times faster than the global average, a phenomenon called Arctic amplification, driven partly by the ice-albedo feedback as reflective ice gives way to dark ocean. Summer sea ice extent has declined dramatically since satellite records began in 1979, and scientists expect largely ice-free summers within decades. The Greenland ice sheet is losing ice and contributing to sea level rise, and thawing permafrost releases carbon.",
    "Melting ice is opening new shipping routes, the Northern Sea Route along Russia and the Northwest Passage through Canada, and access to oil, gas, and minerals, increasing geopolitical interest. The Arctic Council, founded in 1996, brings together the eight Arctic states and Indigenous organizations."]],
  ["Antarctica's land and life",[
    "Antarctica contains about 90 percent of the world's ice and about 70 percent of its fresh water. The Transantarctic Mountains divide the larger East Antarctic Ice Sheet, resting mostly on land, from the West Antarctic Ice Sheet, much of which rests on bedrock below sea level and is considered vulnerable to collapse. Huge floating ice shelves, such as the Ross and Ronne, fringe the coast. Vinson Massif (4,892 meters) is the highest peak.",
    "Life is concentrated on the coasts and in the rich Southern Ocean, where krill support penguins, seals, whales, and seabirds. Emperor penguins breed on sea ice in the depths of the Antarctic winter."]],
  ["Exploration and governance",[
    "Antarctica was first sighted in 1820. In the “heroic age” of exploration, Norway's Roald Amundsen reached the South Pole on 14 December 1911, about five weeks before Britain's Robert Falcon Scott, whose party died on the return journey. Ernest Shackleton's Endurance expedition (1914–1917) became a legendary survival story. The North Pole was reached by disputed claims in 1908–1909; the first confirmed surface arrival came later.",
    "The Antarctic Treaty, signed in 1959 by 12 countries and since joined by over 50, reserves the continent for peaceful scientific research, bans military activity and nuclear testing, and freezes the territorial claims of seven nations. A 1991 protocol bans mining. Antarctica has no permanent population, but thousands of scientists live at research stations in summer, such as McMurdo and the Amundsen-Scott South Pole Station."]],
  ["Why the poles matter",[
    "Though remote, the polar regions play a vital role in the Earth system. They reflect sunlight, drive the deep ocean circulation as cold, salty water sinks, and store vast amounts of ice whose melting could raise sea level by many meters. Ice cores drilled from Antarctica and Greenland provide records of climate stretching back hundreds of thousands of years.",
    "Changes at the poles, from melting ice to shifting ecosystems, are among the clearest signals of global climate change and affect coastal communities everywhere."]]
  ],
  terms:[["Arctic Ocean","The ocean surrounding the North Pole."],["Sea ice","Frozen ocean water floating on the sea."],["Arctic amplification","Faster warming in the Arctic than elsewhere."],["Ice shelf","A floating extension of an ice sheet."],["Krill","Small crustaceans at the base of the Southern Ocean food web."],["Antarctic Treaty","The 1959 treaty reserving Antarctica for peace and science."],["Arctic Council","The forum of Arctic states and Indigenous peoples."]],
  w:"The polar regions regulate Earth's climate and sea level, and their rapid changes are among the clearest signs of a warming world.",
  src:["Arctic","Antarctica","Arctic sea ice decline","West Antarctic Ice Sheet","Antarctic Treaty System","Roald Amundsen","Arctic Council"],
  q:[["Which polar region is an ocean surrounded by land?","The Arctic","Antarctica","Both","Neither"],
     ["Where was the lowest natural temperature on Earth recorded?","Vostok Station","The South Pole","Oymyakon","Greenland"],
     ["What share of the world's ice is in Antarctica?","About 90 percent","About 50 percent","About 70 percent","About 30 percent"],
     ["Who first reached the South Pole?","Roald Amundsen","Robert Falcon Scott","Ernest Shackleton","Richard Byrd"],
     ["What is Antarctica's highest peak?","Vinson Massif","Mount Erebus","Mount Kirkpatrick","Mount Terror"],
     ["How much faster is the Arctic warming than the global average?","About three to four times","About the same","About half as fast","About ten times"]]},

{ t:"Our Changing Planet", s:"Sustainability and thinking geographically",
  sec:[
  ["The Anthropocene",[
    "Humans have become a major force shaping the planet. People have transformed about three-quarters of the ice-free land, moved more sediment than all rivers combined, altered the chemistry of the atmosphere and oceans, and driven many species to extinction. Some scientists have proposed calling the present the Anthropocene, the age of humans, though in 2024 geologists voted not to add it formally to the geologic time scale.",
    "The concept of planetary boundaries, introduced by Johan Rockström and colleagues in 2009, identifies nine Earth-system processes, including climate change, biodiversity loss, nitrogen and phosphorus flows, land use, and fresh water, with limits beyond which humanity risks destabilizing the planet; research suggests several have already been crossed."]],
  ["Sustainable development",[
    "Sustainable development was defined by the 1987 Brundtland Report, Our Common Future, as development that meets the needs of the present without compromising the ability of future generations to meet their own needs. It balances three pillars: economic growth, social well-being, and environmental protection.",
    "The UN's 17 Sustainable Development Goals, adopted in 2015, apply this idea to targets for 2030, from ending poverty and hunger to clean water, affordable clean energy, sustainable cities, climate action, and life below water and on land."]],
  ["Geography of solutions",[
    "Solutions to environmental problems are themselves geographic. Renewable energy depends on where sun, wind, and water are abundant. Protecting biodiversity requires locating hotspots and connecting habitats. Climate adaptation requires mapping who and what are exposed to floods, heat, and drought. Urban planning shapes energy use and transport for generations.",
    "There have been real successes: the recovery of the ozone layer after the Montreal Protocol, the cleanup of once-polluted rivers such as the Thames and the Rhine, the return of forests in parts of Europe and China, the rapid spread of solar power, and dramatic declines in deaths from disasters."]],
  ["Thinking geographically",[
    "Geography's distinctive contribution is a way of thinking: asking where things are and why, how places are connected, and how the same process plays out differently in different places and at different scales. It joins physical and human systems, showing how a drought, a dam, a trade agreement, or a migration links environment and society.",
    "A geographer looking at any news story asks: Where is this happening? What is that place like, physically and culturally? How is it connected to other places? What are the scales involved, local, national, global? Who gains and who loses?"]],
  ["Where to go from here",[
    "These foundations have covered the tools of geography, the physical systems of the Earth, the patterns of human life, and the regions of the world. Each can be explored in much greater depth: geomorphology, climatology, biogeography, oceanography, urban geography, economic geography, political geography, cartography and GIS, and the detailed study of any country or region.",
    "The world is always changing, populations shift, borders move, cities grow, climates warm, so there is always more to learn. The best geographers combine knowledge of places with curiosity, maps with fieldwork, and a sense of wonder at the diversity of our planet."]]
  ],
  terms:[["Anthropocene","A proposed name for the age of human impact on Earth."],["Planetary boundaries","Limits of Earth systems beyond which humanity risks instability."],["Sustainable development","Meeting present needs without compromising future generations."],["Brundtland Report","The 1987 UN report that defined sustainable development."],["Geographic thinking","Analyzing location, place, connection, and scale."]],
  w:"Understanding the planet as an interconnected system of people and environments is the key to meeting the challenges of the 21st century.",
  src:["Anthropocene","Planetary boundaries","Sustainable development","Our Common Future","Sustainable Development Goals","Geography"],
  q:[["What does Anthropocene mean?","The age of humans","The age of mammals","The recent ice age","The age of industry"],
     ["Who introduced the concept of planetary boundaries in 2009?","Johan Rockström and colleagues","Gro Harlem Brundtland","Rachel Carson","Paul Crutzen alone"],
     ["Which 1987 report defined sustainable development?","The Brundtland Report","The Stern Review","The Club of Rome report","The IPCC First Assessment"],
     ["What are the three pillars of sustainable development?","Economic, social, and environmental","Political, military, and economic","Land, water, and air","Local, national, and global"],
     ["Which environmental agreement led to recovery of the ozone layer?","The Montreal Protocol","The Kyoto Protocol","The Paris Agreement","The Ramsar Convention"],
     ["What did geologists decide about the Anthropocene in 2024?","Not to add it formally to the time scale","To add it as a new epoch","To make it an eon","To rename the Holocene"]]}

);
