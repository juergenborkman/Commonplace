/* ---- from sports-01.js ---- */
/* SPORTS FOUNDATIONS, part 1: Unit 1 Understanding Sport, chapters 1-5 */
COURSES.sports = { units: [] };
COURSES.sports.units.push({ t:"Understanding Sport", ch:[

{ t:"What Is Sport?", s:"Play, rules, and competition",
  sec:[
  ["Defining sport",[
    "Sport is usually defined as physical activity governed by rules, involving skill and competition, and organized by some kind of institution. Play, by contrast, is free and spontaneous; games add rules; sports add physical skill, organized competition, and recognized records and champions. The philosopher Bernard Suits famously described playing a game as 'the voluntary attempt to overcome unnecessary obstacles': nothing stops a golfer from carrying the ball to the hole, except the rules that make golf golf.",
    "Borderline cases spark debate. Chess is recognized by the International Olympic Committee (IOC) as a sport, but involves little physical exertion; esports challenge the definition further. Activities such as hunting, dancing, or hiking become sport when organized competitively."]],
  ["Why humans play",[
    "Sport is found in almost every culture. Anthropologists link it to practice for hunting and warfare, display of strength and status, ritual and religion, social bonding, and simple enjoyment of movement. Historian Johan Huizinga's book Homo Ludens (1938) argued that play is a fundamental element of human culture, older than culture itself.",
    "Modern research highlights sport's benefits for physical and mental health, teamwork, and community identity, as well as its darker sides: injury, violence, exclusion, and corruption."]],
  ["Types of sport",[
    "Sports can be classified in many ways. Team sports (football, basketball) versus individual sports (tennis, golf); invasion games, where teams attack each other's territory to score (football, rugby, hockey, basketball); net and wall games (tennis, volleyball, squash); striking and fielding games (cricket, baseball); target games (golf, archery, darts); and racing (athletics, swimming, cycling, motorsport).",
    "Other categories include combat sports (boxing, judo, wrestling), aesthetic or judged sports (gymnastics, figure skating, diving), and adventure or 'lifestyle' sports (surfing, skateboarding, climbing)."]],
  ["Amateur and professional",[
    "Amateur athletes compete without being paid; professionals earn a living from sport. In the 19th century, 'amateurism' was often a class barrier designed to keep working people out of elite competition. The Olympics gradually abandoned strict amateur rules from the 1970s to 1990s.",
    "Today, most sport is still played by amateurs, from school teams to weekend leagues, while professional sport is a global entertainment industry worth hundreds of billions of dollars."]],
  ["Sport's global reach",[
    "Association football (soccer) is the world's most popular sport, with the FIFA World Cup final regularly watched by over a billion people. Cricket has an enormous following in South Asia; basketball is popular worldwide; and the Summer Olympics bring together athletes from more than 200 nations.",
    "Sport is a shared language across borders: fans who share no words can debate a match together."]]
  ],
  terms:[["Sport","Rule-governed, competitive physical activity organized by institutions."],["Invasion game","Team sport where sides attack each other's territory."],["Amateur","Athlete who competes without pay."],["Homo Ludens","Huizinga's study of play in culture."],["IOC","International Olympic Committee."]],
  w:"Understanding what sport is and how sports are grouped gives a framework for every game you watch or play.",
  src:["Sport","Homo Ludens","Bernard Suits","Amateur sports","Invasion games"],
  q:[
  ["Which philosopher described games as 'the voluntary attempt to overcome unnecessary obstacles'?","Bernard Suits","Johan Huizinga","Aristotle","Pierre de Coubertin"],
  ["Which is an invasion game?","Basketball","Tennis","Golf","Cricket"],
  ["Which book argued play is a fundamental element of culture?","Homo Ludens","The Republic","Leviathan","The Wealth of Nations"],
  ["Which is a striking and fielding game?","Baseball","Volleyball","Rugby","Archery"],
  ["What is the world's most popular sport?","Association football (soccer)","Basketball","Cricket","Tennis"],
  ["Which is an aesthetic or judged sport?","Gymnastics","Marathon","Football","Darts"]]},

{ t:"Sport in the Ancient World", s:"Games of gods and kings",
  sec:[
  ["Early evidence",[
    "Some of the earliest evidence of sport comes from cave paintings and ancient art. Egyptian tomb paintings at Beni Hasan (about 2000 BCE) show hundreds of wrestling holds; Egyptians also enjoyed swimming, archery, rowing, and ball games. In Mesopotamia, the Epic of Gilgamesh describes wrestling, and Sumerian art shows boxing.",
    "In Minoan Crete (about 1600 BCE), frescoes at Knossos depict bull-leaping, in which athletes grasped a charging bull's horns and vaulted over its back."]],
  ["Greece and athletic culture",[
    "Ancient Greece placed athletics at the center of civic and religious life. Young men trained naked in the gymnasium (from gymnos, 'naked'), and athletic excellence was linked to arete, virtue or excellence. Homer's Iliad describes funeral games held by Achilles, with chariot racing, boxing, wrestling, and running.",
    "Besides the Olympic Games, the Panhellenic 'circuit' included the Pythian Games at Delphi, the Isthmian Games near Corinth, and the Nemean Games. Winners received wreaths, but their home cities showered them with money, statues, and free meals for life."]],
  ["Rome: spectacle",[
    "Romans favored sport as spectacle rather than participation. Chariot racing in the Circus Maximus, which may have held around 150,000 spectators, was enormously popular; fans followed four factions, Reds, Whites, Greens, and Blues, with passionate loyalty. The charioteer Gaius Appuleius Diocles is said to have won over 1,400 races and earned a fortune.",
    "Gladiatorial games in amphitheaters such as the Colosseum (opened 80 CE) pitted trained fighters, often enslaved people or prisoners, against one another or animals. Emperors used 'bread and circuses,' in the poet Juvenal's phrase, to win popular support."]],
  ["The Americas and Asia",[
    "In Mesoamerica, the ballgame (ōllamaliztli in Nahuatl) was played for over 3,000 years with a heavy solid rubber ball, struck mainly with the hips, in stone courts; some versions had stone rings high on the walls. It had religious significance and, in some contexts, was linked to human sacrifice. Hundreds of ballcourts have been found from Mexico to Central America; a modern version, ulama, survives.",
    "In China, cuju, a kicking game played with a leather ball, dates back over 2,000 years and is recognized by FIFA as an early form of football; it was popular in the Han and Song dynasties. Polo originated in ancient Persia and spread across Asia. India's ancient texts mention wrestling, archery, and early forms of games such as kabaddi."]],
  ["Meaning of ancient sport",[
    "Ancient sport was rarely just recreation: it was tied to religion, military training, social status, and political power. Records in the modern sense, measured times and distances, were largely unknown; winning was what mattered.",
    "Many modern sports, wrestling, boxing, running, javelin, and discus, have clear ancient ancestors."]]
  ],
  terms:[["Arete","Greek ideal of excellence or virtue."],["Gymnasium","Greek training ground, from gymnos, 'naked.'"],["Circus Maximus","Rome's great chariot-racing stadium."],["Cuju","Ancient Chinese kicking ball game."],["Mesoamerican ballgame","Ancient rubber-ball game of Mexico and Central America."]],
  w:"Sport is as old as civilization, and its ancient forms shaped modern ideas of competition and spectacle.",
  src:["Sport in ancient Greek art","Chariot racing","Mesoamerican ballgame","Cuju","Bull-leaping"],
  q:[
  ["Which ancient Chinese game is recognized by FIFA as an early form of football?","Cuju","Polo","Kemari","Chinlone"],
  ["Where did Roman chariot races take place?","Circus Maximus","Colosseum","Forum","Pantheon"],
  ["With what did players mainly strike the ball in the Mesoamerican ballgame?","Their hips","Their hands","A bat","Their feet only"],
  ["Which Minoan sport is shown in frescoes at Knossos?","Bull-leaping","Chariot racing","Archery","Swimming"],
  ["Which games were held at Delphi?","Pythian Games","Isthmian Games","Nemean Games","Olympic Games"],
  ["Polo originated in which ancient land?","Persia","Greece","Egypt","China"]]},

{ t:"The Ancient Olympic Games", s:"776 BCE to the end of antiquity",
  sec:[
  ["Origins",[
    "The ancient Olympic Games were held at Olympia, a sanctuary of Zeus in the western Peloponnese. Traditional dating places the first recorded Games in 776 BCE, when Koroibos, a cook from Elis, won the stadion footrace. The Games were held every four years, a period called an Olympiad, which Greeks used to count time.",
    "During the Games, a sacred truce (ekecheiria) was proclaimed so that athletes and spectators could travel safely to Olympia."]],
  ["The events",[
    "For decades the only event was the stadion, a sprint of one stade (about 192 meters at Olympia). Later events included the diaulos (two lengths), the dolichos (long-distance race), the pentathlon (stadion, long jump, discus, javelin, and wrestling), wrestling, boxing, the pankration (a brutal mix of boxing and wrestling with few rules), and equestrian events such as four-horse chariot racing.",
    "There was even a race in armor, the hoplitodromos. Long jumpers used hand-held weights called halteres to extend their jumps."]],
  ["Who competed",[
    "Competitors had to be free Greek men; athletes competed naked. Married women were reportedly barred from watching the main events. However, in equestrian events the prize went to the horse's owner, so a woman could win: Cynisca, a Spartan princess, won the four-horse chariot race in 396 and 392 BCE, becoming the first woman Olympic champion.",
    "Women had their own festival at Olympia, the Heraean Games in honor of Hera, with footraces for unmarried girls."]],
  ["Prizes and fame",[
    "Olympic victors received a wreath of olive leaves (kotinos), cut from a sacred tree. But fame brought great rewards at home. The wrestler Milo of Croton, six-time Olympic champion in the 6th century BCE, became legendary for his strength; the story that he trained by carrying a calf daily as it grew into a bull is often cited as an early example of progressive overload.",
    "Corruption existed too: athletes caught bribing opponents were fined, and the money paid for bronze statues of Zeus (called Zanes) lining the entrance to the stadium, inscribed with the cheaters' names."]],
  ["Decline",[
    "The Games continued under Roman rule; Emperor Nero entered in 67 CE and was declared winner of the chariot race despite falling out of his chariot. The Games declined in late antiquity, and are traditionally said to have ended after decrees by the Christian emperor Theodosius I banning pagan festivals in the 390s CE, though some activity may have continued into the 5th century.",
    "Excavations of Olympia from the 1870s inspired the modern revival."]]
  ],
  terms:[["Olympiad","Four-year period between Games."],["Stadion","Original Olympic sprint of one stade."],["Pankration","Brutal ancient combat sport mixing boxing and wrestling."],["Ekecheiria","Sacred Olympic truce."],["Kotinos","Olive wreath given to Olympic victors."]],
  w:"The ancient Olympics created the ideal of athletic competition that the modern Games revived.",
  src:["Ancient Olympic Games","Cynisca","Milo of Croton","Pankration","Olympia, Greece"],
  q:[
  ["What is the traditional date of the first recorded ancient Olympics?","776 BCE","490 BCE","1000 BCE","393 CE"],
  ["What was the original and only event for decades?","The stadion footrace","Wrestling","Chariot racing","Discus"],
  ["Who was the first woman Olympic champion, as a chariot owner?","Cynisca","Sappho","Atalanta","Hera"],
  ["What prize did ancient Olympic victors receive at Olympia?","An olive wreath","A gold medal","A bronze statue","A silver cup"],
  ["What was the pankration?","A combat sport mixing boxing and wrestling","A long-distance race","A chariot race","A javelin contest"],
  ["Which emperor is traditionally linked to the end of the ancient Games?","Theodosius I","Nero","Augustus","Constantine"]]},

{ t:"Sport from the Middle Ages to 1800", s:"Tournaments, folk games, and the first rules",
  sec:[
  ["Knights and tournaments",[
    "In medieval Europe, the nobility trained for war through hunting, archery, and tournaments. Early tournaments were mock battles (mêlées) between groups of knights; later, the joust, in which two mounted knights charged with lances, became the centerpiece. Tournaments became elaborate spectacles of chivalry, heraldry, and courtly display.",
    "King Henry II of France died in 1559 after a splinter from a lance pierced his eye in a joust, one of many tournament fatalities."]],
  ["Folk football",[
    "Common people played rough, often chaotic folk games. 'Mob football' in England pitted whole villages against each other, with few rules and unlimited players, often on holidays such as Shrove Tuesday; some versions survive, such as the Royal Shrovetide Football match in Ashbourne, Derbyshire. Kings repeatedly banned football, partly because it distracted men from archery practice.",
    "Similar games existed elsewhere: calcio storico in Florence (still played annually), soule in France, and hurling in Ireland."]],
  ["Ball games of the elite",[
    "Real tennis (jeu de paume, 'game of the palm') developed in French monasteries and courts from the 12th century, first played with the hand, later with rackets; it is the ancestor of lawn tennis. Henry VIII was an enthusiastic player, and a court survives at Hampton Court Palace.",
    "Golf developed in Scotland by the 15th century; in 1457 the Scottish Parliament banned it along with football to protect archery. The oldest surviving rules of golf were written in 1744 by the Gentlemen Golfers of Leith, and the Society of St Andrews Golfers (later the Royal and Ancient Golf Club) was founded in 1754."]],
  ["Asia and the Islamic world",[
    "In Japan, sumo wrestling developed from Shinto rituals and became organized professionally in the Edo period (1603–1868). Martial arts such as kyūdō (archery) and kenjutsu (swordsmanship) were part of samurai training. In Persia and India, polo was a royal sport; the Mughal emperors played it.",
    "Kemari, a Japanese aristocratic kicking game, was played at court. In the Ottoman Empire, oil wrestling (yağlı güreş) has been held at Kırkpınar since at least the 14th century, making it one of the oldest continuously run sporting competitions."]],
  ["The 18th century: rules and betting",[
    "In 18th-century Britain, gambling drove the codification of sports, because bets required agreed rules. Cricket's first known written laws date from 1744. Horse racing became organized, with the Jockey Club founded around 1750 and classic races such as the St Leger (1776) and the Derby (1780).",
    "Prizefighting (bare-knuckle boxing) gained its first rules from champion Jack Broughton in 1743, introducing the idea of not hitting a downed opponent. These developments laid the groundwork for the explosion of modern organized sport in the 19th century."]]
  ],
  terms:[["Joust","Mounted combat of two knights with lances."],["Mob football","Medieval village ball game with few rules."],["Real tennis","Indoor ancestor of lawn tennis."],["Sumo","Japanese wrestling rooted in Shinto ritual."],["Codification","Writing down formal rules."]],
  w:"Medieval and early modern games bridged ancient sport and the rule-based sports of the modern era.",
  src:["Tournament (medieval)","Medieval football","Real tennis","History of golf","Jack Broughton"],
  q:[
  ["Which game is the ancestor of lawn tennis?","Real tennis (jeu de paume)","Badminton","Squash","Pelota"],
  ["Why did English kings repeatedly ban football?","It distracted men from archery practice","It was too expensive","It was a foreign sport","It damaged churches"],
  ["Who wrote early boxing rules in 1743?","Jack Broughton","Marquess of Queensberry","Daniel Mendoza","John L. Sullivan"],
  ["Which Turkish competition is one of the oldest continuously held?","Kırkpınar oil wrestling","Istanbul marathon","Ottoman archery","Buzkashi"],
  ["What drove the codification of sports in 18th-century Britain?","Gambling","Religion","Military orders","Schools"],
  ["Which Florence game is still played annually?","Calcio storico","Soule","Kemari","Pallone"]]},

{ t:"The Birth of Modern Sport", s:"Victorian Britain and the world",
  sec:[
  ["Why Britain?",[
    "Many of the world's major sports, football, rugby, cricket, tennis, golf, boxing, and horse racing in modern form, were codified in 19th-century Britain. Reasons include industrialization and urbanization (creating crowds and leisure time), railways (allowing teams to travel), the press, the public schools, and the British Empire, which spread sports around the world.",
    "The 1850 Factory Act and the spread of the Saturday half-holiday gave workers free afternoons, the origin of Saturday sport."]],
  ["Public schools and 'muscular Christianity'",[
    "Elite boarding schools such as Eton, Harrow, and Rugby made games central to education, believing they built character, discipline, and leadership. Thomas Arnold, headmaster of Rugby School, was associated with this ethos, popularized by the novel Tom Brown's School Days (1857).",
    "'Muscular Christianity' linked physical strength, morality, and religion. Each school had its own football rules, which caused confusion when former pupils met at university."]],
  ["Governing bodies and rules",[
    "The Football Association (FA) was founded in London in 1863, creating unified rules that banned carrying the ball; schools favoring handling split off, and the Rugby Football Union followed in 1871. The Marylebone Cricket Club (MCC, 1787) became the guardian of cricket's laws; the All England Club staged the first Wimbledon tennis championships in 1877.",
    "In 1867 the Queensberry Rules for boxing introduced gloves, three-minute rounds, and the ten-second count. Governing bodies standardized rules, fields, and equipment, making national and international competition possible."]],
  ["Professionalism and class",[
    "Working-class players in northern England wanted to be paid for time lost from work. Football legalized professionalism in 1885, and the Football League, the world's first professional football league, began in 1888. Rugby split in 1895 when northern clubs formed the Northern Union (later rugby league) over payments to players, while rugby union remained officially amateur until 1995.",
    "Class tensions over amateurism shaped many sports for a century."]],
  ["America and the world",[
    "The United States developed its own sports: baseball (professional National League founded 1876), American football (evolving from rugby in the 1870s–80s), and basketball (invented by James Naismith in 1891 in Springfield, Massachusetts). Volleyball followed in 1895.",
    "British traders, soldiers, engineers, and teachers spread football to South America, Europe, and Africa, and cricket throughout the Empire. By 1900, organized modern sport was becoming a global phenomenon, setting the stage for the modern Olympics."]]
  ],
  terms:[["Muscular Christianity","Belief linking sport, morality, and religion."],["Football Association","English governing body founded 1863."],["Queensberry Rules","1867 boxing rules introducing gloves and rounds."],["Professionalism","Paying athletes to compete."],["Northern Union","1895 breakaway that became rugby league."]],
  w:"The modern sporting world, its rules, leagues, and governing bodies, was largely created in the 19th century.",
  src:["Football Association","Muscular Christianity","Marquess of Queensberry Rules","Football League (1888)","James Naismith"],
  q:[
  ["When was the Football Association founded?","1863","1888","1871","1904"],
  ["Who invented basketball in 1891?","James Naismith","Abner Doubleday","Walter Camp","William Morgan"],
  ["Which rules introduced gloves and three-minute rounds in boxing?","Queensberry Rules","Broughton's Rules","London Prize Ring Rules","Olympic Rules"],
  ["When did the world's first professional football league begin?","1888","1863","1901","1920"],
  ["Why did rugby split in 1895?","Over payments to players","Over the shape of the ball","Over religion","Over the number of players"],
  ["Which novel popularized the public-school games ethos?","Tom Brown's School Days","Oliver Twist","Chariots of Fire","Goodbye, Mr. Chips"]]}

]});


/* ---- from sports-02.js ---- */
/* SPORTS FOUNDATIONS, part 2: Unit 1 chapters 6-9 */
COURSES.sports.units[0].ch.push(

{ t:"The Modern Olympic Games", s:"Coubertin's dream",
  sec:[
  ["The revival",[
    "French aristocrat and educator Pierre de Coubertin, inspired by British school sport and the excavations at Olympia, founded the International Olympic Committee (IOC) at a congress in Paris in 1894. The first modern Olympics were held in Athens in 1896, with about 241 athletes, all men, from 14 nations. American James Connolly, winning the triple jump, became the first modern Olympic champion; Greek water carrier Spyridon Louis won the first marathon, to national joy.",
    "Earlier revivals, such as the Wenlock Olympian Games in Shropshire, England (from 1850), and Greece's Zappas Olympics, had inspired Coubertin."]],
  ["Growing pains",[
    "The 1900 Paris and 1904 St. Louis Games were stretched over months as sideshows to world's fairs. Women first competed in 1900 in Paris (tennis player Charlotte Cooper became the first woman Olympic champion in an individual event). The 1908 London Games fixed the marathon distance at 26.2 miles (42.195 km), reportedly so the race could start at Windsor Castle and finish before the royal box.",
    "Symbols were added over time: the five interlocking rings, designed by Coubertin in 1913 to represent the five inhabited continents joined together, first flew at Antwerp in 1920, along with the athletes' oath; the Olympic flame was introduced in Amsterdam in 1928, and the torch relay from Olympia began with the 1936 Berlin Games."]],
  ["The Olympics and politics",[
    "The 1936 Berlin Olympics were staged by the Nazi regime as propaganda, but African American sprinter Jesse Owens won four gold medals. The Games were canceled in 1916, 1940, and 1944 due to world wars. At Mexico City 1968, US sprinters Tommie Smith and John Carlos raised gloved fists on the podium in protest against racial injustice.",
    "At Munich 1972, Palestinian militants of the Black September group took Israeli team members hostage; eleven Israelis were killed. Boycotts marked the Cold War: many African nations boycotted Montreal 1976 over New Zealand's rugby links with apartheid South Africa; the US led a boycott of Moscow 1980 over the Soviet invasion of Afghanistan, and the Soviet bloc boycotted Los Angeles 1984."]],
  ["The modern Games",[
    "From the 1980s, under IOC president Juan Antonio Samaranch, the Olympics opened to professionals and became commercialized through television rights and sponsorship; Los Angeles 1984 made a profit and set a new model. Barcelona 1992 featured the US basketball 'Dream Team.' The Winter Olympics began in Chamonix in 1924, and since 1994 Summer and Winter Games alternate every two years.",
    "Scandals have included bribery in the Salt Lake City bid (revealed 1998) and state-sponsored Russian doping at Sochi 2014. The IOC has introduced new sports to attract younger audiences, such as skateboarding, surfing, and sport climbing (Tokyo 2020, held in 2021 because of COVID-19) and breaking (Paris 2024)."]],
  ["Olympic ideals",[
    "The Olympic motto is 'Citius, Altius, Fortius' ('Faster, Higher, Stronger'), to which the IOC added 'Communiter' ('Together') in 2021. The Olympic Charter emphasizes friendship, respect, and excellence, and the creed often attributed to Coubertin holds that the most important thing is not winning but taking part.",
    "Critics point to enormous costs for host cities, displacement of residents, environmental impact, and corruption, while supporters emphasize the Games' unique power to bring the world together. Los Angeles will host the 2028 Summer Games, and Brisbane 2032."]]
  ],
  terms:[["IOC","International Olympic Committee, founded 1894."],["Olympic rings","Five rings representing the continents."],["Boycott","Refusal to participate as protest."],["Olympic Charter","IOC's founding rules and principles."],["Dream Team","US basketball team of NBA stars at Barcelona 1992."]],
  w:"The Olympics are the world's largest sporting event and a mirror of global politics, ideals, and controversies.",
  src:["Olympic Games","Pierre de Coubertin","1896 Summer Olympics","1936 Summer Olympics","Munich massacre"],
  q:[
  ["Who founded the IOC in 1894?","Pierre de Coubertin","Avery Brundage","Juan Antonio Samaranch","William Penny Brookes"],
  ["Where were the first modern Olympics held in 1896?","Athens","Paris","London","Olympia"],
  ["Who won four gold medals at the 1936 Berlin Olympics?","Jesse Owens","Carl Lewis","Paavo Nurmi","Jim Thorpe"],
  ["Which Games saw the US-led boycott?","Moscow 1980","Los Angeles 1984","Montreal 1976","Seoul 1988"],
  ["When was the marathon distance fixed at 42.195 km?","London 1908","Athens 1896","Paris 1924","Berlin 1936"],
  ["Which word was added to the Olympic motto in 2021?","Communiter (Together)","Pacem (Peace)","Gloria (Glory)","Fair Play"]]},

{ t:"How Sport Is Governed", s:"Federations, courts, and money",
  sec:[
  ["The pyramid",[
    "Most sports are organized as a pyramid. At the top is an international federation (IF) that sets global rules and runs world championships: FIFA (football, founded 1904), World Athletics, FIBA (basketball), World Aquatics, the International Cricket Council, World Rugby, and many others. Below are continental confederations (such as UEFA in European football), then national governing bodies, regional associations, and clubs.",
    "The IOC oversees the Olympic movement, recognizing federations and National Olympic Committees (NOCs) that select national teams."]],
  ["The European and American models",[
    "In the European model, leagues are open: teams are promoted and relegated between divisions based on performance, so a small club can theoretically rise to the top. Clubs are linked to national federations and international competitions.",
    "In the North American model, major leagues such as the NFL, NBA, MLB, and NHL are closed: a fixed set of franchises owned by private owners, with no relegation. Leagues use tools such as salary caps, revenue sharing, and drafts (where the weakest teams pick the best young players first) to promote competitive balance."]],
  ["Disputes and justice",[
    "The Court of Arbitration for Sport (CAS), founded in 1984 and based in Lausanne, Switzerland, resolves disputes over doping, eligibility, selection, and governance; it holds ad hoc sessions at the Olympics. Its decisions can be appealed only on limited grounds to the Swiss Federal Supreme Court.",
    "Major cases have reshaped sport: the Bosman ruling of the European Court of Justice (1995) allowed out-of-contract footballers in the EU to move freely and ended quotas on EU players, transforming the transfer market."]],
  ["Anti-doping",[
    "The World Anti-Doping Agency (WADA) was created in 1999 after doping scandals, notably the 1998 Festina affair in the Tour de France. It publishes the World Anti-Doping Code and a Prohibited List, updated annually, and accredits testing laboratories.",
    "Athletes in testing pools must report their whereabouts for out-of-competition testing; the 'athlete biological passport' tracks blood and hormone markers over time to detect doping indirectly."]],
  ["Governance problems",[
    "Sports bodies have faced serious scandals. In 2015, US and Swiss authorities indicted and arrested numerous FIFA officials and associates on charges including racketeering and bribery; FIFA president Sepp Blatter was later banned by FIFA's ethics committee. The awarding of World Cups to Russia (2018) and Qatar (2022) drew allegations and controversy.",
    "Calls for better governance emphasize transparency, independent oversight, athlete representation, and safeguarding against abuse, especially of young athletes."]]
  ],
  terms:[["International federation","Body setting a sport's global rules."],["Promotion and relegation","Moving teams between divisions by results."],["Draft","System where weak teams pick top new players first."],["CAS","Court of Arbitration for Sport."],["WADA","World Anti-Doping Agency, founded 1999."]],
  w:"Knowing who runs sport, and how, explains transfers, bans, scandals, and how leagues stay competitive.",
  src:["Sports governing body","Court of Arbitration for Sport","World Anti-Doping Agency","Bosman ruling","Promotion and relegation"],
  q:[
  ["Where is the Court of Arbitration for Sport based?","Lausanne, Switzerland","Zurich","Paris","Geneva"],
  ["What does promotion and relegation mean?","Teams move between divisions based on results","Teams are added by vote","Players are traded","Coaches are fired"],
  ["What was the Bosman ruling about?","Free movement of out-of-contract footballers in the EU","Doping penalties","TV rights","Stadium safety"],
  ["When was WADA created?","1999","1984","1968","2008"],
  ["Which is a feature of North American major leagues?","Closed franchises with drafts","Promotion and relegation","No salary rules","Open entry for any club"],
  ["When was FIFA founded?","1904","1863","1930","1894"]]},

{ t:"Rules, Officials, and Fair Play", s:"Keeping the game honest",
  sec:[
  ["Constitutive and regulative rules",[
    "Philosophers distinguish constitutive rules, which create the game itself (in basketball, the ball must go through the hoop to score), from regulative rules, which govern conduct (fouls, time limits). Without constitutive rules there is no game; breaking regulative rules brings penalties.",
    "Rules change over time to improve safety, fairness, or entertainment: the shot clock in basketball (1954) sped up the game; football's back-pass rule (1992) stopped goalkeepers from picking up deliberate passes from teammates, reducing time-wasting."]],
  ["The officials",[
    "Officials enforce rules: referees, umpires, judges, linesmen, and timekeepers. Their tasks include judging facts (was the ball out?), interpreting rules (was the tackle reckless?), managing players' emotions, and controlling the game's flow, often deciding in a fraction of a second.",
    "Different sports give officials different powers: a football referee can apply 'advantage,' letting play continue after a foul if stopping would hurt the fouled team; cricket umpires respond to appeals ('How's that?'); judges in gymnastics and figure skating score performances."]],
  ["Technology",[
    "Technology increasingly assists officials. Tennis adopted Hawk-Eye ball tracking for line calls from 2006, and many tournaments now use fully electronic line calling; Wimbledon replaced line judges with it in 2025. Cricket's Decision Review System (DRS) uses ball-tracking and edge detection.",
    "Football introduced goal-line technology (2012 rule approval) and the Video Assistant Referee (VAR), used at the World Cup from 2018, to review goals, penalties, red cards, and mistaken identity. Critics complain of delays and ruined celebrations; supporters cite more correct decisions. Photo finishes and electronic timing to thousandths of a second decide races."]],
  ["Fair play and gamesmanship",[
    "Fair play means respecting rules, opponents, and officials, and competing honestly. Famous examples include athletes helping injured rivals and the International Fair Play Committee's awards.",
    "Gamesmanship pushes rules to the limit without breaking them, such as time-wasting or psychological games. Cheating breaks rules deliberately: diving to win fouls, ball tampering in cricket (as in the 2018 Australian 'Sandpapergate' scandal), or Diego Maradona's 'Hand of God' goal against England in 1986. Debates over the 'spirit of the game' are especially strong in cricket."]],
  ["Respecting officials",[
    "Abuse of referees at all levels is a serious problem, driving many to quit. Campaigns such as England's 'Respect' program (2008) aim to protect officials, especially in youth sport.",
    "Being an official requires training, fitness, rule knowledge, and calm judgment; many top officials are themselves professional athletes in terms of preparation."]]
  ],
  terms:[["Constitutive rule","Rule that creates the game itself."],["Advantage","Allowing play to continue after a foul."],["Hawk-Eye","Ball-tracking system for line calls."],["VAR","Video Assistant Referee in football."],["Gamesmanship","Bending rules without breaking them."]],
  w:"Rules and officials make sport fair and meaningful; understanding them deepens appreciation of every decision.",
  src:["Referee","Hawk-Eye","Video assistant referee","Fair play","Hand of God goal"],
  q:[
  ["What does the 'advantage' rule in football allow?","Play to continue after a foul if stopping would hurt the fouled team","Extra time","A penalty kick","Substitutions"],
  ["When did VAR debut at the World Cup?","2018","2010","2014","2022"],
  ["What is DRS in cricket?","Decision Review System","Defensive Run Strategy","Drag Reduction System","Delivery Rate Score"],
  ["Which 1986 goal is a famous example of cheating?","Maradona's 'Hand of God'","Zidane's headbutt","Henry's handball","Lampard's ghost goal"],
  ["What is a constitutive rule?","A rule that creates the game itself","A rule about fines","A safety rule","A rule about uniforms"],
  ["What change did football's 1992 back-pass rule make?","Goalkeepers can't pick up deliberate passes from teammates","Players can't pass backward","Offside was abolished","Throw-ins became kicks"]]},

{ t:"How to Watch Sport", s:"Seeing the game within the game",
  sec:[
  ["Beyond the ball",[
    "Casual viewers follow the ball; experienced fans watch the whole field. In football, watch the shape of the team without the ball, the runs players make to create space, and how a team presses. In basketball, watch off-ball screens and defensive rotations. In baseball, watch the pitcher–batter duel, pitch selection, and fielders' positioning before each pitch.",
    "Rewatching key moments, as broadcasters do with replays and analysts' telestrators, reveals how plays develop."]],
  ["Strategy and tactics",[
    "Strategy is the overall game plan; tactics are the specific actions used to carry it out. Coaches adjust tactics during a game: substitutions, formation changes, timeouts, and set plays. Recognizing these adjustments makes watching more interesting: why did the team switch to a zone defense, or bring on a fresh forward?",
    "Every sport balances risk and reward, attack and defense, and individual brilliance against team structure."]],
  ["Statistics and analytics",[
    "Statistics have long accompanied sport: batting averages in baseball, goals and assists in football and hockey, points and rebounds in basketball. Since the 2000s, analytics has transformed sport. Baseball's sabermetrics, popularized by Michael Lewis's book Moneyball (2003) about the Oakland Athletics, showed that undervalued statistics such as on-base percentage predict winning better than traditional ones.",
    "Modern metrics include expected goals (xG) in football, which estimates the probability that a shot becomes a goal based on its location and type; player efficiency and plus-minus in basketball; and Corsi in hockey (shot attempts). Tracking data captures every player's position many times per second."]],
  ["Context and narrative",[
    "Sport's drama comes from context: rivalries, standings, records, injuries, and history. A regular-season game may matter little, while a derby or cup final is charged with meaning. Commentators and journalists build narratives about underdogs, dynasties, comebacks, and legacies.",
    "Being aware of narratives helps viewers enjoy the story while recognizing where hype exaggerates."]],
  ["Live versus broadcast",[
    "Watching live in a stadium offers atmosphere, chanting, and a full view of the field; broadcasts offer close-ups, replays, statistics, and expert commentary. Each reveals different things.",
    "Second-screen habits, social media, fantasy sports, and betting have changed how fans watch; many follow multiple games at once. Knowing the rules well, though, remains the single best way to enjoy any sport."]]
  ],
  terms:[["Strategy","Overall game plan."],["Tactics","Specific actions carrying out a plan."],["Sabermetrics","Statistical analysis of baseball."],["Expected goals (xG)","Probability a shot becomes a goal."],["Derby","Match between local rivals."]],
  w:"Learning what to watch, and how to read statistics and context, transforms sport from noise into a rich story.",
  src:["Sports analytics","Sabermetrics","Moneyball","Expected goals","Strategy (game theory)"],
  q:[
  ["Which book popularized baseball analytics in 2003?","Moneyball","The Blind Side","Friday Night Lights","Fever Pitch"],
  ["What does expected goals (xG) estimate?","The probability a shot becomes a goal","Total goals in a season","A player's salary","Possession percentage"],
  ["What is the difference between strategy and tactics?","Strategy is the overall plan; tactics are specific actions","They are the same","Tactics are long-term","Strategy is only for defense"],
  ["Which team was the subject of Moneyball?","Oakland Athletics","New York Yankees","Boston Red Sox","Chicago Cubs"],
  ["What is a derby?","A match between local rivals","A horse race only","A cup final","An exhibition game"],
  ["Which statistic did Moneyball show was undervalued?","On-base percentage","Batting average","Stolen bases","Home runs"]]}

);


/* ---- from sports-03.js ---- */
/* SPORTS FOUNDATIONS, part 3: Unit 2 Football (Soccer), chapters 1-5 */
COURSES.sports.units.push({ t:"Football (Soccer)", ch:[

{ t:"The Laws of the Game", s:"How football works",
  sec:[
  ["The basics",[
    "Association football (called soccer in the US, Canada, and Australia, from 'assoc.') is played by two teams of eleven players, including a goalkeeper, on a rectangular grass or artificial pitch. The aim is to score by getting the ball entirely over the opponent's goal line between the posts and under the crossbar. A match lasts two 45-minute halves plus added time for stoppages; knockout games may go to extra time (two 15-minute periods) and a penalty shootout.",
    "Only the goalkeeper may handle the ball, and only within their own penalty area. The rules, called the Laws of the Game, are maintained by the International Football Association Board (IFAB), founded in 1886 by the four British associations, now joined by FIFA."]],
  ["Restarts",[
    "When the ball leaves the field over the touchline, the opponents of the last player to touch it take a throw-in. Over the goal line (not a goal), it's a goal kick if the attackers touched it last, or a corner kick if the defenders did. Play begins and restarts after goals with a kick-off from the center spot.",
    "Free kicks are awarded for fouls: direct free kicks (can score directly) for offenses such as tripping, pushing, or handball; indirect free kicks (must touch another player first) for others, such as dangerous play. A direct free kick offense by defenders inside their own penalty area results in a penalty kick from 11 meters (12 yards)."]],
  ["Offside",[
    "The offside rule is football's most debated law. A player is in an offside position if, when the ball is played by a teammate, they are in the opponents' half and nearer the opponents' goal line than both the ball and the second-last opponent (usually the last outfield defender, since the goalkeeper is usually last). Being in an offside position is only an offense if the player becomes involved in active play.",
    "A player cannot be offside directly from a goal kick, corner kick, or throw-in. The rule prevents attackers from simply waiting beside the goal. Defenders use the 'offside trap,' stepping up together to catch attackers offside."]],
  ["Cards and discipline",[
    "Referees caution players with a yellow card for offenses such as unsporting behavior, persistent fouling, or delaying the restart; a second yellow in a match means a red card. A straight red card, for serious foul play, violent conduct, or denying an obvious goal-scoring opportunity, sends the player off, and the team plays a person short.",
    "Yellow and red cards were introduced at the 1970 World Cup, inspired by English referee Ken Aston, who thought of the idea while waiting at traffic lights."]],
  ["Officials and changes",[
    "A match is controlled by a referee, two assistant referees (linesmen) with flags, a fourth official, and often the Video Assistant Referee. Substitution rules have evolved: from none until 1965 in England, to five substitutions in most top competitions since the COVID-19 period, plus concussion substitutes.",
    "Pitch size is flexible: international matches require roughly 100–110 meters long and 64–75 meters wide. The ball is size 5 for adults, with a circumference of 68–70 cm."]]
  ],
  terms:[["IFAB","Body that maintains football's Laws of the Game."],["Offside","Being beyond the second-last defender when the ball is played, while involved in play."],["Penalty kick","Free shot from 11 meters for a foul in the penalty area."],["Direct free kick","Free kick that can score directly."],["Red card","Sending-off, leaving the team a player short."]],
  w:"Knowing the Laws of the Game, especially offside, is essential to understanding every match of the world's biggest sport.",
  src:["Laws of the Game (association football)","Offside (association football)","International Football Association Board","Penalty kick (association football)","Ken Aston"],
  q:[
  ["How long is a standard football match?","Two 45-minute halves plus added time","Four 15-minute quarters","Two 40-minute halves","Three 30-minute periods"],
  ["From how far is a penalty kick taken?","11 meters (12 yards)","9.15 meters","16.5 meters","20 meters"],
  ["When can a player NOT be offside?","Directly from a throw-in","After a pass from midfield","In the opponent's half","When behind the last defender"],
  ["Who inspired the idea of yellow and red cards?","Ken Aston","Pierluigi Collina","Howard Webb","Sepp Blatter"],
  ["Which body maintains the Laws of the Game?","IFAB","UEFA","FIFA Council only","The FA"],
  ["What happens if the defending team last touched the ball before it crossed their goal line (no goal)?","Corner kick","Goal kick","Throw-in","Penalty"]]},

{ t:"Positions, Formations, and Tactics", s:"Shape and space",
  sec:[
  ["The positions",[
    "The goalkeeper guards the goal and organizes the defense. Defenders include center-backs, who mark strikers and win headers, and full-backs, who defend the flanks and increasingly attack (wing-backs push even further forward). Midfielders link defense and attack: the defensive midfielder (the 'number 6' or holding midfielder) shields the defense; central midfielders ('8s') cover ground; the attacking midfielder ('10' or playmaker) creates chances.",
    "Forwards include wingers, who attack down the sides, and strikers or center-forwards ('9s'), whose main job is scoring. The 'false nine' is a striker who drops deep into midfield to pull defenders out of position, famously used by Lionel Messi at Barcelona."]],
  ["Formations",[
    "Formations are described by numbers of defenders, midfielders, and forwards (not counting the goalkeeper). Early football used attacking 2-3-5 'pyramid' formations. Arsenal manager Herbert Chapman created the W-M (3-2-2-3) in the 1920s after the 1925 offside change.",
    "Brazil's 4-2-4 won the 1958 World Cup; England won in 1966 with a 4-4-2 'wingless wonders' shape. The 4-4-2 dominated for decades; the 4-3-3 and 4-2-3-1 became common in the 2000s, and back-three systems such as 3-5-2 and 3-4-3 have returned. Formations are only a starting point: teams change shape between attacking and defending."]],
  ["Key tactical ideas",[
    "Total Football, developed by Ajax and the Netherlands under coach Rinus Michels with Johan Cruyff in the early 1970s, had players constantly interchanging positions, with a high defensive line and pressing. Italy's catenaccio ('door-bolt'), associated with Helenio Herrera's Inter Milan in the 1960s, used a sweeper (libero) behind the defense and counterattacks.",
    "Pressing means harassing opponents to win the ball back quickly; 'gegenpressing' (counter-pressing), associated with Jürgen Klopp, aims to win it immediately after losing it. Tiki-taka, short-passing possession play perfected by Pep Guardiola's Barcelona (2008–12) and Spain's national team, dominated possession and wore opponents down."]],
  ["Attacking and defending",[
    "In attack, teams create width to stretch defenses, make runs 'in behind' the defensive line, use overlapping full-backs, and exploit 'half-spaces' between full-back and center-back. Set pieces, corners and free kicks, produce a large share of goals and are carefully rehearsed.",
    "In defense, teams choose between zonal marking (covering areas) and man-marking (following opponents), and between a high line (pushing up to compress space) and a low block (sitting deep and compact). Counterattacking teams defend deep and strike quickly into the space left behind."]],
  ["The manager's role",[
    "The manager or head coach selects the team, sets tactics, makes substitutions, and in Britain traditionally also handled transfers. Great managers include Sir Alex Ferguson (Manchester United, 13 Premier League titles), Arrigo Sacchi, Johan Cruyff, José Mourinho, Pep Guardiola, Carlo Ancelotti (record winner of the Champions League as a coach), and Jürgen Klopp.",
    "Modern clubs have large staffs of analysts, fitness coaches, and data scientists supporting the manager."]]
  ],
  terms:[["False nine","Striker who drops deep to create space."],["Total Football","Dutch system of fluid positional interchange."],["Catenaccio","Italian defensive system with a sweeper."],["Gegenpressing","Counter-pressing immediately after losing the ball."],["Low block","Deep, compact defensive shape."]],
  w:"Tactics and positions explain why teams play so differently and how matches are won and lost.",
  src:["Formation (association football)","Total Football","Catenaccio","Tiki-taka","Pressing (association football)"],
  q:[
  ["Which system is associated with Rinus Michels and Johan Cruyff?","Total Football","Catenaccio","Tiki-taka","Gegenpressing"],
  ["What is a 'false nine'?","A striker who drops deep into midfield","A defensive midfielder","A substitute goalkeeper","A winger"],
  ["Which formation did Brazil use to win the 1958 World Cup?","4-2-4","4-4-2","3-5-2","2-3-5"],
  ["Which coach is associated with gegenpressing?","Jürgen Klopp","Pep Guardiola","Helenio Herrera","Arrigo Sacchi"],
  ["What does catenaccio mean?","Door-bolt","Short passing","Total football","High press"],
  ["Which manager created the W-M formation?","Herbert Chapman","Alf Ramsey","Bill Shankly","Matt Busby"]]},

{ t:"The World Cup", s:"The planet's biggest tournament",
  sec:[
  ["Beginnings",[
    "FIFA president Jules Rimet championed a world championship, and the first FIFA World Cup was held in Uruguay in 1930, with 13 teams; the hosts, reigning Olympic champions, beat Argentina 4–2 in the final. The tournament has been held every four years since, except 1942 and 1946 because of World War II.",
    "Italy won in 1934 and 1938 under Mussolini's regime. In 1950 in Brazil, Uruguay's shock victory over Brazil in the deciding match before about 200,000 people at the Maracanã became known as the 'Maracanazo,' a national trauma for Brazil."]],
  ["Brazil and the golden era",[
    "Brazil has won the World Cup a record five times: 1958, 1962, 1970, 1994, and 2002. Pelé, a teenager in 1958, became the only player to win three World Cups (1958, 1962, 1970). The 1970 Brazil team, with Pelé, Jairzinho, Rivellino, Tostão, and captain Carlos Alberto, is often called the greatest team ever, and the first World Cup broadcast widely in color.",
    "England won its only World Cup at home in 1966, with Geoff Hurst scoring a hat-trick in the final against West Germany."]],
  ["Germany, Italy, Argentina, and others",[
    "Germany (as West Germany in 1954, 1974, 1990, and united in 2014) and Italy (1934, 1938, 1982, 2006) have four titles each. Argentina has three (1978, 1986, 2022): Diego Maradona inspired the 1986 win, including the 'Hand of God' and a famous solo 'Goal of the Century' against England, and Lionel Messi finally won in 2022 in Qatar after a dramatic final against France, decided on penalties after a 3–3 draw in which Kylian Mbappé scored a hat-trick.",
    "France has won twice (1998 at home, with Zinedine Zidane; and 2018), Uruguay twice (1930, 1950), and England and Spain (2010) once each."]],
  ["Records and moments",[
    "Germany's Miroslav Klose holds the record for most World Cup goals (16). France's Just Fontaine scored 13 in a single tournament (1958). Germany's 7–1 semifinal win over host Brazil in 2014 shocked the world. Memorable moments include Zidane's headbutt and red card in the 2006 final, and Cameroon's Roger Milla dancing at the corner flag at age 38 in 1990.",
    "Africa's best runs reached the semifinals for the first time when Morocco did so in 2022; South Korea (2002) and the US (1930) also reached the last four."]],
  ["The modern tournament",[
    "The World Cup expanded from 16 teams to 24 (1982), then 32 (1998). The 2026 World Cup, co-hosted by the United States, Canada, and Mexico, was the first with 48 teams and 104 matches. The 2022 Qatar tournament, the first in the Middle East and held in November–December, drew criticism over migrant workers' conditions and human rights.",
    "The FIFA Women's World Cup began in 1991; the United States has won it four times, and Spain won its first title in 2023."]]
  ],
  terms:[["Jules Rimet","FIFA president who founded the World Cup."],["Maracanazo","Uruguay's 1950 upset of Brazil."],["Hat-trick","Three goals by one player in a match."],["Group stage","Opening round-robin phase of a tournament."],["Knockout stage","Elimination rounds after the groups."]],
  w:"The World Cup is the world's most-watched sporting event and the stage for football's greatest legends.",
  src:["FIFA World Cup","1930 FIFA World Cup","Maracanazo","Pelé","2022 FIFA World Cup final"],
  q:[
  ["Which country hosted and won the first World Cup in 1930?","Uruguay","Brazil","Italy","Argentina"],
  ["Which nation has won the World Cup a record five times?","Brazil","Germany","Italy","Argentina"],
  ["Who is the only player to win three World Cups?","Pelé","Maradona","Messi","Ronaldo Nazário"],
  ["Who holds the record for most World Cup goals?","Miroslav Klose","Ronaldo Nazário","Just Fontaine","Lionel Messi"],
  ["Which country won the 2022 World Cup?","Argentina","France","Croatia","Morocco"],
  ["How many teams competed in the 2026 World Cup?","48","32","40","64"]]},

{ t:"Club Football in Europe", s:"Leagues, cups, and giants",
  sec:[
  ["The 'Big Five' leagues",[
    "Europe's top national leagues are England's Premier League (founded 1992, the richest league in the world), Spain's La Liga, Italy's Serie A, Germany's Bundesliga (founded 1963), and France's Ligue 1. Each league plays a double round-robin (home and away against every team), with three points for a win (introduced in England in 1981 and adopted widely by FIFA in 1994) and one for a draw.",
    "Bottom teams are relegated to the second division and replaced by promoted teams, creating dramatic battles at both ends of the table."]],
  ["Cup competitions",[
    "Domestic knockout cups give smaller clubs a chance to upset giants. England's FA Cup (first played 1871–72) is the oldest national football competition in the world. Spain has the Copa del Rey, Italy the Coppa Italia, Germany the DFB-Pokal, and France the Coupe de France.",
    "Winning the league, domestic cup, and European Cup in one season is called a 'treble.'"]],
  ["European competitions",[
    "The European Cup began in 1955–56; Real Madrid won the first five editions with stars such as Alfredo Di Stéfano and Ferenc Puskás, and has won the competition a record 15 times as of 2024. It was rebranded the UEFA Champions League in 1992, with a group stage and the famous anthem; from 2024–25 it switched to a single 36-team 'league phase.'",
    "The second-tier Europa League and the third-tier Conference League (from 2021) give other clubs European football. Other clubs with multiple European Cups include AC Milan, Bayern Munich, Liverpool, Barcelona, and Ajax."]],
  ["Great clubs and rivalries",[
    "Clubs inspire intense loyalty, often tied to local identity, class, or religion. Famous rivalries include El Clásico (Real Madrid vs Barcelona, charged with Spanish and Catalan politics), the Derby della Madonnina (AC Milan vs Inter), the North West derby (Liverpool vs Manchester United), the Old Firm (Celtic vs Rangers in Glasgow, with Catholic and Protestant associations), and Der Klassiker (Bayern vs Dortmund).",
    "Ownership models differ: many English clubs are owned by billionaires, investment funds, or states (Manchester City, Newcastle United, Paris Saint-Germain), while German clubs follow the '50+1 rule,' requiring members to hold majority voting rights, and Barcelona and Real Madrid are member-owned."]],
  ["Money and the Super League",[
    "Television money transformed European football from the 1990s, widening the gap between rich and poor clubs. Financial rules such as UEFA's Financial Fair Play (introduced 2011, replaced by financial sustainability rules) try to limit overspending.",
    "In April 2021, twelve elite clubs announced a breakaway 'European Super League'; furious fan protests, especially in England, caused most to withdraw within 48 hours. The episode showed the power of fans and the tensions between tradition and commercial ambition."]]
  ],
  terms:[["Premier League","England's top division since 1992."],["Treble","Winning league, cup, and European title in one season."],["Champions League","UEFA's elite club competition."],["50+1 rule","German rule giving members majority control of clubs."],["El Clásico","Real Madrid vs Barcelona."]],
  w:"European club football is the sport's richest and most-watched level, full of history and rivalry.",
  src:["UEFA Champions League","Premier League","FA Cup","El Clásico","European Super League"],
  q:[
  ["Which club won the first five European Cups?","Real Madrid","AC Milan","Benfica","Barcelona"],
  ["What is the oldest national football competition in the world?","FA Cup","Copa del Rey","Scottish Cup","Coppa Italia"],
  ["What does the '50+1 rule' in Germany require?","Members hold majority voting rights","Half the players must be German","Clubs must be 50% profitable","50 home games a year"],
  ["What is El Clásico?","Real Madrid vs Barcelona","AC Milan vs Inter","Celtic vs Rangers","Bayern vs Dortmund"],
  ["When was the Premier League founded?","1992","1888","1963","2001"],
  ["What happened to the 2021 European Super League plan?","Most clubs withdrew within 48 hours after fan protests","It launched successfully","UEFA adopted it","It was delayed to 2025"]]},

{ t:"Legends of Football", s:"Pelé, Maradona, Messi, Ronaldo, and more",
  sec:[
  ["Early giants",[
    "Alfredo Di Stéfano, Argentine-born, led Real Madrid's 1950s dynasty with all-around brilliance. Ferenc Puskás captained Hungary's 'Magical Magyars,' who beat England 6–3 at Wembley in 1953, the first home defeat of England by a team from outside the British Isles. Stanley Matthews, the 'Wizard of the Dribble,' played top-flight football in England until age 50.",
    "Lev Yashin of the Soviet Union, the 'Black Spider,' remains the only goalkeeper to win the Ballon d'Or (1963). Eusébio of Portugal and Benfica was Africa-born (Mozambique) and among the first global Black superstars."]],
  ["Pelé and Maradona",[
    "Pelé (Edson Arantes do Nascimento, 1940–2022) of Santos and Brazil won three World Cups and scored over 1,000 goals in total by his count (including friendlies), becoming the first global football icon. Garrincha, his Brazilian teammate, was a dazzling dribbler.",
    "Diego Maradona (1960–2020) of Argentina led his nation to the 1986 World Cup and transformed Napoli into Italian champions (1987, 1990). His genius, controversies, and struggles with addiction made him a complex legend."]],
  ["Cruyff, Beckenbauer, and the 1970s–90s",[
    "Johan Cruyff embodied Total Football with Ajax and the Netherlands, won three Ballons d'Or, invented the 'Cruyff turn,' and as coach shaped Barcelona's philosophy. Franz Beckenbauer, 'Der Kaiser,' redefined the attacking libero, captained West Germany to the 1974 World Cup, and coached them to the 1990 title.",
    "Later legends include Michel Platini, Marco van Basten, Roberto Baggio, George Weah of Liberia (the only African to win the Ballon d'Or, 1995, later president of Liberia), Ronaldo Nazário ('O Fenômeno'), Zinedine Zidane, and Ronaldinho."]],
  ["Messi and Ronaldo",[
    "Lionel Messi (born 1987) of Argentina spent most of his career at Barcelona, winning numerous Champions Leagues and league titles and a record eight Ballons d'Or; he capped his career with the 2022 World Cup. His dribbling, vision, and goals made him, for many, the greatest of all time.",
    "Cristiano Ronaldo (born 1985) of Portugal starred for Manchester United, Real Madrid, Juventus, and later Al Nassr in Saudi Arabia, won five Ballons d'Or and five Champions Leagues, led Portugal to Euro 2016, and became the all-time top scorer in men's international football. Their rivalry defined football for over a decade."]],
  ["Women's legends and today's stars",[
    "In the women's game, Marta of Brazil has scored a record number of goals at Women's World Cups; Mia Hamm and Abby Wambach led the United States; Birgit Prinz starred for Germany; Christine Sinclair of Canada holds the record for most international goals by any player, male or female; and Alexia Putellas and Aitana Bonmatí of Spain each won multiple Ballons d'Or Féminin.",
    "Leading men's stars of the 2020s include Kylian Mbappé, Erling Haaland, Mohamed Salah, Kevin De Bruyne, Vinícius Júnior, Jude Bellingham, Rodri (Ballon d'Or 2024), and Lamine Yamal."]]
  ],
  terms:[["Ballon d'Or","Annual award for the world's best player."],["Magical Magyars","Hungary's great 1950s team."],["Libero","Free-roaming sweeper behind the defense."],["Cruyff turn","Dribbling feint invented by Johan Cruyff."],["GOAT","'Greatest of all time' debate."]],
  w:"Football's legends define its history and the debates that fans love to have.",
  src:["Pelé","Diego Maradona","Johan Cruyff","Lionel Messi","Cristiano Ronaldo"],
  q:[
  ["Who is the only goalkeeper to win the Ballon d'Or?","Lev Yashin","Gianluigi Buffon","Manuel Neuer","Iker Casillas"],
  ["Which African player won the Ballon d'Or and later became a president?","George Weah","Samuel Eto'o","Didier Drogba","Roger Milla"],
  ["Who led Napoli to Italian titles in 1987 and 1990?","Diego Maradona","Zico","Michel Platini","Ruud Gullit"],
  ["Who holds the record for most international goals by any player?","Christine Sinclair","Cristiano Ronaldo","Abby Wambach","Ali Daei"],
  ["Which Hungarian team beat England 6–3 at Wembley in 1953?","The Magical Magyars","Ferencváros","Honvéd only","Austria"],
  ["How many Ballons d'Or has Messi won?","Eight","Five","Six","Ten"]]}

]});


/* ---- from sports-04.js ---- */
/* SPORTS FOUNDATIONS, part 4: Unit 2 chapters 6-9 */
COURSES.sports.units[1].ch.push(

{ t:"Continental Championships", s:"Euros, Copa América, AFCON, and more",
  sec:[
  ["The European Championship",[
    "The UEFA European Championship ('the Euros') began in 1960, won by the Soviet Union. It expanded from four finalists to eight (1980), 16 (1996), and 24 (2016). Spain has won it a record four times (1964, 2008, 2012, 2024), and Germany three times (1972, 1980, 1996).",
    "Famous upsets include Denmark's 1992 win, after being called up as a late replacement for Yugoslavia, which was banned due to war, and Greece's defensive triumph in 2004. Spain's 2008–2012 run (Euros, World Cup, Euros) is considered one of the greatest in international football. Italy won Euro 2020 (played in 2021) on penalties at Wembley."]],
  ["The Copa América",[
    "The Copa América, South America's championship, began in 1916 and is the oldest continental national-team competition. Argentina has won it a record 16 times, including 2021 and 2024, followed by Uruguay with 15. Guest teams from other confederations sometimes take part; the 2016 'Centenario' and 2024 editions were held in the United States.",
    "Brazil–Argentina is one of the fiercest international rivalries in the world."]],
  ["Africa Cup of Nations",[
    "The Africa Cup of Nations (AFCON) began in 1957 with just three teams, Egypt, Sudan, and Ethiopia, and Egypt won. Egypt has won a record seven titles. Cameroon, Ghana, Nigeria, Ivory Coast (which won as host in 2024 after nearly being eliminated in the group stage), Senegal (first title 2021), and Algeria are other powers.",
    "African players became stars in Europe from the 1990s, and Africa's representation at the World Cup has grown, with nine African teams qualifying for the expanded 2026 tournament."]],
  ["Asia, North America, and Oceania",[
    "The AFC Asian Cup began in 1956; Japan has won it a record four times, while Saudi Arabia and Iran have three each and Qatar won consecutive titles in 2019 and 2023. The CONCACAF Gold Cup covers North and Central America and the Caribbean; Mexico and the United States dominate. The OFC Nations Cup covers Oceania, where New Zealand is strongest; Australia moved to the Asian confederation in 2006.",
    "Each continental confederation also runs World Cup qualification for its region."]],
  ["Nations League and club world events",[
    "UEFA introduced the Nations League in 2018 to replace many friendlies with competitive matches, organized in divisions with promotion and relegation; Portugal won the first edition and won again in 2025. CONCACAF has a similar competition.",
    "FIFA's Club World Cup brings together continental club champions; it was expanded to a 32-team tournament held in the United States in 2025, which Chelsea won."]]
  ],
  terms:[["Euros","UEFA European Championship."],["Copa América","South American championship, oldest continental tournament."],["AFCON","Africa Cup of Nations."],["Confederation","Continental football governing body."],["Nations League","UEFA competition replacing many friendlies."]],
  w:"Continental championships are the second great stage of international football and reveal regional football cultures.",
  src:["UEFA European Championship","Copa América","Africa Cup of Nations","AFC Asian Cup","UEFA Nations League"],
  q:[
  ["Which is the oldest continental national-team competition?","Copa América","Euros","AFCON","Asian Cup"],
  ["Which team won Euro 1992 after a late call-up?","Denmark","Greece","Netherlands","Czechoslovakia"],
  ["Which nation has won AFCON a record seven times?","Egypt","Cameroon","Ghana","Nigeria"],
  ["Which country has won the Euros a record four times?","Spain","Germany","Italy","France"],
  ["To which confederation did Australia move in 2006?","Asian (AFC)","Oceania (OFC)","CONCACAF","UEFA"],
  ["Which country won Euro 2004 with a defensive style?","Greece","Portugal","Denmark","Czech Republic"]]},

{ t:"Football Around the World", s:"South America, Africa, Asia, and North America",
  sec:[
  ["South America",[
    "British workers and teachers brought football to South America in the late 19th century, and it became a passion. Argentina, Brazil, and Uruguay developed styles valued for skill and creativity, sometimes called 'jogo bonito' ('the beautiful game') in Brazil. Great clubs include Boca Juniors and River Plate (their Buenos Aires 'Superclásico' is among the world's most intense derbies), Flamengo, Santos, Palmeiras, Peñarol, and Nacional.",
    "The Copa Libertadores (since 1960) is South America's club championship. South American clubs develop many of the world's top players, but most stars move to Europe young, sold to fund local clubs."]],
  ["Africa",[
    "Football spread in Africa through colonial schools, missions, and workplaces, and became tied to independence movements; Algeria's FLN team in 1958 was formed by players who left French clubs to support the independence struggle. Clubs such as Al Ahly of Egypt, the most successful in the CAF Champions League, and TP Mazembe of DR Congo have huge followings.",
    "Stars such as Roger Milla, George Weah, Samuel Eto'o, Didier Drogba, Yaya Touré, Mohamed Salah, and Sadio Mané have become global icons. Academies and scouting networks feed African talent to Europe, raising concerns about exploitation of young players."]],
  ["Asia and the Middle East",[
    "Japan's J.League (1993) and South Korea's K League developed strong professional football, and both nations co-hosted the 2002 World Cup. China invested heavily in its Super League in the 2010s before financial cutbacks. In the Middle East, Saudi Arabia's Pro League attracted stars including Cristiano Ronaldo, Karim Benzema, and Neymar from 2023 with huge salaries, part of a wider national investment in sport, and Saudi Arabia is set to host the 2034 World Cup.",
    "Football is also popular in Iran, India (Indian Super League, 2014), Southeast Asia, and Australia's A-League."]],
  ["North America",[
    "In the United States, soccer long trailed American football, baseball, and basketball. The North American Soccer League (NASL) of the 1970s signed Pelé to the New York Cosmos but collapsed in 1984. The US hosted the 1994 World Cup, which led to Major League Soccer (MLS), launched in 1996.",
    "David Beckham's 2007 move to LA Galaxy, via the 'Designated Player' rule, raised MLS's profile, and Lionel Messi's 2023 move to Inter Miami (co-owned by Beckham) brought global attention. Soccer is among the most played youth sports in the US, and Mexico's Liga MX has some of the highest attendances in the Americas."]],
  ["A global game",[
    "FIFA has 211 member associations, more than the United Nations has member states. The sport's simplicity, needing only a ball and space, makes it accessible everywhere; street football, futsal (a five-a-side indoor version with a smaller, heavier ball), and beach soccer are popular variants.",
    "The global flow of players, coaches, and fans means a match in London may feature players from a dozen countries and be watched live across Asia and Africa."]]
  ],
  terms:[["Copa Libertadores","South American club championship."],["Superclásico","Boca Juniors vs River Plate derby."],["MLS","Major League Soccer, founded 1996."],["Futsal","Indoor five-a-side football."],["Designated Player","MLS rule allowing big salaries outside the cap."]],
  w:"Football's global spread shows how one game takes on different meanings, styles, and passions across cultures.",
  src:["Copa Libertadores","Superclásico","Major League Soccer","Saudi Pro League","Futsal"],
  q:[
  ["Which Buenos Aires clubs contest the Superclásico?","Boca Juniors and River Plate","Racing and Independiente","Flamengo and Fluminense","Peñarol and Nacional"],
  ["What is South America's club championship?","Copa Libertadores","Copa América","Copa Sudamericana only","Recopa"],
  ["Which club is the most successful in the CAF Champions League?","Al Ahly","TP Mazembe","Zamalek","Espérance"],
  ["When did MLS launch?","1996","1984","1994","2007"],
  ["Which two countries co-hosted the 2002 World Cup?","Japan and South Korea","China and Japan","USA and Mexico","Qatar and UAE"],
  ["How many member associations does FIFA have?","211","193","150","250"]]},

{ t:"The Women's Game", s:"From bans to stadium records",
  sec:[
  ["Early boom",[
    "Women played organized football in Britain from the 1890s. During World War I, factory teams flourished; Dick, Kerr Ladies of Preston drew a crowd of 53,000 to Goodison Park, Liverpool, on Boxing Day 1920. Lily Parr, a striker for the team, scored hundreds of goals.",
    "In 1921, the English FA banned women from playing on its members' grounds, calling football 'quite unsuitable for females.' The ban lasted until 1971, devastating the women's game; similar bans existed in Germany (until 1970) and Brazil (until 1979)."]],
  ["Revival",[
    "After the bans ended, women's football grew rapidly, especially in Scandinavia, the United States, and China. Title IX (1972), a US law requiring equal opportunity in federally funded education programs, led to huge growth in American girls' and college soccer.",
    "The first official FIFA Women's World Cup was held in China in 1991, won by the United States. Women's football joined the Olympics in 1996."]],
  ["The US and the 1999 World Cup",[
    "The 1999 Women's World Cup final in Pasadena, California, drew over 90,000 fans; the US beat China on penalties, and Brandi Chastain's celebration became iconic. The US has won four Women's World Cups (1991, 1999, 2015, 2019) and multiple Olympic golds.",
    "US players including Megan Rapinoe and Alex Morgan led a legal fight for equal pay, resolved in 2022 with an agreement for equal pay between the US men's and women's national teams."]],
  ["European growth",[
    "Club women's football has grown fast in Europe. Lyon dominated the UEFA Women's Champions League with eight titles; Barcelona's women's team drew 91,553 spectators to Camp Nou in 2022, then a record for a women's match. England's Lionesses won Euro 2022 at home and retained the title in 2025; the 2023 Women's World Cup in Australia and New Zealand was won by Spain.",
    "Professional leagues such as England's Women's Super League, the US National Women's Soccer League (NWSL, founded 2012), and Spain's Liga F have increased investment, media deals, and attendance."]],
  ["Continuing challenges",[
    "Women's football still faces gaps in pay, facilities, media coverage, and medical research, for example on the higher rates of ACL (knee ligament) injuries among female players. Abuse scandals, such as the misconduct revealed in the NWSL in 2021–22 and the controversy over Spanish federation president Luis Rubiales's unwanted kiss of player Jenni Hermoso after the 2023 final, prompted reforms.",
    "Yet the trajectory is strongly upward, with record crowds, sponsorships, and a new generation of stars."]]
  ],
  terms:[["Dick, Kerr Ladies","Famous early English women's team."],["FA ban (1921)","English ban on women's football, lifted 1971."],["Title IX","1972 US law driving growth of women's sport."],["Lionesses","England women's national team."],["NWSL","US National Women's Soccer League."]],
  w:"Women's football overcame decades of bans and is now one of the fastest-growing areas of sport.",
  src:["Women's association football","Dick, Kerr Ladies F.C.","FIFA Women's World Cup","Title IX","1999 FIFA Women's World Cup final"],
  q:[
  ["When did the English FA ban women from members' grounds?","1921","1895","1945","1966"],
  ["Which early team drew 53,000 spectators in 1920?","Dick, Kerr Ladies","Lyon","Arsenal Ladies","Doncaster Belles"],
  ["Where was the first official Women's World Cup held in 1991?","China","USA","Sweden","Germany"],
  ["Which US law boosted women's sports from 1972?","Title IX","Equal Pay Act","Civil Rights Act","Amateur Sports Act"],
  ["Which country won the 2023 Women's World Cup?","Spain","England","USA","Sweden"],
  ["Which club won eight UEFA Women's Champions League titles?","Lyon","Barcelona","Wolfsburg","Arsenal"]]},

{ t:"The Business of Football", s:"Transfers, TV, and fans",
  sec:[
  ["Revenue streams",[
    "Top clubs earn money from broadcasting rights, commercial deals (sponsorships, kits, merchandise), and matchday revenue (tickets and hospitality), plus prize money from competitions. Broadcasting is the biggest source for most top clubs; the Premier League's global TV deals are worth billions of pounds per season.",
    "Deloitte's annual Football Money League ranks clubs by revenue; Real Madrid has recently topped the list with over €1 billion in a season."]],
  ["Transfers",[
    "Players move between clubs via transfers: the buying club pays a fee to the selling club to end the player's contract. Agents negotiate deals and earn large commissions. Since the Bosman ruling (1995), players out of contract can leave for free, increasing their bargaining power.",
    "The world-record transfer fee is Neymar's €222 million move from Barcelona to Paris Saint-Germain in 2017. Transfer windows, typically in summer and January, restrict when clubs can register new players. Loans and sell-on clauses are common."]],
  ["Wages and inequality",[
    "Elite players earn enormous salaries; wages typically consume more than half of top clubs' revenues. Below the elite, many professional players earn modest wages and have short careers. Clubs in smaller leagues act as 'selling clubs' that develop talent for richer leagues.",
    "Financial regulations try to limit losses; clubs breaking rules can face fines, transfer bans, or points deductions, as several English clubs did in the 2020s."]],
  ["Fans and ownership",[
    "Fans are the emotional and economic heart of football, but rising ticket prices, kick-off times set for TV, and distant owners have led to protests. Supporter trusts and movements such as 'Against Modern Football' campaign for fan influence. Germany's 50+1 rule and member-owned clubs show alternatives.",
    "After the 2021 Super League attempt, the UK government commissioned a fan-led review (2021), leading to the Football Governance Act 2025, which created an Independent Football Regulator for English football."]],
  ["Stadiums and safety",[
    "Stadium disasters reshaped football. At Hillsborough in Sheffield in 1989, 97 Liverpool fans were killed in a crush; inquests in 2016 concluded they were unlawfully killed and that police failures caused the disaster, overturning false claims blaming fans. The Taylor Report led to all-seater stadiums in England's top divisions.",
    "Other tragedies include the 1985 Heysel disaster in Brussels, where 39 people died before a European Cup final, leading to English clubs' five-year ban from European competition, and the 2022 Kanjuruhan Stadium disaster in Indonesia. Safe standing areas have recently returned to some grounds."]]
  ],
  terms:[["Transfer fee","Payment to release a player from a contract."],["Transfer window","Period when clubs can register new players."],["Football Money League","Deloitte's ranking of club revenues."],["Taylor Report","Inquiry after Hillsborough leading to all-seater stadiums."],["Supporter trust","Fan organization seeking influence in clubs."]],
  w:"Money, ownership, and safety shape the game fans see, and the debates about football's future.",
  src:["Transfer (association football)","Deloitte Football Money League","Hillsborough disaster","Heysel Stadium disaster","Independent Football Regulator"],
  q:[
  ["What is the world-record transfer fee?","Neymar's €222 million move to PSG","Mbappé to Real Madrid","Ronaldo to Juventus","Bale to Real Madrid"],
  ["Which disaster in 1989 led to all-seater stadiums in England?","Hillsborough","Heysel","Bradford fire","Ibrox"],
  ["What is usually the largest revenue source for top clubs?","Broadcasting rights","Ticket sales","Food sales","Prize money"],
  ["Which ruling let out-of-contract players move freely in the EU?","Bosman ruling","Taylor Report","Webster ruling","Fair Play rule"],
  ["What did the 1985 Heysel disaster lead to?","A ban on English clubs in Europe","All-seater stadiums","VAR","The Premier League"],
  ["What did the Football Governance Act 2025 create?","An Independent Football Regulator","A new league","A transfer cap","A Super League"]]}

);


/* ---- from sports-05.js ---- */
/* SPORTS FOUNDATIONS, part 5: Unit 3 North American Sports, chapters 1-4 */
COURSES.sports.units.push({ t:"North American Sports", ch:[

{ t:"American Football: The Rules", s:"Downs, yards, and touchdowns",
  sec:[
  ["Origins",[
    "American football evolved from rugby and soccer-style games played at American colleges; the first intercollegiate game, between Rutgers and Princeton in 1869, resembled soccer. Walter Camp of Yale, the 'Father of American Football,' introduced key innovations in the 1880s: the line of scrimmage, the system of downs, and the reduction of teams to eleven players.",
    "The game was so violent that in 1905 eighteen players died; President Theodore Roosevelt pressed colleges to reform it, and the forward pass was legalized in 1906, gradually opening up the game. The body that became the NCAA was created in 1906 partly as a result."]],
  ["The field and scoring",[
    "The field is 100 yards long between goal lines, plus two 10-yard end zones, and 53⅓ yards wide, marked with yard lines every five yards. A team scores a touchdown (6 points) by carrying the ball into, or catching it in, the opponent's end zone, then attempts an extra point (1 point, kicked) or a two-point conversion (a play from close range).",
    "A field goal (3 points) is kicked through the uprights. A safety (2 points) is scored when the defense tackles a ball-carrier in his own end zone."]],
  ["Downs",[
    "The offense has four downs (attempts) to advance the ball at least 10 yards. If it succeeds, it earns a new 'first down' and four more attempts. If it fails, possession goes to the other team. So teams usually punt (kick the ball away) on fourth down to push the opponent back, or attempt a field goal if close enough.",
    "Each play starts from the line of scrimmage with a snap from the center. Plays are either runs or passes; only one forward pass is allowed per play, from behind the line of scrimmage. An incomplete pass stops the clock and the play ends."]],
  ["Game structure",[
    "An NFL game has four 15-minute quarters, but frequent stoppages mean games last over three hours. Teams have eleven players on the field; unlike most sports, there is unlimited substitution between plays, so teams have separate offensive, defensive, and special teams units.",
    "The play clock gives the offense 40 seconds between plays. Each team has three timeouts per half. Ties in the regular season go to a 10-minute overtime period."]],
  ["Penalties",[
    "Officials throw yellow flags for penalties, which cost yardage. Common penalties include false start (an offensive player moving before the snap), offside (a defender crossing the line early), holding (illegally grabbing an opponent), pass interference (illegally hindering a receiver), and roughing the passer.",
    "Safety rules have increased, especially concerning hits to the head, as research revealed the risks of concussions and chronic traumatic encephalopathy (CTE)."]],
  ["Canadian football",[
    "Canadian football, played in the Canadian Football League (CFL), developed from the same rugby roots but differs: a longer and wider field, 12 players per side, only three downs to gain 10 yards, and the 'rouge' or single point for a kick not returned out of the end zone. The Grey Cup, first awarded in 1909, is its championship.",
    "These differences produce a more pass-heavy, open game."]]
  ],
  terms:[["Down","One of four attempts to gain 10 yards."],["Line of scrimmage","Line where each play starts."],["Touchdown","Six-point score in the end zone."],["Field goal","Three-point kick through the uprights."],["Punt","Kick on fourth down to give the ball away with field position."]],
  w:"The down-and-distance system makes American football a game of strategy between every play.",
  src:["American football","Walter Camp","American football rules","Forward pass","Canadian football"],
  q:[
  ["How many points is a touchdown?","6","7","3","2"],
  ["How many downs does an NFL offense have to gain 10 yards?","Four","Three","Five","Two"],
  ["Who is called the 'Father of American Football'?","Walter Camp","Vince Lombardi","Knute Rockne","Pop Warner"],
  ["When was the forward pass legalized?","1906","1869","1920","1933"],
  ["How many downs does Canadian football allow?","Three","Four","Five","Two"],
  ["What is a safety worth?","2 points","1 point","3 points","6 points"]]},

{ t:"The NFL and Football Culture", s:"From mill towns to the Super Bowl",
  sec:[
  ["Early pro football",[
    "Professional football began in the 1890s in Pennsylvania mill towns. The American Professional Football Association was founded in 1920 in Canton, Ohio (now home of the Pro Football Hall of Fame) and renamed the National Football League in 1922. Early stars included Jim Thorpe, a Native American Olympic champion, and Red Grange, whose 1925 signing with the Chicago Bears drew huge crowds.",
    "For decades, college football was more popular than the professional game."]],
  ["The rise of the NFL",[
    "The 1958 championship game between the Baltimore Colts and the New York Giants, decided in sudden-death overtime and watched by millions on television, became known as 'The Greatest Game Ever Played' and helped make the NFL a TV sport. Commissioner Pete Rozelle negotiated league-wide TV deals and revenue sharing, ensuring small-market teams like the Green Bay Packers (community-owned) could compete.",
    "The rival American Football League (AFL) agreed to merge with the NFL in 1966, completed in 1970. The first AFL–NFL World Championship Game, later called the Super Bowl, was played in January 1967; Vince Lombardi's Packers won the first two. The trophy is named after Lombardi."]],
  ["The Super Bowl",[
    "The Super Bowl has become an unofficial American holiday and the most-watched annual television event in the US, with audiences over 100 million, famous for its commercials and halftime show. The New England Patriots and the Pittsburgh Steelers had each won six Super Bowls by 2025, the most of any team.",
    "Famous moments include Joe Namath's guaranteed victory for the AFL's New York Jets in Super Bowl III (1969), the Miami Dolphins' 1972 perfect season (the only undefeated, untied season including the Super Bowl), and the Patriots' comeback from 28–3 against Atlanta in Super Bowl LI."]],
  ["Legends",[
    "Great players include running back Jim Brown, quarterbacks Johnny Unitas, Joe Montana, Peyton Manning, Patrick Mahomes, and Tom Brady (who won a record seven Super Bowls, six with the Patriots and one with Tampa Bay), wide receiver Jerry Rice (career records for receptions and receiving yards), running backs Walter Payton and Emmitt Smith (career rushing yards record), and defenders Lawrence Taylor and Reggie White.",
    "Coaches such as Vince Lombardi, Paul Brown, Don Shula (most wins), Bill Walsh (West Coast offense), and Bill Belichick are legendary."]],
  ["The league today",[
    "The NFL has 32 teams in two conferences (AFC and NFC), each with four divisions. The regular season expanded to 17 games in 2021. The NFL Draft, where teams pick college players in reverse order of their records, is a major media event. A hard salary cap promotes parity.",
    "The NFL is the most valuable sports league in the world by revenue. It plays regular-season games internationally, in London, Germany, Mexico, Brazil, and elsewhere."]],
  ["Controversies",[
    "The NFL faced a reckoning over concussions: research by pathologist Bennet Omalu and others linked repeated head impacts to CTE in former players, leading to a lawsuit settled in 2013–15 for over $1 billion and rule changes. In 2016, quarterback Colin Kaepernick began kneeling during the national anthem to protest police brutality and racial injustice, sparking a national debate.",
    "The league's record on hiring Black head coaches led to the 'Rooney Rule' (2003), requiring teams to interview minority candidates."]]
  ],
  terms:[["Super Bowl","NFL championship game, first played 1967."],["AFC/NFC","The NFL's two conferences."],["Lombardi Trophy","Super Bowl trophy."],["CTE","Brain disease linked to repeated head trauma."],["Rooney Rule","Requirement to interview minority coaching candidates."]],
  w:"The NFL is America's most popular league and a lens on American media, money, health, and politics.",
  src:["National Football League","Super Bowl","1958 NFL Championship Game","Tom Brady","Chronic traumatic encephalopathy"],
  q:[
  ["Where was the NFL's predecessor founded in 1920?","Canton, Ohio","Chicago","Green Bay","New York"],
  ["Which game is called 'The Greatest Game Ever Played'?","The 1958 NFL Championship","Super Bowl I","Super Bowl LI","The Ice Bowl"],
  ["Who has won a record seven Super Bowls as a player?","Tom Brady","Joe Montana","Peyton Manning","Patrick Mahomes"],
  ["Which team had the only perfect season including the Super Bowl?","1972 Miami Dolphins","2007 New England Patriots","1985 Chicago Bears","1966 Green Bay Packers"],
  ["Who is the Super Bowl trophy named after?","Vince Lombardi","Pete Rozelle","George Halas","Paul Brown"],
  ["What does the Rooney Rule require?","Interviewing minority candidates for coaching jobs","A salary cap","Concussion tests","Playing abroad"]]},

{ t:"Football Strategy and Positions", s:"Chess with bodies",
  sec:[
  ["The offense",[
    "The quarterback receives the snap and runs the offense, handing off to running backs or passing to receivers. The offensive line (center, two guards, two tackles) blocks to protect the quarterback and open running lanes; the left tackle, protecting a right-handed quarterback's 'blind side,' is especially valued. Wide receivers run routes to catch passes; the tight end both blocks and catches.",
    "Running backs carry the ball on running plays and catch short passes; fullbacks, now rarer, mainly block."]],
  ["The defense",[
    "The defensive line (tackles and ends) tries to stop runs and pressure the quarterback; a tackle of the quarterback behind the line is a 'sack.' Linebackers stand behind the line, defending both run and pass. The secondary, cornerbacks and safeties, covers receivers and is the last line of defense; catching an opponent's pass is an 'interception.'",
    "Defenses are described by their front: a 4-3 has four linemen and three linebackers; a 3-4 has three linemen and four linebackers. Coverage schemes include man-to-man and zone defenses."]],
  ["Special teams",[
    "Special teams handle kicks: kickoffs, punts, field goals, and extra points, and the returns. Kickers and punters are specialists; return specialists can change games with long runs. The NFL changed kickoff rules in 2024 to a new 'dynamic kickoff' format to reduce high-speed collisions while keeping returns.",
    "A blocked kick or a fake punt can swing momentum dramatically."]],
  ["Offensive philosophies",[
    "Coaches build offenses around different ideas. The West Coast offense, developed by Bill Walsh with the San Francisco 49ers in the 1980s, used short, precise passes as an extension of the running game. The spread offense uses wide formations to stretch defenses; the run-pass option (RPO) lets the quarterback decide after the snap whether to hand off or pass.",
    "Play-action passing fakes a run before passing. The 'no-huddle' and hurry-up tempo pressure defenses. Analytics has encouraged teams to 'go for it' on fourth down more often and to pass more on early downs."]],
  ["Reading a play",[
    "Before the snap, watch the formation, motion, and defensive alignment; quarterbacks may change the play at the line ('audibles'). After the snap, watch the line battle, whether the quarterback has time, and how receivers' routes interact with coverage.",
    "Clock management is crucial at the end of halves: running plays keep the clock moving, while incomplete passes and running out of bounds stop it."]],
  ["The draft and team building",[
    "Teams build rosters through the draft, free agency, and trades under the salary cap. The quarterback is the most important and highest-paid position. The NFL Scouting Combine tests prospects' speed (the 40-yard dash), strength, and agility.",
    "Depth matters because injuries are frequent; the 53-player roster allows teams to replace injured starters."]]
  ],
  terms:[["Quarterback","Player who leads the offense and throws passes."],["Sack","Tackling the quarterback behind the line."],["Interception","Defender catching an opponent's pass."],["West Coast offense","Short-passing system developed by Bill Walsh."],["Audible","Changing the play at the line of scrimmage."]],
  w:"Understanding positions and schemes reveals the strategy hidden in every football play.",
  src:["American football positions","West Coast offense","Quarterback","Defensive back","Spread offense"],
  q:[
  ["Who protects a right-handed quarterback's blind side?","Left tackle","Center","Right guard","Tight end"],
  ["What is a sack?","Tackling the quarterback behind the line","Catching a pass","Blocking a kick","A fumble recovery"],
  ["Who developed the West Coast offense?","Bill Walsh","Vince Lombardi","Bill Belichick","Tom Landry"],
  ["What does a 4-3 defense have?","Four linemen and three linebackers","Four cornerbacks and three safeties","Four linebackers and three linemen","Four receivers and three backs"],
  ["What is an audible?","Changing the play at the line","A loud crowd","A penalty","A type of kick"],
  ["What does a play-action pass do?","Fakes a run before passing","Passes backward","Kicks the ball","Runs with the quarterback only"]]},

{ t:"College Sports in America", s:"Saturdays and March Madness",
  sec:[
  ["A unique system",[
    "In the United States, universities field teams that attract huge audiences, a system unlike almost anywhere else. The National Collegiate Athletic Association (NCAA), founded in 1906, governs most college sports, divided into Divisions I, II, and III. Division I football is further split into the Football Bowl Subdivision (FBS) and Football Championship Subdivision (FCS).",
    "College stadiums are among the largest in the world: Michigan Stadium ('The Big House') holds over 107,000 people."]],
  ["College football",[
    "College football has deep regional traditions, especially in the South and Midwest, with rivalries such as Michigan–Ohio State ('The Game'), Alabama–Auburn ('Iron Bowl'), and Army–Navy. Bowl games, such as the Rose Bowl (first played 1902, 'The Granddaddy of Them All'), end the season.",
    "The national champion was long chosen by polls, then by the Bowl Championship Series (1998–2013) and a four-team College Football Playoff (2014–2023), which expanded to 12 teams in 2024. The Heisman Trophy (since 1935) honors the season's best player."]],
  ["March Madness",[
    "The NCAA Division I men's basketball tournament, begun in 1939 and known as 'March Madness,' features 68 teams in a single-elimination bracket culminating in the Final Four. Millions of people fill out brackets predicting results; upsets by low-seeded 'Cinderella' teams are celebrated.",
    "UCLA under coach John Wooden won ten titles in twelve years (1964–75), a record. The women's tournament, begun in 1982, has grown enormously; UConn under Geno Auriemma has won a record number of titles, and stars such as Caitlin Clark of Iowa drew record audiences in 2023–24."]],
  ["Amateurism debates",[
    "For most of its history the NCAA insisted that college athletes be unpaid amateurs, even as coaches earned millions and TV deals brought in billions. Critics called this exploitation, particularly of Black athletes in revenue-generating sports.",
    "In NCAA v. Alston (2021), the US Supreme Court unanimously ruled against NCAA limits on education-related benefits, with Justice Brett Kavanaugh writing that the NCAA's business model would be flatly illegal in almost any other industry. The NCAA then allowed athletes to profit from their name, image, and likeness (NIL), and a 2025 legal settlement (House v. NCAA) allowed schools to share revenue directly with athletes."]],
  ["Conferences and change",[
    "Colleges compete in conferences such as the SEC, Big Ten, Big 12, and ACC. Driven by television money, conference realignment in the 2020s saw schools move across the country; the once-storied Pac-12 lost most of its members.",
    "The transfer portal lets athletes switch schools more easily. These rapid changes have made college sports resemble professional leagues more than ever, while debates continue about education, fairness, and the future of Olympic sports funded through college programs."]]
  ],
  terms:[["NCAA","National Collegiate Athletic Association."],["Bowl game","Postseason college football game."],["March Madness","NCAA basketball tournament."],["NIL","Name, image, and likeness rights."],["Heisman Trophy","Award for the best college football player."]],
  w:"College sports are central to American culture and are undergoing their biggest transformation in a century.",
  src:["National Collegiate Athletic Association","College football","NCAA Division I men's basketball tournament","NCAA v. Alston","Name, image and likeness"],
  q:[
  ["When was the NCAA founded?","1906","1869","1939","1921"],
  ["Which coach won ten NCAA titles with UCLA?","John Wooden","Mike Krzyzewski","Dean Smith","Bob Knight"],
  ["What is the oldest bowl game?","Rose Bowl","Sugar Bowl","Orange Bowl","Cotton Bowl"],
  ["What did NCAA v. Alston (2021) decide?","NCAA limits on education benefits violated antitrust law","College athletes must be amateurs","NCAA could ban NIL","Football playoffs were illegal"],
  ["What does NIL stand for?","Name, image, and likeness","National Intercollegiate League","No individual liability","New investment law"],
  ["How many teams entered the expanded College Football Playoff in 2024?","12","4","8","16"]]}

]});


/* ---- from sports-06.js ---- */
/* SPORTS FOUNDATIONS, part 6: Unit 3 chapters 5-8 (baseball and basketball) */
COURSES.sports.units[2].ch.push(

{ t:"Baseball: The Rules", s:"Nine innings, three outs",
  sec:[
  ["The field",[
    "Baseball is played on a diamond: four bases 90 feet (27.4 m) apart, with home plate at the bottom. The pitcher throws from a raised mound 60 feet 6 inches (18.4 m) from home plate, a distance fixed in 1893. Beyond the infield lies the outfield, bounded by foul lines and an outfield fence; stadiums vary in shape and dimensions, giving each park character, like Boston's tall left-field wall, the 'Green Monster.'",
    "Each team has nine players in the field: pitcher, catcher, first, second, and third basemen, shortstop, and left, center, and right fielders."]],
  ["Innings and outs",[
    "A game has nine innings. In each, both teams bat once (the visitors in the 'top,' the home team in the 'bottom') until the fielding team records three outs. There is no game clock; tied games continue into extra innings.",
    "Outs are made by a strikeout, catching a batted ball in the air (a fly out), throwing the ball to a base before the runner arrives (a force out or a throw to first), or tagging a runner who is off base. A 'double play' records two outs on one play."]],
  ["Balls and strikes",[
    "The batter faces pitches. A pitch in the strike zone (over home plate, roughly between the batter's knees and the midpoint of the torso) that the batter doesn't swing at, or any pitch swung at and missed, is a strike; a foul ball counts as a strike unless the batter already has two. Three strikes is a strikeout. Four pitches outside the zone not swung at ('balls') give the batter a walk to first base.",
    "The 'count' is given as balls–strikes, such as 3–2, a 'full count.' Hitting a pitch into fair territory makes the batter a runner."]],
  ["Scoring runs",[
    "A run scores when a runner touches all four bases in order and reaches home. Hits are classified by how far the batter gets: single, double, triple, or home run (usually hitting the ball over the outfield fence in fair territory). A home run with the bases loaded is a 'grand slam' (4 runs).",
    "Runners can steal bases by running while the pitcher throws. A sacrifice bunt or fly deliberately gives up an out to advance a runner."]],
  ["Pitching",[
    "Pitchers use a variety of pitches: the fastball (sometimes over 100 mph), curveball, slider, changeup, sinker, cutter, and knuckleball (thrown with little spin so it moves unpredictably). Starting pitchers typically pitch around five to seven innings, then relievers take over; the closer finishes close games, earning a 'save.'",
    "Pitch counts and injury prevention, especially of elbow injuries requiring 'Tommy John' ligament surgery, are major concerns."]],
  ["Recent rule changes",[
    "In 2023 Major League Baseball introduced a pitch clock (limiting time between pitches), limits on defensive shifts, and larger bases, shortening games by about 25 minutes and increasing stolen bases. The 'universal designated hitter' (a hitter who bats instead of the pitcher) was adopted in both leagues in 2022.",
    "An 'automatic runner' on second base begins each extra inning in the regular season. MLB announced an automated ball-strike challenge system for 2026."]]
  ],
  terms:[["Inning","Period in which each team bats until three outs."],["Strike zone","Area over the plate where pitches count as strikes."],["Home run","Hit allowing the batter to circle all bases."],["Designated hitter","Player who bats in place of the pitcher."],["Save","Credit for a reliever who protects a close lead."]],
  w:"Baseball's rhythm of pitch-by-pitch duels rewards patience and understanding of the count.",
  src:["Baseball","Baseball rules","Strike zone","Pitch clock","Designated hitter"],
  q:[
  ["How far apart are the bases in baseball?","90 feet","60 feet 6 inches","100 feet","75 feet"],
  ["How many outs does each team get per half-inning?","Three","Four","Two","Nine"],
  ["What is a walk?","Four balls, sending the batter to first","Three strikes","A stolen base","A bunt"],
  ["What is a grand slam?","A home run with the bases loaded","Four hits in a game","A triple play","A perfect game"],
  ["When did MLB introduce the pitch clock?","2023","2010","2020","1998"],
  ["What is the 'Green Monster'?","Fenway Park's tall left-field wall","A famous pitcher","A mascot","A type of pitch"]]},

{ t:"Baseball History and Legends", s:"America's pastime and the world game",
  sec:[
  ["Origins",[
    "Baseball developed from English bat-and-ball games such as rounders and cricket. The legend that Abner Doubleday invented it in Cooperstown, New York, in 1839 is a myth, though Cooperstown hosts the National Baseball Hall of Fame (1939). Alexander Cartwright and the New York Knickerbockers codified early rules in 1845.",
    "The Cincinnati Red Stockings became the first openly all-professional team in 1869; the National League was founded in 1876, and the American League in 1901. The first World Series was played in 1903."]],
  ["The early stars",[
    "Ty Cobb's fierce play and record batting average (.366 career) dominated the 'dead-ball era.' In 1919, members of the Chicago White Sox were accused of deliberately losing the World Series for gamblers; eight 'Black Sox' players were banned for life, and a commissioner, Kenesaw Mountain Landis, was appointed.",
    "Babe Ruth transformed the game with home runs, hitting 60 in 1927 for the New York Yankees, who became baseball's most successful franchise with a record 27 World Series titles. Lou Gehrig, the 'Iron Horse,' played 2,130 consecutive games before ALS ended his career; the disease is often called Lou Gehrig's disease."]],
  ["Integration",[
    "From the 1880s, Black players were excluded by an unwritten 'color line.' They played in the Negro Leagues, which produced great players such as Josh Gibson, Satchel Paige, and Oscar Charleston; in 2020 MLB officially recognized the Negro Leagues of 1920–48 as major leagues, adding their statistics to the record books.",
    "On 15 April 1947, Jackie Robinson broke the color line with the Brooklyn Dodgers, enduring abuse and winning Rookie of the Year. Every MLB player now wears his number 42 on 'Jackie Robinson Day.' Larry Doby integrated the American League months later."]],
  ["Postwar legends",[
    "Ted Williams was the last player to hit over .400 in a season (.406 in 1941); Joe DiMaggio hit safely in a record 56 consecutive games the same year. Willie Mays, Hank Aaron (who broke Ruth's career home run record in 1974 despite racist threats), Mickey Mantle, Sandy Koufax, Roberto Clemente (a Puerto Rican star and humanitarian who died in a 1972 plane crash delivering aid to Nicaragua), and Bob Gibson defined their eras.",
    "Later stars include Nolan Ryan (record 5,714 strikeouts and seven no-hitters), Cal Ripken Jr. (breaking Gehrig's streak with 2,632 consecutive games), and Rickey Henderson (stolen base record)."]],
  ["Steroids and the modern era",[
    "The late 1990s home run boom, when Mark McGwire and Sammy Sosa chased the single-season record, was later tainted by performance-enhancing drugs. Barry Bonds set the single-season (73 in 2001) and career (762) home run records amid steroid suspicions. MLB began testing with penalties in 2004, and the 2007 Mitchell Report named many players.",
    "Modern superstars include Mike Trout, Aaron Judge (62 home runs in 2022, an American League record), and Japan's Shohei Ohtani, a rare elite two-way player who both pitches and hits, and in 2024 became the first player with 50 home runs and 50 stolen bases in a season."]],
  ["Baseball worldwide",[
    "Baseball is hugely popular in Japan (Nippon Professional Baseball, and the summer high school tournament at Koshien Stadium), South Korea, Taiwan, Cuba, the Dominican Republic, Venezuela, Puerto Rico, and Mexico. The Dominican Republic produces more MLB players than any country outside the US.",
    "The World Baseball Classic (since 2006) is the sport's top international tournament; Japan has won it three times, including 2023, when Ohtani struck out his Angels teammate Mike Trout for the final out."]]
  ],
  terms:[["Color line","Unwritten ban on Black players in MLB."],["Negro Leagues","Professional leagues of Black players."],["World Series","MLB championship series, first played 1903."],["Black Sox","1919 White Sox players banned for fixing."],["Two-way player","Player who both pitches and hits."]],
  w:"Baseball's long history mirrors America's, from industrial cities to segregation, integration, and globalization.",
  src:["History of baseball","Jackie Robinson","Babe Ruth","Negro league baseball","Shohei Ohtani"],
  q:[
  ["Who broke MLB's color line in 1947?","Jackie Robinson","Larry Doby","Satchel Paige","Josh Gibson"],
  ["Which franchise has won a record 27 World Series?","New York Yankees","St. Louis Cardinals","Boston Red Sox","Los Angeles Dodgers"],
  ["Who was the last player to hit over .400 in a season?","Ted Williams","Ty Cobb","Tony Gwynn","Joe DiMaggio"],
  ["What scandal involved the 1919 White Sox?","Fixing the World Series","Steroids","Sign stealing","Corked bats"],
  ["Who holds the career home run record (762)?","Barry Bonds","Hank Aaron","Babe Ruth","Alex Rodriguez"],
  ["Which player recorded the first 50 home run, 50 stolen base season in 2024?","Shohei Ohtani","Aaron Judge","Mike Trout","Ronald Acuña Jr."]]},

{ t:"Basketball: The Rules and the Game", s:"Naismith's peach baskets",
  sec:[
  ["Invention",[
    "In December 1891, James Naismith, a Canadian physical education instructor at the YMCA training school in Springfield, Massachusetts, invented basketball as an indoor winter activity. He nailed peach baskets to the balcony, ten feet above the floor, and wrote 13 original rules. The first game ended 1–0. Open-bottomed nets replaced baskets around 1906.",
    "Basketball spread quickly through YMCAs, colleges, and abroad, and became an Olympic sport in 1936, where Naismith presented the medals."]],
  ["Basic rules",[
    "Two teams of five players try to shoot the ball through the opponent's hoop, 10 feet (3.05 m) high. Field goals count two points, or three points from beyond the three-point line (introduced in the NBA in 1979; the arc is 23 feet 9 inches at the top in the NBA, 6.75 m in international play). Free throws, awarded after certain fouls, count one point each.",
    "Players move the ball by dribbling (bouncing it) or passing; walking with the ball without dribbling is traveling, and dribbling with both hands or stopping and starting again is a double dribble."]],
  ["Time and fouls",[
    "NBA games have four 12-minute quarters; FIBA (international) and WNBA games use 10-minute quarters. The shot clock, introduced in the NBA in 1954 at 24 seconds, forces a team to shoot within that time; it saved the league from slow, stalling games.",
    "Personal fouls for illegal contact lead to free throws or possession; a player who commits six fouls in an NBA game (five in FIBA) 'fouls out.' Team fouls beyond a limit per quarter give the opponent free throws ('the bonus')."]],
  ["Positions",[
    "Traditional positions are point guard (ball-handler and playmaker), shooting guard, small forward, power forward, and center (the tallest player, near the basket). Modern basketball is increasingly 'positionless,' with players expected to handle, pass, and shoot.",
    "Key skills include shooting, dribbling, passing, rebounding (retrieving missed shots), defense, and blocking shots."]],
  ["Plays and tactics",[
    "The pick-and-roll, where a player sets a screen (pick) for the ball-handler and then rolls toward the basket, is the most common play in modern basketball. Other tactics include isolation plays, the triangle offense (used by Phil Jackson's Bulls and Lakers), motion offenses, and fast breaks.",
    "Defenses play man-to-man or zone (guarding areas); the NBA allowed zone defenses from 2001 with a 'defensive three seconds' rule. The analytics movement has pushed teams toward three-point shots and shots near the rim, the most efficient options."]],
  ["3x3 and variations",[
    "3x3 basketball, played on a half court with one basket and a 12-second shot clock, became an Olympic event in 2021. Wheelchair basketball is a major Paralympic sport. Netball, a related game without dribbling and with a basket without a backboard, is popular among women in Commonwealth countries.",
    "Streetball culture, with famous courts such as Rucker Park in Harlem, has influenced style and fashion."]]
  ],
  terms:[["Three-pointer","Shot from beyond the arc worth three points."],["Shot clock","Time limit to attempt a shot."],["Pick-and-roll","Screen followed by a cut to the basket."],["Traveling","Moving with the ball without dribbling."],["Rebound","Gaining possession after a missed shot."]],
  w:"Basketball, invented in a single winter, became one of the world's most played sports thanks to its simple rules and space for creativity.",
  src:["Basketball","James Naismith","Shot clock","Pick and roll","3x3 basketball"],
  q:[
  ["Where did James Naismith invent basketball?","Springfield, Massachusetts","Toronto","New York City","Chicago"],
  ["How high is a basketball hoop?","10 feet (3.05 m)","9 feet","11 feet","12 feet"],
  ["When did the NBA introduce the three-point line?","1979","1954","1946","1991"],
  ["How long is the NBA shot clock?","24 seconds","30 seconds","35 seconds","20 seconds"],
  ["How many fouls cause an NBA player to foul out?","Six","Five","Four","Seven"],
  ["What is a pick-and-roll?","A screen followed by a cut to the basket","A type of free throw","A dunk","A zone defense"]]},

{ t:"The NBA and Basketball Legends", s:"From Mikan to the global game",
  sec:[
  ["Early pro basketball",[
    "The Basketball Association of America was founded in 1946 and merged with the National Basketball League in 1949 to form the National Basketball Association (NBA). George Mikan, a dominant center for the Minneapolis Lakers, was its first star. Barnstorming teams such as the Harlem Globetrotters (founded 1926), known for comedy and skill, and the New York Renaissance ('Rens') were also important.",
    "The NBA's first Black players joined in 1950: Earl Lloyd, Chuck Cooper, and Nat 'Sweetwater' Clifton."]],
  ["Russell, Chamberlain, and the Celtics",[
    "Bill Russell, a defensive genius, led the Boston Celtics, coached by Red Auerbach, to eleven championships in thirteen seasons (1957–69); he also became the first Black head coach in a major US professional league in 1966 and was a civil rights activist. Wilt Chamberlain was a scoring phenomenon: he scored 100 points in a single game in 1962 and averaged 50.4 points per game that season.",
    "Oscar Robertson averaged a triple-double (double figures in points, rebounds, and assists) over a season in 1961–62. Kareem Abdul-Jabbar, with his 'skyhook,' set the NBA career scoring record in 1984, which stood until LeBron James passed it in 2023."]],
  ["Magic, Bird, and Jordan",[
    "In the 1980s, the rivalry between Magic Johnson's 'Showtime' Los Angeles Lakers and Larry Bird's Boston Celtics revived the NBA. Michael Jordan of the Chicago Bulls then became the most famous athlete in the world, winning six championships in two 'three-peats' (1991–93, 1996–98), five MVP awards, and six Finals MVPs.",
    "Jordan's athleticism, competitiveness, and his Nike 'Air Jordan' shoes made him a global cultural icon, celebrated in the 2020 documentary The Last Dance."]],
  ["The modern era",[
    "Tim Duncan's San Antonio Spurs won five titles with a team-first style; Shaquille O'Neal and Kobe Bryant led the Lakers to three straight titles (2000–02); Bryant (who died in a 2020 helicopter crash) won five titles in total. LeBron James, a dominant all-around player, won four titles with three teams and became the NBA's all-time leading scorer.",
    "Stephen Curry's Golden State Warriors (four titles, 2015–22) revolutionized basketball with long-range three-point shooting. International stars such as Dirk Nowitzki (Germany), Giannis Antetokounmpo (Greece), Nikola Jokić (Serbia), Luka Dončić (Slovenia), and Victor Wembanyama (France) have become MVPs or franchise players."]],
  ["The WNBA and women's basketball",[
    "The Women's National Basketball Association (WNBA) launched in 1997. Stars include Lisa Leslie, Sheryl Swoopes, Diana Taurasi (the league's all-time leading scorer), Sue Bird, Candace Parker, Maya Moore, and A'ja Wilson. The arrival of Caitlin Clark and Angel Reese in 2024 brought record viewership and attendance.",
    "The US women's national team has won a record eight consecutive Olympic gold medals (1996–2024)."]],
  ["Global basketball",[
    "FIBA, founded in 1932, governs international basketball. The 1992 US 'Dream Team' of NBA stars, including Jordan, Magic, and Bird, inspired a generation worldwide. Since then, other nations have challenged US dominance: Argentina won Olympic gold in 2004; Spain won World Cups in 2006 and 2019; Germany won the 2023 World Cup.",
    "Europe's EuroLeague and leagues in Spain, Turkey, Greece, and Serbia are strong; basketball is hugely popular in China, the Philippines, Lithuania, and increasingly Africa, where the NBA launched the Basketball Africa League in 2021."]]
  ],
  terms:[["Triple-double","Double figures in three statistical categories."],["Three-peat","Three consecutive championships."],["MVP","Most Valuable Player award."],["WNBA","Women's National Basketball Association, founded 1997."],["FIBA","International Basketball Federation."]],
  w:"The NBA turned basketball into a global culture, and its legends are among the most famous athletes in the world.",
  src:["National Basketball Association","Bill Russell","Michael Jordan","LeBron James","Women's National Basketball Association"],
  q:[
  ["Who scored 100 points in a single NBA game in 1962?","Wilt Chamberlain","Bill Russell","Kareem Abdul-Jabbar","Elgin Baylor"],
  ["How many championships did Bill Russell win with the Celtics?","Eleven","Six","Eight","Five"],
  ["Who passed Kareem Abdul-Jabbar as the NBA's career scoring leader in 2023?","LeBron James","Kobe Bryant","Karl Malone","Michael Jordan"],
  ["How many NBA titles did Michael Jordan win?","Six","Five","Four","Eight"],
  ["Which team revolutionized basketball with three-point shooting from 2015?","Golden State Warriors","Houston Rockets","Miami Heat","San Antonio Spurs"],
  ["Who is the WNBA's all-time leading scorer?","Diana Taurasi","Lisa Leslie","Sue Bird","Tamika Catchings"]]}

);


/* ---- from sports-07.js ---- */
/* SPORTS FOUNDATIONS, part 7: Unit 3 chapters 9-10 (ice hockey) */
COURSES.sports.units[2].ch.push(

{ t:"Ice Hockey: The Rules", s:"Speed on ice",
  sec:[
  ["Origins",[
    "Ice hockey grew from stick-and-ball games such as shinny, hurling, and bandy, played on frozen ponds. The first recorded indoor game was played at the Victoria Skating Rink in Montreal on 3 March 1875, organized by James Creighton, using a flat wooden puck instead of a ball. McGill University students wrote early rules.",
    "The Stanley Cup, donated in 1892 by Lord Stanley of Preston, Canada's Governor General, is the oldest trophy competed for by professional athletes in North America."]],
  ["The rink and players",[
    "The NHL rink is 200 by 85 feet (about 61 by 26 m) with rounded corners and boards topped by glass. Each team has six players on the ice: a goaltender, two defensemen, and three forwards (a center and two wingers). Players change 'on the fly' while play continues; shifts typically last 40 to 60 seconds because of the intense pace.",
    "The vulcanized rubber puck is 3 inches (7.6 cm) in diameter and is often frozen before games to reduce bouncing. Shots can exceed 100 mph (160 km/h)."]],
  ["Game structure",[
    "An NHL game has three 20-minute periods. Tied regular-season games go to five minutes of three-on-three overtime, then a shootout; playoff games continue with full sudden-death overtime periods until someone scores, sometimes lasting several extra periods.",
    "The rink is divided by a center red line and two blue lines into defensive, neutral, and attacking zones."]],
  ["Offside and icing",[
    "Offside occurs when an attacking player enters the attacking zone (crosses the blue line) before the puck. Icing occurs when a player shoots the puck from behind the center red line across the opponent's goal line without it being touched; play stops and the faceoff returns to the offending team's defensive zone (unless the team is shorthanded).",
    "Faceoffs, where the referee drops the puck between two opposing centers, restart play."]],
  ["Penalties",[
    "Penalized players go to the penalty box, leaving their team shorthanded and giving the opponent a 'power play.' Minor penalties (2 minutes) include tripping, hooking, slashing, holding, and high-sticking; major penalties (5 minutes) are for more serious offenses including fighting.",
    "Fighting, though penalized, has long been tolerated in North American professional hockey, unlike in international and Olympic play, where it brings ejection; its frequency has declined greatly in recent years. Body checking (hitting an opponent with the hip or shoulder) is legal for men's professional play but not in women's hockey."]],
  ["Skills and tactics",[
    "Key skills include skating, stickhandling, passing, shooting (wrist shot, slap shot, snapshot, backhand), checking, and goaltending, which demands extraordinary reflexes; the 'butterfly' style, dropping to the knees to cover the bottom of the net, became dominant.",
    "Teams use systems such as the forecheck (pressuring opponents in their zone) and the neutral-zone trap (clogging the middle of the ice, made famous by the 1990s New Jersey Devils). Teams may pull the goaltender for an extra attacker late in games when trailing."]]
  ],
  terms:[["Stanley Cup","NHL championship trophy, donated 1892."],["Power play","Playing with more skaters due to an opponent's penalty."],["Icing","Shooting the puck the length of the ice untouched."],["Faceoff","Puck drop to restart play."],["Hat trick","Three goals by one player."]],
  w:"Hockey is the fastest team sport on foot, and its rules on offside and icing shape every rush up the ice.",
  src:["Ice hockey","Stanley Cup","Icing (ice hockey)","Offside (ice hockey)","Penalty (ice hockey)"],
  q:[
  ["Where was the first recorded indoor ice hockey game played in 1875?","Montreal","Toronto","Boston","Ottawa"],
  ["How many skaters, including the goalie, does each team have on the ice?","Six","Five","Seven","Eleven"],
  ["How long is a minor penalty?","2 minutes","5 minutes","10 minutes","1 minute"],
  ["What is icing?","Shooting the puck from behind center across the opponent's goal line untouched","Freezing the puck","A fight","Entering the zone before the puck"],
  ["Who donated the Stanley Cup?","Lord Stanley of Preston","James Creighton","Wayne Gretzky","Queen Victoria"],
  ["How many periods are in an NHL game?","Three","Four","Two","Five"]]},

{ t:"The NHL and World Hockey", s:"From the Original Six to Olympic gold",
  sec:[
  ["The NHL",[
    "The National Hockey League was founded in 1917 in Montreal. From 1942 to 1967, it consisted of the 'Original Six': the Montreal Canadiens, Toronto Maple Leafs, Boston Bruins, Chicago Black Hawks, Detroit Red Wings, and New York Rangers. Expansion in 1967 doubled the league, and today it has 32 teams across Canada and the United States.",
    "The Montreal Canadiens have won the Stanley Cup a record 24 times, including five straight (1956–60). The New York Islanders won four straight (1980–83), and the Edmonton Oilers five in seven years (1984–90)."]],
  ["Legends",[
    "Maurice 'Rocket' Richard became the first player to score 50 goals in 50 games (1944–45); his 1955 suspension sparked the Richard Riot in Montreal, linked to French Canadian identity. Gordie Howe, 'Mr. Hockey,' played professionally across five decades. Bobby Orr revolutionized defense with his rushing offense and his famous flying goal in 1970.",
    "Wayne Gretzky, 'The Great One,' holds dozens of records, including 894 regular-season goals (broken by Alexander Ovechkin in 2025) and 1,963 assists, more assists than any other player has total points. His 1988 trade from Edmonton to Los Angeles helped popularize hockey in the US Sun Belt. Mario Lemieux, Sidney Crosby, and Connor McDavid are also among the greatest."]],
  ["International hockey",[
    "The International Ice Hockey Federation (IIHF), founded in 1908, runs world championships. The Soviet Union dominated international hockey from the 1950s to 1990, with a style based on passing and puck control, winning seven Olympic golds.",
    "The 1972 Summit Series between Canada and the USSR, won by Canada with Paul Henderson's last-minute goal in Game 8, was a Cold War sporting epic. At the 1980 Lake Placid Olympics, a team of US college players beat the mighty Soviets in the 'Miracle on Ice' and went on to win gold."]],
  ["The hockey nations",[
    "Canada is the spiritual home of hockey, with many Olympic and world titles. Other leading hockey nations include the United States, Russia, Sweden, Finland, the Czech Republic (whose 1998 Olympic gold was led by goalie Dominik Hašek), Slovakia, Switzerland, and Germany. NHL players took part in the Olympics from 1998 to 2014 and returned for the 2026 Milan–Cortina Games.",
    "The Kontinental Hockey League (KHL), founded in 2008, is based in Russia; Sweden's SHL and Finland's Liiga are strong European leagues."]],
  ["Women's hockey",[
    "Women's hockey became an Olympic event in 1998, when the United States won gold. Canada and the US have dominated, meeting in nearly every Olympic final; Canada's Hayley Wickenheiser and Marie-Philip Poulin are legends.",
    "The Professional Women's Hockey League (PWHL) launched in 2024 with teams in Canada and the US, drawing record crowds."]],
  ["Hockey culture",[
    "Hockey is central to Canadian identity, from backyard rinks to 'Hockey Night in Canada' broadcasts since the 1930s on radio and 1952 on TV. Traditions include the playoff beard, players not touching the conference trophy, and the Stanley Cup's custom of each winning player spending a day with the Cup.",
    "Hockey also faces issues of cost, safety (concussions), and inclusivity, prompting efforts to diversify the sport."]]
  ],
  terms:[["Original Six","The NHL's six teams from 1942 to 1967."],["Miracle on Ice","1980 US Olympic win over the USSR."],["Summit Series","1972 Canada vs USSR series."],["IIHF","International Ice Hockey Federation."],["PWHL","Professional Women's Hockey League, launched 2024."]],
  w:"Hockey's history connects Canadian identity, Cold War rivalry, and some of sport's greatest individual records.",
  src:["National Hockey League","Wayne Gretzky","Miracle on Ice","Summit Series","Professional Women's Hockey League"],
  q:[
  ["Which team has won the Stanley Cup a record 24 times?","Montreal Canadiens","Toronto Maple Leafs","Detroit Red Wings","Edmonton Oilers"],
  ["Who is known as 'The Great One'?","Wayne Gretzky","Gordie Howe","Mario Lemieux","Bobby Orr"],
  ["What was the 'Miracle on Ice'?","US college players beating the Soviets at the 1980 Olympics","Canada's win in the Summit Series","A Stanley Cup comeback","Gretzky's 92-goal season"],
  ["Who broke Gretzky's career goals record in 2025?","Alexander Ovechkin","Sidney Crosby","Jaromír Jágr","Connor McDavid"],
  ["When did women's hockey become an Olympic event?","1998","1980","2006","1972"],
  ["Which teams made up part of the 'Original Six'?","Montreal, Toronto, Boston, Chicago, Detroit, New York Rangers","Montreal, Toronto, Ottawa, Quebec, Winnipeg, Calgary","Boston, Philadelphia, Pittsburgh, Detroit, Chicago, St. Louis","Montreal, Toronto, Boston, Chicago, Detroit, Philadelphia"]]}

);


/* ---- from sports-08.js ---- */
/* SPORTS FOUNDATIONS, part 8: Unit 4 Cricket and Rugby, chapters 1-5 */
COURSES.sports.units.push({ t:"Cricket, Rugby, and Other Codes", ch:[

{ t:"Cricket: The Basics", s:"Bat, ball, and wickets",
  sec:[
  ["The field and teams",[
    "Cricket is played between two teams of eleven on a large oval field. At the center is the pitch, a strip 22 yards (20.12 m) long, with a wicket at each end: three wooden stumps topped by two bails. One team bats while the other bowls and fields; then they swap. Each turn at batting is an innings.",
    "The laws of cricket are maintained by the Marylebone Cricket Club (MCC) at Lord's in London, known as the 'Home of Cricket,' while the International Cricket Council (ICC) runs the international game."]],
  ["Bowling and batting",[
    "A bowler delivers the ball overarm with a straight arm (throwing is illegal) from one end, usually bouncing it on the pitch, trying to hit the stumps or induce a mistake. Six legal deliveries make an over; then another bowler bowls from the other end. Two batters are on the field at once, one at each end.",
    "The batter defends the wicket and tries to score runs by hitting the ball and running between the wickets, swapping ends; each completed run scores one. Hitting the ball to the boundary along the ground scores four; over the boundary without bouncing scores six."]],
  ["Getting out",[
    "A batter is dismissed ('out') in several ways: bowled (the ball hits the stumps and dislodges a bail), caught (a fielder catches a hit ball before it bounces), leg before wicket or LBW (the ball would have hit the stumps but was blocked by the batter's body), run out (the wicket is broken while batters are running and haven't reached their ground), stumped (the wicketkeeper breaks the wicket while the batter is out of the crease), and rarer methods such as hit wicket.",
    "An innings ends when ten batters are out (the last remains 'not out'), or when overs run out in limited-overs cricket, or when the captain 'declares.'"]],
  ["Types of bowling",[
    "Fast bowlers (pace bowlers) rely on speed, sometimes over 150 km/h (93 mph), plus swing (curving through the air) and seam movement (deviating off the pitch). Spin bowlers bowl slowly with spin to make the ball turn sharply after bouncing: off-spin, leg-spin (wrist spin), and variations such as the googly, a leg-spinner's delivery that turns the other way.",
    "Extras (runs not scored off the bat) include wides, no-balls (illegal deliveries), byes, and leg byes."]],
  ["Fielding positions and captaincy",[
    "Fielding positions have colorful names: slips (beside the wicketkeeper), gully, point, cover, mid-off, mid-on, square leg, fine leg, third man, and silly point (very close to the batter). The captain sets the field, chooses bowlers, and decides whether to bat or bowl first after the coin toss.",
    "Umpires (two on the field, plus a third using video replays) adjudicate; fielders appeal by shouting 'Howzat?'"]],
  ["Reading a scorecard",[
    "Scores are written as runs for wickets, such as 245/6 (or 6/245 in Australia), meaning 245 runs with six batters out. A batter scoring 100 runs makes a 'century'; 50 is a half-century; zero is a 'duck.' A bowler taking five wickets in an innings achieves a 'five-for.'",
    "Batting average (runs per dismissal) and bowling average (runs conceded per wicket) are key statistics."]]
  ],
  terms:[["Wicket","Three stumps and two bails; also a dismissal."],["Over","Six legal deliveries."],["LBW","Leg before wicket dismissal."],["Century","100 runs by one batter."],["Googly","Leg-spinner's ball that turns the opposite way."]],
  w:"Cricket is the second most-followed sport in the world, and its laws reward patience and strategy.",
  src:["Cricket","Laws of Cricket","Leg before wicket","Over (cricket)","Spin bowling"],
  q:[
  ["How long is a cricket pitch?","22 yards","20 meters exactly","30 yards","18 yards"],
  ["How many deliveries are in an over?","Six","Five","Eight","Four"],
  ["How many runs is a hit over the boundary without bouncing?","Six","Four","Five","Eight"],
  ["What is LBW?","Leg before wicket, when the body blocks a ball that would hit the stumps","A type of no-ball","A run out","A spin delivery"],
  ["Who maintains the Laws of Cricket?","Marylebone Cricket Club (MCC)","ICC","England and Wales Cricket Board","BCCI"],
  ["What is a 'duck'?","A score of zero","100 runs","Five wickets","A fielding position"]]},

{ t:"Cricket's Formats, History, and Legends", s:"From village greens to the IPL",
  sec:[
  ["History",[
    "Cricket emerged in southeast England by the 16th century and became popular among both aristocrats and villagers in the 18th century. The first international match was played in 1844 between the United States and Canada. The first Test match, England vs Australia, was played in Melbourne in 1877.",
    "In 1882, after Australia beat England at The Oval, a mock obituary declared English cricket dead and its body cremated, and 'the ashes' taken to Australia. The tiny urn known as the Ashes has been the prize of England–Australia Test series ever since."]],
  ["Formats",[
    "Test cricket, the oldest and most prestigious format, lasts up to five days, with each team batting twice; many Tests end in draws. One Day Internationals (ODIs, from 1971) give each side 50 overs. Twenty20 (T20), introduced in England in 2003, gives each side 20 overs, with games lasting about three hours.",
    "The ICC organizes the Cricket World Cup (ODI, since 1975), the T20 World Cup (since 2007), and the World Test Championship (since 2019–21). Cricket returns to the Olympics at Los Angeles 2028 in T20 format."]],
  ["Cricket and empire",[
    "Cricket spread throughout the British Empire, becoming a passion in India, Pakistan, Sri Lanka, Bangladesh, the West Indies, South Africa, New Zealand, and Australia. It became a vehicle for anticolonial pride: West Indian writer C. L. R. James's Beyond a Boundary (1963) explored cricket, race, and colonialism.",
    "The West Indies dominated in the 1970s and 80s with fearsome fast bowlers and batters such as Viv Richards, winning the first two World Cups (1975, 1979). South Africa was banned from international cricket from 1970 to 1991 because of apartheid."]],
  ["South Asia and the IPL",[
    "India's 1983 World Cup win under Kapil Dev ignited cricket mania; today India has the largest cricket audience in the world and the Board of Control for Cricket in India (BCCI) is the sport's financial powerhouse. India–Pakistan matches are among the most-watched sporting events anywhere.",
    "The Indian Premier League (IPL), launched in 2008, is a franchise T20 league with player auctions and enormous TV deals; its media rights for 2023–27 sold for over $6 billion, making it one of the most valuable sports leagues in the world per match."]],
  ["Legends",[
    "Australia's Don Bradman has the highest Test batting average ever, 99.94, a statistical outlier unmatched in major sport. W. G. Grace dominated Victorian cricket. Sachin Tendulkar of India scored 100 international centuries and the most Test and ODI runs. Garfield Sobers was perhaps the greatest all-rounder.",
    "Great bowlers include Shane Warne (leg-spin, his 1993 'Ball of the Century'), Muttiah Muralitharan (most Test wickets, 800), James Anderson (most Test wickets by a fast bowler), Wasim Akram, and Glenn McGrath. Modern stars include Virat Kohli, Joe Root, Steve Smith, Ben Stokes, and Jasprit Bumrah."]],
  ["Women's cricket",[
    "The first Women's Cricket World Cup was held in 1973, two years before the men's. Australia has dominated, winning many titles. The Women's Premier League in India (2023) and England's The Hundred have expanded professional opportunities. Stars include Ellyse Perry, Mithali Raj, Meg Lanning, and Smriti Mandhana.",
    "Cricket's 'spirit of the game' and traditions, tea breaks, whites in Test cricket, and the cricket tea, remain part of its appeal."]]
  ],
  terms:[["Test cricket","Multi-day international format, up to five days."],["ODI","One Day International, 50 overs per side."],["T20","Twenty overs per side."],["The Ashes","England–Australia Test series trophy."],["IPL","Indian Premier League, founded 2008."]],
  w:"Cricket's formats and history connect empire, independence, and the modern sports economy of South Asia.",
  src:["Test cricket","The Ashes","Indian Premier League","Don Bradman","Sachin Tendulkar"],
  q:[
  ["Where was the first Test match played in 1877?","Melbourne","Lord's","The Oval","Sydney"],
  ["What is Don Bradman's Test batting average?","99.94","89.78","60.97","104.5"],
  ["When was the IPL launched?","2008","2003","1999","2013"],
  ["Who has the most Test wickets?","Muttiah Muralitharan","Shane Warne","James Anderson","Anil Kumble"],
  ["Which team won the first two Cricket World Cups?","West Indies","Australia","England","India"],
  ["When was the first Women's Cricket World Cup held?","1973","1975","1983","1993"]]},

{ t:"Rugby Union", s:"The game played in heaven",
  sec:[
  ["Origins",[
    "According to legend, in 1823 William Webb Ellis, a pupil at Rugby School, 'with a fine disregard for the rules of football as played in his time, first took the ball in his arms and ran with it.' Historians doubt the story, but the Rugby World Cup trophy is named after him. The Rugby Football Union (RFU) was formed in 1871.",
    "Rugby union remained officially amateur until 1995, when it turned professional immediately after that year's World Cup."]],
  ["The basics",[
    "Rugby union is played by two teams of 15 players for 80 minutes (two 40-minute halves). The ball may be carried, kicked, or passed, but passes must go sideways or backward; a forward pass or 'knock-on' (losing the ball forward) gives the opponents a scrum.",
    "A try (5 points) is scored by grounding the ball in the opponent's in-goal area; a conversion kick adds 2. Penalty kicks and drop goals (kicked during open play after a bounce) are worth 3. A penalty try (7 points) is awarded if foul play prevented a probable try."]],
  ["Set pieces and breakdowns",[
    "A scrum restarts play after minor infringements: eight forwards from each side bind together and push, while the scrum-half feeds the ball into the tunnel. A lineout restarts play after the ball goes into touch: forwards line up and teammates lift a jumper to catch the thrown ball.",
    "When a player is tackled, a ruck forms as players contest the ball on the ground; a maul is a similar contest while the ball-carrier stays on his feet. These breakdowns are complex and much of the refereeing focuses on them."]],
  ["Positions",[
    "The eight forwards (numbers 1–8: props, hooker, locks, flankers, and number eight) are bigger and win possession. The seven backs (9–15: scrum-half, fly-half, centers, wings, and fullback) are faster and use space. The fly-half (number 10) is usually the chief playmaker and kicker.",
    "Rugby is a collision sport; concerns about concussion have led to stricter tackle-height laws and head injury assessments (HIA)."]],
  ["International rugby",[
    "The Rugby World Cup began in 1987. New Zealand and South Africa have each won it a record four times (South Africa in 1995, 2007, 2019, 2023); Australia twice and England once (2003, with Jonny Wilkinson's drop goal in extra time). South Africa's 1995 win, with President Nelson Mandela wearing captain François Pienaar's jersey, became a symbol of post-apartheid reconciliation, depicted in the film Invictus.",
    "The Six Nations Championship (England, France, Ireland, Italy, Scotland, Wales) is the oldest international rugby tournament (from 1883 as the Home Nations); the Rugby Championship involves New Zealand, South Africa, Australia, and Argentina. The British and Irish Lions tour every four years."]],
  ["Rugby culture",[
    "New Zealand's All Blacks perform the haka before matches and have the highest winning percentage of any major international team. Rugby is especially strong in New Zealand, South Africa, Wales, Ireland, France, the Pacific islands (Fiji, Samoa, Tonga), Argentina, Japan (which hosted the 2019 World Cup), and parts of England and Scotland.",
    "Rugby sevens, with seven players and seven-minute halves, is fast and open; it joined the Olympics in 2016, where Fiji won the nation's first-ever Olympic medal, a gold. Women's rugby is growing rapidly; the 2025 Women's Rugby World Cup in England drew record crowds and England won the title."]]
  ],
  terms:[["Try","Five points for grounding the ball in-goal."],["Scrum","Set piece where forwards bind and push."],["Lineout","Restart where players are lifted to catch a throw."],["Ruck","Contest for the ball on the ground after a tackle."],["Knock-on","Losing the ball forward."]],
  w:"Rugby union's mix of power and skill makes it a global sport with powerful national meanings.",
  src:["Rugby union","William Webb Ellis","Rugby World Cup","Six Nations Championship","Scrum (rugby union)"],
  q:[
  ["How many points is a try in rugby union?","5","4","3","6"],
  ["Which nations have each won the Rugby World Cup four times?","New Zealand and South Africa","Australia and England","France and Wales","Ireland and Argentina"],
  ["In which direction must passes go in rugby?","Sideways or backward","Forward only","Any direction","Forward from the scrum only"],
  ["When did rugby union turn professional?","1995","1871","1987","2003"],
  ["Which nation won its first Olympic medal in rugby sevens in 2016?","Fiji","Samoa","Tonga","Kenya"],
  ["Which teams compete in the Six Nations?","England, France, Ireland, Italy, Scotland, Wales","England, France, Spain, Italy, Scotland, Wales","England, Ireland, Scotland, Wales, Argentina, Italy","England, France, Ireland, Scotland, Wales, Georgia"]]},

{ t:"Rugby League and Other Football Codes", s:"Aussie rules, Gaelic games, and more",
  sec:[
  ["Rugby league",[
    "Rugby league began in 1895 when 22 northern English clubs broke from the Rugby Football Union over 'broken time' payments to working-class players, forming the Northern Union. Over time it changed its rules to speed up the game: 13 players per side instead of 15, no lineouts, and simplified rucks.",
    "The tackled team retains possession for six tackles (the 'six-tackle rule'), then must hand over the ball, usually after a kick. A try is worth 4 points, a conversion 2, a penalty goal 2, and a drop goal 1. Rugby league is strongest in northern England, eastern Australia (New South Wales and Queensland), New Zealand, Papua New Guinea (its national sport), and southern France."]],
  ["State of Origin",[
    "Australia's National Rugby League (NRL) is the sport's top competition. The annual State of Origin series between Queensland and New South Wales, where players represent the state of their origin, is one of Australia's most intense sporting events.",
    "The Rugby League World Cup began in 1954; Australia has won it most often."]],
  ["Australian rules football",[
    "Australian rules football ('footy' or 'Aussie rules') was codified in Melbourne in 1859, possibly making it the oldest of the major modern football codes. It is played on an oval cricket ground by teams of 18, with four goalposts at each end: kicking the ball between the two tall central posts scores a goal (6 points); between a goal post and a shorter behind post scores a 'behind' (1 point).",
    "Players move the ball by kicking or 'handballing' (punching it off one hand); a clean catch of a kick traveling 15 meters, a 'mark,' earns a free kick. Spectacular high marks are celebrated. The Australian Football League (AFL) grand final at the Melbourne Cricket Ground draws about 100,000 spectators. The AFL Women's league started in 2017."]],
  ["Gaelic games",[
    "Gaelic football and hurling are Ireland's national sports, governed by the Gaelic Athletic Association (GAA), founded in 1884 as part of the Irish cultural revival. All players are amateurs representing their local parish club and county. The All-Ireland finals at Croke Park in Dublin are major national events.",
    "Gaelic football combines elements of soccer and rugby: 15 players, a round ball that can be kicked or hand-passed; goals under the crossbar score 3 points, and over the bar 1 point. Hurling, one of the world's oldest field games (its roots are said to reach back thousands of years), uses a wooden stick (hurley) and a small ball (sliotar) and is among the fastest field sports; camogie is the women's version. On Bloody Sunday in 1920, British forces opened fire at a Gaelic football match at Croke Park, killing 14 people."]],
  ["Other codes",[
    "Other football codes include Canadian football, touch rugby, and futsal. International Rules football is a hybrid played between Ireland and Australia.",
    "These codes share a common 19th-century ancestry in British school games but evolved distinct identities rooted in place and community."]]
  ],
  terms:[["Six-tackle rule","Rugby league possession limit."],["State of Origin","Queensland vs New South Wales rugby league series."],["Mark","Clean catch in Aussie rules earning a free kick."],["GAA","Gaelic Athletic Association, founded 1884."],["Hurling","Ancient Irish stick-and-ball sport."]],
  w:"The football codes show how one family of games evolved into distinct national passions.",
  src:["Rugby league","State of Origin series","Australian rules football","Gaelic Athletic Association","Hurling"],
  q:[
  ["How many players per side in rugby league?","13","15","11","18"],
  ["How many points is a goal in Australian rules football?","6","3","5","1"],
  ["When was the GAA founded?","1884","1859","1895","1922"],
  ["Which country has rugby league as its national sport?","Papua New Guinea","Fiji","Samoa","Tonga"],
  ["What is the women's version of hurling called?","Camogie","Shinty","Lacrosse","Netball"],
  ["Where was Australian rules football codified in 1859?","Melbourne","Sydney","Adelaide","Brisbane"]]}

]});


/* ---- from sports-09.js ---- */
/* SPORTS FOUNDATIONS, part 9: Unit 5 Racket, Net, and Target Sports, chapters 1-4 */
COURSES.sports.units.push({ t:"Racket, Net, and Target Sports", ch:[

{ t:"Tennis: Rules and Scoring", s:"Love, deuce, and tiebreaks",
  sec:[
  ["Origins",[
    "Lawn tennis was popularized in 1874 by Major Walter Clopton Wingfield, who patented a game called 'sphairistikè,' adapted from real tennis for outdoor lawns. The All England Croquet Club added tennis and held the first Wimbledon Championships in 1877, establishing rules close to today's.",
    "Tennis is played as singles (one against one) or doubles (two against two), on a rectangular court divided by a net 3 feet (0.914 m) high at the center."]],
  ["Scoring",[
    "Tennis has an unusual scoring system. Points in a game go 0 ('love'), 15, 30, 40, then game. At 40–40 ('deuce'), a player must win two consecutive points: the first gives 'advantage.' The origins of 15–30–40 are uncertain; one theory links them to a clock face, with 45 shortened to 40.",
    "Games make up sets: the first to six games, with a margin of two, wins the set. At 6–6, most sets go to a tiebreak, first to seven points by two. Matches are best of three sets, or best of five in men's Grand Slam singles. Since 2022, all four Grand Slams use a 10-point tiebreak at 6–6 in the deciding set."]],
  ["Serving",[
    "Each point starts with a serve, hit from behind the baseline diagonally into the opponent's service box. A player gets two attempts; missing both is a 'double fault.' A serve that touches the net but lands in is a 'let' and is replayed. An unreturned serve is an 'ace.'",
    "Players alternate serving games. Holding serve (winning your own service game) is expected at the top level; winning the opponent's is a 'break,' often deciding sets."]],
  ["Strokes and styles",[
    "Main strokes include the forehand, backhand (one- or two-handed), volley (hit before the ball bounces, usually at the net), overhead smash, lob, and drop shot. Topspin makes the ball dip and bounce high; slice (backspin) makes it skid low.",
    "Players' styles range from serve-and-volley (rushing the net after serving) to baseline play (rallying from the back). Modern racket technology and slower courts have made baseline power dominant."]],
  ["Surfaces",[
    "Court surfaces shape the game. Grass (Wimbledon) is fast with low bounces, favoring big servers; clay (the French Open) is slow with high bounces, rewarding endurance and topspin; hard courts (the Australian Open and US Open) are in between. Spain's Rafael Nadal won the French Open a record 14 times on clay.",
    "Electronic line-calling and Hawk-Eye replays are now standard at most top events."]],
  ["Tournaments and rankings",[
    "The four Grand Slam tournaments are the Australian Open (January, Melbourne), the French Open or Roland-Garros (May–June, Paris), Wimbledon (June–July, London), and the US Open (August–September, New York). Winning all four in a calendar year is a 'Grand Slam'; Rod Laver did it twice (1962, 1969) and Steffi Graf in 1988, adding Olympic gold for a 'Golden Slam.'",
    "The men's professional tour is run by the ATP and the women's by the WTA, with rankings based on points earned. The Davis Cup (men's, from 1900) and Billie Jean King Cup (women's) are national team competitions."]]
  ],
  terms:[["Deuce","40–40 score in a game."],["Ace","Unreturned serve."],["Break","Winning the opponent's service game."],["Tiebreak","Points-based decider at 6–6."],["Grand Slam","The four major tournaments; also winning all four in a year."]],
  w:"Tennis's quirky scoring creates constant pressure points; understanding it makes every match gripping.",
  src:["Tennis","Tennis scoring system","Grand Slam (tennis)","Wimbledon Championships","Walter Clopton Wingfield"],
  q:[
  ["What does 'love' mean in tennis scoring?","Zero","A tie","A serve","Advantage"],
  ["Which Grand Slam is played on clay?","French Open","Wimbledon","US Open","Australian Open"],
  ["What is a double fault?","Missing both serve attempts","Hitting the net twice","Two aces in a row","Losing two games"],
  ["Who won the French Open a record 14 times?","Rafael Nadal","Novak Djokovic","Björn Borg","Roger Federer"],
  ["When were the first Wimbledon Championships held?","1877","1900","1868","1891"],
  ["Who completed the 'Golden Slam' in 1988?","Steffi Graf","Martina Navratilova","Serena Williams","Chris Evert"]]},

{ t:"Tennis Legends", s:"From Tilden to the Big Three",
  sec:[
  ["Early greats",[
    "Bill Tilden dominated the 1920s; France's 'Four Musketeers' (René Lacoste, Henri Cochet, Jean Borotra, and Jacques Brugnon) won Davis Cups, and the stadium at Roland-Garros was built for their 1928 defense. Lacoste also founded the famous shirt brand with its crocodile logo.",
    "Suzanne Lenglen of France was the first female tennis celebrity in the 1920s, and Helen Wills Moody won 19 Grand Slam singles titles. Don Budge completed the first calendar Grand Slam in 1938."]],
  ["Breaking barriers",[
    "Althea Gibson became the first Black player to win a Grand Slam title, at the 1956 French Open, then Wimbledon and the US Nationals in 1957 and 1958. Arthur Ashe became the first Black man to win the US Open (1968), Wimbledon (1975), and the Australian Open; the main US Open stadium is named after him.",
    "The 'Open Era' began in 1968 when Grand Slams admitted professionals. Billie Jean King fought for equal prize money (the US Open was first to offer it, in 1973), founded the WTA, and beat Bobby Riggs in the 1973 'Battle of the Sexes,' watched by some 90 million people."]],
  ["The 1970s–90s",[
    "Björn Borg of Sweden won five straight Wimbledons (1976–80); his rivalry with fiery American John McEnroe, culminating in the 1980 Wimbledon final, is legendary. Jimmy Connors, Ivan Lendl, Boris Becker (Wimbledon champion at 17), Stefan Edberg, Pete Sampras (seven Wimbledons), and Andre Agassi followed.",
    "Chris Evert and Martina Navratilova had one of sport's greatest rivalries, meeting 80 times; Navratilova won a record nine Wimbledon singles titles. Steffi Graf won 22 Grand Slam singles titles, and Monica Seles dominated before being stabbed by a spectator in 1993."]],
  ["The Big Three",[
    "From 2003 to the early 2020s, men's tennis was dominated by Roger Federer of Switzerland (20 Grand Slam titles, including a record eight Wimbledons, renowned for elegance), Rafael Nadal of Spain (22, including 14 French Opens), and Novak Djokovic of Serbia, who holds the men's record of 24 Grand Slam singles titles and the most weeks at world number one. Andy Murray, who ended Britain's 77-year wait for a men's Wimbledon champion in 2013, joined them in a 'Big Four.'",
    "In 2024 and 2025, a new rivalry emerged between Italy's Jannik Sinner and Spain's Carlos Alcaraz, who between them won every Grand Slam title in those two years."]],
  ["The Williams sisters and today",[
    "Serena Williams won 23 Grand Slam singles titles in the Open Era, the most by any player in that era, and her sister Venus won seven, including five Wimbledons. Raised in Compton, California, and coached by their father, they transformed women's tennis with power and athleticism and inspired players worldwide. Margaret Court holds the all-time record of 24, many won before the Open Era.",
    "Recent stars include Naomi Osaka, Iga Świątek (multiple French Opens), Aryna Sabalenka, and Coco Gauff. Tennis remains the leading professional sport for women in earnings."]]
  ],
  terms:[["Open Era","Period since 1968 when professionals could enter majors."],["Battle of the Sexes","1973 King vs Riggs match."],["Big Three","Federer, Nadal, Djokovic."],["Calendar Grand Slam","Winning all four majors in one year."],["WTA","Women's Tennis Association, founded 1973."]],
  w:"Tennis's legends include some of sport's greatest rivalries and pioneers for racial and gender equality.",
  src:["Billie Jean King","Althea Gibson","Arthur Ashe","Novak Djokovic","Serena Williams"],
  q:[
  ["Who was the first Black player to win a Grand Slam title (1956)?","Althea Gibson","Arthur Ashe","Venus Williams","Zina Garrison"],
  ["Who won the 1973 'Battle of the Sexes'?","Billie Jean King","Bobby Riggs","Chris Evert","Margaret Court"],
  ["Who holds the men's record of 24 Grand Slam singles titles?","Novak Djokovic","Rafael Nadal","Roger Federer","Pete Sampras"],
  ["Who won five straight Wimbledon titles from 1976 to 1980?","Björn Borg","John McEnroe","Jimmy Connors","Rod Laver"],
  ["How many Open Era Grand Slam singles titles did Serena Williams win?","23","24","22","19"],
  ["Who won a record nine Wimbledon singles titles?","Martina Navratilova","Steffi Graf","Serena Williams","Venus Williams"]]},

{ t:"Golf: How It's Played", s:"Par, birdies, and the rules of the course",
  sec:[
  ["The game",[
    "Golf is played on a course, usually of 18 holes. Each hole begins at a tee box and ends at a green, a closely mown area containing a hole (cup) 4.25 inches (10.8 cm) in diameter marked by a flag. Between them are the fairway (short grass), rough (longer grass), and hazards such as bunkers (sand traps) and water.",
    "The aim is to complete each hole, and the round, in as few strokes as possible."]],
  ["Par and scoring",[
    "Each hole has a par, the number of strokes an expert is expected to need: usually 3, 4, or 5 depending on length. A typical 18-hole course has a par of about 70–72. Scores relative to par have names: a birdie is one under par, an eagle two under, an albatross (double eagle) three under; a bogey is one over, a double bogey two over. A hole-in-one (ace) is holing the tee shot.",
    "In stroke play, the total number of strokes over the round or tournament counts; in match play, players compete hole by hole, winning, losing, or halving each hole, as in the Ryder Cup."]],
  ["Clubs and shots",[
    "Players may carry up to 14 clubs: woods (including the driver, for long tee shots), irons (numbered, with higher numbers giving more loft and less distance), wedges (for short, high shots and bunkers), hybrids, and a putter for rolling the ball on the green.",
    "Shots include the drive, approach, chip, pitch, bunker shot, and putt. Reading the slope and speed of greens is a crucial skill; putting often decides tournaments."]],
  ["Rules and etiquette",[
    "The Rules of Golf are jointly maintained by the R&A (based in St Andrews) and the United States Golf Association (USGA); a major simplification took effect in 2019. Players generally must play the ball as it lies; penalties apply for lost balls, out of bounds, and unplayable lies. Golf is notable for players calling penalties on themselves.",
    "Etiquette includes not talking during others' swings, repairing divots and ball marks, raking bunkers, and keeping up the pace of play."]],
  ["Handicaps",[
    "Golf's handicap system lets players of different abilities compete fairly. A handicap index reflects a player's potential ability; on a given course, a player with a handicap of 18 receives one stroke per hole. The World Handicap System, introduced in 2020, unified handicaps globally.",
    "Amateur golf is enormously popular, with tens of millions of players worldwide, from public courses to exclusive clubs."]],
  ["Course design",[
    "Links courses, the original form, are coastal courses on sandy land in Scotland and Ireland, exposed to wind, such as the Old Course at St Andrews. Parkland courses are inland with trees and lush grass, like Augusta National in Georgia. Desert, heathland, and mountain courses add variety.",
    "Famous architects include Old Tom Morris, Alister MacKenzie (co-designer of Augusta National), Donald Ross, and Pete Dye."]]
  ],
  terms:[["Par","Expected strokes for an expert on a hole."],["Birdie","One stroke under par."],["Bogey","One stroke over par."],["Match play","Scoring hole by hole."],["Handicap","Number adjusting scores to equalize players."]],
  w:"Golf's scoring and rules reward precision and honesty, and its handicap system lets anyone compete.",
  src:["Golf","Par (score)","Rules of Golf","Handicap (golf)","Links (golf)"],
  q:[
  ["What is a birdie?","One stroke under par","One stroke over par","Two under par","A hole-in-one"],
  ["How many clubs may a golfer carry?","14","12","18","10"],
  ["Who jointly maintains the Rules of Golf with the USGA?","The R&A","The PGA Tour","Augusta National","The European Tour"],
  ["What is match play?","Scoring hole by hole","Total strokes over a round","Team putting contests","Playing nine holes only"],
  ["What is a links course?","A coastal course on sandy land","An inland wooded course","A desert course","A mini-golf course"],
  ["What is an albatross?","Three strokes under par","Three over par","A water hazard","A long drive"]]},

{ t:"Golf's History and Majors", s:"From St Andrews to Augusta",
  sec:[
  ["Scottish origins",[
    "Golf as we know it developed in Scotland in the 15th century. St Andrews, with its Old Course, is known as the 'Home of Golf.' The first Open Championship was played in 1860 at Prestwick; Willie Park Sr. won. Early professionals such as Old Tom Morris and his son Young Tom Morris (who won four straight Opens) were Scottish.",
    "Golf spread to England, the United States, and the Empire in the late 19th century; the US Open began in 1895."]],
  ["The four majors",[
    "Men's professional golf has four major championships: the Masters (April, always at Augusta National in Georgia, winner receives a green jacket), the PGA Championship, the US Open (known for difficult course setups), and The Open Championship (the 'British Open,' the oldest, played on links courses, winner receives the Claret Jug).",
    "Women's majors include the Chevron Championship, the US Women's Open, the Women's PGA Championship, the Evian Championship, and the Women's British Open."]],
  ["Legends",[
    "Bobby Jones, an amateur, won the 'Grand Slam' of his era in 1930 and co-founded Augusta National and the Masters. Ben Hogan, famous for ball-striking, came back from a near-fatal car crash to win multiple majors. Arnold Palmer brought charisma and TV popularity in the 1960s ('Arnie's Army'), and Gary Player of South Africa became a global ambassador.",
    "Jack Nicklaus, 'the Golden Bear,' holds the record of 18 men's major championships, including six Masters; his final Masters win came at age 46 in 1986. Seve Ballesteros of Spain inspired European golf with flair."]],
  ["Tiger Woods",[
    "Tiger Woods won the 1997 Masters by a record 12 strokes at age 21, the first major won by a player of African American and Asian descent, transforming golf's popularity and diversity. He held all four major titles at once in 2000–01 (the 'Tiger Slam') and has 15 majors.",
    "After injuries and personal scandals, Woods won the 2019 Masters in one of sport's great comebacks. Women's legends include Babe Didrikson Zaharias, Annika Sörenstam, Mickey Wright, Lorena Ochoa, Inbee Park, and Nelly Korda."]],
  ["Team golf and professional tours",[
    "The Ryder Cup, begun in 1927, pits the United States against Europe (originally Great Britain, then Great Britain and Ireland, with continental Europe joining in 1979) every two years in match play, generating intense patriotism. The Solheim Cup is the women's equivalent, and the Presidents Cup pits the US against an International team.",
    "The PGA Tour and the DP World Tour (formerly European Tour) are the main men's tours. In 2022 the Saudi-funded LIV Golf league lured stars with huge contracts, splitting men's golf and sparking controversy over 'sportswashing'; negotiations over a merger followed."]],
  ["Golf and society",[
    "Golf has a history of exclusivity: many clubs excluded women, Black, and Jewish people. Augusta National admitted its first Black member in 1990 and its first women members in 2012. Charlie Sifford broke the PGA Tour's 'Caucasian-only' clause in 1961.",
    "Golf returned to the Olympics in 2016 after 112 years. Environmental issues, such as water use and land, and efforts to make golf more affordable and inclusive are ongoing."]]
  ],
  terms:[["Major","One of the four most prestigious championships."],["Green jacket","Prize for winning the Masters."],["Claret Jug","Trophy of The Open Championship."],["Ryder Cup","US vs Europe team match play event."],["LIV Golf","Saudi-funded league launched 2022."]],
  w:"Golf's majors and legends span from 19th-century Scotland to today's global tours and controversies.",
  src:["Men's major golf championships","Jack Nicklaus","Tiger Woods","Ryder Cup","The Open Championship"],
  q:[
  ["Who holds the record of 18 men's major championships?","Jack Nicklaus","Tiger Woods","Arnold Palmer","Ben Hogan"],
  ["What does the Masters winner receive?","A green jacket","The Claret Jug","The Wanamaker Trophy","A silver cup"],
  ["Where was the first Open Championship played in 1860?","Prestwick","St Andrews","Carnoustie","Muirfield"],
  ["By how many strokes did Tiger Woods win the 1997 Masters?","12","8","15","5"],
  ["What is the Ryder Cup?","A US vs Europe team match play competition","The British Open trophy","A women's major","An amateur championship"],
  ["Who co-founded Augusta National and the Masters?","Bobby Jones","Jack Nicklaus","Ben Hogan","Walter Hagen"]]}

]});


/* ---- from sports-10.js ---- */
/* SPORTS FOUNDATIONS, part 10: Unit 5 chapters 5-7 */
COURSES.sports.units[4].ch.push(

{ t:"Badminton, Table Tennis, Squash, and Pickleball", s:"Fast hands, small courts",
  sec:[
  ["Badminton",[
    "Badminton developed from the ancient game of battledore and shuttlecock and from 'poona' played by British officers in India; it takes its name from Badminton House, the Duke of Beaufort's estate in England, where it was played around 1873. Players hit a feathered shuttlecock over a high net; a point is won when the shuttle lands in the opponent's court or they fault.",
    "Games are played to 21 points with rally scoring, best of three games. Smashes can exceed 400 km/h, making the shuttlecock the fastest projectile in racket sports (a record of over 565 km/h was set in 2023). Asia dominates: China, Indonesia, Malaysia, Japan, South Korea, India, and Denmark are the leading nations. Badminton joined the Olympics in 1992."]],
  ["Table tennis",[
    "Table tennis (ping-pong) began as an after-dinner parlor game in Victorian England. Played on a table 2.74 m long with a 15.25 cm net, games go to 11 points (since 2001), with players alternating two serves each. Players use spin heavily: topspin, backspin, and sidespin, controlled by rubber-coated paddles.",
    "China has dominated since the 1960s, winning the vast majority of Olympic golds since the sport's 1988 debut. 'Ping-pong diplomacy' in 1971, when the US table tennis team visited China, helped open relations between the two countries before President Nixon's 1972 visit."]],
  ["Squash",[
    "Squash developed at Harrow School in England around 1830 from rackets, using a softer, 'squashable' ball. Two players alternately hit a small rubber ball against the front wall of an enclosed four-walled court; the ball may hit side and back walls but must bounce only once on the floor. Rallies are physically grueling.",
    "Pakistan dominated men's squash for decades: Jahangir Khan won 555 consecutive matches between 1981 and 1986, one of the longest winning streaks in any sport; Jansher Khan followed. Egypt has dominated in the 21st century. Squash will make its Olympic debut at Los Angeles 2028."]],
  ["Pickleball and padel",[
    "Pickleball was invented in 1965 on Bainbridge Island, Washington, by Joel Pritchard, Bill Bell, and Barney McCallum, combining elements of tennis, badminton, and table tennis. It is played with paddles and a perforated plastic ball on a badminton-sized court, with a 'kitchen' (non-volley zone) near the net. It became one of the fastest-growing sports in the United States in the 2020s.",
    "Padel, invented in Mexico in 1969 and hugely popular in Spain and Argentina, is played in doubles on an enclosed court with walls that can be used, and solid paddles. It is spreading rapidly across Europe and the Middle East."]],
  ["Shared skills",[
    "Racket sports share key skills: footwork and court movement, anticipation, wrist and grip control, and tactical placement. They also offer lifelong fitness: they can be played at any age and at varied intensities.",
    "Research has associated racket sports with health benefits, including improved cardiovascular fitness."]]
  ],
  terms:[["Shuttlecock","Feathered projectile in badminton."],["Rally scoring","A point is scored on every rally."],["Ping-pong diplomacy","1971 US–China table tennis exchange."],["Kitchen","Pickleball's non-volley zone."],["Padel","Walled-court doubles racket sport."]],
  w:"Racket sports are among the most popular participation sports in the world and offer lifelong fitness.",
  src:["Badminton","Table tennis","Ping-pong diplomacy","Squash (sport)","Pickleball"],
  q:[
  ["Badminton is named after what?","Badminton House, an English estate","A town in India","Its inventor","A Danish city"],
  ["What was 'ping-pong diplomacy'?","A 1971 US–China table tennis exchange","A tennis treaty","Olympic boycotts","A Cold War chess match"],
  ["Who won 555 consecutive squash matches?","Jahangir Khan","Jansher Khan","Nicol David","Ramy Ashour"],
  ["Where was pickleball invented in 1965?","Bainbridge Island, Washington","Florida","California","Ontario"],
  ["To how many points is a table tennis game played?","11","21","15","7"],
  ["Which country has dominated Olympic table tennis?","China","Japan","Sweden","South Korea"]]},

{ t:"Volleyball, Handball, Hockey, and Lacrosse", s:"Team sports around the world",
  sec:[
  ["Volleyball",[
    "Volleyball was invented in 1895 by William G. Morgan at a YMCA in Holyoke, Massachusetts, as a less strenuous alternative to basketball. Two teams of six players hit a ball over a high net; each side may touch the ball up to three times (typically pass, set, and attack or 'spike') before returning it, and a player cannot touch it twice in a row.",
    "Matches use rally scoring, best of five sets, with sets to 25 points (the fifth to 15). The libero is a defensive specialist in a different-colored jersey. Brazil, the United States, Italy, Poland, Serbia, China, and Japan are leading nations. Beach volleyball, played two-a-side on sand, joined the Olympics in 1996."]],
  ["Handball",[
    "Team handball, codified in Denmark and Germany in the late 19th and early 20th centuries, is played by two teams of seven (including a goalkeeper) on an indoor court. Players pass and bounce the ball by hand and shoot at a goal; only the goalkeeper may enter the semicircular goal area. It is fast and high-scoring, with matches of two 30-minute halves often producing 50–60 total goals.",
    "Handball is hugely popular in Europe, especially Denmark, France, Germany, Spain, Norway, and Sweden, and in North Africa. France's men and Norway's women have been among the most successful in recent decades."]],
  ["Field hockey",[
    "Field hockey, with roots in ancient stick-and-ball games, was codified in England in the 19th century. Two teams of eleven use curved sticks, flat on one side, to hit a hard ball into the opponents' goal; goals can only be scored from inside the 'shooting circle.' Penalty corners are important set pieces.",
    "India dominated Olympic hockey from 1928 to 1956, winning six straight golds with players such as Dhyan Chand, 'The Wizard.' Pakistan, the Netherlands, Australia, Germany, Belgium, and Argentina have since been powers. Field hockey is especially popular among women in Europe, the US, Australia, and Argentina, where the national team is known as 'Las Leonas.'"]],
  ["Lacrosse",[
    "Lacrosse originated with Indigenous peoples of North America, especially the Haudenosaunee (Iroquois), as a spiritual game called 'the Creator's Game,' sometimes played by hundreds of players across miles of territory. French missionaries named it after the crosse (crozier-like stick).",
    "Modern field lacrosse, codified in Canada in the 1860s, uses sticks with netted pockets to catch, carry, and throw a rubber ball into the opponent's goal. Box lacrosse, played indoors, is Canada's official summer sport. The Haudenosaunee Nationals compete internationally as a sovereign nation. Lacrosse sixes will feature at the Los Angeles 2028 Olympics."]],
  ["Water polo and other team sports",[
    "Water polo, developed in Britain in the 1870s, is played in a pool by teams of seven who swim, tread water, and throw the ball into a goal; it is among the oldest Olympic team sports (since 1900). Hungary is the most successful nation.",
    "Other team sports include netball (popular in the Commonwealth), korfball (a mixed-gender Dutch sport), kabaddi (a South Asian tag-and-breath-holding contest with a popular professional league in India), sepak takraw (Southeast Asian 'kick volleyball'), and ultimate frisbee."]]
  ],
  terms:[["Spike","Powerful downward attacking hit in volleyball."],["Libero","Volleyball defensive specialist."],["Shooting circle","Area from which field hockey goals can be scored."],["Creator's Game","Haudenosaunee name for lacrosse."],["Kabaddi","South Asian contact team sport."]],
  w:"These sports show how team games take different forms around the world, each with its own heroes and traditions.",
  src:["Volleyball","Handball","Field hockey","Lacrosse","Water polo"],
  q:[
  ["Who invented volleyball in 1895?","William G. Morgan","James Naismith","Walter Camp","Abner Doubleday"],
  ["How many touches may a volleyball team make before returning the ball?","Three","Two","Four","Five"],
  ["Which country won six straight Olympic field hockey golds from 1928 to 1956?","India","Pakistan","Netherlands","Great Britain"],
  ["Which Indigenous people call lacrosse 'the Creator's Game'?","Haudenosaunee (Iroquois)","Navajo","Cree","Cherokee"],
  ["How many players per team are on court in handball?","Seven","Six","Five","Eleven"],
  ["Which nation is most successful in Olympic water polo?","Hungary","Italy","USA","Serbia"]]},

{ t:"Target and Cue Sports", s:"Precision under pressure",
  sec:[
  ["Archery",[
    "Archery is among the oldest human skills, used for hunting and war for tens of thousands of years. As a sport, it was popular in medieval England, where laws required men to practice. In Olympic archery (since 1972 in its modern form), archers shoot recurve bows at a target 70 meters away, with ten scoring rings; the central ten ring is just 12.2 cm wide.",
    "South Korea has dominated Olympic archery, especially in women's events, through rigorous national selection and training. Compound bows, with pulleys, are used in other competitions and will join the Olympics in 2028. Japan's kyūdō is a traditional, meditative form."]],
  ["Shooting",[
    "Sport shooting includes rifle, pistol, and shotgun (clay target) events, testing steadiness, breathing control, and concentration. It was part of the first modern Olympics in 1896.",
    "Shotgun events such as trap and skeet require hitting flying clay targets; rifle and pistol events involve precise shots at fixed targets at set distances. Biathlon combines cross-country skiing with rifle shooting."]],
  ["Darts",[
    "Darts developed in English pubs. Players throw three darts per turn at a dartboard divided into numbered segments with doubles and trebles rings; the bullseye is worth 50 points. The most common game, 501, requires players to reduce their score exactly to zero, finishing on a double. A perfect leg takes nine darts.",
    "Professional darts has grown into a major televised sport, especially the PDC World Championship at London's Alexandra Palace; Phil Taylor won 16 world titles, and teenager Luke Littler became a sensation, winning the 2025 PDC world title at 17."]],
  ["Snooker, pool, and billiards",[
    "Cue sports descend from a lawn game similar to croquet brought indoors in the 15th century. Snooker was invented by British army officers in India in 1875. Players use a cue to pot (sink) 15 red balls (1 point each), alternating with colored balls (2–7 points), in a sequence; a maximum break is 147.",
    "Snooker's World Championship at the Crucible Theatre in Sheffield is a major event; Stephen Hendry and Ronnie O'Sullivan have each won seven modern-era world titles. Pool (popular in America, such as eight-ball and nine-ball) and carom billiards (without pockets) are related games."]],
  ["Bowling and other target sports",[
    "Ten-pin bowling, popular in the United States, involves rolling a heavy ball down a lane to knock down pins; a perfect game scores 300 (twelve consecutive strikes). Lawn bowls, bocce (Italy), pétanque (France), and curling (on ice) are target games where players roll or slide objects toward a target.",
    "Target sports reward fine motor control, consistency, and psychological composure; many can be played at elite level into later life."]]
  ],
  terms:[["Recurve bow","Olympic bow with tips curving away from the archer."],["501","Standard darts game finishing on a double."],["Maximum break","Snooker's highest single-visit score, 147."],["Strike","Knocking down all pins with the first ball."],["Biathlon","Cross-country skiing plus rifle shooting."]],
  w:"Target sports test precision and nerve, and include some of the world's most popular televised games.",
  src:["Archery","Darts","Snooker","Ten-pin bowling","Shooting sports"],
  q:[
  ["Which country has dominated Olympic archery?","South Korea","USA","China","Japan"],
  ["What is the maximum break in snooker?","147","155","100","180"],
  ["Where is the World Snooker Championship held?","The Crucible Theatre, Sheffield","Alexandra Palace","Wembley Arena","Royal Albert Hall"],
  ["How many darts does a perfect leg of 501 take?","Nine","Twelve","Six","Fifteen"],
  ["What is a perfect score in ten-pin bowling?","300","200","250","500"],
  ["Where was snooker invented in 1875?","India","England","Ireland","South Africa"]]}

);


/* ---- from sports-11.js ---- */
/* SPORTS FOUNDATIONS, part 11: Unit 6 Athletics and Swimming, chapters 1-5 */
COURSES.sports.units.push({ t:"Athletics, Gymnastics, and Endurance Sports", ch:[

{ t:"Track and Field: An Overview", s:"Run, jump, throw",
  sec:[
  ["The 'mother of sports'",[
    "Athletics (called track and field in the US) is the core of the Olympics, combining running, jumping, throwing, and walking events. Its basic actions are the most natural human movements, and it is the most universal Olympic sport, with nearly every nation competing.",
    "The sport is governed by World Athletics (formerly the IAAF, founded 1912). The World Athletics Championships began in 1983 and are now held every two years."]],
  ["The venue",[
    "A standard outdoor track is an oval of 400 meters with eight or nine lanes, surrounding an infield where field events take place. Races up to 400 meters are run entirely in lanes, with staggered starts on bends so everyone runs the same distance. Indoor tracks are 200 meters, with banked curves.",
    "Synthetic tracks replaced cinder tracks from the 1960s–70s, allowing faster times."]],
  ["Event groups",[
    "Track events include sprints (100 m, 200 m, 400 m), hurdles, middle distance (800 m, 1500 m, the mile), long distance (3000 m steeplechase, 5000 m, 10,000 m), and relays. Road events include the marathon and race walking. Field events include the jumps (high jump, pole vault, long jump, triple jump) and throws (shot put, discus, hammer, javelin).",
    "Combined events test all-round ability: the decathlon (ten events over two days) for men and the heptathlon (seven events) for women. The decathlon champion is traditionally called 'the world's greatest athlete,' a title King Gustav V of Sweden supposedly gave Jim Thorpe in 1912."]],
  ["Timing and measurement",[
    "Races are timed electronically to the hundredth of a second, with photo-finish cameras deciding close finishes; a false start brings disqualification under rules introduced in 2010. Field events are measured precisely; long and triple jumps are measured to the nearest centimeter from the takeoff board.",
    "Wind gauges measure tailwind in sprints and horizontal jumps; records require a tailwind no stronger than 2.0 meters per second."]],
  ["Records and professionalism",[
    "World records are ratified by World Athletics. Athletics remained officially amateur until the 1980s; today top athletes earn from prize money, appearance fees, and sponsorship. The Diamond League (since 2010) is the top annual series of one-day meets.",
    "Famous athletes across events include Jesse Owens, Carl Lewis, Usain Bolt, Jackie Joyner-Kersee, Florence Griffith Joyner, Haile Gebrselassie, Eliud Kipchoge, Armand Duplantis, and Faith Kipyegon."]],
  ["Doping and controversies",[
    "Athletics has been heavily affected by doping: Canadian sprinter Ben Johnson was stripped of his 1988 Olympic 100 m gold for steroids; East German women dominated the 1970s–80s through a secret state doping program; Russia's athletics federation was suspended from 2015 for state-sponsored doping.",
    "Eligibility rules for athletes with differences of sex development (DSD) and transgender athletes have been major debates; Caster Semenya's legal challenges went to the European Court of Human Rights, which in 2025 ruled that her right to a fair hearing had been violated."]]
  ],
  terms:[["Athletics","Track, field, road running, and walking."],["Decathlon","Ten-event men's combined competition."],["Heptathlon","Seven-event women's combined competition."],["Photo finish","Camera judging of close race finishes."],["Diamond League","Top annual series of athletics meets."]],
  w:"Athletics is the foundation of the Olympics and measures the limits of human speed, strength, and endurance.",
  src:["Sport of athletics","World Athletics","Decathlon","Track and field","Diamond League"],
  q:[
  ["How long is a standard outdoor track?","400 meters","200 meters","500 meters","1 mile"],
  ["How many events are in the decathlon?","Ten","Seven","Five","Twelve"],
  ["What is the maximum legal tailwind for records in sprints?","2.0 meters per second","1.0 m/s","3.0 m/s","5.0 m/s"],
  ["Which sprinter was stripped of his 1988 Olympic gold for steroids?","Ben Johnson","Carl Lewis","Linford Christie","Donovan Bailey"],
  ["What was World Athletics formerly called?","IAAF","FIFA","IOC","AAU"],
  ["Who was reportedly called 'the world's greatest athlete' in 1912?","Jim Thorpe","Jesse Owens","Paavo Nurmi","Carl Lewis"]]},

{ t:"Sprints, Hurdles, and Relays", s:"The fastest humans",
  sec:[
  ["The 100 meters",[
    "The 100 m dash determines 'the fastest man and woman in the world.' Sprinters start in blocks, react to the gun (a reaction under 0.1 seconds is considered a false start), accelerate for about 50–60 meters, reach top speed, and try to maintain it as they inevitably slow. Usain Bolt's world record of 9.58 seconds (Berlin, 2009) included a top speed of about 44.7 km/h (27.8 mph).",
    "Florence Griffith Joyner's women's record of 10.49 seconds has stood since 1988. Jamaica's Shelly-Ann Fraser-Pryce won two Olympic and five world 100 m titles."]],
  ["The 200 and 400",[
    "The 200 m begins on the curve. Bolt also holds that record (19.19, 2009). Michael Johnson, with his upright style, dominated the 200 and 400 m in the 1990s, winning both at the 1996 Olympics. Wayde van Niekerk of South Africa set the 400 m record (43.03) from lane 8 at Rio 2016.",
    "The 400 m, one lap, is often called the hardest sprint, demanding speed and the ability to endure the buildup of lactate. The women's 400 m record by Marita Koch of East Germany (47.60, 1985) is among the oldest."]],
  ["Hurdles",[
    "Sprint hurdles are 110 m for men (hurdles 1.067 m high) and 100 m for women (0.838 m), with ten hurdles each; athletes take three strides between hurdles. The 400 m hurdles uses lower hurdles around a full lap. Edwin Moses won 122 consecutive 400 m hurdles races (1977–87).",
    "Norway's Karsten Warholm and the US's Sydney McLaughlin-Levrone shattered 400 m hurdles world records in the 2020s, aided in part by new shoe and track technology."]],
  ["Relays",[
    "Relays have four runners, each covering a leg: 4 × 100 m and 4 × 400 m are the standard Olympic relays, and a mixed 4 × 400 m relay was added in 2021. Runners pass a baton within a 30-meter exchange zone; dropped batons and failed exchanges often decide championships.",
    "Jamaica and the United States have been the dominant sprint relay nations."]],
  ["Usain Bolt",[
    "Usain Bolt of Jamaica, 1.95 m tall, unusually large for a sprinter, won the 100 m and 200 m at three consecutive Olympics (2008, 2012, 2016) and set world records still standing. His charisma and 'lightning bolt' pose made him a global star.",
    "Earlier sprint legends include Jesse Owens, Bob Hayes, Carl Lewis (nine Olympic golds across sprints and the long jump), and Wilma Rudolph, who overcame childhood polio to win three golds in 1960."]],
  ["The science of speed",[
    "Sprinting depends on fast-twitch muscle fibers, stride length and frequency, ground reaction forces, and technique. Elite sprinters apply massive force to the ground in brief contacts of under a tenth of a second.",
    "West African ancestry is common among elite sprinters, and research into genetics (such as the ACTN3 gene), training, and environment continues; scientists stress that no single gene explains speed."]]
  ],
  terms:[["Starting blocks","Foot supports for sprint starts."],["Exchange zone","Area where relay batons must pass."],["Fast-twitch fibers","Muscle fibers for explosive power."],["Reaction time","Time from gun to movement."],["Stagger","Offset starting positions on bends."]],
  w:"Sprinting is the purest test of speed, and its records chart the limits of human performance.",
  src:["100 metres","Usain Bolt","Hurdling","Relay race","Florence Griffith Joyner"],
  q:[
  ["What is Usain Bolt's 100 m world record?","9.58 seconds","9.69 seconds","9.79 seconds","9.49 seconds"],
  ["Who holds the women's 100 m world record (10.49)?","Florence Griffith Joyner","Shelly-Ann Fraser-Pryce","Marion Jones","Elaine Thompson-Herah"],
  ["Who won 122 consecutive 400 m hurdles races?","Edwin Moses","Karsten Warholm","Kevin Young","Michael Johnson"],
  ["How many hurdles are in the 110 m hurdles?","Ten","Eight","Twelve","Nine"],
  ["What reaction time is considered a false start?","Under 0.1 seconds","Under 0.5 seconds","Under 0.01 seconds","Under 0.2 seconds"],
  ["Who set the 400 m world record from lane 8 in 2016?","Wayde van Niekerk","Michael Johnson","Kirani James","Steven Gardiner"]]},

{ t:"Distance Running and the Marathon", s:"Endurance on track and road",
  sec:[
  ["Middle distance",[
    "Middle-distance events, the 800 m and 1500 m (and the mile), combine speed and endurance, with tactical racing. On 6 May 1954 at Oxford, Roger Bannister became the first person to run a mile in under four minutes (3:59.4), a barrier some had thought impossible; within weeks Australia's John Landy broke it too. Morocco's Hicham El Guerrouj holds the mile record (3:43.13, 1999).",
    "Kenya's David Rudisha set the 800 m record (1:40.91) at the 2012 Olympics, leading from the front. Kenya's Faith Kipyegon dominated the women's 1500 m with multiple Olympic and world titles and world records."]],
  ["Long distance on the track",[
    "The 5000 m and 10,000 m test aerobic endurance. Finland's 'Flying Finns,' especially Paavo Nurmi (nine Olympic golds in the 1920s), dominated early. Czech runner Emil Zátopek won the 5000 m, 10,000 m, and marathon at the 1952 Olympics, his first marathon.",
    "East African runners from Ethiopia and Kenya have dominated since the 1960s: Haile Gebrselassie, Kenenisa Bekele, Tirunesh Dibaba, and Joshua Cheptegei. Britain's Mo Farah won the 'double' at two Olympics (2012, 2016). The 3000 m steeplechase includes barriers and a water jump; Kenyan men have won it at most Olympics since 1968."]],
  ["The marathon",[
    "The marathon recalls the legend of the Greek messenger Pheidippides running from Marathon to Athens to announce victory over the Persians in 490 BCE. The first Olympic marathon was in 1896; the distance was fixed at 42.195 km (26.2 miles) after 1908. Ethiopia's Abebe Bikila won the 1960 Rome Olympic marathon running barefoot.",
    "Kenya's Eliud Kipchoge won two Olympic marathons and in 2019 ran a marathon distance in 1:59:40 in a special event in Vienna (not an official record, due to rotating pacers and other aids). Kenya's Kelvin Kiptum set the official record of 2:00:35 in Chicago in 2023 before dying in a car crash in 2024; Kenya's Ruth Chepngetich set the women's record of 2:09:56 in 2024 but was later suspended for doping."]],
  ["The big city marathons",[
    "The World Marathon Majors are Tokyo, Boston (the oldest annual marathon, since 1897), London, Berlin (known for fast, flat courses where many records fall), Chicago, New York, and, from 2025, Sydney. They attract tens of thousands of amateur runners.",
    "Women were long excluded from distance running; Kathrine Switzer ran the 1967 Boston Marathon officially registered under her initials, and an official tried to remove her mid-race. The women's Olympic marathon was added only in 1984, won by Joan Benoit."]],
  ["Shoe technology and training",[
    "Since 2017, 'super shoes' with carbon-fiber plates and highly resilient foams have improved running economy and contributed to a wave of records, prompting World Athletics to introduce shoe regulations in 2020.",
    "Distance runners train with high weekly mileage, interval sessions, tempo runs, and long runs; many train at high altitude, such as Iten in Kenya, to increase red blood cell production."]],
  ["Running for everyone",[
    "Running is one of the most popular forms of exercise globally. The 1970s 'running boom' made jogging mainstream, and today parkrun, a free weekly 5 km event begun in London in 2004, has spread to many countries.",
    "Ultramarathons (longer than a marathon), trail running, and cross-country offer other challenges; the Comrades Marathon in South Africa (about 90 km) is among the oldest ultras."]]
  ],
  terms:[["Four-minute mile","Barrier first broken by Roger Bannister in 1954."],["Steeplechase","Race with barriers and a water jump."],["Marathon","Race of 42.195 km."],["Super shoes","Carbon-plated, high-rebound racing shoes."],["Altitude training","Training at elevation to boost endurance."]],
  w:"Distance running tests human endurance and has become one of the world's most popular participation sports.",
  src:["Roger Bannister","Marathon","Eliud Kipchoge","Emil Zátopek","World Marathon Majors"],
  q:[
  ["Who ran the first sub-four-minute mile in 1954?","Roger Bannister","John Landy","Paavo Nurmi","Hicham El Guerrouj"],
  ["Who won the 1960 Olympic marathon barefoot?","Abebe Bikila","Emil Zátopek","Haile Gebrselassie","Frank Shorter"],
  ["Who ran a 1:59:40 marathon distance in 2019?","Eliud Kipchoge","Kelvin Kiptum","Kenenisa Bekele","Mo Farah"],
  ["Which is the oldest annual marathon?","Boston","New York","London","Berlin"],
  ["Who won the 5000 m, 10,000 m, and marathon at the 1952 Olympics?","Emil Zátopek","Paavo Nurmi","Lasse Virén","Abebe Bikila"],
  ["When was the women's Olympic marathon added?","1984","1960","1972","1996"]]},

{ t:"Jumps, Throws, and Combined Events", s:"Height, distance, and versatility",
  sec:[
  ["High jump",[
    "In the high jump, athletes try to clear a horizontal bar without knocking it off, with three attempts at each height. Techniques evolved from the scissors and straddle to the 'Fosbury Flop,' introduced by American Dick Fosbury at the 1968 Olympics: going over backward, head first, and landing on the back, made possible by soft foam landing mats.",
    "Cuba's Javier Sotomayor has held the men's record (2.45 m) since 1993. At Tokyo 2020, Mutaz Barshim of Qatar and Gianmarco Tamberi of Italy agreed to share the gold rather than jump off."]],
  ["Pole vault",[
    "Pole vaulters sprint down a runway, plant a flexible pole in a box, and are catapulted over a bar. Poles evolved from bamboo to aluminum to fiberglass and carbon fiber, which bend and store energy. Ukraine's Sergey Bubka broke the world record 35 times; Sweden's Armand 'Mondo' Duplantis has repeatedly raised the record, past 6.20 meters, often by a single centimeter at a time.",
    "Women's pole vault was added to the Olympics in 2000; Russia's Yelena Isinbayeva set many records."]],
  ["Long and triple jump",[
    "The long jump requires speed down the runway and a takeoff from a board without stepping over the foul line. Bob Beamon's leap of 8.90 m at the 1968 Mexico City Olympics, helped by high altitude, broke the record by 55 cm; Mike Powell's 8.95 m (1991) still stands.",
    "The triple jump consists of a hop, a step, and a jump. Britain's Jonathan Edwards set the record of 18.29 m in 1995."]],
  ["The throws",[
    "The shot put involves pushing (not throwing) a heavy metal ball (7.26 kg for men) from a circle; American Ryan Crouser has set world records. The discus is thrown with a spinning motion from a circle; the hammer is a metal ball on a wire with a handle, swung in turns. The javelin is thrown after a run-up; its design was changed in 1986 to bring the point down sooner because throws were becoming dangerously long.",
    "Czech Jan Železný holds the javelin record (98.48 m). Throwers combine explosive strength with precise rotational technique."]],
  ["Combined events",[
    "The decathlon includes, over two days: 100 m, long jump, shot put, high jump, 400 m (day one), and 110 m hurdles, discus, pole vault, javelin, and 1500 m (day two). Points tables convert each performance into a score. Daley Thompson, Dan O'Brien, Ashton Eaton, and Kevin Mayer (record holder) are great decathletes.",
    "The heptathlon includes 100 m hurdles, high jump, shot put, 200 m, long jump, javelin, and 800 m. Jackie Joyner-Kersee set the world record (7,291 points) at the 1988 Olympics; Jessica Ennis-Hill and Nafissatou Thiam (three Olympic golds) followed."]]
  ],
  terms:[["Fosbury Flop","Backward high-jump technique introduced in 1968."],["Pole vault","Vaulting over a bar using a flexible pole."],["Triple jump","Hop, step, and jump."],["Shot put","Pushing a heavy metal ball for distance."],["Points tables","Scoring system for combined events."]],
  w:"Field events combine power and technique, and their records reveal the impact of innovation in sport.",
  src:["Fosbury flop","Pole vault","Long jump","Javelin throw","Heptathlon"],
  q:[
  ["Who introduced the backward high jump technique at the 1968 Olympics?","Dick Fosbury","Javier Sotomayor","Valeriy Brumel","Bob Beamon"],
  ["Who has repeatedly raised the pole vault record past 6.20 m?","Armand Duplantis","Sergey Bubka","Renaud Lavillenie","Sam Kendricks"],
  ["Who set the long jump record of 8.95 m in 1991?","Mike Powell","Bob Beamon","Carl Lewis","Jesse Owens"],
  ["What three phases make up the triple jump?","Hop, step, jump","Run, jump, land","Skip, hop, leap","Jump, jump, jump"],
  ["Who set the heptathlon world record in 1988?","Jackie Joyner-Kersee","Jessica Ennis-Hill","Nafissatou Thiam","Carolina Klüft"],
  ["Why was the javelin redesigned in 1986?","Throws were becoming dangerously long","To make it lighter for women","To make it cheaper","To make it fly farther"]]},

{ t:"Swimming and Diving", s:"Strokes, records, and the pool",
  sec:[
  ["The four strokes",[
    "Competitive swimming uses four strokes. Freestyle (in practice the front crawl, the fastest stroke) uses alternating arm strokes and a flutter kick. Backstroke is swum on the back. Breaststroke, the slowest, uses a simultaneous arm sweep and frog kick. Butterfly, developed from breaststroke in the 1930s and recognized separately in the 1950s, uses both arms together over the water and a dolphin kick.",
    "The individual medley (IM) combines all four strokes in the order butterfly, backstroke, breaststroke, freestyle. Medley relays use backstroke, breaststroke, butterfly, and freestyle."]],
  ["The pool",[
    "Olympic pools are 50 meters long ('long course') with eight or ten lanes; short-course competitions use 25-meter pools. Races range from 50 m to 1500 m; open-water swimming (the 10 km marathon swim) joined the Olympics in 2008.",
    "Swimmers start with a dive from blocks (backstrokers start in the water) and use flip turns and underwater dolphin kicks, limited to 15 meters after starts and turns. Touchpads at the wall record times to the hundredth of a second."]],
  ["Legends",[
    "Johnny Weissmuller won five Olympic golds in the 1920s before playing Tarzan in films. Mark Spitz won seven golds at Munich 1972. Australia's Dawn Fraser won the 100 m freestyle at three straight Olympics. East German swimmers dominated women's events in the 1970s–80s through state doping.",
    "Michael Phelps of the United States won 23 Olympic gold medals and 28 medals in total, both records in any sport, including eight golds at Beijing 2008. Katie Ledecky dominated women's distance freestyle with nine Olympic golds through 2024; France's Léon Marchand won four individual golds at Paris 2024."]],
  ["Technology and the suit controversy",[
    "Swimsuit technology became controversial in 2008–09 when full-body polyurethane 'super suits' helped swimmers break dozens of world records. They were banned from 2010; men's suits are now limited to waist to knee, women's from shoulder to knee.",
    "Other innovations include goggles (allowed in Olympics from 1976), caps, pool designs that reduce waves, and underwater analysis of technique."]],
  ["Diving",[
    "Divers perform acrobatic dives from a 3-meter springboard or a 10-meter platform (and 1 m springboard in other competitions), judged on takeoff, flight, and entry, with the score multiplied by a degree of difficulty. A 'rip entry' with almost no splash earns high marks. Synchronized diving pairs two divers.",
    "China has dominated Olympic diving since the 1980s. Greg Louganis of the US won consecutive doubles in 1984 and 1988. High diving, from 20–27 meters, is a newer world championship event."]],
  ["Artistic swimming and water safety",[
    "Artistic swimming (formerly synchronized swimming) combines swimming, dance, and gymnastics in routines to music. Men were allowed to compete in the Olympic team event from 2024.",
    "Swimming is also a life skill: the World Health Organization estimates hundreds of thousands of drowning deaths occur each year, making learn-to-swim programs a public health priority."]]
  ],
  terms:[["Freestyle","Any stroke, in practice front crawl."],["Individual medley","Race using all four strokes."],["Long course","50-meter pool."],["Degree of difficulty","Multiplier for a dive's complexity."],["Rip entry","Splashless dive entry."]],
  w:"Swimming produced the most decorated Olympian ever and is a life skill as well as a sport.",
  src:["Swimming (sport)","Michael Phelps","Butterfly stroke","Diving (sport)","Katie Ledecky"],
  q:[
  ["Which is the fastest swimming stroke?","Front crawl (freestyle)","Butterfly","Backstroke","Breaststroke"],
  ["How many Olympic gold medals did Michael Phelps win?","23","18","28","14"],
  ["What is the order of strokes in the individual medley?","Butterfly, backstroke, breaststroke, freestyle","Freestyle, butterfly, backstroke, breaststroke","Backstroke, breaststroke, butterfly, freestyle","Breaststroke, butterfly, freestyle, backstroke"],
  ["How long is an Olympic pool?","50 meters","25 meters","100 meters","33 meters"],
  ["Why were 'super suits' banned from 2010?","They gave unfair performance advantages","They were unsafe","They were too expensive","They caused injuries"],
  ["Which country has dominated Olympic diving since the 1980s?","China","USA","Russia","Mexico"]]}

]});


/* ---- from sports-12.js ---- */
/* SPORTS FOUNDATIONS, part 12: Unit 6 chapters 6-8 */
COURSES.sports.units[5].ch.push(

{ t:"Gymnastics", s:"Strength, flexibility, and artistry",
  sec:[
  ["Origins",[
    "Gymnastics has ancient roots, but the modern sport grew from 19th-century physical education movements. In Germany, Friedrich Ludwig Jahn, the 'father of gymnastics,' introduced apparatus such as the parallel bars, rings, and horizontal bar in the 1810s, linking exercise to national strength. Sweden's Per Henrik Ling developed a system focused on health.",
    "Gymnastics was part of the first modern Olympics in 1896; women's events were added in 1928 (team) and 1952 (individual)."]],
  ["Artistic gymnastics apparatus",[
    "Men compete on six apparatus: floor exercise, pommel horse, still rings, vault, parallel bars, and horizontal (high) bar. Women compete on four: vault, uneven bars, balance beam (just 10 cm wide), and floor exercise, performed to music.",
    "Competitions include team, all-around (combined score on all apparatus), and individual apparatus finals."]],
  ["Scoring",[
    "In 1976 at Montreal, 14-year-old Nadia Comăneci of Romania scored the first perfect 10 in Olympic gymnastics; the scoreboard could only display 1.00. The 'perfect 10' system was replaced in 2006 by an open-ended system with two parts: a difficulty score (D-score), based on the value of skills performed, and an execution score (E-score) starting from 10 with deductions for errors.",
    "Skills are often named after the first gymnast to perform them in major competition, such as the 'Biles' moves."]],
  ["Legends",[
    "Larisa Latynina of the Soviet Union won 18 Olympic medals (1956–64), a record that stood until Michael Phelps. Věra Čáslavská of Czechoslovakia won seven golds and protested the 1968 Soviet invasion on the podium. Olga Korbut's daring at Munich 1972 popularized the sport worldwide.",
    "Simone Biles of the United States is widely considered the greatest gymnast ever, with numerous world and Olympic titles and several skills named after her. At Tokyo 2020 she withdrew from most events because of the 'twisties,' a dangerous loss of air awareness, sparking global discussion of athletes' mental health, then returned to win three golds at Paris 2024. Japan's Kohei Uchimura dominated men's all-around in the 2010s."]],
  ["Other disciplines",[
    "Rhythmic gymnastics (women's Olympic event since 1984) combines dance and apparatus handling, with ribbon, hoop, ball, clubs, and rope. Trampoline joined the Olympics in 2000. Acrobatic and aerobic gymnastics, parkour, and tumbling are other disciplines under the FIG (Fédération Internationale de Gymnastique).",
    "Gymnastics is a foundation for many sports, developing body control, strength, and spatial awareness."]],
  ["Safeguarding",[
    "Gymnastics has faced serious abuse scandals. Former USA Gymnastics team doctor Larry Nassar was sentenced in 2017–18 to what amounts to life in prison after more than 150 women and girls, including Olympians, testified to his sexual abuse. Investigations revealed failures by USA Gymnastics, Michigan State University, and the FBI.",
    "The scandal led to reforms such as the US Center for SafeSport and greater attention to athlete welfare, minimum ages, and abusive coaching cultures worldwide."]]
  ],
  terms:[["All-around","Combined score across all apparatus."],["D-score","Difficulty value of a routine."],["E-score","Execution score with deductions from 10."],["Twisties","Loss of air awareness in twisting skills."],["FIG","International Gymnastics Federation."]],
  w:"Gymnastics combines extraordinary athleticism and artistry, and its scandals reshaped how sport protects athletes.",
  src:["Artistic gymnastics","Nadia Comăneci","Simone Biles","Code of Points (artistic gymnastics)","Larisa Latynina"],
  q:[
  ["Who scored the first perfect 10 in Olympic gymnastics?","Nadia Comăneci","Olga Korbut","Simone Biles","Mary Lou Retton"],
  ["How many apparatus do women compete on in artistic gymnastics?","Four","Six","Five","Three"],
  ["How wide is the balance beam?","10 cm","20 cm","5 cm","15 cm"],
  ["Who won 18 Olympic medals, a record until Phelps?","Larisa Latynina","Věra Čáslavská","Nadia Comăneci","Svetlana Khorkina"],
  ["What replaced the 'perfect 10' in 2006?","Difficulty and execution scores","A 1–5 scale","Judges' rankings only","Time-based scoring"],
  ["Who is called the 'father of gymnastics'?","Friedrich Ludwig Jahn","Per Henrik Ling","Pierre de Coubertin","James Naismith"]]},

{ t:"Cycling", s:"Grand Tours, track, and the bike for all",
  sec:[
  ["The bicycle",[
    "The bicycle evolved from the 'running machine' of Karl von Drais (1817) through the high-wheeled 'penny-farthing' to the 'safety bicycle' of the 1880s with equal wheels and a chain drive. Pneumatic tires (John Boyd Dunlop, 1888) completed the modern design. The bicycle brought cheap mobility and helped women's emancipation; Susan B. Anthony said bicycling had 'done more to emancipate women than anything else in the world.'",
    "Bicycle racing began almost immediately; the first recorded race took place in Paris in 1868."]],
  ["Road racing and the Grand Tours",[
    "Road racing is the most famous form of cycling. The three Grand Tours are three-week stage races: the Tour de France (since 1903, created by the newspaper L'Auto to boost sales), Italy's Giro d'Italia (1909), and Spain's Vuelta a España (1935). Riders compete in daily stages; the overall leader of the Tour wears the yellow jersey (maillot jaune), introduced in 1919.",
    "Other jerseys reward the best sprinter (green in the Tour), best climber (polka dot), and best young rider (white). One-day 'Monuments,' such as Paris–Roubaix over cobblestones and the Tour of Flanders, are prestigious classics."]],
  ["Teams and tactics",[
    "Professional road cycling is a team sport: each team supports a leader. 'Domestiques' fetch water and food and shield the leader from wind; riding in the slipstream (drafting) of others saves up to 30–40% of energy, so riders form a peloton (main pack). Breakaways try to escape the peloton; sprint teams build 'lead-out trains' for their sprinter.",
    "Mountain stages and time trials (individual races against the clock) usually decide the overall classification."]],
  ["Legends and scandals",[
    "Belgium's Eddy Merckx, 'the Cannibal,' won five Tours de France and five Giros and is widely considered the greatest cyclist ever. Jacques Anquetil, Bernard Hinault, and Miguel Induráin also won five Tours. Fausto Coppi and Gino Bartali, Italian rivals, are legends; Bartali secretly helped save Jews during World War II by carrying forged documents in his bicycle frame.",
    "Doping plagued cycling: the 1998 Festina affair, and Lance Armstrong, stripped of his seven Tour titles in 2012 after a US Anti-Doping Agency report described 'the most sophisticated, professionalized and successful doping program that sport has ever seen.' Recent stars include Tadej Pogačar of Slovenia, multiple Tour winner, Jonas Vingegaard of Denmark, and Wout van Aert."]],
  ["Track, mountain bike, and BMX",[
    "Track cycling takes place on a banked oval velodrome, usually 250 m, with events such as the sprint, keirin (from Japan, paced by a motorbike at first), team pursuit, and omnium. Britain's Chris Hoy and Jason Kenny won many Olympic golds.",
    "Mountain biking (Olympic since 1996) and BMX racing (2008) and freestyle (2021) appeal to younger riders. The Hour Record, riding as far as possible in one hour, is a classic test."]],
  ["Women's cycling",[
    "Women's professional cycling has grown, with the Tour de France Femmes launched in 2022. Stars include Marianne Vos of the Netherlands, Annemiek van Vleuten, and Demi Vollering.",
    "Cycling is also a mass activity for commuting and fitness, promoted by cities such as Amsterdam and Copenhagen for health and sustainability."]]
  ],
  terms:[["Grand Tour","Three-week stage race: Tour, Giro, or Vuelta."],["Yellow jersey","Tour de France leader's jersey."],["Peloton","Main pack of riders."],["Domestique","Rider working for the team leader."],["Velodrome","Banked track for track cycling."]],
  w:"Cycling combines individual endurance with team tactics and is also a global form of everyday transport.",
  src:["Tour de France","Eddy Merckx","Peloton","Lance Armstrong doping case","Track cycling"],
  q:[
  ["When was the first Tour de France held?","1903","1869","1919","1936"],
  ["What does the Tour de France leader wear?","Yellow jersey","Pink jersey","Green jersey","Polka dot jersey"],
  ["Who is nicknamed 'the Cannibal'?","Eddy Merckx","Bernard Hinault","Lance Armstrong","Fausto Coppi"],
  ["What is a domestique?","A rider who works for the team leader","A team car","A mountain stage","A sprint jersey"],
  ["Which Grand Tour is held in Italy?","Giro d'Italia","Vuelta","Tour de France","Tour of Flanders"],
  ["How much energy can drafting save?","Up to 30–40%","About 5%","About 80%","None"]]},

{ t:"Rowing, Sailing, and Endurance Multisports", s:"On water and over long distances",
  sec:[
  ["Rowing",[
    "Rowing as a sport developed in England in the 18th and 19th centuries. The Oxford–Cambridge Boat Race on the River Thames has been held since 1829, and the Henley Royal Regatta since 1839. In sweep rowing, each rower holds one oar (pairs, fours, eights with a coxswain who steers and calls the rhythm); in sculling, each rower has two oars (single, double, and quadruple sculls).",
    "Olympic races cover 2,000 meters. Britain's Steve Redgrave won gold at five consecutive Olympics (1984–2000), and Romania's Elisabeta Lipă won medals across eight Olympics."]],
  ["Canoeing and kayaking",[
    "Canoe sprint and canoe slalom (on whitewater, through gates) are Olympic events. Kayakers use double-bladed paddles, while canoeists kneel and use single blades.",
    "These sports have deep roots in Indigenous transport in the Americas and the Arctic; the word kayak comes from Inuit languages."]],
  ["Sailing",[
    "Competitive sailing includes Olympic dinghy and windsurfing classes, offshore races such as the Sydney to Hobart, and round-the-world races. The America's Cup, first contested in 1851 around the Isle of Wight and won by the schooner America, is the oldest trophy in international sport; the New York Yacht Club held it for 132 years until Australia II won in 1983.",
    "Modern America's Cup yachts use hydrofoils to 'fly' above the water at speeds above 50 knots. Kitefoiling joined the Olympics in 2024."]],
  ["Triathlon",[
    "Triathlon combines swimming, cycling, and running in sequence. The first modern triathlon was held in San Diego in 1974; the Ironman, begun in Hawaii in 1978, includes a 3.8 km swim, 180 km bike ride, and full marathon. Olympic triathlon (since 2000) uses 1.5 km, 40 km, and 10 km distances.",
    "Transitions between disciplines are timed, and nutrition and pacing are crucial in long events."]],
  ["Modern pentathlon and multisport",[
    "Modern pentathlon, created by Pierre de Coubertin and debuting at the 1912 Olympics, was designed to test the skills of a 19th-century cavalry officer behind enemy lines: fencing, swimming, horse riding, and a combined run and pistol shoot. After a horse-related controversy at Tokyo 2020, riding is being replaced by an obstacle course from 2028.",
    "Adventure racing, ultra-endurance events, and long-distance open-water swims such as crossing the English Channel (first done by Matthew Webb in 1875) push human endurance further."]]
  ],
  terms:[["Sculling","Rowing with two oars per rower."],["Coxswain","Person who steers and directs a rowing crew."],["America's Cup","Sailing trophy first contested in 1851."],["Ironman","Long-distance triathlon."],["Modern pentathlon","Fencing, swimming, riding, and laser-run."]],
  w:"Water and multisport events test endurance and teamwork, and include some of sport's oldest traditions.",
  src:["Rowing (sport)","The Boat Race","America's Cup","Ironman Triathlon","Modern pentathlon"],
  q:[
  ["Since when has the Oxford–Cambridge Boat Race been held?","1829","1900","1851","1775"],
  ["Who won rowing gold at five consecutive Olympics?","Steve Redgrave","Matthew Pinsent","Elisabeta Lipă","Jack Beresford"],
  ["What is the oldest trophy in international sport?","America's Cup","Stanley Cup","Davis Cup","FA Cup"],
  ["Where did the Ironman triathlon begin in 1978?","Hawaii","California","Florida","Australia"],
  ["Who created the modern pentathlon?","Pierre de Coubertin","Jim Thorpe","Avery Brundage","Baron Ling"],
  ["Who first swam the English Channel in 1875?","Matthew Webb","Gertrude Ederle","Captain Cook","Johnny Weissmuller"]]}

);


/* ---- from sports-13.js ---- */
/* SPORTS FOUNDATIONS, part 13: Unit 7 Combat and Strength Sports */
COURSES.sports.units.push({ t:"Combat and Strength Sports", ch:[

{ t:"Boxing", s:"The sweet science",
  sec:[
  ["From bare knuckles to gloves",[
    "Boxing appears in ancient Greece and Rome, but modern boxing began with 18th-century English prizefighting, a bare-knuckle sport with wrestling holds and rounds that lasted until a man went down. Jack Broughton's rules (1743) and the London Prize Ring Rules (1838) brought some order.",
    "The Marquess of Queensberry Rules (published 1867) required padded gloves, three-minute rounds with one-minute rests, and a ten-second count for knockdowns, creating modern boxing. John L. Sullivan was the last bare-knuckle heavyweight champion and lost the first gloved heavyweight title fight under Queensberry rules to James J. Corbett in 1892."]],
  ["How boxing works",[
    "Boxers fight in a square 'ring' and may hit only with closed gloved fists above the belt. Main punches are the jab (quick lead-hand punch), cross (straight power punch with the rear hand), hook (curved punch), and uppercut (rising punch). Defense includes footwork, blocking, slipping, and the clinch.",
    "A fight can be won by knockout (KO, when a fighter cannot rise by the count of ten), technical knockout (TKO, when the referee stops the fight), or decision by three judges scoring each round, usually on a 10-point must system. Professional title fights last up to 12 rounds."]],
  ["Weight classes and belts",[
    "Boxers compete in weight divisions, from minimumweight (105 lb / 47.6 kg) to heavyweight (over 200 lb / 90.7 kg); the number of divisions has grown to 17 in professional boxing. Fighters often 'cut' weight before weigh-ins.",
    "Professional boxing has multiple sanctioning bodies, chiefly the WBA, WBC, IBF, and WBO, each with its own champion, which confuses fans; an 'undisputed' champion holds all four belts. Amateur and Olympic boxing, now governed by World Boxing, uses three-round bouts."]],
  ["Legends",[
    "Jack Johnson became the first Black world heavyweight champion in 1908, provoking racist backlash. Joe Louis, 'the Brown Bomber,' held the heavyweight title for nearly 12 years (1937–49); his 1938 knockout of German Max Schmeling was seen as a symbolic blow against Nazism. Sugar Ray Robinson is often called the greatest 'pound-for-pound' boxer.",
    "Muhammad Ali (born Cassius Clay) won Olympic gold in 1960 and the heavyweight title in 1964. He refused induction into the US Army in 1967 on religious grounds as a Muslim, opposing the Vietnam War, and was stripped of his title; the Supreme Court overturned his conviction in 1971. His fights against Joe Frazier ('Thrilla in Manila') and George Foreman ('Rumble in the Jungle,' Zaire, 1974, using 'rope-a-dope') are legendary. Later stars include Sugar Ray Leonard, Mike Tyson (youngest heavyweight champion at 20), Floyd Mayweather Jr. (50–0 record), Manny Pacquiao (champion in eight divisions), and Oleksandr Usyk."]],
  ["Women's boxing and safety",[
    "Women's boxing was banned or restricted in many places until the 1990s; it joined the Olympics in 2012, where Ireland's Katie Taylor and Britain's Nicola Adams won gold. Claressa Shields became one of the most decorated boxers of any gender.",
    "Boxing carries serious risks of brain injury, including chronic traumatic encephalopathy (once called 'dementia pugilistica'); Ali developed Parkinson's syndrome. Medical bodies have debated banning boxing, while supporters stress regulation, medical checks, and the sport's role in giving opportunities to young people from poor communities."]]
  ],
  terms:[["Queensberry Rules","1867 rules creating modern gloved boxing."],["Knockout","Win when the opponent can't rise by ten."],["Jab","Quick lead-hand punch."],["Undisputed champion","Holder of all four major belts."],["Pound-for-pound","Ranking boxers regardless of weight."]],
  w:"Boxing's history is intertwined with race, politics, and celebrity, and its techniques underpin all striking sports.",
  src:["Boxing","Muhammad Ali","Joe Louis","Jack Johnson (boxer)","Marquess of Queensberry Rules"],
  q:[
  ["Who was the first Black world heavyweight champion?","Jack Johnson","Joe Louis","Muhammad Ali","Sonny Liston"],
  ["Where was the 'Rumble in the Jungle' held?","Zaire","Philippines","Nigeria","Las Vegas"],
  ["How many rounds are professional title fights?","12","15","10","8"],
  ["What is a TKO?","When the referee stops the fight","A win on points","A disqualification","A draw"],
  ["When did women's boxing join the Olympics?","2012","1996","2004","2020"],
  ["Which boxer retired with a 50–0 record?","Floyd Mayweather Jr.","Rocky Marciano","Manny Pacquiao","Sugar Ray Robinson"]]},

{ t:"Wrestling and Judo", s:"Grappling through the ages",
  sec:[
  ["The oldest sport",[
    "Wrestling may be humanity's oldest sport, depicted in cave art, Egyptian tombs, and Greek vases, and featured in the ancient Olympics. Nearly every culture has its own folk wrestling: Turkish oil wrestling, Mongolian bökh, Swiss Schwingen, Scottish backhold, Senegalese laamb (a hugely popular national sport), Indian kushti, and Icelandic glíma.",
    "Wrestlers aim to throw or pin opponents using holds and leverage rather than strikes."]],
  ["Olympic wrestling",[
    "Olympic wrestling has two styles. In Greco-Roman wrestling, competitors may not attack below the waist or use their legs to trip. In freestyle wrestling, attacks on the legs are allowed. Bouts last two three-minute periods; wrestlers win by pin (fall), by technical superiority (a large points lead), or on points for takedowns, exposures, and reversals.",
    "Russia, Iran, Turkey, Japan, Cuba, and the United States are leading nations. Women's freestyle wrestling joined the Olympics in 2004; Japan's Kaori Icho won four straight golds. Cuban Greco-Roman wrestler Mijaín López won five consecutive Olympic golds (2008–2024)."]],
  ["Sumo",[
    "Sumo, Japan's national sport, has Shinto ritual roots over 1,500 years old. Two rikishi (wrestlers) try to force the other out of a circular ring (dohyō) or make him touch the ground with anything other than the soles of his feet. Bouts often last only seconds.",
    "Professional sumo has six annual tournaments of 15 days. Wrestlers live in training stables under strict rules; the highest rank is yokozuna (grand champion). Foreign wrestlers, particularly from Mongolia, such as Hakuhō (a record 45 tournament titles), have dominated recent decades."]],
  ["Judo",[
    "Judo ('the gentle way') was created in 1882 by Japanese educator Jigorō Kanō, who adapted jujutsu into a sport and educational system emphasizing maximum efficiency and mutual welfare. Practitioners (judoka) wear a white or blue judogi and colored belts indicating rank, up to black belt (dan grades).",
    "Judo contests are won by ippon (a full point), awarded for a clean throw onto the back with force and speed, a 20-second hold-down, or a submission by arm lock or choke. Judo became an Olympic sport in 1964 in Tokyo, where Dutchman Anton Geesink's win in the open category shocked Japan. France has one of the largest judo populations in the world; Teddy Riner won multiple Olympic and many world titles."]],
  ["Brazilian jiu-jitsu",[
    "Brazilian jiu-jitsu (BJJ) developed from judo, brought to Brazil by Mitsuyo Maeda; the Gracie family refined it in the 20th century, emphasizing ground fighting, positional control, and submissions that allow a smaller person to defeat a larger one.",
    "BJJ's success in early mixed martial arts events made it a core skill for MMA fighters and a popular recreational sport worldwide."]],
  ["Professional wrestling",[
    "Professional wrestling (such as WWE) evolved from carnival wrestling into scripted entertainment with predetermined outcomes, characters, and storylines, though athletes perform genuinely risky physical stunts. It is best understood as a form of athletic theater.",
    "Amateur 'folkstyle' wrestling is a major school and college sport in the United States."]]
  ],
  terms:[["Greco-Roman","Wrestling style without attacks below the waist."],["Freestyle","Wrestling style allowing leg attacks."],["Yokozuna","Highest sumo rank."],["Ippon","Full point winning a judo contest."],["Jigorō Kanō","Founder of judo in 1882."]],
  w:"Grappling sports are humanity's oldest contests, and judo and BJJ show how technique can beat size.",
  src:["Wrestling","Greco-Roman wrestling","Sumo","Judo","Brazilian jiu-jitsu"],
  q:[
  ["What is forbidden in Greco-Roman wrestling?","Attacks below the waist","Throws","Pins","Takedowns"],
  ["Who founded judo in 1882?","Jigorō Kanō","Mitsuyo Maeda","Gichin Funakoshi","Morihei Ueshiba"],
  ["What is the highest rank in sumo?","Yokozuna","Ōzeki","Sekiwake","Komusubi"],
  ["What does 'judo' mean?","The gentle way","The empty hand","The way of the sword","The way of harmony"],
  ["Which family refined Brazilian jiu-jitsu?","The Gracies","The Machados","The Kanōs","The Rouseys"],
  ["Which wrestler won five consecutive Olympic golds from 2008 to 2024?","Mijaín López","Aleksandr Karelin","Kaori Icho","Hamid Sourian"]]},

{ t:"Martial Arts, Fencing, and MMA", s:"Ways of fighting",
  sec:[
  ["Karate and taekwondo",[
    "Karate ('empty hand') developed in Okinawa from local fighting methods and Chinese martial arts, and was introduced to mainland Japan in the 1920s by Gichin Funakoshi. It emphasizes punches, kicks, and blocks, practiced in kata (set forms) and kumite (sparring). Karate appeared at the Tokyo 2020 Olympics.",
    "Taekwondo, a Korean martial art developed in the 1940s–50s, emphasizes high, fast, spinning kicks. It became a full Olympic sport in 2000, with electronic scoring sensors in body protectors and headgear."]],
  ["Chinese martial arts and others",[
    "Chinese martial arts (wushu or kung fu) include hundreds of styles, from external styles associated with the Shaolin Temple to internal arts such as tai chi, practiced by millions for health. Bruce Lee popularized kung fu worldwide through films in the early 1970s and developed his own philosophy, Jeet Kune Do.",
    "Other arts include Muay Thai ('the art of eight limbs,' using fists, elbows, knees, and shins), kickboxing, capoeira (Afro-Brazilian art combining fighting and dance), Krav Maga, aikido, and kendo (Japanese sword fencing with bamboo swords)."]],
  ["Fencing",[
    "Fencing descends from European dueling and swordsmanship. Modern fencing has three weapons: foil (target is the torso; 'right of way' rules decide who scored), épée (the whole body is a target; no right of way; simultaneous hits count for both), and sabre (cutting and thrusting; target above the waist; right of way). Hits are recorded electronically.",
    "Fencing has been in every modern Olympics since 1896. Italy, France, Hungary, and Russia have strong traditions; Hungary's Aladár Gerevich won sabre golds across six Olympics."]],
  ["Mixed martial arts",[
    "Mixed martial arts (MMA) allows striking and grappling. The Ultimate Fighting Championship (UFC) began in 1993 as a no-holds-barred contest between styles, won by Royce Gracie using Brazilian jiu-jitsu. Under pressure from regulators, the Unified Rules of MMA (2000s) introduced weight classes, rounds, gloves, and banned techniques.",
    "MMA fighters must combine wrestling, BJJ, boxing, and kickboxing. Fights are won by knockout, submission, or decision. Stars include Georges St-Pierre, Anderson Silva, Jon Jones, Khabib Nurmagomedov (29–0), Conor McGregor, Amanda Nunes, and Ronda Rousey, who helped bring women into the UFC in 2013."]],
  ["Philosophy and practice",[
    "Many martial arts emphasize discipline, respect, self-control, and personal development, not just fighting. Belt and grading systems mark progress, and practice in a dojo (training hall) follows etiquette such as bowing.",
    "Martial arts are popular for self-defense, fitness, and confidence-building, especially among children."]]
  ],
  terms:[["Kata","Set pattern of martial arts movements."],["Taekwondo","Korean kicking martial art, Olympic since 2000."],["Épée","Fencing weapon with full-body target."],["Muay Thai","Thai 'art of eight limbs.'"],["MMA","Mixed martial arts combining striking and grappling."]],
  w:"Martial arts carry philosophies as well as techniques, and MMA has made them a global spectator sport.",
  src:["Karate","Taekwondo","Fencing","Mixed martial arts","Ultimate Fighting Championship"],
  q:[
  ["What does 'karate' mean?","Empty hand","Gentle way","Way of the sword","Art of eight limbs"],
  ["Which fencing weapon allows the whole body as a target?","Épée","Foil","Sabre","All of them"],
  ["Who won the first UFC tournament in 1993?","Royce Gracie","Ken Shamrock","Dan Severn","Chuck Liddell"],
  ["Which art is called 'the art of eight limbs'?","Muay Thai","Kickboxing","Kung fu","Capoeira"],
  ["When did taekwondo become a full Olympic sport?","2000","1988","2012","1964"],
  ["Who popularized kung fu worldwide through films in the 1970s?","Bruce Lee","Jackie Chan","Jet Li","Chuck Norris"]]},

{ t:"Weightlifting and Strength Sports", s:"Lifting the impossible",
  sec:[
  ["Olympic weightlifting",[
    "Olympic weightlifting tests explosive strength and technique with two lifts. In the snatch, the barbell is lifted from the floor to overhead in one continuous movement. In the clean and jerk, it is lifted to the shoulders (the clean), then driven overhead (the jerk). Each lifter gets three attempts at each lift; the total of the best attempts decides the winner within each bodyweight category.",
    "Georgia's Lasha Talakhadze has set super-heavyweight world records with totals around 490 kg. Weightlifting has been plagued by doping, leading the IOC to reduce its Olympic places and demand reforms."]],
  ["Powerlifting",[
    "Powerlifting tests maximal strength in three lifts: the squat, bench press, and deadlift. It is not an Olympic sport, but Para powerlifting (bench press for athletes with lower-body impairments) is a Paralympic event.",
    "Equipment categories ('raw' or 'equipped' with supportive suits) and drug-tested federations divide the sport."]],
  ["Strongman and Highland games",[
    "Strongman competitions, such as the World's Strongest Man (since 1977), test strength with events like the Atlas stones, truck pulls, log press, and farmer's walk. Iceland's Magnús Ver Magnússon and Hafþór Björnsson, Poland's Mariusz Pudzianowski (five titles), and Britain's Eddie Hall (first to deadlift 500 kg) became famous.",
    "Scottish Highland games include caber tossing (flipping a long log end over end), stone put, and hammer throw, in a tradition going back centuries."]],
  ["Bodybuilding",[
    "Bodybuilding is judged on muscular size, symmetry, and definition rather than strength. Eugen Sandow popularized it around 1900; Arnold Schwarzenegger won the Mr. Olympia title seven times and became a film star and governor of California.",
    "The sport has faced criticism over extreme diets, dehydration, and drug use."]],
  ["Strength training for all",[
    "Resistance training is now recognized as important for everyone's health: it builds muscle, strengthens bones, improves metabolism, and helps prevent falls in older age. Health guidelines, such as those of the World Health Organization, recommend muscle-strengthening activities at least twice a week for adults.",
    "Proper technique, gradual progression, and rest are key to lifting safely."]]
  ],
  terms:[["Snatch","Lift from floor to overhead in one motion."],["Clean and jerk","Lift to shoulders, then overhead."],["Powerlifting","Squat, bench press, and deadlift."],["Strongman","Strength contests with unusual objects."],["Resistance training","Exercise against force to build strength."]],
  w:"Strength sports show the limits of human power, and strength training benefits health at every age.",
  src:["Olympic weightlifting","Powerlifting","World's Strongest Man","Bodybuilding","Strength training"],
  q:[
  ["What are the two lifts in Olympic weightlifting?","Snatch and clean and jerk","Squat and deadlift","Bench press and squat","Press and snatch"],
  ["Which three lifts make up powerlifting?","Squat, bench press, deadlift","Snatch, clean, jerk","Press, curl, row","Squat, snatch, press"],
  ["What is tossed end over end in the Highland games?","The caber","The hammer","A stone","A log press"],
  ["Who won Mr. Olympia seven times and became governor of California?","Arnold Schwarzenegger","Ronnie Coleman","Lou Ferrigno","Eugen Sandow"],
  ["How often does the WHO recommend muscle-strengthening activities for adults?","At least twice a week","Once a month","Daily for hours","Never"],
  ["Who was first to deadlift 500 kg?","Eddie Hall","Hafþór Björnsson","Mariusz Pudzianowski","Brian Shaw"]]}

]});


/* ---- from sports-14.js ---- */
/* SPORTS FOUNDATIONS, part 14: Unit 8 Speed, Snow, and New Frontiers, chapters 1-4 */
COURSES.sports.units.push({ t:"Speed, Snow, and New Frontiers", ch:[

{ t:"Formula One", s:"The pinnacle of motorsport",
  sec:[
  ["Origins",[
    "Motor racing began almost as soon as the automobile: the Paris–Rouen trial of 1894 and the first Grand Prix, held by the Automobile Club de France in 1906. The Formula One World Championship began in 1950 at Silverstone, England; 'Formula' refers to the set of rules all cars must meet.",
    "F1 is governed by the FIA (Fédération Internationale de l'Automobile), with commercial rights owned by Liberty Media since 2017."]],
  ["How a Grand Prix works",[
    "A Grand Prix weekend includes practice sessions, qualifying (a knockout format that decides the starting grid), and the race of about 305 km (or two hours). Points are awarded to the top ten finishers (25 for a win). Some weekends add a shorter sprint race.",
    "Two championships run in parallel: the Drivers' Championship and the Constructors' Championship for teams. Each team runs two cars, designs its own chassis, and uses a power unit from a manufacturer such as Mercedes, Ferrari, Honda, or Renault."]],
  ["Technology and strategy",[
    "F1 cars are marvels of engineering: hybrid V6 turbo engines (since 2014) producing around 1,000 horsepower, carbon-fiber chassis, and aerodynamics generating enough downforce, in theory, to drive upside down at high speed. DRS (drag reduction system) opens a rear wing flap to help overtaking.",
    "Tire strategy is central: Pirelli supplies compounds of different grip and durability, and drivers must make pit stops, where crews change all four tires in about two seconds. Teams use simulators and real-time data to choose when to stop. A budget cap was introduced in 2021 to limit spending. New regulations from 2026 changed engines and aerodynamics significantly."]],
  ["Legends and teams",[
    "Juan Manuel Fangio won five titles in the 1950s. Jim Clark, Jackie Stewart (who campaigned for safety), Niki Lauda (who returned to racing weeks after a near-fatal fire in 1976), Alain Prost, and Ayrton Senna, killed at Imola in 1994, are legends; the Senna–Prost rivalry was among sport's fiercest. Michael Schumacher won seven titles with Benetton and Ferrari.",
    "Lewis Hamilton, the sport's first Black driver, matched Schumacher's seven titles and holds records for most wins and pole positions; he joined Ferrari in 2025. Max Verstappen dominated with Red Bull from 2021 to 2024. Ferrari is the oldest and most successful team; McLaren, Williams, Mercedes, and Red Bull have had dominant eras."]],
  ["Safety",[
    "Early F1 was deadly: dozens of drivers died in its first decades. Safety improvements, championed by Jackie Stewart and later by FIA medical delegate Sid Watkins, include crash structures, run-off areas, barriers, HANS devices protecting the neck, and the 'halo' cockpit protection (2018), which saved Romain Grosjean in a fiery 2020 crash.",
    "Jules Bianchi's death after a 2014 crash in Japan was the first F1 driver fatality from a race incident since Senna's."]],
  ["F1 today",[
    "Races take place worldwide, from historic circuits such as Monaco (a tight street circuit since 1929), Monza, Spa, and Silverstone, to new venues in the Middle East, Asia, and the US, including night races in Singapore and Las Vegas. The Netflix series Drive to Survive (from 2019) greatly expanded F1's audience, especially in the US.",
    "F1 Academy and other programs aim to bring more women into the sport, which has had very few female drivers."]]
  ],
  terms:[["FIA","International governing body of motorsport."],["Constructors' Championship","Team title in F1."],["Downforce","Aerodynamic force pressing the car to the track."],["Pit stop","Stop for tires and adjustments."],["Halo","Cockpit protection device introduced in 2018."]],
  w:"Formula One combines driver skill, engineering, and strategy, and its safety innovations have saved lives.",
  src:["Formula One","Ayrton Senna","Lewis Hamilton","Michael Schumacher","Halo (safety device)"],
  q:[
  ["Where was the first Formula One World Championship race held in 1950?","Silverstone","Monaco","Monza","Spa"],
  ["How many points does a Grand Prix winner receive?","25","10","20","30"],
  ["Which driver died at Imola in 1994?","Ayrton Senna","Niki Lauda","Jim Clark","Jules Bianchi"],
  ["Which device saved Romain Grosjean in 2020?","The halo","DRS","HANS only","The roll bar"],
  ["Which drivers share the record of seven world titles?","Lewis Hamilton and Michael Schumacher","Senna and Prost","Fangio and Vettel","Verstappen and Hamilton"],
  ["Which is the oldest and most successful F1 team?","Ferrari","McLaren","Williams","Mercedes"]]},

{ t:"Other Motorsports", s:"Ovals, rallies, and two wheels",
  sec:[
  ["IndyCar and the Indianapolis 500",[
    "The Indianapolis 500, first run in 1911 at the Indianapolis Motor Speedway, is one of the world's most famous races; 500 miles on an oval at speeds averaging over 350 km/h on fast laps, watched by more than 300,000 spectators, making it the largest single-day sporting event. The winner traditionally drinks milk.",
    "The Indy 500, the Monaco Grand Prix, and the 24 Hours of Le Mans form the unofficial 'Triple Crown of Motorsport'; only Graham Hill has won all three."]],
  ["NASCAR",[
    "NASCAR (National Association for Stock Car Auto Racing), founded in 1948 in Daytona Beach, Florida, grew from moonshine runners in the American South who modified their cars to outrun police. Races, mostly on oval tracks, feature heavy 'stock cars,' close pack racing, and drafting.",
    "The Daytona 500 is its most prestigious race. Richard Petty ('The King') and Dale Earnhardt Sr. (killed on the last lap of the 2001 Daytona 500) each won seven championships, as did Jimmie Johnson. Wendell Scott was the first Black driver to win a top-level NASCAR race (1963)."]],
  ["Endurance racing",[
    "Endurance races test cars and teams of drivers over many hours. The 24 Hours of Le Mans in France, first run in 1923, is the most famous; Porsche, Audi, Ferrari, and Toyota have been successful manufacturers. Ford's victory over Ferrari in 1966 was dramatized in the film Ford v Ferrari.",
    "The 1955 Le Mans disaster, in which a car crashed into the crowd and killed more than 80 spectators, remains motorsport's deadliest accident."]],
  ["Rallying and off-road",[
    "Rally drivers race against the clock on closed public roads, gravel, snow, and tarmac, with a co-driver reading 'pace notes.' The World Rally Championship began in 1973; Sébastien Loeb and Sébastien Ogier of France have won the most titles. The Dakar Rally, a grueling off-road race, began in 1978 from Paris to Dakar and now runs in Saudi Arabia.",
    "Rallycross, drifting, and hill climbs are other disciplines; karting is the training ground for nearly all top drivers."]],
  ["Motorcycle racing",[
    "MotoGP, the premier class of Grand Prix motorcycle racing (world championship since 1949), features prototype bikes reaching over 350 km/h, with riders leaning at extreme angles through corners. Giacomo Agostini won 15 world titles; Valentino Rossi became one of motorsport's most popular figures; Marc Márquez is a modern great.",
    "The Isle of Man TT, held on public roads since 1907, is famous and notoriously dangerous. Superbikes, motocross, speedway, and trials are other forms."]],
  ["Electric and future motorsport",[
    "Formula E, an all-electric single-seater series, began in 2014, racing mostly on city street circuits. Motorsport has served as a laboratory for technologies later used in road cars, from disc brakes to hybrid systems.",
    "Debates continue about motorsport's environmental impact, with series exploring sustainable fuels."]]
  ],
  terms:[["Indy 500","500-mile race at Indianapolis, since 1911."],["Stock car","Heavy race car based on production models."],["Pace notes","Co-driver's descriptions of the road in rallying."],["Le Mans","24-hour endurance race in France."],["MotoGP","Premier motorcycle Grand Prix class."]],
  w:"Motorsport's many forms reflect national cultures and drive technological innovation.",
  src:["Indianapolis 500","NASCAR","24 Hours of Le Mans","World Rally Championship","Grand Prix motorcycle racing"],
  q:[
  ["What does the Indy 500 winner traditionally drink?","Milk","Champagne","Water","Orange juice"],
  ["Who is the only driver to win the Triple Crown of Motorsport?","Graham Hill","Mario Andretti","Fernando Alonso","A. J. Foyt"],
  ["Where was NASCAR founded in 1948?","Daytona Beach","Indianapolis","Charlotte","Talladega"],
  ["When was the first 24 Hours of Le Mans?","1923","1906","1950","1955"],
  ["Who won 15 motorcycle world titles?","Giacomo Agostini","Valentino Rossi","Marc Márquez","Mike Hailwood"],
  ["What is Formula E?","An all-electric single-seater series","An endurance series","A karting series","A motorcycle series"]]},

{ t:"Horse Racing and Equestrian Sports", s:"The sport of kings",
  sec:[
  ["Thoroughbred racing",[
    "Horse racing is among the oldest sports, practiced in ancient Greece, Rome, Central Asia, and the Middle East. Modern thoroughbred racing developed in 17th–18th century England; all thoroughbreds descend from three foundation stallions imported from the Middle East: the Byerley Turk, the Darley Arabian, and the Godolphin Arabian.",
    "Newmarket is the historic home of British racing. Flat racing has no obstacles; jump racing (National Hunt) has hurdles and fences, as in the Grand National at Aintree (since 1839), famous for its huge fences."]],
  ["Great races",[
    "England's five Classics for three-year-olds include the Epsom Derby (1780) and the 2,000 Guineas; Royal Ascot is a social and racing highlight. In the US, the Triple Crown consists of the Kentucky Derby (since 1875, 'the most exciting two minutes in sports'), the Preakness Stakes, and the Belmont Stakes; only 13 horses have won it, including Secretariat (1973), who won the Belmont by 31 lengths in record time, and Justify (2018).",
    "Other major races include France's Prix de l'Arc de Triomphe, Australia's Melbourne Cup ('the race that stops a nation'), the Dubai World Cup, and Japan's Japan Cup."]],
  ["Betting and welfare",[
    "Betting has always been central to racing's economics, through bookmakers and the pari-mutuel (tote) system. Jockeys must meet strict weight limits. Legendary jockeys include Lester Piggott, Frankie Dettori, A. P. McCoy (20 consecutive British jump champion titles), and Rachael Blackmore, who in 2021 became the first woman to win the Grand National.",
    "Animal welfare is a major issue: horse fatalities, whip use, and doping of horses have prompted reforms and protests."]],
  ["Olympic equestrian",[
    "Equestrian events, the only Olympic sports where men and women compete directly against each other and where humans partner with animals, include dressage (precise, elegant movements, sometimes called 'horse ballet'), show jumping (clearing a course of fences without faults), and eventing (combining dressage, cross-country, and jumping).",
    "Germany, Britain, and the Netherlands are strong nations. Equestrian sport faced scrutiny after a British dressage rider was suspended before Paris 2024 over a video showing her whipping a horse."]],
  ["Other horse sports",[
    "Polo, played on horseback with mallets, is strongest in Argentina, home to the world's best players. Harness racing uses horses pulling two-wheeled sulkies. Rodeo, rooted in ranch work in the American West and Mexico (charrería), includes bull and bronc riding.",
    "Central Asian games such as buzkashi (Afghanistan), where riders compete to carry a goat carcass to a goal, preserve ancient nomadic traditions."]]
  ],
  terms:[["Thoroughbred","Racing breed descended from three Arabian stallions."],["Triple Crown","Kentucky Derby, Preakness, Belmont."],["Dressage","Precise, judged movements by horse and rider."],["Eventing","Dressage, cross-country, and jumping combined."],["Pari-mutuel","Pool betting system."]],
  w:"Horse sports link ancient traditions to modern betting and Olympic competition, and raise questions about animal welfare.",
  src:["Horse racing","Triple Crown of Thoroughbred Racing","Secretariat (horse)","Equestrian at the Summer Olympics","Grand National"],
  q:[
  ["Which horse won the Belmont Stakes by 31 lengths in 1973?","Secretariat","Seabiscuit","Justify","American Pharoah"],
  ["Which race is called 'the race that stops a nation'?","Melbourne Cup","Kentucky Derby","Grand National","Epsom Derby"],
  ["Who became the first woman to win the Grand National in 2021?","Rachael Blackmore","Hayley Turner","Julie Krone","Bryony Frost"],
  ["What are the three US Triple Crown races?","Kentucky Derby, Preakness, Belmont","Derby, Oaks, St Leger","Arc, Derby, Melbourne Cup","Breeders' Cup, Derby, Preakness"],
  ["What is unique about Olympic equestrian events?","Men and women compete directly against each other","They have no judges","They are untimed","They use only ponies"],
  ["Which country produces the world's best polo players?","Argentina","England","India","USA"]]},

{ t:"Winter Sports on Snow", s:"Skiing and snowboarding",
  sec:[
  ["Origins",[
    "Skis have been used for travel in snowy regions for thousands of years; ancient skis found in Russia and Scandinavia date back about 8,000 years. Norway is the cradle of modern skiing: Sondre Norheim of Telemark developed improved bindings and techniques in the 1860s, and Fridtjof Nansen's 1888 crossing of Greenland on skis inspired enthusiasm.",
    "The Winter Olympics began at Chamonix, France, in 1924. Norway is the most successful nation in Winter Olympic history."]],
  ["Nordic skiing",[
    "Nordic skiing includes cross-country skiing (classic and skating styles), ski jumping (flying from a large hill, judged on distance and style; the V-style became standard in the 1990s), and Nordic combined (cross-country plus jumping). Biathlon adds rifle shooting to cross-country skiing.",
    "Cross-country skiers are among the fittest athletes in the world, with exceptional aerobic capacity. Norway's Marit Bjørgen won 15 Winter Olympic medals and Bjørn Dæhlie 12."]],
  ["Alpine skiing",[
    "Alpine skiing, racing downhill through gates, developed in the Alps in the early 20th century; Briton Arnold Lunn organized the first slalom in 1922. Disciplines range from the fastest, downhill (speeds above 130 km/h), and super-G, to the technical giant slalom and slalom, with tightly spaced gates. The combined event tests both.",
    "The World Cup circuit, begun in 1967, runs each winter. Legends include Jean-Claude Killy (three golds in 1968), Ingemar Stenmark (86 World Cup wins), Hermann Maier, Lindsey Vonn, and Mikaela Shiffrin, who in 2023 passed Stenmark's record for World Cup wins and went on to over 100."]],
  ["Freestyle and snowboarding",[
    "Freestyle skiing includes moguls (bumpy courses with jumps), aerials (acrobatic flips), ski cross (racing in groups), halfpipe, slopestyle, and big air. Snowboarding, developed in the US in the 1960s–70s (the 'Snurfer' and pioneers such as Jake Burton Carpenter), entered the Olympics in 1998.",
    "Shaun White won three Olympic halfpipe golds; Chloe Kim won golds in 2018 and 2022. These disciplines brought youth culture and action-sports style to the Winter Games."]],
  ["Mountains and safety",[
    "Ski resorts transformed Alpine valleys and mountain towns into tourist economies. Avalanche safety, helmets, and slope rules are crucial; backcountry skiing requires training in avalanche awareness and rescue equipment.",
    "Climate change is reducing natural snowfall in many regions, raising concerns about the future of winter sports and increasing reliance on artificial snow."]]
  ],
  terms:[["Nordic skiing","Cross-country, jumping, and combined events."],["Alpine skiing","Downhill racing through gates."],["Slalom","Technical race through closely spaced gates."],["Biathlon","Cross-country skiing plus shooting."],["Halfpipe","U-shaped course for freestyle tricks."]],
  w:"Skiing grew from ancient transport into a global sport, now facing the challenge of a warming climate.",
  src:["Skiing","Alpine skiing","Cross-country skiing","Snowboarding","Mikaela Shiffrin"],
  q:[
  ["Where were the first Winter Olympics held in 1924?","Chamonix","St. Moritz","Lake Placid","Oslo"],
  ["Which country is the most successful in Winter Olympic history?","Norway","USA","Germany","Austria"],
  ["Which is the fastest Alpine discipline?","Downhill","Slalom","Giant slalom","Super combined"],
  ["Who passed Ingemar Stenmark's record for World Cup wins in 2023?","Mikaela Shiffrin","Lindsey Vonn","Marcel Hirscher","Lara Gut-Behrami"],
  ["When did snowboarding enter the Olympics?","1998","1988","2002","1992"],
  ["What does biathlon combine?","Cross-country skiing and rifle shooting","Skiing and skating","Jumping and slalom","Snowboarding and skiing"]]}

]});


/* ---- from sports-15.js ---- */
/* SPORTS FOUNDATIONS, part 15: Unit 8 chapters 5-8 */
COURSES.sports.units[7].ch.push(

{ t:"Ice and Sliding Sports", s:"Skating, sledding, and curling",
  sec:[
  ["Figure skating",[
    "Figure skating combines athletic jumps and spins with artistry, performed to music. The name comes from the figures (patterns) skaters once traced on the ice. Events include men's and women's singles, pairs, and ice dance (without big jumps or lifts above the head, emphasizing rhythm and partnering).",
    "Jumps include the axel (the only jump with a forward takeoff, adding an extra half rotation), lutz, flip, loop, salchow, and toe loop. The quadruple jump (four rotations) became essential for top men; in 2022 Ilia Malinin of the US landed the first quadruple axel in competition. Since the 2002 Salt Lake City judging scandal, scoring uses the International Judging System, with technical elements and program components. Legends include Sonja Henie, Dick Button, Katarina Witt, Torvill and Dean (whose 'Boléro' ice dance received perfect scores in 1984), Yuna Kim, and Yuzuru Hanyu."]],
  ["Speed skating",[
    "Long-track speed skating races take place on a 400-meter oval, with skaters racing in pairs against the clock. The Netherlands is the dominant nation, where skating is a national passion; Ireen Wüst won medals at five Olympics. Clap skates, with a hinged blade, revolutionized the sport in the late 1990s.",
    "Short-track speed skating, on a 111-meter track with skaters racing in packs, features crashes and tactics; South Korea, China, Canada, and the Netherlands are strong."]],
  ["Sliding sports",[
    "Bobsleigh (bobsled) teams of two or four push a sled at the start, then jump in and steer down an icy track at speeds over 140 km/h. In luge, athletes slide feet first lying on their backs; in skeleton, head first on their stomachs, a terrifying experience at high speed.",
    "The Jamaican bobsled team at the 1988 Calgary Olympics, inspiration for the film Cool Runnings, became a beloved underdog story. Germany dominates sliding sports with many tracks and strong funding."]],
  ["Curling",[
    "Curling originated in 16th-century Scotland on frozen ponds. Teams of four slide 20-kilogram granite stones (many made from granite from Ailsa Craig, a Scottish island) toward a target called the house. Sweepers brush the ice in front of the moving stone to make it travel farther and straighter; 'curl' refers to the stone's curving path.",
    "Curling is often called 'chess on ice' for its strategy. Canada is the leading curling nation; mixed doubles joined the Olympics in 2018. The sport is famous for its etiquette and sportsmanship."]],
  ["Ice sports culture",[
    "Ice sports are popular in cold-climate nations, from Dutch canal skating, including the legendary 200-km Elfstedentocht race (last held in 1997 because the canals rarely freeze thick enough), to Canadian backyard rinks.",
    "Indoor rinks spread ice sports worldwide; figure skating is hugely popular in Japan, South Korea, China, and Russia."]]
  ],
  terms:[["Axel","Figure-skating jump with forward takeoff."],["Quad","Jump with four rotations."],["Short track","Pack speed skating on a 111 m track."],["Skeleton","Head-first sled racing."],["House","Curling's circular target."]],
  w:"Ice sports blend speed, danger, artistry, and strategy, and are central to Winter Olympic drama.",
  src:["Figure skating","Speed skating","Bobsleigh","Curling","Jamaica national bobsleigh team"],
  q:[
  ["Which figure skating jump has a forward takeoff?","Axel","Lutz","Salchow","Toe loop"],
  ["Who landed the first quadruple axel in competition?","Ilia Malinin","Yuzuru Hanyu","Nathan Chen","Kaori Sakamoto"],
  ["Which country dominates long-track speed skating?","Netherlands","Norway","USA","Canada"],
  ["In which sliding sport do athletes go head first?","Skeleton","Luge","Bobsleigh","Toboggan"],
  ["Where did curling originate?","Scotland","Canada","Norway","Switzerland"],
  ["Which team inspired the film Cool Runnings?","The Jamaican bobsled team","The Canadian curling team","The Dutch skating team","The Swiss luge team"]]},

{ t:"Action and Adventure Sports", s:"Boards, waves, and walls",
  sec:[
  ["Surfing",[
    "Surfing originated in Polynesia, especially Hawaii, where riding waves (he'e nalu) held cultural and spiritual importance for both commoners and royalty. Hawaiian Olympic swimmer Duke Kahanamoku popularized surfing worldwide in the early 20th century, demonstrating it in Australia and California.",
    "Surfing culture boomed in the 1950s–60s, with films and music such as the Beach Boys. Professional surfing tours began in the 1970s; Kelly Slater won 11 world titles. Surfing joined the Olympics at Tokyo 2020; the Paris 2024 event was held at Teahupo'o in Tahiti. Big-wave surfers ride giants of over 20 meters at spots such as Nazaré, Portugal."]],
  ["Skateboarding",[
    "Skateboarding began in 1950s California as 'sidewalk surfing.' The Z-Boys of Venice skated empty swimming pools during the 1970s drought, inventing vertical skating; Tony Hawk landed the first '900' (two and a half rotations) in 1999 and became the face of the sport.",
    "Skateboarding's street and park disciplines entered the Olympics in 2021, with some medalists in their early teens, such as Japan's Momiji Nishiya (13) and Britain's Sky Brown (13). Skate culture influences fashion, music, and art."]],
  ["Climbing",[
    "Rock climbing grew from mountaineering in the 19th and 20th centuries. Sport climbing, using fixed bolts for protection, and bouldering (short routes without ropes over crash pads) became hugely popular with indoor climbing gyms. Competition climbing entered the Olympics in 2021, with speed, bouldering, and lead disciplines.",
    "In 2017, Alex Honnold climbed El Capitan in Yosemite free solo (without ropes), shown in the Oscar-winning film Free Solo. Mountaineering's great feats include the first ascent of Everest by Edmund Hillary and Tenzing Norgay in 1953."]],
  ["Extreme sports",[
    "The X Games, launched by ESPN in 1995, showcased skateboarding, BMX, motocross, and snowboarding. Other action sports include windsurfing, kitesurfing, wakeboarding, parkour, freediving, base jumping, paragliding, and mountain biking.",
    "Action sports emphasize creativity, style, and self-expression over rigid rules, and communities often value progression and risk-taking. Their inclusion in the Olympics has been part of an effort to attract younger audiences, sometimes debated by participants worried about losing their countercultural spirit."]],
  ["Risk and safety",[
    "Adventure sports carry real risks; helmets, training, gradual progression, and respect for conditions such as weather and tides are essential. Many athletes speak of 'flow,' a state of total absorption described by psychologist Mihaly Csikszentmihalyi, as part of the attraction.",
    "Outdoor and adventure sports also connect participants with nature and environmental causes, such as ocean conservation in surfing."]]
  ],
  terms:[["He'e nalu","Hawaiian wave sliding, the origin of surfing."],["Bouldering","Short climbs without ropes over pads."],["Free solo","Climbing without ropes or protection."],["X Games","Extreme sports competition launched in 1995."],["Flow","State of total absorption in an activity."]],
  w:"Action sports represent sport's creative, youthful frontier and now share the Olympic stage.",
  src:["Surfing","Duke Kahanamoku","Skateboarding","Sport climbing","X Games"],
  q:[
  ["Who popularized surfing worldwide in the early 20th century?","Duke Kahanamoku","Kelly Slater","Tony Hawk","Laird Hamilton"],
  ["Who landed the first '900' in skateboarding in 1999?","Tony Hawk","Rodney Mullen","Stacy Peralta","Nyjah Huston"],
  ["Who free-soloed El Capitan in 2017?","Alex Honnold","Tommy Caldwell","Adam Ondra","Chris Sharma"],
  ["When did surfing, skateboarding, and climbing debut at the Olympics?","Tokyo 2020 (held 2021)","London 2012","Rio 2016","Paris 2024"],
  ["Who made the first ascent of Everest in 1953?","Edmund Hillary and Tenzing Norgay","George Mallory and Andrew Irvine","Reinhold Messner","Junko Tabei"],
  ["Which TV network launched the X Games in 1995?","ESPN","NBC","MTV","Fox"]]},

{ t:"Esports and Mind Sports", s:"Competition beyond the body",
  sec:[
  ["Chess",[
    "Chess, which developed from the Indian game chaturanga around the 6th century and spread through Persia and the Arab world to Europe, is the most famous mind sport. Official world champions date from 1886 (Wilhelm Steinitz). The Soviet Union dominated for decades; the 1972 match in Reykjavík between American Bobby Fischer and Soviet Boris Spassky became a Cold War sensation.",
    "Garry Kasparov was champion from 1985 to 2000, and lost a famous 1997 match to IBM's Deep Blue computer. Magnus Carlsen of Norway was world champion from 2013 to 2023 and has the highest-ever rating. Online chess boomed during the COVID-19 pandemic and after the series The Queen's Gambit (2020); India's D. Gukesh became the youngest undisputed world champion in 2024 at 18."]],
  ["Other mind sports",[
    "Go (weiqi/baduk), an ancient East Asian board game of territory, is far more complex than chess in the number of possible positions; in 2016 DeepMind's AlphaGo defeated top professional Lee Sedol, a landmark in artificial intelligence. Bridge, a partnership card game, and poker, which combines skill and chance, have professional competitions.",
    "The IOC recognizes chess and bridge federations, and chess has appeared at the Asian Games."]],
  ["The rise of esports",[
    "Esports (electronic sports) are organized video game competitions. Early events include a 1972 Spacewar! tournament at Stanford and the 1980 Space Invaders Championship. In the late 1990s and 2000s, South Korea built a professional StarCraft scene with televised leagues and celebrity players, a model for the industry.",
    "Today's major esports include League of Legends (whose World Championship draws huge online audiences; South Korea's Faker is its most famous player), Dota 2 (with The International's multimillion-dollar prize pools), Counter-Strike, Valorant, Fortnite, and sports games like EA Sports FC."]],
  ["How esports work",[
    "Esports teams have coaches, analysts, and sports psychologists; players train for many hours a day, refining reflexes (actions per minute), game knowledge, and teamwork. Leagues may be franchise-based or open, and events fill arenas while streaming platforms such as Twitch and YouTube carry them to millions.",
    "Universities offer esports scholarships. Esports debuted as a medal event at the 2022 Asian Games, and the IOC has explored an Olympic Esports Games."]],
  ["Are they sports?",[
    "Debates continue over whether esports and mind sports are 'real' sports, since they lack major physical exertion. Supporters point to the skill, training, competition, and organized structures they share with traditional sports; critics stress that physical activity is essential to sport.",
    "Concerns about esports include health issues from sedentary play, burnout, gambling, and harassment, while supporters highlight community, accessibility, and new career paths."]]
  ],
  terms:[["Mind sport","Game of skill without physical exertion."],["Deep Blue","IBM computer that beat Kasparov in 1997."],["AlphaGo","AI that beat Lee Sedol at Go in 2016."],["Esports","Competitive video gaming."],["APM","Actions per minute, a measure of speed."]],
  w:"Mind sports and esports extend competition into the digital age and challenge definitions of sport.",
  src:["Chess","Esports","Deep Blue versus Garry Kasparov","AlphaGo versus Lee Sedol","League of Legends World Championship"],
  q:[
  ["Which computer defeated Garry Kasparov in 1997?","Deep Blue","AlphaGo","Watson","Stockfish"],
  ["Who became the youngest undisputed world chess champion in 2024?","D. Gukesh","Magnus Carlsen","Hikaru Nakamura","Ding Liren"],
  ["Where was the 1972 Fischer–Spassky match held?","Reykjavík","Moscow","New York","Geneva"],
  ["Which country built the first major professional esports scene with StarCraft?","South Korea","USA","China","Japan"],
  ["At which event did esports debut as a medal event in 2022?","Asian Games","Olympics","Commonwealth Games","World Games"],
  ["What did AlphaGo achieve in 2016?","It defeated top Go professional Lee Sedol","It won a chess championship","It won at poker","It designed a video game"]]},

{ t:"The Paralympics and Disability Sport", s:"Excellence without limits",
  sec:[
  ["Origins",[
    "Organized disability sport grew after World War II. In 1948, neurologist Ludwig Guttmann at Stoke Mandeville Hospital in England, who treated soldiers with spinal injuries, organized the Stoke Mandeville Games for wheelchair athletes on the opening day of the London Olympics, using sport as rehabilitation.",
    "The first Paralympic Games were held in Rome in 1960, with 400 athletes from 23 countries. The Winter Paralympics began in 1976. Since Seoul 1988, the Paralympics have been held in the same city and venues as the Olympics, shortly after them."]],
  ["Classification",[
    "The International Paralympic Committee (IPC), founded in 1989, governs the movement. Athletes compete in classes grouping those with similar levels of impairment, so competition is fair; eligible impairment types include physical impairments, visual impairment, and intellectual impairment.",
    "Classification is complex and sometimes controversial, but central to the idea that results should reflect skill, training, and effort rather than degree of impairment."]],
  ["Sports and adaptations",[
    "Paralympic sports include athletics (with racing wheelchairs and running blades), swimming, wheelchair basketball, wheelchair rugby ('murderball'), wheelchair tennis, sitting volleyball, goalball (for visually impaired athletes, with a ball containing bells), boccia, para cycling, and para ice hockey.",
    "Visually impaired runners compete with sighted guides tethered to them; blind footballers use a ball with a rattle."]],
  ["Champions",[
    "American swimmer Trischa Zorn won 55 Paralympic medals, the most of any athlete. Britain's Tanni Grey-Thompson won 11 wheelchair racing golds; Dutch wheelchair tennis player Esther Vergeer won 470 consecutive matches; Brazil's Daniel Dias and China's many champions have dominated swimming and athletics.",
    "South African sprinter Oscar Pistorius, a double amputee, competed in the 2012 Olympics as well as the Paralympics, sparking debate about prosthetics and fairness; he was later convicted of murdering his girlfriend, Reeva Steenkamp. German long jumper Markus Rehm's performances with a prosthetic have raised similar questions about equipment and advantage."]],
  ["Changing perceptions",[
    "The London 2012 Paralympics, with sold-out venues and the Channel 4 'Meet the Superhumans' campaign, transformed public perceptions in Britain. Paralympic athletes are increasingly professional, with sponsorships and media coverage.",
    "Other movements include the Special Olympics (founded in 1968 by Eunice Kennedy Shriver for athletes with intellectual disabilities, emphasizing participation), the Deaflympics (since 1924), and the Invictus Games (founded by Prince Harry in 2014 for wounded service members). Disability advocates continue to push for accessible facilities, coaching, and equal funding."]]
  ],
  terms:[["Paralympics","Elite multisport event for athletes with impairments."],["Classification","Grouping athletes by level of impairment."],["Goalball","Team sport for visually impaired athletes."],["Stoke Mandeville Games","1948 origin of the Paralympic movement."],["Special Olympics","Movement for athletes with intellectual disabilities."]],
  w:"The Paralympic movement shows the breadth of human athletic excellence and has changed attitudes toward disability.",
  src:["Paralympic Games","Ludwig Guttmann","Paralympic classification","Goalball","Special Olympics"],
  q:[
  ["Who organized the 1948 Stoke Mandeville Games?","Ludwig Guttmann","Eunice Kennedy Shriver","Pierre de Coubertin","Tanni Grey-Thompson"],
  ["Where were the first Paralympic Games held in 1960?","Rome","London","Tokyo","Seoul"],
  ["What is goalball?","A team sport for visually impaired athletes using a ball with bells","Wheelchair football","Sitting volleyball","A target sport"],
  ["Who founded the Special Olympics?","Eunice Kennedy Shriver","Ludwig Guttmann","Prince Harry","Jesse Owens"],
  ["Who won 55 Paralympic medals, the most of any athlete?","Trischa Zorn","Daniel Dias","Esther Vergeer","Tanni Grey-Thompson"],
  ["Since which Games have the Paralympics used the same city and venues as the Olympics?","Seoul 1988","Rome 1960","Barcelona 1992","Atlanta 1996"]]}

);


/* ---- from sports-16.js ---- */
/* SPORTS FOUNDATIONS, part 16: Unit 9 The Science of Sport, chapters 1-5 */
COURSES.sports.units.push({ t:"The Science of Sport", ch:[

{ t:"Energy Systems: How the Body Fuels Sport", s:"ATP, glycogen, and oxygen",
  sec:[
  ["ATP: the energy currency",[
    "Every muscle contraction is powered by adenosine triphosphate (ATP). Muscles store only enough ATP for a few seconds of intense effort, so the body must constantly regenerate it. It does this through three overlapping energy systems, which differ in speed and capacity.",
    "Which system dominates depends on the intensity and duration of the activity: a 100 m sprint, a 400 m race, and a marathon rely on very different balances of energy production."]],
  ["The phosphagen system",[
    "The phosphagen (ATP–PCr) system uses phosphocreatine stored in muscles to regenerate ATP almost instantly, without oxygen. It provides maximum power for about 10 seconds: sprints, jumps, throws, and heavy lifts.",
    "Phosphocreatine stores refill within a few minutes of rest. Creatine supplements, among the most researched legal supplements, can increase these stores and modestly improve repeated high-intensity performance."]],
  ["The glycolytic system",[
    "Anaerobic glycolysis breaks down glucose (from blood sugar or stored glycogen) to make ATP quickly without oxygen. It dominates intense efforts lasting from about 10 seconds to two minutes, such as the 400 m or a hard shift in hockey.",
    "It produces lactate and hydrogen ions; the acid buildup, not lactate itself, is now thought to be a major contributor to the burning fatigue of intense exercise. The old idea that lactic acid causes next-day muscle soreness is a myth; lactate is actually recycled as a fuel."]],
  ["The aerobic system",[
    "The aerobic (oxidative) system uses oxygen in the mitochondria to break down carbohydrates and fats into ATP. It is slower but can supply energy almost indefinitely, powering endurance events and recovery between bursts in team sports.",
    "At low intensities, the body burns a higher proportion of fat; as intensity rises, it relies more on carbohydrates. Glycogen stores in muscles and liver can fuel roughly 90 minutes to two hours of hard exercise; running out causes the sudden exhaustion marathoners call 'hitting the wall.'"]],
  ["Thresholds",[
    "The lactate threshold is the intensity at which lactate begins to accumulate faster than it can be cleared; trained athletes can sustain a higher percentage of their maximum before reaching it. Endurance training raises this threshold, improving performance.",
    "Coaches use heart rate, power, pace, and blood lactate testing to set training zones based on these thresholds."]],
  ["Team and intermittent sports",[
    "Many sports, such as football, basketball, tennis, and rugby, are intermittent: bursts of high intensity separated by lower-intensity recovery. Players need all three systems: power for sprints and jumps, glycolytic capacity for repeated efforts, and an aerobic base to recover quickly and keep going.",
    "A professional footballer may cover 10–13 km in a match, including dozens of sprints, illustrating the mix of energy demands."]]
  ],
  terms:[["ATP","Adenosine triphosphate, the body's energy currency."],["Phosphocreatine","Fuel for instant, short bursts."],["Glycogen","Stored carbohydrate in muscle and liver."],["Lactate threshold","Intensity where lactate begins to accumulate."],["Hitting the wall","Exhaustion when glycogen runs out."]],
  w:"Understanding energy systems explains how athletes train, pace themselves, and fuel for different sports.",
  src:["Adenosine triphosphate","Bioenergetic systems","Lactate threshold","Glycogen","Hitting the wall"],
  q:[
  ["What molecule directly powers muscle contraction?","ATP","Glucose","Lactate","Oxygen"],
  ["Which energy system powers a 10-second sprint?","Phosphagen (ATP–PCr)","Aerobic","Fat oxidation","Ketone"],
  ["Where does the aerobic system produce ATP?","Mitochondria","Nucleus","Bloodstream","Bones"],
  ["What does 'hitting the wall' refer to?","Exhaustion when glycogen runs out","Muscle cramps","Dehydration","Heat stroke"],
  ["Is lactic acid the cause of next-day muscle soreness?","No, that is a myth","Yes, always","Only in sprinters","Only in cold weather"],
  ["About how far might a pro footballer cover in a match?","10–13 km","2–3 km","25 km","50 km"]]},

{ t:"Heart, Lungs, and Aerobic Fitness", s:"VO2 max and endurance",
  sec:[
  ["The oxygen delivery chain",[
    "Endurance depends on getting oxygen from the air to working muscles: the lungs take in oxygen, the heart pumps oxygen-rich blood, hemoglobin in red blood cells carries it, capillaries deliver it, and mitochondria in muscles use it.",
    "Training improves almost every link in this chain."]],
  ["VO2 max",[
    "VO2 max is the maximum rate at which the body can take in and use oxygen, measured in milliliters of oxygen per kilogram of body weight per minute. Untrained adults might be around 35–45; elite endurance athletes reach 70–90, with cross-country skiers and cyclists among the highest recorded.",
    "VO2 max is partly genetic and partly trainable. However, it does not alone predict race results: running economy (how efficiently one uses oxygen at a given speed) and the fraction of VO2 max that can be sustained matter greatly."]],
  ["The athlete's heart",[
    "Endurance training enlarges the heart's left ventricle and increases stroke volume, the amount of blood pumped per beat. As a result, trained athletes have low resting heart rates; Tour de France winner Miguel Induráin reportedly had a resting heart rate around 28 beats per minute.",
    "Maximum heart rate declines with age and is not significantly changed by training; the formula '220 minus age' is a rough estimate with large individual variation."]],
  ["Blood and altitude",[
    "More red blood cells and hemoglobin mean more oxygen-carrying capacity. Living or training at altitude, where oxygen pressure is lower, stimulates production of erythropoietin (EPO), a hormone that increases red blood cells. The 'live high, train low' approach seeks to combine this benefit with high-quality training.",
    "Injecting synthetic EPO or transfusing blood ('blood doping') to achieve the same effect is banned and dangerous, as it thickens the blood."]],
  ["Heat and environment",[
    "Exercising in heat raises body temperature and diverts blood to the skin for cooling, reducing performance. Athletes acclimatize over one to two weeks, increasing sweat rate and plasma volume. Heat stroke is a medical emergency.",
    "Cold, humidity, and air pollution also affect performance; pollution was a concern at Beijing 2008 and heat at Tokyo 2020, where the marathon was moved to cooler Sapporo."]],
  ["Fitness and health",[
    "Cardiorespiratory fitness is one of the strongest predictors of long-term health; higher fitness is associated with lower risk of heart disease, diabetes, and early death. Health guidelines from the World Health Organization recommend at least 150–300 minutes of moderate or 75–150 minutes of vigorous aerobic activity per week for adults.",
    "High-intensity interval training (HIIT) can improve VO2 max efficiently, while steady moderate exercise builds the aerobic base."]]
  ],
  terms:[["VO2 max","Maximum rate of oxygen uptake."],["Stroke volume","Blood pumped per heartbeat."],["EPO","Hormone stimulating red blood cell production."],["Running economy","Oxygen cost of running at a given speed."],["Acclimatization","Adapting to heat or altitude."]],
  w:"Aerobic fitness underpins endurance sport and long-term health; understanding it guides smart training.",
  src:["VO2 max","Athletic heart syndrome","Altitude training","Erythropoietin","Exercise physiology"],
  q:[
  ["What does VO2 max measure?","Maximum oxygen uptake","Maximum heart rate","Lung size","Blood sugar"],
  ["Which hormone increases red blood cell production at altitude?","EPO","Insulin","Adrenaline","Cortisol"],
  ["Why do endurance athletes have low resting heart rates?","Their hearts pump more blood per beat","Their hearts are weaker","They breathe slower","They have less blood"],
  ["Where was the Tokyo 2020 marathon moved because of heat?","Sapporo","Osaka","Kyoto","Nagano"],
  ["What does the WHO recommend for adults?","150–300 minutes of moderate aerobic activity weekly","10 minutes a week","Only strength training","Exercise once a month"],
  ["What is 'live high, train low'?","Living at altitude while training lower","Sleeping in tents","Training only at sea level","Living on mountains permanently"]]},

{ t:"Muscles, Strength, and Power", s:"How muscles work and grow",
  sec:[
  ["Muscle structure",[
    "Skeletal muscles are made of bundles of long cells called muscle fibers, containing myofibrils with repeating units (sarcomeres) of actin and myosin filaments. According to the sliding filament theory, myosin heads pull actin filaments together when stimulated by a nerve signal, shortening the muscle.",
    "A motor neuron and the fibers it controls form a motor unit; the body recruits more and larger motor units for stronger efforts."]],
  ["Fiber types",[
    "Slow-twitch (type I) fibers are fatigue-resistant and suited to endurance; fast-twitch (type II) fibers contract quickly and powerfully but tire faster. Elite marathoners tend to have a high proportion of slow-twitch fibers, sprinters of fast-twitch fibers.",
    "Fiber type distribution is largely genetic, though training can shift fiber characteristics somewhat."]],
  ["Strength and hypertrophy",[
    "Early strength gains from training come mostly from neural adaptations: better recruitment and coordination of motor units. Over weeks and months, muscles grow larger (hypertrophy) as fibers increase in size in response to mechanical tension and repair.",
    "Progressive overload, gradually increasing weight, repetitions, or volume, drives continued adaptation, an idea illustrated by the legend of Milo of Croton carrying a growing calf."]],
  ["Power and speed",[
    "Power is force multiplied by velocity: the ability to produce force quickly. It is essential for jumping, sprinting, throwing, and striking. Training methods include Olympic lifts, plyometrics (explosive jumping exercises that use the stretch-shortening cycle), sprints, and ballistic throws.",
    "The stretch-shortening cycle stores elastic energy when a muscle-tendon unit is stretched just before contracting, like a spring, as in the countermovement before a jump."]],
  ["Types of contraction",[
    "Concentric contractions shorten the muscle under load (lifting); eccentric contractions lengthen it under load (lowering), and produce more muscle damage and soreness; isometric contractions hold force without movement.",
    "Delayed onset muscle soreness (DOMS), peaking 24–72 hours after unfamiliar or eccentric exercise, results from microscopic damage and inflammation, not lactic acid."]],
  ["Flexibility and mobility",[
    "Flexibility is the range of motion around a joint. Static stretching (holding a stretch) can slightly reduce maximal power if done immediately before explosive activity, so many coaches favor dynamic warm-ups with movement-based stretches before training, and static stretching afterward or separately.",
    "Mobility, balance, and core stability support efficient movement and may help reduce injury risk."]]
  ],
  terms:[["Sliding filament theory","Actin and myosin sliding to contract muscle."],["Motor unit","A motor neuron and the fibers it controls."],["Hypertrophy","Increase in muscle size."],["Plyometrics","Explosive jump training."],["DOMS","Delayed onset muscle soreness."]],
  w:"Knowing how muscles adapt explains how athletes build strength, speed, and power safely.",
  src:["Skeletal muscle","Sliding filament theory","Muscle hypertrophy","Plyometrics","Delayed onset muscle soreness"],
  q:[
  ["Which two proteins slide together to contract a muscle?","Actin and myosin","Collagen and keratin","Hemoglobin and insulin","Elastin and fibrin"],
  ["Which fibers suit endurance?","Slow-twitch (type I)","Fast-twitch (type II)","Smooth muscle","Cardiac fibers only"],
  ["Where do early strength gains mostly come from?","Neural adaptations","Muscle growth only","Bone growth","Fat loss"],
  ["What is power?","Force multiplied by velocity","Maximum weight lifted","Endurance capacity","Flexibility"],
  ["Which contraction type lengthens the muscle under load?","Eccentric","Concentric","Isometric","Isotonic shortening"],
  ["What are plyometrics?","Explosive jumping exercises","Long slow runs","Stretching routines","Breathing drills"]]},

{ t:"Training Principles and Periodization", s:"Planning to peak",
  sec:[
  ["Core principles",[
    "Sport science identifies key principles of training. Specificity: the body adapts to the demands placed on it, so training should resemble the sport. Overload: stress must exceed what the body is used to. Progression: overload should increase gradually. Reversibility: fitness declines when training stops ('use it or lose it'). Individualization: people respond differently to the same program.",
    "The FITT framework (frequency, intensity, time, type) helps design programs."]],
  ["Stress, recovery, adaptation",[
    "Training causes fatigue and temporary decline; with recovery, the body adapts and rebuilds to a higher level, a process called supercompensation. Too little stimulus produces no gain; too much without recovery leads to overreaching and, if prolonged, overtraining syndrome, with persistent fatigue, declining performance, mood changes, and illness.",
    "Monitoring tools include training load, heart rate variability, sleep, and athletes' own wellness ratings."]],
  ["Periodization",[
    "Periodization divides training into phases to peak at the right time. Classic models, developed in the Soviet Union by Lev Matveyev and others, use macrocycles (a season or year), mesocycles (blocks of several weeks), and microcycles (usually a week).",
    "A typical plan moves from a general preparation phase (building base fitness and volume) to specific preparation, then competition, with tapering (reducing volume before key events while maintaining intensity) and a transition phase of rest. Block periodization and undulating models vary the emphasis more flexibly."]],
  ["Intensity distribution",[
    "Studies of elite endurance athletes found that many train with a 'polarized' distribution: roughly 80% of sessions at low intensity and 20% at high intensity, with relatively little time in the moderate middle. Norwegian methods using lactate-guided 'threshold' sessions have also become influential.",
    "Interval training, alternating hard efforts with recovery, allows more total time at high intensity."]],
  ["Team sport training",[
    "Team sports must balance fitness, technical skill, tactics, and recovery across a long season with frequent matches. Small-sided games combine conditioning with skills and decision-making. GPS trackers monitor players' distances and sprints to manage workload and reduce injury risk.",
    "The 'acute:chronic workload ratio,' comparing recent and longer-term load, has been used to flag injury risk, though researchers debate its value."]],
  ["Warm-up and cool-down",[
    "A good warm-up raises body temperature, increases blood flow, activates the nervous system, and rehearses movements. Programs such as FIFA 11+ (a structured warm-up) have been shown in studies to reduce injuries in amateur football players.",
    "Cool-downs and gradual reductions in intensity help the transition to rest, though their effect on next-day soreness is modest."]]
  ],
  terms:[["Specificity","Training should match the sport's demands."],["Supercompensation","Rebuilding to a higher level after recovery."],["Periodization","Planned phases of training."],["Taper","Reducing training volume before competition."],["Overtraining syndrome","Prolonged decline from excessive training."]],
  w:"Smart training follows principles of overload, recovery, and planning; these apply to Olympians and beginners alike.",
  src:["Sports periodization","Supercompensation","Overtraining","Tapering","FIFA 11+"],
  q:[
  ["What is the principle of specificity?","Training should resemble the sport's demands","Train as much as possible","Rest is unnecessary","All athletes train the same"],
  ["What is tapering?","Reducing volume before competition","Increasing volume before competition","Stretching only","Eating more carbs"],
  ["What is supercompensation?","Rebuilding to a higher level after recovery","Overeating after training","Training twice a day","An injury"],
  ["What is a microcycle?","A short training cycle, usually a week","A full season","A single exercise","A recovery drink"],
  ["What is 'polarized' training?","Mostly low intensity with some high intensity","All moderate intensity","Only high intensity","Only strength training"],
  ["What is FIFA 11+?","A warm-up program shown to reduce injuries","A formation","A rule change","A youth league"]]},

{ t:"Sports Nutrition", s:"Fueling performance",
  sec:[
  ["Macronutrients",[
    "Carbohydrates are the main fuel for high-intensity exercise, stored as glycogen; endurance athletes may need 6–10 grams per kilogram of body weight per day during heavy training. Protein supports muscle repair and adaptation; sports nutrition guidelines commonly recommend about 1.2–2.0 grams per kilogram per day for athletes. Fats provide energy for low-intensity exercise and essential nutrients.",
    "Energy needs vary enormously: a Tour de France rider may burn 5,000–8,000 kilocalories on a mountain stage."]],
  ["Timing",[
    "Eating carbohydrates before events tops up glycogen; 'carb-loading' in the days before endurance events can increase glycogen stores. During events lasting over about an hour, athletes consume carbohydrates (drinks, gels, bananas); elite marathoners and cyclists now take in 60–120 grams per hour with training to tolerate it.",
    "After exercise, carbohydrates and protein help replenish glycogen and repair muscle; distributing protein across meals supports muscle building."]],
  ["Micronutrients",[
    "Vitamins and minerals are essential for energy metabolism, oxygen transport, and bone health. Iron deficiency, especially common in female endurance athletes, impairs oxygen transport; vitamin D and calcium support bones.",
    "A varied diet usually provides enough; supplements are useful mainly for diagnosed deficiencies."]],
  ["Supplements",[
    "Few supplements have strong evidence for performance benefits. The International Olympic Committee's 2018 consensus statement identified caffeine, creatine, nitrate (as from beetroot juice), beta-alanine, and sodium bicarbonate as having good evidence in specific situations.",
    "Supplements can be contaminated with banned substances; athletes are strictly liable for anything in their bodies, so many use third-party-tested products."]],
  ["Energy availability",[
    "Relative Energy Deficiency in Sport (RED-S) occurs when athletes don't eat enough to support both training and basic body functions. It can impair hormones, bone health (raising stress fracture risk), immunity, and performance, and affects both female and male athletes; it updated the earlier concept of the 'female athlete triad.'",
    "Sports with weight categories or aesthetic judging, such as gymnastics, distance running, and combat sports, carry particular risks of under-fueling and disordered eating, so professional support is important."]],
  ["Myths and practical eating",[
    "Common myths include that protein alone builds muscle without training, that carbohydrates are inherently fattening, or that special diets suit all athletes. Evidence supports eating a varied diet of whole foods, adequate energy, and timing intake around training.",
    "Sports dietitians tailor plans to the athlete, sport, and training phase."]]
  ],
  terms:[["Carb-loading","Increasing carbohydrate intake before endurance events."],["Glycogen","Stored carbohydrate fuel."],["RED-S","Relative Energy Deficiency in Sport."],["Strict liability","Athletes are responsible for any banned substance in their bodies."],["Ergogenic aid","Substance or method that enhances performance."]],
  w:"Good nutrition is a foundation of performance and health, and much popular advice is myth.",
  src:["Sports nutrition","Carbohydrate loading","Relative energy deficiency in sport","Dietary supplement","Creatine"],
  q:[
  ["What is the main fuel for high-intensity exercise?","Carbohydrates","Fat","Protein","Vitamins"],
  ["What is carb-loading?","Increasing carbohydrate intake before endurance events","Eating only protein","Fasting before races","Drinking only water"],
  ["What does RED-S stand for?","Relative Energy Deficiency in Sport","Rapid Energy Delivery System","Red blood cell syndrome","Recovery Diet Standard"],
  ["Which supplement has good evidence for performance in specific situations?","Caffeine","Vitamin C megadoses","Ginseng","Bee pollen"],
  ["Which deficiency is common among female endurance athletes?","Iron","Vitamin K","Sodium","Fat"],
  ["Why are some supplements risky for athletes?","They may be contaminated with banned substances","They are always illegal","They are too expensive only","They have no calories"]]}

]});


/* ---- from sports-17.js ---- */
/* SPORTS FOUNDATIONS, part 17: Unit 9 chapters 6-10 */
COURSES.sports.units[8].ch.push(

{ t:"Recovery, Sleep, and Hydration", s:"Getting better between sessions",
  sec:[
  ["Why recovery matters",[
    "Adaptation happens during recovery, not during training itself. Recovery includes restoring energy stores, repairing tissues, rebalancing hormones, and allowing the nervous system and mind to rest. Inadequate recovery leads to stagnation, injury, and illness.",
    "Elite athletes treat recovery as part of training, planning rest days and lighter weeks."]],
  ["Sleep",[
    "Sleep is perhaps the most powerful recovery tool. During deep sleep the body releases growth hormone and repairs tissue; sleep also consolidates motor learning. Studies, such as one on Stanford basketball players who extended sleep to about ten hours a night, found improvements in sprint times and shooting accuracy.",
    "Travel across time zones disrupts sleep and performance (jet lag); teams schedule flights and light exposure to adjust. Many athletes aim for eight to ten hours and use naps."]],
  ["Hydration",[
    "Sweating cools the body but loses water and electrolytes, especially sodium. Losing more than about 2% of body weight through dehydration can impair endurance performance and thinking, especially in heat. Athletes can estimate sweat losses by weighing themselves before and after exercise.",
    "Overdrinking is also dangerous: exercise-associated hyponatremia, low blood sodium from drinking too much water, has caused deaths among marathon runners. Guidelines now emphasize drinking to thirst or according to individual sweat rates."]],
  ["Recovery methods",[
    "Common recovery methods include active recovery (light exercise), massage, foam rolling, compression garments, cold-water immersion (ice baths), and contrast baths. Evidence for many is mixed: ice baths may reduce soreness but, used regularly after strength training, can blunt muscle growth adaptations.",
    "Nutrition (carbohydrates, protein, fluids) and sleep have the strongest evidence; many other methods may help partly by making athletes feel better."]],
  ["Mental recovery",[
    "Psychological stress affects physical recovery. Time away from sport, social support, relaxation, and enjoyable activities support mental freshness. Burnout, physical and emotional exhaustion with reduced motivation, is a risk in year-round sport, especially for young athletes who specialize early.",
    "The off-season and rest periods are essential for long careers."]]
  ],
  terms:[["Recovery","Process of restoring the body after training."],["Hyponatremia","Dangerously low blood sodium from overdrinking."],["Electrolytes","Minerals such as sodium lost in sweat."],["Active recovery","Light exercise to aid recovery."],["Burnout","Exhaustion and loss of motivation from chronic stress."]],
  w:"Recovery is where fitness is built; sleep, fuel, and fluids matter more than any gadget.",
  src:["Sleep and athletic performance","Exercise-associated hyponatremia","Dehydration","Cold-water immersion","Athletic burnout"],
  q:[
  ["When does adaptation to training mainly happen?","During recovery","During the workout itself","Only during competition","Never"],
  ["What is exercise-associated hyponatremia?","Low blood sodium from overdrinking","Dehydration","High blood sugar","A heart condition"],
  ["What did a Stanford study find when basketball players slept more?","Improved sprint times and shooting accuracy","No change","Worse performance","More injuries"],
  ["Dehydration beyond about what percentage of body weight can impair performance?","2%","10%","0.1%","25%"],
  ["What can regular ice baths after strength training do?","Blunt muscle growth adaptations","Double strength gains","Cure injuries","Increase VO2 max"],
  ["What is burnout?","Exhaustion and loss of motivation from chronic stress","A sprint drill","A type of heat illness","A recovery method"]]},

{ t:"Sports Injuries and Prevention", s:"Staying in the game",
  sec:[
  ["Acute and overuse injuries",[
    "Acute injuries happen suddenly: sprains (ligament injuries), strains (muscle or tendon injuries), fractures, dislocations, and contusions. Overuse injuries develop gradually from repetitive stress without enough recovery: stress fractures, tendinopathies (such as Achilles or patellar tendinopathy, 'jumper's knee'), shin splints, and 'tennis elbow.'",
    "Injury patterns vary by sport: hamstring strains in football and sprinting, shoulder injuries in swimming and baseball pitching, knee injuries in skiing and basketball."]],
  ["The ACL",[
    "The anterior cruciate ligament (ACL) stabilizes the knee. ACL tears often happen without contact, when landing, cutting, or pivoting, and frequently require reconstruction surgery and nine months or more of rehabilitation. Female athletes have a higher rate of ACL injury, linked to factors such as anatomy, hormones, neuromuscular control, and possibly footwear and training access.",
    "Prevention programs that train landing mechanics, balance, and strength reduce ACL injuries in studies."]],
  ["Treatment and rehabilitation",[
    "Initial management of soft-tissue injuries has evolved from 'RICE' (rest, ice, compression, elevation) toward approaches emphasizing protection followed by early, gradual loading, since tissues heal better with appropriate movement. Physiotherapists guide rehabilitation through stages: restoring range of motion, strength, function, and sport-specific skills.",
    "Return-to-play decisions balance the athlete's desire to compete with the risk of reinjury. Sports medicine combines doctors, physiotherapists, athletic trainers, and surgeons."]],
  ["Famous surgical advances",[
    "'Tommy John surgery,' ulnar collateral ligament reconstruction first performed by Dr. Frank Jobe on pitcher Tommy John in 1974, has saved many baseball careers. Arthroscopic (keyhole) surgery, developed in the 20th century, allows faster recovery from knee and shoulder operations.",
    "Advances in imaging (MRI) and rehabilitation have extended careers that once would have ended."]],
  ["Prevention",[
    "Injury prevention strategies include proper warm-ups, strength training (including eccentric exercises such as the Nordic hamstring curl, shown to reduce hamstring injuries), managing training load, good technique, protective equipment, appropriate footwear, and adequate rest.",
    "Rule changes also prevent injuries, such as bans on spear tackling in American football or high tackles in rugby. Pitch counts limit throwing in youth baseball."]],
  ["Youth athletes",[
    "Young athletes have growth plates, areas of developing cartilage near the ends of bones, which are vulnerable to injury. Early specialization in a single sport and year-round training are associated with higher overuse injury and burnout rates; many experts recommend sampling multiple sports in childhood.",
    "Pain should never be simply 'played through' by children; supervision by trained coaches and medical staff is important."]]
  ],
  terms:[["Sprain","Ligament injury."],["Strain","Muscle or tendon injury."],["ACL","Knee ligament often torn in pivoting sports."],["Tommy John surgery","Elbow ligament reconstruction for pitchers."],["Overuse injury","Damage from repetitive stress."]],
  w:"Understanding injuries and prevention keeps athletes of all levels healthy and playing longer.",
  src:["Sports injury","Anterior cruciate ligament injury","Ulnar collateral ligament reconstruction","Nordic hamstring curl","Sports medicine"],
  q:[
  ["What is a sprain?","A ligament injury","A muscle injury","A broken bone","A bruise"],
  ["Who first performed Tommy John surgery in 1974?","Dr. Frank Jobe","Dr. James Andrews","Dr. Bennet Omalu","Dr. Christiaan Barnard"],
  ["Which exercise is shown to reduce hamstring injuries?","Nordic hamstring curl","Bicep curl","Bench press","Calf raise"],
  ["What does ACL stand for?","Anterior cruciate ligament","Achilles core ligament","Arm collateral ligament","Active cartilage layer"],
  ["What is a risk of early single-sport specialization in children?","Higher overuse injury and burnout","Better long-term results always","Stronger bones","No risk"],
  ["How has soft-tissue injury management evolved?","Toward protection followed by early gradual loading","Toward complete rest for months","Toward heat only","Toward immediate full training"]]},

{ t:"Concussion and Brain Health", s:"Protecting the head",
  sec:[
  ["What a concussion is",[
    "A concussion is a mild traumatic brain injury caused by a blow or jolt to the head or body that makes the brain move rapidly inside the skull, disrupting its function. Most concussions do not involve loss of consciousness. Symptoms can include headache, dizziness, confusion, memory problems, nausea, sensitivity to light and noise, and mood changes.",
    "Concussions are common in collision sports such as American football, rugby, ice hockey, boxing, and MMA, but also occur in football (soccer), cycling, skiing, and equestrian sports."]],
  ["'If in doubt, sit them out'",[
    "Modern protocols require any player suspected of concussion to be removed from play immediately and not return the same day. A second impact before recovery can be especially dangerous; rare 'second impact syndrome' can cause fatal brain swelling in young athletes.",
    "Return to play follows a graduated, step-by-step program, from rest to light activity to full contact, with medical clearance. International consensus statements on concussion in sport (the latest from Amsterdam in 2022) guide practice."]],
  ["Long-term effects",[
    "Chronic traumatic encephalopathy (CTE) is a degenerative brain disease associated with repeated head impacts, including sub-concussive hits. It was described in boxers ('punch-drunk syndrome') in the 1920s; in 2005, Dr. Bennet Omalu published a case of CTE in former NFL player Mike Webster, a story told in the film Concussion.",
    "CTE can currently be definitively diagnosed only after death by examining the brain. Studies of donated brains of former American football players have found CTE in a large proportion, though such samples are not random. Research has also linked heading in football to possible risks, prompting limits on heading for children in some countries."]],
  ["Changes in sport",[
    "Sports have changed rules and equipment: the NFL banned helmet-to-helmet hits and changed kickoffs; rugby lowered legal tackle heights in community games; football (soccer) introduced concussion substitutes; and the US and UK restricted heading for young children.",
    "Lawsuits by former players, such as the NFL settlement and legal actions in rugby, have increased pressure on sports bodies."]],
  ["Helmets and limits",[
    "Helmets prevent skull fractures and severe brain injuries, especially in cycling, skiing, and equestrian sports, but cannot fully prevent concussions, since the brain can still move within the skull. Mouthguards with sensors now measure impacts in some sports.",
    "Education of athletes, parents, coaches, and referees to recognize concussion is one of the most effective protective measures."]]
  ],
  terms:[["Concussion","Mild traumatic brain injury from a blow or jolt."],["Second impact syndrome","Dangerous brain swelling after a second hit before recovery."],["CTE","Degenerative disease linked to repeated head impacts."],["Return to play","Graduated program after injury."],["Sub-concussive hit","Head impact without symptoms."]],
  w:"Concussion awareness is transforming collision sports and protecting athletes' long-term brain health.",
  src:["Concussions in sport","Chronic traumatic encephalopathy","Bennet Omalu","Second-impact syndrome","Concussion substitute"],
  q:[
  ["Do most concussions involve loss of consciousness?","No","Yes, always","Only in boxing","Only in children"],
  ["What should happen to a player suspected of concussion?","Be removed from play and not return that day","Continue after a short rest","Return after five minutes","Take painkillers and continue"],
  ["Who published the first case of CTE in an NFL player in 2005?","Dr. Bennet Omalu","Dr. Frank Jobe","Dr. Ann McKee","Dr. Robert Cantu"],
  ["How can CTE currently be definitively diagnosed?","Only after death, by examining the brain","With a blood test","With an eye exam","With a reflex test"],
  ["What did football introduce to manage head injuries?","Concussion substitutes","Helmets for all players","Shorter matches","No headers for adults"],
  ["What is second impact syndrome?","Dangerous brain swelling after a second hit before recovery","A double knockout","Two concussions in a career","A type of helmet"]]},

{ t:"Sport Psychology", s:"The mental game",
  sec:[
  ["Motivation",[
    "Sport psychology studies how the mind affects performance and how sport affects wellbeing. Motivation can be intrinsic (enjoyment of the activity itself) or extrinsic (rewards, recognition). Self-determination theory suggests that motivation thrives when athletes feel autonomy, competence, and relatedness.",
    "Achievement goal theory distinguishes task orientation (focus on improving and mastering) from ego orientation (focus on beating others); a task-focused climate is associated with greater persistence and enjoyment."]],
  ["Arousal and anxiety",[
    "Performance relates to arousal (physiological and mental activation). The inverted-U hypothesis suggests performance is best at moderate arousal: too little leads to flatness, too much to anxiety and errors. Optimal levels differ by sport and person: a weightlifter may need more arousal than a golfer.",
    "'Choking' is a sudden decline in performance under pressure, often linked to overthinking well-learned skills. Reframing anxiety as excitement, routines, and practice under pressure can help."]],
  ["Mental skills",[
    "Athletes use a toolkit of mental skills: goal setting (process, performance, and outcome goals, often 'SMART'), imagery or visualization (mentally rehearsing performance with all senses), self-talk (instructional or motivational statements), concentration techniques, and pre-performance routines, such as a tennis player bouncing the ball before serving or a basketball free-throw ritual.",
    "Relaxation methods include controlled breathing and progressive muscle relaxation."]],
  ["Confidence, flow, and resilience",[
    "Self-efficacy, belief in one's ability to succeed in a specific task (a concept from psychologist Albert Bandura), comes from past successes, watching others, encouragement, and interpreting physical states. Flow, described by Mihaly Csikszentmihalyi, is a state of complete absorption where challenge and skill match and performance feels effortless.",
    "Resilience, bouncing back from setbacks, is built through support, perspective, and learning from failure; a 'growth mindset' (Carol Dweck) treats ability as developable."]],
  ["Team dynamics",[
    "Team cohesion includes task cohesion (commitment to shared goals) and social cohesion (liking each other); task cohesion is more strongly linked to performance. Leadership, communication, and clear roles shape team culture.",
    "Coaches' behavior strongly affects athletes' motivation and wellbeing; supportive, autonomy-encouraging coaching is associated with better outcomes."]],
  ["Mental health",[
    "Elite athletes face pressures including public scrutiny, social media abuse, injury, and career transitions. Athletes such as swimmer Michael Phelps, tennis player Naomi Osaka, and gymnast Simone Biles spoke openly about depression, anxiety, and mental health in the 2010s–20s, helping reduce stigma.",
    "Sports organizations increasingly employ psychologists and offer support, including for retirement, which can be a difficult identity transition."]]
  ],
  terms:[["Intrinsic motivation","Doing something for its own enjoyment."],["Inverted-U","Performance peaks at moderate arousal."],["Choking","Sudden performance decline under pressure."],["Imagery","Mental rehearsal of performance."],["Self-efficacy","Belief in one's ability to succeed at a task."]],
  w:"The mind shapes performance as much as the body; these skills help in sport and beyond.",
  src:["Sport psychology","Yerkes–Dodson law","Choking under pressure","Flow (psychology)","Self-efficacy"],
  q:[
  ["What does the inverted-U hypothesis suggest?","Performance is best at moderate arousal","More arousal is always better","Arousal doesn't matter","Lowest arousal is best"],
  ["What is intrinsic motivation?","Doing something for its own enjoyment","Doing it for money","Doing it for fame","Doing it under pressure"],
  ["Who described the state of 'flow'?","Mihaly Csikszentmihalyi","Albert Bandura","Carol Dweck","Sigmund Freud"],
  ["What is 'choking'?","Sudden performance decline under pressure","A breathing technique","A wrestling move","A type of injury"],
  ["What is imagery in sport psychology?","Mentally rehearsing performance","Watching videos only","Taking photos","Drawing plays"],
  ["Which type of team cohesion is more strongly linked to performance?","Task cohesion","Social cohesion","Neither","Financial cohesion"]]},

{ t:"Biomechanics and Technique", s:"The physics of movement",
  sec:[
  ["What biomechanics studies",[
    "Biomechanics applies the laws of physics to human movement. It analyzes forces, levers, motion, and energy to improve technique, prevent injury, and design equipment. Tools include high-speed cameras, motion-capture systems, force plates measuring ground reaction forces, and wearable sensors.",
    "Coaches use biomechanical insight to refine a golf swing, a sprint start, or a swimming stroke."]],
  ["Newton's laws in sport",[
    "Newton's first law (inertia): a stationary ball stays still until a force acts on it. The second law (force = mass × acceleration): a heavier shot needs more force to accelerate equally. The third law (action and reaction): a sprinter pushes back and down against the ground and the ground pushes the sprinter forward and up.",
    "Momentum (mass × velocity) and impulse (force × time) explain why follow-through matters: applying force over a longer time increases the ball's speed, and 'giving' with the hands when catching reduces impact force."]],
  ["Levers and the kinetic chain",[
    "Bones act as levers and joints as pivots. Longer levers, such as long arms or a tennis racket, can produce higher speeds at the end. The kinetic chain describes how power transfers sequentially from large body segments to small ones, legs, hips, trunk, shoulder, arm, wrist, in throwing, striking, and kicking.",
    "Elite pitchers and tennis servers coordinate this sequence precisely; breaks in the chain reduce power and can increase injury risk."]],
  ["Projectiles and spin",[
    "A thrown or hit object follows a projectile path determined by release speed, angle, and height, plus air resistance. In theory, 45 degrees gives the maximum distance on flat ground with no air resistance, but in practice optimal angles are often lower, as in the shot put and long jump, because of release height and how athletes generate speed.",
    "Spin creates the Magnus effect: a spinning ball curves because of pressure differences in the air around it. This explains a footballer's curling free kick (Roberto Carlos's famous 1997 free kick against France), topspin in tennis, a baseball curveball, and cricket swing (which also depends on the seam and ball condition)."]],
  ["Fluids and drag",[
    "Drag slows athletes and objects moving through air and water. Cyclists adopt aerodynamic positions and use streamlined helmets and wheels; drafting behind others reduces drag. Swimmers reduce drag with streamlined body positions and long underwater phases.",
    "Golf ball dimples, introduced after players noticed scuffed balls flew farther, create turbulence that reduces drag and allows longer flight."]],
  ["Equipment design",[
    "Equipment design draws on biomechanics and materials science: fiberglass poles, carbon-fiber bikes, tennis rackets with larger sweet spots, running shoes with energy-returning foams, and prosthetic running blades.",
    "Governing bodies regulate equipment to protect fairness and the nature of the sport, such as limits on golf driver 'springiness,' javelin design, swimsuits, and running shoe sole thickness."]]
  ],
  terms:[["Biomechanics","Physics of human movement."],["Ground reaction force","Force the ground exerts back on the athlete."],["Kinetic chain","Sequential transfer of power through body segments."],["Magnus effect","Curving of a spinning ball."],["Drag","Resistance from air or water."]],
  w:"Physics explains why great technique works and how equipment changes sport.",
  src:["Sports biomechanics","Magnus effect","Kinetic chain","Projectile motion","Golf ball"],
  q:[
  ["Which law explains a sprinter being pushed forward by the ground?","Newton's third law","Newton's first law","Boyle's law","Hooke's law"],
  ["What causes a spinning ball to curve?","The Magnus effect","Gravity only","The Doppler effect","Friction with the ground"],
  ["Why do golf balls have dimples?","To reduce drag and fly farther","For decoration","To add weight","To make them softer"],
  ["What is the kinetic chain?","Sequential transfer of power through body segments","A bike chain","A muscle type","A training plan"],
  ["Why might the optimal shot put angle be lower than 45 degrees?","Because of release height and how athletes generate speed","Because of wind only","Because the shot is round","Because of rules"],
  ["What does a force plate measure?","Ground reaction forces","Heart rate","Muscle size","Wind speed"]]}

);


/* ---- from sports-18.js ---- */
/* SPORTS FOUNDATIONS, part 18: Unit 9 chapters 11-13 */
COURSES.sports.units[8].ch.push(

{ t:"Talent, Genes, Age, and Sex", s:"What makes an elite athlete",
  sec:[
  ["Nature and nurture",[
    "Elite performance results from an interplay of genetics, training, environment, opportunity, and psychology. Twin and family studies suggest that many athletic traits, such as VO2 max, muscle fiber composition, height, and responsiveness to training, are substantially heritable. But no single 'sports gene' exists; hundreds of genetic variants each have tiny effects.",
    "Journalist David Epstein's The Sports Gene (2013) explored how body types match sports: tall, long-armed swimmers like Michael Phelps; long-limbed, light-framed Kenyan and Ethiopian distance runners from high-altitude regions; very tall basketball players."]],
  ["Practice and the '10,000 hours' debate",[
    "Psychologist K. Anders Ericsson's research on deliberate practice was popularized by Malcolm Gladwell's 'Outliers' (2008) as a '10,000-hour rule.' Later studies found practice explains only part of the variation in performance, and the amount needed differs greatly between people and sports.",
    "Birthplace and opportunity matter too: the 'relative age effect' means children born early in a selection year (older and more physically mature within their age group) are over-represented in youth teams and later professional sport."]],
  ["Age and performance",[
    "Peak ages vary by sport: gymnasts and swimmers often peak in their teens or early twenties; sprinters in their mid-twenties; marathon runners, golfers, and equestrian riders often later. Performance generally declines with age as muscle mass, power, and VO2 max fall, but masters athletes show that regular training greatly slows the decline.",
    "Remarkable longevity examples include Tom Brady winning a Super Bowl at 43, Kazuyoshi Miura playing professional football into his late fifties, and equestrian riders competing at Olympics in their sixties."]],
  ["Sex differences and categories",[
    "After puberty, higher testosterone levels in males lead, on average, to greater muscle mass, larger hearts and lungs, higher hemoglobin, and longer bones, producing performance gaps of roughly 10–12% in running and swimming and larger gaps in some strength and power events. This is why most sports have separate men's and women's categories.",
    "Eligibility rules for athletes with differences of sex development (DSD) and for transgender athletes are among the most contested issues in sport, balancing fairness, inclusion, and human rights. Different federations have adopted different rules; World Athletics and World Aquatics restrict participation in the female category, and in 2025 several bodies introduced genetic (SRY gene) screening, while the debate and legal challenges continue."]],
  ["Talent identification",[
    "Sports systems try to identify and develop talent. The Soviet bloc and China used systematic testing of children; Britain's UK Sport invested heavily after poor results at Atlanta 1996, contributing to strong performances from 2008 onward. Many experts warn that early identification is unreliable, since children develop at different rates.",
    "Long-term athlete development models emphasize fundamental movement skills, play, and multiple sports before specialization."]]
  ],
  terms:[["Heritability","Proportion of trait variation due to genetics."],["Relative age effect","Advantage for those born early in a selection year."],["Masters athlete","Older competitive athlete."],["DSD","Differences of sex development."],["Talent identification","Systems for finding promising athletes."]],
  w:"Elite performance emerges from genes, training, age, and opportunity, and raises hard questions about fairness.",
  src:["The Sports Gene","Relative age effect","Sex differences in sports","Long-term athlete development","Masters athletics"],
  q:[
  ["Is there a single 'sports gene'?","No, many variants each have small effects","Yes, ACTN3 alone determines success","Yes, in sprinters only","Yes, discovered in 2013"],
  ["What is the relative age effect?","Advantage for those born early in a selection year","Older athletes always win","Youngest athletes are best","Age doesn't matter in sport"],
  ["Who popularized the '10,000-hour rule'?","Malcolm Gladwell","David Epstein","Carol Dweck","Albert Bandura"],
  ["Roughly what is the male–female performance gap in running?","10–12%","1–2%","30–40%","50%"],
  ["Who won a Super Bowl at age 43?","Tom Brady","Peyton Manning","Brett Favre","Drew Brees"],
  ["What do long-term athlete development models emphasize?","Fundamental skills and multiple sports before specialization","Early specialization","Only competition","Only strength training"]]},

{ t:"Doping: History and Science", s:"The fight for clean sport",
  sec:[
  ["A long history",[
    "Athletes have sought performance aids since antiquity. In the early modern Olympics, marathoner Thomas Hicks was given strychnine and brandy during the 1904 race. Amphetamines spread after World War II; British cyclist Tom Simpson died climbing Mont Ventoux in the 1967 Tour de France with amphetamines in his system, and Danish cyclist Knud Enemark Jensen collapsed and died at the 1960 Olympics.",
    "The IOC began drug testing at the 1968 Olympics. Anabolic steroids, synthetic versions of testosterone that build muscle, spread in the 1960s–80s."]],
  ["State-sponsored doping",[
    "East Germany ran a secret state doping program (State Plan 14.25) from the 1970s, giving steroids to thousands of athletes, including minors, often without their knowledge. Many suffered severe health problems.",
    "Russia's state-sponsored program, exposed by whistleblowers and by the 2016 McLaren Report, included swapping urine samples through a 'mouse hole' at the Sochi 2014 laboratory. Russia was barred from competing under its flag at several Olympics, with athletes competing as neutrals."]],
  ["Types of doping",[
    "Banned methods include anabolic agents (steroids), peptide hormones (EPO, growth hormone), beta-2 agonists, hormone modulators, diuretics and masking agents, stimulants, narcotics, and cannabinoids in competition. Banned methods include blood doping (transfusions) and tampering with samples. Gene doping is a theoretical future threat.",
    "A substance is generally banned if it meets two of three criteria: it enhances performance, poses a health risk, or violates the spirit of sport."]],
  ["Great scandals",[
    "Ben Johnson tested positive for stanozolol after winning the 1988 Olympic 100 m. Marion Jones was stripped of her 2000 Olympic medals after admitting steroid use linked to the BALCO laboratory scandal. Lance Armstrong's doping, exposed by USADA in 2012, led to the loss of his seven Tour de France titles.",
    "Baseball's steroid era, the 1998 Festina affair in cycling, and repeated scandals in weightlifting show doping across sports. Some cases involve contamination or disputed evidence, and debates arise over medical exemptions."]],
  ["How anti-doping works",[
    "WADA's Code sets rules worldwide. Athletes provide urine and blood samples in and out of competition, and elite athletes submit 'whereabouts' information daily. Samples can be stored and retested for up to ten years as detection methods improve; retests of samples from Beijing 2008 and London 2012 led to many disqualifications.",
    "Therapeutic Use Exemptions (TUEs) allow athletes with genuine medical needs to use otherwise banned medications. Strict liability means athletes are responsible for any banned substance found, regardless of intent."]],
  ["Ethics and debate",[
    "Arguments against doping cite fairness, athlete health, and the meaning of sport. Some commentators argue for allowing supervised enhancement, pointing to the difficulty of enforcement; in 2023, the controversial 'Enhanced Games,' permitting performance-enhancing drugs, were announced, and widely condemned by sports bodies.",
    "Most athletes and fans continue to support clean sport, and education programs aim to prevent doping from the youth level."]]
  ],
  terms:[["Anabolic steroids","Synthetic testosterone-like drugs that build muscle."],["Blood doping","Increasing red blood cells by transfusion or EPO."],["McLaren Report","2016 report on Russian state doping."],["TUE","Therapeutic Use Exemption."],["Whereabouts","Daily location reporting for out-of-competition testing."]],
  w:"Doping threatens athletes' health and sport's integrity; understanding it explains many of sport's biggest scandals.",
  src:["Doping in sport","Doping in East Germany","Doping in Russia","World Anti-Doping Code","BALCO scandal"],
  q:[
  ["When did the IOC begin drug testing at the Olympics?","1968","1896","1988","2000"],
  ["Which 2016 report exposed Russian state-sponsored doping?","McLaren Report","Mitchell Report","Taylor Report","Dubin Report"],
  ["Which cyclist died on Mont Ventoux in 1967?","Tom Simpson","Marco Pantani","Fausto Coppi","Knud Enemark Jensen"],
  ["How long can doping samples be stored for retesting?","Up to ten years","One year","Forever","Six months"],
  ["What is a TUE?","An exemption allowing medically needed banned medications","A type of steroid","A drug test","A penalty"],
  ["Which country ran State Plan 14.25?","East Germany","Soviet Union","China","Bulgaria"]]},

{ t:"Technology and Data in Sport", s:"From stopwatches to AI",
  sec:[
  ["Timing and measurement",[
    "Precise timing transformed sport: hand-held stopwatches gave way to fully automatic electronic timing (required for world sprint records from 1977), photo-finish cameras, and touchpads in swimming. Times are recorded to hundredths or thousandths of a second; swimmers can tie to the hundredth.",
    "Laser measurement and electronic distance measurement are used in field events."]],
  ["Wearables and tracking",[
    "GPS vests, heart rate monitors, accelerometers, and power meters (in cycling) track athletes' workloads in training and competition. Optical tracking systems in stadiums record every player's position many times per second; the NBA installed cameras in all arenas in 2013, and football leagues use similar systems.",
    "Consumer wearables such as smartwatches bring similar data to everyday exercisers."]],
  ["Analytics revolution",[
    "Data analytics influences decisions at every level: player recruitment, tactics, in-game strategy, and injury prevention. Baseball's sabermetrics, basketball's shift to three-pointers, football's expected goals, and American football's fourth-down decisions all reflect analytical thinking. Clubs such as Liverpool and Brentford became known for data-driven recruitment.",
    "Machine learning and artificial intelligence now analyze video, predict injuries, and generate scouting insights."]],
  ["Officiating technology",[
    "Technology assists officials: Hawk-Eye in tennis and cricket, goal-line technology and VAR in football, the Television Match Official in rugby, instant replay in American sports, and semi-automated offside technology (used at the 2022 World Cup). MLB moved toward automated ball-strike challenges.",
    "These systems increase accuracy but raise debates about the flow of games and the human element of sport."]],
  ["Equipment innovation and 'technological doping'",[
    "Equipment changes can transform performance: fiberglass poles, clap skates, carbon bikes, polyurethane swimsuits, and super shoes. Governing bodies must decide when innovation becomes unfair 'technological doping'; for example, the UCI's hour record rules and World Athletics' shoe regulations.",
    "In 2008–09, polyurethane swimsuits led to over 100 world records before being banned."]],
  ["Media technology",[
    "Broadcast innovations, slow-motion replay, on-screen graphics (such as the yellow first-down line in American football, 1998), drones, cameras in cars, and live statistics, have changed how fans experience sport. Streaming, highlights on social media, and virtual reality continue to reshape viewing.",
    "Fantasy sports and legal sports betting, expanded in the US after a 2018 Supreme Court ruling, have made data central to fans' engagement."]]
  ],
  terms:[["Photo finish","Camera image deciding close races."],["Power meter","Device measuring cycling power output."],["Optical tracking","Camera systems recording player positions."],["Semi-automated offside","AI-assisted offside detection."],["Technological doping","Unfair advantage from equipment."]],
  w:"Technology and data now shape how sport is played, judged, coached, and watched.",
  src:["Sports technology","Sports analytics","Semi-automated offside technology","Photo finish","Power meter"],
  q:[
  ["Which device measures a cyclist's output directly?","Power meter","Heart rate monitor","GPS watch","Speedometer"],
  ["When did the NBA install tracking cameras in all arenas?","2013","2001","1998","2020"],
  ["When was semi-automated offside technology used at a World Cup?","2022","2018","2014","2010"],
  ["What was 'technological doping' in swimming in 2008–09?","Polyurethane super suits","Starting blocks","Goggles","Pool lane ropes"],
  ["What graphic was introduced to American football broadcasts in 1998?","The yellow first-down line","The score bug","Instant replay","Slow motion"],
  ["Which 2018 event expanded legal sports betting in the US?","A Supreme Court ruling","A new NFL rule","An Olympic decision","A FIFA ruling"]]}

);


/* ---- from sports-19.js ---- */
/* SPORTS FOUNDATIONS, part 19: Unit 10 Sport and Society, chapters 1-4 */
COURSES.sports.units.push({ t:"Sport and Society", ch:[

{ t:"The Business of Sport", s:"Leagues, owners, and money",
  sec:[
  ["A global industry",[
    "Sport is a vast industry encompassing professional leagues, events, media rights, sponsorship, merchandise, sporting goods, fitness, betting, and tourism. Estimates of the global sports market run to hundreds of billions of dollars per year.",
    "The most valuable franchises, such as the Dallas Cowboys, Golden State Warriors, Real Madrid, and Manchester United, are each valued in the billions of dollars."]],
  ["Revenue streams",[
    "Media rights are the largest revenue source for many leagues: the NFL's TV deals beginning in 2023 were reported at over $100 billion over roughly a decade. Sponsorship includes naming rights (stadiums and events), shirt sponsors, and official partners. Ticketing, hospitality, concessions, and merchandise add further income.",
    "Prize money and appearance fees are key for individual sports; endorsement deals can make top athletes far richer than their salaries."]],
  ["Athletes' pay and unions",[
    "Athlete salaries rose dramatically after players won free agency. In baseball, the reserve clause bound players to teams until arbitrator Peter Seitz's 1975 decision (following Curt Flood's earlier challenge, which he lost in the Supreme Court in 1972) opened free agency. Players' unions negotiate collective bargaining agreements covering salaries, revenue splits, and working conditions; strikes and lockouts have canceled games, including the entire 1994 World Series and the 2004–05 NHL season.",
    "Michael Jordan's Nike deal (1984) created a model of athlete as global brand; athletes such as LeBron James, Cristiano Ronaldo, and Serena Williams have built business empires."]],
  ["Sporting goods and brands",[
    "Sporting goods companies such as Nike (founded 1964 as Blue Ribbon Sports), Adidas and Puma (founded by feuding brothers Adi and Rudolf Dassler in Herzogenaurach, Germany), and Under Armour sell shoes, apparel, and equipment worldwide, and sponsor teams and athletes. Their marketing shapes youth culture and fashion.",
    "Critics have highlighted labor conditions in overseas factories producing sports goods, leading to campaigns for workers' rights."]],
  ["New owners and investment",[
    "Ownership has shifted from local businessmen to billionaires, private equity funds, and sovereign wealth funds. Multi-club ownership groups own teams in several countries. Saudi Arabia's Public Investment Fund backs Newcastle United, LIV Golf, and other ventures; Qatar Sports Investments owns Paris Saint-Germain.",
    "These trends raise questions about competitive balance, fan influence, and 'sportswashing,' using sport to improve a country's image despite human rights concerns."]],
  ["Economics of hosting",[
    "Cities often justify subsidies for stadiums or bids for events by promising economic growth, jobs, and tourism. Most independent economic research finds that publicly funded stadiums and mega-events rarely produce the promised benefits, with costs frequently exceeding budgets.",
    "Nevertheless, sport can bring intangible benefits, civic pride, urban regeneration in some cases, and global visibility."]]
  ],
  terms:[["Media rights","Fees paid to broadcast sporting events."],["Free agency","Players' right to sign with any team when contracts end."],["Collective bargaining","Negotiation between leagues and players' unions."],["Naming rights","Paid rights to name a venue or event."],["Sportswashing","Using sport to improve a reputation."]],
  w:"Money shapes every level of sport, from players' salaries to which cities host the Olympics.",
  src:["Sports industry","Reserve clause","Curt Flood","Adidas","Sportswashing"],
  q:[
  ["Who challenged baseball's reserve clause and lost at the Supreme Court in 1972?","Curt Flood","Marvin Miller","Jackie Robinson","Andy Messersmith"],
  ["Which brothers founded Adidas and Puma?","The Dassler brothers","The Wright brothers","The Nike brothers","The Knight brothers"],
  ["What was canceled in 1994 due to a baseball strike?","The World Series","The All-Star Game","Opening Day only","The draft"],
  ["What is 'sportswashing'?","Using sport to improve a reputation despite human rights concerns","Cleaning sports equipment","Doping cover-ups","Laundering money through bets"],
  ["What does most economic research find about publicly funded stadiums?","They rarely produce promised benefits","They always pay for themselves","They double local GDP","They reduce taxes"],
  ["Which company was founded as Blue Ribbon Sports?","Nike","Reebok","Adidas","Under Armour"]]},

{ t:"Sport and the Media", s:"From newspapers to streaming",
  sec:[
  ["Print and radio",[
    "Sport and media grew together. In the 19th century, newspapers created sports pages and even founded events to boost sales, such as the Tour de France (L'Auto, 1903). Sports writers like Grantland Rice in America mythologized heroes.",
    "Radio brought live commentary from the 1920s: the first radio broadcast of a baseball game was in 1921, and the BBC broadcast the FA Cup final from 1927. Radio created shared national moments."]],
  ["Television",[
    "Television transformed sport from the 1950s. The 1936 Berlin Olympics had been the first televised in a limited way; by the 1960s live satellite broadcasts reached global audiences. TV money made the NFL and the Olympics wealthy and changed sports themselves: TV timeouts, tiebreaks in tennis, color uniforms, and evening kick-offs.",
    "ESPN launched in 1979 as the first 24-hour sports channel. Rupert Murdoch's Sky Sports deal with the new Premier League in 1992 showed how pay-TV could transform a league's finances."]],
  ["Commentary and journalism",[
    "Commentators and broadcasters, such as Howard Cosell, John Arlott, Vin Scully (who called Dodgers games for 67 years), and Martin Tyler, became beloved voices. Sports journalism ranges from match reports to investigative reporting, which has exposed doping, corruption, and abuse.",
    "Critics note conflicts of interest when broadcasters are also business partners of leagues."]],
  ["The digital age",[
    "The internet, social media, and streaming services have fragmented sports media. Leagues sell rights to streaming platforms such as Amazon Prime Video, Apple, and Netflix; highlights spread instantly on YouTube, X, Instagram, and TikTok. Athletes communicate directly with millions of fans, bypassing journalists.",
    "Documentary series such as The Last Dance, Drive to Survive, and All or Nothing have brought new audiences to sport."]],
  ["Representation in media",[
    "Women's sport has historically received a small share of media coverage, often with focus on appearance rather than performance; coverage has grown substantially in recent years, with record audiences for women's football and basketball.",
    "Media portrayals can reinforce or challenge stereotypes about race, gender, nationality, and disability. Athletes increasingly use their platforms to tell their own stories."]],
  ["Fans as media",[
    "Fans now produce content: podcasts, blogs, fan channels, and memes. Fantasy sports and betting apps have deepened engagement with data and multiple games.",
    "Social media also enables abuse of athletes, particularly racist and sexist abuse, prompting campaigns, boycotts, and calls for platform regulation."]]
  ],
  terms:[["Broadcast rights","Rights to televise or stream events."],["ESPN","First 24-hour sports channel, launched 1979."],["Pay-TV","Subscription television."],["Commentator","Broadcaster describing live action."],["Streaming","Delivering video over the internet."]],
  w:"Media turned sport into mass entertainment and continues to change how sport is played and consumed.",
  src:["Sports broadcasting","ESPN","Sports journalism","Sky Sports","Vin Scully"],
  q:[
  ["Which newspaper founded the Tour de France?","L'Auto","Le Monde","The Times","La Gazzetta dello Sport"],
  ["When did ESPN launch?","1979","1969","1989","1959"],
  ["Which broadcaster partnered with the new Premier League in 1992?","Sky Sports","BBC","ITV","ESPN"],
  ["Who called Dodgers games for 67 years?","Vin Scully","Howard Cosell","John Madden","Bob Costas"],
  ["Which documentary series boosted Formula One's audience?","Drive to Survive","The Last Dance","All or Nothing","Sunderland 'Til I Die"],
  ["How did TV change sports themselves?","It brought TV timeouts and evening games","It shortened the Olympics","It banned commentary","It made all sports free"]]},

{ t:"Race and Sport", s:"Barriers, breakthroughs, and ongoing struggles",
  sec:[
  ["Segregation and exclusion",[
    "For much of the 20th century, racial segregation excluded Black athletes from major sports in the United States and elsewhere. Baseball's color line kept Black players in the Negro Leagues; boxing champion Jack Johnson faced violent racism; and many golf clubs, swimming pools, and colleges barred Black people.",
    "In South Africa, apartheid laws enforced racial separation in sport, leading to international boycotts."]],
  ["Breakthroughs",[
    "Pioneers broke barriers: Jesse Owens in 1936, Jackie Robinson in baseball (1947), Althea Gibson and Arthur Ashe in tennis, Willie O'Ree in the NHL (1958), Kenny Washington and others reintegrating the NFL (1946), and Earl Lloyd in the NBA (1950). In English football, Viv Anderson became the first Black player to represent England in a full international (1978), and players such as Cyrille Regis and Laurie Cunningham endured racist abuse.",
    "Their success challenged racist ideas and inspired civil rights movements, but often came at great personal cost."]],
  ["Myths and stereotypes",[
    "Racist stereotypes have attributed Black athletes' success to 'natural' physical gifts while crediting white athletes with intelligence and work ethic, a pattern researchers have found in commentary. Black players were historically steered away from 'thinking' positions such as quarterback in American football ('stacking').",
    "Scientists emphasize that racial categories are poor proxies for genetic variation, and athletic success reflects complex interactions of genetics, culture, opportunity, and training."]],
  ["Representation in leadership",[
    "While many players in leagues such as the NFL and NBA are Black, coaches, executives, and owners have remained disproportionately white. Measures such as the NFL's Rooney Rule and English football's similar initiatives aim to improve diversity in hiring.",
    "Indigenous athletes have also faced discrimination, and team names and mascots based on Native Americans (such as Washington's former NFL name, changed in 2020 and becoming the Commanders, and Cleveland's baseball team, now the Guardians) have been widely criticized."]],
  ["Racism today",[
    "Racist abuse persists, from monkey chants in European football stadiums to online abuse, such as that aimed at England players Marcus Rashford, Jadon Sancho, and Bukayo Saka after the Euro 2020 final penalty shootout, and at Real Madrid's Vinícius Júnior in Spain. Campaigns such as 'Kick It Out' (founded 1993) and 'Show Racism the Red Card' work to combat it.",
    "Players 'taking the knee' before matches from 2020, following the murder of George Floyd, was a gesture against racism echoing Colin Kaepernick's protest."]],
  ["Sport as a force for unity",[
    "Sport has also brought people together across racial lines, from integrated teams to moments like South Africa's 1995 Rugby World Cup victory, which Nelson Mandela used to promote reconciliation. Siya Kolisi became South Africa's first Black Test rugby captain in 2018 and lifted the World Cup in 2019 and 2023.",
    "Understanding sport's racial history helps explain both its power to unite and its continuing inequalities."]]
  ],
  terms:[["Color line","Racial barrier excluding Black athletes."],["Stacking","Assigning players to positions by race."],["Rooney Rule","Requirement to interview minority candidates."],["Kick It Out","UK anti-racism campaign in football."],["Taking the knee","Gesture against racism."]],
  w:"Sport has been both a site of racial exclusion and a powerful stage for equality and change.",
  src:["Racism in sport","Willie O'Ree","Kick It Out (campaign)","Siya Kolisi","Native American mascot controversy"],
  q:[
  ["Who broke the NHL's color barrier in 1958?","Willie O'Ree","Grant Fuhr","Jarome Iginla","Herb Carnegie"],
  ["Who was the first Black player to represent England in a full international?","Viv Anderson","Cyrille Regis","Laurie Cunningham","John Barnes"],
  ["What is 'stacking' in sport?","Assigning players to positions by race","Stacking points","A defensive formation","Stacking trophies"],
  ["Who became South Africa's first Black Test rugby captain?","Siya Kolisi","Bryan Habana","Chester Williams","Tendai Mtawarira"],
  ["When was the anti-racism campaign Kick It Out founded?","1993","2005","1978","2015"],
  ["What did Washington's NFL team become after its name change?","Commanders","Redhawks","Generals","Guardians"]]},

{ t:"Women in Sport", s:"From exclusion to equality",
  sec:[
  ["Exclusion and myths",[
    "For much of history, women were excluded from sport by laws, customs, and pseudo-scientific claims that vigorous exercise would damage their health or fertility. Pierre de Coubertin opposed women's participation in the Olympics, calling it 'impractical, uninteresting, unaesthetic, and incorrect.' After several women collapsed at the end of the 800 m at the 1928 Olympics (as men often did too), the event was dropped for women until 1960.",
    "Women were barred from the Boston Marathon until 1972 and from the Olympic marathon until 1984."]],
  ["Pioneers",[
    "Pioneers include Charlotte Cooper, the first female Olympic champion in an individual event (1900); Babe Didrikson Zaharias, an Olympic track star and golf champion; Fanny Blankers-Koen, who won four athletics golds in 1948 as a mother of two; Wilma Rudolph; and Billie Jean King, who fought for equal pay and founded the Women's Sports Foundation.",
    "Alice Milliat founded the Women's World Games in the 1920s when the IOC refused to include women's athletics, pressuring the Olympics to change."]],
  ["Title IX and growth",[
    "In the United States, Title IX (1972), barring sex discrimination in federally funded education programs, led to a dramatic rise in girls' and women's sports participation, from about 300,000 high school girls before 1972 to over 3 million today. It also created the college pathway for many professional and Olympic athletes.",
    "Elsewhere, government policies, school programs, and professional leagues have expanded opportunities, though gaps remain in many countries."]],
  ["Equal pay and professionalization",[
    "Tennis led in equal prize money: the US Open from 1973, and Wimbledon from 2007 after a campaign led by Venus Williams. The US women's soccer team won equal pay in 2022. Women's professional leagues in football, basketball, cricket, and hockey have grown rapidly, with record media deals and attendance in the 2020s.",
    "Nevertheless, overall pay, sponsorship, and media coverage for women's sport remain far below men's in most sports."]],
  ["Olympic progress",[
    "Women made up about 2% of athletes at the 1900 Olympics and reached full numerical parity (50%) at Paris 2024, the first Games to do so. Every sport on the Olympic program now includes women's events.",
    "Female coaches, officials, and administrators remain under-represented, and efforts are under way to increase their numbers."]],
  ["Ongoing issues",[
    "Women athletes face issues including unequal resources, sexualized media coverage, harassment and abuse, lack of research on female physiology (most sports science studies have used male participants), and challenges combining sport with pregnancy and motherhood. Allyson Felix campaigned successfully for maternity protections in sponsorship contracts.",
    "Debates about eligibility for the female category, discussed in the science unit, are also part of the conversation about women's sport."]]
  ],
  terms:[["Title IX","1972 US law barring sex discrimination in education."],["Women's World Games","1920s events founded by Alice Milliat."],["Equal prize money","Same prize money for men and women."],["Gender parity","Equal numbers of men and women."],["Women's Sports Foundation","Advocacy group founded by Billie Jean King."]],
  w:"Women's sport has moved from exclusion to rapid growth, and its story is central to understanding sport today.",
  src:["Women's sports","Title IX","Alice Milliat","Fanny Blankers-Koen","Equal pay in sports"],
  q:[
  ["Who founded the Women's World Games?","Alice Milliat","Billie Jean King","Babe Didrikson","Kathrine Switzer"],
  ["Which Olympics first achieved full gender parity?","Paris 2024","Tokyo 2020","London 2012","Rio 2016"],
  ["Which Grand Slam was first to offer equal prize money (1973)?","US Open","Wimbledon","French Open","Australian Open"],
  ["Who won four athletics golds in 1948 as a mother of two?","Fanny Blankers-Koen","Wilma Rudolph","Babe Didrikson","Betty Cuthbert"],
  ["What did Title IX do?","Barred sex discrimination in federally funded education programs","Created the WNBA","Banned women from contact sports","Funded the Olympics"],
  ["Which athlete campaigned for maternity protections in sponsorship contracts?","Allyson Felix","Serena Williams","Megan Rapinoe","Simone Biles"]]}

]});


/* ---- from sports-20.js ---- */
/* SPORTS FOUNDATIONS, part 20: Unit 10 chapters 5-9 */
COURSES.sports.units[9].ch.push(

{ t:"Sport and Politics", s:"Boycotts, diplomacy, and propaganda",
  sec:[
  ["Sport as politics",[
    "Although sports bodies often claim to be apolitical, sport has always been entangled with politics. Governments use sport to build national identity, demonstrate strength, and win prestige; activists use it to protest; and international sport reflects diplomatic relationships.",
    "George Orwell wrote in 1945 that serious sport 'is war minus the shooting,' though others stress sport's capacity for peaceful exchange."]],
  ["Propaganda and prestige",[
    "Fascist Italy and Nazi Germany used sport for propaganda: Italy hosted and won the 1934 World Cup, and Berlin 1936 showcased the regime, though Jesse Owens's victories undercut its racist ideology. During the Cold War, the US and the Soviet Union competed for Olympic medals as proof of their systems' superiority; East Germany, with a population of about 17 million, finished above the United States in the 1976 medal table.",
    "Today, nations still invest heavily in medal success, and hosting mega-events is a tool of 'soft power.'"]],
  ["Boycotts and bans",[
    "The international sporting boycott of apartheid South Africa, including its exclusion from the Olympics from 1964 to 1992 and the 1977 Gleneagles Agreement among Commonwealth nations, is considered one of the most effective uses of sport to apply political pressure. The 1970s rugby tours by the All Blacks provoked protests and the 1976 African boycott of the Montreal Olympics.",
    "Cold War boycotts in 1980 and 1984 harmed athletes without changing policy. Russia was excluded from many international competitions after its 2022 invasion of Ukraine."]],
  ["Sport diplomacy",[
    "Sport can open diplomatic doors: 'ping-pong diplomacy' preceded US–China rapprochement in 1971; North and South Korea marched together at several Olympic opening ceremonies and fielded a joint women's ice hockey team at PyeongChang 2018. 'Cricket diplomacy' has occasionally eased India–Pakistan tensions.",
    "The Olympic Truce, revived by the United Nations, calls for peace during the Games, echoing the ancient ekecheiria."]],
  ["Conflicts and sport",[
    "Sport has also been linked to conflict: the 1969 'Football War' between El Salvador and Honduras erupted amid tensions heightened by World Cup qualifiers, though its causes were deeper. The 1990 riot at a Dinamo Zagreb–Red Star Belgrade match is remembered as a symbolic moment before the wars in Yugoslavia.",
    "Conversely, a Christmas truce football match between British and German soldiers in 1914 is a famous symbol of shared humanity."]],
  ["Hosting and human rights",[
    "Awarding major events to authoritarian states has drawn criticism, including the 2008 Beijing and 2022 Beijing Winter Olympics, the 2014 Sochi Olympics, the 2018 Russia and 2022 Qatar World Cups, and the planned 2034 Saudi Arabia World Cup. Human rights groups highlight migrant workers' conditions, freedom of expression, and LGBTQ+ rights.",
    "Supporters argue that engagement through sport can encourage reform; critics call it sportswashing."]]
  ],
  terms:[["Soft power","Influence through attraction rather than force."],["Gleneagles Agreement","1977 Commonwealth sporting boycott of apartheid."],["Olympic Truce","Call for peace during the Games."],["Football War","1969 conflict between El Salvador and Honduras."],["Medal table","Ranking of nations by Olympic medals."]],
  w:"Sport is a stage for politics, from propaganda and boycotts to diplomacy and protest.",
  src:["Politics and sports","Sporting boycott of South Africa during the apartheid era","Ping-pong diplomacy","Football War","1980 Summer Olympics boycott"],
  q:[
  ["Who wrote that serious sport is 'war minus the shooting'?","George Orwell","Winston Churchill","Pierre de Coubertin","Nelson Mandela"],
  ["What was the 1977 Gleneagles Agreement?","A Commonwealth sporting boycott of apartheid South Africa","A peace treaty","A football rule","An Olympic bid"],
  ["Which countries fought the 1969 'Football War'?","El Salvador and Honduras","Argentina and England","Brazil and Uruguay","Mexico and USA"],
  ["Which two countries fielded a joint women's ice hockey team in 2018?","North and South Korea","China and Taiwan","USA and Canada","Russia and Ukraine"],
  ["From when to when was South Africa excluded from the Olympics?","1964 to 1992","1948 to 1960","1976 to 1984","1990 to 2000"],
  ["What preceded US–China rapprochement in 1971?","Ping-pong diplomacy","Basketball diplomacy","Chess diplomacy","Baseball diplomacy"]]},

{ t:"Athletes as Activists", s:"Using the platform",
  sec:[
  ["A long tradition",[
    "Athletes have used their fame to speak on social issues for over a century. Jack Johnson defied racist norms; Jesse Owens and Joe Louis became symbols of hope; Jackie Robinson spoke out on civil rights after his early years of enforced silence.",
    "In 1967, Black athletes including Jim Brown, Bill Russell, and Lew Alcindor (later Kareem Abdul-Jabbar) met in Cleveland to support Muhammad Ali's refusal of the draft, in the 'Ali Summit.'"]],
  ["1968",[
    "At the Mexico City Olympics, sprinters Tommie Smith (gold) and John Carlos (bronze) raised black-gloved fists during the US national anthem to protest racial injustice, wearing no shoes to represent poverty; silver medalist Peter Norman of Australia wore an Olympic Project for Human Rights badge in solidarity. Smith and Carlos were expelled from the Games and faced years of hostility; today they are widely honored.",
    "Czech gymnast Věra Čáslavská turned her head away during the Soviet anthem at the same Games to protest the invasion of Czechoslovakia."]],
  ["Women and equality",[
    "Billie Jean King fought for equal pay and founded the WTA; Martina Navratilova was one of the first major athletes to come out as gay (1981). The US women's soccer team's equal pay campaign set an example worldwide.",
    "Athletes have also campaigned against sexual abuse in sport, such as the gymnasts who testified against Larry Nassar."]],
  ["Recent activism",[
    "In 2016, NFL quarterback Colin Kaepernick began kneeling during the anthem to protest police brutality; he did not play in the NFL again after that season. In 2020, after George Floyd's murder, athletes across leagues protested; NBA players briefly boycotted playoff games, and many wore social justice messages. Marcus Rashford campaigned successfully in 2020 for free school meals for children in England.",
    "LeBron James, Naomi Osaka, Megan Rapinoe, and Lewis Hamilton have spoken on racial justice and other issues; Hamilton wore messages demanding justice for Breonna Taylor."]],
  ["Rules and backlash",[
    "The Olympic Charter's Rule 50 restricts political demonstrations at Olympic venues; the IOC relaxed it before Tokyo 2020, allowing gestures on the field of play before competition under conditions. Football's governing bodies restrict political messages on kits.",
    "Activist athletes often face criticism ('stick to sports') and career consequences, but many argue that athletes, as citizens with large platforms, have a right and responsibility to speak."]],
  ["Athletes and humanitarian work",[
    "Many athletes engage in charity and humanitarian work: Roberto Clemente died delivering aid to earthquake victims; Didier Drogba helped call for peace during Ivory Coast's civil war; Dikembe Mutombo built a hospital in Kinshasa.",
    "Athlete-led organizations, such as player unions and groups like Global Athlete, also advocate for athletes' own rights within sport."]]
  ],
  terms:[["Rule 50","Olympic rule restricting political protests."],["Ali Summit","1967 meeting of Black athletes supporting Ali."],["Olympic Project for Human Rights","Movement behind the 1968 protest."],["Taking a knee","Kneeling during anthem as protest."],["Platform","An athlete's public influence."]],
  w:"Athletes have long used their visibility to push for justice, often at great personal cost.",
  src:["1968 Olympics Black Power salute","Colin Kaepernick","Peter Norman","Marcus Rashford","Rule 50"],
  q:[
  ["Which two sprinters raised fists on the podium at the 1968 Olympics?","Tommie Smith and John Carlos","Carl Lewis and Jesse Owens","Bob Beamon and Lee Evans","Jim Hines and Charlie Greene"],
  ["Who was the silver medalist who supported their protest?","Peter Norman","Ralph Boston","Jim Hines","Lennox Miller"],
  ["Who began kneeling during the national anthem in 2016?","Colin Kaepernick","LeBron James","Michael Bennett","Eric Reid"],
  ["Which footballer campaigned for free school meals in England in 2020?","Marcus Rashford","Raheem Sterling","Harry Kane","Jordan Henderson"],
  ["What does Olympic Rule 50 restrict?","Political demonstrations","Doping","Advertising only","Number of athletes"],
  ["Which tennis star came out as gay in 1981?","Martina Navratilova","Billie Jean King","Chris Evert","Steffi Graf"]]},

{ t:"Fans, Stadiums, and Identity", s:"Why we cheer",
  sec:[
  ["Fandom and identity",[
    "Fans form deep emotional attachments to teams, often inherited from family or place. Social identity theory explains that people derive part of their sense of self from group memberships; fans 'bask in reflected glory' after wins ('we won') and distance themselves after losses ('they lost').",
    "Fandom offers community, ritual, and continuity across generations, and research has linked it to wellbeing and social connection."]],
  ["Rituals and atmosphere",[
    "Fans create atmosphere through chants, songs ('You'll Never Walk Alone' at Liverpool), tifos (giant choreographed banners), drums, and colors. Organized supporter groups, called ultras in Europe and barras bravas in South America, lead singing and display. Tailgating before American football games is a ritual of food and community.",
    "The 'home advantage' in sport, consistent across many sports, has been attributed to crowd support, familiarity, travel fatigue of opponents, and referees' subtle bias; games without crowds during the COVID-19 pandemic reduced home advantage in several sports, supporting the crowd's role."]],
  ["Stadiums through history",[
    "Stadiums evolved from Greek stadia and Roman amphitheaters to Victorian football grounds with terraces, modern multipurpose stadiums, and today's high-tech arenas. Iconic venues include Wembley, the Maracanã, Camp Nou, Yankee Stadium, Lambeau Field, the Melbourne Cricket Ground, and Madison Square Garden.",
    "Modern stadiums emphasize hospitality, technology, and revenue, with retractable roofs and giant screens, but critics say they sometimes sacrifice atmosphere and affordability."]],
  ["Hooliganism and violence",[
    "Football hooliganism, organized violence between fan groups, peaked in England in the 1970s and 1980s, with the 'English disease' exported abroad. The Heysel disaster of 1985 led to English clubs' ban from Europe. Policing, all-seater stadiums, CCTV, banning orders, and changing culture greatly reduced it in England, though violence persists in some countries.",
    "Sociologists link hooliganism to masculinity, territorial identity, and social marginalization."]],
  ["Fan power",[
    "Fans have influenced their clubs through protests (against owners, ticket prices, or the 2021 Super League), supporter trusts, and fan ownership. Some fans have founded new clubs, such as AFC Wimbledon after the original club moved to Milton Keynes, rising through the leagues.",
    "Green Bay Packers fans own their team as shareholders, a unique model in US major leagues."]],
  ["Fandom and society",[
    "Sporting events create collective emotional experiences, from national celebrations to mourning. Yet fandom can also exclude or intimidate, with racist, sexist, or homophobic chanting.",
    "Clubs and organizations increasingly promote inclusive fan cultures, family sections, and accessible facilities for disabled supporters."]]
  ],
  terms:[["Ultras","Organized hardcore supporter groups."],["Tifo","Large choreographed fan display."],["Home advantage","Tendency for home teams to win more."],["Hooliganism","Organized fan violence."],["Supporter trust","Fan organization seeking influence."]],
  w:"Fans give sport its meaning and atmosphere, and their power and passion shape clubs and communities.",
  src:["Fan (person)","Ultras","Home advantage","Football hooliganism","AFC Wimbledon"],
  q:[
  ["What is a tifo?","A large choreographed fan display","A type of chant","A stadium seat","A team scarf"],
  ["What happened to home advantage when games were played without crowds?","It decreased in several sports","It increased sharply","It stayed exactly the same","It reversed completely"],
  ["Which club did fans found after the original moved to Milton Keynes?","AFC Wimbledon","FC United of Manchester","Phoenix FC","Accrington Stanley"],
  ["Which NFL team is owned by its fans as shareholders?","Green Bay Packers","Dallas Cowboys","New England Patriots","Chicago Bears"],
  ["Which song is sung at Liverpool?","You'll Never Walk Alone","Glory Glory","Blue Moon","I'm Forever Blowing Bubbles"],
  ["What was hooliganism called when exported abroad from England?","The English disease","The British problem","Football fever","Terrace culture"]]},

{ t:"Gambling, Match-Fixing, and Integrity", s:"When sport is corrupted",
  sec:[
  ["Betting and sport",[
    "Betting has accompanied sport since antiquity and drove the codification of many sports. Today sports betting is a huge global industry, with online betting accessible on phones. In the US, a 2018 Supreme Court decision (Murphy v. NCAA) struck down a federal ban, allowing states to legalize sports betting, and most have done so.",
    "Betting sponsorship has become pervasive in some sports, raising concerns about gambling addiction, especially among young people; some countries have restricted gambling advertising in sport."]],
  ["Match-fixing",[
    "Match-fixing means manipulating the result or events of a competition, usually for betting profits. 'Spot-fixing' manipulates specific events, such as a no-ball in cricket. Famous scandals include the 1919 Black Sox in baseball; the 2000 cricket scandal involving South African captain Hansie Cronje; the 2010 Pakistan spot-fixing case at Lord's, leading to prison sentences; Italian football's 2006 Calciopoli scandal, which saw Juventus stripped of titles and relegated; and fixed matches in tennis's lower tiers.",
    "Organized crime syndicates have targeted lower-level matches where players are poorly paid and less monitored."]],
  ["Corruption in governance",[
    "Beyond the field, corruption has affected decisions on hosting and governance: the Salt Lake City Olympic bid scandal (1998), the 2015 FIFA corruption cases, and investigations into bribery for the 2016 Rio Olympics.",
    "Reforms include ethics committees, term limits, independent oversight, and transparency rules."]],
  ["Protecting integrity",[
    "Integrity units monitor betting patterns for suspicious activity; the International Tennis Integrity Agency and similar bodies investigate. Athletes are often banned from betting on their own sport; in 2024, MLB banned a player for life for betting on baseball, and several NFL and NBA players were suspended for gambling violations.",
    "Education programs teach athletes to recognize and report approaches by fixers."]],
  ["Cheating within the game",[
    "Other integrity issues include sign-stealing (the Houston Astros' electronic sign-stealing scandal of 2017, punished in 2020), ball tampering (Australia's 2018 'Sandpapergate'), 'Deflategate' (the 2015 NFL controversy over underinflated footballs), and 'tanking' (losing deliberately to gain draft advantages).",
    "Pete Rose, baseball's all-time hits leader, was banned for life in 1989 for betting on games; MLB removed deceased banned players, including Rose, from its ineligible list in 2025."]],
  ["Why integrity matters",[
    "Sport's value depends on the uncertainty of outcome and the belief that competition is genuine. Without integrity, fans, sponsors, and athletes lose trust.",
    "Protecting integrity requires cooperation among sports bodies, betting operators, law enforcement, and governments."]]
  ],
  terms:[["Match-fixing","Manipulating a competition's result."],["Spot-fixing","Manipulating specific events in a match."],["Calciopoli","2006 Italian football scandal."],["Integrity unit","Body investigating corruption in sport."],["Tanking","Losing deliberately for future advantage."]],
  w:"Integrity is what makes sport meaningful; betting and corruption threaten it in new ways.",
  src:["Match fixing","Calciopoli","Hansie Cronje","Murphy v. National Collegiate Athletic Association","Houston Astros sign stealing scandal"],
  q:[
  ["Which 2018 Supreme Court case allowed US states to legalize sports betting?","Murphy v. NCAA","NCAA v. Alston","Flood v. Kuhn","Brown v. Board"],
  ["What was Calciopoli?","A 2006 Italian football scandal","A cricket fixing case","A doping scandal","A stadium disaster"],
  ["What is spot-fixing?","Manipulating specific events in a match","Fixing the final score","Marking pitch spots","Moving a ball spot"],
  ["Which team was punished for electronic sign-stealing in 2017?","Houston Astros","Boston Red Sox","New York Yankees","Los Angeles Dodgers"],
  ["For what was Pete Rose banned in 1989?","Betting on baseball games","Steroids","Fighting","Tax evasion"],
  ["Which South African cricket captain was involved in a 2000 fixing scandal?","Hansie Cronje","Graeme Smith","Shaun Pollock","Kepler Wessels"]]},

{ t:"Mega-Events and Their Legacy", s:"Hosting the world",
  sec:[
  ["What mega-events are",[
    "Mega-events are large, global sporting events, chiefly the Summer and Winter Olympics and the FIFA World Cup, plus continental championships, the Commonwealth Games, and the Asian Games. They attract billions of viewers and require years of preparation and massive investment.",
    "Hosts are chosen by governing bodies, traditionally through competitive bidding; the IOC reformed its process in 2019 to use targeted dialogue with preferred hosts."]],
  ["Costs and overruns",[
    "Research by economist Bent Flyvbjerg and colleagues found that every Olympics from 1960 to 2016 had cost overruns, with an average overrun of over 150%. Montreal took about 30 years to pay off its 1976 Olympic debts. Athens 2004 left unused venues, and Rio 2016 coincided with economic crisis.",
    "Sochi 2014 was reported as the most expensive Olympics in history, with costs around $50 billion including infrastructure. Qatar spent an estimated $200 billion or more on infrastructure related to the 2022 World Cup."]],
  ["Benefits and legacies",[
    "Supporters cite benefits: urban regeneration (Barcelona 1992 transformed its waterfront and is often seen as a model), improved transport, tourism, national pride, and increased sport participation, though participation boosts are often temporary.",
    "London 2012 regenerated part of east London with the Queen Elizabeth Olympic Park, though debates continue about displacement and affordability."]],
  ["Human costs",[
    "Mega-events have displaced residents, as in Rio and Beijing, and led to security crackdowns. Concerns about migrant workers' deaths and labor conditions in Qatar drew global scrutiny before the 2022 World Cup.",
    "Environmental impacts include construction emissions and travel by fans; organizers increasingly promise sustainability and use existing or temporary venues, as Paris 2024 did."]],
  ["Declining interest",[
    "Rising costs and public opposition led many cities to withdraw from Olympic bidding; referendums in cities such as Munich, Hamburg, and Oslo rejected bids. In response, the IOC awarded 2024 and 2028 simultaneously (Paris and Los Angeles) and encouraged cheaper, more sustainable Games.",
    "The 2026 World Cup across three countries, and the 2030 World Cup spread across Spain, Portugal, and Morocco with opening matches in South America to mark its centenary, reflect a trend toward multi-country hosting."]],
  ["Other multisport events",[
    "The Commonwealth Games (first held as the British Empire Games in 1930 in Hamilton, Canada), Asian Games (1951), Pan American Games (1951), African Games (1965), and the World University Games bring nations together regionally.",
    "The Youth Olympic Games (since 2010) and the World Games (for non-Olympic sports) extend the multisport model."]]
  ],
  terms:[["Mega-event","Very large global sporting event."],["Cost overrun","Spending beyond the budget."],["Legacy","Long-term effects of hosting."],["Commonwealth Games","Multisport event for Commonwealth nations."],["Bidding","Competition to host an event."]],
  w:"Hosting mega-events brings prestige but also huge costs and controversies, shaping cities for decades.",
  src:["Mega-event","Cost of the Olympic Games","Commonwealth Games","Asian Games","2030 FIFA World Cup"],
  q:[
  ["How long did Montreal take to pay off its 1976 Olympic debts?","About 30 years","2 years","10 years","It never did"],
  ["Which Olympics is often seen as a model of urban regeneration?","Barcelona 1992","Athens 2004","Atlanta 1996","Sochi 2014"],
  ["Which two cities were awarded the 2024 and 2028 Olympics simultaneously?","Paris and Los Angeles","London and Tokyo","Rome and Boston","Madrid and Toronto"],
  ["Where were the first British Empire Games held in 1930?","Hamilton, Canada","London","Sydney","Cardiff"],
  ["Which countries host the main 2030 World Cup?","Spain, Portugal, and Morocco","USA, Canada, and Mexico","Argentina and Uruguay","Saudi Arabia"],
  ["What did research find about Olympic costs from 1960 to 2016?","Every Games had cost overruns","Most were under budget","Costs were always accurate","Only Winter Games overran"]]}

);


/* ---- from sports-21.js ---- */
/* SPORTS FOUNDATIONS, part 21: Unit 10 chapters 10-15 */
COURSES.sports.units[9].ch.push(

{ t:"Sports Law", s:"Contracts, courts, and rights",
  sec:[
  ["What sports law covers",[
    "Sports law is not a single body of law but the application of many areas, contract, employment, antitrust (competition), intellectual property, tort, criminal, and international law, to sport, plus the private rules of sports governing bodies (sometimes called lex sportiva).",
    "Lawyers in the field represent athletes, clubs, leagues, federations, broadcasters, and sponsors."]],
  ["Contracts and agents",[
    "Player contracts set salaries, length, bonuses, image rights, and conduct clauses. Agents negotiate contracts and endorsements; regulations govern agent licensing and fees, as FIFA reintroduced agent licensing with its Football Agent Regulations from 2023.",
    "Standard player contracts in North American leagues are governed by collective bargaining agreements negotiated between leagues and players' unions."]],
  ["Antitrust and labor",[
    "Because leagues act collectively, they face antitrust scrutiny. In the US, baseball enjoys a unique antitrust exemption from the 1922 Supreme Court case Federal Baseball Club v. National League, reaffirmed in Flood v. Kuhn (1972) though acknowledged as an 'anomaly.' Other leagues rely on collective bargaining (the labor exemption) to protect rules such as drafts and salary caps.",
    "NCAA v. Alston (2021) applied antitrust law to college sports, and in Europe, competition law cases such as Bosman (1995) and the European Super League case (decided by the Court of Justice of the EU in December 2023, which found that FIFA and UEFA's prior-approval rules had breached EU law) shape governance."]],
  ["Disciplinary and anti-doping law",[
    "Sports bodies have internal disciplinary processes; appeals often go to the Court of Arbitration for Sport (CAS). In doping cases, the WADA Code's strict liability principle applies, but athletes may reduce sanctions by showing no fault or no significant fault, as in contamination cases.",
    "Courts sometimes review sports decisions for fairness and human rights, as in Caster Semenya's case before the European Court of Human Rights."]],
  ["Injury, liability, and criminal law",[
    "Participants are generally considered to accept the ordinary risks of their sport, but reckless or intentional harm can lead to civil liability or criminal charges; courts in several countries have convicted players for violent assaults during games. Organizers owe duties of care regarding safety, as in stadium disasters and concussion litigation.",
    "Safeguarding laws and bodies, such as the US Center for SafeSport (2017), address abuse."]],
  ["Intellectual property and broadcasting",[
    "Leagues and events protect trademarks (logos, team names), broadcasting rights, and data. Olympic symbols are specially protected by law in many countries. 'Ambush marketing,' when brands associate themselves with an event without paying, is often restricted by special event laws.",
    "Image rights let athletes control commercial use of their name and likeness, as in the college NIL changes. Piracy of live sports streams is a major legal battleground."]]
  ],
  terms:[["Lex sportiva","Body of rules and decisions specific to sport."],["Antitrust exemption","Baseball's unique immunity from US antitrust law."],["Collective bargaining agreement","Contract between league and players' union."],["Ambush marketing","Unauthorized association with an event."],["Duty of care","Legal obligation to protect participants' safety."]],
  w:"Sports law shapes contracts, eligibility, broadcasting, and safety, and is a growing legal career field.",
  src:["Sports law","Federal Baseball Club v. National League","Flood v. Kuhn","Court of Arbitration for Sport","Ambush marketing"],
  q:[
  ["Which 1922 case gave baseball an antitrust exemption?","Federal Baseball Club v. National League","Flood v. Kuhn","NCAA v. Alston","Brown v. NFL"],
  ["What is ambush marketing?","Unauthorized association of a brand with an event","A sponsor's official campaign","A ticket promotion","Ticket scalping"],
  ["Where are many sports disciplinary appeals heard?","Court of Arbitration for Sport","International Court of Justice","UN Security Council","European Parliament"],
  ["What did the EU Court of Justice decide in the Super League case (2023)?","FIFA and UEFA's prior-approval rules breached EU law","The Super League was illegal","UEFA must dissolve","Clubs must leave UEFA"],
  ["What is lex sportiva?","The body of rules and decisions specific to sport","A Latin sports motto","A type of contract","A doping test"],
  ["What do image rights let athletes do?","Control commercial use of their name and likeness","Ban photographers","Choose referees","Own stadiums"]]},

{ t:"Sport, Health, and Physical Education", s:"Activity for all",
  sec:[
  ["The health case",[
    "Regular physical activity reduces the risk of heart disease, stroke, type 2 diabetes, several cancers, depression, and early death, and improves sleep, mood, and cognitive function. The World Health Organization estimates that a large share of adults and most adolescents worldwide do not meet recommended activity levels.",
    "Physical inactivity is considered one of the leading risk factors for death globally. Sport is one of many ways to be active, alongside walking, cycling, play, and active work."]],
  ["Guidelines",[
    "The WHO's 2020 guidelines recommend that adults do 150–300 minutes of moderate-intensity or 75–150 minutes of vigorous-intensity aerobic activity per week, plus muscle-strengthening activities on two or more days; older adults should add balance training. Children and adolescents should average at least 60 minutes of moderate-to-vigorous activity daily.",
    "Reducing sedentary time, such as long periods of sitting, is also recommended."]],
  ["Physical education",[
    "School physical education (PE) aims to develop movement skills, fitness, knowledge, and lifelong enjoyment of activity. Its history includes 19th-century gymnastic systems (German Turnen, Swedish gymnastics), military drill, and the British games tradition.",
    "Modern approaches such as 'physical literacy' focus on the motivation, confidence, competence, and knowledge to value and engage in physical activity for life. Critics note that negative PE experiences can turn children away from activity, so inclusive, enjoyable programs matter."]],
  ["Barriers to participation",[
    "Barriers to sport include cost, access to facilities, time, safety, lack of confidence, discrimination, and cultural expectations. Girls' participation tends to drop sharply in adolescence; campaigns such as England's 'This Girl Can' (2015) aimed to change attitudes.",
    "Community programs, free events such as parkrun, and urban design that encourages walking and cycling widen access."]],
  ["Sport for development",[
    "Sport for development uses sport to achieve social goals: education, health, gender equality, peacebuilding, and youth engagement. The United Nations recognizes sport as an enabler of sustainable development.",
    "Programs range from football leagues teaching HIV awareness in Africa to midnight basketball and boxing gyms for at-risk youth. Evaluations show sport works best combined with education and mentoring, rather than alone."]],
  ["Exercise as medicine",[
    "Doctors increasingly 'prescribe' exercise for chronic diseases and mental health. Even modest activity brings benefits: research suggests that moving from inactivity to some activity produces the biggest health gains.",
    "Being active with others, in teams, clubs, or groups, adds social benefits that support long-term adherence."]]
  ],
  terms:[["Physical literacy","Motivation, confidence, and skill for lifelong activity."],["Sedentary behavior","Prolonged sitting or low-energy activity."],["Sport for development","Using sport for social goals."],["Physical education","School-based movement education."],["Exercise is medicine","Treating exercise as a health prescription."]],
  w:"Sport's biggest impact may be on public health; understanding guidelines helps people stay active for life.",
  src:["Physical activity","Physical education","Physical literacy","Sport for development","This Girl Can"],
  q:[
  ["How much daily activity does the WHO recommend for children?","At least 60 minutes on average","10 minutes","3 hours","Only on weekends"],
  ["What is physical literacy?","Motivation, confidence, and skill to be active for life","Reading about sport","Knowing rules","A PE exam"],
  ["Which campaign aimed to increase women's participation in England in 2015?","This Girl Can","Just Do It","Kick It Out","Get Moving"],
  ["What do evaluations suggest about sport-for-development programs?","They work best combined with education and mentoring","Sport alone solves social problems","They have no effect","They harm children"],
  ["Where do the biggest health gains come from?","Moving from inactivity to some activity","Going from very fit to elite","Only intense training","Only team sports"],
  ["How often should adults do muscle-strengthening activities, according to WHO?","Two or more days a week","Once a month","Every hour","Never"]]},

{ t:"Inclusion and Identity in Sport", s:"Who gets to play",
  sec:[
  ["LGBTQ+ athletes",[
    "For decades, lesbian, gay, bisexual, transgender, and queer athletes faced stigma, especially in men's team sports. Pioneers include tennis players Billie Jean King (outed in 1981) and Martina Navratilova, diver Greg Louganis, footballer Justin Fashanu, England's first openly gay professional footballer (1990), who faced severe abuse, and NBA player Jason Collins (2013).",
    "Openness has grown: many Olympians competed openly at recent Games, and Australian footballer Josh Cavallo and English footballer Jake Daniels came out while playing professionally. Campaigns such as the Rainbow Laces and You Can Play fight homophobia, though abuse persists, and some countries' laws remain hostile."]],
  ["Religion and culture",[
    "Religious and cultural practices intersect with sport. FIFA lifted its ban on hijabs in 2014 after advocacy; Ibtihaj Muhammad became the first US Olympian to compete in a hijab (fencing, 2016). Athletes fasting during Ramadan, and leagues adapting with breaks for players to break their fast, show accommodation.",
    "France's ban on headscarves for its own athletes at Paris 2024, based on its secularism laws, drew criticism from human rights groups. Some athletes decline to play on religious holy days, such as Eric Liddell refusing to run on a Sunday in 1924 (depicted in Chariots of Fire) and Sandy Koufax skipping a World Series game on Yom Kippur in 1965."]],
  ["Class and access",[
    "Sports have often been divided by class: polo, sailing, and equestrian sports require wealth, while boxing and football were traditionally working-class. Studies of British Olympians have found private school students heavily over-represented in some sports.",
    "Costs of youth sport ('pay-to-play'), travel teams, and equipment create barriers; scholarships, public facilities, and community clubs help widen access."]],
  ["Ethnic minorities and migrants",[
    "Sport has played a role in integrating immigrants and building multicultural national teams, such as France's 1998 'black-blanc-beur' World Cup team, celebrated as a symbol of diversity, though debates about identity continued. Refugee athletes have competed in a Refugee Olympic Team since 2016, and in Paris 2024 Cindy Ngamba won the team's first medal (boxing bronze).",
    "At the same time, minority communities can face barriers in access, coaching pathways, and leadership roles."]],
  ["Inclusive design",[
    "Inclusive approaches include adapted rules, unified sports (Special Olympics teams mixing athletes with and without intellectual disabilities), walking football for older people, and wheelchair-accessible facilities.",
    "The idea that 'sport is for everyone' is central to the Olympic Charter's statement that the practice of sport is a human right."]]
  ],
  terms:[["Inclusion","Ensuring everyone can participate."],["Rainbow Laces","Campaign against homophobia in sport."],["Refugee Olympic Team","Team of refugee athletes since 2016."],["Unified sports","Teams mixing athletes with and without disabilities."],["Pay-to-play","Fees required to participate in sport."]],
  w:"Making sport open to all, regardless of identity, faith, class, or background, is one of its central modern challenges.",
  src:["Homosexuality in sports","Ibtihaj Muhammad","Refugee Olympic Team","Eric Liddell","Justin Fashanu"],
  q:[
  ["Who was England's first openly gay professional footballer (1990)?","Justin Fashanu","Thomas Hitzlsperger","Jake Daniels","Robbie Rogers"],
  ["Who was the first US Olympian to compete in a hijab?","Ibtihaj Muhammad","Dalilah Muhammad","Sarah Attar","Ruqaya Al-Ghasra"],
  ["Who refused to run on a Sunday at the 1924 Olympics?","Eric Liddell","Harold Abrahams","Paavo Nurmi","Jesse Owens"],
  ["Since when has there been a Refugee Olympic Team?","2016","2000","2008","2024"],
  ["Who skipped a 1965 World Series game for Yom Kippur?","Sandy Koufax","Hank Greenberg","Don Drysdale","Ken Holtzman"],
  ["When did FIFA lift its hijab ban?","2014","2000","2022","1998"]]},

{ t:"Sport in Film, Literature, and Art", s:"Stories of the game",
  sec:[
  ["Ancient celebration",[
    "Sport has inspired art since antiquity: Greek vases depicting athletes, Myron's sculpture the Discobolus (Discus Thrower, about 450 BCE), and the poet Pindar's odes celebrating Olympic victors. Roman mosaics show chariot racers and gladiators.",
    "Medieval tapestries and manuscripts depict tournaments, hunts, and ball games."]],
  ["Literature",[
    "Sport has produced rich writing. Classics include Ring Lardner's baseball stories, Bernard Malamud's The Natural, Ernest Hemingway's bullfighting writing, C. L. R. James's Beyond a Boundary on cricket and colonialism, Norman Mailer's The Fight about the Rumble in the Jungle, and A. J. Liebling's boxing essays.",
    "Modern works include Nick Hornby's Fever Pitch (football fandom), H. G. Bissinger's Friday Night Lights, Michael Lewis's Moneyball and The Blind Side, Laura Hillenbrand's Seabiscuit, Andre Agassi's memoir Open, and Haruki Murakami's What I Talk About When I Talk About Running."]],
  ["Film",[
    "Sports films often tell underdog stories. Famous examples include Rocky (1976), Raging Bull (1980, about boxer Jake LaMotta), Chariots of Fire (1981, about the 1924 Olympics), Hoosiers, Field of Dreams, A League of Their Own (1992, about the women's baseball league during World War II), Remember the Titans, Million Dollar Baby, Invictus, Moneyball, Rush (Lauda vs Hunt), I, Tonya, King Richard (about the Williams sisters' father), and Ford v Ferrari.",
    "Documentaries such as When We Were Kings (Ali), Hoop Dreams, Senna, Free Solo, and The Last Dance are acclaimed."]],
  ["Painting, photography, and design",[
    "Artists such as Thomas Eakins (rowing and boxing), George Bellows (boxing), Edgar Degas (horse racing), and L. S. Lowry (crowds going to football matches) depicted sport. Sports photography captured iconic images, such as Neil Leifer's photo of Ali standing over Sonny Liston (1965).",
    "Olympic posters, logos, and stadium architecture are important design traditions."]],
  ["Why sport stories resonate",[
    "Sport offers built-in drama: clear goals, conflict, uncertainty, struggle, and resolution. Stories explore themes of perseverance, class, race, nationalism, aging, and identity.",
    "Sports narratives can also oversimplify, turning complex lives into myths of triumph; critical writing seeks the fuller human story."]]
  ],
  terms:[["Discobolus","Myron's ancient Greek discus thrower sculpture."],["Pindar","Greek poet who praised Olympic victors."],["Underdog story","Narrative of an unlikely winner."],["Sports documentary","Non-fiction film about sport."],["Iconic image","Photograph that defines a moment."]],
  w:"Sport is a rich source of stories and art that explore what it means to strive, win, and lose.",
  src:["Sports film","Discobolus","Beyond a Boundary","Chariots of Fire","Pindar"],
  q:[
  ["Who sculpted the Discobolus?","Myron","Phidias","Praxiteles","Polykleitos"],
  ["Which book by C. L. R. James explores cricket and colonialism?","Beyond a Boundary","Fever Pitch","The Natural","Open"],
  ["Which film depicts the 1924 Olympics?","Chariots of Fire","Rocky","Invictus","Rush"],
  ["Which film is about the women's baseball league during World War II?","A League of Their Own","Field of Dreams","The Natural","Bull Durham"],
  ["Which ancient Greek poet wrote odes for Olympic victors?","Pindar","Homer","Sappho","Hesiod"],
  ["Which painter depicted crowds going to football matches?","L. S. Lowry","Edgar Degas","George Bellows","Thomas Eakins"]]},

{ t:"Sport and the Environment", s:"Climate, nature, and sustainability",
  sec:[
  ["Sport's footprint",[
    "Sport has an environmental footprint: fans' and teams' travel (often the largest share of an event's emissions), stadium energy and water use, construction, equipment manufacturing, and waste. Golf courses use land and water; motorsport burns fuel; global tours involve constant flights.",
    "Mega-events have huge carbon footprints from construction and international travel."]],
  ["Climate threats to sport",[
    "Climate change threatens sport itself. Rising temperatures increase heat illness risks; events such as the Australian Open and Tokyo 2020 adopted extreme heat policies. Studies project that many former Winter Olympic host cities may not be climate-reliable for winter games by later this century.",
    "Flooding damages grassroots pitches; droughts affect playing surfaces; wildfire smoke has disrupted events; and rising seas threaten coastal venues."]],
  ["Responses",[
    "The UN Sports for Climate Action Framework (2018) invites sports organizations to commit to reducing emissions. Initiatives include renewable energy in stadiums, public transport for fans, reusable cups, and carbon reduction targets. Paris 2024 aimed to halve emissions compared with recent Games, using mostly existing or temporary venues.",
    "Forest Green Rovers, an English football club, was declared by FIFA the world's first carbon-neutral football club and serves vegan food; Formula One pledged net zero by 2030."]],
  ["Athletes and nature",[
    "Outdoor athletes, surfers, climbers, skiers, and sailors have become advocates for environmental protection, as the places they compete are directly affected. Groups such as Protect Our Winters (founded 2007 by snowboarder Jeremy Jones) campaign on climate.",
    "Critics warn of 'greenwashing' when sponsors with heavy emissions market sport sustainability."]],
  ["Sustainable participation",[
    "Individuals can reduce sport's footprint by traveling actively or by public transport, sharing equipment, buying second-hand gear, and supporting clubs' sustainability efforts.",
    "Sport's global reach also gives it power to raise awareness of environmental issues among fans."]]
  ],
  terms:[["Carbon footprint","Total greenhouse gas emissions caused."],["Sports for Climate Action","UN framework for sports organizations."],["Greenwashing","Misleading environmental claims."],["Heat policy","Rules for playing in extreme heat."],["Net zero","Balancing emissions with removals."]],
  w:"Climate change threatens many sports, and sport can lead by reducing its own environmental impact.",
  src:["Environmental impact of sport","Sports for Climate Action Framework","Forest Green Rovers F.C.","Protect Our Winters","Climate change and sport"],
  q:[
  ["What is often the largest source of an event's emissions?","Fans' and teams' travel","Floodlights","Concessions","Ticket printing"],
  ["Which English club was declared the first carbon-neutral football club by FIFA?","Forest Green Rovers","Brentford","Brighton","Bristol City"],
  ["When was the UN Sports for Climate Action Framework launched?","2018","2008","1998","2023"],
  ["Who founded Protect Our Winters in 2007?","Jeremy Jones","Shaun White","Lindsey Vonn","Tony Hawk"],
  ["What is greenwashing?","Misleading environmental claims","Planting grass","Recycling","Using green uniforms"],
  ["By when did Formula One pledge net zero?","2030","2050","2025","2040"]]}

);


/* ---- from sports-22.js ---- */
/* SPORTS FOUNDATIONS, part 22: Unit 11 Sport Around the World */
COURSES.sports.units.push({ t:"Sport Around the World", ch:[

{ t:"Sport in Africa", s:"Runners, footballers, and traditions",
  sec:[
  ["Traditional sports",[
    "Africa has rich traditional sports, many tied to ritual, community, and preparation for adulthood. Wrestling is especially important: Senegalese laamb, which combines wrestling with punches, music, and mystical rituals, is the country's most popular sport, drawing stadium crowds. Nigerian and Nuba (Sudan) wrestling traditions are also famous.",
    "Stick fighting among the Zulu and Xhosa of South Africa, Ethiopian genna (a hockey-like game played at Christmas), and mancala-type board games are other traditions. Dambe, a Hausa boxing tradition from Nigeria and Niger, has gained online popularity."]],
  ["Colonialism and modern sport",[
    "European colonizers introduced football, cricket, rugby, athletics, and boxing through schools, missions, and armies. Africans adopted and transformed these sports, which became vehicles for anticolonial pride and national identity after independence in the 1950s–60s.",
    "The Confederation of African Football (CAF) was founded in 1957; Ghana's President Kwame Nkrumah saw football as a tool for Pan-African unity."]],
  ["Running",[
    "East African distance runners from Kenya and Ethiopia have dominated world distance running since Abebe Bikila's barefoot marathon win in 1960 and Kenya's Kip Keino in 1968. Most elite Kenyan runners come from the Kalenjin ethnic group in the highlands of the Rift Valley, where altitude, running culture, training camps, and economic motivation combine.",
    "Stars include Haile Gebrselassie, Kenenisa Bekele, Tirunesh Dibaba, Eliud Kipchoge, and Faith Kipyegon. North Africans such as Morocco's Hicham El Guerrouj and Algeria's Noureddine Morceli and Hassiba Boulmerka excelled at middle distances."]],
  ["Football and beyond",[
    "Football is Africa's most popular sport. African nations have grown stronger at the World Cup, from Cameroon's 1990 quarterfinal run to Morocco's 2022 semifinal. African stars dominate many European clubs. Rugby is a passion in South Africa (with four World Cup titles), and cricket in South Africa and Zimbabwe.",
    "Basketball is growing, with the NBA-backed Basketball Africa League (2021) and stars such as Hakeem Olajuwon (Nigeria), Dikembe Mutombo (DR Congo), Joel Embiid (Cameroon), and Giannis Antetokounmpo (Greek-born to Nigerian parents)."]],
  ["Challenges and hosting",[
    "Challenges include limited funding, facilities, and governance problems, and the 'brain drain' of talent to Europe and elsewhere. South Africa hosted the 2010 FIFA World Cup, the first in Africa, remembered for the vuvuzela horn.",
    "Senegal hosts the 2026 Youth Olympic Games in Dakar, the first Olympic event held in Africa. Africa's young population represents great sporting potential."]]
  ],
  terms:[["Laamb","Senegalese wrestling."],["Kalenjin","Kenyan ethnic group producing many elite runners."],["CAF","Confederation of African Football."],["Vuvuzela","Plastic horn famous from the 2010 World Cup."],["Dambe","Hausa boxing tradition."]],
  w:"Africa's sporting story combines ancient traditions, anticolonial pride, and global stars.",
  src:["Sport in Africa","Senegalese wrestling","Kenyan long-distance runners","2010 FIFA World Cup","2026 Summer Youth Olympics"],
  q:[
  ["What is Senegal's most popular sport?","Laamb (wrestling)","Football","Basketball","Athletics"],
  ["Which Kenyan ethnic group produces many elite distance runners?","Kalenjin","Kikuyu","Maasai","Luo"],
  ["Where was the first African World Cup held in 2010?","South Africa","Nigeria","Egypt","Morocco"],
  ["Where will the 2026 Youth Olympics be held, the first Olympic event in Africa?","Dakar","Cairo","Nairobi","Cape Town"],
  ["Which Ghanaian president saw football as a tool for Pan-African unity?","Kwame Nkrumah","Jerry Rawlings","Kofi Annan","John Kufuor"],
  ["When was CAF founded?","1957","1904","1980","1930"]]},

{ t:"Sport in Asia", s:"Ancient arts and modern powers",
  sec:[
  ["Traditional sports",[
    "Asia has many ancient sports: sumo and martial arts in Japan; taekwondo and ssireum (wrestling) in Korea; wushu, dragon boat racing, and cuju in China; kabaddi, kho-kho, and wrestling (kushti) in South Asia; buzkashi in Afghanistan and Central Asia; sepak takraw in Southeast Asia; and Mongolia's Naadam festival, featuring wrestling, archery, and horse racing.",
    "Polo spread from Persia across Asia, and chess and Go originated in the region."]],
  ["Cricket and South Asia",[
    "Cricket is the dominant sport in India, Pakistan, Bangladesh, Sri Lanka, Afghanistan, and Nepal, carrying enormous national passion. Sri Lanka won the 1996 World Cup; Afghanistan's rise despite war has been a remarkable story. The IPL made India the financial center of cricket.",
    "Field hockey was India's great Olympic sport, and badminton (P. V. Sindhu, Saina Nehwal) and wrestling have produced Indian Olympic medalists. Neeraj Chopra won India's first Olympic athletics gold in the javelin at Tokyo 2020."]],
  ["China",[
    "After joining the Olympic movement fully in 1984 (when shooter Xu Haifeng won China's first gold), China invested heavily in a state sports system and topped the gold medal table at Beijing 2008. China dominates table tennis, diving, badminton, weightlifting, and gymnastics.",
    "Basketball is hugely popular, boosted by Yao Ming's NBA career (2002–11). Tennis player Li Na won two Grand Slams. China hosted the 2022 Winter Olympics in Beijing, the first city to host both Summer and Winter Games."]],
  ["Japan and Korea",[
    "Japan hosted the first Asian Olympics in 1964 (Tokyo), signaling its postwar recovery, and again in 2021. Baseball is Japan's leading team sport, with the summer high school tournament at Koshien a national event; football grew after the J.League's launch in 1993. Japanese athletes excel in judo, wrestling, gymnastics, swimming, and figure skating.",
    "South Korea hosted the 1988 Seoul Olympics and the 2018 PyeongChang Winter Games, and co-hosted the 2002 World Cup with Japan, reaching the semifinals. Korea excels in archery, short-track skating, taekwondo, golf (especially women), and esports."]],
  ["West and Central Asia",[
    "The Gulf states have invested heavily in hosting and owning sport: Qatar's 2022 World Cup, Saudi Arabia's boxing, golf, football, Formula One, and the 2034 World Cup, and the UAE's ownership of Manchester City. Iran is a power in wrestling, weightlifting, and volleyball.",
    "Central Asian nations such as Kazakhstan and Uzbekistan excel in boxing, wrestling, and weightlifting, building on traditional strength sports."]],
  ["Southeast Asia",[
    "Southeast Asia is passionate about football and badminton; Indonesia and Malaysia have great badminton traditions. Muay Thai is Thailand's national sport, and the Philippines loves basketball and boxing, producing Manny Pacquiao.",
    "The Southeast Asian Games, held every two years, are a major regional event."]]
  ],
  terms:[["Naadam","Mongolian festival of wrestling, archery, and horse racing."],["Kabaddi","South Asian contact team sport."],["Koshien","Japan's famous high school baseball tournament."],["Sepak takraw","Southeast Asian kick volleyball."],["SEA Games","Southeast Asian Games."]],
  w:"Asia combines ancient sporting traditions with some of the world's largest and fastest-growing sports economies.",
  src:["Sport in Asia","Naadam","Sport in China","Sport in India","Sport in Japan"],
  q:[
  ["Which festival features wrestling, archery, and horse racing in Mongolia?","Naadam","Tsagaan Sar","Nowruz","Diwali"],
  ["Who won India's first Olympic athletics gold?","Neeraj Chopra","Milkha Singh","P. T. Usha","Abhinav Bindra"],
  ["Which city first hosted both Summer and Winter Olympics?","Beijing","Tokyo","Seoul","Sapporo"],
  ["Who won China's first Olympic gold in 1984?","Xu Haifeng","Li Ning","Yao Ming","Liu Xiang"],
  ["What is Thailand's national sport?","Muay Thai","Football","Badminton","Sepak takraw"],
  ["Which country won the 1996 Cricket World Cup?","Sri Lanka","India","Pakistan","Australia"]]},

{ t:"Sport in Latin America", s:"Passion, flair, and resilience",
  sec:[
  ["Football as identity",[
    "Across Latin America, football is a central part of national and local identity. Brazil's 'jogo bonito,' Argentina's passion and its 'potrero' street-football culture, and Uruguay's 'garra charrúa' (fighting spirit) are celebrated styles. Clubs are social institutions; derbies such as Boca–River and Flamengo–Fluminense ('Fla-Flu') divide cities.",
    "Writers such as Uruguay's Eduardo Galeano, in Soccer in Sun and Shadow, captured football's poetry and politics."]],
  ["Baseball in the Caribbean and Mexico",[
    "Baseball dominates in Cuba, the Dominican Republic, Venezuela, Puerto Rico, Nicaragua, and parts of Mexico. Cuba's national team long dominated amateur baseball; many Cuban players defected to play in MLB. The Dominican town of San Pedro de Macorís has produced an extraordinary number of major leaguers.",
    "The Caribbean Series brings together winter league champions from the region."]],
  ["Boxing and combat",[
    "Boxing has produced Latin American legends: Argentina's Carlos Monzón, Panama's Roberto Durán ('Hands of Stone'), Mexico's Julio César Chávez and Saúl 'Canelo' Álvarez, Puerto Rico's Félix Trinidad, and Cuba's three-time Olympic champions Teófilo Stevenson and Félix Savón. Mexico's lucha libre, masked professional wrestling, is a cultural icon.",
    "Brazil's capoeira and the Gracie family's jiu-jitsu shaped global martial arts."]],
  ["Other sports",[
    "Argentina excels in polo, rugby (Los Pumas), field hockey (Las Leonas), basketball (2004 Olympic gold), and tennis. Brazil has strengths in volleyball, beach volleyball, Formula One (Senna, Piquet, Fittipaldi), surfing, and judo. Colombia loves cycling (Egan Bernal won the 2019 Tour de France) and football. Jamaica, though Caribbean and English-speaking, is a sprinting superpower.",
    "Mexico hosted the 1968 Olympics and the 1970 and 1986 World Cups, and co-hosts 2026; Rio de Janeiro hosted South America's first Olympics in 2016."]],
  ["Challenges",[
    "Latin American sport faces challenges of inequality, violence among some supporter groups, corruption, and the export of talent to wealthier leagues. Yet sport offers pathways and pride, and grassroots street football and community clubs remain vibrant.",
    "The Pan American Games, first held in 1951 in Buenos Aires, unite the Americas every four years."]]
  ],
  terms:[["Jogo bonito","'The beautiful game,' Brazil's style."],["Garra charrúa","Uruguay's famous fighting spirit."],["Lucha libre","Mexican masked professional wrestling."],["Fla-Flu","Flamengo vs Fluminense derby."],["Pan American Games","Multisport event of the Americas."]],
  w:"Latin American sport is passionate and stylish, and has given the world many of its greatest stars.",
  src:["Sport in Latin America","Lucha libre","Eduardo Galeano","Baseball in the Dominican Republic","Pan American Games"],
  q:[
  ["What is lucha libre?","Mexican masked professional wrestling","A Brazilian dance","Cuban baseball","An Argentine rugby style"],
  ["Which Dominican town has produced many major leaguers?","San Pedro de Macorís","Santo Domingo","Santiago","La Romana"],
  ["Which Colombian won the 2019 Tour de France?","Egan Bernal","Nairo Quintana","Rigoberto Urán","Fernando Gaviria"],
  ["Who wrote Soccer in Sun and Shadow?","Eduardo Galeano","Gabriel García Márquez","Jorge Luis Borges","Pablo Neruda"],
  ["Where did South America's first Olympics take place?","Rio de Janeiro, 2016","Buenos Aires","Mexico City","Santiago"],
  ["Which Cuban boxer won three Olympic heavyweight golds (1972–80)?","Teófilo Stevenson","Félix Savón","Kid Chocolate","Ángel Espinosa"]]},

{ t:"Sport in Europe", s:"Clubs, communities, and traditions",
  sec:[
  ["The club system",[
    "Europe's sporting life is built on clubs: member-based associations offering many sports, from local amateur teams to giants like FC Barcelona (with over 100,000 members) and multi-sport clubs such as Real Madrid (football and basketball) and Olympiacos. Germany's Sportvereine (sports clubs) have millions of members, often subsidized by local governments.",
    "This differs from the American model, where school and college sports dominate youth development."]],
  ["National passions",[
    "Football is the leading sport in most European countries, but each has distinct passions: rugby in Wales, Ireland, and southern France; Gaelic games in Ireland; cycling in Belgium, the Netherlands, France, and Italy; skiing in Austria, Switzerland, and Norway; handball in Scandinavia, Germany, and Spain; basketball in Lithuania, Serbia, Greece, and Spain; ice hockey in Finland, Sweden, and the Czech Republic; and darts and snooker in Britain.",
    "Cross-country skiing and biathlon are national obsessions in Norway, which wins remarkable numbers of Winter Olympic medals for a nation of about 5.5 million."]],
  ["Traditional sports and festivals",[
    "Traditional sports include Basque pelota (and jai alai) and rural sports such as stone lifting; Swiss Schwingen wrestling and Hornussen; Scottish Highland games; Florence's calcio storico; Siena's Palio horse race (twice each summer around the city square since the Middle Ages); and Ireland's road bowling.",
    "Bullfighting in Spain, Portugal, and southern France is a traditional spectacle increasingly contested on animal welfare grounds; several regions have restricted it."]],
  ["Eastern Europe",[
    "Under communism, Eastern European states built centralized sports systems that produced Olympic success in gymnastics, athletics, weightlifting, wrestling, and more, sometimes with state doping. After 1989–91, many systems collapsed or reformed.",
    "Countries such as Croatia (football and handball), Serbia (basketball, water polo, tennis with Novak Djokovic), Hungary (water polo, fencing, swimming), and Poland (volleyball, ski jumping, athletics) remain sporting powers."]],
  ["Pan-European competitions",[
    "UEFA's Champions League, the Euros, the EuroLeague in basketball, the Six Nations in rugby, the Ryder Cup in golf, and the European Championships multisport event give Europe a dense calendar of continental competition.",
    "The European Union also influences sport through rulings on free movement, competition law, and broadcasting."]]
  ],
  terms:[["Sportverein","German community sports club."],["Palio","Siena's historic horse race."],["Basque pelota","Traditional ball game played against walls."],["Schwingen","Swiss traditional wrestling."],["Multi-sport club","Club offering several sports."]],
  w:"Europe's club-based model and regional traditions shape the world's most-followed professional sports.",
  src:["Sport in Europe","Palio di Siena","Basque pelota","Schwingen","Sport in Norway"],
  q:[
  ["What is the Palio?","A historic horse race in Siena","A Spanish bullfight","A Basque ball game","A Swiss wrestling contest"],
  ["Which country wins remarkable numbers of Winter Olympic medals for a population of about 5.5 million?","Norway","Austria","Switzerland","Finland"],
  ["What is Schwingen?","Swiss traditional wrestling","German gymnastics","Austrian skiing","Dutch skating"],
  ["Which sport is a national passion in Lithuania?","Basketball","Ice hockey","Rugby","Cricket"],
  ["What is the core of Europe's sporting life?","Member-based clubs","School teams","College athletics","Private franchises only"],
  ["Where is jai alai traditionally rooted?","The Basque region","Scotland","Switzerland","Sicily"]]},

{ t:"Sport in Oceania and North America's Cultures", s:"Island nations and frontier games",
  sec:[
  ["Australia",[
    "Australia is often described as one of the world's most sports-obsessed nations. Its major codes include Australian rules football, rugby league, cricket, rugby union, and soccer, with distinct regional loyalties (Aussie rules in Victoria and the south and west, rugby league in New South Wales and Queensland).",
    "Australia has an outstanding Olympic record, especially in swimming, and the Australian Institute of Sport (1981), founded after poor results at the 1976 Olympics, became a model for national sports systems. The Melbourne Cup, the Boxing Day Test at the MCG, the Australian Open, and the AFL Grand Final are national rituals. Sydney hosted the 2000 Olympics, where Cathy Freeman, an Aboriginal athlete, won the 400 m."]],
  ["New Zealand",[
    "Rugby is central to New Zealand's identity; the All Blacks are among the most successful teams in any sport. New Zealand also excels in netball (the Silver Ferns), rowing, sailing (America's Cup wins), cricket, and track cycling. Māori culture, including the haka, is woven into national sport.",
    "Mountaineer Edmund Hillary, who first climbed Everest with Tenzing Norgay, appears on the New Zealand five-dollar note."]],
  ["The Pacific islands",[
    "Pacific Island nations such as Fiji, Samoa, and Tonga punch far above their weight in rugby; Fiji's sevens team won Olympic gold in 2016 and 2020. Many players of Pacific heritage star for New Zealand, Australia, and in professional leagues worldwide.",
    "Papua New Guinea is passionate about rugby league. The Pacific Games bring the region's nations together."]],
  ["North American traditions",[
    "Beyond the big four leagues, North America has rich sporting cultures: rodeo in the West, rooted in cowboy work; Indigenous lacrosse and traditional games such as snowsnake; Inuit games such as the high kick, tested at the Arctic Winter Games; and Canada's curling and hockey traditions.",
    "High school sports, especially 'Friday night lights' football in Texas and basketball in Indiana, bind American communities."]],
  ["Small nations, big impact",[
    "Small nations often find sporting identity in particular sports: Jamaica in sprinting, Fiji in rugby sevens, Kenya in distance running, Iceland in football (whose 2016 Euro run and 'thunderclap' captured the world), and New Zealand in rugby.",
    "Such successes show how culture, focus, and community can overcome limited resources."]]
  ],
  terms:[["Australian Institute of Sport","National elite sports institute founded 1981."],["Silver Ferns","New Zealand's netball team."],["Pacific Games","Multisport event of Pacific nations."],["Arctic Winter Games","Event featuring traditional northern sports."],["Boxing Day Test","Traditional cricket Test at the MCG."]],
  w:"From Australia's sporting culture to Pacific rugby and Iceland's football, nations shape sport and sport shapes nations.",
  src:["Sport in Australia","Australian Institute of Sport","Sport in New Zealand","Fiji national rugby sevens team","Cathy Freeman"],
  q:[
  ["Which Aboriginal athlete won the 400 m at Sydney 2000?","Cathy Freeman","Nova Peris","Patrick Johnson","Evonne Goolagong"],
  ["When was the Australian Institute of Sport founded?","1981","1956","2000","1976"],
  ["What is New Zealand's netball team called?","Silver Ferns","Black Ferns","Tall Blacks","Kiwis"],
  ["Which nation won Olympic rugby sevens gold in 2016 and 2020?","Fiji","New Zealand","Samoa","South Africa"],
  ["Which mountaineer appears on New Zealand's five-dollar note?","Edmund Hillary","George Mallory","Reinhold Messner","Peter Blake"],
  ["Which small nation's 2016 Euro run featured a famous 'thunderclap'?","Iceland","Wales","Albania","Northern Ireland"]]}

]});


/* ---- from sports-23.js ---- */
/* SPORTS FOUNDATIONS, part 23: Unit 12 Legends, Rivalries, and Great Moments */
COURSES.sports.units.push({ t:"Legends, Rivalries, and Great Moments", ch:[

{ t:"The Greatest of All Time", s:"How we judge greatness",
  sec:[
  ["The GOAT debate",[
    "Fans love to argue about the 'greatest of all time' (GOAT). Criteria include dominance over contemporaries, longevity, championships, records, versatility, influence on the sport, and performance in big moments. Comparing eras is difficult because of changes in equipment, training, competition depth, and rules.",
    "Statistics help but cannot settle debates; context matters, such as the strength of opponents or the role of teammates."]],
  ["Candidates across sports",[
    "Commonly cited GOAT candidates include: football, Pelé, Maradona, and Messi; basketball, Michael Jordan and LeBron James; American football, Tom Brady; baseball, Babe Ruth; hockey, Wayne Gretzky; tennis, Novak Djokovic, Roger Federer, Rafael Nadal, Serena Williams, and Steffi Graf; golf, Jack Nicklaus and Tiger Woods; cricket, Don Bradman; boxing, Muhammad Ali and Sugar Ray Robinson.",
    "In athletics, Usain Bolt and Carl Lewis; in swimming, Michael Phelps and Katie Ledecky; in gymnastics, Simone Biles; in cycling, Eddy Merckx; in Formula One, Lewis Hamilton, Michael Schumacher, Ayrton Senna, and Juan Manuel Fangio."]],
  ["Statistical outliers",[
    "Some achievements stand out statistically: Bradman's Test average of 99.94 is more than 60% higher than the next best long-career averages; Gretzky has more assists than any other player has total points; Phelps's 23 Olympic golds are more than double the next highest total; Jahangir Khan's 555-match unbeaten run in squash; and Edwin Moses's 122 straight 400 m hurdles wins.",
    "Other astonishing records include Cal Ripken's 2,632 consecutive games and Joe DiMaggio's 56-game hitting streak."]],
  ["Influence beyond results",[
    "Some athletes are judged great for changing their sport or society: Jackie Robinson, Billie Jean King, Muhammad Ali, Jesse Owens, Johan Cruyff (who shaped football's tactics as player and coach), and Dick Fosbury (who changed high jumping forever).",
    "Others revolutionized how a sport is played, like Stephen Curry with the three-pointer, or expanded its global reach, like Tiger Woods and Yao Ming."]],
  ["Thinking critically",[
    "Recency bias leads people to overrate current stars; nostalgia can do the opposite. Media and marketing shape reputations. Women's achievements have historically been underrated in GOAT discussions, and athletes from less-covered countries or sports are often overlooked.",
    "Ultimately, GOAT debates are less about final answers than about appreciating what made each athlete special."]]
  ],
  terms:[["GOAT","Greatest of all time."],["Era adjustment","Accounting for differences between periods."],["Recency bias","Overvaluing recent events."],["Longevity","Sustaining excellence over many years."],["Statistical outlier","Result far beyond the norm."]],
  w:"Debating greatness sharpens understanding of what excellence means across sports and eras.",
  src:["Greatest of all time","Don Bradman","Michael Phelps","Wayne Gretzky","Muhammad Ali"],
  q:[
  ["What does GOAT stand for?","Greatest of all time","Greatest Olympic athlete today","Grand Olympic all-time","Golden Olympic award trophy"],
  ["Whose Test batting average of 99.94 is a famous outlier?","Don Bradman","Sachin Tendulkar","Brian Lara","Steve Smith"],
  ["Who has more assists than any other NHL player has total points?","Wayne Gretzky","Mario Lemieux","Gordie Howe","Sidney Crosby"],
  ["Which athlete changed high jumping forever?","Dick Fosbury","Javier Sotomayor","Mutaz Barshim","Valeriy Brumel"],
  ["What is recency bias?","Overvaluing recent events","Favoring old players","Ignoring statistics","Preferring home teams"],
  ["Whose 56-game hitting streak is a famous record?","Joe DiMaggio","Ted Williams","Pete Rose","Ty Cobb"]]},

{ t:"Great Rivalries", s:"Opponents who define each other",
  sec:[
  ["Why rivalries matter",[
    "Rivalries add meaning and drama to sport. They may be rooted in geography (local derbies), history and politics (national rivalries), contrasting styles or personalities, or repeated meetings in big games. Rivals often push each other to greater heights.",
    "Rivalries also sell tickets and attract audiences, and leagues and broadcasters promote them."]],
  ["Team rivalries",[
    "Famous club rivalries include Real Madrid vs Barcelona, Boca Juniors vs River Plate, Celtic vs Rangers, Liverpool vs Manchester United, the New York Yankees vs Boston Red Sox (fueled by the 'Curse of the Bambino' after Boston sold Babe Ruth to New York in 1919, broken when Boston won the 2004 World Series after coming back from 3–0 down against the Yankees), the Boston Celtics vs Los Angeles Lakers, and the Montreal Canadiens vs Toronto Maple Leafs.",
    "College rivalries such as Michigan–Ohio State and Duke–North Carolina in basketball are equally intense."]],
  ["National rivalries",[
    "International rivalries often reflect history: England vs Germany and England vs Argentina in football (the latter colored by the 1982 Falklands War and Maradona's 1986 goals); the Ashes between England and Australia; India vs Pakistan in cricket; USA vs USSR in Cold War hockey and basketball (including the controversial 1972 Olympic basketball final); and Brazil vs Argentina.",
    "The Ryder Cup (USA vs Europe) and the Six Nations add continental and national pride."]],
  ["Individual rivalries",[
    "Great individual rivalries include Ali vs Frazier in boxing (three fights, 1971–75), Borg vs McEnroe and Evert vs Navratilova in tennis, Federer vs Nadal vs Djokovic, Magic Johnson vs Larry Bird, Senna vs Prost in Formula One, Coe vs Ovett in middle-distance running, Nicklaus vs Palmer in golf, and Messi vs Ronaldo in football.",
    "Contrasting personalities, the cool Borg versus the fiery McEnroe, or the stylish Federer versus the relentless Nadal, deepen these stories."]],
  ["Respect within rivalry",[
    "Many rivals develop deep mutual respect. Federer and Nadal's friendship, shown when they cried together at Federer's farewell match in 2022, and Magic and Bird's friendship after retirement are examples.",
    "At their worst, rivalries can turn toxic, leading to violence among fans; at their best, they show sport's capacity to combine fierce competition with sportsmanship."]]
  ],
  terms:[["Derby","Match between local rivals."],["Curse of the Bambino","Supposed Red Sox curse after selling Babe Ruth."],["The Ashes","England–Australia cricket rivalry."],["El Clásico","Real Madrid vs Barcelona."],["Sportsmanship","Fairness and respect toward opponents."]],
  w:"Rivalries give sport its narrative tension and often bring out the very best performances.",
  src:["Sports rivalry","Yankees–Red Sox rivalry","Ali–Frazier trilogy","Borg–McEnroe rivalry","Federer–Nadal rivalry"],
  q:[
  ["What ended the 'Curse of the Bambino'?","The Red Sox winning the 2004 World Series","The Yankees winning in 1996","Babe Ruth's retirement","A new stadium"],
  ["How many times did Ali and Frazier fight?","Three","Two","Four","Five"],
  ["Which Formula One rivalry was among sport's fiercest?","Senna vs Prost","Hamilton vs Verstappen only","Schumacher vs Alonso","Lauda vs Hunt only"],
  ["Which cricket nations contest a famously intense rivalry rooted in partition?","India and Pakistan","England and West Indies","Australia and New Zealand","South Africa and Zimbabwe"],
  ["Which middle-distance runners had a famous British rivalry?","Coe and Ovett","Bannister and Chataway","Cram and Elliott","Farah and Radcliffe"],
  ["Which tennis rivals cried together at a 2022 farewell?","Federer and Nadal","Borg and McEnroe","Agassi and Sampras","Djokovic and Murray"]]},

{ t:"Upsets, Miracles, and Unforgettable Moments", s:"When the impossible happens",
  sec:[
  ["The appeal of the underdog",[
    "Sport's uncertainty means the weaker side sometimes wins, and these upsets become legendary. Psychologists note that many neutral fans instinctively support underdogs, perhaps from a sense of fairness.",
    "Upsets are more common in low-scoring sports such as football and hockey, where a single goal can decide a game."]],
  ["Famous team upsets",[
    "The 'Miracle on Ice' (1980), when US college players beat the Soviet hockey team; Leicester City winning the 2015–16 Premier League after starting the season as 5,000-to-1 outsiders; Greece winning Euro 2004; the 1950 'Maracanazo'; the US beating England 1–0 at the 1950 World Cup; and Joe Namath's New York Jets winning Super Bowl III.",
    "Other shocks include Japan beating South Africa at the 2015 Rugby World Cup ('the Brighton Miracle'), Saudi Arabia beating eventual champions Argentina at the 2022 World Cup, and 16th seed UMBC beating top seed Virginia in the 2018 NCAA tournament, the first such upset in men's March Madness."]],
  ["Individual upsets",[
    "Buster Douglas knocked out the unbeaten Mike Tyson in Tokyo in 1990 as a 42-to-1 underdog. Seventeen-year-old Boris Becker won Wimbledon unseeded in 1985. Emma Raducanu won the 2021 US Open as a qualifier without dropping a set. Rulon Gardner, an American wrestler, beat the long-unbeaten Russian Aleksandr Karelin at Sydney 2000.",
    "Steven Bradbury of Australia won the 2002 Olympic short-track speed skating gold when all his rivals crashed on the final corner."]],
  ["Iconic moments",[
    "Some moments transcend results: Jesse Owens in Berlin; Bob Beamon's long jump of 1968; Nadia Comăneci's perfect 10; Muhammad Ali lighting the Olympic cauldron in Atlanta in 1996 with hands trembling from Parkinson's; Derek Redmond's father helping him finish the 400 m semifinal after a hamstring tear in Barcelona 1992; and Kerri Strug's one-footed vault landing in 1996.",
    "In football, moments include Maradona's 'Goal of the Century,' Zidane's volley in the 2002 Champions League final, Liverpool's 2005 'Miracle of Istanbul' comeback from 3–0 down, and Messi lifting the World Cup in 2022."]],
  ["Comebacks",[
    "Great comebacks include the Patriots overturning a 28–3 deficit in Super Bowl LI, Barcelona's 6–1 win over PSG in 2017 after losing the first leg 4–0, Tiger Woods's 2019 Masters, Niki Lauda returning to racing six weeks after his near-fatal 1976 crash, and Monica Seles returning after being stabbed.",
    "Comebacks illustrate resilience and the belief that a game is not over until it's over, a line attributed to baseball's Yogi Berra."]]
  ],
  terms:[["Upset","Victory by an expected loser."],["Underdog","Competitor expected to lose."],["Comeback","Recovery from a losing position."],["Cinderella story","Unlikely team's deep run."],["Long odds","Betting odds showing a small chance of winning."]],
  w:"Upsets and great moments are why we watch: they show that in sport, anything can happen.",
  src:["Upset (competition)","Leicester City F.C.","Miracle of Istanbul","Buster Douglas","Steven Bradbury"],
  q:[
  ["Which club won the 2015–16 Premier League as 5,000-to-1 outsiders?","Leicester City","Blackburn Rovers","Nottingham Forest","Aston Villa"],
  ["Who knocked out Mike Tyson in 1990 as a 42-to-1 underdog?","Buster Douglas","Evander Holyfield","Lennox Lewis","Larry Holmes"],
  ["What was the 'Miracle of Istanbul'?","Liverpool's 2005 Champions League comeback from 3–0 down","Turkey's World Cup run","A Galatasaray upset","A basketball comeback"],
  ["Which 16th seed beat a top seed in the 2018 NCAA tournament?","UMBC","Fairleigh Dickinson","Florida Gulf Coast","Saint Peter's"],
  ["Who won the 2021 US Open as a qualifier?","Emma Raducanu","Leylah Fernandez","Naomi Osaka","Iga Świątek"],
  ["Who lit the Olympic cauldron in Atlanta in 1996?","Muhammad Ali","Carl Lewis","Michael Johnson","Jesse Owens's daughter"]]},

{ t:"Dynasties and Golden Generations", s:"Sustained dominance",
  sec:[
  ["What makes a dynasty",[
    "A dynasty is a team that dominates over several seasons, winning multiple championships. Dynasties typically combine exceptional talent, outstanding coaching, strong organizational culture, smart management, and some luck with injuries and timing.",
    "In leagues with salary caps and drafts, dynasties are rarer, making them more impressive; in open European leagues, wealth concentration can produce long periods of dominance."]],
  ["North American dynasties",[
    "The Boston Celtics of Bill Russell (11 titles in 13 years), the New York Yankees of the late 1940s–50s (five straight World Series, 1949–53), the Montreal Canadiens (five straight Stanley Cups, 1956–60), UCLA basketball under John Wooden, the Chicago Bulls of the 1990s, and the New England Patriots of Brady and Belichick (six Super Bowls, 2001–2018) are classic examples.",
    "The Golden State Warriors (2015–22) and the UConn women's basketball program under Geno Auriemma are modern dynasties."]],
  ["Football dynasties",[
    "Real Madrid's five straight European Cups (1956–60), Ajax's three (1971–73), Bayern Munich's three (1974–76), Arrigo Sacchi's AC Milan (1989, 1990), Barcelona under Guardiola (2008–12), and Real Madrid's three straight Champions Leagues (2016–18) stand out. Bayern won eleven consecutive Bundesliga titles (2013–23).",
    "At national level, Hungary's 1950s 'Golden Team,' Brazil's 1958–70 era, and Spain's 2008–12 run are celebrated."]],
  ["Other dynasties",[
    "The West Indies cricket team was unbeaten in Test series from 1980 to 1995; Australia's cricket team of the late 1990s–2000s won three straight World Cups (1999, 2003, 2007). New Zealand's All Blacks won consecutive Rugby World Cups (2011, 2015). China has dominated table tennis and diving for decades; the US men's 4 × 100 m medley relay team long dominated swimming; and Mercedes won eight straight F1 constructors' titles (2014–21).",
    "Individuals can build personal dynasties, such as Federer, Nadal, and Djokovic in tennis or Phelps in swimming."]],
  ["Golden generations",[
    "A 'golden generation' is a group of exceptional players emerging together, such as Belgium's 2010s football team (Hazard, De Bruyne, Lukaku), England's 2000s 'golden generation' (Beckham, Gerrard, Lampard), and Portugal's 1990s 'golden generation' (Figo, Rui Costa). Some golden generations win titles; others are remembered for falling short.",
    "Their stories show that talent alone is not enough without team chemistry, coaching, and timing."]]
  ],
  terms:[["Dynasty","Team dominating across multiple seasons."],["Golden generation","Group of exceptional players emerging together."],["Three-peat","Three consecutive titles."],["Team culture","Shared values and habits of a team."],["Competitive balance","How evenly matched teams are."]],
  w:"Dynasties show what sustained excellence requires: talent, coaching, culture, and management.",
  src:["Sports dynasty","Boston Celtics","New England Patriots dynasty","Bayern Munich","West Indies cricket team"],
  q:[
  ["Which club won five straight European Cups from 1956 to 1960?","Real Madrid","Benfica","AC Milan","Ajax"],
  ["How many Super Bowls did the Brady–Belichick Patriots win?","Six","Five","Seven","Four"],
  ["Which cricket team won three straight World Cups (1999–2007)?","Australia","West Indies","India","England"],
  ["How many consecutive Bundesliga titles did Bayern Munich win from 2013?","Eleven","Seven","Nine","Five"],
  ["Which F1 team won eight straight constructors' titles (2014–21)?","Mercedes","Ferrari","Red Bull","McLaren"],
  ["Which nation's 2010s football team with Hazard and De Bruyne was called a golden generation?","Belgium","Netherlands","Croatia","Portugal"]]},

{ t:"Tragedy, Courage, and Character", s:"Sport's human side",
  sec:[
  ["Tragedies",[
    "Sport has known terrible tragedies. The 1958 Munich air disaster killed eight Manchester United players, the 'Busby Babes'; the 1949 Superga air disaster killed the entire Grande Torino team; and in 2016 a plane crash killed most of Brazil's Chapecoense team on the way to a cup final. Stadium disasters at Hillsborough, Heysel, Bradford (1985 fire), and elsewhere claimed hundreds of lives.",
    "Athletes have died in competition, from racing drivers to footballers with undiagnosed heart conditions; Christian Eriksen's cardiac arrest at Euro 2020, and his survival thanks to rapid CPR and defibrillation, led to greater emphasis on emergency preparedness."]],
  ["Courage under adversity",[
    "Many athletes have overcome adversity: Wilma Rudolph overcame polio; Ben Hogan returned from a near-fatal car crash; Lance Armstrong's cancer recovery inspired many before his doping exposure; Monica Seles returned after being stabbed; and Bethany Hamilton resumed competitive surfing after losing an arm to a shark attack in 2003.",
    "Lou Gehrig's 1939 'luckiest man on the face of the earth' speech, delivered as ALS ended his career, is one of sport's most moving moments."]],
  ["Sportsmanship",[
    "Memorable acts of sportsmanship include Luz Long helping Jesse Owens in the 1936 long jump and becoming his friend; the 2016 Olympic 5000 m, where Nikki Hamblin and Abbey D'Agostino helped each other finish after colliding; Barshim and Tamberi sharing high jump gold in 2021; and Spanish runner Iván Fernández Anaya slowing to let Kenyan Abel Mutai win a cross-country race after Mutai mistakenly stopped early.",
    "The International Fair Play Committee's awards and the Pierre de Coubertin Medal honor such acts."]],
  ["Sport and resilience",[
    "Sport has helped communities heal: baseball after the September 11 attacks, the New Orleans Saints' return after Hurricane Katrina, and Manchester United's rebuilding after Munich, winning the European Cup ten years later with survivor Bobby Charlton.",
    "Sport also offers personal resilience, giving structure, purpose, and community to people facing hardship."]],
  ["Character in sport",[
    "Debates continue about whether sport builds character or merely reveals it. Research suggests sport can develop teamwork, discipline, and resilience when coaches deliberately teach these values; it can also encourage cheating and aggression when winning is all that matters.",
    "The quality of coaching, culture, and leadership largely determines which lessons sport teaches."]]
  ],
  terms:[["Busby Babes","Manchester United team struck by the 1958 Munich disaster."],["Sportsmanship","Fair, respectful conduct."],["Fair Play awards","Honors for sporting conduct."],["Resilience","Recovering from adversity."],["Defibrillator","Device restoring heart rhythm."]],
  w:"Sport's tragedies and acts of courage remind us that athletes and fans are human first.",
  src:["Munich air disaster","Superga air disaster","Christian Eriksen","Luz Long","Lou Gehrig"],
  q:[
  ["Which team was struck by the 1958 Munich air disaster?","Manchester United","Torino","Chapecoense","Liverpool"],
  ["Who helped Jesse Owens in the 1936 long jump and became his friend?","Luz Long","Max Schmeling","Carl Diem","Leni Riefenstahl"],
  ["Which footballer survived a cardiac arrest at Euro 2020?","Christian Eriksen","Fabrice Muamba","Marc-Vivien Foé","Daley Blind"],
  ["Who gave the 'luckiest man on the face of the earth' speech?","Lou Gehrig","Babe Ruth","Jackie Robinson","Joe DiMaggio"],
  ["Which surfer returned to competition after losing an arm to a shark?","Bethany Hamilton","Layne Beachley","Stephanie Gilmore","Carissa Moore"],
  ["Which Brazilian club lost most of its team in a 2016 plane crash?","Chapecoense","Flamengo","Santos","Grêmio"]]}

]});


/* ---- from sports-24.js ---- */
/* SPORTS FOUNDATIONS, part 24: Unit 13 Playing, Coaching, and Watching Like a Pro, chapters 1-5 */
COURSES.sports.units.push({ t:"Playing, Coaching, and Watching Like a Pro", ch:[

{ t:"Coaching", s:"Teaching, leading, and planning",
  sec:[
  ["The coach's roles",[
    "Coaches wear many hats: teacher of skills, planner of training, tactician, motivator, mentor, manager of people, and often administrator. At elite levels, head coaches lead staffs of assistants, analysts, strength and conditioning coaches, medical staff, and psychologists.",
    "Good coaching is fundamentally about helping athletes learn and improve, and creating an environment where they want to keep playing."]],
  ["Teaching skills",[
    "Motor learning research informs coaching. Early learners benefit from simple instructions and demonstrations; practice should progress from simple to complex. 'Blocked' practice (repeating the same skill) improves short-term performance, while 'random' or variable practice (mixing skills and situations) produces better long-term learning and transfer to games.",
    "Game-based approaches such as 'Teaching Games for Understanding' put players in realistic situations, developing decision-making as well as technique. Feedback should be specific and not excessive, so learners develop their own sense of performance. External focus cues (on the effect of movement, such as 'push the ground away') often work better than internal ones ('extend your knees')."]],
  ["Coaching styles",[
    "Styles range from autocratic (the coach decides) to democratic and athlete-centered (athletes share decisions). Research associates autonomy-supportive coaching, explaining reasons, offering choices, and acknowledging feelings, with greater motivation, enjoyment, and wellbeing.",
    "Legendary coaches show different styles: John Wooden's teaching and 'Pyramid of Success,' Vince Lombardi's intensity, Phil Jackson's mindful leadership of stars, Alex Ferguson's demanding man-management, and Pep Guardiola's tactical innovation."]],
  ["Planning",[
    "Coaches plan seasons using periodization, design sessions with clear objectives, and evaluate progress. A typical session includes a warm-up, skill development, game-related practice, conditioning, and a cool-down with reflection.",
    "Analysis of performance through video and data increasingly informs planning even at amateur levels."]],
  ["Ethics and safeguarding",[
    "Coaches hold power over athletes, especially children. Ethical coaching means prioritizing welfare, avoiding abusive practices such as humiliation or excessive punishment, maintaining boundaries, and following safeguarding rules. Scandals in gymnastics, swimming, and football have shown the damage abusive coaching can cause.",
    "Coach education programs and certifications teach safeguarding, first aid, and child development."]],
  ["Becoming a coach",[
    "Many people start coaching as volunteers with children's teams. National governing bodies offer qualifications at increasing levels; elite coaches often combine playing experience, formal education, and years of practice.",
    "Women remain under-represented in coaching at the top level, and programs aim to change that."]]
  ],
  terms:[["Blocked practice","Repeating one skill in a block."],["Random practice","Mixing different skills in practice."],["Teaching Games for Understanding","Game-based coaching approach."],["External focus","Attention on a movement's effect."],["Autonomy-supportive coaching","Coaching that offers choice and explanation."]],
  w:"Good coaching shapes not just performance but whether people love sport for life.",
  src:["Coaching","Motor learning","Teaching games for understanding","John Wooden","Safeguarding in sport"],
  q:[
  ["Which type of practice produces better long-term learning?","Random or variable practice","Blocked practice only","No practice","Only watching videos"],
  ["What is an external focus cue?","Attention on the effect of a movement","Attention on body parts","Ignoring instructions","Focusing on the crowd"],
  ["Which coach created the 'Pyramid of Success'?","John Wooden","Vince Lombardi","Phil Jackson","Bill Belichick"],
  ["What is associated with autonomy-supportive coaching?","Greater motivation and wellbeing","More injuries","Lower performance","Less enjoyment"],
  ["What does 'Teaching Games for Understanding' emphasize?","Realistic game situations and decision-making","Only drills","Only fitness","Only rules"],
  ["Why is safeguarding important in coaching?","Coaches hold power over athletes, especially children","It improves tactics","It increases revenue","It is only for professionals"]]},

{ t:"Officiating", s:"The third team on the field",
  sec:[
  ["The role",[
    "Referees, umpires, and judges enforce rules, ensure safety, and keep games fair and flowing. They make hundreds of decisions per game, often in fractions of a second, under pressure from players, coaches, and crowds.",
    "Elite officials train like athletes: football referees may run 10–12 km per match and undergo fitness tests, video review of decisions, and continuous education."]],
  ["Skills of officiating",[
    "Key skills include thorough knowledge of the rules, positioning (being at the right angle to see incidents), concentration, decisiveness, communication (clear signals, explaining decisions), consistency, and game management, knowing when to apply the letter of the law and when to let play flow.",
    "Personality matters: calm authority helps defuse conflict. Famous officials include football's Pierluigi Collina and Howard Webb, cricket's Dickie Bird and Aleem Dar, and rugby's Nigel Owens, known for his humor and clear communication."]],
  ["Bias and error",[
    "Research has found officials can be subtly influenced by crowd noise (contributing to home advantage), reputation of players, and previous decisions. Technology such as VAR, Hawk-Eye, and replay aims to correct clear errors.",
    "Mistakes are inevitable; accepting this is part of sport's human element. Some famous errors, such as the 'Hand of God' or Frank Lampard's disallowed goal in 2010 (which helped lead to goal-line technology), shaped rule changes."]],
  ["Shortages and abuse",[
    "Many sports face shortages of officials at grassroots level, largely due to verbal and sometimes physical abuse from players, coaches, and parents. Governing bodies have responded with codes of conduct, body cameras in trials, sin bins for dissent, and 'only the captain' rules for speaking to referees.",
    "Respecting officials is a key part of good sporting culture."]],
  ["Becoming an official",[
    "Most sports offer courses for new officials, starting with youth and amateur games. Officiating offers a way to stay involved in sport, improve fitness, earn some money, and develop leadership skills.",
    "Women officials, such as Stéphanie Frappart, who in 2022 became the first woman to referee a men's World Cup match, and Sarah Thomas in the NFL, have broken barriers."]]
  ],
  terms:[["Game management","Controlling the flow and temperature of a match."],["Positioning","Being in the best place to see incidents."],["Sin bin","Temporary suspension from play."],["VAR","Video Assistant Referee."],["Code of conduct","Rules of behavior for participants."]],
  w:"Officials are essential to sport; understanding their job makes for fairer criticism and better games.",
  src:["Referee","Pierluigi Collina","Stéphanie Frappart","Nigel Owens","Sports official"],
  q:[
  ["Who became the first woman to referee a men's World Cup match in 2022?","Stéphanie Frappart","Bibiana Steinhaus","Sarah Thomas","Kateryna Monzul"],
  ["Which disallowed goal in 2010 helped lead to goal-line technology?","Frank Lampard's against Germany","Thierry Henry's handball","Maradona's Hand of God","Geoff Hurst's 1966 goal"],
  ["What is a common cause of grassroots referee shortages?","Abuse from players, coaches, and parents","Too much pay","Lack of rules","Too many referees"],
  ["Which famous rugby referee is known for humor and clear communication?","Nigel Owens","Howard Webb","Dickie Bird","Pierluigi Collina"],
  ["What is 'game management'?","Controlling the flow and temperature of a match","Selling tickets","Planning tactics","Managing a club"],
  ["What can subtly influence referees, research suggests?","Crowd noise","Weather only","Team colors only","Nothing"]]},

{ t:"Youth Sport", s:"Fun, development, and keeping kids playing",
  sec:[
  ["Why children play",[
    "Surveys consistently find children play sport mainly for fun, friends, learning skills, and being active, not mainly to win. Research has also found that a large share of children drop out of organized sport by early adolescence, often because it stops being fun, pressure increases, or they feel they are not good enough.",
    "Keeping children engaged in physical activity has major long-term health benefits."]],
  ["Development models",[
    "The Developmental Model of Sport Participation suggests children benefit from a 'sampling' phase (roughly ages 6–12) of playing many sports with lots of unstructured play, before 'specializing' (13–15) and 'investing' (16+) for those pursuing elite sport. Many elite athletes, such as Roger Federer (who played badminton, skiing, football, and more), sampled multiple sports.",
    "Early single-sport specialization is associated with higher risks of overuse injury and burnout, though some sports with early peak ages, such as gymnastics, involve earlier specialization."]],
  ["Adapted games",[
    "Modified games suited to children's size and abilities, smaller fields, fewer players, lower hoops, softer balls, and shorter games, give each child more touches, success, and enjoyment. Examples include mini tennis with low-compression balls and small-sided football (such as 5-a-side and 7-a-side formats for young players).",
    "Emphasis on skill development and effort rather than results, with equal playing time at young ages, helps retention."]],
  ["Parents and coaches",[
    "Supportive parents encourage effort and enjoyment, attend without pressuring, and let coaches coach. Over-involved or critical parents can increase anxiety and dropout. The car ride home after games is a famous moment where young athletes report feeling pressured; experts suggest simply saying 'I love watching you play.'",
    "Youth coaches set the tone: positive, encouraging, and focused on learning."]],
  ["Access and cost",[
    "In some countries, especially the United States, youth sport has become expensive and professionalized, with travel teams, private coaching, and year-round seasons, creating barriers for lower-income families and contributing to inequality in who plays.",
    "School sports, community programs, and free play spaces help ensure all children can participate."]],
  ["Safety and safeguarding",[
    "Youth sport programs must protect children from abuse, harassment, and unsafe practices through background checks, codes of conduct, policies preventing one-on-one isolated contact, and clear reporting procedures.",
    "Concussion education, heat policies, and age-appropriate training loads are also essential."]]
  ],
  terms:[["Sampling","Playing many sports in childhood."],["Specialization","Focusing on one sport intensively."],["Small-sided games","Reduced-player versions of games."],["Dropout","Leaving organized sport."],["Pay-to-play","Fees limiting youth access."]],
  w:"Well-designed youth sport builds lifelong activity, skills, and enjoyment; poorly designed sport drives children away.",
  src:["Youth sports","Developmental model of sport participation","Early sports specialization","Small-sided games","Sport for children"],
  q:[
  ["Why do children mainly say they play sport?","For fun, friends, and learning skills","Mainly to win","For money","Because parents insist"],
  ["What is the 'sampling' phase?","Playing many sports in childhood","Trying out for elite teams","Taking supplements","Watching sports"],
  ["What risk is associated with early single-sport specialization?","Overuse injury and burnout","Better long-term health always","Faster growth","None"],
  ["What do adapted youth games provide?","More touches and success for each child","Longer games","Adult rules","Fewer players involved"],
  ["Which tennis great sampled many sports as a child?","Roger Federer","Andre Agassi","Serena Williams","Martina Hingis"],
  ["What do experts suggest saying to children after games?","'I love watching you play'","'Why did you miss?'","'You must win next time'","Nothing at all ever"]]},

{ t:"Sport for Life: Starting and Staying Active", s:"It's never too late",
  sec:[
  ["Choosing a sport",[
    "Adults can take up sport at any age. Good choices depend on interests, fitness, budget, available facilities, and social preferences: team sports offer community; individual sports offer flexibility; outdoor sports offer nature; racket sports combine fitness and social play.",
    "Popular adult entry points include running (with programs such as 'Couch to 5K'), swimming, cycling, tennis, padel and pickleball, golf, martial arts, climbing gyms, and recreational leagues for football, basketball, softball, or netball."]],
  ["Starting safely",[
    "Beginners should progress gradually, increasing duration or intensity by small amounts each week, to avoid injury. People with heart conditions, other health issues, or who have been inactive for a long time may benefit from medical advice before vigorous activity.",
    "Learning proper technique from a coach or class prevents injury and speeds progress."]],
  ["Staying motivated",[
    "Behavior research suggests that people stick with activity when they enjoy it, set realistic goals, track progress, have social support, and build routines. Joining clubs, classes, or groups creates commitment and friendship.",
    "Variety helps prevent boredom and overuse injuries; cross-training combines different activities."]],
  ["Masters and veterans sport",[
    "Masters competitions (usually from age 35 or older, in five-year age groups) let older athletes compete at every level; World Masters Games and age-group world championships exist in many sports. Remarkable older athletes include runners who complete marathons in their eighties and nineties.",
    "Walking football, walking netball, and similar adapted sports allow older adults and people with health conditions to keep playing team sports."]],
  ["The social side",[
    "Amateur sport is a major part of community life: club volunteers, coaches, referees, and organizers keep it running. Volunteering in sport is itself a way to participate.",
    "Sport also offers belonging and purpose, especially during life transitions such as retirement or moving to a new place."]]
  ],
  terms:[["Couch to 5K","Beginner running program."],["Cross-training","Combining different activities."],["Masters sport","Competition for older athletes by age group."],["Walking football","Low-impact version of football."],["Progressive overload","Gradual increase of training load."]],
  w:"Sport is for every stage of life; starting gradually and finding enjoyment are the keys to lasting activity.",
  src:["Couch to 5K","Masters athletics","Walking football","Recreational sport","World Masters Games"],
  q:[
  ["What is 'Couch to 5K'?","A beginner running program","A TV show","A marathon","A cycling race"],
  ["What is walking football?","A low-impact version of football","Football with walking sticks","A training drill","A referee exercise"],
  ["At what age do masters competitions usually begin?","Around 35","50","18","65"],
  ["What helps people stick with exercise?","Enjoyment, goals, and social support","Pain","Punishment","Doing the same thing alone forever"],
  ["What is cross-training?","Combining different activities","Training across a field","Training only one muscle","Arguing with a coach"],
  ["How should beginners increase training?","Gradually, by small amounts","As fast as possible","Only on weekends","By doubling every week"]]},

{ t:"Reading a Football Match", s:"What experts watch for",
  sec:[
  ["Before kick-off",[
    "Experts start with team sheets: who is playing, the likely formation, and any surprise selections. Context matters: league position, form, injuries, rivalry, and what each team needs from the game. Weather and pitch conditions can favor certain styles.",
    "Pre-match analysis often identifies key matchups, such as a fast winger against a slow full-back."]],
  ["Shape and phases",[
    "Watch a team's shape in different phases: in possession (build-up, progression, chance creation), out of possession (pressing high, mid-block, or low block), and in transition (the moments right after the ball changes hands, often when goals are scored). Notice how a back four becomes a back three in possession as a full-back pushes up or a midfielder drops in.",
    "Watch the distances between lines: compact teams leave little space between defense and midfield; stretched teams can be exploited."]],
  ["Space and movement",[
    "Football is a game of space. Watch players off the ball: forwards making runs in behind to stretch the defense, midfielders finding pockets between the lines, wide players holding width. Third-man runs (a player running into space created by two teammates' combination) are key attacking patterns.",
    "Defensively, watch how players cover each other, track runners, and whether they mark zonally at set pieces."]],
  ["Game state and adjustments",[
    "Teams behave differently depending on the score ('game state'): a leading team may sit deeper and counterattack; a trailing team pushes more players forward. Managers make substitutions and tactical changes, switching formation, adding a striker, or bringing on a defensive midfielder to protect a lead.",
    "Momentum swings are often visible in territory, pressing success, and shots."]],
  ["Using statistics",[
    "Possession percentage alone can mislead: a team can dominate the ball yet create little. Expected goals (xG) shows the quality of chances; shots on target, progressive passes, pressures, and field tilt (share of possession in the final third) give fuller pictures.",
    "Post-match, compare the scoreline with xG to judge whether a result reflected the balance of chances or luck."]],
  ["Set pieces and discipline",[
    "Set pieces, corners, free kicks, and throw-ins in the attacking third, account for a significant share of goals; teams rehearse routines and use specialist set-piece coaches. Watch for blocking runs and near-post flicks.",
    "Discipline affects games: cards change how aggressively players can tackle, and a red card transforms tactics, forcing the short-handed team to defend in a compact shape."]]
  ],
  terms:[["Transition","Moment when possession changes."],["Game state","How the score affects tactics."],["Third-man run","Run into space created by two teammates."],["Field tilt","Share of possession in the final third."],["Mid-block","Defending in the middle third."]],
  w:"Learning to read football's shapes, space, and statistics turns watching into understanding.",
  src:["Association football tactics and skills","Expected goals","Transition (association football)","Set piece (association football)","Pressing (association football)"],
  q:[
  ["What is 'transition' in football?","The moment possession changes","Halftime","A substitution","A goal kick"],
  ["What does 'game state' refer to?","How the score affects tactics","The weather","The league table","Player fitness"],
  ["Why can possession percentage mislead?","A team can dominate the ball but create little","It is always wrong","It counts only goals","It measures fouls"],
  ["What is a third-man run?","A run into space created by two teammates' combination","A run by the third substitute","A defensive run","A goalkeeper run"],
  ["What does xG compared with the score help judge?","Whether the result reflected the chances","Which team was richer","Who refereed","The attendance"],
  ["What does a red card usually force a team to do?","Defend in a more compact shape","Attack more","Change goalkeepers","Stop the match"]]}

]});


/* ---- from sports-25.js ---- */
/* SPORTS FOUNDATIONS, part 25: Unit 13 chapters 6-10 */
COURSES.sports.units[12].ch.push(

{ t:"Reading Basketball and American Football", s:"Seeing plays develop",
  sec:[
  ["Basketball: possessions and pace",[
    "Basketball analysts think in possessions: each team gets roughly the same number per game, so efficiency (points per possession) matters more than raw points. Pace measures possessions per game. Offensive rating and defensive rating are points scored and allowed per 100 possessions.",
    "Dean Oliver's 'four factors' explain winning: shooting efficiency (effective field goal percentage, which weights three-pointers), turnovers, offensive rebounding, and getting to the free-throw line."]],
  ["Basketball: what to watch",[
    "Watch the pick-and-roll: how the defense responds (switching, 'drop' coverage where the big man stays back, or 'hedging' to trap the ball-handler). Watch spacing: shooters spread around the arc open driving lanes. Off-ball action, such as cuts and screens away from the ball, creates open shots.",
    "Defensively, watch rotations: when a defender helps on a drive, others must rotate to cover the open man. Late-game strategy includes intentional fouls, timeouts, and matchup hunting (targeting a weaker defender)."]],
  ["American football: before the snap",[
    "Pre-snap, watch the offensive formation and personnel (how many receivers, tight ends, and running backs), motion that reveals defensive coverage, and defensive alignment (number of players 'in the box' near the line suggests run defense; two deep safeties suggest pass defense).",
    "Down and distance shape play-calling: third-and-long favors passing, short-yardage favors runs or quick passes."]],
  ["American football: after the snap",[
    "Watch the line of scrimmage: the battle between offensive and defensive lines often decides games. On passes, watch whether the quarterback has a clean pocket and how quickly he gets the ball out; on runs, watch blocking schemes (zone vs gap) and where the running lanes open.",
    "Analytics in football includes expected points added (EPA), which measures how much each play changes a team's expected points, and success rate; these have influenced decisions such as going for it on fourth down."]],
  ["Clock and situational football",[
    "Late in halves, teams manage the clock: a leading team runs the ball to keep the clock moving; a trailing team throws to the sidelines and uses timeouts. The 'two-minute drill' is a hurry-up offense at the end of halves.",
    "Coaches' decisions on challenges, timeouts, and fourth downs are scrutinized by analysts and fans alike."]]
  ],
  terms:[["Possession","One team's turn with the ball until it scores or loses it."],["Four factors","Shooting, turnovers, rebounding, free throws."],["Drop coverage","Big man stays back against pick-and-roll."],["EPA","Expected points added per play."],["Two-minute drill","Hurry-up offense at the end of a half."]],
  w:"Reading these games through possessions, matchups, and situations reveals the strategy behind the highlights.",
  src:["Basketball statistics","Four factors","American football strategy","Expected points","Pick and roll"],
  q:[
  ["What do basketball's 'four factors' include?","Shooting, turnovers, rebounding, free throws","Height, weight, speed, age","Assists, blocks, steals, fouls","Points, minutes, games, wins"],
  ["What does offensive rating measure?","Points scored per 100 possessions","Total points per season","Shots attempted","Fouls drawn"],
  ["What does 'drop coverage' mean?","The big man stays back against the pick-and-roll","The defense drops the ball","Players fall back on offense","A zone defense"],
  ["What does EPA stand for?","Expected points added","Extra possession allowed","End-of-play average","Efficient passing attempt"],
  ["What does a third-and-long situation usually favor?","Passing","Running","Punting immediately","Kneeling"],
  ["What is the two-minute drill?","A hurry-up offense at the end of a half","A fitness test","A halftime show","A penalty"]]},

{ t:"Reading Baseball, Cricket, and Individual Sports", s:"Duels, conditions, and patterns",
  sec:[
  ["Baseball: the duel",[
    "Baseball is a series of pitcher–batter duels. Watch the count: hitters are more aggressive in 'hitter's counts' (2–0, 3–1), and pitchers try to get ahead with first-pitch strikes. Pitchers vary speed and location to disrupt timing; catchers call pitches and frame borderline ones.",
    "Modern statistics include on-base plus slugging (OPS), wins above replacement (WAR, estimating total value compared with a replacement-level player), and Statcast data such as exit velocity and launch angle."]],
  ["Baseball strategy",[
    "Managers decide on bullpen usage (when to replace pitchers, often based on matchups such as left-handed pitchers versus left-handed batters), defensive positioning, pinch hitters, and baserunning risks. Analytics reduced sacrifice bunts and increased emphasis on strikeouts and home runs, prompting MLB's rule changes in 2023.",
    "The 'third time through the order' penalty, where hitters do better seeing a starter for the third time, influences when starters are removed."]],
  ["Cricket: conditions and tactics",[
    "In cricket, conditions matter enormously: the pitch's hardness, grass, and cracks; cloud cover (aiding swing); and the ball's age (new balls swing and seam; older balls may reverse swing or spin). The coin toss decision to bat or bowl first depends on these.",
    "Watch field placements: attacking fields with slips and close catchers when trying to take wickets; spread fields to save runs. Captains rotate bowlers to exploit batters' weaknesses. In T20, watch the 'powerplay' (early overs with fielding restrictions) and 'death overs' at the end, where yorkers and slower balls are key."]],
  ["Tennis and golf",[
    "In tennis, watch serve patterns (wide, body, T), return positions, and rally tolerance; key points such as break points and 30–30 reveal mental strength. Statistics like first-serve percentage, points won behind serve, and unforced errors explain results.",
    "In golf, the 'strokes gained' statistic, developed by Columbia professor Mark Broadie, measures how much each shot gains or loses relative to the field average, showing whether a player wins through driving, approach shots, short game, or putting. Course management, choosing safe or aggressive targets, and wind and green conditions are crucial."]],
  ["Racing and judged sports",[
    "In races, watch pacing strategies: even splits, negative splits (second half faster), and tactical sit-and-kick finishes in championship distance races. In cycling, watch team tactics, breakaways, and when contenders attack on climbs.",
    "In judged sports, learn the scoring codes: in gymnastics, difficulty and execution; in diving, degree of difficulty; in figure skating, technical elements and components. Understanding these lets you see why scores differ."]]
  ],
  terms:[["OPS","On-base plus slugging."],["WAR","Wins above replacement."],["Reverse swing","Swing of an older cricket ball opposite to conventional swing."],["Strokes gained","Golf stat comparing shots with field average."],["Negative split","Running the second half faster."]],
  w:"Each sport has its own patterns to read; knowing them reveals the contest beneath the surface.",
  src:["Wins Above Replacement","Statcast","Reverse swing","Strokes gained","Negative split"],
  q:[
  ["What does WAR estimate in baseball?","A player's value compared with a replacement-level player","Wins at home","Walks and runs","Weekly attendance"],
  ["What is a 'hitter's count'?","A count favoring the batter, like 2–0","Three strikes","A full count only","No balls"],
  ["What does reverse swing require?","An older cricket ball","A new ball","A wet pitch only","Spin bowling"],
  ["Who developed the 'strokes gained' statistic?","Mark Broadie","Bill James","Dean Oliver","Billy Beane"],
  ["What is a negative split?","Running the second half faster than the first","Losing time","A false start","A split decision"],
  ["What are the 'death overs' in T20 cricket?","The final overs of an innings","The first six overs","Overs bowled by spinners","Rain-shortened overs"]]},

{ t:"Sports Statistics Literacy", s:"Numbers that tell the truth, and numbers that mislead",
  sec:[
  ["Counting versus rate stats",[
    "Counting statistics (total goals, home runs, yards) reward longevity and opportunity; rate statistics (goals per 90 minutes, batting average, points per possession) measure efficiency. A player with high totals may simply have played more; rate stats allow fairer comparison but can mislead with small samples.",
    "Always ask: per what? Per game, per minute, per possession, per attempt?"]],
  ["Sample size and luck",[
    "Small samples produce extreme results by chance: a batter hitting .500 in ten at-bats or a striker scoring five goals in three games. Over larger samples, performance tends to 'regress to the mean,' moving toward typical levels.",
    "The 'hot hand' debate illustrates this: a famous 1985 study argued that basketball 'hot streaks' were illusions; later research found a modest real hot-hand effect once statistical biases were corrected."]],
  ["Context and adjustments",[
    "Raw numbers need context: era, league, ballpark (some stadiums favor hitters), opponents' strength, team quality, and role. Adjusted statistics, such as OPS+ in baseball (100 equals league average), account for these factors.",
    "Statistics measure some things well and others poorly; defense, leadership, and off-ball movement are harder to capture."]],
  ["Expected metrics",[
    "Expected metrics, xG in football, expected batting average in baseball, expected points in American football, estimate what 'should' have happened based on chance quality, separating skill from luck. Over time, actual results tend to converge toward expected ones, though elite finishers may consistently outperform xG.",
    "These metrics are probabilistic models, not facts: they depend on the data and assumptions used."]],
  ["Misleading uses",[
    "Common pitfalls include cherry-picking (choosing time periods that support an argument), confusing correlation with causation (a team wins when a player scores, but perhaps because it plays weaker opponents), ignoring denominators, and survivorship bias (studying only successful athletes).",
    "Broadcast graphics sometimes present selective statistics to build narratives; critical viewers ask what is missing."]],
  ["Using numbers well",[
    "The best analysis combines data with observation: numbers suggest questions, video and expertise provide answers. Analysts at top clubs pair data scientists with coaches and scouts.",
    "For fans, a little statistical literacy makes debates sharper and more fun."]]
  ],
  terms:[["Rate statistic","Measure per unit of opportunity."],["Regression to the mean","Extreme results drifting back toward average."],["Hot hand","Belief that success breeds streaks."],["Survivorship bias","Focusing only on successes."],["Adjusted statistic","Stat corrected for context."]],
  w:"Understanding how statistics work, and how they mislead, is essential to modern sports analysis.",
  src:["Regression toward the mean","Hot hand","Survivorship bias","Sample size determination","OPS+"],
  q:[
  ["What does 'regression to the mean' describe?","Extreme results drifting back toward average","Teams getting worse","Players aging","Statistics being wrong"],
  ["What is a rate statistic?","A measure per unit of opportunity","A total count","A player's salary","A betting rate"],
  ["What did later research find about the 'hot hand'?","A modest real effect once biases were corrected","It doesn't exist at all","It explains every streak","It is huge"],
  ["What does OPS+ of 100 mean?","League average","Perfect","Below replacement","Double the average"],
  ["What is survivorship bias?","Studying only successful cases","Favoring older players","Ignoring injuries","Counting survivors of accidents"],
  ["What is cherry-picking?","Choosing data that supports an argument","Picking the best players","A fruit-based diet","Random sampling"]]},

{ t:"Following Sport: Calendars, Competitions, and Sources", s:"A fan's map of the year",
  sec:[
  ["The sporting calendar",[
    "The global sports year has a rhythm. Winter brings the NFL playoffs and Super Bowl (February), the Australian Open (January), the Six Nations (February–March), and the NBA and NHL regular seasons. Spring brings March Madness, the Masters (April), the start of MLB, the Boston and London marathons, the Champions League and European league climaxes, and the NBA and NHL playoffs.",
    "Summer brings the French Open and Wimbledon, the Tour de France (July), The Open Championship, and, in alternating years, the World Cup, Euros, Copa América, or Olympics. Autumn brings the US Open tennis, the start of European football seasons and the NFL, the Ryder Cup in odd years, the World Series (October), and the Rugby World Cup every four years."]],
  ["Cycles of major events",[
    "Many major events follow four-year cycles: the Summer Olympics (2024 Paris, 2028 Los Angeles, 2032 Brisbane), Winter Olympics (2026 Milan–Cortina, 2030 French Alps), the men's FIFA World Cup (2026 North America, 2030 Spain–Portugal–Morocco, 2034 Saudi Arabia), the Rugby World Cup, the Cricket World Cup, and the Euros.",
    "World championships in athletics and swimming are held more frequently, typically every two years."]],
  ["Reliable sources",[
    "Good sources include official governing body websites (for rules and results), reputable sports journalism (such as major newspapers, the BBC, ESPN, and specialized outlets), statistical databases (Sports Reference sites, FBref, Cricinfo, Olympedia), and books by respected historians and journalists.",
    "Be cautious with rumors, especially transfer gossip, unverified social media posts, and AI-generated content; check claims against reliable sources."]],
  ["Following a new sport",[
    "To get into a new sport: learn the basic rules, pick a team or athlete to follow, watch with someone knowledgeable, follow a podcast or newsletter, and learn a few key storylines and rivalries. Watching highlights and documentaries is a good on-ramp.",
    "Attending live events, even at local or amateur level, builds connection."]],
  ["Healthy fandom",[
    "Healthy fandom keeps perspective: enjoying sport without letting results harm wellbeing or relationships, avoiding abusive behavior toward athletes and officials, and being careful with gambling, which carries risks of addiction.",
    "Sport is best enjoyed as a source of community, joy, and inspiration."]]
  ],
  terms:[["Sporting calendar","Annual cycle of major events."],["Quadrennial","Occurring every four years."],["Governing body","Organization running a sport."],["Statistical database","Reference site for sports data."],["Transfer gossip","Unconfirmed reports about player moves."]],
  w:"Knowing the calendar and reliable sources makes it easy to follow any sport and avoid misinformation.",
  src:["Sports calendar","FIFA World Cup hosts","Olympic Games host cities","Sports journalism","Problem gambling"],
  q:[
  ["In which month is the Tour de France held?","July","April","October","January"],
  ["Where will the 2028 Summer Olympics be held?","Los Angeles","Brisbane","Paris","Rome"],
  ["Which Grand Slam opens the tennis year in January?","Australian Open","French Open","Wimbledon","US Open"],
  ["Where are the 2030 Winter Olympics planned?","French Alps","Milan–Cortina","Salt Lake City","Sapporo"],
  ["When is the Masters golf tournament held?","April","July","September","December"],
  ["Which is a good practice when following sports news?","Checking claims against reliable sources","Trusting all social media posts","Believing all transfer rumors","Ignoring official sites"]]},

{ t:"A Lifelong Life in Sport", s:"Where the foundations lead",
  sec:[
  ["What you now know",[
    "These foundations have covered sport's origins and history, the rules and legends of the world's major sports, the science of performance, and sport's role in society, from business and media to politics, inclusion, and health. Together they form the shared knowledge of coaches, analysts, journalists, and serious fans.",
    "Every chapter opens into deeper study, and the branches ahead let you specialize in particular sports, eras, or disciplines."]],
  ["Watching with understanding",[
    "Watching sport with knowledge transforms it: you see the tactics, sense the pressure of the count or the break point, recognize the history behind a rivalry, and understand the science of an athlete's effort.",
    "Try watching a sport you don't know with fresh eyes, and revisit favorites with new questions."]],
  ["Playing and participating",[
    "The deepest understanding comes from playing. Whatever your age or ability, there is a way to take part: playing, coaching, officiating, volunteering, or simply moving for health and joy.",
    "Sport's benefits, physical health, mental wellbeing, friendship, and community, are available to everyone."]],
  ["Thinking critically",[
    "Sport raises lasting questions: What makes competition fair? How should we balance inclusion and fairness? Who should profit from athletes' talent? How can sport be governed honestly? What do we owe the planet and future generations?",
    "Bringing knowledge and critical thinking to these debates makes you a better fan and citizen."]],
  ["Next steps",[
    "The specialized branches of this subject build on these foundations, offering deeper study of individual sports, their histories and tactics, sports science, sports business and law, and great athletes. Your reading will make the branches your own.",
    "As Nelson Mandela said in 2000, 'Sport has the power to change the world. It has the power to inspire. It has the power to unite people in a way that little else does.'"]]
  ],
  terms:[["Foundations","Core knowledge shared across sport."],["Branch","Specialized path building on the foundations."],["Participation","Taking part in sport at any level."],["Critical fandom","Enjoying sport while thinking critically."],["Lifelong activity","Staying active throughout life."]],
  w:"Sport is a lifelong source of joy and learning; these foundations prepare you to watch, play, and think about it deeply.",
  src:["Sport","Nelson Mandela","Physical activity","Sports fan","Olympic Charter"],
  q:[
  ["Who said 'Sport has the power to change the world'?","Nelson Mandela","Pierre de Coubertin","Muhammad Ali","Barack Obama"],
  ["Where does the deepest understanding of sport come from, according to this chapter?","Playing","Reading only","Betting","Watching highlights only"],
  ["Which is a lasting question raised by sport?","How to balance inclusion and fairness","How many players are on a team","What color the ball is","When the season starts"],
  ["What do the branches ahead offer?","Deeper specialized study","Repetition of the foundations","Only quizzes","Nothing new"],
  ["Which is a way to take part in sport besides playing?","Coaching, officiating, or volunteering","Only watching TV","Only betting","None"],
  ["What benefits does sport offer everyone?","Health, wellbeing, friendship, and community","Only fame","Only money","Only trophies"]]}

);


/* ---- from sports-26.js ---- */
/* SPORTS FOUNDATIONS, part 26: extra chapters spliced into Units 1 and 2 */
(function(){
const u1=COURSES.sports.units[0].ch;
const i1=u1.findIndex(c=>c.t==="The Modern Olympic Games");
u1.splice(i1+1,0,

{ t:"Sport in the Twentieth Century", s:"From amateur games to global spectacle",
  sec:[
  ["1900–1945: organization and nationalism",[
    "The early 20th century saw the founding of international federations (FIFA 1904, the IAAF 1912), the first Olympics outside Europe (St. Louis 1904), and the spread of professional leagues. Sport became tied to nationalism, with countries using international success to display strength.",
    "Between the wars, mass spectator sport boomed: radio broadcasts, huge stadiums such as Wembley (1923), and stars such as Babe Ruth, Jack Dempsey, Suzanne Lenglen, and Paavo Nurmi. Fascist regimes used sport for propaganda, and the 1936 Berlin Olympics became the defining example."]],
  ["1945–1970: rebuilding and integration",[
    "After World War II, sport helped rebuild national morale. The 1948 'Austerity Olympics' in London were held with existing venues and rationed food. Integration advanced, with Jackie Robinson in 1947 and the NBA in 1950, while decolonization brought new nations into international sport.",
    "Television transformed sport in the 1950s–60s; the Cold War turned the Olympics into a contest between superpowers; and the 1966 and 1970 World Cups reached unprecedented audiences."]],
  ["1970–2000: money, media, and professionalism",[
    "From the 1970s, commercialization accelerated: sponsorship, TV rights, free agency, and the end of strict amateurism. Women's sport grew after Title IX (1972). Protests and boycotts marked the Olympics, and doping became a major scandal.",
    "Satellite and cable TV, the Premier League (1992), the Dream Team (1992), and global brands such as Nike made sport a worldwide entertainment industry. Rugby union turned professional in 1995, and the Bosman ruling liberalized player movement in Europe."]],
  ["Technology and performance",[
    "Throughout the century, performance improved dramatically: the men's 100 m record fell from 10.6 seconds (1912) to 9.79 (1999), the marathon from about 2:55 to around 2:06. Reasons include better training, nutrition, sports science, synthetic tracks, equipment, larger talent pools, professionalism, and, in some cases, doping.",
    "By 2000, sport had become a global, professional, media-driven industry, setting the stage for the digital age."]]
  ],
  terms:[["Austerity Olympics","London 1948 Games after WWII."],["Decolonization","End of colonial empires, creating new sporting nations."],["Commercialization","Growth of money and marketing in sport."],["Professionalism","Paying athletes openly."],["Talent pool","Population of potential athletes."]],
  w:"The 20th century turned sport from a pastime into a global industry and a stage for national identity.",
  src:["History of sport","1948 Summer Olympics","Wembley Stadium (1923)","Professional sports","Men's 100 metres world record progression"],
  q:[
  ["What were the 1948 London Games nicknamed?","The Austerity Olympics","The Cold War Games","The Peace Games","The Television Games"],
  ["When did the original Wembley Stadium open?","1923","1948","1966","1908"],
  ["When did rugby union turn professional?","1995","1971","1987","2003"],
  ["What was the men's 100 m record in 1912?","10.6 seconds","9.9 seconds","11.5 seconds","10.0 seconds"],
  ["Which technology transformed sport in the 1950s–60s?","Television","Radio","Internet","Cinema"],
  ["Which 1992 team helped globalize basketball?","The Dream Team","The Harlem Globetrotters","The Chicago Bulls","Team Canada"]]},

{ t:"Sport in the Twenty-First Century", s:"Data, streaming, and global stars",
  sec:[
  ["Globalization",[
    "In the 21st century, sport became more global than ever. European football leagues gained audiences across Asia, Africa, and the Americas; the NBA and NFL played games abroad; and stars such as Messi, Ronaldo, LeBron James, Serena Williams, and Shohei Ohtani became worldwide brands. New powers emerged: China at Beijing 2008, the Gulf states as hosts and investors, and India through the IPL.",
    "Players move across continents, and teams are multinational."]],
  ["Digital media",[
    "Social media and streaming changed how fans follow sport. Highlights, memes, and athlete posts spread instantly; leagues sell rights to streaming services; and fans watch on phones. Documentary series and podcasts bring behind-the-scenes access.",
    "Esports grew into a major industry, and fantasy sports and legal betting expanded rapidly."]],
  ["Science and data",[
    "Analytics, wearables, and video analysis transformed coaching and recruitment. Technology aided officiating with VAR, Hawk-Eye, and electronic line-calling. Equipment innovations, such as super shoes, led to new records and new regulations.",
    "Sports science professionalized recovery, nutrition, and injury prevention, extending careers."]],
  ["Social change",[
    "Women's sport grew rapidly, with gender parity at Paris 2024 and record audiences. Athletes spoke out on racial justice, mental health, and other issues. Debates intensified about eligibility, concussion, abuse and safeguarding, sportswashing, and climate change.",
    "The COVID-19 pandemic (2020–21) halted sport worldwide, postponed the Tokyo Olympics and Euro 2020 by a year, and led to games in empty stadiums, showing how much fans matter."]],
  ["Looking ahead",[
    "Future trends include further growth of women's sport, artificial intelligence in coaching and broadcasting, new formats such as T20 cricket and 3x3 basketball, shifting power to new investors, and the challenge of climate change for outdoor and winter sports.",
    "Through all these changes, sport's core appeal, uncertain contests of skill and effort, remains."]]
  ],
  terms:[["Globalization","Worldwide spread and integration of sport."],["Streaming","Delivering sport over the internet."],["Wearables","Body-worn tracking devices."],["Safeguarding","Protecting athletes from harm."],["New formats","Shorter, faster versions of sports."]],
  w:"Understanding recent changes in sport explains the debates and opportunities shaping its future.",
  src:["2020s in sports","Impact of the COVID-19 pandemic on sports","Globalization and sport","Sports analytics","Women's sports"],
  q:[
  ["Which major event was postponed by a year due to COVID-19?","Tokyo Olympics","Qatar World Cup","Beijing Winter Olympics","Rugby World Cup 2023"],
  ["Which Games achieved gender parity among athletes?","Paris 2024","Tokyo 2020","London 2012","Beijing 2008"],
  ["Which league made India cricket's financial center?","The IPL","The Big Bash","The Hundred","The County Championship"],
  ["What did games in empty stadiums show?","How much fans matter","That fans don't matter","That TV is unnecessary","That home advantage grew"],
  ["Which innovation in shoes led to new running regulations?","Super shoes with carbon plates","Spikes","Leather soles","Velcro"],
  ["Which is a new, shorter format of a traditional sport?","3x3 basketball","Test cricket","Marathon","Decathlon"]]}

);

const u2=COURSES.sports.units[1].ch;
const i2=u2.findIndex(c=>c.t==="Positions, Formations, and Tactics");
u2.splice(i2+1,0,

{ t:"Football Skills and Training", s:"Technique from grassroots to elite",
  sec:[
  ["First touch and passing",[
    "The foundation of football is controlling and passing the ball. A good first touch cushions or redirects the ball into space, buying time. Passing types include the short inside-foot pass (most accurate), the driven pass, the lofted or long ball, the through ball (played into space behind defenders), and the cross from wide areas.",
    "Players are taught to scan, looking around before receiving, so they know their options; studies of elite midfielders show they scan many times per minute."]],
  ["Dribbling and shooting",[
    "Dribbling uses close control, changes of pace and direction, and feints such as step-overs and the Cruyff turn to beat opponents. Shooting techniques include the instep drive for power, the inside-foot placement for accuracy, the volley, the chip, and the header.",
    "Finishing under pressure, staying composed in front of goal, distinguishes great strikers."]],
  ["Defending",[
    "Individual defending involves body position (side-on, on the toes), jockeying (delaying the attacker), timing tackles, and staying goal-side of an opponent. Team defending requires communication, covering, and compactness.",
    "Heading is an important skill for defenders and forwards; due to concerns about brain health, many associations now limit heading practice for children."]],
  ["Goalkeeping",[
    "Goalkeepers need shot-stopping reflexes, positioning (narrowing the angle), handling, diving, command of the penalty area on crosses, distribution with hands and feet, and leadership of the defense. Modern 'sweeper-keepers,' such as Manuel Neuer and Ederson, are comfortable playing out from the back with their feet.",
    "Penalty saves combine study of opponents' habits with reaction and anticipation."]],
  ["Training at different levels",[
    "Youth training emphasizes ball mastery, small-sided games, and enjoyment. Elite training combines technical drills, tactical sessions, position-specific work, set-piece rehearsal, conditioning, and recovery, carefully planned around fixtures.",
    "Academies at professional clubs develop young players, and Spain's and Germany's investment in youth coaching in the 2000s is credited with producing golden generations."]],
  ["Futsal and street football",[
    "Futsal and street football develop close control and quick decisions in tight spaces; many Brazilian and Portuguese stars, including Ronaldinho and Cristiano Ronaldo, played futsal as children. Freestyle football, juggling tricks, has become a sport and online culture.",
    "Whatever the level, repetition, game-like practice, and love of the ball build skill."]]
  ],
  terms:[["First touch","Initial control of the ball."],["Scanning","Looking around before receiving."],["Jockeying","Delaying an attacker without tackling."],["Sweeper-keeper","Goalkeeper who plays outside the area."],["Through ball","Pass into space behind defenders."]],
  w:"Technique is the language of football; understanding it helps you appreciate and play the game.",
  src:["Association football","Dribbling","Goalkeeper (association football)","Futsal","Sweeper-keeper"],
  q:[
  ["What is scanning in football?","Looking around before receiving the ball","A video review","A fitness test","A ticket check"],
  ["Which pass is generally most accurate?","Inside-foot pass","Lofted pass","Backheel","Overhead kick"],
  ["What is jockeying?","Delaying an attacker without committing to a tackle","Riding a horse","A dribbling trick","A goalkeeper dive"],
  ["Which goalkeeper is known as a sweeper-keeper?","Manuel Neuer","Lev Yashin","Gordon Banks","Peter Schmeichel"],
  ["Why do many associations limit heading for children?","Concerns about brain health","It is too easy","It wastes time","It is illegal"],
  ["Which small-court game helped develop stars like Ronaldinho?","Futsal","Beach volleyball","Handball","Walking football"]]}

);
})();


/* ---- from sports-27.js ---- */
/* SPORTS FOUNDATIONS, part 27: extra chapters spliced across units */
(function(){
const S=COURSES.sports.units;
const after=(u,title,ch)=>{const a=S[u].ch;const i=a.findIndex(c=>c.t===title);a.splice(i+1,0,ch);};
const before=(u,title,ch)=>{const a=S[u].ch;const i=a.findIndex(c=>c.t===title);a.splice(i,0,ch);};

after(0,"Sport in the Twenty-First Century",
{ t:"The Olympic Program: Sports In and Out", s:"Why sports come and go",
  sec:[
  ["A changing lineup",[
    "The Olympic program has changed constantly. Early Games included events now gone: tug of war (1900–1920), the standing high jump, live pigeon shooting (1900), rope climbing, solo synchronized swimming, and even art competitions (1912–1948), where medals were awarded for painting, sculpture, literature, music, and architecture inspired by sport.",
    "Sports such as lacrosse, cricket (once, in 1900), polo, rugby, and baseball have dropped out and in again."]],
  ["How sports are chosen",[
    "The IOC decides the program, considering global participation, gender equality, youth appeal, cost, governance, and anti-doping compliance. Since the 2014 Olympic Agenda 2020 reforms, host cities can propose additional sports, which is how baseball/softball, karate, skateboarding, sport climbing, and surfing appeared at Tokyo 2020 and breaking at Paris 2024.",
    "Los Angeles 2028 adds cricket (T20), flag football, lacrosse (sixes), squash, and baseball/softball. Some sports, such as breaking, were not retained for later Games."]],
  ["Pressures to stay in",[
    "Federations work hard to keep their sports on the program, because Olympic status brings funding, visibility, and government support. Wrestling was briefly dropped in 2013, provoking global protests and reforms, before being reinstated. Weightlifting, boxing, and modern pentathlon were warned to fix governance, doping, or format problems.",
    "Formats have changed to be more TV-friendly: mixed-gender relays, 3x3 basketball, sevens rugby, BMX freestyle, and shorter events."]],
  ["Demonstration and new sports",[
    "Demonstration sports once allowed hosts to showcase local or emerging sports, such as baseball in several Games and curling in 1988 and 1992 before it became official in 1998.",
    "Sports not on the Olympic program compete at the World Games, held every four years, including sports such as korfball, orienteering, and tug of war."]]
  ],
  terms:[["Olympic program","List of sports and events at the Games."],["Agenda 2020","IOC reforms allowing host-proposed sports."],["Demonstration sport","Sport shown at the Games without official medals."],["Art competitions","Olympic medal events for arts, 1912–1948."],["World Games","Event for non-Olympic sports."]],
  w:"The changing Olympic program shows how sport evolves with culture, media, and politics.",
  src:["Discontinued Olympic sports","Art competitions at the Summer Olympics","Olympic Agenda 2020","Tug of war at the 1900 Summer Olympics","World Games"],
  q:[
  ["Which discontinued Olympic event ran from 1900 to 1920?","Tug of war","Ski jumping","Water polo","Fencing"],
  ["Between which years were Olympic art competitions held?","1912–1948","1896–1920","1950–1970","1928–1960"],
  ["Which sports are added for Los Angeles 2028?","Cricket, flag football, lacrosse, squash, baseball/softball","Esports and chess","Darts and snooker","Polo and kabaddi"],
  ["Which sport was briefly dropped in 2013 before reinstatement?","Wrestling","Judo","Rowing","Archery"],
  ["What allowed host cities to propose extra sports?","Olympic Agenda 2020","The Olympic Charter of 1894","Rule 50","The Gleneagles Agreement"],
  ["Where do many non-Olympic sports compete?","The World Games","The Asian Games only","The Paralympics","The Commonwealth Games only"]]});

after(2,"Baseball History and Legends",
{ t:"Softball and the Bat-and-Ball Family", s:"Cousins of baseball and cricket",
  sec:[
  ["Softball",[
    "Softball was invented in Chicago in 1887 when George Hancock improvised an indoor game with a boxing glove and a broom handle. It uses a larger ball than baseball, a smaller field (bases 60 feet apart in fastpitch), and seven innings. In fastpitch softball, pitchers throw underhand with a 'windmill' motion at speeds that, given the shorter distance, give batters less reaction time than many baseball pitches.",
    "Slow-pitch softball, with high arcing pitches, is one of the most popular recreational sports in the United States."]],
  ["Women's softball and baseball",[
    "Fastpitch softball is a major women's sport in the US, Japan, Australia, and elsewhere. It was an Olympic sport from 1996 to 2008 and returned in 2020; the US and Japan are dominant, and pitcher Jennie Finch became a celebrity. College softball's Women's College World Series draws large TV audiences.",
    "During World War II, the All-American Girls Professional Baseball League (1943–54) gave hundreds of women professional careers, as depicted in A League of Their Own. Women's baseball has its own World Cup, and leagues for women's professional baseball are developing."]],
  ["Rounders, stoolball, and pesäpallo",[
    "Rounders, an English game played by schoolchildren, shares ancestry with baseball; stoolball, played in Sussex since at least the 15th century, is a possible ancestor of cricket. Finland's national game, pesäpallo, developed in the 1920s by Lauri 'Tahko' Pihkala, adapts baseball with a vertical pitch thrown above the batter's head.",
    "Kickball, Baseball5 (an urban five-a-side version played by hitting a rubber ball with the hand, introduced by the World Baseball Softball Confederation in 2017), and cricket's backyard and street forms show how the family keeps evolving."]],
  ["Shared skills",[
    "Bat-and-ball games share skills: hand–eye coordination, throwing, catching, and the duel between thrower and hitter. They tend to alternate phases of offense and defense and are rich in statistics.",
    "Cricket and baseball fans often find common ground in the patience, strategy, and history of their games."]]
  ],
  terms:[["Fastpitch","Softball with fast underhand windmill pitching."],["Slow-pitch","Recreational softball with arcing pitches."],["AAGPBL","1943–54 women's professional baseball league."],["Pesäpallo","Finnish baseball-style game."],["Baseball5","Urban hand-hit version of baseball."]],
  w:"Baseball's family of games includes some of the world's most popular recreational and women's sports.",
  src:["Softball","All-American Girls Professional Baseball League","Pesäpallo","Rounders","Baseball5"],
  q:[
  ["Where was softball invented in 1887?","Chicago","Boston","New York","Toronto"],
  ["How do fastpitch softball pitchers throw?","Underhand with a windmill motion","Overhand","Sidearm only","With a bounce"],
  ["Which women's league ran from 1943 to 1954?","All-American Girls Professional Baseball League","WNBA","NWSL","Women's College World Series"],
  ["What is Finland's national baseball-style game?","Pesäpallo","Rounders","Stoolball","Kickball"],
  ["How many innings in a softball game?","Seven","Nine","Five","Six"],
  ["What is Baseball5?","An urban version where the ball is hit with the hand","Five-inning baseball","Baseball with five players per team on a large field","A baseball video game"]]});

after(4,"Golf's History and Majors",
{ t:"Technique in Tennis and Golf", s:"Building repeatable strokes",
  sec:[
  ["Tennis grips and strokes",[
    "Tennis grips determine racket angle: the continental grip for serves, volleys, and slices; the eastern and semi-western grips for forehands, with semi-western helping generate topspin; and one- or two-handed backhands. The modern forehand uses a closed or open stance, unit turn of the shoulders, and a 'windshield-wiper' finish for heavy topspin.",
    "The serve combines a ball toss, trophy position, knee bend, upward drive, and pronation of the forearm. Footwork, split-stepping as the opponent hits and recovering to center, underlies every shot."]],
  ["Tennis tactics",[
    "Basic tactics include hitting crosscourt (over the lower middle of the net, with more court to aim at) and changing direction down the line when attacking; serving to an opponent's weaker side; approaching the net behind deep shots; and using the 'serve plus one' pattern, planning the first shot after the serve.",
    "In doubles, partners use formations such as both at the net or one up, one back, and the 'I-formation' to confuse returners."]],
  ["The golf swing",[
    "The golf swing begins with the setup: grip (overlapping, interlocking, or ten-finger), stance, posture, and alignment toward the target. The backswing turns the shoulders around a stable lower body; the downswing starts from the ground and hips, transferring weight to the lead side, releasing the club through impact, and finishing in balance.",
    "Consistency matters more than power: tour professionals repeat their swings under pressure through endless practice and pre-shot routines."]],
  ["The short game",[
    "Most strokes in golf happen within about 100 meters of the hole: pitches, chips, bunker shots, and putts. Putting accounts for a large share of strokes for amateurs and professionals alike. Good putting depends on reading the slope ('break') and speed of greens, a consistent stroke, and confidence.",
    "Practicing the short game is often the fastest way for amateurs to lower scores."]],
  ["Learning technique",[
    "In both sports, lessons from qualified coaches, video analysis, and launch monitors (which measure club speed, ball speed, launch angle, and spin in golf) help players improve. Drills break complex movements into parts before reassembling them.",
    "Equipment fitting, rackets and strings, or golf club length and shaft flex, can help, but technique and practice matter most."]]
  ],
  terms:[["Continental grip","Tennis grip for serves and volleys."],["Topspin","Forward spin making the ball dip."],["Split-step","Small hop to prepare to move."],["Short game","Golf shots near the green."],["Launch monitor","Device measuring golf shot data."]],
  w:"Understanding technique and tactics in tennis and golf helps players improve and viewers appreciate skill.",
  src:["Grip (tennis)","Forehand","Golf swing","Putting (golf)","Launch monitor"],
  q:[
  ["Which tennis grip is used for serves and volleys?","Continental","Western","Semi-western","Eastern backhand"],
  ["Why is crosscourt a safe tennis shot?","It goes over the lower middle of the net with more court","It is faster","It always wins","It avoids spin"],
  ["What is a split-step?","A small hop to prepare to move","A type of serve","A doubles formation","A grip change"],
  ["Where do most golf strokes happen?","Within about 100 meters of the hole","On the tee","In bunkers only","On the fairway"],
  ["What does a golf launch monitor measure?","Club speed, ball speed, launch angle, and spin","Green speed","Wind direction","Heart rate"],
  ["What starts the golf downswing?","The ground and hips","The hands","The head","The putter"]]});

after(8,"Talent, Genes, Age, and Sex",
{ t:"The Female Athlete", s:"Physiology, health, and research gaps",
  sec:[
  ["A research gap",[
    "Historically, most sports science research studied men; reviews have found that women made up a minority of participants in sports and exercise medicine studies. Applying male-based findings to women can be misleading, so researchers are increasingly studying female athletes directly.",
    "Topics include the menstrual cycle, hormonal contraception, pregnancy, menopause, bone health, injury risk, and nutrition."]],
  ["The menstrual cycle",[
    "Hormones such as estrogen and progesterone fluctuate across the menstrual cycle. Research on their effects on performance is mixed, with small average effects but large individual differences; many athletes report symptoms such as fatigue or cramps that affect training. Some teams, such as the US women's football team before the 2019 World Cup, tracked cycles to tailor training and recovery.",
    "Missing periods (amenorrhea) in athletes is not normal and can signal low energy availability (RED-S), with risks to bone health."]],
  ["Injuries and equipment",[
    "Female athletes have higher rates of ACL injuries and some concussion symptoms in comparable sports. Factors may include anatomy, hormones, neuromuscular patterns, and also equipment designed for men, such as football boots, as well as unequal access to strength training and medical support.",
    "Properly fitted sports bras, women-specific equipment, and injury prevention programs help address these issues."]],
  ["Pregnancy and motherhood",[
    "Exercise during uncomplicated pregnancy is generally recommended by health bodies, with appropriate modifications. Many elite athletes have returned to top competition after childbirth: Kim Clijsters won the 2009 US Open as a mother, Serena Williams won the 2017 Australian Open while pregnant, and Allyson Felix and Shelly-Ann Fraser-Pryce won world titles after giving birth.",
    "Policies on maternity leave, protected rankings, and childcare at competitions have improved but vary widely."]],
  ["Toward better support",[
    "Organizations increasingly employ specialists in female athlete health, fund research, and educate coaches on topics once considered taboo. Recognizing women's specific needs improves performance, health, and long-term participation.",
    "These advances also benefit recreational exercisers, who make up the vast majority of active women."]]
  ],
  terms:[["Menstrual cycle","Monthly hormonal cycle."],["Amenorrhea","Absence of menstrual periods."],["Low energy availability","Insufficient fuel for training and health."],["ACL","Knee ligament more often injured in female athletes."],["Protected ranking","Ranking preserved during maternity leave."]],
  w:"Understanding female athletes' physiology closes a long research gap and improves health and performance.",
  src:["Women's sports","Sport and the menstrual cycle","Female athlete triad","Kim Clijsters","Exercise during pregnancy"],
  q:[
  ["Historically, who were most sports science study participants?","Men","Women","Children","Older adults"],
  ["What can missing periods in athletes signal?","Low energy availability","Peak fitness","Overhydration","High iron"],
  ["Who won the 2017 Australian Open while pregnant?","Serena Williams","Kim Clijsters","Venus Williams","Naomi Osaka"],
  ["Which team tracked menstrual cycles before the 2019 World Cup?","US women's football team","England women's team","Brazil women's team","Japan women's team"],
  ["Which injury occurs at higher rates in female athletes?","ACL tears","Tommy John injuries","Tennis elbow only","Broken noses"],
  ["Who won the 2009 US Open as a mother?","Kim Clijsters","Justine Henin","Steffi Graf","Lindsay Davenport"]]});

after(9,"Inclusion and Identity in Sport",
{ t:"Sport, Religion, and Ritual", s:"Sacred origins and modern devotion",
  sec:[
  ["Sacred origins",[
    "Many sports began as religious rituals: the ancient Olympics honored Zeus; the Mesoamerican ballgame had cosmic meaning; sumo grew from Shinto ceremonies, and still includes salt-throwing purification; and lacrosse was 'the Creator's Game' for the Haudenosaunee. Some Indigenous running traditions, such as Hopi and Tarahumara (Rarámuri) running, carry spiritual significance.",
    "Medieval festivals hosted games on holy days, such as Shrovetide football."]],
  ["Christianity and sport",[
    "Victorian 'muscular Christianity' linked sport and faith, and churches founded many clubs: English football clubs including Aston Villa, Everton, and Southampton began as church teams. The YMCA helped invent basketball and volleyball.",
    "Many modern athletes express faith publicly, praying or pointing upward after scoring; organizations such as Athletes in Action support Christian athletes."]],
  ["Other faiths",[
    "Muslim athletes observe Ramadan fasting during competitions, with teams adjusting training and meals; some leagues now pause matches for players to break their fast. Jewish athletes such as Sandy Koufax have skipped games on holy days; the Maccabiah Games are a major Jewish multisport event. Sikh athletes' turbans and Muslim women's hijabs prompted rule changes in sports such as basketball (FIBA allowed head coverings from 2017) and football.",
    "Hindu, Buddhist, and Taoist traditions influence martial arts and practices such as yoga and tai chi."]],
  ["Sport as secular religion",[
    "Scholars have described sport as a kind of 'civil religion': fans gather weekly in 'cathedrals' (stadiums), wear sacred colors, sing hymns, venerate heroes and relics, and observe rituals and superstitions. Club crests and anthems function like sacred symbols.",
    "This helps explain the intensity of fan devotion and the grief when legends die."]],
  ["Superstitions and rituals",[
    "Athletes often have superstitions and rituals: Rafael Nadal's precise arrangement of water bottles, Michael Jordan wearing his college shorts under his NBA uniform, Serena Williams bouncing the ball five times before first serves, and hockey's playoff beards. Psychologists suggest rituals reduce anxiety and increase a sense of control.",
    "Fans have rituals too: lucky shirts, seats, and pre-game routines."]]
  ],
  terms:[["Muscular Christianity","Victorian linking of faith and sport."],["Maccabiah Games","Jewish international multisport event."],["Civil religion","Secular devotion with religious features."],["Superstition","Belief that rituals affect outcomes."],["Rarámuri","Mexican Indigenous people famous for running."]],
  w:"Sport's links to religion and ritual explain its emotional power and the devotion of fans.",
  src:["Religion and sports","Muscular Christianity","Maccabiah Games","Superstitions in sport","Rarámuri"],
  q:[
  ["Which English football clubs began as church teams?","Aston Villa, Everton, and Southampton","Arsenal, Chelsea, Spurs","Manchester United, Leeds, Wolves","Liverpool, City, Newcastle"],
  ["What do sumo wrestlers throw before bouts as purification?","Salt","Rice","Water","Flowers"],
  ["What are the Maccabiah Games?","A Jewish international multisport event","A Muslim festival","A Christian youth league","A Hindu wrestling event"],
  ["When did FIBA allow head coverings?","2017","1990","2005","2022"],
  ["Why do athletes use rituals, according to psychologists?","To reduce anxiety and increase a sense of control","To confuse opponents","Because rules require them","For sponsorship"],
  ["Which tennis player arranges water bottles precisely?","Rafael Nadal","Roger Federer","Andy Murray","Novak Djokovic"]]});

before(12,"A Lifelong Life in Sport",
{ t:"Careers in Sport", s:"Many ways to work in the game",
  sec:[
  ["Playing and coaching",[
    "Professional athletes are a tiny fraction of those who work in sport; careers are short, often ending in the early-to-mid thirties or earlier due to injury. Many former athletes move into coaching, broadcasting, management, or business, and transition support is increasingly offered.",
    "Coaching careers range from youth and school coaching to elite head coach and specialist roles, often requiring qualifications and years of experience."]],
  ["Science and medicine",[
    "Sports science and medicine roles include sports physicians, physiotherapists, athletic trainers, strength and conditioning coaches, nutritionists, sport psychologists, biomechanists, and performance analysts. Most require relevant university degrees and professional certification.",
    "Data science is a fast-growing area, with clubs hiring analysts to work on recruitment, tactics, and injury prevention."]],
  ["Business, law, and administration",[
    "Sport business careers include marketing, sponsorship, ticketing, event management, facility management, and front-office roles such as general manager or sporting director. Agents represent athletes. Sports lawyers handle contracts, disputes, governance, and integrity cases.",
    "Governing bodies, federations, and Olympic committees employ administrators, policy specialists, and integrity officers."]],
  ["Media and communications",[
    "Media careers include journalism, broadcasting, commentary, production, photography, social media, podcasting, and public relations. Former athletes often become pundits; journalists cover games, business, and investigations.",
    "Writing well, understanding the sport deeply, and building credibility are key."]],
  ["Officiating, education, and community",[
    "Officials, PE teachers, community sports development officers, and coordinators of sport-for-development programs keep grassroots sport running. Many roles combine paid work and volunteering.",
    "Facilities and groundskeeping, equipment design and manufacturing, and esports production are other areas."]],
  ["Building a path",[
    "People enter sports careers through degrees (sports science, management, journalism, law), internships and volunteering, networking, and starting at local level. Passion for sport helps, but specialist skills and professionalism matter most.",
    "Transferable knowledge from these foundations, rules, history, science, and society, gives a strong base for any of these paths."]]
  ],
  terms:[["Performance analyst","Specialist analyzing data and video."],["Sporting director","Executive overseeing a club's football operations."],["Pundit","Expert commentator, often a former player."],["Athletic trainer","Medical professional caring for athletes."],["Career transition","Moving from playing to other work."]],
  w:"Sport offers a wide range of careers beyond playing, from science and medicine to law, media, and community work.",
  src:["Sports management","Sports science","Sports journalism","Performance analysis","Athletic trainer"],
  q:[
  ["Around what age do many pro athletes' careers end?","Early-to-mid thirties or earlier","Fifties","Twenties only","Sixties"],
  ["Which is a fast-growing sports career area?","Data science and performance analysis","Ticket printing","Typewriter repair","Telegram services"],
  ["What does a sporting director oversee?","A club's football operations","Ticket sales only","Stadium cleaning","TV production"],
  ["What is a pundit?","An expert commentator, often a former player","A referee","A team doctor","A ticket agent"],
  ["Who represents athletes in contract negotiations?","Agents","Referees","Groundskeepers","Fans"],
  ["How do many people enter sports careers?","Degrees, internships, volunteering, and networking","Only by being famous athletes","By luck alone","By betting"]]});

})();


/* ---- from sports-28.js ---- */
/* SPORTS FOUNDATIONS, part 28: further chapters spliced across units */
(function(){
const S=COURSES.sports.units;
const after=(u,title,ch)=>{const a=S[u].ch;const i=a.findIndex(c=>c.t===title);a.splice(i+1,0,ch);};

after(1,"Club Football in Europe",
{ t:"Football's Great Clubs", s:"A guide to the giants",
  sec:[
  ["Spain: Real Madrid and Barcelona",[
    "Real Madrid, founded in 1902, is the most successful club in European history, with a record number of European Cups and Spanish titles. Its 'Galácticos' policy under president Florentino Pérez from 2000 signed superstars such as Zidane, Ronaldo Nazário, and Beckham. Its stadium is the Santiago Bernabéu.",
    "FC Barcelona, founded in 1899 by Swiss businessman Joan Gamper, carries the motto 'Més que un club' ('More than a club') and is a symbol of Catalan identity. Its La Masia academy produced Messi, Xavi, and Iniesta, and its Camp Nou is Europe's largest football stadium."]],
  ["England: the big clubs",[
    "Manchester United, rebuilt by Matt Busby after the Munich disaster, became England's most successful club under Alex Ferguson (1986–2013), winning 13 league titles in the Premier League era and two Champions Leagues. Liverpool, shaped by Bill Shankly and Bob Paisley in the 1960s–80s and later Jürgen Klopp, has six European Cups, the most of any English club.",
    "Arsenal under Arsène Wenger went unbeaten through the 2003–04 league season ('The Invincibles'); Chelsea rose after Roman Abramovich's 2003 takeover; and Manchester City, after its 2008 takeover by Abu Dhabi owners, won a record four straight Premier League titles (2021–24) and a treble in 2023 under Pep Guardiola, while facing charges over alleged financial rule breaches."]],
  ["Italy and Germany",[
    "In Italy, Juventus of Turin, owned by the Agnelli family, has the most Serie A titles; AC Milan has seven European Cups; and Inter Milan won a treble in 2010 under José Mourinho. Napoli and Roma have passionate followings.",
    "In Germany, Bayern Munich dominates with the most Bundesliga titles and six European Cups; Borussia Dortmund is famous for the 'Yellow Wall,' a terrace of about 25,000 standing fans."]],
  ["Other European giants",[
    "Ajax of Amsterdam, with its renowned youth academy, won three straight European Cups in the 1970s. Benfica and Porto lead Portuguese football; Celtic became the first British club to win the European Cup in 1967 with a team all born near Glasgow ('the Lisbon Lions'). Paris Saint-Germain, Qatari-owned since 2011, won its first Champions League in 2025.",
    "Clubs such as Red Star Belgrade (1991 European champions), Steaua Bucharest (1986), and Nottingham Forest (two European Cups, 1979 and 1980) show that smaller clubs once reached the top."]],
  ["Beyond Europe",[
    "South American giants include Boca Juniors and River Plate (Argentina), Flamengo, Santos, Palmeiras, and Corinthians (Brazil), and Peñarol and Nacional (Uruguay). Africa's Al Ahly, Mexico's Club América and Chivas Guadalajara (which fields only Mexican players), and Saudi Arabia's Al Hilal are huge clubs in their regions.",
    "Each club carries history, identity, and rivalries that make it far more than a sports team to its supporters."]]
  ],
  terms:[["Més que un club","Barcelona's motto, 'More than a club.'"],["La Masia","Barcelona's youth academy."],["Invincibles","Arsenal's unbeaten 2003–04 league team."],["Yellow Wall","Dortmund's huge standing terrace."],["Lisbon Lions","Celtic's 1967 European champions."]],
  w:"Knowing the great clubs and their stories is essential to understanding world football culture.",
  src:["Real Madrid CF","FC Barcelona","Liverpool F.C.","Bayern Munich","Lisbon Lions"],
  q:[
  ["What is Barcelona's motto?","Més que un club","You'll Never Walk Alone","Mia San Mia","Forza Juve"],
  ["Which Arsenal team went unbeaten in the 2003–04 league season?","The Invincibles","The Galácticos","The Busby Babes","The Lisbon Lions"],
  ["Which was the first British club to win the European Cup (1967)?","Celtic","Manchester United","Liverpool","Rangers"],
  ["What is Dortmund's famous terrace called?","The Yellow Wall","The Kop","The Stretford End","The Curva Sud"],
  ["Which Mexican club fields only Mexican players?","Chivas Guadalajara","Club América","Cruz Azul","Monterrey"],
  ["Which English club has the most European Cups?","Liverpool","Manchester United","Chelsea","Nottingham Forest"]]});

after(2,"The NBA and Basketball Legends",
{ t:"Basketball Skills and Team Play", s:"Fundamentals of the game",
  sec:[
  ["Shooting",[
    "Good shooting form is often taught with the acronym BEEF: balance, eyes on the target, elbow aligned under the ball, and follow-through. The jump shot, popularized in the 1940s–50s, made shooting over defenders possible; Stephen Curry's range and quick release redefined what counts as a good shot.",
    "Free throws, uncontested shots from 15 feet, reward routine and consistency; great free-throw shooters make around 90%."]],
  ["Ball-handling and passing",[
    "Dribbling skills include keeping the ball low and protected, using both hands, crossovers, behind-the-back and between-the-legs dribbles, and changes of speed. Passing types include the chest pass, bounce pass, overhead pass, and no-look pass; great passers such as Magic Johnson, John Stockton (career assists record), and Nikola Jokić see plays before they happen.",
    "Turnovers, losing the ball, are costly, so taking care of the ball is a core value."]],
  ["Rebounding and defense",[
    "Rebounding relies on positioning ('boxing out' an opponent by putting your body between them and the basket), timing, and effort. Dennis Rodman won seven straight rebounding titles despite being relatively short for a forward.",
    "On defense, players use a low, wide stance, slide their feet, stay between their opponent and the basket, contest shots without fouling, and communicate on screens. Help defense and rotations make team defense work."]],
  ["Team play",[
    "Successful teams share the ball, space the floor, set screens, cut, and play unselfishly. Coaches design offenses (motion, Princeton, triangle, pick-and-roll heavy) and defenses (man-to-man, zone, press).",
    "Chemistry, understanding teammates' tendencies and trusting one another, often separates good teams from great ones, as shown by the 2004 Detroit Pistons and 2014 San Antonio Spurs, praised for selfless play."]],
  ["Training",[
    "Players develop through skill drills, shooting repetitions, scrimmages, conditioning, and strength training. Vertical jump, agility, and endurance are trained alongside skills.",
    "Basketball is accessible: a ball and a hoop are enough, which is why it thrives on playgrounds worldwide."]]
  ],
  terms:[["Jump shot","Shot released at the top of a jump."],["Boxing out","Positioning to secure rebounds."],["Turnover","Losing possession."],["Help defense","Leaving your player to stop a drive."],["Chemistry","Teammates' understanding and trust."]],
  w:"Fundamentals and team play are the foundations of basketball at every level.",
  src:["Basketball moves","Jump shot","Rebound (basketball)","John Stockton","Team chemistry"],
  q:[
  ["What does 'boxing out' mean?","Positioning your body to secure a rebound","Fighting an opponent","Leaving the court","A type of pass"],
  ["Who holds the NBA career assists record?","John Stockton","Magic Johnson","Chris Paul","Jason Kidd"],
  ["What is a turnover?","Losing possession","A change of ends","A timeout","A free throw"],
  ["Which player won seven straight rebounding titles?","Dennis Rodman","Shaquille O'Neal","Moses Malone","Dwight Howard"],
  ["What does the 'E' for elbow in BEEF remind shooters?","Keep the elbow aligned under the ball","Extend the elbow outward","Ignore the elbow","Bend the elbow sideways"],
  ["Which 2014 team was praised for selfless play?","San Antonio Spurs","Miami Heat","Los Angeles Lakers","Oklahoma City Thunder"]]});

after(5,"Distance Running and the Marathon",
{ t:"Running for Everyone", s:"Technique, training, and injury prevention",
  sec:[
  ["Running form",[
    "Good running form is relaxed and efficient: upright posture with a slight forward lean, relaxed shoulders, arms swinging forward and back rather than across the body, and feet landing roughly under the body rather than far ahead (overstriding). Cadence, steps per minute, of around 170–180 is common among experienced runners, though individuals vary.",
    "Debates about heel striking versus forefoot striking and about minimalist shoes, sparked by the book Born to Run (2009) about the Rarámuri, have no single answer; gradual change is important if adjusting technique."]],
  ["Building a training plan",[
    "Beginners often alternate walking and running, gradually extending running time. A common guideline is to increase weekly volume gradually (often cited as about 10% per week, though this is a rule of thumb). Most training should be easy, conversational pace, with occasional faster sessions such as intervals, tempo runs, and hill repeats once a base is built.",
    "Long runs build endurance for half marathons and marathons. Rest days and easy weeks allow adaptation."]],
  ["Common injuries",[
    "Common running injuries include runner's knee (patellofemoral pain), iliotibial band syndrome, Achilles tendinopathy, plantar fasciitis, shin splints, and stress fractures. Many result from doing too much too soon.",
    "Strength training, gradual progression, adequate sleep and nutrition, suitable footwear, and listening to warning signs help prevent injuries."]],
  ["Races and community",[
    "Races from 5 km to marathons, trail races, and ultramarathons give goals and community. Pacing evenly, starting conservatively and finishing strong, avoids early burnout. Running clubs and free events such as parkrun make running social.",
    "Many runners find mental health benefits, from stress relief to the 'runner's high,' linked to endocannabinoids and endorphins."]],
  ["Running at every age",[
    "Running can be enjoyed across the lifespan; masters runners set impressive records into their eighties and beyond. Research suggests recreational running is associated with longer life and, contrary to popular belief, not with higher rates of knee osteoarthritis for most recreational runners.",
    "The key is consistency, enjoyment, and adapting training to one's body."]]
  ],
  terms:[["Cadence","Steps per minute."],["Overstriding","Landing with the foot far ahead of the body."],["Tempo run","Sustained, comfortably hard run."],["Runner's knee","Pain around the kneecap."],["Runner's high","Euphoria during or after running."]],
  w:"Running is the most accessible sport; good habits make it enjoyable and injury-free for life.",
  src:["Running","Born to Run (McDougall book)","Running injuries","Parkrun","Runner's high"],
  q:[
  ["What is overstriding?","Landing with the foot far ahead of the body","Running too slowly","Taking short steps","Swinging arms too much"],
  ["Which book sparked debate about minimalist running?","Born to Run","Moneyball","Open","Friday Night Lights"],
  ["What pace should most training be at?","Easy, conversational pace","Maximum effort","Race pace always","Sprinting"],
  ["What causes many running injuries?","Doing too much too soon","Too much rest","Stretching","Eating carbohydrates"],
  ["What does research suggest about recreational running and knee osteoarthritis?","Most recreational runners do not have higher rates","It always causes arthritis","It cures arthritis","There is no research"],
  ["What is a typical cadence among experienced runners?","Around 170–180 steps per minute","Around 100","Around 250","Around 60"]]});

after(7,"Action and Adventure Sports",
{ t:"Mountaineering and Exploration", s:"Summits, poles, and the limits of endurance",
  sec:[
  ["The birth of mountaineering",[
    "Mountaineering as a sport began with the 1786 first ascent of Mont Blanc by Jacques Balmat and Michel-Gabriel Paccard. The 'Golden Age of Alpinism' (1854–1865) saw British and local guides climb many Alpine peaks, ending with Edward Whymper's first ascent of the Matterhorn in 1865, when four of his party died on the descent.",
    "The Alpine Club, founded in London in 1857, was the first mountaineering club."]],
  ["The Himalaya and Everest",[
    "The world's 14 peaks over 8,000 meters are all in the Himalaya and Karakoram. Annapurna was the first climbed (1950, French expedition). George Mallory, asked why he wanted to climb Everest, reportedly replied 'Because it's there'; he and Andrew Irvine disappeared near the summit in 1924.",
    "Edmund Hillary and Tenzing Norgay reached the summit of Everest on 29 May 1953. Reinhold Messner and Peter Habeler climbed it without supplemental oxygen in 1978, and Messner became the first to climb all 14 eight-thousanders (1986). Junko Tabei of Japan became the first woman to summit Everest (1975)."]],
  ["Modern mountaineering",[
    "Commercial expeditions now guide paying clients up Everest, leading to crowding and controversy; the 1996 disaster, in which eight climbers died in a storm in a single day, was recounted in Jon Krakauer's Into Thin Air. Sherpa guides, who carry much of the risk and work, have pushed for better pay and recognition; Nepali climber Nirmal Purja climbed all 14 eight-thousanders in about six months in 2019.",
    "Alpine-style climbing, with small teams and minimal equipment, is valued as purer than large 'siege' expeditions."]],
  ["Polar and endurance exploration",[
    "Exploration became a form of sporting competition in the early 20th century: Roald Amundsen reached the South Pole first in December 1911; Robert Falcon Scott's team arrived weeks later and died on the return. Ernest Shackleton's Endurance expedition (1914–17) became a legendary story of survival; the ship's wreck was found in 2022.",
    "Modern adventurers row oceans, cross ice caps solo, and run across continents, pushing human limits."]],
  ["Risks and ethics",[
    "Mountaineering at altitude risks altitude sickness, including potentially fatal cerebral and pulmonary edema, frostbite, avalanches, and falls. The 'death zone' above about 8,000 meters has too little oxygen to sustain life for long.",
    "Ethical debates concern environmental damage, waste on popular peaks, the treatment of local workers, and rescuing others versus pursuing the summit."]]
  ],
  terms:[["Eight-thousander","Peak over 8,000 meters."],["Alpine style","Climbing with small teams and minimal support."],["Death zone","Altitude above about 8,000 m."],["Sherpa","Himalayan people known for mountaineering expertise."],["Golden Age of Alpinism","1854–1865 era of first Alpine ascents."]],
  w:"Mountaineering and exploration test human endurance and courage at nature's extremes.",
  src:["Mountaineering","Mount Everest","Reinhold Messner","1996 Mount Everest disaster","Roald Amundsen"],
  q:[
  ["Who first reached the summit of Everest in 1953?","Edmund Hillary and Tenzing Norgay","Mallory and Irvine","Messner and Habeler","Junko Tabei"],
  ["Who first climbed all 14 eight-thousanders?","Reinhold Messner","Nirmal Purja","Jerzy Kukuczka","Edmund Hillary"],
  ["Who was the first woman to summit Everest?","Junko Tabei","Wanda Rutkiewicz","Lynn Hill","Alison Hargreaves"],
  ["Who reached the South Pole first in 1911?","Roald Amundsen","Robert Falcon Scott","Ernest Shackleton","Richard Byrd"],
  ["Which book recounted the 1996 Everest disaster?","Into Thin Air","Touching the Void","Annapurna","Seven Years in Tibet"],
  ["What is the 'death zone'?","Altitude above about 8,000 m","A glacier crevasse","An avalanche area","A base camp"]]});

after(9,"Sport and Politics",
{ t:"Sport and National Identity", s:"Flags, anthems, and belonging",
  sec:[
  ["Imagined communities",[
    "Sport is one of the most powerful expressions of national identity. Historian Eric Hobsbawm wrote that 'the imagined community of millions seems more real as a team of eleven named people,' adapting Benedict Anderson's idea of nations as 'imagined communities.' International matches let citizens feel part of a nation in a vivid, emotional way.",
    "National teams wear flags and colors, sing anthems, and carry historical memories."]],
  ["Building nations",[
    "Newly independent nations have used sport to build identity: Kenya through running, Jamaica through sprinting, and many African nations through football. Ireland's GAA promoted Gaelic games as a form of cultural nationalism distinct from British sports.",
    "South Africa's 1995 Rugby World Cup and Nelson Mandela's embrace of the once-symbolically white Springboks became a celebrated example of sport aiding national reconciliation."]],
  ["Multiple identities",[
    "In the United Kingdom, England, Scotland, Wales, and Northern Ireland compete separately in football and rugby, reflecting distinct national identities; in the Olympics they form Great Britain. Catalonia and the Basque Country express regional identity through clubs such as Barcelona and Athletic Bilbao (which fields players with Basque connections).",
    "Diaspora and dual-heritage athletes often choose which nation to represent, raising debates about belonging; many national teams include players born abroad."]],
  ["Rivalries and memory",[
    "National sporting rivalries often echo history: Netherlands vs Germany in football carried memories of World War II; India vs Pakistan echoes partition; Argentina vs England recalls the Falklands War. These matches can unite nations but also inflame tensions.",
    "Sporting triumphs, such as England's 1966 World Cup or Uruguay's 1950 Maracanazo, become part of national myth."]],
  ["Nationalism's dangers",[
    "Sport can encourage exclusionary nationalism, racist abuse, and violence. Athletes of immigrant backgrounds sometimes face conditional acceptance, celebrated when winning and blamed when losing.",
    "Healthy national pride in sport celebrates achievement and shared identity while respecting opponents and diversity."]]
  ],
  terms:[["Imagined community","Benedict Anderson's concept of the nation."],["Cultural nationalism","Promoting a nation's culture, including sports."],["Diaspora","Communities living outside their ancestral homeland."],["National myth","Story shaping a nation's self-image."],["Athletic Bilbao","Basque club fielding players with Basque links."]],
  w:"Sport gives nations a vivid sense of identity, with power both to unite and to divide.",
  src:["Sport and national identity","Imagined Communities","Eric Hobsbawm","Athletic Bilbao","Nationalism and sport"],
  q:[
  ["Who wrote that the imagined community seems more real as 'a team of eleven named people'?","Eric Hobsbawm","Benedict Anderson","George Orwell","Pierre de Coubertin"],
  ["Who coined the idea of nations as 'imagined communities'?","Benedict Anderson","Eric Hobsbawm","Karl Marx","Max Weber"],
  ["Which Basque club fields players with Basque connections?","Athletic Bilbao","Real Sociedad","Osasuna","Barcelona"],
  ["Which Irish body promoted Gaelic games as cultural nationalism?","The GAA","The FAI","The IRFU","The Irish Olympic Council"],
  ["Which 1995 event became a symbol of national reconciliation?","South Africa's Rugby World Cup win","England's cricket victory","Kenya's Olympic team","Germany's World Cup"],
  ["Under which name do UK nations compete together at the Olympics?","Great Britain","England","United Kingdom XI","Britannia"]]});

after(11,"Upsets, Miracles, and Unforgettable Moments",
{ t:"Great Olympic Moments", s:"Stories from the Games",
  sec:[
  ["Early legends",[
    "Jim Thorpe, a Native American athlete, won the pentathlon and decathlon at Stockholm 1912 but was stripped of his medals for having played semi-professional baseball; they were restored posthumously, and in 2022 the IOC recognized him as sole champion. Paavo Nurmi won nine golds across three Games in the 1920s, and Johnny Weissmuller won five swimming golds.",
    "In 1936, Jesse Owens's four golds in Berlin became one of history's great sporting stories."]],
  ["Postwar heroes",[
    "Emil Zátopek's triple at Helsinki 1952, Abebe Bikila's barefoot marathon in Rome 1960, and Wilma Rudolph's three sprint golds the same year inspired millions. Mexico City 1968 brought Bob Beamon's long jump, Dick Fosbury's flop, and the Black Power salute. At Munich 1972, Mark Spitz won seven swimming golds, though the Games were overshadowed by the massacre of Israeli athletes.",
    "Nadia Comăneci's perfect 10 (Montreal 1976) and the Miracle on Ice (Lake Placid 1980) became defining images."]],
  ["Modern icons",[
    "Carl Lewis matched Owens's four golds at Los Angeles 1984; Michael Johnson's golden shoes and 19.32 in the 200 m lit up Atlanta 1996; Cathy Freeman's 400 m win at Sydney 2000 united Australia. Michael Phelps won eight golds at Beijing 2008, and Usain Bolt's sprint triples (2008–2016) made him the face of the Games.",
    "London 2012's 'Super Saturday' saw Britain win three athletics golds in under an hour (Jessica Ennis, Greg Rutherford, and Mo Farah)."]],
  ["Moments of spirit",[
    "Some of the most memorable Olympic moments are not victories: Derek Redmond finishing with his father's help in 1992; Eric Moussambani of Equatorial Guinea, who had learned to swim months earlier, finishing his 100 m freestyle heat alone in 2000; and the Jamaican bobsled team in 1988.",
    "Shared golds and helping rivals, as in 2016 and 2021, remind viewers of the Olympic ideals of friendship and respect."]],
  ["Recent Games",[
    "Tokyo 2020 was held in 2021 without spectators due to COVID-19; Simone Biles's withdrawal sparked discussion of mental health. Paris 2024 featured opening ceremonies on the Seine, gender parity, Léon Marchand's four individual swimming golds for the host nation, Biles's return, and Armand Duplantis breaking the pole vault world record in the stadium.",
    "Each Games adds new stories to a tradition stretching back to 1896."]]
  ],
  terms:[["Golden shoes","Michael Johnson's famous 1996 spikes."],["Super Saturday","Britain's three golds in an hour, 2012."],["Olympic spirit","Ideals of friendship, respect, and excellence."],["Posthumous","After death."],["Triple","Winning three events at one Games."]],
  w:"Olympic moments capture sport's highest achievements and its human spirit.",
  src:["Jim Thorpe","Super Saturday","Eric Moussambani","2024 Summer Olympics","Mark Spitz"],
  q:[
  ["Whose Olympic medals were restored and who was recognized as sole 1912 champion in 2022?","Jim Thorpe","Jesse Owens","Paavo Nurmi","Duke Kahanamoku"],
  ["How many golds did Mark Spitz win at Munich 1972?","Seven","Eight","Five","Nine"],
  ["Which three British athletes won gold on 'Super Saturday' 2012?","Jessica Ennis, Greg Rutherford, Mo Farah","Usain Bolt, Mo Farah, Chris Hoy","Bradley Wiggins, Andy Murray, Mo Farah","Kelly Holmes, Paula Radcliffe, Jessica Ennis"],
  ["Which swimmer finished his 2000 heat alone after learning to swim months earlier?","Eric Moussambani","Paula Barila Bolopa","Thomas Bimis","Ian Thorpe"],
  ["Where were the Paris 2024 opening ceremonies held?","On the Seine","At the Eiffel Tower only","In the Stade de France","At Versailles"],
  ["Who won eight golds at Beijing 2008?","Michael Phelps","Usain Bolt","Mark Spitz","Ryan Lochte"]]});

})();
