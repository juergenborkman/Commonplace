/* ---- from arch-01.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 1: Unit 1 How Architecture Works, chapters 1-5 */
COURSES.architecture = { units: [] };
COURSES.architecture.units.push({ t:"How Architecture Works", ch:[

{ t:"What Is Architecture?", s:"Firmness, commodity, and delight",
  sec:[
  ["More than building",[
    "Architecture is the art and science of designing buildings and spaces. Every culture builds, but architecture implies intention: shaping structures not only to stand and shelter but to express meaning, order, and beauty. The word comes from the Greek arkhitekton, 'chief builder.'",
    "Architecture is unique among the arts because people live inside it. We cannot choose not to experience it; it shapes our homes, workplaces, streets, and cities every day."]],
  ["Vitruvius's triad",[
    "The Roman architect Vitruvius, in De architectura (The Ten Books on Architecture, about 30–15 BCE), the only major architectural treatise surviving from antiquity, said good architecture must have firmitas, utilitas, and venustas. In Henry Wotton's 1624 English translation: 'firmness, commodity, and delight.'",
    "Firmness means structural soundness and durability; commodity means usefulness and fitness for purpose; delight means beauty and the pleasure it gives. These three remain a basic framework for judging buildings."]],
  ["Form and function",[
    "Debates about architecture often turn on the relationship between form (shape and appearance) and function (use). The American architect Louis Sullivan wrote in 1896 that 'form ever follows function,' a phrase that became a slogan of modernism. Others argue that form also expresses meaning, culture, and emotion, not just function.",
    "Architect Ludwig Mies van der Rohe's 'less is more' and Robert Venturi's reply, 'less is a bore,' summarize a later debate."]],
  ["Architecture as cultural record",[
    "Buildings record their societies' values, technologies, and power: the pyramids of Egypt, the temples of Greece, Gothic cathedrals, palaces, factories, and skyscrapers each reveal what their builders believed important. The writer Victor Hugo suggested that before printing, architecture was humanity's great book.",
    "Architecture also expresses identity, as in national parliaments, religious buildings, and memorials."]],
  ["Who makes architecture",[
    "Most buildings in history were made by builders without trained architects, a tradition called vernacular architecture. Professional architects emerged in ancient civilizations, the Renaissance, and especially in the 19th and 20th centuries with formal education and licensing.",
    "Today, buildings are created by teams: clients, architects, engineers, contractors, planners, and the communities who use them."]]
  ],
  terms:[["Architecture","Art and science of designing buildings and spaces."],["Vitruvius","Roman author of the oldest surviving architectural treatise."],["Firmness, commodity, delight","Vitruvius's three qualities of good architecture."],["Form follows function","Sullivan's principle linking shape to use."],["Vernacular architecture","Traditional building without professional architects."]],
  w:"Understanding what architecture is gives a framework for judging every building you live, work, and walk in.",
  src:["Architecture","Vitruvius","De architectura","Form follows function","Vernacular architecture"],
  q:[
  ["Which Roman wrote the only major surviving ancient architectural treatise?","Vitruvius","Pliny","Cicero","Seneca"],
  ["What are Vitruvius's three qualities of architecture?","Firmness, commodity, and delight","Size, cost, and speed","Stone, wood, and brick","Light, space, and color"],
  ["Who wrote that 'form ever follows function'?","Louis Sullivan","Le Corbusier","Frank Lloyd Wright","Mies van der Rohe"],
  ["Who replied 'less is a bore' to Mies's 'less is more'?","Robert Venturi","Philip Johnson","Frank Gehry","Louis Kahn"],
  ["What does the Greek arkhitekton mean?","Chief builder","Stone carver","House maker","Master planner"],
  ["What is vernacular architecture?","Traditional building without professional architects","Government buildings","Skyscrapers","Religious buildings only"]]},

{ t:"Structure: How Buildings Stand Up", s:"Forces, loads, and systems",
  sec:[
  ["Loads",[
    "Every building must resist loads. Dead loads are the permanent weight of the structure itself; live loads are changing weights such as people, furniture, and snow; environmental loads include wind and earthquakes. All loads must be carried safely down to the ground through the structure and foundations.",
    "Structural engineers calculate these loads and design members to carry them with a margin of safety."]],
  ["Tension and compression",[
    "Two basic forces act within structures: compression, which squeezes or pushes material together, and tension, which pulls it apart. Stone and brick are strong in compression but weak in tension; steel is strong in both; wood is reasonably good in both. A beam under load experiences compression on top and tension on the bottom.",
    "Bending, shear (sliding forces), and torsion (twisting) are other important forces."]],
  ["Post and lintel to arches",[
    "The simplest structural system is post and lintel (or column and beam): vertical posts support a horizontal beam, as at Stonehenge and Greek temples. Because stone beams crack under tension, spans had to be short and columns close together.",
    "The arch carries loads by compression along a curve, allowing much larger spans with stone or brick; its wedge-shaped stones (voussoirs) are locked by a central keystone. Arches push outward (thrust), which must be resisted by thick walls or buttresses. Extending an arch creates a vault; rotating it creates a dome."]],
  ["Frames, trusses, and shells",[
    "A frame structure uses a skeleton of columns and beams (wood, steel, or reinforced concrete) to carry loads, freeing walls from load-bearing so they can be thin or glass. A truss is a framework of triangles, which cannot change shape without changing the length of a side, making trusses rigid and efficient for bridges and roofs.",
    "Shells (thin curved surfaces), cables (suspension bridges, tensile roofs), and membranes carry loads through their shape. Cantilevers project beyond their support, like a diving board."]],
  ["Foundations and stability",[
    "Foundations spread loads into the ground: shallow footings for firm soil, deep piles driven to bedrock or firm layers in soft soil. Poor foundations cause settlement, as at the Leaning Tower of Pisa, which began tilting during construction in the 12th century because of soft soil; engineers stabilized it between 1990 and 2001.",
    "Lateral stability against wind and earthquakes requires bracing, shear walls, or rigid frames."]]
  ],
  terms:[["Dead load","Permanent weight of a structure."],["Compression","Force pushing material together."],["Tension","Force pulling material apart."],["Keystone","Central stone locking an arch."],["Truss","Rigid framework of triangles."]],
  w:"Knowing how forces flow through structures explains why buildings take the shapes they do.",
  src:["Structural engineering","Post and lintel","Arch","Truss","Leaning Tower of Pisa"],
  q:[
  ["Stone is strong in which force?","Compression","Tension","Torsion","Shear only"],
  ["What locks the top of an arch?","The keystone","The lintel","The voussoir at the base","The pier"],
  ["Why are trusses made of triangles?","Triangles can't change shape without changing a side's length","Triangles are cheap","Triangles look good","Triangles carry tension only"],
  ["What is a cantilever?","A structural member projecting beyond its support","A type of arch","A foundation","A dome"],
  ["Why does the Leaning Tower of Pisa tilt?","Soft soil under its foundation","Earthquake damage","Bad design on purpose","Wind erosion"],
  ["What is a live load?","Changing weights such as people and furniture","The building's own weight","Wind only","Earthquakes only"]]},

{ t:"Building Materials", s:"Stone, brick, timber, concrete, steel, glass",
  sec:[
  ["Earth and stone",[
    "Earth, in the form of mud brick (adobe), rammed earth, or cob, is among the oldest and most widespread building materials, still housing a large share of the world's people; the Great Mosque of Djenné in Mali is the largest mud-brick building in the world. Stone is durable and strong in compression; ashlar is finely cut, squared stone, while rubble is rough stone.",
    "Great stone traditions range from Egyptian limestone and granite to Greek marble and Inca masonry fitted without mortar."]],
  ["Brick and timber",[
    "Fired brick, made since at least the 4th millennium BCE in Mesopotamia and the Indus Valley, is durable, modular, and fire-resistant. Brick patterns (bonds) such as Flemish and English bond create strength and decoration.",
    "Timber is light, renewable, and strong for its weight, used for frames, roofs, and entire buildings, from Japanese temples (Hōryū-ji, among the oldest wooden buildings in the world, about 7th century) to Scandinavian stave churches and American balloon frames. Cross-laminated timber (CLT), engineered panels of glued wood layers, now enables tall timber buildings."]],
  ["Concrete",[
    "The Romans developed a durable concrete using volcanic ash (pozzolana), allowing them to build the Pantheon's unreinforced dome, still the world's largest. Modern Portland cement was patented in 1824 by Joseph Aspdin in England.",
    "Reinforced concrete, with steel bars (rebar) embedded to resist tension, developed in the late 19th century (pioneers include Joseph Monier and François Hennebique) and became the most widely used structural material in the world. Prestressed concrete uses tensioned steel to increase strength. Concrete's cement production, however, contributes around 8% of global carbon dioxide emissions."]],
  ["Iron and steel",[
    "Cast iron, strong in compression, enabled the first iron bridge at Coalbrookdale, England (1779). Wrought iron and then steel, mass-produced after Henry Bessemer's process (1856), are strong in both tension and compression, enabling long-span bridges, train sheds, and skyscraper frames.",
    "Steel needs fireproofing and protection from corrosion."]],
  ["Glass and new materials",[
    "Glass was used in small panes for centuries; stained glass transformed Gothic cathedrals. The float glass process, invented by Alastair Pilkington in the 1950s, made large flat sheets cheap, enabling glass curtain walls. Modern glazing includes insulated, low-emissivity, and laminated safety glass.",
    "Contemporary materials include aluminum, plastics, fabric membranes such as PTFE and ETFE (used in the Eden Project's domes), and experimental materials like mycelium and recycled composites."]]
  ],
  terms:[["Adobe","Sun-dried mud brick."],["Ashlar","Finely cut, squared stone."],["Reinforced concrete","Concrete with embedded steel bars."],["Cross-laminated timber","Engineered wood panels."],["Curtain wall","Non-structural exterior wall, often glass."]],
  w:"Materials determine what buildings can do and how they look, and they shape architecture's environmental impact.",
  src:["Building material","Reinforced concrete","Roman concrete","Cross-laminated timber","Great Mosque of Djenné"],
  q:[
  ["What is the largest mud-brick building in the world?","Great Mosque of Djenné","Great Wall","Pyramid of the Sun","Arg-e Bam"],
  ["What allowed Roman concrete to be so durable?","Volcanic ash (pozzolana)","Steel rebar","Glass fibers","Plastic"],
  ["Who patented Portland cement in 1824?","Joseph Aspdin","Henry Bessemer","Joseph Monier","François Hennebique"],
  ["Where is the first iron bridge (1779)?","Coalbrookdale, England","Paris","Pittsburgh","Glasgow"],
  ["What does reinforced concrete add to resist tension?","Steel bars (rebar)","Wood beams","Glass","Stone"],
  ["Who invented the float glass process?","Alastair Pilkington","Joseph Paxton","Gustave Eiffel","Henry Bessemer"]]},

{ t:"Space, Light, Scale, and Proportion", s:"The experience of architecture",
  sec:[
  ["Space as the medium",[
    "Architecture shapes space, the void within and between buildings, as much as solid matter. The Chinese Daodejing observes that the usefulness of a room lies in its empty space. Sequences of spaces, compressed entries opening into tall halls, create drama, as Frank Lloyd Wright often used.",
    "Circulation, the paths people take through a building, choreographs movement and experience."]],
  ["Light",[
    "Light reveals form and creates mood. Le Corbusier defined architecture as 'the masterly, correct and magnificent play of masses brought together in light.' Gothic cathedrals used stained glass to create colored, otherworldly light; the Pantheon's oculus casts a moving disc of sunlight; Tadao Ando's Church of the Light in Osaka uses a cross-shaped slit in a concrete wall.",
    "Louis Kahn spoke of 'served' and 'servant' spaces and of light as the giver of presence; daylighting also reduces energy use."]],
  ["Scale",[
    "Scale is size relative to the human body and surroundings. Monumental scale overwhelms, inspiring awe or expressing power, as in cathedrals and government buildings; human scale feels comfortable and intimate, as in traditional streets and houses.",
    "Doors, stairs, windows, and ceiling heights give clues to scale."]],
  ["Proportion",[
    "Proportion is the relationship of parts to each other and to the whole. Architects have used mathematical systems: simple ratios such as 1:2 and 2:3, the golden ratio (about 1.618, though its use in ancient buildings is often exaggerated), Vitruvius's ideas of the proportions of the human body (illustrated by Leonardo da Vinci's 'Vitruvian Man'), and Le Corbusier's Modulor (1948), a scale based on human dimensions.",
    "Renaissance architects such as Palladio linked harmonious proportions to musical harmonies."]],
  ["Materials, texture, and senses",[
    "Architecture engages all the senses: the texture and warmth of materials, acoustics (the echo of a cathedral versus the hush of a library), temperature, and smell. Finnish architect Juhani Pallasmaa's The Eyes of the Skin (1996) argues architecture should address the whole body, not just the eye.",
    "Color, rhythm (repetition of elements like windows and columns), symmetry, and contrast all shape our experience."]]
  ],
  terms:[["Circulation","Paths of movement through a building."],["Oculus","Circular opening, as at the Pantheon."],["Scale","Size relative to humans and surroundings."],["Proportion","Relationship of parts to the whole."],["Modulor","Le Corbusier's human-based proportion system."]],
  w:"Space, light, scale, and proportion are the language through which buildings move us.",
  src:["Architectural design values","Proportion (architecture)","Daylighting","Modulor","Church of the Light"],
  q:[
  ["Who defined architecture as 'the masterly, correct and magnificent play of masses brought together in light'?","Le Corbusier","Louis Kahn","Frank Lloyd Wright","Alvar Aalto"],
  ["Which building has a cross-shaped slit of light in a concrete wall?","Church of the Light","Pantheon","Chartres Cathedral","Notre-Dame du Haut"],
  ["What is Le Corbusier's proportion system called?","The Modulor","The golden section","The Vitruvian scale","The Fibonacci grid"],
  ["Who drew the 'Vitruvian Man'?","Leonardo da Vinci","Michelangelo","Palladio","Brunelleschi"],
  ["What is circulation in architecture?","The paths people take through a building","Air conditioning","Plumbing","Traffic outside"],
  ["Who wrote The Eyes of the Skin?","Juhani Pallasmaa","Christopher Alexander","Rem Koolhaas","Peter Zumthor"]]},

{ t:"Reading Buildings: Drawings and Vocabulary", s:"Plans, sections, and elevations",
  sec:[
  ["Architectural drawings",[
    "Architects communicate through drawings. A plan is a horizontal slice through a building, seen from above, showing walls, rooms, doors, and windows. A section is a vertical slice showing heights, floors, and how spaces relate vertically. An elevation is a flat view of one side of a building.",
    "Axonometric and isometric drawings show three dimensions without perspective distortion; perspective drawings show how a building appears to the eye."]],
  ["Models and digital tools",[
    "Physical models, from rough sketch models to detailed presentation models, help architects study form. Since the 1980s–90s, computer-aided design (CAD) and later building information modeling (BIM), which creates a shared 3D database of all building elements, have transformed design and construction.",
    "Renderings and virtual reality let clients walk through buildings before they exist."]],
  ["Basic vocabulary",[
    "Useful terms include façade (the main face of a building), bay (a vertical division of a façade), cornice (a projecting molding at the top of a wall), pediment (a triangular gable above a portico), portico (a porch with columns), colonnade (a row of columns), arcade (a row of arches), nave (the central hall of a church), and atrium (a central open space).",
    "Roof types include gable, hip, flat, mansard (with two slopes on each side, named after François Mansart), and dome."]],
  ["Parts of a wall and opening",[
    "A building's base is its plinth; walls may be load-bearing or infill; openings have sills (bottom), jambs (sides), and heads or lintels (top). Windows include sash windows (sliding vertically), casements (hinged), and bay windows (projecting).",
    "Moldings, cornices, and string courses articulate walls and cast shadows."]],
  ["Looking at a building",[
    "To read a building, ask: What is it for? How is it structured? What materials are used? How does it meet the ground and the sky? How do you enter, and how do you move through it? How does it relate to its neighbors and site? When and why was it built?",
    "Walking around and through a building, in different light and seasons, reveals far more than photographs."]]
  ],
  terms:[["Plan","Horizontal slice of a building seen from above."],["Section","Vertical slice through a building."],["Elevation","Flat view of one side of a building."],["BIM","Building information modeling."],["Façade","Main face of a building."]],
  w:"Knowing how architects draw and describe buildings lets you read any building with understanding.",
  src:["Architectural drawing","Floor plan","Building information modeling","Glossary of architecture","Facade"],
  q:[
  ["What is a plan drawing?","A horizontal slice seen from above","A vertical slice","A side view","A perspective sketch"],
  ["What is an elevation drawing?","A flat view of one side of a building","A drawing of the roof","A slice through the floors","A site map"],
  ["What does BIM stand for?","Building information modeling","Basic interior model","Brick installation method","Builder's industrial measurement"],
  ["What is a pediment?","A triangular gable above a portico","A row of arches","A central hall","A type of window"],
  ["Who is the mansard roof named after?","François Mansart","Andrea Palladio","Christopher Wren","Inigo Jones"],
  ["What is an arcade?","A row of arches","A row of columns","A central open space","A projecting molding"]]}

]});


/* ---- from arch-02.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 2: Unit 1 chapters 6-10 */
COURSES.architecture.units[0].ch.push(

{ t:"The Classical Orders", s:"Doric, Ionic, Corinthian, and their family",
  sec:[
  ["What an order is",[
    "A classical order is a system of column and beam (entablature) with set proportions and ornaments, developed in ancient Greece and Rome. Each order consists of a base (except Greek Doric), a shaft, a capital (the top of the column), and an entablature made up of the architrave (lowest beam), frieze (middle band, often decorated), and cornice (projecting top).",
    "The orders gave Western architecture a shared grammar that architects used for over two thousand years, and still use today in banks, courthouses, museums, and homes."]],
  ["Doric",[
    "The Doric order, the oldest and plainest, developed in mainland Greece in the 7th century BCE. Greek Doric columns stand directly on the temple floor without a base, have broad, fluted shafts, and simple cushion-like capitals. The frieze alternates triglyphs (vertical grooved blocks) and metopes (panels, often sculpted).",
    "The Parthenon in Athens (447–432 BCE) is the supreme Doric temple. Vitruvius associated Doric with masculine strength."]],
  ["Ionic",[
    "The Ionic order, from the Greek cities of Asia Minor (Ionia), is slenderer, with a base and a capital featuring scroll-shaped volutes. Its frieze is often continuous, allowing long sculpted scenes. Vitruvius compared it to feminine grace.",
    "The Erechtheion on the Athenian Acropolis, with its famous porch of caryatids (columns carved as female figures), and the Temple of Artemis at Ephesus, one of the Seven Wonders of the Ancient World, used the Ionic order."]],
  ["Corinthian",[
    "The Corinthian order, the most ornate, has a slender column topped by a bell-shaped capital of acanthus leaves and small scrolls. Vitruvius told the legend that the sculptor Callimachus was inspired by a basket left on a young girl's grave, around which an acanthus plant had grown.",
    "The Romans favored Corinthian for grand buildings such as the Pantheon's portico."]],
  ["Roman additions and the classical tradition",[
    "The Romans added the Tuscan order (a simplified Doric with a base and unfluted shaft) and the Composite order (combining Ionic volutes with Corinthian leaves). Renaissance theorists, including Sebastiano Serlio and Giacomo Barozzi da Vignola, codified the five orders in illustrated books that spread classical architecture across Europe.",
    "The orders were often superimposed on multistory buildings, sturdy Doric or Tuscan at the bottom and lighter Ionic and Corinthian above, as on the Colosseum."]],
  ["Refinements and classicism",[
    "Greek architects used subtle refinements: entasis (a slight swelling of the column shaft to avoid looking concave), slight inward lean of columns, and a gently curved floor (stylobate) in the Parthenon, correcting optical illusions and adding life.",
    "Classicism, the revival of classical forms, recurred in the Renaissance, Neoclassicism, the Beaux-Arts, and today's 'New Classical' architecture."]]
  ],
  terms:[["Order","System of column and entablature with set proportions."],["Capital","Top of a column."],["Entablature","Beam structure above columns."],["Volute","Scroll-shaped ornament on Ionic capitals."],["Entasis","Slight swelling of a column's shaft."]],
  w:"The classical orders are architecture's oldest shared language, still visible on buildings everywhere.",
  src:["Classical order","Doric order","Ionic order","Corinthian order","Entasis"],
  q:[
  ["Which order has acanthus-leaf capitals?","Corinthian","Doric","Ionic","Tuscan"],
  ["Which order is the oldest and plainest?","Doric","Ionic","Corinthian","Composite"],
  ["What are columns carved as female figures called?","Caryatids","Atlantes","Volutes","Metopes"],
  ["What is entasis?","A slight swelling of the column shaft","A type of capital","A roof ornament","A base molding"],
  ["Which two orders did the Romans add?","Tuscan and Composite","Doric and Ionic","Corinthian and Ionic","Gothic and Romanesque"],
  ["What distinguishes Ionic capitals?","Scroll-shaped volutes","Acanthus leaves","Plain cushions","Triglyphs"]]},

{ t:"Building Types and Their Purposes", s:"Form shaped by use",
  sec:[
  ["Houses and dwellings",[
    "The house is the most common building type, shaped by climate, family structure, materials, and culture: the Roman domus around an atrium, the Chinese courtyard house (siheyuan), the Japanese house with sliding paper screens (shoji) and tatami mats, the English terraced house, the American suburban house, and the apartment block.",
    "Housing makes up the majority of most cities' built area, and its design shapes daily life profoundly."]],
  ["Sacred buildings",[
    "Religious buildings express beliefs about the divine and community: temples housing a god's image, churches gathering congregations, mosques oriented toward Mecca with a mihrab niche showing the direction of prayer (qibla), synagogues with an ark for the Torah, Hindu temples representing a cosmic mountain, and Buddhist stupas containing relics and walked around clockwise.",
    "Sacred architecture often uses height, light, axis, and procession to inspire awe."]],
  ["Civic and governmental buildings",[
    "Civic buildings represent collective life and authority: Greek agoras and stoas, Roman basilicas (law courts, later adapted as churches), medieval town halls, parliaments (the Palace of Westminster, the US Capitol), courthouses, and city halls.",
    "Their architecture often uses classical forms, domes, steps, and towers to express dignity and permanence."]],
  ["Public and cultural buildings",[
    "Theaters, museums, libraries, schools, hospitals, stations, and stadiums each developed specific forms: tiered seating for sightlines, galleries with controlled light, reading rooms, classrooms, wards with ventilation, and vast train sheds. Many became 19th-century civic monuments.",
    "Commercial buildings, markets, arcades, department stores, office towers, and shopping malls, shape modern economic life."]],
  ["Industrial and infrastructure",[
    "Factories, warehouses, power stations, dams, bridges, and airports are also architecture, often pioneering new structures and materials. Early modernists admired American grain silos and factories for their functional beauty.",
    "Many old industrial buildings are now adapted for new uses, such as London's Tate Modern, a former power station."]],
  ["Typology",[
    "Architects speak of 'typology,' the study of building types and their recurring forms. A new building can follow, adapt, or break its type's conventions.",
    "Understanding types helps us read buildings: we often recognize a church, school, or bank at a glance because of type."]]
  ],
  terms:[["Typology","Study of building types."],["Mihrab","Niche in a mosque showing the direction of Mecca."],["Basilica","Roman hall later used for churches."],["Siheyuan","Chinese courtyard house."],["Adaptive reuse","Converting a building to a new use."]],
  w:"Each building type evolved forms suited to its purpose; recognizing them helps you read any streetscape.",
  src:["Building typology","Mihrab","Basilica","Siheyuan","Adaptive reuse"],
  q:[
  ["What does a mihrab indicate in a mosque?","The direction of Mecca","The entrance","The minaret","The women's section"],
  ["What was a Roman basilica originally?","A hall for law courts and business","A temple","A bath house","A theater"],
  ["What is a siheyuan?","A Chinese courtyard house","A Japanese tea house","A Korean palace","An Indian stepwell"],
  ["Which London museum occupies a former power station?","Tate Modern","British Museum","Natural History Museum","V&A"],
  ["How are Buddhist stupas traditionally walked around?","Clockwise","Counterclockwise","Never","In a straight line"],
  ["What is typology in architecture?","The study of building types","A type of font","A structural system","A roof form"]]},

{ t:"Climate, Site, and Vernacular Wisdom", s:"Building with nature",
  sec:[
  ["Responding to climate",[
    "Before air conditioning, buildings had to respond to climate through design. In hot, dry climates, thick walls of earth or stone store heat by day and release it at night (thermal mass); small windows and courtyards provide shade; light colors reflect sun. In hot, humid climates, raised, open, lightweight buildings with deep roofs maximize ventilation, as in Malay houses and traditional Caribbean architecture.",
    "In cold climates, compact forms, insulation, small windows, and steep roofs shedding snow conserve heat."]],
  ["Ingenious traditional techniques",[
    "Persian windcatchers (badgirs) capture breezes and channel them through buildings, sometimes over underground water channels (qanats) for cooling. Indian stepwells (such as Rani ki Vav in Gujarat) provided cool water and gathering spaces. Inuit igloos use snow's insulation; Mongolian gers (yurts) are portable felt dwellings.",
    "Mashrabiya, carved wooden lattice screens in Arab architecture, provide shade, privacy, and airflow."]],
  ["Site and orientation",[
    "Good architecture responds to its site: topography, views, sun path, prevailing winds, water, and vegetation. Orienting buildings to capture winter sun and avoid summer heat is a basic principle of passive design, known since antiquity; the Greek writer Xenophon described south-facing houses.",
    "Feng shui, the traditional Chinese practice of arranging buildings in harmony with landscape and energy (qi), influenced siting in East Asia."]],
  ["Vernacular architecture",[
    "Vernacular architecture, buildings made by local people using local materials and inherited knowledge, accounts for most buildings ever built. Bernard Rudofsky's 1964 exhibition and book Architecture Without Architects at the Museum of Modern Art celebrated its beauty and wisdom.",
    "Examples include Cappadocian cave dwellings, Yemeni mud-brick tower houses in Shibam (called 'the Manhattan of the desert'), Dogon villages in Mali, and Swiss chalets."]],
  ["Lessons for today",[
    "Vernacular techniques inspire sustainable design: passive cooling, local materials, and climate-appropriate forms reduce energy use. Architects such as Hassan Fathy in Egypt (Architecture for the Poor) and Francis Kéré in Burkina Faso adapted traditional methods for modern needs.",
    "As climate change intensifies, learning from traditional climate responses has become urgent."]]
  ],
  terms:[["Thermal mass","Material storing and releasing heat."],["Windcatcher","Persian tower capturing breezes for cooling."],["Passive design","Using climate and orientation instead of machines."],["Mashrabiya","Arab wooden lattice screen."],["Architecture Without Architects","Rudofsky's 1964 exhibition of vernacular buildings."]],
  w:"Traditional buildings show ingenious ways to work with climate, lessons now vital for sustainable design.",
  src:["Vernacular architecture","Windcatcher","Passive solar building design","Architecture Without Architects","Shibam"],
  q:[
  ["What is a Persian windcatcher (badgir) used for?","Capturing breezes for cooling","Storing grain","Defense","Collecting rainwater only"],
  ["Which Yemeni city is called 'the Manhattan of the desert'?","Shibam","Sana'a","Aden","Marib"],
  ["Who curated Architecture Without Architects (1964)?","Bernard Rudofsky","Philip Johnson","Le Corbusier","Hassan Fathy"],
  ["What is thermal mass?","Material that stores and releases heat","A type of insulation foam","A cooling machine","A roof shape"],
  ["Which Egyptian architect wrote Architecture for the Poor?","Hassan Fathy","Zaha Hadid","Francis Kéré","Imhotep"],
  ["What is a mashrabiya?","A wooden lattice screen","A domed roof","A courtyard fountain","A minaret"]]},

{ t:"The Architect and the Design Process", s:"From brief to building",
  sec:[
  ["The profession",[
    "The architect's role has changed over history: master masons led medieval cathedral building; Renaissance architects were often painters or sculptors (Brunelleschi was a goldsmith, Michelangelo a sculptor). Professional bodies emerged in the 19th century: the Royal Institute of British Architects (1834) and the American Institute of Architects (1857). Formal education developed at France's École des Beaux-Arts and later at university schools.",
    "Today architects are typically licensed after university study (often five to seven years), supervised experience, and examinations."]],
  ["The brief",[
    "A project begins with a client's brief (or program): what spaces are needed, their sizes and relationships, budget, schedule, and aspirations. Architects analyze the site, regulations (zoning and building codes), and context.",
    "Understanding users' needs, sometimes through consultation with communities, is essential."]],
  ["Design stages",[
    "Design proceeds through stages: concept or schematic design (exploring big ideas through sketches and models), design development (refining layouts, structure, and materials with engineers), and construction documents (detailed drawings and specifications for builders). The design must obtain planning or building permits.",
    "Iteration, testing and revising options, is central; architects often produce many alternatives."]],
  ["Collaboration",[
    "Architects work with structural engineers, mechanical, electrical, and plumbing (MEP) engineers, landscape architects, interior designers, quantity surveyors (cost consultants), and contractors. Large projects involve dozens of specialists.",
    "Different procurement methods, such as design-bid-build or design-and-build, structure these relationships."]],
  ["Construction and after",[
    "During construction, architects typically review contractors' work, answer questions, and approve changes. After completion, post-occupancy evaluation studies how well buildings perform for users and energy.",
    "Architects also design for maintenance, adaptability, and the building's whole life cycle, from construction to eventual reuse or demolition."]],
  ["Famous awards",[
    "The Pritzker Architecture Prize (from 1979), often called architecture's Nobel, honors living architects; laureates include Philip Johnson (the first), Frank Gehry, Zaha Hadid (the first woman, 2004), Balkrishna Doshi, Francis Kéré, and Riken Yamamoto. The RIBA Royal Gold Medal and the AIA Gold Medal are other major honors.",
    "Awards highlight design excellence but also spark debate about whose work gets recognized."]]
  ],
  terms:[["Brief (program)","Client's statement of needs."],["Schematic design","Early conceptual design stage."],["Construction documents","Detailed drawings for building."],["Post-occupancy evaluation","Studying a building in use."],["Pritzker Prize","Top international architecture award."]],
  w:"Knowing how architects work explains how buildings move from ideas to reality.",
  src:["Architect","Architectural design process","Royal Institute of British Architects","Pritzker Architecture Prize","École des Beaux-Arts"],
  q:[
  ["When was the RIBA founded?","1834","1900","1757","1945"],
  ["Who was the first woman to win the Pritzker Prize?","Zaha Hadid","Kazuyo Sejima","Anne Lacaton","Yvonne Farrell"],
  ["Who won the first Pritzker Prize in 1979?","Philip Johnson","Frank Gehry","Le Corbusier","I. M. Pei"],
  ["What is a client's brief?","A statement of needs, budget, and goals","A legal contract","A construction drawing","An award"],
  ["What was Brunelleschi originally trained as?","A goldsmith","A painter","A priest","A soldier"],
  ["What is post-occupancy evaluation?","Studying how a building performs in use","Demolishing a building","Selling a building","Inspecting foundations"]]},

{ t:"Building Codes, Safety, and Accessibility", s:"Rules that shape buildings",
  sec:[
  ["Ancient rules",[
    "Building regulations are ancient: Hammurabi's Code (about 1754 BCE) prescribed death for a builder whose house collapsed and killed its owner. Roman laws limited building heights, and after the Great Fire of Rome in 64 CE, Nero required wider streets and fire-resistant materials.",
    "After the Great Fire of London (1666), the Rebuilding Act required brick and stone instead of timber."]],
  ["Modern codes",[
    "Modern building codes set minimum standards for structural safety, fire protection, egress (exits), sanitation, ventilation, energy efficiency, and accessibility. In the United States, model codes such as the International Building Code are adopted locally; many countries have national codes. Codes often tighten after disasters.",
    "Fire safety includes fire-resistant materials, compartmentation, sprinklers, alarms, and protected escape stairs; the 1911 Triangle Shirtwaist Factory fire in New York, which killed 146 garment workers trapped behind locked doors, spurred reforms."]],
  ["Disasters and lessons",[
    "Earthquake engineering has advanced through disasters; Japan and Chile have strict seismic codes, and techniques such as base isolation allow buildings to move independently of ground shaking. The 2017 Grenfell Tower fire in London, which killed 72 people after flammable cladding spread flames, led to major reviews of building safety regulations in the UK.",
    "Building collapses due to poor construction, such as the 2013 Rana Plaza collapse in Bangladesh that killed over 1,100 garment workers, highlight the need for enforcement."]],
  ["Zoning and planning",[
    "Zoning laws regulate land use (residential, commercial, industrial), building height, density, and setbacks. New York's 1916 Zoning Resolution, responding to the massive Equitable Building that cast streets into shadow, required setbacks that produced the 'wedding cake' skyscrapers of the 1920s–30s.",
    "Planning laws also protect historic areas, views, and green spaces, and affect housing supply and affordability."]],
  ["Accessibility",[
    "Universal design aims to make buildings usable by everyone, including people with disabilities, older people, and children. The Americans with Disabilities Act (1990) and similar laws require ramps, accessible entrances, elevators, accessible restrooms, and other features in public buildings.",
    "Accessibility is now seen as integral to good design rather than an afterthought."]]
  ],
  terms:[["Building code","Legal minimum standards for construction."],["Egress","Means of exiting a building."],["Base isolation","Seismic technique separating a building from ground motion."],["Zoning","Regulation of land use and building form."],["Universal design","Design usable by everyone."]],
  w:"Codes, zoning, and accessibility laws invisibly shape every building and protect the people inside.",
  src:["Building code","Triangle Shirtwaist Factory fire","Grenfell Tower fire","1916 Zoning Resolution","Universal design"],
  q:[
  ["Which ancient code prescribed death for builders whose houses collapsed fatally?","Hammurabi's Code","Twelve Tables","Justinian's Code","Code of Ur-Nammu"],
  ["Which 1911 fire spurred workplace safety reforms in the US?","Triangle Shirtwaist Factory fire","Chicago Fire","Iroquois Theater fire","Grenfell"],
  ["What caused the Grenfell Tower fire to spread?","Flammable cladding","Gas explosion","Arson only","Lightning"],
  ["Which 1916 law produced 'wedding cake' skyscrapers?","New York's Zoning Resolution","Chicago Building Act","London Building Act","Paris height limit"],
  ["What is base isolation?","A seismic technique separating a building from ground motion","A type of foundation for swamps","A fire barrier","A zoning rule"],
  ["Which 1990 US law requires accessible public buildings?","Americans with Disabilities Act","Civil Rights Act","Fair Housing Act","Clean Air Act"]]}

);


/* ---- from arch-03.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 3: Unit 2 Ancient Architecture, chapters 1-5 */
COURSES.architecture.units.push({ t:"Ancient Architecture", ch:[

{ t:"Prehistoric Building and Megaliths", s:"From shelters to Stonehenge",
  sec:[
  ["The first shelters",[
    "Architecture begins long before written history. Early humans used caves and rock overhangs, but they also built. Sites in Europe and Ukraine show huts framed with mammoth bones and tusks, covered with hides, dating to roughly 15,000–20,000 years ago. Elsewhere people bent saplings into domes, thatched them with grass or reeds, and dug floors slightly below ground to hold warmth.",
    "These first structures already show the basic problems every later builder faced: how to span a space, how to keep out rain and wind, how to hold heat in or let it out, and how to use whatever material is close at hand. The answers changed with climate and resources, which is why the history of architecture is also a history of local materials."]],
  ["Settling down: the Neolithic house",[
    "When people began farming, after about 10,000 BCE in the Fertile Crescent, they settled in permanent villages. Jericho, in the Jordan Valley, had a massive stone wall and tower by around 8000 BCE, among the oldest known. Çatalhöyük in Anatolia (modern Turkey), occupied from about 7100 to 5700 BCE, was a dense town of mud-brick houses packed so tightly that people moved across the rooftops and entered their homes through holes in the roof by ladder.",
    "Inside, Çatalhöyük's houses had plastered walls painted with hunting scenes and bulls' horns set into benches. The town had no streets and no obvious palaces or temples, which archaeologists read as a sign of a fairly equal society. The house was workshop, shrine, and grave at once: people were buried beneath the floors."]],
  ["Göbekli Tepe",[
    "The most surprising early site is Göbekli Tepe in southeastern Turkey, begun around 9500 BCE. It consists of circular enclosures ringed by massive T-shaped limestone pillars, some over 5 meters tall, carved with foxes, boars, snakes, vultures, and stylized human arms and hands. It predates pottery, writing, and the wheel.",
    "Göbekli Tepe was built by people who were still mostly hunter-gatherers. Its excavator, Klaus Schmidt, argued that it was a ritual center and that the need to feed large work crews may have helped push people toward farming. Scholars still debate how it was used, but it overturned the old assumption that monumental building came only after agriculture and cities."]],
  ["Megaliths and dolmens",[
    "Megalith means 'great stone'. Between about 4500 and 1500 BCE, communities along Atlantic Europe, from Portugal to Scandinavia, raised standing stones (menhirs), rows of stones, and dolmens, tombs made of upright slabs capped by a huge flat stone. At Carnac in Brittany, more than 3,000 standing stones stand in long parallel lines.",
    "Passage tombs such as Newgrange in Ireland (about 3200 BCE) show remarkable precision. A long stone passage leads into a cross-shaped chamber under a great mound, and above the entrance a 'roof box' lets the rising sun shine down the passage to the inner chamber for a few days around the winter solstice. The chamber's corbelled roof, built of overlapping stones, has stayed dry for over 5,000 years."]],
  ["Stonehenge",[
    "Stonehenge on Salisbury Plain in England was built in stages from about 3000 to 1500 BCE. It began as a circular ditch and bank. Around 2500 BCE, builders raised a circle of large sarsen stones capped with lintels, and inside it a horseshoe of five great trilithons (two uprights with a lintel). Smaller bluestones were brought from the Preseli Hills in Wales, about 225 km away.",
    "The builders shaped the lintels with mortise-and-tenon and tongue-and-groove joints copied from carpentry, and they curved the lintels slightly to follow the circle. The main axis aligns with sunrise at the summer solstice and sunset at the winter solstice. How the stones were moved is still studied, but sledges, rollers, ropes, and large organized workforces are the likely answer."]],
  ["What prehistory teaches architects",[
    "Prehistoric builders worked out ideas that recur throughout architecture: the post and lintel (two supports and a beam), the corbel (stones stepped inward to close a space), orientation to the sun and seasons, and the use of building as a way to bind a community together through shared labor and ritual.",
    "They also remind us that architecture is not only shelter. A large share of the most ambitious prehistoric building served the dead, the sky, and the sacred. That pattern, in which the most permanent buildings are for gods, rulers, and ancestors rather than everyday homes, continues through most of history."]]
  ],
  terms:[["Megalith","A large stone used, alone or with others, to build a monument."],["Dolmen","A tomb made of upright stones supporting a large flat capstone."],["Trilithon","Two upright stones with a third laid across the top, as at Stonehenge."],["Corbelling","Closing a space by laying courses of stone that each project a little beyond the one below."],["Passage tomb","A burial chamber reached by a long stone passage, covered by an earth or stone mound."]],
  w:"The basic structural moves of all architecture, and its link to ritual, astronomy, and community, appear in these first monuments.",
  src:["Stonehenge","Göbekli Tepe","Çatalhöyük","Newgrange","Megalith"],
  q:[["Göbekli Tepe is significant mainly because it…","Shows monumental building before farming was established","Is the oldest Roman temple","Was the first city with paved streets","Contains the first known arch"],
     ["How did residents of Çatalhöyük usually enter their houses?","Through openings in the roof by ladder","Through arched street doorways","Through underground tunnels","Through courtyard gates"],
     ["What happens at Newgrange around the winter solstice?","Sunlight enters the passage through a roof box and lights the inner chamber","The mound is ritually rebuilt","The stones cast a shadow onto a sundial","Water floods the burial chamber"],
     ["A trilithon is made of…","Two uprights and a lintel","Three stacked capstones","Three standing stones in a row","A ring of three ditches"],
     ["Stonehenge's bluestones came from…","The Preseli Hills in Wales","Brittany in France","Cornwall's coast","The Orkney Islands"],
     ["Corbelling closes a space by…","Stepping each course of stone slightly inward","Using wedge-shaped stones in a true arch","Hanging tension cables","Pouring concrete over a mold"]]},

{ t:"Mesopotamia", s:"Mud brick, ziggurats, and the first cities",
  sec:[
  ["A land without stone",[
    "Mesopotamia, the land 'between the rivers' Tigris and Euphrates in modern Iraq, saw the rise of the first cities after about 4000 BCE. The region had abundant clay and reeds but little stone or good timber. So its architecture was built of mud brick: sun-dried for ordinary walls, kiln-fired and sometimes glazed for important surfaces, laid in bitumen (natural asphalt) mortar where water resistance mattered.",
    "Mud brick shaped everything. Walls had to be thick, and they eroded quickly in rain, so buildings needed constant repair and were often rebuilt on the ruins of their predecessors. Over centuries this produced tells, artificial hills made of layer upon layer of earlier settlement. Mud brick also encouraged the use of buttresses and recessed panels to stiffen long walls, a pattern that gave Mesopotamian temples their rhythmic, ribbed facades."]],
  ["Uruk and the first city",[
    "Uruk, in southern Mesopotamia, may have had some 40,000 people by around 3000 BCE, making it one of the world's first true cities. Its sacred precincts held large temples, including the White Temple raised on a high platform, whitewashed so that it gleamed above the plain. Uruk's builders decorated some walls with cone mosaics: thousands of small clay cones with colored heads pushed into the plaster to form patterns.",
    "The city was surrounded by a wall about 9 km long that later legend credited to the hero-king Gilgamesh. The rise of the city brought new building types: temples run by priestly institutions, storehouses for grain, workshops, and the houses of a stratified society. Writing itself developed partly to manage the goods flowing through these temple economies."]],
  ["The ziggurat",[
    "The ziggurat was a massive stepped tower of mud brick with a temple on top. It was solid, not hollow; its job was to raise the god's shrine toward the sky and make it visible across the flat land. The best preserved is the Ziggurat of Ur, built around 2100 BCE under King Ur-Nammu, with a core of sun-dried brick faced with a thick skin of fired brick set in bitumen.",
    "Three monumental staircases converge on the Ziggurat of Ur's first stage. Its walls slope inward and are subtly curved, refinements that make the mass look stable and alive. The ziggurat of Babylon, Etemenanki, was probably the inspiration for the biblical Tower of Babel. Ziggurats show architecture's early role as a link between the human world and the divine."]],
  ["Palaces of Assyria",[
    "The Assyrian kings of northern Mesopotamia (about 900–612 BCE) built immense palaces at Nimrud, Khorsabad, and Nineveh. Their gateways were guarded by lamassu: colossal stone figures with the body of a bull or lion, wings, and a bearded human head. Inside, the lower walls were lined with carved stone reliefs showing royal hunts, battles, and sieges.",
    "These palaces were architecture as propaganda. Visitors walked past images of conquered cities and executed enemies before reaching the king. Sargon II's citadel at Khorsabad was laid out as a new planned capital, and Sennacherib boasted that his palace at Nineveh was the 'palace without rival'. Many of these reliefs are now in the British Museum and the Louvre."]],
  ["Babylon and the Ishtar Gate",[
    "Under Nebuchadnezzar II (reigned about 605–562 BCE), Babylon was rebuilt as one of the ancient world's greatest cities. Its Processional Way passed through the Ishtar Gate, faced with brilliant blue glazed bricks bearing molded images of dragons (mušḫuššu) and bulls in yellow and brown. A reconstruction using original bricks stands in the Pergamon Museum in Berlin.",
    "Babylon's Hanging Gardens, one of the Seven Wonders of the Ancient World, are described by later Greek writers, but no clear archaeological trace has been found in Babylon. Some scholars have suggested the story may reflect gardens at Nineveh. This uncertainty is a good reminder that famous buildings sometimes survive only in texts."]],
  ["The legacy of Mesopotamia",[
    "Mesopotamian builders gave the world the planned city with walls and gates, the monumental platform, glazed brick, the true arch and vault in brick (used mostly for drains, tombs, and gateways), and architectural decoration in molded and glazed clay. Persian palaces later borrowed many of these ideas.",
    "Above all, Mesopotamia shows how material dictates form. With no stone, its builders produced massive, horizontal, buttressed buildings whose grandeur came from scale and color rather than from carved columns. Architects today use the lesson in reverse: understand the local material first, then design with it."]]
  ],
  terms:[["Ziggurat","A solid stepped tower of mud brick with a shrine at the top, built in Mesopotamia."],["Tell","An artificial mound formed by layers of earlier settlement."],["Lamassu","A colossal winged guardian figure with a human head and an animal body, flanking Assyrian gateways."],["Glazed brick","Brick coated with a fired, glass-like colored surface."],["Bitumen","Natural asphalt, used in Mesopotamia as waterproof mortar."]],
  w:"Mesopotamia invented the city and shows clearly how local materials determine what architecture can be.",
  src:["Ziggurat","Ziggurat of Ur","Ishtar Gate","Uruk","Lamassu"],
  q:[["What was the main building material of Mesopotamia?","Mud brick","Granite","Marble","Timber"],
     ["A ziggurat was…","A solid stepped tower raising a shrine","A hollow pyramid tomb","A columned assembly hall","A fortified harbor"],
     ["The Ziggurat of Ur was built under which king?","Ur-Nammu","Nebuchadnezzar II","Sargon II","Hammurabi"],
     ["The Ishtar Gate is famous for its…","Blue glazed bricks with dragons and bulls","Marble caryatids","Gold-leafed dome","Painted wooden columns"],
     ["Lamassu figures guarded the gateways of…","Assyrian palaces","Egyptian pyramids","Greek temples","Minoan villas"],
     ["Why are the Hanging Gardens of Babylon uncertain?","No clear archaeological trace has been found at Babylon","They were destroyed by Romans and recorded in detail","They were on an island now underwater","Their ruins are in a closed military zone"]]},

{ t:"Ancient Egypt", s:"Pyramids, temples, and building for eternity",
  sec:[
  ["Stone and the afterlife",[
    "Ancient Egypt, unified around 3100 BCE, built in two materials with two purposes. Houses and even palaces were mud brick, because they served this life, which was short. Tombs and temples, meant to last forever, were built of stone: limestone, sandstone, and granite quarried along the Nile and moved by boat.",
    "The Nile shaped the country's architecture. It provided transport for stone, a calendar of floods that freed farm labor for building in some seasons, and an axis that every Egyptian understood: east bank for the living and the rising sun, west bank for the dead and the setting sun. Egyptian architecture is massive, symmetrical, axial, and designed to look permanent."]],
  ["From mastaba to pyramid",[
    "Early kings and nobles were buried under mastabas, flat-topped rectangular tombs with sloping sides. Around 2650 BCE, the architect Imhotep designed for King Djoser at Saqqara a tomb of six mastaba-like stages stacked one on another: the Step Pyramid. It is often called the oldest large-scale cut-stone building in the world. Imhotep was later honored as a god of wisdom and medicine.",
    "Builders under King Sneferu experimented next. The Bent Pyramid at Dahshur changes angle halfway up, probably because the steep lower slope was proving unstable. Sneferu's Red Pyramid, also at Dahshur, used a gentler angle throughout and is considered the first successful smooth-sided pyramid."]],
  ["The Great Pyramid of Giza",[
    "The Great Pyramid, built for King Khufu around 2560 BCE, was originally about 146 meters tall and remained the tallest human-made structure on Earth for nearly 4,000 years. It contains an estimated 2.3 million blocks. Its base is almost perfectly level and its sides are aligned to the cardinal directions with remarkable accuracy. Inside, the Grand Gallery is a tall corbelled passage leading to the King's Chamber, lined with granite and topped by stress-relieving chambers.",
    "Evidence from workers' villages, bakeries, and cemeteries near Giza shows the pyramids were built by organized, paid, and fed crews, not slaves as once popularly believed. Papyri found at Wadi al-Jarf record a team transporting limestone casing blocks by boat. The pyramids show what a centralized state could achieve: planning, logistics, surveying, and the management of thousands of people."]],
  ["Temples of the New Kingdom",[
    "By the New Kingdom (about 1550–1070 BCE), the great temple had a standard sequence along an axis: an avenue of sphinxes, a massive gateway called a pylon, an open courtyard, a hypostyle hall packed with columns, and finally the small, dark sanctuary where the god's statue lived. Floors rose and ceilings dropped as one moved inward, so the spaces grew darker, smaller, and more sacred.",
    "The Temple of Karnak at Thebes (modern Luxor), expanded by pharaohs over some 2,000 years, has a hypostyle hall with 134 columns; the central ones are about 21 meters tall with open papyrus-flower capitals. Higher central columns let light enter through clerestory windows, a technique later used in Roman basilicas and Christian churches."]],
  ["Rock-cut temples and mortuary temples",[
    "Egyptians also carved architecture directly into cliffs. Ramesses II's temple at Abu Simbel has four seated colossi, about 20 meters high, cut from the rock face. Twice a year, sunlight reaches deep into the sanctuary to illuminate statues of gods and the king. In the 1960s, as the Aswan High Dam threatened to flood the site, an international UNESCO campaign cut the temples into blocks and reassembled them on higher ground.",
    "Queen Hatshepsut's mortuary temple at Deir el-Bahari, designed around 1470 BCE and associated with her official Senenmut, rises in broad colonnaded terraces against the cliffs. Its horizontal lines and ramps sit beautifully in the landscape, and its square-section pillars have struck many visitors as surprisingly 'modern'."]],
  ["Egyptian design principles",[
    "Egyptian architecture relied on post-and-lintel construction in stone, which limited spans and produced forests of columns. Its columns imitated plants: papyrus, lotus, and palm. Walls were covered in carved and painted hieroglyphs and scenes, so buildings were also texts. The slight inward slope of walls, called batter, made structures look stable and solid.",
    "Egypt's influence was enormous. Greek builders saw Egyptian stone temples, and some scholars connect early Greek Doric columns to Egyptian fluted columns such as those at Djoser's complex. Much later, Napoleon's expedition (1798–1801) set off waves of 'Egyptian Revival' architecture, and obelisks were shipped to Rome, Paris, London, and New York. The pyramid remains the universal symbol of permanence."]]
  ],
  terms:[["Mastaba","A flat-topped rectangular Egyptian tomb with sloping sides."],["Pylon","The monumental gateway of an Egyptian temple, formed by two tapering towers."],["Hypostyle hall","A hall whose roof is held up by many columns."],["Clerestory","A row of windows set high in a wall above a lower roof, admitting light."],["Batter","The inward slope of a wall's face as it rises."],["Obelisk","A tall, four-sided tapering stone shaft topped by a pyramidal point."]],
  w:"Egypt set the template for monumental, axial, symbolic stone architecture and showed what large-scale state organization could build.",
  src:["Egyptian pyramids","Great Pyramid of Giza","Pyramid of Djoser","Karnak","Abu Simbel","Mortuary Temple of Hatshepsut"],
  q:[["Who designed the Step Pyramid of Djoser?","Imhotep","Senenmut","Khufu","Ramesses II"],
     ["Why does the Bent Pyramid change angle?","Builders likely reduced the slope because the steep lower angle was unstable","It was built by two rival kings","An earthquake bent it","It was designed to point at a star"],
     ["Who built the Giza pyramids, according to modern evidence?","Organized, paid, and fed work crews","Enslaved prisoners of war only","Foreign mercenaries","Priests alone"],
     ["In what order did a New Kingdom temple usually unfold?","Pylon, open court, hypostyle hall, sanctuary","Sanctuary, pylon, court, hall","Hypostyle hall, sanctuary, pylon, court","Court, sanctuary, pylon, hall"],
     ["Why were the Abu Simbel temples moved in the 1960s?","They were threatened by flooding from the Aswan High Dam","They were sliding into the Nile","A new city was built over them","They were sold to a museum"],
     ["A clerestory is…","A row of high windows above a lower roof","A sunken courtyard","A stepped burial mound","A column carved as a woman"]]},

{ t:"Ancient Greece", s:"The temple, the polis, and the pursuit of proportion",
  sec:[
  ["Before the classical temple",[
    "Greek architecture had predecessors. The Minoans of Crete built the sprawling palace of Knossos (flourishing about 1900–1450 BCE) with light wells, colored plaster, and distinctive columns that taper downward. The Mycenaeans on the mainland built fortified citadels with walls of huge stones, later called 'Cyclopean' because Greeks thought only giants could have lifted them, and the Lion Gate at Mycenae with its relief of two lions over the lintel.",
    "The Mycenaeans also built tholos tombs, beehive-shaped chambers made by corbelling. The so-called Treasury of Atreus (about 1250 BCE) had the widest interior span in the world for more than a thousand years, until Roman builders surpassed it with concrete."]],
  ["The Greek temple",[
    "The Greek temple was the house of a god's statue, not a place for congregations; worship and sacrifice took place at an altar outside. At its heart was the cella (naos), a walled room holding the cult statue. A front porch (pronaos) and often a back porch completed the core. In larger temples a colonnade called the peristyle wrapped around all four sides.",
    "Temples began in wood and mud brick and turned to stone during the 7th and 6th centuries BCE. Some features of the stone Doric order, such as triglyphs and the small peg-like guttae beneath them, may preserve memories of earlier timber construction. The temple sat on a stepped platform, the crepidoma, the top step of which is the stylobate on which the columns stand."]],
  ["The Parthenon and optical refinements",[
    "After the Persians sacked Athens in 480 BCE, Pericles led a building program on the Acropolis. The Parthenon (447–432 BCE), designed by Ictinus and Callicrates with sculpture supervised by Phidias, honored Athena. It is a Doric temple of Pentelic marble with 8 columns across the front and 17 along the sides.",
    "Almost no line in the Parthenon is truly straight. The stylobate curves upward toward the middle; the columns swell slightly in the middle (entasis), lean inward, and the corner columns are thicker and set closer. These refinements counteract optical effects that would otherwise make the building look sagging or weak, and they give the temple a subtle sense of life. They also required that nearly every block be cut to its own unique shape."]],
  ["The rest of the Acropolis",[
    "Visitors entered the Acropolis through the Propylaea, a monumental gateway designed by Mnesicles that cleverly handles a steep slope. The small Ionic Temple of Athena Nike stands on a bastion beside it. The Erechtheion, an irregular Ionic temple on uneven ground, housed several cults and has the famous Porch of the Caryatids.",
    "The Acropolis was arranged not by strict symmetry but as a sequence of buildings seen at angles as one climbed and walked. Later architects, including Le Corbusier, studied it for its handling of movement and viewpoint. The Parthenon itself suffered much: it became a church, a mosque, and was blown up in 1687 when a Venetian shell hit Ottoman gunpowder stored inside. Many of its sculptures, the Elgin or Parthenon Marbles, are in the British Museum, and Greece continues to request their return."]],
  ["Civic architecture of the polis",[
    "Greek cities, or poleis, built for civic life as well as for the gods. The agora was the open public square for markets, politics, and conversation, lined by stoas: long roofed colonnades offering shade and space for shops and meetings. The Stoa of Attalos in Athens has been reconstructed and now houses a museum.",
    "Other key building types included the theater, cut into a hillside, with a circular orchestra and tiers of seats; the theater at Epidaurus (4th century BCE) is famous for its acoustics. There were also the bouleuterion (council house), gymnasium, and stadium. Hippodamus of Miletus, in the 5th century BCE, is credited with promoting the grid plan for cities such as Miletus and Piraeus."]],
  ["Hellenistic architecture",[
    "After Alexander the Great (died 323 BCE), Greek culture spread across the eastern Mediterranean and beyond. Hellenistic architecture became larger, more theatrical, and more varied. The Great Altar of Pergamon, now reconstructed in Berlin, wrapped a staircase in a dramatic sculpted frieze of gods battling giants. The Lighthouse (Pharos) of Alexandria, one of the Seven Wonders, may have stood over 100 meters tall.",
    "The Greeks' lasting gift was a way of thinking: architecture as a rational system of parts with fixed proportions, refined by the eye and tied to ideals of harmony. Through Rome and the Renaissance, these ideas shaped Western building for over two thousand years, from the US Capitol to countless banks and university buildings."]]
  ],
  terms:[["Cella","The inner room of a temple that held the cult statue."],["Peristyle","A colonnade surrounding a building or courtyard."],["Entasis","The slight swelling of a column shaft, making it look stronger and more natural."],["Stylobate","The top step of a temple platform on which columns stand."],["Stoa","A long covered colonnade used for public life in Greek cities."],["Tholos","A circular building or beehive-shaped tomb."]],
  w:"Greek architecture created the vocabulary of columns, proportion, and optical refinement that Western architecture has used ever since.",
  src:["Parthenon","Acropolis of Athens","Ancient Greek architecture","Treasury of Atreus","Erechtheion","Stoa"],
  q:[["What was the main function of a Greek temple's cella?","To house the cult statue of the god","To hold the congregation during services","To store city grain","To host the city council"],
     ["Entasis refers to…","A slight swelling of a column's shaft","A sculpted frieze band","A stepped temple platform","A covered colonnade"],
     ["Who were the architects of the Parthenon?","Ictinus and Callicrates","Mnesicles and Phidias","Imhotep and Senenmut","Hippodamus and Vitruvius"],
     ["Why was the Parthenon badly damaged in 1687?","A Venetian shell ignited gunpowder stored inside","An earthquake toppled its columns","Lord Elgin dismantled the roof","A fire spread from a nearby market"],
     ["A Greek stoa was…","A long roofed colonnade for public life","A beehive tomb","A sacred inner room","A theater's stage building"],
     ["Hippodamus of Miletus is associated with…","The grid plan for cities","The Corinthian capital","Optical refinements","The tholos tomb"]]},

{ t:"Roman Engineering", s:"Arches, vaults, domes, and concrete",
  sec:[
  ["Building an empire",[
    "Rome absorbed Greek architecture but transformed it with engineering. Where the Greeks perfected the column and beam, the Romans exploited the arch, the vault, the dome, and above all concrete. These let them enclose huge interior spaces for crowds, a new ambition in architecture. Roman buildings were made to serve the public life of a vast empire: baths, basilicas, amphitheaters, aqueducts, roads, and bridges.",
    "The Romans learned arch construction partly from the Etruscans of central Italy, who used true arches in city gates and drains. The Etruscans also gave Rome a temple type set on a high podium with a deep front porch and steps only at the front, which became the standard Roman temple, as in the well-preserved Maison Carrée at Nîmes in France."]],
  ["The arch and the vault",[
    "A true arch is made of wedge-shaped stones called voussoirs, locked by a central keystone. It converts the downward load into compression that flows around the curve and outward into the supports, which must resist the sideways push called thrust. Arches can span far more than a stone lintel, which is weak in bending.",
    "Extend an arch in depth and you get a barrel vault, like a tunnel. Cross two barrel vaults at right angles and you get a groin vault, which concentrates loads at four corners and lets windows open in the sides. Rotate an arch around its center and you get a dome. These forms, combined, gave Roman builders a flexible kit for vast covered spaces."]],
  ["Roman concrete",[
    "Roman concrete (opus caementicium) mixed lime mortar with rubble aggregate. Its key ingredient around Rome was pozzolana, a volcanic ash from near Pozzuoli on the Bay of Naples, which reacts chemically with lime to form a strong binder that even sets underwater. This allowed harbors and piers to be built in the sea.",
    "Concrete freed the Romans from stone shapes. It could be poured into wooden formwork to make curving walls, vaults, and domes, and it could be built by less-skilled labor. Roman walls usually had a concrete core faced with brick or stone in patterns such as opus reticulatum (a net-like diamond pattern). Research published in 2023 suggests that lime clasts in Roman concrete may give it a self-healing quality, helping explain its durability."]],
  ["The Pantheon",[
    "The Pantheon in Rome, rebuilt under Emperor Hadrian around 113–125 CE, is the greatest monument of Roman concrete. Behind a traditional columned portico lies a vast rotunda roofed by a dome 43.3 meters in diameter, exactly matching the height from the floor to the top of the dome, so that a perfect sphere would fit inside. It remains the largest unreinforced concrete dome in the world.",
    "The dome is lightened in several ways: coffers (recessed panels) reduce weight, the aggregate becomes lighter toward the top (using pumice and tuff instead of heavy stone), and the wall thins upward. At the top, an open oculus 8.2 meters across admits a moving circle of sunlight and rain, drained through holes in the floor. The building survived because it became a church in 609 CE."]],
  ["Aqueducts, roads, and bridges",[
    "Rome's aqueducts carried water over long distances by gravity, on a gentle, carefully surveyed slope. Most of their length ran underground or along the surface; the famous arcades were used only to cross valleys. The Pont du Gard in southern France, part of the aqueduct to Nîmes, stands about 49 meters high on three tiers of arches, built of stone without mortar.",
    "Roman roads, eventually tens of thousands of kilometers long, were built in layers for drainage and durability. Roman bridges, like the Alcántara Bridge in Spain, still carry traffic today. Vitruvius, a Roman architect of the 1st century BCE, wrote that good architecture must have firmitas, utilitas, and venustas: strength, usefulness, and beauty, a formula still quoted today."]],
  ["Vitruvius and the engineering mindset",[
    "Vitruvius's 'Ten Books on Architecture' is the only major architectural treatise surviving from antiquity. It covers materials, temples, the orders, town planning, water, machines, and the training of architects, who he said should know drawing, geometry, history, philosophy, music, medicine, law, and astronomy.",
    "The Roman approach combined standardized construction, logistics, and practical engineering with Greek ornament applied to the surface. Critics sometimes see a split between Roman structure (arches and concrete) and its decoration (columns used for show), but that combination proved enormously influential. Renaissance architects rediscovered Vitruvius in the 15th century, and Leonardo da Vinci's 'Vitruvian Man' illustrates his idea that the human body embodies ideal proportions."]]
  ],
  terms:[["Voussoir","A wedge-shaped stone forming part of an arch."],["Keystone","The central top voussoir that locks an arch."],["Thrust","The outward, sideways push exerted by an arch, vault, or dome."],["Barrel vault","A continuous semicircular vault, like a tunnel."],["Groin vault","A vault formed by two barrel vaults crossing at right angles."],["Pozzolana","Volcanic ash that makes lime mortar hydraulic and strong."],["Oculus","A circular opening, especially at the top of a dome."]],
  w:"Roman engineering made it possible to enclose huge interior spaces, and its arches, vaults, domes, and concrete still underlie modern construction.",
  src:["Ancient Roman architecture","Roman concrete","Pantheon, Rome","Pont du Gard","Vitruvius","Arch"],
  q:[["What does a keystone do?","Locks the voussoirs at the top of an arch","Supports a lintel from below","Anchors a dome's oculus","Forms the base of a column"],
     ["Pozzolana was important because it…","Let lime mortar set strong, even underwater","Made marble easier to carve","Colored bricks blue","Waterproofed timber roofs"],
     ["The Pantheon's dome is about how wide?","43 meters","15 meters","90 meters","26 meters"],
     ["What is the Pantheon's oculus?","An open circular hole at the top of the dome","A hidden staircase","A bronze statue niche","A window in the portico"],
     ["Vitruvius's three qualities of architecture are…","Strength, usefulness, and beauty","Height, width, and depth","Wood, stone, and brick","Order, ornament, and color"],
     ["Why did the Pantheon survive so well?","It was converted into a church in 609 CE","It was buried by volcanic ash","It was rebuilt in the Renaissance","It was sealed and unused for centuries"]]}

]});


/* ---- from arch-04.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 4: Unit 2 Ancient Architecture, chapters 6-10 */
COURSES.architecture.units[1].ch.push(

{ t:"Roman Building Types", s:"Forums, baths, amphitheaters, and houses",
  sec:[
  ["The forum and the basilica",[
    "Every Roman town had a forum, the central open space for markets, law, religion, and politics, descended from the Greek agora but more formally planned, often enclosed by colonnades with a temple at one end. Rome itself accumulated many forums; the largest, the Forum of Trajan (dedicated 112 CE), was designed by Apollodorus of Damascus and included Trajan's Column, whose spiraling relief records the Dacian Wars.",
    "Beside the forum stood the basilica, a large roofed hall for law courts and business. A typical basilica had a tall central nave flanked by lower aisles, with clerestory windows above, and often an apse (a semicircular recess) at one end where magistrates sat. This simple, flexible form later became the model for Christian churches, which is why we still call major churches 'basilicas'."]],
  ["The baths",[
    "Public baths (thermae) were among the most important buildings of Roman life: places to wash, exercise, meet friends, read, and do business. A visitor moved through the frigidarium (cold room), tepidarium (warm room), and caldarium (hot room). Rooms were heated by the hypocaust, a system of raised floors on brick stacks with hot air from furnaces flowing beneath and up through hollow wall tiles.",
    "Imperial baths reached enormous size. The Baths of Caracalla (completed around 216 CE) could serve over a thousand bathers at once, and the Baths of Diocletian were even larger; part of them was converted by Michelangelo into the church of Santa Maria degli Angeli. The great vaulted halls of Roman baths inspired 19th- and 20th-century railway stations, notably the original Pennsylvania Station in New York."]],
  ["Amphitheaters, theaters, and circuses",[
    "The Colosseum (Flavian Amphitheatre), begun under Vespasian around 70 CE and opened in 80 CE under Titus, held perhaps 50,000 spectators for gladiator fights and animal hunts. Its oval plan, 80 numbered entrances, and system of corridors and stairs let crowds enter and leave quickly, a design principle used in modern stadiums. Its outer wall stacks the orders: Tuscan or Doric at the bottom, then Ionic, then Corinthian, with Corinthian pilasters on the top story.",
    "Beneath the arena floor was the hypogeum, a maze of tunnels and lifts for animals and scenery. A huge awning (velarium) operated by sailors could shade spectators. Roman theaters, unlike Greek ones, were often freestanding, built on vaults rather than hillsides, and the Circus Maximus, a long track for chariot races, may have held 150,000 or more people."]],
  ["Houses and apartments",[
    "Wealthy Romans lived in the domus, a house turned inward. From the street one entered the atrium, a hall with an opening in the roof (compluvium) that let rain fall into a pool (impluvium). Beyond lay the tablinum (office) and a peristyle garden surrounded by columns. Walls were painted with frescoes, and floors were covered in mosaics. Pompeii and Herculaneum, buried by Vesuvius in 79 CE, preserve many examples.",
    "Most urban Romans, though, lived in insulae, apartment blocks of several stories with shops on the ground floor. They were often poorly built and prone to fire and collapse, and Augustus is reported to have limited their height to about 70 Roman feet. The insulae of Ostia, Rome's port, show what an ordinary Roman street looked like, with balconies, shopfronts, and stairs."]],
  ["Villas and palaces",[
    "Outside the city, Romans built villas: country estates combining farm and luxury retreat. Hadrian's Villa at Tivoli (about 118–138 CE) was a sprawling complex of pavilions, pools, and gardens that recalled places the emperor had visited across the empire. Its inventive domed and curving spaces show Roman concrete at its most experimental.",
    "Emperors also built palaces on Rome's Palatine Hill, which gives us the word 'palace'. Nero's Golden House (Domus Aurea) included an octagonal domed room and a large artificial lake, later filled in for the Colosseum. At Split in Croatia, Diocletian's fortified palace (about 300 CE) became the core of a medieval town whose people still live within its walls."]],
  ["Triumphal arches and city planning",[
    "Romans celebrated victories with triumphal arches, freestanding gateways covered in reliefs and inscriptions, such as the Arch of Titus (showing spoils from the Temple in Jerusalem) and the Arch of Constantine. These inspired later monuments like the Arc de Triomphe in Paris and Marble Arch in London.",
    "New Roman towns and military camps followed a grid laid out around two main streets: the cardo (north–south) and the decumanus (east–west), meeting near the forum. Many European cities, from Turin to Cologne to Chester, still show this Roman grid. Roman architecture's real legacy is not one monument but a complete toolkit of public building types for urban life."]]
  ],
  terms:[["Basilica","A Roman public hall with a central nave, side aisles, and often an apse; later a church type."],["Apse","A semicircular or polygonal recess, usually at the end of a hall or church."],["Hypocaust","A Roman underfloor heating system using hot air from a furnace."],["Domus","A Roman single-family town house built around an atrium."],["Insula","A Roman apartment block."],["Cardo and decumanus","The two main perpendicular streets of a Roman town grid."]],
  w:"Rome invented or perfected many building types still in use: the civic hall, the stadium, the apartment block, the spa, and the planned grid.",
  src:["Colosseum","Thermae","Roman basilica","Domus","Insula (building)","Hadrian's Villa"],
  q:[["Which Roman building type became the model for Christian churches?","The basilica","The amphitheater","The insula","The hypocaust"],
     ["How did a hypocaust work?","Hot air from a furnace flowed under raised floors and through hollow walls","Water was heated in lead pipes in the ceiling","Charcoal braziers stood in every room","Sunlight was focused through glass"],
     ["About how many spectators could the Colosseum hold?","About 50,000","About 5,000","About 500,000","About 150,000"],
     ["In a Roman domus, the impluvium was…","A pool collecting rainwater under a roof opening","A dining couch","The owner's office","A street-facing shop"],
     ["Roman insulae were…","Apartment blocks, often with shops on the ground floor","Island villas","Underground tunnels","Military watchtowers"],
     ["The cardo and decumanus were…","The two main crossing streets of a Roman grid","Two kinds of concrete","Types of triumphal arch","Rooms in the baths"]]},

{ t:"Persia and the Ancient Near East", s:"Persepolis, Petra, and empires of stone",
  sec:[
  ["The Achaemenid Empire",[
    "The Achaemenid Persian Empire (about 550–330 BCE), founded by Cyrus the Great, stretched from Egypt and Anatolia to the Indus. Its kings built palaces that drew craftsmen and ideas from every province: Mesopotamian platforms and glazed brick, Egyptian door frames, Ionian Greek stone carving. The result was a deliberately international imperial style.",
    "Cyrus's tomb at Pasargadae is a small gabled stone chamber on a stepped base, simple and dignified. Later kings were buried in rock-cut tombs at Naqsh-e Rustam, whose facades take the shape of a cross carved into the cliff, showing a palace front with columns."]],
  ["Persepolis",[
    "Persepolis, begun by Darius I around 518 BCE and continued by Xerxes and his successors, was a ceremonial capital on a vast stone terrace. Visitors climbed a broad double staircase, shallow enough, it is often said, to be climbed on horseback, and passed through the Gate of All Nations guarded by lamassu-like bulls.",
    "The Apadana, the great audience hall, had a roof carried by 36 slender stone columns about 20 meters high, with capitals of paired bulls or other animals back-to-back, supporting timber beams. Its staircases carry reliefs of delegations from across the empire bringing gifts to the king. Alexander the Great burned Persepolis in 330 BCE; its ruins, now a UNESCO World Heritage Site, remain among the most impressive of the ancient world."]],
  ["The Parthians and the iwan",[
    "Later Iranian dynasties made a lasting contribution: the iwan, a large vaulted hall walled on three sides and fully open on the fourth, usually facing a courtyard. The Parthians (about 247 BCE–224 CE) developed it, and the Sasanians (224–651 CE) made it monumental.",
    "The Taq Kasra at Ctesiphon, near Baghdad, a Sasanian palace usually dated to the 6th century CE, has a vast brick barrel-vault often cited as among the largest single-span unreinforced brick vaults ever built. Its form, built without centering using inclined courses of brick, had huge influence on Islamic architecture, where the iwan became a central feature of mosques, madrasas, and caravanserais."]],
  ["Petra and rock-cut cities",[
    "The Nabataeans, an Arab people who grew rich from the incense and spice trade, carved their capital Petra (in modern Jordan) out of rose-red sandstone cliffs from roughly the 1st century BCE. Its most famous facade, Al-Khazneh ('the Treasury', actually probably a royal tomb), is reached through a narrow canyon called the Siq and combines Hellenistic columns, pediments, and a round tholos in a two-story composition.",
    "Petra also had a theater, temples, and an extensive water system of channels and cisterns that allowed a large population in the desert. Its architecture shows how ideas traveled along trade routes: Greek and Roman forms reworked by local builders in a completely different material and setting."]],
  ["Anatolia, the Hittites, and the Levant",[
    "The Hittites of central Anatolia (about 1650–1180 BCE) built their capital Hattusa with massive stone walls and gates carved with lions and sphinxes. In the Levant, the Phoenicians were famed builders and craftsmen; according to the Bible, King Hiram of Tyre sent cedar and craftsmen for Solomon's Temple in Jerusalem.",
    "Solomon's Temple and the Second Temple, rebuilt grandly by Herod the Great from about 20 BCE, were central to Jewish worship. Herod's enormous platform survives, including the Western Wall, a retaining wall of huge cut stones that is today Judaism's holiest prayer site. Herod was a prolific builder, also responsible for the harbor of Caesarea, built with Roman hydraulic concrete in the open sea."]],
  ["Why the Near East matters",[
    "The ancient Near East connected Egypt, Mesopotamia, Greece, and India. Ideas passed in every direction: the glazed brick of Babylon, the columned hall of Persia, the vault and iwan of Parthia and Sasanian Iran. Many forms later associated with Islamic architecture, including the dome on a square room and the courtyard with iwans, have roots here.",
    "For an architect, the region illustrates how empires used architecture to display power and unity, by gathering craftspeople and motifs from many lands into a single grand statement. It also shows how architecture travels with trade, and how a borrowed form changes when it is built in new materials by new hands."]]
  ],
  terms:[["Apadana","A large columned audience hall in Achaemenid Persian palaces."],["Iwan","A vaulted hall open on one side, usually facing a courtyard."],["Rock-cut architecture","Buildings or facades carved directly from natural rock."],["Retaining wall","A wall that holds back earth or supports a raised platform."]],
  w:"The Near East bridged the ancient world and supplied forms, like the iwan and the columned hall, that later shaped Islamic and world architecture.",
  src:["Persepolis","Petra","Taq Kasra","Iwan","Achaemenid architecture","Western Wall"],
  q:[["Who began building Persepolis?","Darius I","Cyrus the Great","Alexander the Great","Nebuchadnezzar II"],
     ["What was the Apadana?","A great columned audience hall","A rock-cut tomb","A defensive gate","A water reservoir"],
     ["An iwan is…","A vaulted hall open on one side toward a courtyard","A stepped tower","A type of column capital","A circular tomb"],
     ["Petra was carved by which people?","The Nabataeans","The Hittites","The Phoenicians","The Sasanians"],
     ["The Western Wall in Jerusalem is part of…","The retaining wall of Herod's Temple platform","Solomon's palace","A Roman fortress","A Crusader castle"],
     ["Persepolis was burned by…","Alexander the Great","The Romans","The Mongols","An earthquake-caused fire"]]},

{ t:"Ancient India", s:"Indus cities, stupas, rock-cut halls, and temples",
  sec:[
  ["The Indus Valley cities",[
    "The Indus Valley (Harappan) Civilization flourished from roughly 2600 to 1900 BCE in what is now Pakistan and northwest India. Its cities, including Mohenjo-daro and Harappa, were remarkably planned: streets ran on a rough grid, houses were built of standardized fired bricks, and many had private bathing areas and toilets connected to covered street drains.",
    "Mohenjo-daro's Great Bath, a watertight brick pool sealed with bitumen and surrounded by rooms, may have been used for ritual bathing. Strikingly, archaeologists have found no grand palaces or temples comparable to those of Egypt or Mesopotamia. The emphasis on drainage, water, and orderly housing makes these some of the most sophisticated early examples of urban infrastructure."]],
  ["The stupa",[
    "With the spread of Buddhism, especially under the Mauryan emperor Ashoka (reigned about 268–232 BCE), India developed the stupa: a solid hemispherical mound containing relics of the Buddha or a revered teacher. Pilgrims walk around it clockwise along a path called the pradakshina, a form of meditation in motion.",
    "The Great Stupa at Sanchi, begun under Ashoka and enlarged later, is surrounded by a stone railing with four gateways (toranas) carved with scenes from the Buddha's lives. Interestingly, the stone toranas imitate wooden construction, with beams and joints, revealing an earlier timber tradition. The stupa's form traveled across Asia, becoming the chorten of Tibet, the dagoba of Sri Lanka, and, in East Asia, inspiring the pagoda."]],
  ["Rock-cut chaityas and viharas",[
    "Indian builders carved entire halls into cliffs, working from the top down. At Karla and Ajanta, Buddhist monks carved chaityas (prayer halls) shaped like basilicas, with a nave, aisles, rows of columns, a rock-cut stupa at the apsidal end, and a horseshoe-shaped window. The ribbed ceilings again imitate timber roofs.",
    "Viharas were monasteries carved around a central hall with small cells for monks. The Ajanta Caves (about 2nd century BCE to 5th century CE) are famous for their paintings, and the Ellora Caves include Buddhist, Hindu, and Jain monuments side by side. Ellora's Kailasa Temple (8th century CE) is a whole multistory temple carved downward from a single mass of rock, one of the most ambitious feats of sculpture-architecture anywhere."]],
  ["The Hindu temple",[
    "The structural Hindu temple developed from about the 5th century CE. Its core is the garbhagriha ('womb chamber'), a small, dark sanctum holding the deity's image, above which rises a tower representing the cosmic mountain Meru. Worshippers approach through one or more halls (mandapas). Temple plans were governed by sacred texts on architecture and geometry, the vastu shastras, which often use a square grid (mandala) as a diagram of the cosmos.",
    "Two main regional styles emerged. The northern Nagara style has a curving, beehive-like tower called a shikhara, as at the Kandariya Mahadeva Temple at Khajuraho (about 1030 CE), where smaller tower forms cluster up the main one like rising peaks. The southern Dravida style has a stepped, pyramidal tower called a vimana and, later, enormous gateway towers called gopurams."]],
  ["Great southern temples",[
    "The Brihadisvara Temple at Thanjavur, completed around 1010 CE under the Chola king Rajaraja I, has a vimana about 66 meters tall topped by a huge stone capstone. It is a UNESCO site and one of India's largest temples. Later southern temple cities, such as the Meenakshi Temple at Madurai, grew outward in concentric enclosures marked by towering, brightly painted gopurams covered with sculpted figures.",
    "Jain temples at Mount Abu (Dilwara temples, 11th–13th centuries) are famed for intricately carved white marble ceilings. Across all these traditions, the Indian temple is less an enclosed space than a sculpted mass, a mountain of carving meant to be circled, approached, and contemplated."]],
  ["Lessons from Indian architecture",[
    "Indian architecture teaches that buildings can be cosmological diagrams. The mandala plan, the central sacred point, the vertical axis of the tower, and the ritual path around the shrine all express a view of the universe. Movement and approach matter more than an interior volume.",
    "It also shows the depth of a tradition guided by written canons, passed down through guilds of builders called sthapatis, some of whose descendants still practice. Hindu and Buddhist forms spread to Southeast Asia, shaping Angkor in Cambodia and Borobudur in Java, which later chapters will explore."]]
  ],
  terms:[["Stupa","A Buddhist hemispherical mound containing relics, circled by pilgrims."],["Torana","A ceremonial gateway, especially to a stupa enclosure."],["Chaitya","A Buddhist prayer hall, often rock-cut, containing a stupa."],["Garbhagriha","The inner sanctum of a Hindu temple housing the deity."],["Shikhara","The curving tower of a northern (Nagara) Hindu temple."],["Gopuram","A monumental gateway tower of a southern Indian temple."],["Vastu shastra","Traditional Indian texts on architecture, planning, and sacred geometry."]],
  w:"Indian architecture shows buildings as diagrams of the cosmos and gave Asia the stupa and the temple tower.",
  src:["Indus Valley Civilisation","Mohenjo-daro","Sanchi","Ellora Caves","Hindu temple architecture","Brihadisvara Temple, Thanjavur"],
  q:[["What feature made Indus Valley cities stand out?","Planned streets with covered drains and standardized bricks","Giant pyramids","Domed basilicas","Wooden skyscrapers"],
     ["A stupa is…","A solid mound holding relics, circled by pilgrims","A columned prayer hall","A tower gateway","A monastery cell"],
     ["The Kailasa Temple at Ellora is remarkable because it…","Was carved downward from a single mass of rock","Is made entirely of glass","Was moved from another site","Floats on a lake"],
     ["The garbhagriha of a Hindu temple is…","The inner sanctum holding the deity's image","The main gateway","The outer pilgrimage path","The temple kitchen"],
     ["Which tower type belongs to northern (Nagara) temples?","Shikhara","Gopuram","Pagoda","Minaret"],
     ["The Brihadisvara Temple was built under which dynasty?","Chola","Maurya","Mughal","Gupta"]]},

{ t:"Ancient China", s:"Timber frames, walls, and the ordered courtyard",
  sec:[
  ["A timber tradition",[
    "Chinese architecture developed one of the world's most consistent traditions, based for over two thousand years on the timber frame. A grid of wooden columns rests on stone bases and supports beams and a heavy, tiled, upward-curving roof. The walls carry no roof load; they are screens, so they can be opened or closed freely.",
    "Because wood burns and decays, few early buildings survive. The oldest standing timber buildings in China date from the Tang dynasty, such as the main hall of Nanchan Temple (782 CE) and of Foguang Temple (857 CE) on Mount Wutai. Much knowledge of earlier architecture comes from tomb models, paintings, and excavated foundations."]],
  ["Dougong brackets and roofs",[
    "The dougong is the signature Chinese structural device: interlocking wooden brackets stacked on top of columns that spread the roof's weight and let the eaves project far beyond the walls, protecting them from rain. Assembled without nails, dougong also give the frame some flexibility in earthquakes.",
    "Roofs carried strong meaning. The hip roof and the hip-and-gable roof, with their upward-curving ridges and eaves, came in a hierarchy of types, and the most prestigious were reserved for imperial and religious buildings. Colors were also regulated: yellow glazed tiles were for the emperor. The Song-dynasty building manual Yingzao Fashi (1103), written by Li Jie, standardized proportions using a modular unit based on bracket timber sizes."]],
  ["The courtyard and the axis",[
    "Chinese buildings were rarely isolated objects. They were arranged as groups around courtyards along a north–south axis, with the main hall facing south. This applied to everything from family homes to temples to palaces. The Beijing siheyuan, a house with four buildings around a courtyard, expressed family hierarchy: elders occupied the north, the most honored position.",
    "Planning followed principles of order, hierarchy, and harmony with nature, influenced by Confucian ideas of social order and by fengshui, the practice of siting buildings according to landform, water, and orientation. A walled compound turned inward, offering privacy and a protected microclimate."]],
  ["Cities and the Great Wall",[
    "Chinese capitals were planned as walled grids centered on the palace. Chang'an (modern Xi'an), the Tang capital, was laid out as a vast grid of walled wards around a central avenue, and around the 8th century it may have had some one million inhabitants. Its plan influenced Japanese capitals such as Heijō-kyō (Nara) and Heian-kyō (Kyoto).",
    "Long defensive walls were built across northern China from the 7th century BCE onward. The first emperor, Qin Shi Huang, joined many of them after unifying China in 221 BCE, using rammed earth. The famous brick and stone sections seen today, such as Badaling and Mutianyu near Beijing, were built mostly under the Ming dynasty (1368–1644). Despite popular belief, the Great Wall is not visible to the naked eye from the Moon."]],
  ["Pagodas and tombs",[
    "Buddhism reached China in the first centuries CE, and the Indian stupa was transformed into the multistory pagoda, built in timber, brick, or stone. The Yingxian Wooden Pagoda in Shanxi (1056), about 67 meters tall, is the oldest and tallest fully wooden pagoda still standing; its layered brackets have helped it survive earthquakes for nearly a thousand years. The Giant Wild Goose Pagoda in Xi'an, a brick tower, was first built in 652.",
    "Imperial tombs reflected the belief that the afterlife mirrored this life. The tomb complex of Qin Shi Huang near Xi'an, with its army of thousands of life-size terracotta warriors, was discovered in 1974. Later imperial tombs, such as the Ming Tombs near Beijing, were approached by a 'spirit way' lined with stone animals and officials."]],
  ["The Forbidden City",[
    "The Forbidden City in Beijing, built from 1406 to 1420 under the Ming Yongle Emperor, was the imperial palace for nearly 500 years. It is the summation of Chinese architectural ideas: a vast walled rectangle of about 72 hectares, with courtyards and halls arranged along a central north–south axis, roofs of yellow glazed tiles, and a strict hierarchy of building sizes and roof types.",
    "The Hall of Supreme Harmony, raised on a three-tiered marble terrace, was the largest and most important hall, used for coronations and major ceremonies. The palace is now the Palace Museum. Nearby, the Temple of Heaven (1420), with its round, triple-roofed Hall of Prayer for Good Harvests on circular terraces, expresses the ancient Chinese idea that heaven is round and the earth is square."]]
  ],
  terms:[["Dougong","Interlocking wooden brackets that transfer roof loads to columns in Chinese architecture."],["Siheyuan","A traditional Chinese house of four buildings around a courtyard."],["Pagoda","A multistory tower, derived from the stupa, found across East Asia."],["Rammed earth","Damp earth compacted in layers inside formwork to build walls."],["Fengshui","Chinese practice of siting and orienting buildings in harmony with landscape and energy."]],
  w:"China's timber-frame and courtyard tradition shows how a consistent system, refined over millennia, can produce an entire architectural civilization.",
  src:["Chinese architecture","Dougong","Forbidden City","Great Wall of China","Yingzao Fashi","Siheyuan"],
  q:[["In traditional Chinese timber buildings, what carries the roof?","A grid of wooden columns and brackets","The outer walls","Stone vaults","Steel trusses"],
     ["What do dougong brackets do?","Spread roof loads and allow deep overhanging eaves","Anchor walls to the ground","Collect rainwater","Decorate floors"],
     ["What was the Yingzao Fashi?","A Song-dynasty building manual standardizing construction","A Tang palace","A book of poems about pagodas","A Ming map of the Great Wall"],
     ["Most of the brick and stone Great Wall seen by tourists today was built under…","The Ming dynasty","The Qin dynasty","The Han dynasty","The Tang dynasty"],
     ["Which direction does the main hall of a traditional Chinese compound usually face?","South","North","East","West"],
     ["The Temple of Heaven's round hall reflects the idea that…","Heaven is round and earth is square","The emperor is the sun","Water flows in circles","All roofs must be yellow"]]},

{ t:"Ancient Americas", s:"Pyramids, plazas, and mountain cities",
  sec:[
  ["Independent invention",[
    "The civilizations of the Americas developed monumental architecture entirely independently of Eurasia. They did so without iron tools, draft animals, or the wheel used for transport, which makes their achievements all the more remarkable. Builders relied on stone tools, human labor, and sophisticated organization.",
    "Common themes include stepped platform pyramids topped by temples, large plazas for public ritual, careful astronomical alignments, and cities planned around sacred axes. The earliest monumental site in the Americas is often said to be Caral in Peru's Supe Valley, with platform mounds and sunken circular plazas dating to about 2600 BCE, roughly the same time as the Egyptian pyramids."]],
  ["The Olmec and Teotihuacan",[
    "The Olmec of Mexico's Gulf Coast (about 1200–400 BCE) built earthen platform mounds and carved colossal stone heads. Later, Teotihuacan in central Mexico grew into one of the largest cities in the world in its time, with perhaps 100,000 or more people around 500 CE. It was laid out along a great axis, the Avenue of the Dead, with the Pyramid of the Sun and the Pyramid of the Moon at key points.",
    "Teotihuacan's builders used the talud-tablero style: a sloping wall (talud) topped by a vertical rectangular panel (tablero), repeated in stepped layers. The city's orientation, about 15.5 degrees east of north, appears to relate to astronomical events. It was abandoned around 550–650 CE, and when the Aztecs found it centuries later they gave it its name, meaning roughly 'place where the gods were created'."]],
  ["The Maya",[
    "Maya cities, flourishing in the Classic period (about 250–900 CE) across southern Mexico, Guatemala, Belize, and Honduras, included Tikal, Palenque, Copán, and Calakmul. Their steep stepped pyramids carried small temples crowned by tall roof combs, decorative stone crests. Palaces, ball courts, and plazas filled the ceremonial centers, often linked by raised causeways called sacbeob.",
    "Maya builders used the corbel vault, which produced narrow, high rooms. Inscriptions carved on stelae and stairways record dynasties and dates in the Long Count calendar; the Hieroglyphic Stairway at Copán is the longest known Maya text. Since the 2010s, lidar surveys have revealed thousands of previously unknown Maya structures under the Guatemalan rainforest, showing far denser settlement than once thought."]],
  ["Chichen Itza and the Aztecs",[
    "At Chichen Itza in Yucatán, the pyramid known as El Castillo (Temple of Kukulcán) has four stairways of 91 steps each, which with the top platform total 365. Around the spring and autumn equinoxes, the afternoon sun casts triangular shadows on the north staircase's edge that look like a serpent descending to a carved serpent head at the base.",
    "The Aztec capital Tenochtitlan, founded in 1325 on an island in Lake Texcoco, was linked to the shore by causeways and had canals, aqueducts, and chinampas (raised farm plots). Its Templo Mayor was a double pyramid with twin shrines to Tlaloc and Huitzilopochtli, rebuilt in several enlarged phases. Spanish conquerors destroyed the city after 1521, and Mexico City was built on top; the Templo Mayor's remains were excavated from 1978."]],
  ["The Andes and the Inca",[
    "In the Andes, the Inca Empire (15th–early 16th century) built a road network of about 40,000 km with suspension bridges of woven grass. Inca masons were famed for ashlar walls of stones cut to fit so tightly, without mortar, that a knife blade cannot be inserted. Their trapezoidal doorways and windows, and walls leaning slightly inward, help resist earthquakes.",
    "Machu Picchu, built around the 1450s as an estate for the ruler Pachacuti, sits on a mountain ridge above the Urubamba River, with agricultural terraces, temples, and residences. The terraces also manage drainage on steep slopes. In Cusco, the Inca capital, the Spanish built churches on Inca foundations; during earthquakes the colonial upper structures have sometimes fallen while the Inca walls below stood."]],
  ["North America",[
    "In North America, the Mississippian culture built Cahokia near modern St. Louis, which around 1100 CE may have had 10,000–20,000 people. Its central earthen platform, Monks Mound, is the largest prehistoric earthwork in the Americas. Ancestral Puebloans in the American Southwest built multistory stone and adobe 'great houses' at Chaco Canyon (about 850–1150 CE), such as Pueblo Bonito with hundreds of rooms, and cliff dwellings like those at Mesa Verde.",
    "Across the Americas, architecture expressed relationships to land, sky, and community. Plazas, axes, and alignments organized public ritual, and terraces and earthworks reshaped whole landscapes. These achievements are a powerful reminder that many cultures independently arrived at monumental architecture."]]
  ],
  terms:[["Talud-tablero","A Mesoamerican architectural profile of a sloping wall topped by a vertical panel."],["Roof comb","A decorative stone crest on top of a Maya temple."],["Corbel vault","A false arch made by stepping stones inward until they meet."],["Ashlar","Finely cut, squared stone masonry with tight joints."],["Platform mound","An earthen or stone mound with a flat top, supporting buildings."]],
  w:"The Americas developed sophisticated cities, astronomy-based planning, and earthquake-resistant masonry entirely on their own.",
  src:["Teotihuacan","Maya architecture","Chichen Itza","Machu Picchu","Inca architecture","Cahokia"],
  q:[["Which site is often called the oldest monumental center in the Americas?","Caral in Peru","Tikal in Guatemala","Cahokia in Illinois","Machu Picchu in Peru"],
     ["What is talud-tablero?","A sloping wall topped by a vertical panel","A Maya roof comb","An Inca road","A type of Aztec canoe"],
     ["What has lidar revealed in Guatemala?","Thousands of previously unknown Maya structures","A buried Aztec capital","Inca gold mines","Olmec sea walls"],
     ["What happens at El Castillo near the equinoxes?","Shadows create the image of a descending serpent","The pyramid floods","The temple doors align with the moon","The steps glow at night"],
     ["Inca walls are famous for…","Stones fitted so tightly no mortar is needed","Using steel reinforcement","Painted glazed tiles","Wooden frames"],
     ["Monks Mound is part of which site?","Cahokia","Chaco Canyon","Teotihuacan","Tenochtitlan"]]}

);


/* ---- from arch-05.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 5: Unit 3 Medieval and Islamic, chapters 1-5 */
COURSES.architecture.units.push({ t:"Medieval and Islamic Architecture", ch:[

{ t:"Early Christian and Byzantine", s:"Basilicas, domes, and Hagia Sophia",
  sec:[
  ["From house church to basilica",[
    "Early Christians met in private houses; the house church at Dura-Europos in Syria (about 230s CE) is the oldest identified. After Emperor Constantine legalized Christianity in 313, the church needed large public buildings. Builders adopted the Roman basilica rather than the temple, because a temple was a house for a god's statue while a church had to hold a congregation.",
    "Old St. Peter's in Rome, begun around 319–322 over the supposed tomb of St. Peter, had a long nave, double side aisles, a transept (a cross arm near the end), and an apse. Its east–west orientation and longitudinal plan, leading the eye toward the altar, became the standard for Western churches. Santa Sabina in Rome (5th century) still conveys the bright, columned interior of an early basilica."]],
  ["Centrally planned buildings",[
    "Alongside the long basilica, Christians built centrally planned structures, round or polygonal, for baptisteries and martyria (shrines over the graves or sites of martyrs). Santa Costanza in Rome, built as a mausoleum for Constantine's daughter, has a central domed space ringed by an ambulatory (a walkway) with mosaic-covered vaults.",
    "The Church of the Holy Sepulchre in Jerusalem combined both types: a basilica and a rotunda over the tomb of Christ. The tension between the long axis, good for processions and congregations, and the central plan, symbolizing perfection and heaven, runs through the whole history of church architecture."]],
  ["Hagia Sophia",[
    "When the capital moved to Constantinople, the Eastern (Byzantine) Empire developed its own architecture. Its supreme achievement is Hagia Sophia ('Holy Wisdom'), built in under six years (532–537) by Emperor Justinian, designed by Anthemius of Tralles and Isidore of Miletus, who were mathematicians and engineers as much as architects. It fused the basilica and central plan: a great dome about 31 meters across rises over a square, extended east and west by half-domes to create a vast longitudinal space.",
    "The dome sits on four pendentives, curved triangular surfaces that make the transition from a square base to a circular dome, a technique Hagia Sophia used at unprecedented scale. A ring of 40 windows at the dome's base makes it seem to float on light; the historian Procopius said it appeared 'suspended from heaven by a golden chain'. The first dome collapsed after an earthquake in 558 and was rebuilt higher. The building became a mosque in 1453, a museum in 1934, and a mosque again in 2020."]],
  ["Mosaics and Ravenna",[
    "Byzantine interiors were clad in marble and glittering mosaics of glass and gold tesserae, which made walls dissolve into shimmering light. The idea was to evoke heaven, not to show physical structure. Exteriors were often plain brick by comparison.",
    "Ravenna in Italy, a Byzantine outpost, preserves some of the finest mosaics, notably in San Vitale (completed 547), an octagonal church with images of Justinian and Empress Theodora, and in the Mausoleum of Galla Placidia, whose blue ceiling is scattered with gold stars. Ravenna's monuments are a UNESCO World Heritage Site."]],
  ["The cross-in-square and Orthodox churches",[
    "After the 9th century, the typical Byzantine church became the cross-in-square: a square plan with a central dome over the crossing of a Greek cross (four equal arms), smaller domes or vaults at the corners, and apses to the east. These churches were smaller, intimate, and vertical, with a hierarchy of images: Christ Pantokrator in the dome, the Virgin in the apse, saints and feasts below.",
    "This model spread with Orthodox Christianity to the Balkans, Armenia, Georgia, and Russia. St. Mark's Basilica in Venice (rebuilt from 1063) has five domes on a Greek-cross plan, modeled on a lost church in Constantinople. In Russia, domes took on the onion shape, as at St. Basil's Cathedral in Moscow (1555–1561), with its colorful cluster of chapels."]],
  ["The iconostasis and lasting influence",[
    "In Orthodox churches, the sanctuary is separated from the nave by an iconostasis, a screen of icons with doors through which the clergy pass. Architecture, imagery, and liturgy form a single designed experience of incense, chant, candlelight, and gold.",
    "Byzantine architecture influenced early Islamic buildings such as the Dome of the Rock and, through Hagia Sophia, the great Ottoman mosques. Its mastery of the dome on pendentives became a key tool for Renaissance architects. And its central lesson, that light and surface can transform the experience of space, still guides designers of sacred buildings."]]
  ],
  terms:[["Transept","The cross arm of a church plan, crossing the nave near the altar end."],["Ambulatory","A walkway around a central space or behind an altar."],["Pendentive","A curved triangle of vaulting that transitions from a square base to a circular dome."],["Tesserae","Small pieces of glass, stone, or tile used in mosaics."],["Cross-in-square","A Byzantine church plan with a central dome over a Greek cross inside a square."],["Iconostasis","A screen of icons separating the sanctuary from the nave in Orthodox churches."]],
  w:"Early Christian and Byzantine builders set the plans of Western and Eastern churches and mastered the dome on pendentives.",
  src:["Hagia Sophia","Byzantine architecture","Old St. Peter's Basilica","Pendentive","Basilica of San Vitale","Early Christian art and architecture"],
  q:[["Why did early Christians adopt the Roman basilica rather than the temple?","They needed a hall for a congregation, not a house for a statue","Temples were too expensive","Basilicas faced Jerusalem","The emperor banned temples"],
     ["Who designed Hagia Sophia?","Anthemius of Tralles and Isidore of Miletus","Apollodorus of Damascus","Justinian and Theodora","Sinan"],
     ["A pendentive is…","A curved triangle connecting a square base to a dome","A hanging lamp","A type of mosaic","A column capital"],
     ["What makes Hagia Sophia's dome seem to float?","A ring of 40 windows at its base","Hidden steel cables","A gold-covered exterior","Its transparent glass"],
     ["Ravenna is famous for…","Byzantine mosaics such as those in San Vitale","Gothic stained glass","Onion domes","Rock-cut churches"],
     ["An iconostasis is…","A screen of icons separating sanctuary and nave","A bell tower","A baptismal pool","A round domed tomb"]]},

{ t:"Islamic Architecture I", s:"The mosque and its elements",
  sec:[
  ["The first mosques",[
    "Islam began in Arabia in the 7th century CE. The Prophet Muhammad's house in Medina, a courtyard with a shaded area of palm-trunk columns and palm-frond roofing, served as the first gathering place for prayer. Its simple form, an enclosure with a covered prayer hall, shaped mosque design for centuries.",
    "A mosque (masjid, 'place of prostration') needs no altar or image. What matters is the qibla, the direction of Mecca, toward which Muslims pray. Mosques are therefore wide rather than deep, so that the rows of worshippers stretch side to side facing the qibla wall."]],
  ["Elements of the mosque",[
    "The qibla wall contains the mihrab, a niche indicating the direction of prayer, often the most richly decorated part of the building. Beside it stands the minbar, a stepped pulpit for the Friday sermon. Many mosques have a courtyard (sahn) with a fountain or basin for ablutions (washing before prayer).",
    "The minaret, a tower from which the call to prayer (adhan) was given, became a strong visual symbol of the mosque, though early mosques had none. Minaret shapes vary by region: square in North Africa and Spain, slender cylinders in Ottoman Turkey, spiraling at Samarra in Iraq. Today the call is often amplified by loudspeakers."]],
  ["The Dome of the Rock and the Umayyads",[
    "The Dome of the Rock in Jerusalem, completed in 691–692 under the Umayyad caliph Abd al-Malik, is the oldest major surviving Islamic monument. It is not a mosque but a shrine, built over a rock sacred to Jews, Christians, and Muslims. Its octagonal plan with a central dome and double ambulatory draws on Byzantine martyria, but its inscriptions and decoration announce a new faith. The exterior tiles mostly date from later Ottoman restorations.",
    "The Great Mosque of Damascus (705–715) converted a Roman temple precinct and church site into a vast courtyard mosque with a prayer hall of three aisles parallel to the qibla. Its mosaics of trees, rivers, and buildings, without human figures, are among the finest of the period. Its plan became a model for later mosques."]],
  ["The hypostyle mosque",[
    "Many early mosques were hypostyle: a large hall supported by a forest of columns, expandable as communities grew. The Great Mosque of Kairouan in Tunisia (rebuilt in the 9th century) has a massive square minaret and a prayer hall of reused Roman columns. The Great Mosque of Samarra in Iraq (848–852) was for a time the largest mosque in the world, with a spiral minaret, the Malwiya, about 52 meters tall.",
    "The Great Mosque of Córdoba in Spain, begun in 784–786 and enlarged several times, is the most famous hypostyle mosque. Its hall of over 850 columns carries striking double-tiered arches of alternating red brick and white stone voussoirs, creating a seemingly endless repeating space. After the Christian conquest of 1236, a cathedral was built in its center in the 16th century."]],
  ["Ornament: geometry, plants, and writing",[
    "Islamic religious architecture generally avoids images of humans and animals. Instead, it developed three great decorative systems: geometric patterns (interlocking stars and polygons generated from circles and grids), arabesque (stylized, infinitely continuing plant scrolls), and calligraphy (Qur'anic verses and other texts in scripts such as angular Kufic and flowing Thuluth).",
    "These patterns suggest infinity and unity, central ideas in Islamic thought. Craftsmen worked in carved stucco, cut tile mosaic, glazed tiles, carved wood, and stone. Some medieval geometric designs, such as tilings at the Darb-i Imam shrine in Isfahan (1453), show patterns that have been compared to the mathematics of quasicrystals, discovered by Western science only in the 1970s–80s."]],
  ["Muqarnas and the arch",[
    "Muqarnas is a uniquely Islamic form: a honeycomb-like vaulting made of many small niche-shaped units stacked in tiers, used to transition between surfaces, such as from a square room to a dome, or to fill the head of a portal. It turns structure into something like a stalactite cave or a cascade of light.",
    "Islamic builders also used many arch forms: the horseshoe arch (common in Spain and North Africa), the pointed arch (which Islamic builders used before it appeared in Gothic Europe), the multifoil (many-lobed) arch, and the ogee arch with its S-shaped curves. The pointed arch likely reached Europe in part through contact with Islamic lands, including Sicily and Spain."]]
  ],
  terms:[["Qibla","The direction of Mecca, toward which Muslims pray."],["Mihrab","A niche in the qibla wall marking the direction of prayer."],["Minbar","A stepped pulpit in a mosque for the Friday sermon."],["Minaret","A tower associated with a mosque, used for the call to prayer."],["Arabesque","A decorative pattern of stylized, continuous plant scrolls."],["Muqarnas","Honeycomb-like vaulting of small stacked niche units."],["Hypostyle mosque","A mosque with a prayer hall supported by many columns."]],
  w:"Islamic architecture created the mosque and a rich decorative language of geometry, plants, and calligraphy that shaped buildings from Spain to India.",
  src:["Islamic architecture","Mosque","Dome of the Rock","Mosque–Cathedral of Córdoba","Muqarnas","Mihrab"],
  q:[["What does the mihrab indicate?","The direction of Mecca for prayer","The location of the imam's house","The tomb of the founder","The entrance for women"],
     ["Why are mosques usually wider than they are deep?","So rows of worshippers can face the qibla side by side","To fit city blocks","Because domes require it","To keep the minaret centered"],
     ["The Dome of the Rock is…","A shrine completed around 691, not a mosque","The first Ottoman mosque","A Christian cathedral","A palace of the Abbasids"],
     ["The Great Mosque of Córdoba is famous for…","A forest of columns with red-and-white double arches","A spiral minaret","Eight minarets","Gold onion domes"],
     ["Muqarnas is…","Honeycomb-like vaulting of stacked niches","A type of minaret","A carpet pattern","A garden fountain"],
     ["Which three systems dominate Islamic ornament?","Geometric patterns, arabesque, and calligraphy","Portraits, landscapes, and battles","Columns, pediments, and friezes","Stained glass, frescoes, and statues"]]},

{ t:"Islamic Architecture II", s:"From Alhambra to Isfahan, Istanbul, and the Taj Mahal",
  sec:[
  ["Al-Andalus and the Alhambra",[
    "In Muslim Spain (al-Andalus), the Nasrid dynasty built the Alhambra in Granada, mostly in the 13th and 14th centuries. Behind plain, fortified outer walls lie palaces of extraordinary refinement. The Court of the Myrtles centers on a long reflecting pool; the Court of the Lions has a fountain supported by twelve stone lions and arcades of slender columns.",
    "The Alhambra's interiors are covered in carved stucco, tile dadoes (lower wall panels), and poetry inscriptions. The Hall of the Abencerrajes and the Hall of the Two Sisters have spectacular muqarnas domes. Water, light, and pattern are combined to create a vision of paradise, an idea expressed throughout Islamic gardens."]],
  ["The four-iwan mosque in Iran",[
    "In Iran and Central Asia, the mosque developed around a courtyard with an iwan in the middle of each side, the four-iwan plan, with a domed chamber behind the qibla iwan. The Friday Mosque (Masjid-i Jami) of Isfahan, built up over centuries from the 11th century on, is the key example.",
    "Under the Safavid dynasty, Shah Abbas I made Isfahan his capital around 1598 and laid out the vast Naqsh-e Jahan Square, lined by two-story arcades and anchored by the Shah Mosque (now the Imam Mosque), the Sheikh Lotfollah Mosque, the Ali Qapu palace, and the entrance to the bazaar. Domes and iwans are sheathed in blue and yellow glazed tiles. The Shah Mosque's entrance is rotated to face the square while the mosque behind turns to face Mecca, a famous design solution."]],
  ["Timurid Central Asia",[
    "In the late 14th and 15th centuries, the conqueror Timur (Tamerlane) and his successors built monumental architecture in Samarkand and Herat. The Gur-e Amir mausoleum (early 15th century) has a ribbed turquoise dome on a tall drum. Samarkand's Registan, a square framed by three madrasas built from the 15th to 17th centuries, is one of the great urban ensembles of the Islamic world.",
    "Timurid architecture favored double domes, an inner one sized for the interior and a taller outer one for the skyline, and lavish tilework. These ideas traveled to India with Timur's descendant Babur, founder of the Mughal dynasty."]],
  ["The Ottomans and Sinan",[
    "The Ottoman Turks took Constantinople in 1453 and were deeply impressed by Hagia Sophia. Ottoman architects developed the domed mosque into a dominant form: a central dome over a unified prayer space, buttressed by half-domes and smaller domes cascading down, with pencil-thin minarets.",
    "Mimar Sinan (about 1490–1588), chief architect to Suleiman the Magnificent and his successors, is credited with hundreds of buildings. The Süleymaniye Mosque in Istanbul (1550–1557) was part of a complex (külliye) including schools, a hospital, a soup kitchen, baths, and tombs. Sinan considered the Selimiye Mosque in Edirne (1568–1575) his masterpiece; its dome, about 31 meters across, rests on eight piers and creates a remarkably unified interior. The later Sultan Ahmed ('Blue') Mosque (1609–1616) has six minarets and blue İznik tiles inside."]],
  ["Mughal India and the Taj Mahal",[
    "The Mughals (1526–1857) blended Persian, Timurid, and Indian traditions. Humayun's Tomb in Delhi (completed around 1570s) introduced the garden tomb on a grand scale: a domed mausoleum on a platform at the center of a charbagh, a four-part garden divided by water channels, symbolizing the gardens of paradise.",
    "The Taj Mahal in Agra, built by Shah Jahan for his wife Mumtaz Mahal from about 1632 to 1653, is the culmination. Its white marble mausoleum, inlaid with semiprecious stones (pietra dura), stands at the end of a charbagh rather than its center, so its reflection in the long pool is complete. Four minarets frame it, and they lean slightly outward, reportedly so they would fall away from the tomb in an earthquake. The chief architect is generally thought to be Ustad Ahmad Lahauri."]],
  ["Beyond the heartlands",[
    "Islamic architecture is also deeply local. The Great Mosque of Djenné in Mali, rebuilt in 1907, is the largest mud-brick building in the world, with wooden beams (toron) projecting from the walls that serve as permanent scaffolding for the annual replastering festival. In China, mosques such as the Great Mosque of Xi'an use Chinese timber-frame halls and courtyards. In Southeast Asia, early mosques used tiered roofs related to local wooden building.",
    "The diversity is the lesson: shared needs, such as the qibla, the community prayer, and ablution, produce a remarkable variety of forms when combined with local materials, climates, and traditions."]]
  ],
  terms:[["Four-iwan plan","A mosque or madrasa plan with an iwan at the center of each side of a courtyard."],["Madrasa","An Islamic school, often of religious law."],["Külliye","An Ottoman complex centered on a mosque, with schools, kitchens, baths, and other services."],["Charbagh","A Persian-style four-part garden divided by water channels."],["Pietra dura","Inlay of cut and polished colored stones to create images."],["Double dome","Two domes, one inside the other, to suit both interior and skyline."]],
  w:"From Spain to India, Islamic builders produced some of the world's most admired buildings by adapting shared principles to local traditions.",
  src:["Alhambra","Naqsh-e Jahan Square","Mimar Sinan","Süleymaniye Mosque","Taj Mahal","Great Mosque of Djenné"],
  q:[["The Alhambra was built mainly by which dynasty?","The Nasrids","The Ottomans","The Mughals","The Safavids"],
     ["The four-iwan plan is associated mainly with…","Iran and Central Asia","Spain and Morocco","West Africa","China"],
     ["Who was the chief Ottoman architect of the Süleymaniye and Selimiye mosques?","Mimar Sinan","Ustad Ahmad Lahauri","Anthemius of Tralles","Shah Abbas I"],
     ["Why is the Taj Mahal placed at the end of its garden rather than the center?","So its reflection in the long pool is complete","To hide it from the river","Because the ground at the center was swampy","To leave room for a palace"],
     ["What is pietra dura?","Inlay of colored stones into marble","Glazed blue tile","A type of brick vault","Carved stucco"],
     ["The Great Mosque of Djenné is built of…","Mud brick","White marble","Cut granite","Steel and glass"]]},

{ t:"Romanesque", s:"Thick walls, round arches, and pilgrimage churches",
  sec:[
  ["Europe rebuilds",[
    "After the collapse of the Western Roman Empire, Europe built little in stone for centuries. Charlemagne's Palatine Chapel at Aachen (consecrated around 805), an octagon inspired by San Vitale in Ravenna, was an early attempt to revive imperial grandeur. Around the year 1000, with growing population, monasteries, and stability, a wave of church building began. A chronicler, Raoul Glaber, wrote that it was as if the world was clothing itself 'in a white mantle of churches'.",
    "This style was later named Romanesque ('Roman-like') by 19th-century scholars because it revived Roman forms: round arches, barrel and groin vaults, thick masonry walls, and massive piers. It flourished roughly from 1000 to 1150, longer in some regions."]],
  ["Characteristics",[
    "Romanesque churches are solid, heavy, and clearly composed of geometric blocks. Thick walls with small windows were needed to resist the outward thrust of stone vaults; builders replaced earlier timber roofs, which burned often, with masonry vaults. Interiors divided into bays by piers and arches feel rhythmic and dim.",
    "Typical features include a cruciform plan, a crossing tower, west-front towers, round-arched portals with carved tympanums (the semicircular panel above a door), and blind arcading on walls. Sculpture returned to monumental scale, especially at portals, where Last Judgment scenes warned all who entered, as at Autun and Conques in France."]],
  ["Pilgrimage churches",[
    "Pilgrimage to sacred relics was a major part of medieval life, and the route to Santiago de Compostela in Spain, where the remains of St. James were venerated, was among the most popular. Along it rose a group of 'pilgrimage churches', such as Saint-Sernin in Toulouse and the Cathedral of Santiago itself.",
    "Their design solved a practical problem: crowds of pilgrims needed to view relics without disrupting services. So aisles continued around the transepts and around the apse as an ambulatory, from which radiating chapels opened, each holding relics or altars. This plan, called the chevet, became central to later Gothic cathedrals."]],
  ["Monasteries and Cluny",[
    "Monasteries were the great builders and patrons of Romanesque. The Benedictine abbey of Cluny in Burgundy led a network of hundreds of houses. Its third church, Cluny III (begun 1088), was the largest church in Christendom until the new St. Peter's in Rome; it was almost entirely demolished after the French Revolution.",
    "A monastery was planned around the cloister, a square garden surrounded by covered walkways connecting the church, chapter house, dormitory, refectory (dining hall), and other buildings. The Plan of St. Gall (about 820), a drawing preserved in Switzerland, shows an ideal monastic layout and is the oldest surviving detailed architectural plan from medieval Europe."]],
  ["Regional variety",[
    "Romanesque varied widely. In Italy, Pisa's cathedral complex (begun 1063), including the Leaning Tower (begun 1173), uses tiers of arcades in white and colored marble; the tower began leaning during construction because of soft soil and was stabilized by engineers between 1990 and 2001. In Germany, Speyer Cathedral (begun about 1030) is a massive imperial church.",
    "In England, the Normans after 1066 built Romanesque, called Norman style there: Durham Cathedral (begun 1093) has huge cylindrical piers carved with zigzags and spirals, and it features some of the earliest ribbed vaults over a high nave, along with pointed transverse arches, a major step toward Gothic."]],
  ["From Romanesque to Gothic",[
    "Romanesque builders pushed masonry vaulting forward but were limited by thick walls and small windows. Experiments with ribbed vaults and pointed arches, as at Durham and in Normandy, pointed the way to a lighter structural system.",
    "Romanesque's sense of weight, mass, and clear geometric volumes has influenced later architects, notably the American H. H. Richardson, whose 19th-century 'Richardsonian Romanesque' (Trinity Church, Boston, 1872–1877) spread across the United States."]]
  ],
  terms:[["Romanesque","European style of about 1000–1150 with round arches, thick walls, and masonry vaults."],["Tympanum","The semicircular panel above a doorway, often carved."],["Chevet","The east end of a church with an ambulatory and radiating chapels."],["Cloister","A covered walkway around a courtyard, central to monasteries."],["Rib vault","A vault with projecting arched ribs along its groins."],["Bay","A repeating unit of space in a building, defined by columns or piers."]],
  w:"Romanesque revived large-scale masonry building in Europe and developed the plans and structures that made Gothic possible.",
  src:["Romanesque architecture","Durham Cathedral","Cluny Abbey","Basilica of Saint-Sernin, Toulouse","Plan of Saint Gall","Leaning Tower of Pisa"],
  q:[["Why do Romanesque churches have thick walls and small windows?","To resist the outward thrust of stone vaults","To keep out arrows","Because glass was illegal","To support flat timber roofs"],
     ["What is a tympanum?","The semicircular panel above a doorway","A bell tower","A side chapel","A type of pier"],
     ["Pilgrimage churches added ambulatories and radiating chapels so that…","Pilgrims could see relics without disrupting services","Monks had private cells","Bells could ring louder","Kings could be crowned"],
     ["Which was the largest church in Christendom until the new St. Peter's?","Cluny III","Durham Cathedral","Speyer Cathedral","Saint-Sernin"],
     ["Durham Cathedral is important because it has…","Early ribbed vaults over a high nave","The first flying buttresses","A spiral minaret","The first steel frame"],
     ["Why does the Leaning Tower of Pisa lean?","Soft soil under its foundation","An earthquake in 1500","It was designed to lean","A war damaged its base"]]},

{ t:"Gothic I: The Invention", s:"Saint-Denis and the structure of light",
  sec:[
  ["Abbot Suger and Saint-Denis",[
    "Gothic architecture is usually dated to the rebuilding of the choir of the Abbey Church of Saint-Denis, near Paris, under Abbot Suger, consecrated in 1144. Suger wanted a church flooded with 'wonderful and uninterrupted light' through stained glass, which he linked to theological ideas of divine light leading the mind to God.",
    "His builders combined three existing elements, the pointed arch, the ribbed vault, and external buttressing, into a new system. The ambulatory at Saint-Denis has slender columns and chapels whose walls are nearly all glass. The style spread quickly across the Île-de-France region and then all of Europe. The name 'Gothic' was originally an insult given by Renaissance Italians who considered it barbaric."]],
  ["The pointed arch",[
    "A semicircular arch's height is fixed at half its span. A pointed arch can be taller or shorter for the same span, so builders could make vaults of different widths reach the same height, simplifying complex plans. Pointed arches also direct forces more steeply downward, reducing outward thrust compared with round arches.",
    "Combined with the ribbed vault, in which stone ribs are built first over temporary wooden centering and then filled with thin webbing, the pointed arch let Gothic builders cover irregular spaces and concentrate loads onto specific points rather than continuous walls."]],
  ["The flying buttress",[
    "Because loads were concentrated at points, walls between them no longer needed to be solid. The vault's outward thrust was carried by flying buttresses: arches springing from the upper wall across the side aisles to tall, heavy buttress piers outside. Pinnacles on top of those piers added weight that helped direct the thrust downward.",
    "Flying buttresses appeared prominently at Notre-Dame de Paris around 1180 and became a defining Gothic feature. They turned the cathedral into a kind of skeleton: an internal cage of piers and ribs and an external scaffold of buttresses, with the walls between replaced by glass. This is a pre-industrial version of the frame-and-infill idea behind modern skyscrapers."]],
  ["Stained glass and tracery",[
    "Stained glass windows were made of colored glass pieces held in lead strips (cames) and painted with details. They told biblical stories for a largely illiterate public and transformed the interior with colored light. Chartres Cathedral preserves an outstanding collection of its original 12th- and 13th-century windows, famous for their deep 'Chartres blue'.",
    "Window openings were divided by tracery, stone frameworks that grew more elaborate over time: plate tracery (holes cut into stone panels), then bar tracery (thin stone bars forming patterns), first used at Reims around 1211. Huge circular rose windows filled the ends of transepts and west fronts, as at Notre-Dame and Chartres."]],
  ["The elevation of the nave",[
    "The interior wall of a Gothic nave is composed in levels. At the bottom is the arcade opening to the aisles; above it, the triforium, a narrow arcaded passage; and at the top, the clerestory windows. Early Gothic churches sometimes had four levels including a gallery; later High Gothic simplified to three, enlarging the clerestory.",
    "Vertical shafts running from floor to vault unify the levels, drawing the eye upward. The goal was an interior that felt weightless, luminous, and unified, an image of the heavenly Jerusalem described in the Book of Revelation."]],
  ["Building a cathedral",[
    "Cathedrals took decades or centuries to build. Construction was led by master masons, who were designers, engineers, and contractors combined. They used geometry, templates, and full-size drawings scratched on plaster floors called tracing floors, some of which survive at York and Wells. Villard de Honnecourt's 13th-century sketchbook gives a rare glimpse into a builder's mind.",
    "Cathedrals were funded by bishops, chapters, kings, guilds, and ordinary people, and they were sources of civic pride. Their scale was staggering: medieval building projects employed quarrymen, masons, carpenters, glaziers, sculptors, and laborers, and dominated their towns for generations."]]
  ],
  terms:[["Gothic","European style from about 1140 to 1500 using pointed arches, rib vaults, and flying buttresses."],["Flying buttress","An external arch that carries the outward thrust of a vault to a buttress pier."],["Pinnacle","A small spire on top of a buttress that adds weight and decoration."],["Tracery","Ornamental stone framework dividing a window."],["Rose window","A large circular window with radiating tracery."],["Triforium","An arcaded passage in a church wall above the arcade and below the clerestory."],["Master mason","The medieval designer and builder in charge of a construction project."]],
  w:"Gothic builders turned masonry into a skeletal frame filled with glass, an engineering leap that redefined what buildings could be.",
  src:["Gothic architecture","Basilica of Saint-Denis","Flying buttress","Chartres Cathedral","Notre-Dame de Paris","Tracery"],
  q:[["Which building is usually considered the first Gothic church?","The choir of Saint-Denis","Durham Cathedral","Hagia Sophia","Speyer Cathedral"],
     ["An advantage of the pointed arch is that it…","Can vary in height for a given span and reduces outward thrust","Needs no supports","Is easier to build without centering","Is always semicircular"],
     ["What does a flying buttress do?","Carries the outward thrust of a vault to an external pier","Holds up a bell tower","Supports the floor","Channels rainwater"],
     ["Which cathedral is famous for its original 'Chartres blue' glass?","Chartres","Cologne","Salisbury","Milan"],
     ["The triforium is…","A narrow arcaded passage between the arcade and clerestory","A three-part window","A spire","A crypt"],
     ["Where did master masons make full-size drawings?","On plaster tracing floors","On parchment scrolls only","On wax tablets","On the cathedral's roof"]]}

]});


/* ---- from arch-06.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 6: Unit 3 Medieval and Islamic, chapters 6-10 */
COURSES.architecture.units[2].ch.push(

{ t:"Gothic II: Cathedrals Across Europe", s:"High Gothic, national styles, and late Gothic",
  sec:[
  ["High Gothic in France",[
    "In the decades around 1200, French builders pushed the Gothic system to its limits. Chartres Cathedral (rebuilt after a fire in 1194) set the High Gothic model: a three-story elevation, a tall clerestory with large windows, and a coherent system of flying buttresses. Reims Cathedral, where French kings were crowned, is famed for its sculpted west front, including the smiling angel.",
    "Amiens Cathedral (begun 1220) has a nave vault about 42 meters high and is often considered the classic High Gothic interior. The ambition peaked at Beauvais, whose choir vault reached about 48 meters, the tallest of any Gothic cathedral; part of it collapsed in 1284, and a later crossing tower fell in 1573. Beauvais was never finished, a reminder that medieval builders worked by experience and sometimes exceeded what their structures could carry."]],
  ["Rayonnant and Sainte-Chapelle",[
    "From the 1240s, the Rayonnant ('radiating') style, named for the radiating tracery of its rose windows, emphasized thinness, glass, and delicate tracery over sheer height. The finest example is the Sainte-Chapelle in Paris (consecrated 1248), built by King Louis IX to house relics including what was believed to be the Crown of Thorns.",
    "Its upper chapel is essentially a cage of stone shafts with walls of stained glass about 15 meters tall, held together partly with concealed iron chains and bars. Standing inside on a sunny day, visitors feel enclosed in colored light rather than walls. It is perhaps the purest realization of Suger's ideal."]],
  ["English Gothic",[
    "English Gothic developed its own character: long, low, and horizontal, often in green settings called closes, with square east ends rather than French rounded apses. Salisbury Cathedral (1220–1258) was built largely in one campaign, giving it unusual unity; its spire, added in the 14th century, is the tallest surviving medieval spire in Britain, at about 123 meters.",
    "English builders loved elaborate vaults. The Decorated style (about 1290–1350) added many extra ribs called tiercerons and liernes, forming star patterns, as at Exeter. The Perpendicular style (about 1350–1530) used strong vertical tracery grids and invented the fan vault, cone-shaped vaults covered in tracery, seen at its finest in King's College Chapel, Cambridge (vault completed 1512–1515), and Henry VII's Lady Chapel at Westminster Abbey."]],
  ["German, Italian, and Spanish Gothic",[
    "German Gothic produced the hall church, in which aisles are the same height as the nave, creating a single broad interior. Cologne Cathedral, begun in 1248 on French models, was left unfinished for centuries and completed only in 1880 using the medieval drawings; its twin spires are about 157 meters tall. Ulm Minster's spire, completed in 1890, about 161.5 meters, was the tallest church spire in the world for well over a century, until the central tower of Gaudí's Sagrada Família in Barcelona surpassed it in 2025.",
    "Italian Gothic was more restrained, with wider spaces, colored marble facades, and fewer flying buttresses, as at Florence Cathedral, Siena Cathedral, and Orvieto. Milan Cathedral, begun 1386, took nearly six centuries to complete. Spanish Gothic produced huge cathedrals at Seville, among the largest Gothic churches in the world, and Burgos and León."]],
  ["Late Gothic and Flamboyant",[
    "In 15th-century France, the Flamboyant style used flame-like curving tracery, as on the west front of Rouen Cathedral. Late Gothic also produced fantastic vaults in central Europe, such as the twisting ribs in Prague's Vladislav Hall (1490s), and in Portugal the exuberant Manueline style, with carved ropes, shells, and sea motifs reflecting the age of exploration, as at the Jerónimos Monastery in Lisbon.",
    "Gothic was not only for churches. Town halls, guild halls, universities, and houses in Flanders, Venice (the Doge's Palace), and elsewhere used Gothic forms. The Cloth Hall at Ypres and Bruges' belfry show a prosperous urban Gothic."]],
  ["Restoration and the Gothic legacy",[
    "Gothic cathedrals have been restored repeatedly. Eugène Viollet-le-Duc restored Notre-Dame de Paris in the 19th century, adding a new spire. After the devastating fire of April 2019, which destroyed the roof and spire, Notre-Dame was rebuilt using traditional materials and techniques, including oak timber framing, and reopened in December 2024, with the spire reconstructed to Viollet-le-Duc's design.",
    "The Gothic Revival of the 18th and 19th centuries, covered later, carried Gothic forms to churches, universities, and parliaments worldwide. And engineers from Viollet-le-Duc onward admired the Gothic cathedral as an efficient skeletal structure, linking it to the steel frame."]]
  ],
  terms:[["High Gothic","The mature phase of French Gothic around 1200–1250."],["Rayonnant","French Gothic style emphasizing thin structure, large glass areas, and radiating tracery."],["Fan vault","An English vault form with cone-shaped surfaces covered in tracery."],["Hall church","A church in which the aisles are as high as the nave."],["Flamboyant","Late French Gothic style with flame-like curving tracery."],["Perpendicular","English Gothic style with strong vertical lines and grids of tracery."]],
  w:"Gothic took different forms in each region, and its cathedrals remain among the greatest engineering and artistic achievements in history.",
  src:["Amiens Cathedral","Sainte-Chapelle","Salisbury Cathedral","Cologne Cathedral","Fan vault","Notre-Dame de Paris fire"],
  q:[["Which Gothic cathedral had the tallest vault but suffered collapses and was never finished?","Beauvais","Amiens","Chartres","Reims"],
     ["Sainte-Chapelle is known mainly for…","Walls almost entirely of stained glass","The tallest spire in Europe","Its fan vaults","Twin bell towers"],
     ["The fan vault is characteristic of which style?","English Perpendicular","French Rayonnant","Italian Gothic","German hall churches"],
     ["When was Cologne Cathedral finally completed?","1880","1322","1550","1945"],
     ["Which church held the record for the tallest church spire from 1890 until 2025?","Ulm Minster","Salisbury Cathedral","Cologne Cathedral","Milan Cathedral"],
     ["When did Notre-Dame de Paris reopen after its 2019 fire?","December 2024","April 2020","June 2022","It has not reopened"]]},

{ t:"Castles, Walls, and Medieval Towns", s:"Defense and daily life",
  sec:[
  ["The motte and bailey",[
    "Castles combined a lord's residence with a military stronghold. After the Norman Conquest of 1066, the Normans quickly built hundreds of motte-and-bailey castles in England: a wooden tower on an earth mound (motte) overlooking a fenced courtyard (bailey). They were fast to erect and helped control a conquered country.",
    "These were soon replaced by stone. The White Tower of the Tower of London, begun by William the Conqueror around 1078, is a great stone keep, a massive square tower with thick walls, the lord's hall, chapel, and storerooms. Keeps had entrances on the first floor, reached by removable stairs, to make attack harder."]],
  ["Concentric castles",[
    "Crusaders encountered sophisticated Byzantine and Islamic fortifications in the Middle East. Krak des Chevaliers in Syria, held by the Knights Hospitaller from 1142 and greatly expanded, used two rings of walls, the inner higher than the outer, so defenders could fire over the heads of those in front. This is the concentric castle.",
    "Edward I of England built a ring of castles in Wales in the late 13th century, many designed by Master James of St. George. Beaumaris and Harlech are concentric masterpieces, and Caernarfon has polygonal towers and banded masonry that some think deliberately echoed the walls of Constantinople, linking Edward to imperial power. They are now a World Heritage Site."]],
  ["Elements of defense",[
    "Castle builders developed a vocabulary still familiar today. Curtain walls connected towers; round towers resisted mining and battering rams better than square ones and had no blind corners. The top of walls carried battlements with crenellations (alternating gaps and solid merlons), and machicolations, projecting galleries with openings in the floor for dropping missiles on attackers below.",
    "Entrances were the weakest point, so gatehouses were heavily defended with drawbridges, portcullises (iron-shod wooden grilles dropping in grooves), and murder holes. Moats, wet or dry, kept siege engines and tunnels away. Arrow slits were narrow outside and splayed inside to give archers a wide field of fire."]],
  ["The end of the castle",[
    "Gunpowder artillery, effective by the 15th century, made tall, thin medieval walls vulnerable. The Ottoman cannons that breached Constantinople's walls in 1453 showed the new reality. Engineers responded with the bastion fort (trace italienne): low, thick, angled walls filled with earth and arrowhead-shaped bastions designed so defenders could cover every part of the wall with crossfire.",
    "Castles became palaces and country houses. In the Loire Valley of France, châteaux such as Chambord (begun 1519), with its famous double-helix staircase possibly influenced by Leonardo da Vinci, kept towers and turrets as symbols of status rather than defense."]],
  ["Medieval towns",[
    "Medieval towns grew from Roman foundations, around castles or monasteries, at river crossings, or as planned new towns called bastides, laid out on grids in southern France and Wales. Town walls defined the boundary between urban freedom and rural obligation; a German saying held that 'town air makes you free'.",
    "Inside, streets were narrow and irregular, focused on a market square, the parish church or cathedral, and the town hall. Houses were often timber-framed with upper floors projecting over the street (jetties). Carcassonne in France, heavily restored by Viollet-le-Duc, gives a vivid picture of a walled medieval city, and Rothenburg ob der Tauber in Germany preserves a timber-framed townscape."]],
  ["Civic pride and the Italian commune",[
    "Prosperous Italian city-states built public palaces as symbols of self-government. Siena's Palazzo Pubblico (begun 1297) faces the shell-shaped Piazza del Campo, whose design was strictly regulated; buildings around it had to match window styles. Florence's Palazzo Vecchio has a tall, asymmetric tower.",
    "In San Gimignano, competing families built tall stone tower houses; 14 survive of perhaps 70 or more. Medieval urban form, with its enclosed squares, winding streets, and landmark towers, later inspired planners like Camillo Sitte in the 19th century, who argued that picturesque, irregular streets were more humane than rigid grids."]]
  ],
  terms:[["Motte and bailey","An early castle with a tower on a mound overlooking a fenced courtyard."],["Keep","The main tower of a castle."],["Concentric castle","A castle with two or more rings of walls, the inner higher than the outer."],["Machicolation","An overhanging gallery with floor openings for dropping missiles."],["Portcullis","A heavy grille lowered to block a gateway."],["Bastion fort","A fortification with low, thick, angled walls designed to resist artillery."],["Bastide","A planned medieval new town, often on a grid."]],
  w:"Castles and towns show how military needs, power, and civic life shaped medieval architecture and the fabric of many cities still in use.",
  src:["Castle","Motte-and-bailey castle","Krak des Chevaliers","Castles and Town Walls of King Edward in Gwynedd","Bastion fort","Piazza del Campo"],
  q:[["What was a motte?","An earth mound topped by a tower","A water-filled ditch","A castle chapel","A projecting balcony"],
     ["Why were round towers often preferred over square ones?","They resisted mining and rams better and had no blind corners","They were cheaper to roof","They held more soldiers","They were easier to decorate"],
     ["A concentric castle has…","Two or more rings of walls, the inner higher than the outer","A central dome","Walls arranged in a spiral","A moat on the inside"],
     ["What made medieval castles obsolete?","Gunpowder artillery","Steel swords","Longbows","Horses"],
     ["The château of Chambord is famous for its…","Double-helix staircase","Concentric walls","Glass roof","Spiral minaret"],
     ["San Gimignano is known for its…","Medieval tower houses","Fan vaults","Bastion forts","Rock-cut churches"]]},

{ t:"Japan and Korea", s:"Shrines, temples, and the art of wood",
  sec:[
  ["Shinto shrines and Ise",[
    "Japan's native religion, Shinto, venerates kami (spirits) present in nature. Early shrines were simple: raised wooden structures with thatched or bark roofs, crossed rafters (chigi) at the gable ends, and log billets (katsuogi) along the ridge. The torii, a gateway of two posts and two crossbeams, marks the entrance to sacred space.",
    "The Grand Shrine of Ise is rebuilt in identical form every 20 years on an adjacent site, a practice called Shikinen Sengū, recorded for well over a thousand years with some interruptions; the 62nd rebuilding was completed in 2013, and the next is planned for 2033. Its unpainted cypress buildings are thus physically new but formally ancient, raising fascinating questions about what 'authenticity' means in architecture."]],
  ["Buddhist temples and Hōryū-ji",[
    "Buddhism arrived from Korea and China in the 6th century, bringing temple compounds with pagodas, main halls, gates, and cloisters, and the Chinese bracket system. Hōryū-ji near Nara, founded in 607 and rebuilt after a fire in the late 7th century, contains some of the oldest surviving wooden buildings in the world; its five-story pagoda's central pillar has been dated to the late 6th century.",
    "Tōdai-ji in Nara houses a giant bronze Buddha in the Great Buddha Hall (Daibutsuden). The current hall, rebuilt in 1709, is smaller than the original but long among the largest wooden buildings in the world. Japanese pagodas have rarely collapsed in earthquakes; their flexible joints, heavy overhanging roofs, and central pillar (shinbashira) seem to help them sway rather than fail, and engineers studied them when designing Tokyo Skytree."]],
  ["Palaces, Zen, and the tea house",[
    "Japanese aristocratic architecture favored lightness and integration with gardens. The shinden style of the Heian period arranged pavilions connected by corridors around a pond garden. The later shoin style, developed in the Muromachi period, introduced features of the classic Japanese room: tatami mats, sliding screens (fusuma and shōji), a decorative alcove (tokonoma), and staggered shelves.",
    "Zen Buddhism inspired restrained architecture and dry gardens of raked gravel and rocks (karesansui), as at Ryōan-ji in Kyoto. The tea house, refined by Sen no Rikyū in the 16th century, was tiny, rustic, and entered through a low door that forced guests to bow. The aesthetic of wabi-sabi, finding beauty in simplicity, imperfection, and impermanence, deeply influenced 20th-century Western modernism."]],
  ["Katsura and the modular house",[
    "The Katsura Imperial Villa in Kyoto (17th century) is a group of shoin-style buildings in a stroll garden, with staggered plans and views composed like paintings. The modernists Bruno Taut and Walter Gropius admired it, seeing in its modular grid, open plans, and unadorned surfaces a precedent for their own ideas.",
    "Japanese houses were built on a module based on the tatami mat (roughly 0.9 by 1.8 meters), so room sizes are still described by the number of mats. Sliding screens let rooms be combined or divided, and verandas (engawa) blurred inside and outside. Castles such as Himeji (completed 1609), with its white plastered towers rising on stone bases, show the military side of Japanese building."]],
  ["Korean architecture",[
    "Korea's architecture shares the East Asian timber frame and courtyard but has its own character: gentler roof curves, harmony with mountain sites, and modest scale. Bulguksa Temple and the Seokguram Grotto near Gyeongju (8th century, Unified Silla period) are UNESCO sites; Seokguram is an artificial grotto of granite blocks with a domed ceiling housing a serene seated Buddha.",
    "In Seoul, Gyeongbokgung Palace (founded 1395, rebuilt in the 1860s after destruction in the 1590s) and Changdeokgung, with its 'Secret Garden', show Joseon-dynasty royal architecture. The hanok, the traditional Korean house, includes ondol, an underfloor heating system in which smoke from a kitchen fire passes through flues under stone floors, an idea that heated Korean homes for well over a thousand years and inspired modern radiant floor heating."]],
  ["Lessons from East Asia",[
    "Japanese and Korean architecture show the power of wood: its flexibility in earthquakes, its modular discipline, and its warmth. They also show a different attitude to permanence. Rebuilding, as at Ise, can preserve form and craft skills across centuries even when materials change.",
    "Most of all, they teach the integration of building and landscape. Gardens are not decoration around a house; they are part of the architecture, framed by openings and experienced through movement and changing seasons. Architects from Frank Lloyd Wright to Tadao Ando have drawn on these ideas."]]
  ],
  terms:[["Torii","A Japanese gateway marking the entrance to a Shinto shrine."],["Shikinen Sengū","The ritual rebuilding of Ise Shrine every 20 years."],["Tatami","A woven straw mat that serves as a module for Japanese room sizes."],["Shōji","A sliding screen of translucent paper on a wooden lattice."],["Tokonoma","A decorative alcove in a Japanese room."],["Ondol","Korean underfloor heating using flues under stone floors."],["Karesansui","A Japanese dry garden of rocks and raked gravel."]],
  w:"Japan and Korea refined timber construction into an art of modular, flexible, landscape-centered building that profoundly shaped modern architecture.",
  src:["Ise Grand Shrine","Hōryū-ji","Katsura Imperial Villa","Japanese architecture","Korean architecture","Ondol"],
  q:[["How often is the Grand Shrine of Ise rebuilt?","Every 20 years","Every 100 years","Every 5 years","Every year"],
     ["Hōryū-ji is notable because it contains…","Some of the oldest surviving wooden buildings in the world","The first steel temple","A giant stone pyramid","Japan's earliest castle"],
     ["What is a tokonoma?","A decorative alcove in a Japanese room","A type of roof tile","A garden bridge","A shrine gateway"],
     ["Japanese room sizes are traditionally measured in…","Tatami mats","Shōji panels","Pillars","Footsteps"],
     ["Which modernists admired the Katsura Imperial Villa?","Bruno Taut and Walter Gropius","Antoni Gaudí and Victor Horta","Christopher Wren and Inigo Jones","Andrea Palladio and Vignola"],
     ["Ondol is…","Korean underfloor heating","A Korean roof curve","A temple bell","A paper screen"]]},

{ t:"Southeast Asia", s:"Angkor, Borobudur, and the temple-mountain",
  sec:[
  ["Indian ideas, local genius",[
    "From the early centuries CE, trade carried Hindu and Buddhist ideas from India to Southeast Asia. Local rulers adopted Sanskrit, religious texts, and temple forms, but transformed them into something new. The central idea was the temple-mountain: a stepped structure representing Mount Meru, the sacred center of the universe, often surrounded by walls and moats symbolizing the surrounding mountain ranges and oceans.",
    "The region's great monuments were built of brick, laterite (an iron-rich soil that hardens when exposed to air), and sandstone, while houses and palaces were wooden and mostly lost. So, as in Egypt, what survives is mainly religious architecture."]],
  ["Borobudur",[
    "Borobudur in central Java, Indonesia, built by the Shailendra dynasty around 780–830 CE, is the largest Buddhist monument in the world. It is a stepped pyramid of nine platforms, six square and three circular, built over a natural hill, topped by a central stupa. The circular terraces carry 72 small perforated stupas, each with a seated Buddha inside.",
    "Pilgrims climb by walking clockwise around each level, passing over 2,600 relief panels depicting Buddhist teachings, from the world of desire at the bottom to formlessness at the top. The building is a three-dimensional path to enlightenment. Borobudur was buried under volcanic ash and jungle for centuries and restored, most extensively in a UNESCO-supported project from 1975 to 1982."]],
  ["Angkor and the Khmer Empire",[
    "The Khmer Empire, centered in Cambodia from the 9th to 15th centuries, built the city of Angkor, which at its height may have been the largest preindustrial urban complex in the world, sprawling across about 1,000 square kilometers with vast reservoirs (barays) and canals. Lidar surveys since 2012 have revealed the extent of its low-density urban network.",
    "Angkor Wat, built in the first half of the 12th century under King Suryavarman II and dedicated to Vishnu, is the largest religious monument in the world. Its central quincunx of five towers, shaped like lotus buds, rises from concentric galleries, all surrounded by a moat about 190 meters wide. Unusually, it faces west, possibly linked to its funerary purpose. Its galleries hold some of the longest continuous bas-reliefs anywhere, including the Churning of the Ocean of Milk."]],
  ["The Bayon and Angkor Thom",[
    "Around 1200, King Jayavarman VII, a Buddhist, built Angkor Thom, a walled city about 3 km on each side. At its center stands the Bayon, a temple of many towers carved with giant serene faces, over 200 in total, generally identified with a bodhisattva or with the king himself.",
    "Ta Prohm, a temple-monastery of the same period, has been left partly in the grip of huge silk-cotton and strangler fig trees, deliberately preserved in that state to show how the jungle reclaimed Angkor. Its image became familiar worldwide through the film 'Lara Croft: Tomb Raider'."]],
  ["Myanmar, Thailand, and Vietnam",[
    "In Myanmar, the plain of Bagan holds the remains of over 2,000 Buddhist temples and stupas built mainly between the 11th and 13th centuries. The Shwedagon Pagoda in Yangon is a vast gilded stupa, covered in gold plates and crowned with gems, and is the most sacred Buddhist site in Myanmar.",
    "Thai temples (wats) have steep, layered roofs with ornamental finials (chofa), glittering tile and mirror mosaics, and bell-shaped stupas (chedi) or corncob-shaped towers (prang) derived from Khmer forms, as at Wat Arun in Bangkok. Vietnam's architecture drew more from China, as seen in Hanoi's Temple of Literature (founded 1070), a Confucian temple and early university."]],
  ["What the temple-mountain teaches",[
    "Southeast Asian monuments show architecture as a model of the universe, arranged around a sacred center with a strong vertical axis and concentric enclosures. Movement through them, often by circumambulation, is a spiritual journey.",
    "They also show how architecture is tied to water and landscape. Angkor's power depended on hydraulic engineering that supported rice farming. Some researchers argue that failures of this water network during periods of drought and flooding contributed to Angkor's decline in the 14th and 15th centuries, a striking lesson about cities, climate, and infrastructure."]]
  ],
  terms:[["Temple-mountain","A temple built as a model of Mount Meru, the center of the cosmos."],["Laterite","An iron-rich soil that hardens on exposure, used as building stone."],["Baray","A large Khmer reservoir."],["Quincunx","An arrangement of five elements, four at the corners and one at the center."],["Chedi","A Thai stupa, often bell-shaped."],["Prang","A tall, corncob-shaped tower derived from Khmer temples."]],
  w:"Angkor and Borobudur are among the world's greatest monuments and show how architecture can embody cosmology on a colossal scale.",
  src:["Borobudur","Angkor Wat","Angkor","Bayon","Bagan","Shwedagon Pagoda"],
  q:[["What does a temple-mountain represent?","Mount Meru, the center of the universe","A royal palace","A fortress","A burial mound for ancestors"],
     ["Borobudur is located in…","Java, Indonesia","Cambodia","Myanmar","Thailand"],
     ["Angkor Wat was originally dedicated to…","Vishnu","The Buddha","Shiva","Allah"],
     ["The Bayon is famous for its…","Giant carved faces on many towers","Golden spire","Fan vaults","Flying buttresses"],
     ["Which site has over 2,000 surviving temples and stupas?","Bagan","Angkor Thom","Ayutthaya","Hue"],
     ["What is a baray?","A large Khmer reservoir","A Thai roof ornament","A Buddhist relief panel","A wooden palace"]]},

{ t:"Africa's Architectural Traditions", s:"Great Zimbabwe, Lalibela, Timbuktu, and beyond",
  sec:[
  ["A continent of traditions",[
    "Africa's architecture is as varied as its landscapes, from Mediterranean coasts to deserts, savannas, and rainforests. Egyptian architecture is one African tradition among many. Others include the stone cities of southern Africa, the rock-hewn churches of Ethiopia, the earthen mosques of the Sahel, the coral-stone towns of the Swahili coast, and an enormous range of vernacular houses built from earth, wood, grass, and stone.",
    "Many traditions were long overlooked or misattributed by European colonial writers, who sometimes refused to believe African peoples had built major monuments. Modern archaeology has corrected these errors, and many sites are now UNESCO World Heritage Sites."]],
  ["Aksum and Lalibela",[
    "The Kingdom of Aksum in Ethiopia and Eritrea (about 1st–7th centuries CE) was a major trading power that adopted Christianity in the 4th century. It erected huge carved stone stelae, the tallest standing one about 24 meters high, representing multistory buildings with false doors and windows. One stela, taken to Rome under Mussolini in 1937, was returned to Ethiopia in 2005.",
    "At Lalibela, in the highlands of Ethiopia, eleven churches were carved down into the volcanic rock, traditionally attributed to King Lalibela around the late 12th and early 13th centuries. Bete Giyorgis (Church of St. George) is cut as a cross-shaped block standing in a deep pit, its roof level with the surrounding ground. The churches remain active places of worship and pilgrimage."]],
  ["Great Zimbabwe",[
    "Great Zimbabwe, in the country that took its name, was the capital of a trading state from about the 11th to 15th centuries, linked to the gold and ivory trade with the Indian Ocean coast. Its builders used dry-stone walling: granite blocks stacked carefully without mortar, often in patterned courses such as chevrons.",
    "The Great Enclosure has walls up to about 11 meters high and 250 meters around, the largest ancient structure south of the Sahara, containing a solid conical tower. Colonial-era writers claimed the site must have been built by foreigners, but archaeologists, beginning with Gertrude Caton-Thompson in 1929, demonstrated that it was built by ancestors of the Shona people."]],
  ["Earthen architecture of the Sahel",[
    "Across the Sahel, the semi-arid belt south of the Sahara, builders created monumental architecture from earth. In Timbuktu, Mali, the Djinguereber Mosque, first built in the 14th century, and the Sankore and Sidi Yahia mosques were centers of Islamic learning. Their earthen walls are bristling with projecting wooden beams that serve as permanent scaffolding.",
    "Earthen buildings must be maintained by regular replastering, often as community festivals, as at Djenné. This links architecture to social life: the building survives because the community keeps it alive. In 2012, armed groups damaged mausoleums in Timbuktu; they were rebuilt by local masons with UNESCO support by 2015."]],
  ["The Swahili coast and North Africa",[
    "Along the East African coast, Swahili city-states such as Kilwa Kisiwani, Lamu, and Zanzibar's Stone Town flourished through Indian Ocean trade. Their builders used coral stone and lime, with carved wooden doors and stone mosques. The Great Mosque of Kilwa, developed from around the 11th century and enlarged later, had an innovative domed and vaulted roof, and the nearby Husuni Kubwa palace was among the largest buildings in sub-Saharan Africa of its time.",
    "North Africa developed brilliant Islamic architecture, from the Great Mosque of Kairouan to the cities of Fez and Marrakesh. The ksour and kasbahs of southern Morocco, such as Aït Benhaddou, are fortified earthen villages with towers decorated in geometric patterns."]],
  ["Vernacular houses and lessons",[
    "Vernacular African houses show sophisticated responses to climate and society. Musgum houses in Cameroon are tall, bullet-shaped earthen domes with raised ridges that serve as built-in footholds. Kassena houses in Burkina Faso are painted with bold geometric patterns by women. Compound homes arrange separate rooms around a shared yard, reflecting family structures.",
    "Contemporary African architects such as Francis Kéré, born in Burkina Faso and winner of the 2022 Pritzker Prize, the first African to receive it, combine local materials like compressed earth with modern techniques. His school in his home village of Gando (2001) used community labor and passive cooling. African traditions teach that sustainable, community-built architecture is not a new idea."]]
  ],
  terms:[["Stela","An upright carved stone slab, often a monument or marker."],["Rock-hewn church","A church carved out of solid rock."],["Dry-stone walling","Masonry built without mortar, relying on careful fitting."],["Coral stone","Building stone cut from fossilized coral reef."],["Ksar (pl. ksour)","A fortified village in North Africa, often of earth."]],
  w:"Africa's diverse traditions, from Great Zimbabwe to Lalibela to the Sahel's earthen mosques, are essential to a complete understanding of world architecture.",
  src:["Great Zimbabwe","Lalibela","Aksum","Djinguereber Mosque","Kilwa Kisiwani","Diébédo Francis Kéré"],
  q:[["How were the Lalibela churches made?","Carved down into solid volcanic rock","Built of mud brick","Assembled from imported stone","Made of timber"],
     ["Great Zimbabwe's walls were built using…","Dry-stone granite blocks without mortar","Fired brick and bitumen","Coral stone and lime","Rammed earth"],
     ["Who demonstrated that Great Zimbabwe was built by local African people?","Gertrude Caton-Thompson","Howard Carter","Arthur Evans","Heinrich Schliemann"],
     ["Why do Sahelian mosques have projecting wooden beams?","They act as permanent scaffolding for replastering","To hold flags","To support bells","To scare birds"],
     ["Swahili coastal towns were typically built of…","Coral stone and lime","Granite and marble","Steel and glass","Bamboo"],
     ["In 2022, Francis Kéré became the first African to win…","The Pritzker Prize","The Nobel Prize in Literature","The RIBA Gold Medal","The Venice Golden Lion"]]}

);


/* ---- from arch-07.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 7: Unit 4 Renaissance to Neoclassicism, chapters 1-5 */
COURSES.architecture.units.push({ t:"Renaissance to Neoclassicism", ch:[

{ t:"The Early Renaissance", s:"Brunelleschi, Alberti, and the rebirth of antiquity",
  sec:[
  ["Florence and the dome",[
    "The Renaissance in architecture began in Florence in the early 15th century, in a wealthy, competitive republic proud of its supposed Roman origins. The city's cathedral had a gaping octagonal crossing about 42 meters wide, too large for any known method of centering. In 1418 a competition was held; Filippo Brunelleschi (1377–1446), a goldsmith who had studied Roman ruins, won the commission, which he at first had to share with his old rival Lorenzo Ghiberti.",
    "Brunelleschi's dome (built 1420–1436) was a double shell of brick, an inner dome and a lighter outer one, built without centering. He laid bricks in a herringbone pattern so each course locked into place as it rose, used stone and timber chains around the dome to resist its outward spread, and invented hoisting machines to lift materials. It remains the largest masonry dome ever built, and it became the symbol of Florence."]],
  ["Brunelleschi's new language",[
    "Brunelleschi did more than engineer. In the Foundling Hospital (Ospedale degli Innocenti, begun 1419), he created a loggia of slender Corinthian columns carrying round arches, each bay a perfect square in plan and a cube in volume. In the churches of San Lorenzo and Santo Spirito, he used gray pietra serena stone against white plaster to make the classical grid of columns, arches, and pilasters crisply legible.",
    "This was a new architecture of clarity and proportion, based on simple ratios and the study of Roman antiquity. Brunelleschi is also credited with demonstrating linear perspective, around 1415–1420, using painted panels of the Baptistery; perspective soon transformed painting and the way architects represented space."]],
  ["Alberti, the theorist",[
    "Leon Battista Alberti (1404–1472) was a humanist scholar, writer, and architect, the model of the Renaissance 'universal man'. His treatise 'De re aedificatoria' (On the Art of Building), completed around 1452, was the first major architectural treatise since Vitruvius. He defined beauty as 'the harmony of all the parts... fitted together with such proportion and connection that nothing could be added, diminished, or altered but for the worse'.",
    "Alberti's buildings applied classical forms in new ways. At the Tempio Malatestiano in Rimini he wrapped a medieval church in a facade based on a Roman triumphal arch. His facade for Santa Maria Novella in Florence used large scrolls (volutes) to link a tall central section with lower side aisles, a solution copied in countless later churches. Sant'Andrea in Mantua, designed in the 1470s, has a vast barrel-vaulted nave inspired by Roman baths."]],
  ["The palazzo",[
    "Wealthy Florentine families built city palaces (palazzi) expressing their power. The Palazzo Medici (begun 1444), by Michelozzo, has a rusticated ground floor of rough-cut stone, smoother stories above, and a massive overhanging cornice crowning the whole. Inside, a colonnaded courtyard brought light and air.",
    "Alberti's Palazzo Rucellai (around 1446–1451) was the first to apply the classical orders as superimposed pilasters across a palace facade, Doric-like at the bottom, then Ionic-like, then Corinthian, following the Colosseum. The palazzo type, a solid block around a courtyard, became the model for city buildings, from Renaissance Rome to 19th-century banks and clubs."]],
  ["Ideal cities and the central plan",[
    "Renaissance architects were fascinated by the centrally planned church, circular or Greek-cross shaped, as the most perfect form, reflecting ideas of divine geometry and the human body inscribed in a circle and square (the Vitruvian Man). Santa Maria delle Carceri in Prato by Giuliano da Sangallo (begun 1485) is an early example.",
    "They also imagined ideal cities. Filarete's treatise described Sforzinda, a star-shaped city. Pienza in Tuscany was rebuilt in the 1460s by Pope Pius II, with Bernardo Rossellino, as a small ideal town center around a trapezoidal piazza. A famous painting, the 'Ideal City' in Urbino, shows a perfectly ordered square with a central round temple."]],
  ["Why it mattered",[
    "The Early Renaissance shifted architecture from the medieval workshop tradition toward the architect as an educated individual designer, an intellectual who studied ancient texts and ruins, drew, theorized, and signed his work. It also established proportion, symmetry, and the classical orders as the foundations of Western design for the next four centuries.",
    "Its key ideas were rational order, human scale, legibility, and a dialogue with the past. Even modern architects who rejected classical ornament often kept the Renaissance concern with proportion and clear geometry."]]
  ],
  terms:[["Renaissance","The 'rebirth' of classical culture in Europe, beginning in 15th-century Italy."],["Herringbone brickwork","Bricks laid in a zigzag pattern; Brunelleschi used it to stabilize his dome as it rose."],["Loggia","A gallery or room open on one or more sides, usually with columns."],["Pilaster","A flat, rectangular column projecting slightly from a wall."],["Rustication","Masonry with deep joints and rough or textured faces, giving a strong, heavy look."],["Linear perspective","A drawing system using vanishing points to show depth."]],
  w:"The Early Renaissance created the idea of the architect as designer and theorist and revived the classical system that dominated Western architecture for centuries.",
  src:["Florence Cathedral","Filippo Brunelleschi","Leon Battista Alberti","Ospedale degli Innocenti","Palazzo Medici Riccardi","De re aedificatoria"],
  q:[["How did Brunelleschi build Florence's dome without centering?","A double brick shell with herringbone courses and tension chains","By filling the space with earth","Using a temporary steel frame","With concrete poured into formwork"],
     ["Which building is often considered the first Renaissance building?","The Foundling Hospital in Florence","St. Peter's in Rome","The Pantheon","Milan Cathedral"],
     ["Who wrote 'De re aedificatoria'?","Leon Battista Alberti","Vitruvius","Andrea Palladio","Giorgio Vasari"],
     ["What problem did Alberti's scrolls on Santa Maria Novella solve?","Linking a tall central section with lower aisles","Supporting a heavy dome","Draining rainwater","Hiding a bell tower"],
     ["Rustication gives masonry…","A rough, heavy, textured look","A smooth polished finish","A glassy glaze","A painted pattern"],
     ["Renaissance architects favored centrally planned churches because…","They saw the circle and square as perfect, divine forms","They were cheaper to build","Bishops required them","They held more people"]]},

{ t:"The High Renaissance and St. Peter's", s:"Bramante, Raphael, and Michelangelo in Rome",
  sec:[
  ["The move to Rome",[
    "Around 1500 the center of the Renaissance shifted to Rome, where ambitious popes, above all Julius II (reigned 1503–1513), aimed to restore the city's ancient glory. Architects there could study the ruins directly. The result, the High Renaissance, was grander, more monumental, and closer to imperial Roman architecture than the delicate work of Florence.",
    "Donato Bramante (1444–1514), who had worked in Milan alongside Leonardo da Vinci, became the leading architect. His Tempietto (begun around 1502) in the courtyard of San Pietro in Montorio, on the supposed site of St. Peter's crucifixion, is a small circular temple with a Doric colonnade and a dome. Despite being tiny, it was hailed as the first building to equal the ancients, and it inspired domes such as those of St. Paul's in London and the US Capitol."]],
  ["Rebuilding St. Peter's",[
    "In 1505–1506, Julius II decided to demolish the 1,200-year-old basilica of Old St. Peter's and build a new church. Bramante's plan was a huge Greek cross with a central dome inspired by the Pantheon, set on vaults like those of the Basilica of Maxentius; he reportedly aimed to 'place the Pantheon on top of the Basilica of Constantine'. Construction began in 1506.",
    "The project took over 120 years and involved a succession of architects: Bramante, Raphael, Baldassare Peruzzi, Antonio da Sangallo the Younger, Michelangelo, Giacomo della Porta, and Carlo Maderno. Funding it through the sale of indulgences was one of the grievances that sparked Martin Luther's Reformation in 1517, a striking example of architecture affecting world history."]],
  ["Michelangelo's contribution",[
    "Michelangelo Buonarroti (1475–1564), already famous as a sculptor and painter, took charge of St. Peter's in 1546 at age 71. He returned to a centralized plan, simplified Sangallo's complicated design, and designed a dome on a high drum with paired columns. He thickened the piers and gave the exterior a giant order of Corinthian pilasters spanning two stories, unifying the building's colossal mass.",
    "After his death, Giacomo della Porta completed the dome in 1590, with a somewhat taller profile. The dome rises about 136 meters to the top of its cross, and is about 42 meters in internal diameter, slightly less than the Pantheon's. Later, Carlo Maderno extended the nave and added the facade (completed 1614) to create a Latin cross, at the request of the Church, which partly hides the dome from the square."]],
  ["Raphael and the villa",[
    "Raphael (1483–1520), best known as a painter, also served as architect of St. Peter's after Bramante's death and designed the Villa Madama in Rome (begun around 1518), an attempt to recreate an ancient Roman villa with gardens, loggias, and a semicircular courtyard. Its decorated loggia, with stucco and painted grotesques (a type of ornament inspired by recently rediscovered Roman wall paintings in Nero's Golden House), influenced decoration across Europe.",
    "The High Renaissance villa reconnected architecture with landscape. Villas such as the Villa Farnesina in Rome by Peruzzi and later the Villa d'Este at Tivoli, with its cascading fountains (begun 1550s), combined buildings and gardens into a single designed setting."]],
  ["Michelangelo as architect",[
    "Michelangelo's architecture was sculptural and bold, breaking classical rules for expressive effect. In the Medici Chapel and the Laurentian Library in Florence (begun 1520s), he used architectural elements in unexpected ways: columns sunk into the wall rather than supporting it, brackets that support nothing, and a flowing staircase in the library vestibule that seems to pour down like lava.",
    "On Rome's Capitoline Hill, his Campidoglio (designed from 1538) reorganized the ancient civic center into a trapezoidal piazza with a star-patterned oval pavement around the ancient bronze statue of Marcus Aurelius. He used a giant order to unify the palace facades. This was one of the first great designed urban spaces of the modern era."]],
  ["The High Renaissance legacy",[
    "The High Renaissance established ideas that dominated for centuries: the dome as a symbol of authority, the monumental classical facade, the giant order, and buildings designed as unified compositions. St. Peter's became the model for great domed churches and capitols worldwide.",
    "It also showed the gap between ideal and practice. The perfect centralized plans of Bramante and Michelangelo were altered by the practical and liturgical needs of the Church, by changing popes, and by time. Most great buildings, then as now, are the product of many hands and compromises."]]
  ],
  terms:[["High Renaissance","The peak of Renaissance art and architecture, centered in Rome, about 1500–1530."],["Tempietto","Bramante's small circular temple in Rome, considered a perfect High Renaissance building."],["Giant order","Columns or pilasters spanning two or more stories."],["Drum","The cylindrical wall on which a dome sits."],["Grotesque","Fanciful decoration of figures, plants, and ornaments, based on ancient Roman wall paintings."],["Latin cross","A cross plan with one arm longer than the others."]],
  w:"The High Renaissance created the monumental classical language and the great dome that shaped churches, capitols, and civic buildings worldwide.",
  src:["St. Peter's Basilica","Donato Bramante","Tempietto","Michelangelo","Laurentian Library","Campidoglio"],
  q:[["What is Bramante's Tempietto?","A small circular temple considered to equal the ancients","A huge basilica","A Florentine palace","A garden villa"],
     ["How was the rebuilding of St. Peter's partly funded?","Through the sale of indulgences","Through a tax on wool","By Spanish gold alone","By donations from the Medici only"],
     ["Who designed the dome of St. Peter's and the giant order on its exterior?","Michelangelo","Raphael","Brunelleschi","Alberti"],
     ["Who completed St. Peter's dome in 1590?","Giacomo della Porta","Carlo Maderno","Gian Lorenzo Bernini","Donato Bramante"],
     ["Why does Maderno's nave partly hide the dome from the square?","The nave was extended to make a Latin cross","The dome was lowered","The facade was too short","The square was raised"],
     ["What is notable about the Laurentian Library vestibule?","Columns sunk into walls and a flowing staircase","A glass ceiling","A rose window","A spiral ramp"]]},

{ t:"Palladio", s:"Villas, temples, and the most copied architect in history",
  sec:[
  ["A stonemason from Padua",[
    "Andrea Palladio (1508–1580) was born Andrea di Pietro in Padua and trained as a stonemason. In Vicenza, the humanist Gian Giorgio Trissino took him under his wing, educated him, took him to Rome to study ruins, and gave him the name Palladio, after Pallas Athena. He became the leading architect of the Venetian Republic.",
    "Palladio's genius was to adapt classical architecture to the practical needs of his clients, especially the Venetian nobility, who were investing in farmland on the mainland. His buildings are calm, symmetrical, and harmonious, built often of cheap brick covered in stucco to look like stone."]],
  ["The villas",[
    "Palladio designed about two dozen surviving villas in the Veneto, which combined a noble residence with a working farm. Typically a central block for the family was linked by long arcaded wings (barchesse) to farm buildings, granaries, and stables. The family's living rooms were on a raised main floor (piano nobile) above service spaces.",
    "His crucial innovation was applying the temple front, with columns and a triangular pediment, to houses. He believed, incorrectly, that ancient Roman houses had used temple porticoes. The Villa Barbaro at Maser has frescoes by Paolo Veronese. The Villa Emo and Villa Badoer show the farm villa type clearly."]],
  ["Villa Rotonda",[
    "The Villa Almerico Capra, known as La Rotonda (begun around 1567), near Vicenza, is his most famous building. It was built as a retreat rather than a farm, on a hilltop with views in all directions, so Palladio gave it four identical temple porticoes, one on each side, around a central domed hall. Its plan is perfectly symmetrical about both axes.",
    "La Rotonda became an icon reproduced around the world: Chiswick House in London (1720s), Mereworth Castle in Kent, and many American houses and public buildings echo it. It expresses the Renaissance ideal of a building as a perfect, self-contained geometric object in harmony with nature."]],
  ["Churches and civic buildings",[
    "In Venice, Palladio designed the churches of San Giorgio Maggiore (begun 1566) and Il Redentore (begun 1577). To give a church facade a classical temple front despite a tall nave and lower aisles, he superimposed two temple fronts: a tall one for the nave and a wider, lower one for the aisles. Their white facades across the water remain key elements of the Venetian skyline.",
    "In Vicenza, Palladio wrapped the old medieval town hall in two stories of arcades, the 'Basilica Palladiana' (designed 1546, built over decades). Its arcades use the motif now called the Palladian or Serlian window: an arch flanked by two narrower rectangular openings. His last work, the Teatro Olimpico (begun 1580), has a permanent stage set with streets painted and built in forced perspective, completed by Vincenzo Scamozzi."]],
  ["The Four Books",[
    "In 1570 Palladio published 'I quattro libri dell'architettura' (The Four Books of Architecture). It covered materials and the orders, private houses (with his own villas and palaces as models), public buildings, and ancient temples. Its clear woodcut illustrations made it the most influential architecture book of its era, translated into many languages.",
    "Through the Four Books, Palladio's ideas reached architects who never saw his buildings. Inigo Jones brought them to England in the early 17th century; in the 18th century Palladianism became the dominant style for English country houses; and in America Thomas Jefferson called the Four Books his 'Bible', drawing on it for Monticello and the University of Virginia."]],
  ["Palladianism worldwide",[
    "Palladianism spread to Britain, Ireland, Russia, and the American colonies. Its features include symmetrical facades, temple-front porticoes, the Palladian window, and harmonious room proportions based on simple ratios. Many government buildings, plantation houses, banks, and suburban homes still carry Palladian elements.",
    "Palladio's significance lies not only in his buildings but in showing how a coherent design system, clearly published, can spread across continents and centuries. He may be the most imitated architect in Western history. His villas and buildings in Vicenza are a UNESCO World Heritage Site."]]
  ],
  terms:[["Piano nobile","The main, raised floor of a house containing the principal rooms."],["Palladian window","A central arched opening flanked by two narrower flat-topped openings, also called a Serlian window or Venetian window."],["Portico","A porch with a roof supported by columns, often with a pediment."],["Pediment","The triangular gable above a classical portico or window."],["Palladianism","An architectural style based on Palladio's designs and writings, especially popular in 18th-century Britain and America."]],
  w:"Palladio adapted classical architecture to everyday buildings and, through his book, shaped houses and public buildings across the Western world.",
  src:["Andrea Palladio","Villa La Rotonda","I quattro libri dell'architettura","Palladian architecture","San Giorgio Maggiore","Palladian window"],
  q:[["What was Palladio's key innovation for houses?","Applying a temple front with a pediment","Using flying buttresses","Inventing the steel frame","Building on stilts"],
     ["Villa La Rotonda has…","Four identical porticoes around a central domed hall","A single grand staircase on one side","No windows facing the hills","A Gothic tower"],
     ["How did Palladio solve the church facade problem at San Giorgio Maggiore?","He superimposed a tall and a wide temple front","He used a single giant arch","He hid the facade behind a wall","He used a bell tower as the facade"],
     ["What is a Palladian window?","A central arch flanked by two narrower rectangular openings","A circular rose window","A pointed Gothic window","A row of clerestory windows"],
     ["Who called Palladio's Four Books his 'Bible'?","Thomas Jefferson","Inigo Jones","Christopher Wren","Le Corbusier"],
     ["Palladio often built with…","Brick covered in stucco to look like stone","Solid marble throughout","Timber frames","Cast iron"]]},

{ t:"Mannerism and the Renaissance Beyond Italy", s:"Breaking rules and spreading ideas",
  sec:[
  ["What Mannerism was",[
    "In the decades after about 1520, some Italian architects began to bend and break the rules that the High Renaissance had established. This tendency is called Mannerism. Mannerist buildings use classical elements in deliberately unexpected or contradictory ways: keystones that slip out of place, pediments broken open, columns paired or squeezed, rhythms that set up and then disrupt expectations.",
    "Mannerism was partly a sophisticated game for educated viewers who knew the rules, and partly a reflection of a troubled era marked by the Sack of Rome in 1527 and the Reformation. Michelangelo's Laurentian Library is often seen as a key Mannerist work."]],
  ["Giulio Romano and the Palazzo del Te",[
    "Giulio Romano (about 1499–1546), Raphael's pupil, designed the Palazzo del Te in Mantua (1524–1534) as a pleasure palace for Federico II Gonzaga. Its courtyard facades have triglyphs that appear to slip down from the frieze as though the building were collapsing, irregular spacing of columns, and rough rustication mixed with polished stone.",
    "Inside, the Sala dei Giganti (Room of the Giants) is painted floor to ceiling with an illusion of giants being crushed by falling buildings as Jupiter hurls thunderbolts, with no visible room corners. The palace is a witty and unsettling demonstration of how architecture can play with the viewer's expectations."]],
  ["Vignola, Serlio, and the treatises",[
    "Sebastiano Serlio published a series of illustrated books on architecture from 1537, practical pattern books that spread Italian forms throughout Europe, especially France, where Serlio worked for King Francis I. Giacomo Barozzi da Vignola's 'Rule of the Five Orders of Architecture' (1562) gave simple proportional rules for each order and became one of the most used architecture textbooks ever.",
    "Vignola also designed Il Gesù in Rome (begun 1568), mother church of the Jesuit order. Its wide nave with side chapels instead of aisles, designed so that everyone could see the altar and hear the sermon, and its facade (completed by Giacomo della Porta) became models for Counter-Reformation and Baroque churches around the world, as the Jesuits spread through Europe, Asia, and the Americas."]],
  ["France: from châteaux to the Louvre",[
    "French kings brought Italian artists and ideas north. Francis I built at Chambord and Fontainebleau, where Italian artists including Rosso Fiorentino and Primaticcio created elaborate decorations combining stucco and painting. This 'School of Fontainebleau' blended Italian Mannerism with French traditions.",
    "Pierre Lescot began rebuilding the Louvre in Paris in 1546, creating a refined French classical facade with sculpture by Jean Goujon. Philibert de l'Orme, one of the first French architects to study in Rome, wrote treatises and invented a timber roof system using short planks. French architecture developed its own classical tradition, with steep roofs and tall chimneys retained from the medieval past."]],
  ["Spain, England, and northern Europe",[
    "In Spain, Philip II built El Escorial (1563–1584) near Madrid, designed by Juan Bautista de Toledo and Juan de Herrera: a vast, severe granite complex combining monastery, palace, church, library, and royal mausoleum. Its austere style, called Herreran, reflects the Counter-Reformation piety of its patron.",
    "In England, Elizabethan prodigy houses such as Hardwick Hall (1590–1597), famous for the rhyme 'Hardwick Hall, more glass than wall', mixed Renaissance symmetry with large Gothic-style windows. In the Netherlands and Germany, pattern books produced lavish gabled facades with scrolls and strapwork. Then Inigo Jones, having traveled in Italy, designed the Queen's House at Greenwich (begun 1616) and the Banqueting House in Whitehall (1619–1622), the first truly classical buildings in England."]],
  ["Russia and the wider world",[
    "Italian architects worked in Moscow in the late 15th century, rebuilding the Kremlin's walls and cathedrals, such as Aristotele Fioravanti's Dormition Cathedral (1475–1479), blending Italian engineering with Russian Orthodox forms. Renaissance ideas spread through Spanish and Portuguese colonies, where Iberian forms combined with indigenous craftsmanship.",
    "The lesson of this period is how architectural ideas travel: through traveling architects, printed books, and royal patronage. By the end of the 16th century, the classical language had become a European, and increasingly global, standard, adapted by each region to its climate, materials, and traditions."]]
  ],
  terms:[["Mannerism","A 16th-century style that used classical elements in deliberately unconventional ways."],["Pattern book","A book of designs and details that builders could copy."],["Strapwork","Ornament of interlaced bands resembling leather straps, popular in northern Europe."],["Prodigy house","A large, showy English country house of the Elizabethan and Jacobean periods."],["Herreran style","The austere Spanish Renaissance style of El Escorial."]],
  w:"Mannerism showed that rules can be bent for effect, and printed books carried the Renaissance from Italy to the rest of Europe and beyond.",
  src:["Mannerism","Palazzo del Te","Church of the Gesù","El Escorial","Inigo Jones","Hardwick Hall"],
  q:[["What characterizes Mannerist architecture?","Classical elements used in deliberately unexpected ways","Strict adherence to Vitruvian rules","Use of steel and glass","Pointed arches and flying buttresses"],
     ["At the Palazzo del Te, Giulio Romano made triglyphs appear to…","Slip down as if the building were collapsing","Glow in the dark","Rotate","Float above the roof"],
     ["Which church became the model for many Jesuit churches?","Il Gesù in Rome","St. Peter's","San Giorgio Maggiore","Santo Spirito"],
     ["Vignola is famous for…","A rulebook of the five orders","The first Gothic cathedral","Designing the Escorial","Inventing the Palladian window"],
     ["Which building was 'more glass than wall'?","Hardwick Hall","Banqueting House","El Escorial","Queen's House"],
     ["Who designed England's first truly classical buildings?","Inigo Jones","Christopher Wren","John Vanbrugh","Robert Adam"]]},

{ t:"Baroque Italy", s:"Bernini, Borromini, and architecture as theater",
  sec:[
  ["What Baroque means",[
    "Baroque architecture emerged in Rome around 1600 and spread through Catholic Europe and its colonies until the mid-18th century. It was strongly linked to the Counter-Reformation, the Catholic Church's response to Protestantism, which called for art that would move the faithful emotionally. Baroque buildings are dynamic, theatrical, and full of movement, light, and drama.",
    "Typical features include curving walls and facades, oval plans, dramatic lighting from hidden sources, rich materials, and a fusion of architecture, sculpture, and painting into one total artwork. The word 'baroque' probably comes from a Portuguese term for an irregular pearl, originally used as criticism."]],
  ["Bernini and St. Peter's",[
    "Gian Lorenzo Bernini (1598–1680), sculptor and architect, dominated Roman art for half a century. Inside St. Peter's, he created the baldacchino (1623–1634), a bronze canopy almost 30 meters high on twisting Solomonic columns over the papal altar, and the Cathedra Petri, a sculptural ensemble enshrining the chair of St. Peter, lit by a golden window with a dove.",
    "Outside, Bernini designed St. Peter's Square (1656–1667): two great curving colonnades, four columns deep, embracing the visitor like 'the motherly arms of the Church', in his own words. The oval square, with its central obelisk and fountains, is one of the world's greatest public spaces. From two points in the square, marked on the pavement, the four rows of columns align so they appear as one."]],
  ["Borromini",[
    "Francesco Borromini (1599–1667), Bernini's great rival, was an introverted, intensely inventive architect. His church of San Carlo alle Quattro Fontane (1638–1641, facade completed 1667) is tiny, small enough, it is often said, to fit inside one of the piers of St. Peter's. Its plan is generated from geometric figures and its walls undulate, while its oval dome is covered in a honeycomb of crosses, octagons, and hexagons that shrink toward the lantern to make it seem higher.",
    "At Sant'Ivo alla Sapienza (1642–1660), Borromini built a plan based on a six-pointed star, a dome that rises continuously from the walls, and a spiraling lantern. Borromini's complex geometry and willingness to bend walls influenced architects in central Europe and, much later, 20th-century architects interested in complex curves."]],
  ["Urban theater",[
    "Baroque Rome was redesigned as a stage for processions and pilgrims. Pope Sixtus V (reigned 1585–1590) and his architect Domenico Fontana cut long straight streets connecting the major pilgrimage churches and erected ancient obelisks as markers at key points, including the obelisk moved to St. Peter's Square in 1586.",
    "Piazza Navona, built over the ancient Stadium of Domitian, holds Bernini's Fountain of the Four Rivers (1651) opposite Borromini's church of Sant'Agnese. The Spanish Steps (1723–1725) and the Trevi Fountain (completed 1762), by Nicola Salvi, show the Baroque genius for combining architecture, sculpture, water, and city space into dramatic scenes."]],
  ["Light, illusion, and the total work of art",[
    "Baroque architects used hidden windows to cast dramatic light on altars and sculptures. Bernini's Cornaro Chapel in Santa Maria della Vittoria (1647–1652) frames his marble 'Ecstasy of Saint Teresa' lit from a concealed window, with members of the patron's family carved in theater-box balconies on the side walls as though watching a performance.",
    "Ceiling painters created illusions of the heavens opening above: Andrea Pozzo's ceiling in Sant'Ignazio (1685–1694) shows saints rising into the sky, with a painted fake dome where a real one had been planned. This fusion of arts, called bel composto ('beautiful whole') by Bernini's biographer, aimed to overwhelm the senses."]],
  ["Guarini and northern Italy",[
    "Guarino Guarini (1624–1683), a priest, mathematician, and architect, worked in Turin. His dome over the Chapel of the Holy Shroud (completed 1694) is formed by stacked, staggered arches that create a dizzying, cone-like pattern of light, and San Lorenzo's dome is made of interlacing ribs inspired partly by Islamic vaults. The Chapel of the Holy Shroud was badly damaged by fire in 1997 and reopened in 2018 after a long restoration.",
    "Filippo Juvarra (1678–1736) later designed the Basilica of Superga and the Stupinigi hunting lodge near Turin. Italian Baroque shows that architecture can be about emotion, movement, and experience as much as about order and rules."]]
  ],
  terms:[["Baroque","A dramatic, dynamic style of the 17th and early 18th centuries, linked to the Counter-Reformation."],["Baldacchino","A canopy over an altar or throne."],["Solomonic column","A twisted, spiraling column."],["Oval plan","A favorite Baroque plan shape, combining a central focus with a directional axis."],["Lantern","A small structure with windows on top of a dome, admitting light."],["Bel composto","The unified fusion of architecture, sculpture, and painting."]],
  w:"The Baroque showed architecture's power to move emotions and to shape cities as dramatic stages.",
  src:["Baroque architecture","Gian Lorenzo Bernini","Francesco Borromini","St. Peter's Square","San Carlo alle Quattro Fontane","Guarino Guarini"],
  q:[["Baroque architecture was closely linked to…","The Counter-Reformation","The Protestant Reformation","The Industrial Revolution","Ancient Egypt"],
     ["Bernini's baldacchino is…","A bronze canopy over the papal altar","A painted ceiling","A fountain in Piazza Navona","An obelisk"],
     ["How did Bernini describe St. Peter's Square's colonnades?","As the motherly arms of the Church","As the gates of heaven","As a crown of stone","As a theater for kings"],
     ["Which architect designed San Carlo alle Quattro Fontane?","Francesco Borromini","Gian Lorenzo Bernini","Carlo Maderno","Guarino Guarini"],
     ["Andrea Pozzo's ceiling in Sant'Ignazio includes…","A painted fake dome","A glass roof","A real oculus","A mosaic of gold tiles"],
     ["Which pope cut long straight streets through Rome to link pilgrimage churches?","Sixtus V","Julius II","Urban VIII","Pius II"]]}

]});


/* ---- from arch-08.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 8: Unit 4 Renaissance to Neoclassicism, chapters 6-9 */
COURSES.architecture.units[3].ch.push(

{ t:"Baroque Across Europe", s:"Versailles, Wren, and the palaces of kings",
  sec:[
  ["French classicism",[
    "In France, the Baroque took a more restrained, classical form suited to an absolute monarchy. François Mansart, whose name survives in the 'mansard roof' (a roof with two slopes on each side, the lower one steep, allowing an extra story of rooms), set high standards of refinement. The east front of the Louvre (1667–1670), designed by a committee including Louis Le Vau, Charles Le Brun, and Claude Perrault, with a long colonnade of paired columns, rejected a design by Bernini in favor of a cooler French classicism.",
    "The château of Vaux-le-Vicomte (1658–1661), built for Louis XIV's finance minister Nicolas Fouquet by Le Vau, Le Brun, and the garden designer André Le Nôtre, was so magnificent that the jealous king had Fouquet arrested soon after a lavish party there. Louis then hired the same team for an even grander project."]],
  ["Versailles",[
    "Louis XIV transformed his father's hunting lodge at Versailles into the largest palace in Europe and moved the court there in 1682. Le Vau, then Jules Hardouin-Mansart, designed the buildings; Le Brun directed the interiors; Le Nôtre designed the gardens. The Hall of Mirrors (1678–1684), with 357 mirrors facing tall windows onto the gardens, was the palace's showpiece; the Treaty of Versailles ending World War I was signed there in 1919.",
    "Versailles was architecture as political instrument. By housing the nobility at court, under the king's eye and immersed in elaborate rituals, Louis reduced their independent power. The palace's axial plan, with the king's bedroom at its center, expressed the idea of the Sun King as the center of the state. Versailles was imitated by rulers across Europe, from Vienna's Schönbrunn to Caserta in Italy and Peterhof in Russia."]],
  ["The formal garden",[
    "Le Nôtre's gardens at Versailles extended the palace's geometry across the landscape: a central axis running toward the horizon, a Grand Canal over 1.5 km long, parterres (flat beds of low hedges in ornamental patterns), clipped trees, fountains, and statues. The garden displayed human, and royal, mastery over nature.",
    "This French formal garden became an international standard. Its long axes, radiating avenues, and focal points also influenced city planning: Pierre Charles L'Enfant, who grew up partly at Versailles where his father was a court painter, used radiating diagonal avenues in his 1791 plan for Washington, D.C."]],
  ["Wren and London",[
    "After the Great Fire of London in 1666 destroyed much of the city, Christopher Wren (1632–1723), a scientist and astronomer turned architect, proposed a new plan of grand avenues, which was not adopted because property owners rebuilt on old lines. But Wren designed 51 new city churches, each with a distinct steeple, giving London a new skyline.",
    "His masterpiece, St. Paul's Cathedral (1675–1710), combines a Latin-cross plan with a great dome. The dome is actually three structures: an inner dome seen from inside, a hidden brick cone that supports the heavy stone lantern, and an outer timber-framed dome covered in lead that shapes the skyline. St. Paul's survived the Blitz in World War II and became a symbol of British resilience. Wren also designed the Royal Hospital at Greenwich and Chelsea."]],
  ["English Baroque and Blenheim",[
    "Wren's followers Nicholas Hawksmoor and John Vanbrugh created a bold English Baroque. Vanbrugh, a former soldier and playwright, designed Castle Howard (begun 1699) and Blenheim Palace (1705–1722), the nation's gift to the Duke of Marlborough for his victory over the French. Blenheim's massive, dramatic silhouette made it more a monument than a home.",
    "Hawksmoor's London churches, such as Christ Church Spitalfields, use heavy, unusual masses and stacked forms with a powerful, almost abstract quality. English Baroque was short-lived, giving way around 1715–1720 to Palladianism, which aristocratic patrons saw as more rational and less associated with Catholic absolutism."]],
  ["Central Europe and Spain",[
    "In Austria, Bavaria, and Bohemia, Baroque architecture flourished after the Thirty Years' War and the defeat of the Ottomans at Vienna in 1683. Johann Bernhard Fischer von Erlach designed the Karlskirche in Vienna (1716–1737), with two giant columns modeled on Trajan's Column; Lukas von Hildebrandt designed the Belvedere palaces. Balthasar Neumann's Würzburg Residence has a staircase vault painted by Giovanni Battista Tiepolo.",
    "In Spain and its colonies, the Churrigueresque style, named for the Churriguera family, covered surfaces with extraordinary ornament, often with estípites (inverted, tapering pilasters). It flourished in Mexico and Latin America, where indigenous craftsmen added their own motifs, as in the Sagrario Metropolitano in Mexico City. In Portugal and Brazil, gilded wood carving (talha dourada) and blue-and-white tile (azulejos) created distinctive Baroque interiors."]]
  ],
  terms:[["Mansard roof","A roof with two slopes on each side, the lower steeper, allowing living space in the attic."],["Parterre","A formal garden of flat beds edged with low hedges in ornamental patterns."],["Formal garden","A garden designed with geometric order, axes, and clipped plants."],["Steeple","A tall church tower, usually topped by a spire."],["Churrigueresque","An extremely ornate Spanish Baroque style."],["Azulejo","Painted, glazed ceramic tile, typical of Portugal and Spain."]],
  w:"Baroque palaces, gardens, and cathedrals show architecture as a tool of royal power, civic identity, and religious display across Europe and its empires.",
  src:["Palace of Versailles","André Le Nôtre","St Paul's Cathedral","Christopher Wren","Blenheim Palace","Churrigueresque"],
  q:[["What is a mansard roof?","A roof with two slopes on each side, the lower steeper","A flat roof with a garden","A dome on a drum","A roof of glass panels"],
     ["Why did Louis XIV move the nobility to Versailles?","To keep them under his control at court","To protect them from plague","To save money on palaces","To train them as architects"],
     ["Who designed the gardens of Versailles?","André Le Nôtre","Jules Hardouin-Mansart","Charles Le Brun","Louis Le Vau"],
     ["What is unusual about St. Paul's dome structure?","An inner dome, a hidden brick cone, and an outer timber dome","It is made entirely of glass","It has no lantern","It is supported by flying buttresses"],
     ["Blenheim Palace was a national gift to…","The Duke of Marlborough","King William III","Christopher Wren","Queen Anne"],
     ["Churrigueresque style is known for…","Extremely rich ornament with inverted tapering pilasters","Plain unornamented walls","Glass curtain walls","Pointed arches"]]},

{ t:"Rococo", s:"Lightness, curves, and the pleasure of interiors",
  sec:[
  ["From grandeur to intimacy",[
    "After Louis XIV died in 1715, French aristocrats left Versailles for Paris, building elegant town houses (hôtels particuliers) with smaller, more comfortable rooms. A new decorative style arose, later called Rococo, from French rocaille, the shell and rock work used in grottoes. It was lighter, more playful, and more intimate than the Baroque.",
    "Rococo was primarily a style of interiors and decoration rather than structure. It favored pale colors (white, cream, pastel blue, pink, and gold), asymmetrical curves, shells, flowers, scrolls, and C- and S-shaped curves, with mirrors and chandeliers multiplying light. The salons of the Hôtel de Soubise in Paris, decorated by Germain Boffrand in the late 1730s, are classic examples."]],
  ["Bavarian and Austrian Rococo churches",[
    "Rococo reached its most spectacular heights in the pilgrimage and abbey churches of southern Germany and Austria. The Wieskirche in Bavaria (1745–1754), by the brothers Dominikus and Johann Baptist Zimmermann, sits in a meadow; inside, white walls and columns support ceilings painted with an open heaven, and gilded stucco ornament seems to grow freely across every surface.",
    "Balthasar Neumann's Vierzehnheiligen (Basilica of the Fourteen Holy Helpers, 1743–1772) uses a complex sequence of interlocking ovals that dissolve the boundaries of the space, flooded with light from large windows. In these churches architecture, stucco, fresco, and sculpture fuse into a heavenly vision meant to delight rather than overwhelm."]],
  ["Palaces and pavilions",[
    "The Amalienburg, a hunting lodge in the gardens of Nymphenburg Palace in Munich (1734–1739) by François de Cuvilliés, has a circular Hall of Mirrors decorated with silver stucco on pale blue. In Potsdam, Frederick the Great's Sanssouci palace (1745–1747) was a single-story summer retreat on terraced vineyards where he could live 'without cares', as its name means.",
    "In Russia, Bartolomeo Rastrelli designed the Winter Palace in St. Petersburg (1754–1762) and the Catherine Palace at Tsarskoye Selo, with long facades in turquoise and white with gold details. The Catherine Palace's famous Amber Room was looted by German forces in World War II and lost; a reconstruction was completed in 2003."]],
  ["Chinoiserie and exoticism",[
    "Rococo designers loved exotic themes. Chinoiserie, a European fantasy of Chinese and East Asian design, appeared in porcelain rooms, lacquered panels, wallpaper, and garden pavilions. The Chinese House at Sanssouci and the Pagoda at Kew Gardens in London (1762, by William Chambers) are examples.",
    "These designs reflected Europe's growing global trade and fascination with Asia, though they rarely showed real understanding of Asian architecture. They also anticipated the eclectic borrowing of styles that would become widespread in the 19th century."]],
  ["Criticism and decline",[
    "By the mid-18th century, critics attacked Rococo as frivolous, irrational, and decadent, associated with an idle aristocracy. Enlightenment thinkers called for an architecture based on reason, nature, and the noble simplicity of the ancients. The rediscovery of Pompeii and Herculaneum and new studies of Greek temples encouraged a return to classical austerity.",
    "In 1753 the French priest Marc-Antoine Laugier published his 'Essay on Architecture', arguing that all true architecture derived from the 'primitive hut' of four tree-trunk columns, beams, and a pitched roof. Ornament not grounded in structure was suspect. This idea, that form should follow structural logic, would echo into modernism."]],
  ["Rococo's lasting influence",[
    "Despite its critics, Rococo left a deep mark on interior design, furniture (Louis XV style), porcelain, and decorative arts. It introduced the idea of rooms designed for comfort and conversation rather than state ceremony, and of specialized rooms such as boudoirs, dining rooms, and small salons.",
    "Rococo also shows that architecture is not only about grand structure. Light, color, surface, and decoration powerfully shape how a space feels. Interior design as a distinct discipline owes much to this era."]]
  ],
  terms:[["Rococo","A light, playful 18th-century decorative style with pastel colors, curves, and shells."],["Rocaille","Shell and rock ornament that gave Rococo its name."],["Hôtel particulier","A grand French town house."],["Chinoiserie","European decoration imitating Chinese and East Asian motifs."],["Primitive hut","Laugier's theoretical model of the origin of architecture in simple columns, beams, and a roof."]],
  w:"Rococo brought comfort, color, and intimacy into architecture, and the reaction against it launched the rational Neoclassical movement.",
  src:["Rococo","Wieskirche","Vierzehnheiligen","Sanssouci","Marc-Antoine Laugier","Chinoiserie"],
  q:[["The name Rococo comes from…","Rocaille, shell and rock ornament","A Spanish word for gold","An Italian architect named Rococo","A type of marble"],
     ["Rococo was primarily a style of…","Interiors and decoration","Engineering and bridges","City planning","Fortifications"],
     ["The Wieskirche was designed by…","The Zimmermann brothers","Balthasar Neumann","François de Cuvilliés","Bartolomeo Rastrelli"],
     ["What does 'Sanssouci' mean?","Without cares","Sun palace","House of mirrors","Garden of kings"],
     ["Laugier's 'primitive hut' argued that architecture should…","Derive from simple structural elements","Be covered in shells","Imitate Chinese pagodas","Avoid columns entirely"],
     ["Chinoiserie was…","A European fantasy of East Asian design","An authentic Chinese building method","A Roman garden type","A style of fortification"]]},

{ t:"Neoclassicism", s:"Reason, archaeology, and the return to antiquity",
  sec:[
  ["Rediscovering the ancients",[
    "Neoclassicism arose in the mid-18th century, fueled by Enlightenment ideals of reason and by archaeology. Excavations at Herculaneum (from 1738) and Pompeii (from 1748) revealed real Roman houses and decoration. Travelers measured Greek temples at Paestum in Italy and in Greece itself; James Stuart and Nicholas Revett's 'Antiquities of Athens' (from 1762) published accurate drawings.",
    "The German scholar Johann Joachim Winckelmann praised the 'noble simplicity and quiet grandeur' of Greek art. Giovanni Battista Piranesi's dramatic etchings of Roman ruins (and his imaginary 'Prisons') spread a sense of Roman grandeur. Architects sought an architecture of clear geometry, restrained ornament, and moral seriousness, in contrast to Rococo."]],
  ["France: Soufflot and the visionaries",[
    "Jacques-Germain Soufflot's church of Sainte-Geneviève in Paris (begun 1757), later the Panthéon, combined Greek-style freestanding columns inside with Gothic structural lightness. After the Revolution, it became a mausoleum for great French citizens, from Voltaire to Marie Curie.",
    "The 'visionary architects' Étienne-Louis Boullée and Claude-Nicolas Ledoux imagined buildings of pure, gigantic geometric forms. Boullée's unbuilt Cenotaph for Newton (1784) was a sphere about 150 meters high, pierced with holes so daylight inside would mimic the stars. Ledoux built the Royal Saltworks at Arc-et-Senans (1775–1779), planned as a semicircle around the director's house, and a ring of tollgates around Paris. Their work anticipated modernism's love of pure forms."]],
  ["Britain: Adam and Soane",[
    "In Britain, Robert Adam (1728–1792) developed a light, elegant Neoclassicism based on Roman domestic decoration he had studied, with delicate plaster ceilings, pastel colors, and designs that coordinated architecture, furniture, carpets, and fittings, as at Syon House and Kenwood House near London. The 'Adam style' was widely copied.",
    "Sir John Soane (1753–1837) developed a highly personal Neoclassicism of shallow domes, top lighting, and abstracted ornament. His Bank of England interiors were mostly demolished in the 1920s, but his Dulwich Picture Gallery (1811–1817), one of the first purpose-built public art galleries, pioneered top-lit galleries. His house in London, crammed with antiquities and ingenious lighting, is now Sir John Soane's Museum."]],
  ["Greek Revival",[
    "From about 1800, the Greek Revival favored the more severe Greek orders, especially the Doric. In Germany, Karl Friedrich Schinkel designed the Altes Museum in Berlin (1823–1830), with a long Ionic colonnade and a central rotunda modeled on the Pantheon, and Leo von Klenze designed Munich's Glyptothek and the Walhalla, a Parthenon-like temple on a hill above the Danube.",
    "In Britain, the British Museum's facade by Robert Smirke (1823–1847) is a great Greek Revival colonnade. Edinburgh, nicknamed the 'Athens of the North', has a Greek Revival New Town and an unfinished replica of the Parthenon, the National Monument on Calton Hill. Greek Revival was also chosen by the newly independent Greece for its capital Athens."]],
  ["Neoclassicism in Russia and America",[
    "Catherine the Great and her successors used Neoclassicism to build St. Petersburg as a European capital, employing architects such as Charles Cameron and Giacomo Quarenghi. Later, Carlo Rossi designed vast ensembles, including the General Staff Building with its triumphal arch facing Palace Square.",
    "In the United States, Neoclassicism expressed the ideals of a new republic consciously modeled on Athens and Rome. Thomas Jefferson designed the Virginia State Capitol (1785–1798) based on the Roman Maison Carrée at Nîmes, and the University of Virginia's 'Academical Village' (1817–1826), with a Pantheon-inspired Rotunda library. The US Capitol and White House, begun in the 1790s, and countless Greek Revival courthouses, banks, and houses followed."]],
  ["The meaning of Neoclassicism",[
    "Neoclassicism linked architecture to ideas of civic virtue, democracy, education, and reason. It became the style of museums, parliaments, courts, banks, and universities, institutions that wanted to look rational, stable, and timeless.",
    "But classicism could serve any political system. It was used by revolutionary France and Napoleon's empire (the Arc de Triomphe, begun 1806), by monarchies, and later by 20th-century dictatorships, as in Albert Speer's designs for Nazi Berlin and Stalinist buildings in Moscow. Its history shows that architectural styles do not have fixed political meanings; their meaning depends on context."]]
  ],
  terms:[["Neoclassicism","A movement from the mid-18th century reviving the forms and spirit of Greek and Roman architecture."],["Greek Revival","A phase of Neoclassicism closely modeled on ancient Greek temples."],["Visionary architecture","Designs, often unbuilt, imagining radical new forms, as by Boullée and Ledoux."],["Rotunda","A round building or room, usually domed."],["Colonnade","A row of columns supporting a roof or entablature."]],
  w:"Neoclassicism made classical forms the language of museums, parliaments, and republics, and its pure geometry anticipated modern architecture.",
  src:["Neoclassical architecture","Panthéon","Étienne-Louis Boullée","Robert Adam","Karl Friedrich Schinkel","Greek Revival architecture"],
  q:[["Which excavations helped inspire Neoclassicism?","Herculaneum and Pompeii","Troy and Mycenae","Knossos and Thera","Angkor and Bagan"],
     ["Boullée's Cenotaph for Newton was designed as…","A giant sphere","A pyramid","A pointed spire","A glass box"],
     ["Who is known for elegant interiors coordinating architecture, furniture, and ceilings?","Robert Adam","John Vanbrugh","Inigo Jones","Charles Barry"],
     ["The Altes Museum in Berlin was designed by…","Karl Friedrich Schinkel","Leo von Klenze","Robert Smirke","Claude-Nicolas Ledoux"],
     ["Jefferson's Virginia State Capitol was modeled on…","The Maison Carrée at Nîmes","The Parthenon","St. Peter's","The Pantheon"],
     ["What does the history of Neoclassicism suggest about style and politics?","Styles can serve very different political systems","Classicism is always democratic","Only monarchies used classicism","Style has no relation to power"]]},

{ t:"Georgian, Colonial, and Federal", s:"The classical house and the planned town",
  sec:[
  ["The Georgian house",[
    "Georgian architecture is named for the four King Georges of Britain (1714–1830). It applied Palladian and classical principles to ordinary buildings, especially houses. A typical Georgian house is symmetrical, with a central door, often with a fanlight (a semicircular window above), evenly spaced sash windows, a balanced facade of brick or stone, and a modest cornice or parapet.",
    "Georgian rules of proportion helped even small houses look dignified. Windows often diminished in height on upper floors, with the tallest on the piano nobile. Builders used pattern books such as James Gibbs's 'Book of Architecture' (1728) and countless builders' manuals, which spread the style through Britain, Ireland, and the colonies."]],
  ["Squares, terraces, and crescents",[
    "Georgian urban development created a beautiful and practical form: rows of attached houses (terraces) with unified facades, arranged around squares with private gardens. London's West End developed in this way, on estates owned by aristocratic landlords who leased land to builders, as at Bedford Square (1775–1783).",
    "In Bath, John Wood the Elder and his son John Wood the Younger built the Circus (begun 1754), a circle of three curved terraces, and the Royal Crescent (1767–1774), a sweeping semi-ellipse of 30 houses behind a continuous Ionic facade facing a park. Edinburgh's New Town (planned 1767 by James Craig) and Dublin's Georgian squares show the same approach. Notably, behind the uniform facades, each house was often built and finished differently by individual owners."]],
  ["Colonial America",[
    "In Britain's American colonies, Georgian ideas arrived through pattern books and immigrant builders, and were built in brick in Virginia and Maryland and in wood in New England. Williamsburg, Virginia's colonial capital, has been reconstructed since the 1920s and shows a planned town with a main street linking the Capitol and the College of William & Mary.",
    "Other European colonists brought their own traditions. Dutch settlers in New York built stepped-gable brick houses; Spanish colonists in Florida, New Mexico, and California built missions and adobe buildings; French colonists in Louisiana built raised houses with wide galleries suited to the hot, humid climate. The Spanish Laws of the Indies (codified 1573) required new towns in the Americas to be laid out around a central plaza on a grid."]],
  ["The Federal style",[
    "After independence, American architects developed the Federal style (about 1780–1830), a lighter, more delicate Neoclassicism inspired by Robert Adam. Federal houses have elliptical fanlights, slender columns, Palladian windows, and refined interior decoration, sometimes with oval or curved rooms.",
    "Charles Bulfinch of Boston designed the Massachusetts State House (1795–1798) with its gilded dome, and later worked on the US Capitol. Samuel McIntire created elegant Federal houses in Salem, Massachusetts. The style expressed a confident, refined new nation."]],
  ["Washington and the Capitol",[
    "Pierre Charles L'Enfant's 1791 plan for Washington, D.C., combined a grid of streets with diagonal avenues radiating from key sites like the Capitol and President's House, and a great open Mall. Benjamin Banneker, a free Black astronomer and surveyor, assisted Andrew Ellicott in surveying the federal district's boundaries.",
    "William Thornton's winning design for the US Capitol was begun in 1793; the building was burned by British troops in 1814, rebuilt, and expanded. Its current cast-iron dome, designed by Thomas U. Walter, was built from 1855 to 1866, partly during the Civil War. James Hoban, an Irish-born architect, designed the White House, influenced by Leinster House in Dublin. Enslaved people were among the laborers who built both buildings."]],
  ["Lessons of the Georgian era",[
    "Georgian architecture showed that consistent design rules could produce beautiful, coherent streets and towns, even when many different builders were involved. Its terraces and squares created dense, walkable, adaptable neighborhoods that remain among the most desired places to live.",
    "Architects and urbanists today study Georgian towns as models of 'gentle density': row houses at three to five stories, mixed with shops, squares, and parks. The period also shows how pattern books and standard details can raise the quality of ordinary building, not just monuments."]]
  ],
  terms:[["Georgian architecture","British and colonial classical architecture of 1714–1830."],["Fanlight","A semicircular or elliptical window over a door."],["Sash window","A window with sliding panels, usually moving vertically."],["Terrace","A row of attached houses with a unified facade."],["Crescent","A curved terrace of houses."],["Federal style","American Neoclassical architecture of about 1780–1830."]],
  w:"Georgian and Federal architecture shaped many of the most loved streets and towns in Britain, Ireland, and America through simple, consistent classical rules.",
  src:["Georgian architecture","Royal Crescent","Federal architecture","L'Enfant Plan","United States Capitol","Edinburgh New Town"],
  q:[["Georgian architecture is named after…","The four King Georges of Britain","The country of Georgia","An architect named George","St. George's Chapel"],
     ["Bath's Royal Crescent is…","A sweeping curved terrace of houses","A bridge","A royal palace","A Gothic cathedral"],
     ["Behind the uniform facades of Georgian terraces…","Houses were often built and finished individually","All rooms were identical","There were no gardens","Shops filled every floor"],
     ["The Spanish Laws of the Indies required new towns to be planned…","Around a central plaza on a grid","Along rivers only","As circular forts","Without streets"],
     ["Who designed the Massachusetts State House?","Charles Bulfinch","Thomas Jefferson","William Thornton","Benjamin Latrobe"],
     ["The current dome of the US Capitol is made of…","Cast iron","Stone","Timber","Concrete"]]}

);


/* ---- from arch-09.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 9: Unit 5 The Nineteenth Century, chapters 1-5 */
COURSES.architecture.units.push({ t:"The Nineteenth Century", ch:[

{ t:"Gothic Revival and the Battle of the Styles", s:"Pugin, Ruskin, and historicism",
  sec:[
  ["A century of revivals",[
    "The 19th century was an age of historicism: architects drew deliberately on past styles, chosen for their associations. Classical meant reason and republic; Gothic meant Christianity, nation, and the Middle Ages; Renaissance meant commerce and culture; and exotic styles suggested pleasure or empire. Debates over which style suited which building, and which suited the age, were called the 'battle of the styles'.",
    "Industrialization, new wealth, railways, and growing cities created vast demand for new buildings: churches, town halls, railway stations, schools, museums, and houses. Archaeology and printed books gave architects a huge catalog of historical forms to choose from."]],
  ["Early Gothic Revival",[
    "Gothic had never fully disappeared in Britain, but its revival as a fashionable style began in the 18th century with Horace Walpole's house Strawberry Hill (from 1749), a playful Gothic fantasy, and William Beckford's enormous Fonthill Abbey, whose tower collapsed in 1825. This early 'Gothick' was about mood and romance, related to the Gothic novel.",
    "Romanticism, which valued emotion, nature, and the past, encouraged admiration for medieval cathedrals. In Germany, the completion of Cologne Cathedral from 1842 became a national project. In France, Victor Hugo's novel 'Notre-Dame de Paris' (1831) spurred interest in restoring Gothic monuments."]],
  ["Pugin and the moral argument",[
    "Augustus Welby Northmore Pugin (1812–1852), a Catholic convert, argued in 'Contrasts' (1836) and 'The True Principles of Pointed or Christian Architecture' (1841) that Gothic was the only true Christian architecture and that architecture reflected the moral health of society. He insisted that ornament should enrich construction, not hide it, and that a building's design should express its purpose honestly.",
    "Pugin designed the interiors, furniture, and details of the Palace of Westminster (Houses of Parliament), rebuilt after a fire in 1834, with Charles Barry as architect. Barry gave it a symmetrical classical plan, and Pugin covered it in Perpendicular Gothic detail, including the clock tower housing Big Ben, renamed the Elizabeth Tower in 2012. Pugin reportedly called it 'all Grecian... Tudor details on a classic body'."]],
  ["Ruskin and Victorian Gothic",[
    "John Ruskin (1819–1900), art critic and social thinker, wrote 'The Seven Lamps of Architecture' (1849) and 'The Stones of Venice' (1851–1853). He celebrated the Gothic of Venice and Italy, with its colored materials, and argued that medieval craftsmen had found joy and freedom in their work, unlike the degraded factory workers of industrial Britain. Imperfection, he said, was a sign of human life.",
    "Ruskin's ideas inspired High Victorian Gothic, with its bold polychromy (multicolored brick and stone). William Butterfield's All Saints, Margaret Street, London (1850–1859) and George Gilbert Scott's Midland Grand Hotel at St Pancras Station (1868–1876) are examples. Gothic spread to universities, from Oxford's University Museum to Yale and the University of Chicago, and to parliaments, including Ottawa and Budapest."]],
  ["Restoration and Viollet-le-Duc",[
    "In France, Eugène Viollet-le-Duc (1814–1879) restored Notre-Dame, Carcassonne, Vézelay, and Mont-Saint-Michel. He believed in restoring buildings to a complete state 'that may never have existed at any given time', which some critics today see as too free. Ruskin and later William Morris opposed such 'restoration' as falsification, favoring careful repair; Morris founded the Society for the Protection of Ancient Buildings in 1877.",
    "Viollet-le-Duc was also a major theorist. He analyzed Gothic as a rational structural system, where each part had a function, and argued that modern architects should use new materials like iron in the same rational spirit. This thinking influenced later architects from Antoni Gaudí to the modernists."]],
  ["Eclecticism around the world",[
    "Historicism produced a rich eclecticism. The Paris Opéra (Palais Garnier, 1861–1875) by Charles Garnier is a lavish Neo-Baroque showpiece. The Neo-Renaissance was used for banks and clubs; the Neo-Romanesque for churches and courthouses; 'Moorish' and 'Indo-Saracenic' styles for theaters, synagogues, and colonial buildings in India, such as the Chhatrapati Shivaji Terminus in Mumbai (1878–1888), which blends Victorian Gothic and Indian motifs.",
    "Critics later dismissed historicism as imitation without conviction. But it produced some magnificent buildings and grappled with a real question still alive today: what should architecture look like in an age with no single shared style?"]]
  ],
  terms:[["Historicism","The use of past architectural styles, chosen for their associations."],["Gothic Revival","The 18th- and 19th-century revival of Gothic architecture."],["Polychromy","The use of many colors, especially in brick or stone."],["Eclecticism","Combining or choosing freely from different historical styles."],["Battle of the styles","The 19th-century debate over which historical style was appropriate."]],
  w:"The Gothic Revival introduced the moral and rational arguments about honesty and structure that later shaped modern architecture.",
  src:["Gothic Revival architecture","Augustus Pugin","John Ruskin","Palace of Westminster","Eugène Viollet-le-Duc","Chhatrapati Shivaji Terminus"],
  q:[["What did 'historicism' mean in 19th-century architecture?","Deliberately using past styles for their associations","Studying only modern materials","Preserving buildings unchanged","Building only for historians"],
     ["Pugin argued that Gothic was…","The only true Christian architecture","Too expensive for churches","Suitable only for castles","A barbaric style"],
     ["Who were the architects of the Palace of Westminster?","Charles Barry and A. W. N. Pugin","John Nash and John Soane","George Gilbert Scott and William Butterfield","Christopher Wren and Nicholas Hawksmoor"],
     ["Ruskin valued imperfection in medieval craft as…","A sign of human life and creative freedom","Evidence of poor training","A defect to eliminate","A religious punishment"],
     ["Viollet-le-Duc's restorations were criticized for…","Completing buildings to states that may never have existed","Leaving buildings in ruins","Using only modern steel","Demolishing cathedrals"],
     ["The Chhatrapati Shivaji Terminus in Mumbai combines…","Victorian Gothic and Indian motifs","Greek Revival and Art Deco","Japanese and Brutalist forms","Baroque and Bauhaus"]]},

{ t:"Iron, Glass, and the Engineers", s:"Crystal Palace, railway stations, and the Eiffel Tower",
  sec:[
  ["The Industrial Revolution's materials",[
    "The Industrial Revolution made iron cheap and plentiful. Cast iron, strong in compression but brittle, was used for columns. Wrought iron, more ductile and stronger in tension, was used for beams and ties. From the 1850s, the Bessemer process made steel, stronger and more reliable than both, available in quantity; by the 1880s steel was replacing iron in large structures.",
    "Iron first appeared in bridges and industrial buildings. The Iron Bridge at Coalbrookdale in England (1779), the first major bridge made of cast iron, used joints copied from carpentry. Iron-framed textile mills, such as Ditherington Flax Mill in Shrewsbury (1797), often described as the world's first iron-framed building, were early ancestors of the skyscraper."]],
  ["Glasshouses and the Crystal Palace",[
    "Gardeners led the way in iron and glass. Greenhouses for tropical plants, such as the Palm House at Kew (1844–1848), by Decimus Burton and Richard Turner, used curved iron ribs and glass panes. Joseph Paxton, gardener to the Duke of Devonshire, built a great conservatory at Chatsworth and a lily house inspired by the ribbed leaves of the giant water lily.",
    "Paxton's design for the Great Exhibition of 1851 in London, the Crystal Palace, was a vast hall of iron and glass about 563 meters long, built from standardized, prefabricated parts in about nine months. It enclosed full-grown elm trees. It was dismantled and re-erected at Sydenham, where it burned down in 1936. The Crystal Palace demonstrated prefabrication, modular design, and speed of construction, ideas central to modern architecture."]],
  ["Railway stations and markets",[
    "Railways created a new building type with a dual nature: a monumental stone headhouse facing the city, often in a historical style, and behind it an engineered train shed of iron and glass. London's St Pancras Station has a shed by William Henry Barlow (1868) spanning about 73 meters, at the time the largest single-span roof in the world, in front of which stands Scott's Gothic hotel.",
    "Iron and glass also covered markets (Les Halles in Paris, 1850s–1870s, demolished in 1971), department stores, exhibition halls, libraries, and shopping arcades such as the Galleria Vittorio Emanuele II in Milan (1865–1877). Henri Labrouste's Bibliothèque Sainte-Geneviève (1843–1851) and the reading room of the Bibliothèque nationale in Paris exposed elegant iron structures inside dignified masonry shells."]],
  ["The Eiffel Tower",[
    "Gustave Eiffel's company, already famous for bridges and the internal iron frame of the Statue of Liberty (1886), built the Eiffel Tower for the Paris Exposition Universelle of 1889, marking the centenary of the French Revolution. The design was largely developed by Eiffel's engineers Maurice Koechlin and Émile Nouguier, with architect Stephen Sauvestre.",
    "At about 300 meters (now around 330 with antennas), it was the tallest structure in the world until the Chrysler Building in 1930. Made of about 18,000 wrought-iron parts held by some 2.5 million rivets, it was assembled in about two years. Its curved profile was shaped to resist wind. Many artists signed a protest against it, but it became the symbol of Paris and of modern engineering. It was meant to stand for 20 years but survived partly because of its usefulness for radio."]],
  ["Engineers versus architects",[
    "In the 19th century, a gap opened between engineers, who built bridges, stations, and factories with new materials, and architects, who mostly designed in historical styles. Critics such as Viollet-le-Duc argued that the engineers were the true architects of the age. The Galerie des Machines at the 1889 Paris Exposition, a hall about 115 meters wide spanned by three-hinged steel arches, was as astonishing as the tower.",
    "Great engineers of the era included Isambard Kingdom Brunel (railways, bridges, and ships), Thomas Telford, and John and Washington Roebling, whose Brooklyn Bridge (1869–1883) was the longest suspension bridge in the world when completed. Emily Warren Roebling played a key role in supervising its construction after her husband became ill."]],
  ["Why this matters",[
    "Iron and glass architecture introduced the frame, prefabrication, standardization, transparency, and large spans: the building blocks of modern architecture. It also raised the question of whether architecture should express new materials honestly or clothe them in historical forms.",
    "The 20th century answered with the modern movement, which embraced the engineer's aesthetic. Le Corbusier would praise grain silos, ships, and airplanes as models for architects. The glass-and-steel buildings of today descend directly from the conservatories and train sheds of the 19th century."]]
  ],
  terms:[["Cast iron","Iron poured into molds; strong in compression but brittle."],["Wrought iron","Worked iron, more ductile and better in tension than cast iron."],["Bessemer process","A method of mass-producing steel by blowing air through molten iron, patented in the 1850s."],["Prefabrication","Manufacturing building parts off-site for assembly on-site."],["Train shed","The large covered structure over railway platforms."],["Suspension bridge","A bridge whose deck hangs from cables strung between towers."]],
  w:"Engineers using iron, steel, and glass created the frame, the large span, and prefabrication, laying the technical foundations of modern architecture.",
  src:["The Crystal Palace","Eiffel Tower","Iron Bridge","St Pancras railway station","Brooklyn Bridge","Bessemer process"],
  q:[["Cast iron is…","Strong in compression but brittle","Strong in tension but weak in compression","Flexible and lightweight","Transparent"],
     ["Who designed the Crystal Palace?","Joseph Paxton","Gustave Eiffel","Decimus Burton","Isambard Kingdom Brunel"],
     ["The Crystal Palace demonstrated…","Prefabrication and modular construction","The pointed arch","Concrete domes","Rammed earth"],
     ["Railway stations typically combined…","A stone headhouse and an iron-and-glass train shed","Two Gothic towers","A wooden hall and brick shed","A Greek temple and a dome"],
     ["The Eiffel Tower was built for…","The 1889 Paris Exposition Universelle","The 1851 Great Exhibition","The 1900 Olympics","Napoleon's coronation"],
     ["Who helped supervise the Brooklyn Bridge's construction after her husband fell ill?","Emily Warren Roebling","Marie Curie","Florence Nightingale","Ada Lovelace"]]},

{ t:"Beaux-Arts and Academic Architecture", s:"The Paris school and the grand plan",
  sec:[
  ["The École des Beaux-Arts",[
    "The École des Beaux-Arts in Paris, reorganized in 1819, was the world's leading school of architecture through the 19th and early 20th centuries. Students worked in ateliers (studios) led by practicing architects and competed in a demanding series of design competitions; the highest prize, the Prix de Rome, sent winners to study in Rome.",
    "Beaux-Arts teaching emphasized the plan above all. Students learned to solve a design problem quickly in an initial sketch, the esquisse, and then develop it into elaborate presentation drawings rendered in watercolor. The parti, the basic organizing idea of a design, had to be clear. These concepts, including 'parti' and the critique-based studio, still shape architectural education worldwide."]],
  ["Principles of composition",[
    "Beaux-Arts design was based on axial symmetry, clear hierarchy, and a logical sequence of spaces. A building was composed of major and minor elements arranged along axes and cross-axes, with grand stairs, vestibules, and halls marking the route through it. Circulation, the way people move through a building, was carefully choreographed.",
    "Externally, buildings used classical (often French Renaissance and Baroque) vocabulary: paired columns, rich sculpture, mansard roofs, and grand entrance sequences. The Paris Opéra by Charles Garnier, with its spectacular grand staircase designed for the social theater of seeing and being seen, is the quintessential example."]],
  ["Beaux-Arts in America",[
    "American architects flocked to Paris to study; Richard Morris Hunt was the first American to attend, in the 1840s. Hunt designed the Biltmore Estate in North Carolina and the main facade of the Metropolitan Museum of Art. The firm of McKim, Mead & White designed the Boston Public Library (1888–1895), the original Pennsylvania Station (1910), and much of Columbia University.",
    "Grand Central Terminal in New York (1913), by Reed & Stem and Warren & Wetmore, combines Beaux-Arts grandeur with ingenious engineering: multiple levels separating trains, pedestrians, and traffic. Its main concourse ceiling is painted with constellations. The New York Public Library (1911) by Carrère and Hastings is another masterpiece."]],
  ["The World's Columbian Exposition and City Beautiful",[
    "The World's Columbian Exposition of 1893 in Chicago, overseen by Daniel Burnham with landscape architect Frederick Law Olmsted, created the 'White City', a unified ensemble of white classical buildings around a formal basin. It left a huge impression on Americans, who saw in it a vision of order, civic grandeur, and beauty.",
    "This inspired the City Beautiful movement, which aimed to improve American cities with grand boulevards, civic centers, parks, and monuments, believing beauty could promote civic virtue. Burnham's 1909 Plan of Chicago, with Edward Bennett, proposed lakefront parks, diagonal avenues, and a monumental civic center; his famous motto was 'Make no little plans'. The McMillan Plan of 1902 reshaped the National Mall in Washington."]],
  ["Beaux-Arts around the world",[
    "Beaux-Arts graduates designed buildings worldwide: the Palacio de Bellas Artes in Mexico City, the Teatro Colón in Buenos Aires, government buildings in colonial capitals, and grand railway stations. The Petit Palais and Grand Palais in Paris, built for the 1900 Exposition, show the style at its most exuberant.",
    "The style also shaped urban design in colonial cities, such as Edwin Lutyens and Herbert Baker's New Delhi (inaugurated 1931), with its great axis, Rajpath (now Kartavya Path), leading to the Viceroy's House (now Rashtrapati Bhavan). Lutyens combined classical order with Indian elements like the chhatri (domed pavilion) and the Buddhist stupa."]],
  ["Decline and rediscovery",[
    "Modernists in the 20th century rejected the Beaux-Arts as backward-looking, decorative, and undemocratic, and many architecture schools replaced its methods with Bauhaus-inspired teaching from the 1930s on. The demolition of New York's Penn Station in 1963–1964 shocked the public and helped launch the American historic preservation movement and New York's Landmarks Preservation Commission (1965).",
    "Today, Beaux-Arts buildings are widely loved and carefully preserved. Many architects again value its lessons: clear planning, ceremonial sequences of space, the integration of architecture with sculpture and landscape, and the dignity of public buildings."]]
  ],
  terms:[["Beaux-Arts","Academic classical architecture taught at the École des Beaux-Arts in Paris."],["Atelier","A studio where students worked under a master architect."],["Parti","The basic organizing idea or concept of a design."],["Esquisse","A quick initial design sketch."],["Circulation","The paths by which people move through a building."],["City Beautiful","A movement around 1900 to improve cities through grand civic design."]],
  w:"The Beaux-Arts tradition taught generations of architects to plan clearly and compose grand public spaces, and its methods still underlie architectural education.",
  src:["Beaux-Arts architecture","École des Beaux-Arts","Palais Garnier","Grand Central Terminal","World's Columbian Exposition","City Beautiful movement"],
  q:[["What did Beaux-Arts teaching emphasize most?","The plan and its clear organization","Steel construction","Asymmetry","Vernacular building"],
     ["The 'parti' is…","The basic organizing idea of a design","A grand staircase","A competition prize","A type of column"],
     ["Who was the first American to study at the École des Beaux-Arts?","Richard Morris Hunt","Daniel Burnham","Louis Sullivan","Thomas Jefferson"],
     ["The 'White City' was created for…","The 1893 World's Columbian Exposition in Chicago","The 1889 Paris Exposition","The 1851 Great Exhibition","The 1900 Olympics"],
     ["Whose motto was 'Make no little plans'?","Daniel Burnham","Frederick Law Olmsted","Charles McKim","Edwin Lutyens"],
     ["The demolition of which building helped launch the US preservation movement?","Penn Station in New York","The Crystal Palace","Les Halles","The Chicago White City"]]},

{ t:"Arts and Crafts", s:"Morris, honest craft, and the reform of the home",
  sec:[
  ["A reaction against industry",[
    "The Arts and Crafts movement arose in Britain in the second half of the 19th century as a reaction against shoddy machine-made goods, industrial ugliness, and the division of labor. Inspired by Ruskin, it championed handcraft, honest use of materials, simple forms, and the unity of the arts. Its leaders believed that beautiful, well-made everyday objects and buildings could improve lives and society.",
    "William Morris (1834–1896), designer, poet, publisher, and socialist, was its central figure. His firm, Morris & Co., produced wallpapers, textiles, stained glass, and furniture based on natural forms and medieval craft. His famous advice: 'Have nothing in your houses that you do not know to be useful, or believe to be beautiful'."]],
  ["The Red House",[
    "Morris's own home, the Red House in Bexleyheath near London (1859–1860), designed by his friend Philip Webb, is often called the first Arts and Crafts house. Built of red brick with steep tiled roofs, it was planned from the inside out: rooms were arranged for convenience, and windows placed where needed rather than for a symmetrical facade.",
    "The house was furnished and decorated by Morris and his artist friends, including Edward Burne-Jones and Dante Gabriel Rossetti. It drew on vernacular English building and medieval forms without copying any one style, and it pointed toward a freer, more functional approach to the house."]],
  ["Architects of the movement",[
    "Arts and Crafts architects designed comfortable, informal houses rooted in local building traditions: steep roofs, prominent chimneys, local stone, brick, timber, and roughcast render, with interiors of exposed wood, inglenooks (fireside seating alcoves), and built-in furniture. Charles Voysey's houses, with their long low roofs, white rendered walls, and green slate, were widely influential.",
    "Edwin Lutyens's early country houses, often with gardens by Gertrude Jekyll, combined Arts and Crafts craft with planting design; Jekyll's naturalistic borders of carefully arranged color shaped garden design worldwide. In Scotland, Charles Rennie Mackintosh blended Arts and Crafts with Scottish tradition and a new abstraction in the Glasgow School of Art (1897–1909), sadly gutted by fires in 2014 and 2018."]],
  ["Garden cities",[
    "Arts and Crafts ideas influenced planning. Ebenezer Howard's 'To-morrow: A Peaceful Path to Real Reform' (1898, reissued as 'Garden Cities of To-morrow') proposed self-contained towns of limited size, surrounded by green belts, combining the benefits of town and country, with land owned by the community.",
    "Letchworth Garden City (begun 1903), planned by Raymond Unwin and Barry Parker, and Welwyn Garden City (1920) put these ideas into practice with cottage-style houses on tree-lined streets. Earlier model villages for workers, such as Port Sunlight (begun 1888) by the Lever soap company and Bournville by the Cadbury family, also reflected the movement's ideals. Garden city ideas spread worldwide and shaped suburbs everywhere."]],
  ["America: Craftsman and the Prairie",[
    "In the United States, Gustav Stickley's magazine 'The Craftsman' (1901–1916) popularized simple oak furniture and the Craftsman bungalow, a modest one- or one-and-a-half-story house with a low-pitched roof, wide eaves, exposed rafters, and a deep porch. Bungalows were sold by catalog, including precut kits from Sears, Roebuck and Co.",
    "In California, the brothers Charles and Henry Greene built the Gamble House in Pasadena (1908–1909), an 'ultimate bungalow' of finely joined wood influenced by Japanese architecture. Frank Lloyd Wright's early Prairie houses also grew partly from Arts and Crafts ideals of craft, natural materials, and the unity of house and furnishings."]],
  ["Legacy",[
    "The Arts and Crafts movement had a paradox at its heart: handmade goods were expensive, so its products mostly served the wealthy, frustrating Morris's socialist ideals. Yet its principles of honesty to materials, fitness for purpose, and unified design passed directly into modernism. The Deutscher Werkbund, founded in 1907 in Germany, sought to combine craft quality with industrial production.",
    "Today, Arts and Crafts ideas echo in the appreciation of local materials, craftsmanship, sustainable design, and the idea that ordinary houses and objects deserve care. Its houses remain some of the most beloved domestic architecture in Britain and America."]]
  ],
  terms:[["Arts and Crafts movement","A late-19th-century movement promoting handcraft, honest materials, and unified design."],["Inglenook","A recessed seating area beside a fireplace."],["Garden city","A planned town of limited size surrounded by a green belt, as proposed by Ebenezer Howard."],["Bungalow","A modest, usually one-story house with a low roof and porch."],["Vernacular","Ordinary local building traditions using local materials."]],
  w:"Arts and Crafts reformers made the ordinary house and its furnishings a serious subject of design and passed on ideas of honesty and fitness for purpose to modernism.",
  src:["Arts and Crafts movement","William Morris","Red House, Bexleyheath","Garden city movement","Charles Rennie Mackintosh","Gamble House"],
  q:[["The Arts and Crafts movement reacted against…","Shoddy machine-made goods and industrial ugliness","Gothic architecture","Medieval craft","Natural materials"],
     ["Who designed William Morris's Red House?","Philip Webb","Charles Voysey","Edwin Lutyens","Augustus Pugin"],
     ["What is an inglenook?","A seating alcove beside a fireplace","A garden path","A roof window","A type of stained glass"],
     ["Who proposed the garden city?","Ebenezer Howard","William Morris","Raymond Unwin","John Ruskin"],
     ["The Gamble House in Pasadena was designed by…","Charles and Henry Greene","Frank Lloyd Wright","Gustav Stickley","Louis Sullivan"],
     ["What paradox troubled the Arts and Crafts movement?","Handmade goods were expensive and mostly served the wealthy","It rejected all decoration","It used only machines","It refused to build houses"]]},

{ t:"Art Nouveau and Gaudí", s:"Organic curves and a new style",
  sec:[
  ["A truly new style",[
    "Art Nouveau ('New Art') flourished from about 1890 to 1910 across Europe. Unlike historicism, it sought a style that copied no past period. Its designers took inspiration from nature, especially plants, flowers, and the curving 'whiplash' line, and used new materials such as iron and glass expressively. They aimed for the Gesamtkunstwerk, the total work of art, designing everything from facades to door handles.",
    "The style took different names and forms across Europe: Jugendstil in Germany, Secession in Austria, Modernisme in Catalonia, Stile Liberty in Italy, and Modern in Russia. It appeared in houses, department stores, cafés, metro entrances, and posters."]],
  ["Horta and Brussels",[
    "Victor Horta's Hôtel Tassel in Brussels (1893) is often called the first Art Nouveau building. Its interior features slender iron columns that branch like plant stems, mosaic floors and painted walls with flowing lines, and a stair hall lit from above. Horta exposed iron structure in a house and made it decorative.",
    "Horta's own house and studio and the Hôtel Solvay are now part of a UNESCO World Heritage Site. His Maison du Peuple (1899), a socialist workers' center with an iron and glass facade, was demolished in 1965, a loss still mourned. Brussels has many Art Nouveau houses by Horta, Paul Hankar, and others."]],
  ["Paris, Nancy, and Guimard",[
    "Hector Guimard designed the famous entrances to the Paris Métro (around 1900), with cast-iron stems, glass canopies, and lamps like plant buds. They were prefabricated in standard parts and could be adapted to different sites. His Castel Béranger apartment building (1895–1898) brought the style to Paris.",
    "In Nancy, the École de Nancy designers, led by Émile Gallé in glass and Louis Majorelle in furniture, created a strong regional Art Nouveau. The Villa Majorelle (1901–1902) is a complete example. Elsewhere, Riga in Latvia has one of the largest concentrations of Art Nouveau buildings in the world."]],
  ["Vienna and the Secession",[
    "In Vienna, a group of artists led by Gustav Klimt broke away from the official academy in 1897 to form the Vienna Secession. Joseph Maria Olbrich's Secession Building (1897–1898), with its dome of gilded metal laurel leaves, bore the motto 'To every age its art, to art its freedom'.",
    "Otto Wagner, the leading Viennese architect, argued in 'Modern Architecture' (1896) that new needs and materials required new forms. His Postal Savings Bank (1904–1912) has a facade of marble panels attached with visible aluminum bolts and a glass-roofed banking hall, and his Steinhof Church has a gilded dome. Josef Hoffmann's Palais Stoclet in Brussels (1905–1911), with interiors including Klimt mosaics, moved toward geometric simplicity, pointing to modernism."]],
  ["Gaudí and Catalan Modernisme",[
    "Antoni Gaudí (1852–1926) of Barcelona developed a unique architecture based on nature, Catalan tradition, his Catholic faith, and structural innovation. Casa Batlló (remodeled 1904–1906) has a facade of colorful broken-tile mosaic (trencadís) and bone-like columns. Casa Milà, 'La Pedrera' (1906–1912), has an undulating stone facade and a rooftop of sculptural chimneys. Park Güell (1900–1914) is a fantastical hillside garden.",
    "Gaudí worked out structures using hanging chain models: chains hung under gravity form catenary curves in pure tension, and when inverted these give shapes in pure compression, ideal for masonry arches. At the Colònia Güell crypt, he used weighted string models to design leaning columns and vaults. His Basílica de la Sagrada Família, begun in 1882, is still under construction; its central Tower of Jesus Christ passed Ulm Minster in late 2025 to make it the tallest church in the world, and its crowning cross was installed in February 2026, the centenary year of Gaudí's death, bringing it to its full 172.5 meters, though work on other parts, including the main Glory facade, continues. Other Modernisme architects included Lluís Domènech i Montaner, whose Palau de la Música Catalana (1905–1908) is a jewel of glass and mosaic."]],
  ["From Art Nouveau to modernism",[
    "Art Nouveau was short-lived; by 1910 it seemed overly decorative and personal. The Austrian architect Adolf Loos attacked ornament in his essay 'Ornament and Crime' (first presented as a lecture in 1910), arguing that modern people no longer needed decoration. Many designers moved toward the geometric simplicity seen in Hoffmann and Mackintosh.",
    "Yet Art Nouveau was a crucial bridge. It broke with historical styles, embraced new materials, and pursued the unified design of everything in a building. Gaudí's structural experiments anticipated later engineers and digital form-finding, and his work, once seen as eccentric, now draws millions of visitors each year."]]
  ],
  terms:[["Art Nouveau","A decorative style of about 1890–1910 inspired by natural forms and curving lines."],["Gesamtkunstwerk","A 'total work of art' integrating all the arts in one design."],["Whiplash line","A sinuous, S-shaped curve characteristic of Art Nouveau."],["Trencadís","Mosaic made of broken tile fragments, used by Gaudí."],["Catenary","The curve formed by a hanging chain; inverted, it gives an ideal arch shape in pure compression."],["Secession","Austrian movement of artists who broke from the academy in 1897."]],
  w:"Art Nouveau was the first major break with historical styles, and Gaudí's structural experiments still inspire engineers and designers.",
  src:["Art Nouveau","Victor Horta","Vienna Secession","Antoni Gaudí","Sagrada Família","Catenary arch"],
  q:[["Which building is often called the first Art Nouveau building?","Hôtel Tassel in Brussels","Casa Batlló in Barcelona","The Secession Building in Vienna","The Red House"],
     ["Who designed the Art Nouveau entrances of the Paris Métro?","Hector Guimard","Victor Horta","Otto Wagner","Émile Gallé"],
     ["The Vienna Secession's motto was…","To every age its art, to art its freedom","Form follows function","Less is more","Make no little plans"],
     ["Gaudí designed arches using hanging chains because…","Inverted, they give curves in pure compression","Chains were cheaper than stone","They made the arches move","He wanted to use steel cables"],
     ["What is trencadís?","Mosaic made of broken tile pieces","Twisted iron columns","A curving roof","Stained glass"],
     ["Who wrote 'Ornament and Crime'?","Adolf Loos","Otto Wagner","Josef Hoffmann","Charles Rennie Mackintosh"]]}

]});


/* ---- from arch-10.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 10: Unit 5 The Nineteenth Century, chapters 6-7 */
COURSES.architecture.units[4].ch.push(

{ t:"The Chicago School and the Skyscraper", s:"Steel frames, elevators, and form follows function",
  sec:[
  ["Why the skyscraper was born in America",[
    "The skyscraper emerged in the United States in the 1880s from a combination of rising land values in dense downtowns, new technology, and commercial ambition. Chicago and New York were the main laboratories. After the Great Chicago Fire of 1871 destroyed much of the city's center, a building boom attracted talented architects and engineers.",
    "Two technologies were essential. The safe passenger elevator, demonstrated by Elisha Otis in 1854 with a safety brake that stopped the car if the cable broke, made upper floors as valuable as lower ones. And the metal skeleton frame meant walls no longer had to carry the building's weight. Fireproofing with terracotta tiles, central heating, electric lighting, and the telephone completed the package."]],
  ["The steel frame",[
    "Before the frame, tall buildings needed enormously thick masonry walls at the base. The 16-story Monadnock Building in Chicago (1891), by Burnham & Root, has load-bearing brick walls about 1.8 meters thick at the bottom, close to the practical limit for masonry. Its northern half is almost free of ornament, its power coming from its flaring, sculpted mass.",
    "William Le Baron Jenney's Home Insurance Building in Chicago (1885, demolished 1931) is often cited as the first skyscraper because it used a metal frame to carry much of its weight, though historians debate the claim. With a full steel skeleton, walls became a thin 'curtain' hung on the frame, and buildings could rise far higher with large windows. The 'Chicago window', a large fixed central pane flanked by two narrow opening sashes, maximized light and air."]],
  ["Louis Sullivan",[
    "Louis Sullivan (1856–1924), working with the engineer Dankmar Adler, gave the skyscraper its first convincing artistic form. In the essay 'The Tall Office Building Artistically Considered' (1896), he argued that a tall building should be 'every inch a proud and soaring thing' and proposed a three-part composition like a classical column: a base for shops and entrance, a shaft of repeated office floors, and a capital or crown at the top for mechanical equipment.",
    "The same essay contains his famous phrase 'form ever follows function', later shortened to 'form follows function' and adopted as a modernist slogan, though Sullivan himself loved lavish organic ornament. His Wainwright Building in St. Louis (1891) and Guaranty Building in Buffalo (1896) express their vertical structure clearly, and his Carson Pirie Scott store in Chicago (1899–1904) has wide Chicago windows above an entrance of swirling cast iron. Sullivan's assistant was a young Frank Lloyd Wright."]],
  ["New York and the race for height",[
    "New York's skyscrapers tended to be more historical in style and competitive in height. The Flatiron Building (1902), by Daniel Burnham, occupies a narrow triangular site. The Woolworth Building (1913), by Cass Gilbert, was called the 'Cathedral of Commerce' for its Gothic detail and was the world's tallest building until 1930.",
    "Concerns about tall buildings blocking light and air, especially after the massive Equitable Building (1915), led to New York's 1916 Zoning Resolution, the first comprehensive zoning law in the United States. It required buildings to step back as they rose, within an angled 'envelope', which produced the characteristic wedding-cake setbacks of 1920s skyscrapers. Hugh Ferriss's moody charcoal drawings of these envelopes shaped the era's imagination."]],
  ["Art Deco towers",[
    "The race for height peaked around 1930. The Chrysler Building (1930), by William Van Alen, briefly the world's tallest, has a stainless-steel crown of stacked sunbursts and a spire secretly assembled inside the building and raised into place to beat a rival. The Empire State Building (1931), by Shreve, Lamb & Harmon, at 102 stories and 381 meters, was built in about 13 months and held the title of world's tallest building for nearly 40 years.",
    "Rockefeller Center (1930s) introduced a planned complex of towers, plazas, and underground connections, combining commerce with public space and art. These buildings made the skyscraper a symbol of modern America and of the modern city in general."]],
  ["What the skyscraper changed",[
    "The skyscraper transformed cities. It enabled extreme densities, concentrated business districts, and new urban skylines that became civic symbols. It also created new problems: shadows, congestion, wind effects at street level, and the dependence on mechanical systems for light, air, and movement.",
    "The skyscraper's basic elements, the frame, curtain wall, elevator core, and zoning envelope, remain the foundation of tall building design today. The Chicago School's direct expression of structure and function was a key step toward modernism, and Chicago's buildings are still studied as a living museum of the tall building."]]
  ],
  terms:[["Skyscraper","A very tall, multistory building made possible by the steel frame and elevator."],["Skeleton frame","A structural frame of columns and beams that carries a building's loads."],["Curtain wall","A non-load-bearing outer wall hung on a building's frame."],["Chicago window","A large fixed central window flanked by two narrow operable windows."],["Setback","A step back in a building's facade as it rises, often required by zoning."],["Zoning","Laws regulating the use, size, and shape of buildings in areas of a city."]],
  w:"The skyscraper reshaped the modern city, and its frame, curtain wall, and elevator remain the core technologies of tall buildings.",
  src:["Chicago school (architecture)","Louis Sullivan","Home Insurance Building","Monadnock Building","1916 Zoning Resolution","Empire State Building"],
  q:[["Which invention made upper floors practical and valuable?","The safety elevator","The telephone","The light bulb","The typewriter"],
     ["Why are the Monadnock Building's base walls so thick?","They are load-bearing masonry carrying the building's weight","To resist cannon fire","To hold water tanks","For insulation only"],
     ["Who wrote that 'form ever follows function'?","Louis Sullivan","Frank Lloyd Wright","Daniel Burnham","Ludwig Mies van der Rohe"],
     ["Sullivan proposed composing skyscrapers like…","A classical column with base, shaft, and capital","A Gothic cathedral","A pyramid","A cube"],
     ["What did New York's 1916 Zoning Resolution require?","Buildings to step back as they rose","A maximum height of 10 stories","All buildings to be Gothic","Glass facades"],
     ["Which building held the title of world's tallest for nearly 40 years after 1931?","The Empire State Building","The Chrysler Building","The Woolworth Building","The Flatiron Building"]]},

{ t:"Remaking the Nineteenth-Century City", s:"Haussmann, Cerdà, Olmsted, and public health",
  sec:[
  ["The industrial city's crisis",[
    "The Industrial Revolution drew millions into cities that were not built for them. Manchester, London, and other cities grew explosively, with overcrowded slums, polluted air and water, and epidemics. Cholera outbreaks in the 1830s–1850s killed tens of thousands. In 1854, the physician John Snow traced a London cholera outbreak to a contaminated water pump on Broad Street, an early milestone of epidemiology.",
    "Reformers argued that physical changes to the city, such as clean water, sewers, light, air, and parks, could improve health and morals. Joseph Bazalgette's London sewer system, built after the 'Great Stink' of 1858, carried waste away through huge brick-lined tunnels and embankments along the Thames, and is still largely in use. Engineering became as important as architecture in shaping cities."]],
  ["Haussmann's Paris",[
    "Under Emperor Napoleon III, Baron Georges-Eugène Haussmann, prefect of the Seine from 1853 to 1870, transformed Paris. He cut wide, straight boulevards through the crowded medieval city, linking railway stations, squares, and monuments, and built new sewers, water supply, parks such as the Bois de Boulogne and Buttes-Chaumont, street lighting, and public buildings.",
    "Haussmann regulated the buildings along the boulevards: uniform cornice lines, stone facades, and a set number of floors, with balconies typically on the second and fifth floors. The resulting unified streets of cream-colored apartment buildings define the image of Paris. But the works displaced many poorer residents to the outskirts, and critics argued the broad avenues were partly designed to make it harder to build barricades and easier to move troops."]],
  ["Vienna and Barcelona",[
    "In Vienna, the old city walls were demolished from 1857 and replaced by the Ringstrasse, a grand circular boulevard lined with public buildings in different historical styles: a Greek-style Parliament, a Gothic town hall, a Renaissance university, and Baroque-inspired museums and opera. The critic Camillo Sitte, in 'City Planning According to Artistic Principles' (1889), criticized such wide open spaces and praised the enclosed, irregular squares of older towns.",
    "In Barcelona, the engineer Ildefons Cerdà designed the Eixample (extension), approved in 1859–1860: a vast grid of blocks with chamfered (cut-off) corners that improve visibility and create small plazas at intersections. Cerdà based his plan on statistical studies of living conditions and coined the term 'urbanization'. He intended blocks to be built on only two or three sides, with gardens inside; over time most were filled in. Recent 'superblock' schemes in Barcelona have reclaimed some streets for pedestrians."]],
  ["Olmsted and the public park",[
    "The great public park was a 19th-century invention. Frederick Law Olmsted and Calvert Vaux won the 1858 competition for Central Park in New York with their 'Greensward Plan'. They created a seemingly natural landscape of meadows, woods, lakes, and rocky outcrops, almost entirely constructed, with sunken transverse roads carrying cross-town traffic beneath the park and separate paths for carriages, riders, and pedestrians.",
    "Olmsted believed parks were democratic spaces where people of all classes could restore themselves through contact with nature. He and his firm designed Prospect Park in Brooklyn, Boston's 'Emerald Necklace' park system, the grounds of the US Capitol, and the planned suburb of Riverside, Illinois, with curving streets. He is widely regarded as the founder of American landscape architecture."]],
  ["Housing reform",[
    "Housing for the working poor was a central problem. Reformers built model dwellings and pushed for regulations on light, ventilation, and sanitation. In New York, Jacob Riis's photographs in 'How the Other Half Lives' (1890) exposed tenement conditions, and the Tenement House Act of 1901 required windows in every room, toilets in each apartment, and courtyards for light and air.",
    "In Britain, philanthropists such as George Peabody and Octavia Hill funded improved housing, and local councils began building public housing late in the century; the London County Council's Boundary Estate (1890s) is an early example. These efforts laid the foundations for 20th-century social housing and building codes."]],
  ["Infrastructure as city-making",[
    "The 19th century showed that infrastructure, including water, sewers, transit, and streets, shapes cities as much as buildings do. London opened the world's first underground railway, the Metropolitan Railway, in 1863. Streetcars and commuter railways allowed cities to spread into suburbs, separating home from work.",
    "These changes created the modern city: zoned, serviced, connected by transport, with public parks and regulated buildings. They also raised lasting questions about who benefits from urban improvement and who is displaced, questions that urban planners still face whenever cities are redeveloped."]]
  ],
  terms:[["Boulevard","A wide, tree-lined city avenue."],["Haussmannization","Large-scale urban renewal by cutting broad avenues through old neighborhoods."],["Ringstrasse","Vienna's circular boulevard built on the site of the old city walls."],["Chamfered corner","A corner cut off at an angle, as in Barcelona's Eixample blocks."],["Landscape architecture","The design of outdoor spaces, parks, and landscapes."],["Tenement","A crowded, often substandard multi-family building."]],
  w:"The 19th-century city invented the modern tools of urbanism: infrastructure, public parks, building regulations, and comprehensive plans.",
  src:["Haussmann's renovation of Paris","Eixample","Ringstraße","Central Park","Frederick Law Olmsted","London sewer system"],
  q:[["Who traced a London cholera outbreak to a water pump in 1854?","John Snow","Joseph Bazalgette","Edwin Chadwick","Florence Nightingale"],
     ["Haussmann transformed which city?","Paris","Vienna","London","Barcelona"],
     ["Barcelona's Eixample grid was designed by…","Ildefons Cerdà","Antoni Gaudí","Camillo Sitte","Otto Wagner"],
     ["What are chamfered corners for in the Eixample?","Better visibility and small plazas at intersections","Defense against attack","Drainage","Hiding shops"],
     ["Who designed Central Park?","Frederick Law Olmsted and Calvert Vaux","Daniel Burnham and John Root","Pierre L'Enfant and Andrew Ellicott","Joseph Paxton and Decimus Burton"],
     ["What did New York's Tenement House Act of 1901 require?","Windows in every room and toilets in each apartment","Steel frames for all housing","A maximum of two families per building","Gardens on every roof"]]}

);


/* ---- from arch-11.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 11: Unit 6 Modernism, chapters 1-5 */
COURSES.architecture.units.push({ t:"Modernism", ch:[

{ t:"The Birth of Modern Architecture", s:"Werkbund, Expressionism, De Stijl, and Constructivism",
  sec:[
  ["What modernism wanted",[
    "Modern architecture, or modernism, emerged in Europe in the early 20th century and became the dominant approach worldwide after World War II. Modernists argued that architecture should be of its own time, not imitate the past. It should use new materials (steel, reinforced concrete, glass), new methods (industrial production), and respond to new social needs, especially decent housing for ordinary people.",
    "Shared ideas included the rejection of historical ornament, function as a starting point for design, honest expression of structure and materials, open and flexible plans, abundant light and air, and the belief that architecture could help build a better, more equal society. Within these principles, modernists differed enormously."]],
  ["Reinforced concrete",[
    "Reinforced concrete, concrete with embedded steel bars, combines concrete's strength in compression with steel's strength in tension. It was developed in France in the second half of the 19th century; François Hennebique patented a complete system in 1892. Concrete can be cast into frames, slabs, shells, and cantilevers of almost any shape.",
    "Auguste Perret's apartment building at 25 bis Rue Franklin in Paris (1903–1904) expressed its concrete frame on the facade, and his church of Notre-Dame du Raincy (1922–1923) used slender concrete columns and walls of concrete and glass screens. Perret later rebuilt the bombed city of Le Havre after World War II, now a UNESCO site. The young Le Corbusier worked in his office."]],
  ["The Werkbund and Behrens",[
    "The Deutscher Werkbund, founded in Munich in 1907, brought together architects, designers, and industrialists to raise the quality of German products through good design. Peter Behrens became artistic consultant to the electrical company AEG in 1907, designing everything from kettles and lamps to the company's logo and its Turbine Factory in Berlin (1909), a great hall of steel and glass with a temple-like dignity. He is often credited as one of the first corporate designers.",
    "Remarkably, Walter Gropius, Ludwig Mies van der Rohe, and Le Corbusier all worked in Behrens's office around 1910. Gropius and Adolf Meyer's Fagus Factory (begun 1911) has glass curtain walls that wrap around the corners without visible supports, one of the first truly modern buildings. The Werkbund exhibition in Cologne in 1914 included Bruno Taut's faceted Glass Pavilion."]],
  ["Expressionism",[
    "After World War I, some architects pursued Expressionism: dramatic, sculptural, emotional forms inspired by crystals, mountains, and organic shapes. Erich Mendelsohn's Einstein Tower in Potsdam (1919–1922), an observatory to test Einstein's theory of relativity, has flowing curved forms; it was intended to be concrete but was largely built of brick covered in render.",
    "Hans Poelzig's Grosses Schauspielhaus in Berlin (1919) had a ceiling of stalactite-like forms. In Amsterdam, architects of the Amsterdam School, such as Michel de Klerk, built expressive brick social housing with sculpted curves, as at Het Schip (1917–1920). Expressionist ideas of organic form and emotional effect resurfaced later in architects like Hans Scharoun and Eero Saarinen."]],
  ["De Stijl",[
    "De Stijl ('The Style') was a Dutch movement founded in 1917, including the painter Piet Mondrian and the designer Theo van Doesburg. It used only straight lines, right angles, the primary colors red, yellow, and blue, plus black, white, and gray, aiming at a universal, abstract harmony.",
    "Gerrit Rietveld's Schröder House in Utrecht (1924), designed with its owner Truus Schröder, is the movement's architectural masterpiece. Its facades are composed of intersecting planes and lines in white, gray, and primary colors, and its upper floor can be opened into one space or divided by sliding partitions. It is a UNESCO World Heritage Site and a manifesto of the open, flexible plan."]],
  ["Russian Constructivism",[
    "After the 1917 Revolution, Soviet Constructivists sought an architecture for a new socialist society, celebrating engineering, dynamism, and collective life. Vladimir Tatlin's Monument to the Third International (1919–1920), a spiraling iron tower meant to be taller than the Eiffel Tower with rotating rooms inside, was never built but became an icon.",
    "Built Constructivist works include Konstantin Melnikov's workers' clubs and his own cylindrical house in Moscow (1927–1929), pierced by hexagonal windows, and Moisei Ginzburg's Narkomfin Building (1928–1930), an experiment in communal living with shared kitchens and laundries; it was restored and reopened around 2020. Under Stalin in the 1930s, Constructivism was suppressed in favor of monumental Socialist Classicism. The Shukhov Tower in Moscow, a hyperboloid lattice radio tower by engineer Vladimir Shukhov (1920–1922), shows the period's engineering brilliance."]]
  ],
  terms:[["Modernism","20th-century architecture rejecting historical styles in favor of new materials, function, and social purpose."],["Reinforced concrete","Concrete with embedded steel bars to resist tension."],["Deutscher Werkbund","A German association founded in 1907 to unite design and industry."],["Expressionism","A sculptural, emotional architectural movement of the 1910s–1920s."],["De Stijl","A Dutch movement using abstract planes, right angles, and primary colors."],["Constructivism","A Soviet avant-garde movement celebrating engineering and collective life."]],
  w:"Modernism's roots lie in a burst of experimental movements that tried to create an architecture for the machine age and a new society.",
  src:["Modern architecture","Deutscher Werkbund","Fagus Factory","Rietveld Schröder House","Constructivist architecture","Einstein Tower"],
  q:[["Why is steel embedded in reinforced concrete?","To resist tension, where concrete is weak","To make it lighter","To change its color","To conduct heat"],
     ["Which three famous modernists worked in Peter Behrens's office?","Gropius, Mies van der Rohe, and Le Corbusier","Wright, Sullivan, and Burnham","Aalto, Kahn, and Niemeyer","Gaudí, Horta, and Guimard"],
     ["What is notable about the Fagus Factory?","Glass walls wrapping the corners without visible supports","Its Gothic spires","Its thatched roof","It is underground"],
     ["De Stijl used…","Straight lines, right angles, and primary colors","Curving organic shapes","Historical ornament","Only black and gold"],
     ["Who designed the Schröder House?","Gerrit Rietveld","Theo van Doesburg","Michel de Klerk","Erich Mendelsohn"],
     ["Tatlin's Monument to the Third International was…","A spiraling iron tower, never built","A Moscow cathedral","A completed skyscraper","A worker's club"]]},

{ t:"The Bauhaus", s:"A school that changed design",
  sec:[
  ["Founding in Weimar",[
    "The Bauhaus was founded in Weimar, Germany, in 1919 by Walter Gropius, who merged an arts academy and a school of applied arts. Its founding manifesto called for artists and craftsmen to work together to build 'the building of the future', uniting architecture, sculpture, and painting. The cover showed a woodcut of a Gothic cathedral by Lyonel Feininger, recalling medieval craft guilds.",
    "Students began with a preliminary course (Vorkurs), first taught by Johannes Itten, exploring materials, color, and form. They then trained in workshops, including metalwork, weaving, furniture, ceramics, printing, and wall painting, each led by both a craft master and an artist, called a 'master of form'. Teachers included painters Paul Klee and Wassily Kandinsky."]],
  ["Art and technology",[
    "In the early 1920s, under the influence of De Stijl and Constructivism and the arrival of László Moholy-Nagy, the Bauhaus shifted from craft romanticism toward industrial design. Its slogan became 'Art and Technology: A New Unity' (1923). Workshops created prototypes for mass production: lamps, chairs, tableware, textiles, and typography.",
    "Famous Bauhaus products include Marianne Brandt's metal teapots and lamps, Wilhelm Wagenfeld's glass table lamp, Marcel Breuer's tubular steel chairs (inspired, the story goes, by bicycle handlebars), and textiles by Anni Albers and Gunta Stölzl, who led the weaving workshop. Herbert Bayer designed a lowercase-only universal typeface."]],
  ["The Dessau building",[
    "Political pressure from conservative authorities forced the Bauhaus out of Weimar in 1925. It moved to the industrial city of Dessau, where Gropius designed a new school building (1925–1926). Its asymmetrical, pinwheel plan separates functions into distinct wings, workshops, classrooms, and a student residence, connected by a bridge.",
    "The workshop wing has a huge glass curtain wall wrapping its corners, making the building's activities visible. Gropius also designed houses for the masters nearby. Both the Bauhaus buildings in Weimar and Dessau are a UNESCO World Heritage Site. The building, seen best from the air or by walking around it, has no single main facade, expressing the modernist idea of space in motion."]],
  ["Meyer, Mies, and closure",[
    "Gropius resigned in 1928. His successor, the Swiss architect Hannes Meyer, emphasized social needs and a scientific, functional approach, and the school's first formal architecture department was established; Meyer was dismissed in 1930 for his Marxist politics. Ludwig Mies van der Rohe then led the school, focusing it more narrowly on architecture.",
    "The Nazis, who saw the Bauhaus as un-German and 'Bolshevik', forced it to close in Dessau in 1932. Mies moved it to a former telephone factory in Berlin as a private school, but under Nazi pressure it closed for good in 1933. In its 14 years, the Bauhaus had only about 1,250 students, yet its influence was immense."]],
  ["The Bauhaus diaspora",[
    "Many Bauhaus teachers and students fled Nazi Germany, spreading its ideas worldwide. Gropius and Breuer went to Harvard, where Gropius led the architecture department from 1938 and trained a generation of American architects. Mies went to Chicago to head the architecture school at the Armour Institute, later the Illinois Institute of Technology (IIT). Moholy-Nagy founded the 'New Bauhaus' in Chicago in 1937. Josef and Anni Albers taught at Black Mountain College in North Carolina.",
    "In Tel Aviv, architects trained at or influenced by the Bauhaus built thousands of white modernist buildings in the 1930s, adapted to the hot climate with balconies and small windows. The 'White City' of Tel Aviv was named a UNESCO World Heritage Site in 2003."]],
  ["Legacy",[
    "The Bauhaus model of design education, a foundation course, hands-on workshops, interdisciplinary teaching, and the integration of art and industry, shaped art and design schools across the world. Its ideas of clean, functional, mass-producible design influenced furniture, graphic design, typography, and product design, from IKEA to Apple.",
    "Critics note that the 'Bauhaus style' is something of a myth, as the school was varied and changed often, and that women were often steered toward weaving rather than architecture. Still, its belief that good design should be available to everyone remains powerful."]]
  ],
  terms:[["Bauhaus","An influential German school of art, design, and architecture (1919–1933)."],["Vorkurs","The Bauhaus preliminary course exploring materials, color, and form."],["Industrial design","The design of products for mass manufacture."],["Pinwheel plan","A plan with wings extending in different directions from a center."],["Tubular steel furniture","Furniture made of bent steel tubes, pioneered by Marcel Breuer."]],
  w:"The Bauhaus defined modern design education and spread modernism worldwide through the émigrés who fled Nazi Germany.",
  src:["Bauhaus","Walter Gropius","Bauhaus Dessau","Marcel Breuer","White City (Tel Aviv)","Anni Albers"],
  q:[["Who founded the Bauhaus in 1919?","Walter Gropius","Ludwig Mies van der Rohe","Hannes Meyer","Paul Klee"],
     ["The Bauhaus slogan from 1923 was…","Art and Technology: A New Unity","Less is more","Form follows function","To every age its art"],
     ["Why did the Bauhaus move from Weimar to Dessau?","Political pressure from conservative authorities","A fire destroyed the Weimar school","Dessau offered free land in the Alps","Gropius was born there"],
     ["Who designed the Bauhaus building in Dessau?","Walter Gropius","Marcel Breuer","Le Corbusier","Peter Behrens"],
     ["Why did the Bauhaus finally close in 1933?","Nazi pressure","Lack of students","A flood","It merged with Harvard"],
     ["Which city has a 'White City' of Bauhaus-influenced buildings?","Tel Aviv","Chicago","Paris","Moscow"]]},

{ t:"Le Corbusier", s:"Machines for living and the radiant city",
  sec:[
  ["A Swiss watchmaker's son",[
    "Charles-Édouard Jeanneret (1887–1965), born in La Chaux-de-Fonds, Switzerland, a watchmaking town, adopted the pseudonym Le Corbusier in 1920. He worked briefly for Perret and Behrens, traveled widely in the Mediterranean, and settled in Paris, where he became a painter, writer, polemicist, and the most influential architect of the 20th century.",
    "His book 'Vers une architecture' (1923), translated as 'Towards a New Architecture', collected his essays from the magazine L'Esprit Nouveau. It compared Greek temples to cars, and praised ocean liners, airplanes, and grain silos as models of rational design. It declared that 'the house is a machine for living in', meaning a house should be as efficient and well designed as a machine, not that it should be cold."]],
  ["The Five Points",[
    "In 1926–1927 Le Corbusier set out 'Five Points of a New Architecture', made possible by the reinforced concrete frame. First, pilotis: columns lifting the building off the ground, freeing the ground for circulation and gardens. Second, the roof garden, replacing the land lost under the building. Third, the free plan: since columns carry the load, interior walls can be placed freely.",
    "Fourth, the free facade: the exterior wall, no longer load-bearing, can be designed freely. Fifth, the horizontal ribbon window running the length of the facade, giving even light. His Domino system (1914–1915), a diagram of concrete slabs on thin columns with a stair, had already shown the frame that underlies these ideas."]],
  ["Villa Savoye",[
    "The Villa Savoye in Poissy, outside Paris (1928–1931), is the perfect demonstration of the Five Points. A white box raised on slender pilotis floats above a meadow; ribbon windows run around all sides; and a roof garden crowns the top. The ground floor curves to match the turning radius of a car, which drove under the house to drop off passengers.",
    "Inside, a ramp rises through the center of the house to the roof, creating an 'architectural promenade', a sequence of changing views as one moves through the building. The villa was nearly demolished in the 1950s but was saved, restored, and is now a museum. In 2016, it was one of 17 Le Corbusier works inscribed as a single UNESCO World Heritage Site spanning seven countries."]],
  ["Cities and the Unité",[
    "Le Corbusier's urban visions were radical. His Plan Voisin (1925) proposed demolishing much of central Paris for a grid of cross-shaped glass skyscrapers set in parkland, and his 'Ville Radieuse' (Radiant City) of the 1930s separated living, working, and traffic. These ideas, codified with the CIAM (International Congresses of Modern Architecture) in the Athens Charter, deeply influenced postwar urban renewal, often with problematic results.",
    "His Unité d'Habitation in Marseille (1947–1952) is a 'vertical village' for about 1,600 people: a 17-story block of rough exposed concrete (béton brut) on massive pilotis, with 337 two-story apartments interlocking around central 'interior streets', a shopping street halfway up, and a roof terrace with a running track, nursery, and pool. Its proportions use the Modulor, his system based on the human body and the golden ratio."]],
  ["Late works",[
    "After World War II, Le Corbusier's work became more sculptural and expressive. The pilgrimage chapel of Notre-Dame du Haut at Ronchamp (1950–1955) has a heavy, curving roof like an upturned shell, thick walls pierced by small, deep, colored windows, and a sense of mystery far from the machine aesthetic. The Dominican monastery of Sainte-Marie de La Tourette (1953–1960) is a severe concrete structure on a slope.",
    "In India, Le Corbusier planned Chandigarh, the new capital of Punjab (from 1951), and designed its Capitol Complex, including the High Court, the Assembly, and the Secretariat, with huge concrete forms, sun-shading screens (brise-soleil), and reflecting pools adapted to the hot climate. It is one of the few realized modernist new cities."]],
  ["A complicated legacy",[
    "Le Corbusier's influence on architecture is unmatched: the free plan, pilotis, the roof terrace, béton brut, and the high-rise housing slab spread worldwide. His sketches, books, and buildings are endlessly studied.",
    "His legacy is also controversial. His urban plans inspired the destruction of historic neighborhoods and isolated tower-block estates. Scholars have also examined his political views, including his contacts with the Vichy regime during World War II and his sympathy for authoritarian solutions. Understanding him means holding together genius and serious flaws."]]
  ],
  terms:[["Pilotis","Columns that lift a building above the ground."],["Free plan","A plan in which interior walls are independent of the structure."],["Ribbon window","A long horizontal band of windows."],["Architectural promenade","A designed route through a building revealing changing views."],["Béton brut","Raw, exposed concrete showing the marks of its formwork."],["Modulor","Le Corbusier's proportioning system based on the human body and the golden ratio."],["Brise-soleil","A sun-shading screen or fins on a facade."]],
  w:"Le Corbusier defined much of modern architecture's vocabulary and its urban ambitions, for better and worse.",
  src:["Le Corbusier","Villa Savoye","Five Points of Architecture","Unité d'habitation","Notre Dame du Haut","Chandigarh"],
  q:[["What did Le Corbusier mean by 'a machine for living in'?","A house should be as efficient and well designed as a machine","Houses should be built in factories only","Houses should move","Houses should have no rooms"],
     ["Which is NOT one of Le Corbusier's Five Points?","Pointed arches","Pilotis","Free plan","Ribbon windows"],
     ["How does one move through the Villa Savoye's center?","Up a ramp in an architectural promenade","By elevator only","Through a spiral staircase in a tower","Along an outdoor bridge"],
     ["The Unité d'Habitation in Marseille includes…","A shopping street and rooftop facilities inside the block","A cathedral","An airport","A private golf course"],
     ["Which Le Corbusier building has a heavy curving roof and deep colored windows?","Notre-Dame du Haut at Ronchamp","Villa Savoye","La Tourette","Unité d'Habitation"],
     ["Which Indian city did Le Corbusier plan?","Chandigarh","New Delhi","Mumbai","Jaipur"]]},

{ t:"Mies van der Rohe", s:"Less is more",
  sec:[
  ["A stonemason's son",[
    "Ludwig Mies van der Rohe (1886–1969), born in Aachen, Germany, to a stonemason, trained in his father's workshop and with the furniture designer Bruno Paul, then worked for Peter Behrens. He was deeply influenced by Karl Friedrich Schinkel's clear Neoclassicism. In the early 1920s he produced radical unbuilt projects: glass skyscrapers for Berlin with crystalline, faceted facades, and a brick country house whose walls slide past each other like a De Stijl painting.",
    "Mies's approach was rooted in craft and precision, with a nearly spiritual sense of order. He sought, in his words, 'almost nothing', reduction to essentials. The phrase 'less is more', which he popularized, became the motto of minimalist modernism."]],
  ["The Barcelona Pavilion",[
    "Mies's German Pavilion for the 1929 International Exposition in Barcelona is one of the most influential buildings of the century, despite having had almost no practical function. A thin flat roof rests on eight cruciform chrome-plated steel columns; beneath it, freestanding walls of onyx, travertine, marble, and tinted glass slide past each other, guiding movement without enclosing rooms. Two reflecting pools, one with Georg Kolbe's statue 'Morning', complete it.",
    "The pavilion was dismantled in 1930 and reconstructed on its original site in 1983–1986. Mies and his partner Lilly Reich designed the Barcelona Chair for it, still produced today. Reich, an important designer in her own right, collaborated closely with Mies on interiors and exhibitions."]],
  ["The Tugendhat House",[
    "The Villa Tugendhat in Brno, Czech Republic (1928–1930), applied the same ideas to a family home. Its main living area is one vast open space defined by an onyx wall and a curved Macassar ebony screen, with chrome cruciform columns. Huge glass windows facing the garden could be lowered electrically into the floor, opening the room to the outside.",
    "The house survived war, Nazi and Soviet occupation, and use as a hospital, and after restoration it reopened as a museum. It was inscribed as a UNESCO World Heritage Site in 2001, recognized as a masterpiece of the modern movement."]],
  ["Chicago and IIT",[
    "After leaving Nazi Germany in 1937–1938, Mies moved to Chicago to direct the architecture school at what became the Illinois Institute of Technology (IIT). He planned its new campus, designing buildings of steel frames filled with glass and brick. Crown Hall (1956), housing the architecture school, is a single vast room under a roof suspended from four great external steel girders, so no interior columns are needed: a 'universal space' adaptable to any use.",
    "In America, steel became Mies's main material. Because fire codes required steel structures to be encased in concrete, the frame itself was hidden; Mies added steel I-beams (mullions) to the outside to express the structure, a detail that is partly ornamental, partly structural, and highly debated."]],
  ["Glass towers",[
    "Mies's 860–880 Lake Shore Drive Apartments in Chicago (1949–1951), twin glass towers, defined the modern high-rise. The Seagram Building in New York (1954–1958), designed with Philip Johnson, is the model of the corporate skyscraper: a bronze and tinted-glass tower set back from Park Avenue behind a granite plaza, which was unusual on such expensive land. That plaza later inspired zoning rules encouraging public plazas.",
    "The Farnsworth House in Plano, Illinois (1945–1951), a weekend retreat for Dr. Edith Farnsworth, is a single glass room suspended between white steel columns above a floodplain. It is serene and beautiful but famously led to a bitter legal dispute between client and architect over cost and livability. His last major work was the New National Gallery in Berlin (1968), a glass hall under a square steel roof on eight columns."]],
  ["Influence and critique",[
    "Mies's glass-and-steel aesthetic became the standard language of corporate and institutional architecture worldwide from the 1950s to the 1970s. Countless office towers imitated the Seagram Building, often with less care and precision.",
    "Critics argued that the copies produced monotonous, anonymous cities, and that glass boxes are energy-inefficient, overheating in summer and losing heat in winter. Postmodernist Robert Venturi retorted 'less is a bore'. Yet Mies's own buildings, with their perfect proportions and exquisite details, are widely admired, and his famous line 'God is in the details' (sometimes attributed to him) sums up his craft-based approach."]]
  ],
  terms:[["Less is more","Mies's motto for reducing design to its essentials."],["Universal space","A large, column-free, flexible space adaptable to many uses."],["Cruciform column","A column with a cross-shaped section."],["Mullion","A vertical element dividing windows or panels in a facade."],["Plaza","An open public space in a city, often in front of a building."]],
  w:"Mies van der Rohe gave modernism its most refined form and created the template for the glass office tower.",
  src:["Ludwig Mies van der Rohe","Barcelona Pavilion","Villa Tugendhat","Seagram Building","Farnsworth House","S. R. Crown Hall"],
  q:[["Which motto did Mies popularize?","Less is more","Form follows function","Less is a bore","A house is a machine for living in"],
     ["What happened to the Barcelona Pavilion after the 1929 exposition?","It was dismantled and later reconstructed in the 1980s","It became a church","It was moved to Berlin","It was converted into a museum immediately"],
     ["Which designer collaborated closely with Mies on the Barcelona Chair and interiors?","Lilly Reich","Marianne Brandt","Charlotte Perriand","Eileen Gray"],
     ["Crown Hall at IIT is a…","Single column-free room under a roof hung from external girders","Tall glass tower","Brick church","Concrete stadium"],
     ["Why did Mies add steel I-beams to the outside of his towers?","To express a structure hidden by fireproofing","To hold up the floors","To support window washing machines","To meet earthquake codes"],
     ["Who responded to Mies with 'less is a bore'?","Robert Venturi","Philip Johnson","Le Corbusier","Frank Lloyd Wright"]]},

{ t:"Frank Lloyd Wright", s:"Organic architecture and the American house",
  sec:[
  ["An American original",[
    "Frank Lloyd Wright (1867–1959) is often called the greatest American architect. Born in Wisconsin, he worked for Louis Sullivan before opening his own practice in Oak Park, near Chicago, in 1893. Over a career of about 70 years, he designed over 1,000 projects, of which more than 500 were built.",
    "Wright developed what he called organic architecture: buildings in harmony with their sites, growing from the landscape, with interior spaces flowing into one another, natural materials, and every detail, from windows to furniture, designed as part of a unified whole. He also absorbed influences from Japanese architecture, which he saw at the 1893 Chicago Exposition and later collected as a dealer of Japanese prints."]],
  ["The Prairie house",[
    "Around 1900–1910, Wright developed the Prairie house, designed for the flat Midwest landscape. These houses have strong horizontal lines, low-pitched roofs with deep overhanging eaves, bands of art-glass windows, and a central fireplace as the heart of the home, with living spaces opening out from it in a cross or pinwheel plan rather than as boxy separate rooms.",
    "The Frederick C. Robie House in Chicago (1909–1910) is the masterpiece: long, low, with cantilevered roofs extending far beyond the walls. A 1910–1911 German publication of his work, the Wasmuth Portfolio, made Wright famous in Europe and influenced the young modernists, including Gropius and Mies. In 2019, the Robie House and seven other Wright works were inscribed as a UNESCO World Heritage Site."]],
  ["Crisis and Japan",[
    "In 1909 Wright left his wife and family and went to Europe with Mamah Borthwick Cheney, the wife of a client, causing a scandal. He built Taliesin, his home and studio in Wisconsin; in 1914 a servant murdered Borthwick and six others and set fire to the house. Wright rebuilt it, and Taliesin later became his school and fellowship.",
    "From 1917 to 1922 Wright worked in Tokyo on the Imperial Hotel, designed with a foundation intended to 'float' on mud and a flexible structure. It survived the 1923 Great Kantō earthquake largely intact, a story Wright promoted widely. It was demolished in 1968, but its entrance lobby was reconstructed at the Meiji Mura museum near Nagoya."]],
  ["Fallingwater and Usonia",[
    "In the 1930s, past age 65, Wright entered a second great period. Fallingwater (1936–1939), a weekend house in Pennsylvania for the Kaufmann family, is built directly over a waterfall on Bear Run. Reinforced concrete terraces cantilever dramatically over the stream, anchored to a stone core. The sound of water fills the house. It became one of the most famous houses in the world; its cantilevers sagged over time and were strengthened with post-tensioning in 2002.",
    "Wright also designed Usonian houses: affordable, single-story homes for middle-class Americans, built on concrete slabs with radiant floor heating, carports, open living-dining-kitchen areas, and walls of glass toward private gardens. The first, the Jacobs House in Madison, Wisconsin (1936–1937), anticipated the postwar ranch house. His vision of a decentralized, low-density America, 'Broadacre City', foreshadowed suburbia."]],
  ["Public buildings",[
    "Wright's Larkin Administration Building in Buffalo (1904–1906, demolished 1950) had a skylit central atrium and early air conditioning. Unity Temple in Oak Park (1905–1908), one of the first significant buildings in exposed poured concrete, has a top-lit sanctuary surrounded by balconies. The S. C. Johnson Administration Building in Racine, Wisconsin (1936–1939) has a great work room with slender 'dendriform' columns, wide at the top like lily pads, with light filtering through glass tubing.",
    "The Solomon R. Guggenheim Museum in New York (designed from 1943, completed 1959, after Wright's death) is a spiraling concrete form: visitors take an elevator to the top and walk down a continuous ramp around a central skylit atrium, viewing art along the way. Some artists complained that the sloping walls were difficult for hanging paintings, but the building itself became an icon."]],
  ["Legacy",[
    "Wright pioneered the open plan, the integration of building and landscape, the carport, the cantilever as an expressive device, radiant floor heating in homes, and much more. His idea of a house that is rooted, sheltering, and open to nature remains a powerful alternative to the more machine-like European modernism.",
    "He was also famously arrogant, careless of budgets and clients' needs, and some of his buildings had leaking roofs and structural problems. The Frank Lloyd Wright Foundation and the Taliesin schools continued his work after his death. His houses are now carefully preserved and visited by hundreds of thousands of people every year."]]
  ],
  terms:[["Organic architecture","Wright's philosophy of buildings in harmony with their sites and unified in every detail."],["Prairie house","Wright's early-20th-century house type with strong horizontal lines and open plans."],["Cantilever","A beam or slab projecting beyond its support, anchored at only one end."],["Usonian house","Wright's affordable single-story house type for middle-class Americans."],["Dendriform column","A tree-like column widening at the top, as in Wright's Johnson Wax building."],["Atrium","A large open central space, often skylit."]],
  w:"Wright created a distinctly American modern architecture rooted in landscape and shaped the American house for generations.",
  src:["Frank Lloyd Wright","Fallingwater","Frederick C. Robie House","Solomon R. Guggenheim Museum","Usonia","Johnson Wax Headquarters"],
  q:[["What did Wright call his approach?","Organic architecture","Brutalism","Rationalism","International Style"],
     ["Prairie houses are characterized by…","Strong horizontal lines and deep overhanging eaves","Tall Gothic spires","Glass curtain walls","Domes"],
     ["What is Fallingwater built over?","A waterfall","A cliff edge in the desert","A lake","A canyon"],
     ["What were Usonian houses?","Affordable single-story homes for middle-class Americans","Luxury skyscrapers","Prefabricated steel huts","Government offices"],
     ["How do visitors usually experience the Guggenheim Museum?","Walking down a continuous spiral ramp","Climbing a grand staircase","Through a series of separate galleries on many floors","By moving walkway"],
     ["Which Wright building in Tokyo survived the 1923 earthquake?","The Imperial Hotel","The Tokyo Station","The National Diet","The Meiji Shrine"]]}

]});


/* ---- from arch-12.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 12: Unit 6 Modernism, chapters 6-10 */
COURSES.architecture.units[5].ch.push(

{ t:"Art Deco and Streamline", s:"Glamour, geometry, and speed",
  sec:[
  ["A modern style of luxury",[
    "Art Deco takes its name from the 1925 Exposition Internationale des Arts Décoratifs et Industriels Modernes in Paris, though the term itself became common only in the 1960s. It flourished from the 1920s to around 1940. Unlike austere modernism, Art Deco was decorative and glamorous, combining modern geometry with luxurious materials such as polished stone, lacquer, chrome, bronze, exotic woods, and glass.",
    "Its sources were eclectic: Cubism, Viennese Secession, ancient Egypt (fueled by the discovery of Tutankhamun's tomb in 1922), Mesoamerican stepped pyramids, and machine imagery. Typical motifs include zigzags, chevrons, sunbursts, stylized fountains, and stepped forms."]],
  ["Skyscrapers and cinemas",[
    "Art Deco became the style of the American skyscraper boom of the late 1920s. The Chrysler Building's stainless-steel crown, with radiator-cap gargoyles, is the most famous example. The Empire State Building, the Rockefeller Center, and many other towers use Deco ornament at entrances, lobbies, elevator doors, and crowns.",
    "It was also the style of new building types associated with modern leisure and technology: cinemas, theaters (Radio City Music Hall, 1932), department stores, radio stations, airports, and ocean liners such as the SS Normandie. Its glamour offered escapism during the Great Depression."]],
  ["Streamline Moderne",[
    "In the 1930s, Streamline Moderne, inspired by aerodynamics, trains, airplanes, and ships, emphasized smooth curves, horizontal bands ('speed lines'), rounded corners, porthole windows, and glass block. Industrial designers such as Raymond Loewy and Norman Bel Geddes streamlined everything from locomotives to pencil sharpeners.",
    "Streamline buildings include diners, gas stations, bus terminals, and seaside pavilions. The De La Warr Pavilion in Bexhill-on-Sea, England (1935), by Erich Mendelsohn and Serge Chermayeff, has a cantilevered spiral stair in a glass drum."]],
  ["Art Deco cities",[
    "Some cities are renowned for Art Deco ensembles. Miami Beach's Art Deco Historic District, mostly from the 1930s, has hundreds of pastel-colored hotels and apartment buildings with tropical motifs, saved from demolition by preservationists led by Barbara Capitman in the late 1970s. Napier in New Zealand was rebuilt in Art Deco after an earthquake destroyed it in 1931.",
    "Mumbai has one of the world's largest collections of Art Deco buildings, especially along Marine Drive and the Oval Maidan, recognized as part of the 'Victorian Gothic and Art Deco Ensembles of Mumbai' UNESCO site in 2018. Shanghai's Bund and Former French Concession, Asmara in Eritrea (with Italian modernist and Deco buildings, UNESCO 2017), and Casablanca also have rich Art Deco heritage."]],
  ["Deco and politics",[
    "Art Deco's stripped classicism, sometimes called 'Moderne Classicism', was used for government buildings in many countries in the 1930s, including the US federal buildings of the New Deal, which combined classical symmetry with simplified, flattened ornament. Similar stripped classicism appeared in totalitarian regimes in Italy, Germany, and the Soviet Union.",
    "In the Soviet Union, the Moscow Metro (opened 1935) used Deco-influenced and classical designs with marble, mosaics, and chandeliers to create 'palaces for the people'. The comparison shows again that styles can carry very different political meanings."]],
  ["Why Art Deco matters",[
    "Art Deco showed that modern architecture need not be austere. It embraced new technology and geometry while keeping ornament, craftsmanship, and glamour, and it reached a wide popular audience.",
    "Modernist critics long dismissed it as superficial, but it has been widely rediscovered since the 1960s. Its blend of modern form with decoration, and of high design with popular culture, anticipates postmodernism and continues to inspire designers today."]]
  ],
  terms:[["Art Deco","A decorative modern style of the 1920s–1930s combining geometry with luxurious materials."],["Streamline Moderne","A 1930s style of smooth curves and horizontal lines inspired by aerodynamics."],["Glass block","Hollow glass bricks admitting light while providing privacy."],["Stripped classicism","Classical symmetry and proportion with simplified, flattened ornament."],["Chevron","A V-shaped or zigzag pattern."]],
  w:"Art Deco brought glamour and ornament to modern architecture and remains one of the most popular 20th-century styles.",
  src:["Art Deco","Chrysler Building","Streamline Moderne","Miami Beach Architectural District","Napier, New Zealand","Victorian Gothic and Art Deco Ensembles of Mumbai"],
  q:[["Art Deco takes its name from…","A 1925 decorative arts exhibition in Paris","An architect named Deco","A New York hotel","A Spanish word for luxury"],
     ["Which discovery boosted Egyptian motifs in Art Deco?","Tutankhamun's tomb in 1922","The Rosetta Stone","The Pyramid of Djoser","The Valley of the Kings tunnels"],
     ["Streamline Moderne was inspired by…","Aerodynamics, trains, and ships","Gothic cathedrals","Japanese gardens","Roman baths"],
     ["Which city was rebuilt in Art Deco style after a 1931 earthquake?","Napier, New Zealand","Miami Beach","Mumbai","Casablanca"],
     ["Which Indian city has one of the world's largest Art Deco collections?","Mumbai","Chandigarh","New Delhi","Kolkata"],
     ["The Moscow Metro was designed as…","Palaces for the people","Bomb shelters only","Industrial tunnels","Glass and steel boxes"]]},

{ t:"Aalto and Nordic Modernism", s:"A humane, organic modernism",
  sec:[
  ["The Nordic way",[
    "In Scandinavia and Finland, modernism took a warmer, more humane direction. Nordic architects drew on traditions of craftsmanship, wood and brick, close relationships to nature, and strong welfare-state ideals of good design for everyone. Swedish architects Gunnar Asplund and Sigurd Lewerentz moved from a refined 'Nordic Classicism' in the 1920s to modernism.",
    "Asplund and Lewerentz's Woodland Cemetery (Skogskyrkogården) in Stockholm (1917–1940), a landscape of pine forest, meadows, and simple chapels, is a UNESCO World Heritage Site and one of the most moving landscapes of the 20th century. Asplund's Stockholm Public Library (1928) has a great cylindrical reading room surrounded by books."]],
  ["Alvar Aalto",[
    "Alvar Aalto (1898–1976), the greatest Finnish architect, combined modernism with organic forms, natural materials, and close attention to human experience. His Paimio Sanatorium (1929–1933), for tuberculosis patients, was designed in every detail for the sick: rooms angled toward the sun, ceilings painted soothing colors because patients lay looking upward, quiet washbasins designed so water would not splash noisily, and the Paimio armchair of bent plywood designed to ease breathing.",
    "His Viipuri Library (1927–1935), now in Vyborg, Russia, has a lecture hall with an undulating wooden ceiling designed for acoustics, and circular skylights spreading even daylight in the reading room. With his wife Aino Aalto, an architect and designer, he founded the furniture company Artek in 1935, producing bent-plywood furniture still sold today."]],
  ["Wood, curves, and landscape",[
    "Aalto's Villa Mairea (1938–1939) in Noormarkku, built for the art patrons Maire and Harry Gullichsen, blends modernism with Finnish vernacular: an L-shaped plan around a garden with a sauna and pool, columns wrapped with rattan or grouped like trees in a forest, and a mix of white render, wood, and stone. The Säynätsalo Town Hall (1949–1952) is a small brick civic building around a raised courtyard, with a council chamber under a dramatic timber roof.",
    "His Finnish Pavilion for the 1939 New York World's Fair had a dramatic undulating wall of wooden slats. The wavy line, possibly inspired by Finland's lakes, appears in his famous glass Savoy vase (1936). Aalto showed that modern architecture could be sensual, contextual, and responsive to the psychological needs of its users."]],
  ["Danish design",[
    "Denmark contributed elegant modern architecture and furniture. Arne Jacobsen designed the SAS Royal Hotel in Copenhagen (1956–1960), including every detail from the building to the Egg and Swan chairs and the cutlery. Jørn Utzon, designer of the Sydney Opera House, built humane courtyard housing at Fredensborg and Helsingør (Kingo Houses).",
    "Danish modern furniture by Hans Wegner, Finn Juhl, Børge Mogensen, and others combined craft traditions with modern forms and became internationally popular in the 1950s and 1960s, part of the broader 'Scandinavian Design' movement promoted by an exhibition touring North America from 1954 to 1957."]],
  ["The welfare state and housing",[
    "Nordic modernism was closely tied to the welfare state. Sweden's 'Million Programme' (1965–1974) built about a million homes in ten years to end housing shortages, though some suburban estates later faced social problems. Housing cooperatives, high-quality schools, libraries, and public buildings in Scandinavia aimed to give all citizens well-designed environments.",
    "The Norwegian Sverre Fehn, winner of the 1997 Pritzker Prize, created poetic museums and pavilions, such as the Nordic Pavilion at the Venice Biennale (1962), with trees growing through its roof. The Nordic approach influenced later architects interested in phenomenology, the study of how buildings are experienced through the senses."]],
  ["Lessons from the North",[
    "Nordic modernism demonstrates that modern architecture can be warm and human. Its key lessons include designing for the human body and senses, using natural materials, respecting landscape and light, and caring about details people touch.",
    "Its influence is visible in today's emphasis on wellbeing, daylight, wooden construction, and biophilic design, the idea that contact with nature improves health. Scandinavian countries remain leaders in sustainable, high-quality public architecture and mass timber construction."]]
  ],
  terms:[["Nordic Classicism","A restrained classical style in Scandinavia in the 1910s–1920s."],["Bent plywood","Thin wood layers glued and bent into curves, used in furniture."],["Organic modernism","Modernism using curves, natural materials, and attention to human experience."],["Scandinavian Design","A mid-20th-century design movement of simple, functional, crafted objects."],["Phenomenology","In architecture, the study of how buildings are experienced through the senses."]],
  w:"Nordic modernism proved that modern architecture can be warm, humane, and rooted in nature, influencing today's focus on wellbeing and wood.",
  src:["Alvar Aalto","Paimio Sanatorium","Villa Mairea","Skogskyrkogården","Gunnar Asplund","Scandinavian design"],
  q:[["Which building did Aalto design for tuberculosis patients?","Paimio Sanatorium","Villa Mairea","Säynätsalo Town Hall","Viipuri Library"],
     ["Why did Aalto paint the Paimio ceilings soothing colors?","Patients lay looking upward","To hide cracks","Paint was cheap","For the doctors' offices"],
     ["What company did Alvar and Aino Aalto found?","Artek","IKEA","Vitra","Knoll"],
     ["The Woodland Cemetery in Stockholm was designed by…","Asplund and Lewerentz","Aalto and Utzon","Jacobsen and Wegner","Fehn and Juhl"],
     ["Arne Jacobsen designed which famous chair?","The Egg chair","The Barcelona chair","The Paimio chair","The Wassily chair"],
     ["Sweden's Million Programme aimed to…","Build about a million homes in ten years","Plant a million trees","Restore a million old buildings","Train a million architects"]]},

{ t:"The International Style and Postwar Modernism", s:"Glass towers, corporations, and new ambitions",
  sec:[
  ["Naming the International Style",[
    "In 1932, the Museum of Modern Art in New York held the exhibition 'Modern Architecture: International Exhibition', curated by Henry-Russell Hitchcock and Philip Johnson. Their accompanying book, 'The International Style', defined modernism by three principles: architecture as volume rather than mass (thin surfaces enclosing space), regularity rather than symmetry, and the avoidance of applied ornament.",
    "Critics noted that this presentation turned a social and political movement into a visual style, removing much of its housing and reform agenda. But the label stuck, and after World War II, the International Style became the dominant architecture of corporations, governments, and universities worldwide."]],
  ["The corporate tower",[
    "Lever House in New York (1950–1952), by Gordon Bunshaft of Skidmore, Owings & Merrill (SOM), was a slim glass slab with a blue-green curtain wall set on a low podium, leaving open space at ground level. Together with Mies's Seagram Building across the street, it set the model of the postwar corporate headquarters.",
    "The United Nations Headquarters in New York (1947–1952), designed by a board of architects including Le Corbusier and Oscar Niemeyer, under Wallace Harrison, featured a glass-walled Secretariat tower. SOM became one of the largest firms in the world, pioneering team-based corporate practice and engineering innovations led by Fazlur Khan, whose tube structures for the John Hancock Center (1969) and Sears (now Willis) Tower (1973) in Chicago made very tall buildings more efficient."]],
  ["Expressive modernism",[
    "Not all postwar modernism was boxy. Eero Saarinen designed the TWA Flight Center at Idlewild (now JFK) Airport (1962), a soaring concrete bird-like form, now reopened as a hotel, and the Gateway Arch in St. Louis (completed 1965), a 192-meter stainless steel catenary curve. Engineers like Pier Luigi Nervi in Italy, Félix Candela in Mexico, and Eduardo Torroja in Spain created thin concrete shells and ribbed structures of great beauty.",
    "Jørn Utzon's Sydney Opera House (designed from 1957, opened 1973) is perhaps the most famous postwar building. Its sail-like shells were so difficult to build that engineers at Ove Arup & Partners spent years solving them; eventually Utzon derived all the shells from segments of a single sphere so they could be prefabricated. Political disputes led Utzon to resign in 1966, and he never saw the completed building. It became a UNESCO World Heritage Site in 2007."]],
  ["The modern house",[
    "Postwar prosperity brought modernism to private houses. In California, the Case Study House program (1945–1966), sponsored by Arts & Architecture magazine, commissioned affordable modern homes from architects including Charles and Ray Eames, Richard Neutra, Pierre Koenig, and Craig Ellwood. The Eames House (1949) was built from off-the-shelf industrial steel parts.",
    "Philip Johnson's Glass House in New Canaan, Connecticut (1949), a glass box in a landscape, paired with an almost windowless brick guest house, became a modernist icon. Mid-century modern houses, with open plans, large windows, and indoor-outdoor living, remain highly popular today. Developers such as Joseph Eichler built thousands of modern tract homes in California."]],
  ["Team 10 and criticism from within",[
    "By the 1950s, younger architects challenged the rigid, functional city of CIAM. The group Team 10, including Alison and Peter Smithson, Aldo van Eyck, and Jacob Bakema, called for designs based on human association, identity, and community. Van Eyck's Amsterdam Orphanage (1955–1960) was a cluster of small domed units like a village, and he designed hundreds of small playgrounds in Amsterdam.",
    "In Japan, the Metabolists, including Kiyonori Kikutake and Kisho Kurokawa, proposed cities that would grow and change like organisms. Kurokawa's Nakagin Capsule Tower in Tokyo (1972) had replaceable prefabricated capsule apartments plugged into a central core, though none were ever replaced; it was dismantled in 2022, with some capsules preserved by museums."]],
  ["Mass housing and its problems",[
    "Postwar governments built vast quantities of housing in modernist forms. Some estates were successful, but others failed. The Pruitt-Igoe housing project in St. Louis (completed 1954–1956), designed by Minoru Yamasaki, was demolished beginning in 1972, and the critic Charles Jencks famously declared that date 'the death of modern architecture'.",
    "Historians now argue Pruitt-Igoe's failure stemmed more from underfunding, poor maintenance, racial segregation, and economic decline than from architecture alone. Still, the experience led to more skepticism about large, isolated housing blocks and to new approaches emphasizing streets, mixed uses, and community participation."]]
  ],
  terms:[["International Style","A name for modernism defined by volume, regularity, and no applied ornament."],["Tube structure","A structural system where the building's perimeter acts as a hollow tube to resist wind."],["Thin shell","A curved concrete structure that is very thin relative to its span."],["Case Study Houses","A program of experimental modern homes in California, 1945–1966."],["Metabolism","A Japanese movement proposing cities that grow and change like organisms."],["Team 10","A group of architects who challenged CIAM's rigid functionalism."]],
  w:"Postwar modernism spread worldwide in corporate towers, houses, and mass housing, revealing both its power and its limitations.",
  src:["International Style (architecture)","Lever House","Sydney Opera House","Fazlur Rahman Khan","Case Study Houses","Pruitt–Igoe"],
  q:[["Who curated the 1932 MoMA exhibition that named the International Style?","Henry-Russell Hitchcock and Philip Johnson","Walter Gropius and Mies van der Rohe","Le Corbusier and Pierre Jeanneret","Frank Lloyd Wright and Louis Sullivan"],
     ["Which engineer developed tube structures for Chicago's tall buildings?","Fazlur Khan","Ove Arup","Pier Luigi Nervi","Félix Candela"],
     ["How were the Sydney Opera House shells made buildable?","They were all derived from segments of a single sphere","They were made of inflated fabric","They were carved from stone","They were built of timber"],
     ["The Eames House was built from…","Off-the-shelf industrial steel parts","Handmade bricks","Rammed earth","Recycled shipping containers"],
     ["The Nakagin Capsule Tower was associated with…","Metabolism","Brutalism","Art Deco","De Stijl"],
     ["Historians now attribute Pruitt-Igoe's failure largely to…","Underfunding, poor maintenance, segregation, and economic decline","Bad weather","Its Gothic design","Too many parks"]]},

{ t:"Brutalism", s:"Raw concrete and ethical ambition",
  sec:[
  ["Name and origins",[
    "Brutalism refers to a strand of modern architecture from the 1950s to the 1970s characterized by raw, exposed materials, especially concrete showing the marks of its wooden formwork, massive sculptural forms, and clear expression of structure and services. The name comes partly from Le Corbusier's 'béton brut' and was popularized by the critic Reyner Banham in his 1955 essay 'The New Brutalism' and his 1966 book of the same name.",
    "Banham associated the 'New Brutalism' with Alison and Peter Smithson in Britain, whose Hunstanton School (1949–1954) exposed its steel structure, pipes, and wiring with uncompromising honesty. For them, Brutalism was an ethic as much as an aesthetic: honesty about materials and a direct engagement with ordinary life."]],
  ["Concrete as material",[
    "Concrete suited postwar needs: it was relatively cheap, fireproof, could be cast into large and expressive shapes, and did not require scarce steel. Architects explored many finishes: board-marked concrete showing the grain of timber planks, bush-hammered concrete with a rough, textured surface, and precast panels.",
    "Paul Rudolph's Yale Art and Architecture Building (1958–1963) used a corduroy-like ribbed concrete, bush-hammered to expose the aggregate. Brutalist buildings often express their different functions as separate volumes and their circulation as bridges, ramps, and towers."]],
  ["Great Brutalist buildings",[
    "London's Barbican Estate (1965–1982), by Chamberlin, Powell and Bon, is a vast complex of towers and terraces with an arts center, lakes, and gardens, built on a bombed site; it has become highly desirable. Ernő Goldfinger's Trellick Tower (1972) and Denys Lasdun's Royal National Theatre (1976) are other London landmarks. Boston City Hall (1968), by Kallmann, McKinnell & Knowles, is a famous American example.",
    "Brutalism spread worldwide: Kenzō Tange in Japan, Paulo Mendes da Rocha and Lina Bo Bardi in Brazil, whose SESC Pompéia leisure center in São Paulo (1977–1986) transformed an old factory with bold concrete towers linked by bridges. Habitat 67 in Montreal, by Moshe Safdie, stacked 354 prefabricated concrete modules into a hillside-like village for Expo 67. In socialist Yugoslavia, abstract concrete war memorials (spomeniks) became internationally famous."]],
  ["Social ambition",[
    "Many Brutalist buildings were public: universities, libraries, theaters, civic centers, and social housing, built by welfare states during a period of optimism about public investment. The Smithsons' Robin Hood Gardens in London (1972), with 'streets in the sky' (wide access decks meant to recreate street life), was demolished starting in 2017, after a long campaign to save it; a section was acquired by the Victoria and Albert Museum.",
    "Park Hill in Sheffield (1957–1961) also used streets in the sky. It became run-down, was listed as a protected building in 1998, and has been redeveloped with colorful new panels, showing how Brutalist buildings can be renewed."]],
  ["Decline and rediscovery",[
    "By the 1980s, Brutalism had become deeply unpopular with many people, associated with failed housing estates, decay, crime, and authoritarian government. Concrete streaked and stained in wet climates, and many buildings were poorly maintained. Numerous Brutalist buildings were demolished.",
    "Since the 2010s, Brutalism has been rediscovered by a new generation through photography, social media, books, and preservation campaigns. Critics now appreciate its sculptural power, social ideals, and honesty. The debate over preserving it is a central question in heritage today: how should we value buildings that many people dislike, but that represent a significant chapter of history?"]],
  ["Lessons",[
    "Brutalism teaches that materials and maintenance matter: concrete needs proper detailing to shed water and resist weathering. It shows the importance of social context and management for housing success, and the risks of large, inflexible structures.",
    "It also teaches the value of architectural ambition in public building. Brutalist architects believed architecture should serve society, and that honest, robust buildings could create a better public realm. That ambition remains inspiring even where results were mixed."]]
  ],
  terms:[["Brutalism","A 1950s–70s style of raw exposed materials, especially concrete, and massive forms."],["Board-marked concrete","Concrete bearing the grain pattern of the timber formwork."],["Bush-hammered concrete","Concrete roughened with a textured hammer to expose its aggregate."],["Streets in the sky","Wide access decks in housing blocks intended to recreate street life."],["Precast concrete","Concrete elements cast off-site and assembled on-site."]],
  w:"Brutalism is one of the most debated architectural legacies, combining social ambition with raw material honesty.",
  src:["Brutalist architecture","Reyner Banham","Barbican Estate","Habitat 67","Robin Hood Gardens","SESC Pompéia"],
  q:[["Who popularized the term 'New Brutalism'?","Reyner Banham","Le Corbusier","Charles Jencks","Philip Johnson"],
     ["What does 'béton brut' mean?","Raw concrete","Brutal building","Broken stone","Steel frame"],
     ["Which Montreal project stacked prefabricated concrete modules?","Habitat 67","Boston City Hall","Barbican Estate","Park Hill"],
     ["'Streets in the sky' were…","Wide access decks in housing blocks","Skybridges between towers","Rooftop roads","Elevated railways"],
     ["Who designed SESC Pompéia in São Paulo?","Lina Bo Bardi","Oscar Niemeyer","Paulo Mendes da Rocha","Lúcio Costa"],
     ["Why did Brutalist concrete often look worse over time?","It streaked and stained in wet climates and was poorly maintained","It melted in the sun","It turned green from copper","It shrank"]]},

{ t:"Modernism Around the World", s:"Niemeyer, Kahn, Tange, Barragán, and Doshi",
  sec:[
  ["A global movement",[
    "After World War II, modernism became truly global. Newly independent nations used it to express progress and break with colonial pasts, while architects in many countries adapted it to local climates, materials, and cultures. This is sometimes called 'critical regionalism', a term developed by Alexander Tzonis, Liane Lefaivre, and Kenneth Frampton in the early 1980s.",
    "Modernism in the tropics, for example, developed deep overhangs, sun-shading screens (brise-soleil), cross-ventilation, and shaded courtyards. Each region produced its own masters."]],
  ["Brazil: Niemeyer and Brasília",[
    "Brazil became a center of modernism after Le Corbusier visited in 1929 and 1936. The Ministry of Education and Health in Rio de Janeiro (1936–1945), designed by a team including Lúcio Costa and Oscar Niemeyer with Le Corbusier as consultant, was one of the first modernist government towers, with brise-soleil and gardens by landscape architect Roberto Burle Marx.",
    "Oscar Niemeyer (1907–2012) developed a sensual architecture of free-flowing curves in concrete, saying he was inspired by the curves of Brazil's mountains, rivers, and women. His Pampulha complex (1940s) in Belo Horizonte was revolutionary. When Brazil built a new capital, Brasília (inaugurated 1960), Lúcio Costa designed the airplane-shaped Pilot Plan, and Niemeyer designed the National Congress, with its twin towers and bowls, the Cathedral, and the palaces. Brasília is a UNESCO site, but its car-dominated plan has been criticized."]],
  ["Louis Kahn",[
    "Louis Kahn (1901–1974), based in Philadelphia, developed a monumental, almost timeless architecture of massive forms, light, and materials. He spoke poetically, asking 'what does a brick want to be?' (and answering 'an arch'). He distinguished 'served spaces' (rooms people use) from 'servant spaces' (stairs, ducts, and services), as at the Richards Medical Research Laboratories (1957–1965).",
    "His masterpieces include the Salk Institute in La Jolla, California (1959–1965), whose concrete laboratories frame a travertine courtyard with a thin channel of water leading toward the Pacific Ocean; the Kimbell Art Museum in Fort Worth (1972), with cycloid vaults admitting silvery daylight; and the National Assembly Building of Bangladesh in Dhaka (completed 1982, after his death), a monumental complex of geometric forms and light."]],
  ["Japan: Tange and beyond",[
    "Kenzō Tange (1913–2005) rebuilt Japan's modern identity after the war. His Hiroshima Peace Memorial Park and Museum (1949–1955) frame the ruined Atomic Bomb Dome along a powerful axis. His Yoyogi National Gymnasium for the 1964 Tokyo Olympics used a dramatic suspension roof hung from cables, blending modern engineering with forms recalling traditional Japanese roofs.",
    "Tange was the first Japanese architect to win the Pritzker Prize (1987), and his students included members of the Metabolist movement. Japan went on to produce more Pritzker laureates than almost any other country, including Fumihiko Maki, Tadao Ando, SANAA (Kazuyo Sejima and Ryue Nishizawa), Toyo Ito, Shigeru Ban, Arata Isozaki, and Riken Yamamoto."]],
  ["Mexico and Latin America",[
    "Luis Barragán (1902–1988) of Mexico created houses and gardens of serene, brightly colored walls, water, and light, combining modernism with Mexican vernacular traditions. His own house and studio in Mexico City (1948) is a UNESCO site, and his Cuadra San Cristóbal stables, with pink walls and a horse pool, is world-famous. He won the Pritzker Prize in 1980.",
    "The National Autonomous University of Mexico's main campus (Ciudad Universitaria, 1949–1952), with its Central Library covered in Juan O'Gorman's mosaic murals, is a landmark of Latin American modernism. In Venezuela, Carlos Raúl Villanueva's Ciudad Universitaria in Caracas integrated works by international artists into the architecture."]],
  ["India, Africa, and beyond",[
    "Balkrishna Doshi (1927–2023), who worked with Le Corbusier and Kahn, built a modernism rooted in Indian life, climate, and community. His Aranya low-cost housing in Indore (1989) provided serviced plots where families could build incrementally. He became the first Indian Pritzker laureate in 2018. Charles Correa designed buildings with open-to-sky spaces suited to India's climate, and Achyut Kanvinde and Raj Rewal shaped modern India's institutions.",
    "In Africa, newly independent nations built modernist parliaments, universities, and stadiums in the 1960s and 1970s, sometimes called 'tropical modernism', as in Ghana, Nigeria, Zambia, and Kenya; the Kenyatta International Conference Centre in Nairobi (1973) is an example. In Sri Lanka, Geoffrey Bawa developed a 'tropical modernism' blending buildings with gardens and landscapes. These works show modernism's capacity for adaptation and local meaning."]]
  ],
  terms:[["Critical regionalism","An approach adapting modern architecture to local climate, culture, and materials."],["Tropical modernism","Modernism adapted to hot climates with shading, ventilation, and courtyards."],["Served and servant spaces","Kahn's distinction between spaces people use and spaces for services and circulation."],["Pilot Plan","Lúcio Costa's plan for Brasília."],["Incremental housing","Housing designed to be expanded by residents over time."]],
  w:"Around the world, architects transformed modernism into regional languages that express local climates, cultures, and national identities.",
  src:["Oscar Niemeyer","Brasília","Louis Kahn","Salk Institute","Kenzo Tange","Luis Barragán","Balkrishna Doshi"],
  q:[["Who designed Brasília's Pilot Plan?","Lúcio Costa","Oscar Niemeyer","Roberto Burle Marx","Le Corbusier"],
     ["Niemeyer's architecture is known for…","Free-flowing concrete curves","Gothic tracery","Timber frames","Glass boxes only"],
     ["Kahn's 'servant spaces' are…","Spaces for services and circulation","Rooms for domestic workers","Gardens","Main living rooms"],
     ["The Salk Institute's courtyard features…","A thin channel of water leading toward the Pacific","A large fountain","A forest","A sculpture garden"],
     ["Which architect designed the Yoyogi National Gymnasium?","Kenzō Tange","Tadao Ando","Kisho Kurokawa","Fumihiko Maki"],
     ["Who was the first Indian architect to win the Pritzker Prize?","Balkrishna Doshi","Charles Correa","Raj Rewal","Achyut Kanvinde"]]}

);


/* ---- from arch-13.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 13: Unit 7 Contemporary Architecture, chapters 1-3 */
COURSES.architecture.units.push({ t:"Contemporary Architecture", ch:[

{ t:"Postmodernism", s:"Complexity, contradiction, and the return of meaning",
  sec:[
  ["The revolt against modernism",[
    "By the 1960s, many people felt that modernism had become monotonous, placeless, and detached from ordinary life and history. Jane Jacobs attacked modernist urban renewal in 'The Death and Life of Great American Cities' (1961). In architecture, the decisive book was Robert Venturi's 'Complexity and Contradiction in Architecture' (1966), which the historian Vincent Scully called the most important writing on architecture since Le Corbusier's 'Towards a New Architecture'.",
    "Venturi argued for an architecture that was 'both-and' rather than 'either-or', rich in meaning, ambiguity, and historical reference. Answering Mies's 'less is more', he wrote 'less is a bore'. He celebrated the messy vitality of Italian Mannerism and Baroque, and of the American vernacular."]],
  ["Learning from Las Vegas",[
    "In 'Learning from Las Vegas' (1972), Venturi, Denise Scott Brown, and Steven Izenour studied the Las Vegas Strip as a serious subject, analyzing how signs and symbols communicated to people moving in cars. They distinguished the 'duck', a building whose whole shape is a symbol (named after a duck-shaped shop on Long Island that sold ducks and eggs), from the 'decorated shed', an ordinary building with signs and ornament applied to its front. They argued the decorated shed was more honest and suitable for the modern era.",
    "Venturi's house for his mother, the Vanna Venturi House in Philadelphia (1962–1964), is an early postmodern building: a simple gabled front with a split pediment, a broken arch applied to the facade, and a plan full of deliberate quirks. Scott Brown, an urban planner and theorist, was a full partner in the firm; when Venturi alone received the Pritzker Prize in 1991, the omission of Scott Brown sparked lasting debate about recognition of women in architecture."]],
  ["Postmodern classicism",[
    "Postmodernism, as named and promoted by the critic Charles Jencks in 'The Language of Post-Modern Architecture' (1977), embraced historical references, ornament, color, and wit, often in ironic or playful ways. Michael Graves's Portland Building in Oregon (1982), a municipal office block with a giant abstracted classical facade in bold colors, became a symbol of the movement and a target of critics; it was renovated in 2017–2020.",
    "Philip Johnson, once a champion of the International Style, designed the AT&T Building in New York (1984, now 550 Madison) with a broken pediment top like a Chippendale highboy. Charles Moore's Piazza d'Italia in New Orleans (1978) is a theatrical collage of colorful classical columns in stainless steel and neon. In Britain, James Stirling's Neue Staatsgalerie in Stuttgart (1977–1984) mixed classical forms with bright high-tech details."]],
  ["Rationalism and the city",[
    "In Italy, a different kind of postmodernism emerged. Aldo Rossi's 'The Architecture of the City' (1966) argued that cities are built of lasting types, like the street, the courtyard, and the square, and of monuments that carry collective memory. His San Cataldo Cemetery in Modena (begun 1971) uses stark, repeating geometric forms evoking a city of the dead.",
    "This 'Neo-Rationalism' influenced the reconstruction of European cities through attention to the street, the block, and the typology of buildings. The International Building Exhibition (IBA) in West Berlin in the 1980s pursued 'critical reconstruction', rebuilding urban blocks with contemporary architecture rather than towers in parks. New Urbanism in America, discussed later, shared some of these ideas."]],
  ["Excess and decline",[
    "In the 1980s, postmodernism became a popular commercial style for offices, malls, and hotels, often reduced to cheap applied pediments and keystones. Critics saw it as shallow, a style of corporate wealth and consumerism. By the 1990s it had largely fallen out of fashion.",
    "But postmodernism had lasting effects. It revived interest in history, context, urban form, symbolism, and communication with the public. It ended the dominance of a single orthodoxy and opened architecture to plurality, meaning that today no single style dominates. Since the 2010s, postmodern buildings have been reappraised, and some, like No 1 Poultry in London by James Stirling (completed 1997), have been listed for protection."]],
  ["Why it matters",[
    "Postmodernism raised questions every architect must face: what do buildings mean, and to whom? Should architecture speak the language of ordinary people, or of experts? How should new buildings relate to their historical context?",
    "Its emphasis on meaning, symbolism, and context continues to shape contemporary architecture, even though few architects now call themselves postmodernists."]]
  ],
  terms:[["Postmodernism","An architectural movement from the 1960s to the 1990s reviving history, ornament, and symbolism, often playfully."],["Decorated shed","A simple building with applied signs and ornament, as opposed to a 'duck'."],["Duck","A building whose entire form is a symbol of its function."],["Typology","The study of building types and their recurring forms."],["Critical reconstruction","Rebuilding cities by restoring historical street and block patterns with new architecture."]],
  w:"Postmodernism ended modernism's monopoly and restored history, meaning, and urban context to architectural debate.",
  src:["Postmodern architecture","Robert Venturi","Denise Scott Brown","Learning from Las Vegas","Portland Building","Aldo Rossi"],
  q:[["Which book by Robert Venturi launched postmodern theory in 1966?","Complexity and Contradiction in Architecture","The Death and Life of Great American Cities","Towards a New Architecture","The Architecture of the City"],
     ["In 'Learning from Las Vegas', what is a 'duck'?","A building whose whole shape is a symbol","A decorated shed","A highway sign","A casino interior"],
     ["Whose omission from the 1991 Pritzker Prize sparked debate?","Denise Scott Brown","Zaha Hadid","Lina Bo Bardi","Aino Aalto"],
     ["Who designed the Portland Building?","Michael Graves","Philip Johnson","Charles Moore","James Stirling"],
     ["Aldo Rossi argued that cities are built of…","Lasting types and monuments carrying collective memory","Temporary structures","Only skyscrapers","Highways and malls"],
     ["What lasting effect did postmodernism have?","It ended the dominance of a single orthodoxy","It banned ornament","It made all buildings glass","It ended interest in history"]]},

{ t:"High-Tech Architecture", s:"Pompidou, Lloyd's, and the expression of technology",
  sec:[
  ["Celebrating the machine",[
    "High-Tech architecture, which emerged in Britain in the late 1960s and 1970s, celebrated industrial technology. Its buildings expose structural frames, ducts, pipes, elevators, and escalators, often brightly colored, and use lightweight steel, glass, and prefabricated components. It drew on the engineer-heroes of the 19th century, like Paxton, and on visionary groups such as Archigram, whose 1960s drawings imagined 'Walking City' and 'Plug-In City'.",
    "Buckminster Fuller, the American inventor of the geodesic dome, was a key inspiration. His domes, made of networks of triangles, could enclose huge spaces with minimal material; his US Pavilion at Expo 67 in Montreal, a 76-meter-diameter dome, is now the Montreal Biosphere. Fuller once asked Norman Foster, 'How much does your building weigh?', a question about efficiency that Foster took to heart."]],
  ["The Centre Pompidou",[
    "The Centre Georges Pompidou in Paris (1971–1977), by Renzo Piano and Richard Rogers with engineers Ove Arup & Partners (Peter Rice), turned the building inside out. Its structure, mechanical systems, and circulation are placed on the outside, color-coded: blue for air, green for water, yellow for electricity, and red for movement such as escalators and elevators. This freed the interior floors as huge, flexible, column-free spaces.",
    "The design, which won an international competition, caused controversy in Paris but became extremely popular, with millions of visitors a year and a lively public square. It was meant as a cultural 'machine' and a public meeting place. It closed in 2025 for a major renovation expected to last about five years."]],
  ["Rogers and Foster",[
    "Richard Rogers (1933–2021) continued the approach in the Lloyd's Building in London (1978–1986), with stainless steel service towers, external elevators, and toilets in pods outside a central atrium, so services could be replaced without disturbing the interior. It was listed as protected (Grade I) in 2011, unusually soon after completion.",
    "Norman Foster (born 1935) pursued a refined, efficient High-Tech. His Willis Faber & Dumas offices in Ipswich (1975) have a curving black-glass facade and a rooftop garden; his HSBC headquarters in Hong Kong (1979–1986) hangs its floors from giant steel trusses, creating a huge atrium and an open public space beneath, with a mirror system bouncing sunlight down. Foster's later works include the Reichstag dome in Berlin (1999), a glass dome with a ramp letting the public walk above the parliament, symbolizing transparency, and 30 St Mary Axe ('the Gherkin', 2004) in London."]],
  ["Other High-Tech pioneers",[
    "Renzo Piano (born 1937) developed a more delicate, craft-oriented approach, as in the Menil Collection in Houston (1987), with leaf-like ferro-cement louvers filtering daylight, and the Kansai International Airport in Osaka (1994), built on an artificial island. Nicholas Grimshaw designed the Waterloo International Terminal (1993) and the Eden Project in Cornwall (2001), giant biomes of hexagonal plastic (ETFE) cushions.",
    "Michael and Patty Hopkins designed lightweight fabric and steel structures, and the Hopkins House in Hampstead (1976) is a glass-and-steel family home. The engineer Peter Rice (1935–1992) worked on the Pompidou, Lloyd's, the Menil, and the Sydney Opera House, and was celebrated for bringing a human, crafted quality to engineering."]],
  ["Technology and sustainability",[
    "High-Tech's interest in efficiency evolved into environmental design. Its practitioners pioneered double-skin facades, natural ventilation systems, and atriums used as environmental lungs. Foster's Commerzbank Tower in Frankfurt (1997) has sky gardens spiraling up the building and natural ventilation through the atrium; it was described as one of the first ecological skyscrapers.",
    "Critics note that High-Tech buildings could be expensive, energy-hungry, and quickly dated, and that exposed services require maintenance. Nevertheless, the movement profoundly influenced airports, stations, offices, and museums worldwide."]],
  ["Legacy",[
    "High-Tech's leading figures, Foster, Rogers, and Piano, all received the Pritzker Prize and created some of the world's largest practices. Their emphasis on flexibility, prefabrication, efficiency, and expressing how buildings work has become part of mainstream contemporary architecture.",
    "The movement also illustrates the close collaboration between architects and engineers at the heart of contemporary practice. Firms like Arup became essential partners in realizing ambitious designs."]]
  ],
  terms:[["High-Tech architecture","A style exposing structure and services and celebrating industrial technology."],["Geodesic dome","A dome made of a network of triangles, developed by Buckminster Fuller."],["Inside-out building","A design that places structure and services outside to free the interior."],["ETFE","A lightweight, transparent fluoropolymer used in inflated cushions for roofs and facades."],["Double-skin facade","Two layers of glass with an air space between, improving environmental performance."]],
  w:"High-Tech architecture celebrated engineering and flexibility and evolved into today's environmental and technical design approaches.",
  src:["High-tech architecture","Centre Pompidou","Lloyd's building","Norman Foster","Buckminster Fuller","HSBC Main Building"],
  q:[["Who designed the Centre Pompidou?","Renzo Piano and Richard Rogers","Norman Foster and Peter Rice","Michael and Patty Hopkins","Nicholas Grimshaw"],
     ["Why are the Pompidou's services on the outside?","To free the interior floors as flexible, column-free spaces","To save on paint","To meet Paris fire codes","To make it look old"],
     ["What did the color red indicate on the Pompidou?","Movement, such as escalators and elevators","Water pipes","Electricity","Air ducts"],
     ["Who invented the geodesic dome?","Buckminster Fuller","Norman Foster","Peter Rice","Frei Otto"],
     ["Foster's Reichstag dome symbolizes…","Transparency of government","Military power","Religious faith","Imperial glory"],
     ["The Eden Project's biomes are covered with…","ETFE cushions","Stained glass","Copper sheets","Timber shingles"]]},

{ t:"Deconstructivism and the Iconic Building", s:"Gehry, Hadid, Koolhaas, and the Bilbao effect",
  sec:[
  ["Deconstructivist architecture",[
    "In 1988, the Museum of Modern Art held the exhibition 'Deconstructivist Architecture', curated by Philip Johnson and Mark Wigley, featuring Frank Gehry, Zaha Hadid, Rem Koolhaas, Daniel Libeskind, Peter Eisenman, Bernard Tschumi, and Coop Himmelb(l)au. Their work shared fragmented, angular, distorted forms that seemed to break the rules of stability, symmetry, and order.",
    "The name combined Russian Constructivism, whose dynamic forms they admired, with deconstruction, a philosophical approach associated with Jacques Derrida that questioned stable meanings. Tschumi's Parc de la Villette in Paris (from 1982) scattered red 'follies' across a park on a grid, overlaid with lines and surfaces, encouraging unpredictable uses."]],
  ["Frank Gehry and Bilbao",[
    "Frank Gehry (1929–2025), born in Toronto and based in Los Angeles, began by remodeling his own house in Santa Monica (1978) with chain-link fence, corrugated metal, and plywood, cheap materials collaged around an ordinary bungalow. He moved toward sculptural forms, using CATIA, aerospace design software, to design and build complex curved shapes.",
    "His Guggenheim Museum Bilbao (1997), with swirling titanium-clad forms beside the Nervión River, was a sensation. It transformed the image of a declining industrial city in Spain's Basque Country and drew huge numbers of tourists; the 'Bilbao effect' became the name for the idea that an iconic building can revive a city. Gehry's Walt Disney Concert Hall in Los Angeles (2003) has stainless-steel sails and a warm wooden auditorium admired for its acoustics."]],
  ["Zaha Hadid",[
    "Zaha Hadid (1950–2016), born in Baghdad and based in London, began as a painter of explosive, fragmented architectural visions; for years her designs were thought unbuildable. Her first major building was the Vitra Fire Station in Germany (1993), a composition of sharp, angled concrete planes. In 2004 she became the first woman to receive the Pritzker Prize.",
    "Her later work became fluid and curving, using digital design: the MAXXI National Museum of 21st Century Arts in Rome (2010), the London Aquatics Centre for the 2012 Olympics, and the Heydar Aliyev Center in Baku (2012), with a continuous white surface flowing from ground to roof. Her firm, Zaha Hadid Architects, continued after her death, led by Patrik Schumacher, an advocate of 'parametricism'."]],
  ["Rem Koolhaas and OMA",[
    "Rem Koolhaas (born 1944), a Dutch former journalist and screenwriter, founded the Office for Metropolitan Architecture (OMA) in 1975. His book 'Delirious New York' (1978) was a 'retroactive manifesto' for Manhattan, celebrating the congestion and unpredictable mix of activities in the skyscraper city. He later wrote 'S, M, L, XL' (1995) and essays such as 'Junkspace'.",
    "OMA's buildings rethink programs, the activities a building contains. The Seattle Central Library (2004) stacks its functions in shifting platforms within a diamond-mesh glass skin, with a continuous spiral of book stacks. The CCTV Headquarters in Beijing (2012), designed with Ole Scheeren, is a continuous loop of two leaning towers joined at top and bottom. Koolhaas won the Pritzker in 2000, and OMA trained many leading architects, including Bjarke Ingels."]],
  ["Libeskind and memory",[
    "Daniel Libeskind's Jewish Museum Berlin (opened 2001) is a zigzag building clad in zinc, with slashing windows. Inside, empty 'voids' cut through the building, representing the absence left by the Holocaust, and the Holocaust Tower is a dark, cold, empty concrete space. Visitors experience disorientation and loss physically.",
    "Libeskind later made the master plan for the World Trade Center site in New York after 2001. Peter Eisenman's Memorial to the Murdered Jews of Europe in Berlin (2005), a field of 2,711 concrete stelae of varying heights on undulating ground, similarly uses architecture to create an experience of disorientation and reflection."]],
  ["The age of the 'starchitect'",[
    "From the late 1990s, cities competed to commission landmark buildings from famous architects, nicknamed 'starchitects', to attract tourists, investment, and attention. Museums, concert halls, and towers became branding devices. Critics argued this produced attention-seeking objects that ignored context, budgets, and ordinary needs, and that the Bilbao effect was hard to replicate.",
    "After the 2008 financial crisis, enthusiasm for expensive icons declined somewhat, and attention turned toward social, sustainable, and modest architecture. The Pritzker Prize choices of the 2010s and 2020s, for example Alejandro Aravena (2016), Balkrishna Doshi (2018), Anne Lacaton and Jean-Philippe Vassal (2021), and Francis Kéré (2022), reflect this shift."]]
  ],
  terms:[["Deconstructivism","A 1980s–90s movement of fragmented, angular, destabilized forms."],["Bilbao effect","The idea that an iconic building can transform a city's fortunes."],["Starchitect","A celebrity architect whose buildings are used as landmarks and brands."],["Program","The set of activities and functions a building must accommodate."],["Folly","A small, often decorative building in a landscape; at La Villette, red pavilions."]],
  w:"Deconstructivism and the iconic building expanded what architecture could look like and showed both the power and the limits of landmark architecture.",
  src:["Deconstructivism","Guggenheim Museum Bilbao","Zaha Hadid","Rem Koolhaas","Jewish Museum Berlin","Bilbao effect"],
  q:[["Which 1988 exhibition named Deconstructivism?","MoMA's 'Deconstructivist Architecture'","The Venice Biennale","Expo 67","The Paris Exposition"],
     ["What is the 'Bilbao effect'?","The idea that an iconic building can revive a city","A structural failure","A way of cladding in titanium","A type of acoustics"],
     ["Who was the first woman to receive the Pritzker Prize?","Zaha Hadid","Kazuyo Sejima","Denise Scott Brown","Anne Lacaton"],
     ["Which book did Rem Koolhaas call a 'retroactive manifesto' for Manhattan?","Delirious New York","S, M, L, XL","Learning from Las Vegas","Junkspace"],
     ["What do the 'voids' in the Jewish Museum Berlin represent?","The absence left by the Holocaust","Storage spaces","Light wells for plants","Emergency exits"],
     ["Which software did Gehry's office adapt from aerospace?","CATIA","AutoCAD","Photoshop","SketchUp"]]}

]});


/* ---- from arch-14.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 14: Unit 7 Contemporary Architecture, chapters 4-6 */
COURSES.architecture.units[6].ch.push(

{ t:"Supertall Buildings", s:"Engineering the sky",
  sec:[
  ["The race goes global",[
    "For most of the 20th century, the world's tallest buildings were in the United States. That changed in 1998 when the Petronas Twin Towers in Kuala Lumpur, by César Pelli, at 452 meters, surpassed Chicago's Sears Tower. Since then, the tallest buildings have risen mainly in Asia and the Middle East, as symbols of economic ambition.",
    "The Council on Tall Buildings and Urban Habitat (CTBUH) defines 'supertall' buildings as those over 300 meters and 'megatall' as over 600 meters. Height is measured to the architectural top, including spires but not antennas, a rule that has caused disputes. Taipei 101 (2004, 508 meters) and the Shanghai World Financial Center (2008) followed."]],
  ["Burj Khalifa",[
    "The Burj Khalifa in Dubai (completed 2010), designed by Adrian Smith with SOM and engineered by William F. Baker, is about 828 meters tall and has been the world's tallest building since its completion. Its Y-shaped 'buttressed core' plan, with three wings supporting a central hexagonal core, gives great stiffness, while the wings step back in a spiral as the tower rises.",
    "This setback pattern 'confuses the wind': by changing the building's shape with height, it prevents organized vortices from forming and causing the building to sway. The tower's design was refined through many wind tunnel tests. Its plan was partly inspired by the desert flower Hymenocallis. As of 2025, the Jeddah Tower in Saudi Arabia, designed to exceed 1,000 meters, had resumed construction after a long pause."]],
  ["Structural systems for height",[
    "Tall buildings must resist gravity, but the real challenge is lateral (sideways) forces from wind and earthquakes. Structural systems evolved from rigid frames to braced frames, then Fazlur Khan's tube systems (framed tube, trussed tube, bundled tube) that use the building's perimeter as a stiff hollow tube. The Willis Tower uses nine bundled tubes; the John Hancock Center uses an X-braced tube.",
    "Modern supertalls often use a concrete core linked by outrigger trusses to massive perimeter columns (megacolumns), sometimes with belt trusses around the building. High-strength concrete, pumped hundreds of meters upward, and high-strength steel make these heights possible. Shanghai Tower (2015, 632 meters), by Gensler, has a twisting glass skin that reduces wind loads by about a quarter compared with a rectangular tower of the same height."]],
  ["Controlling sway and movement",[
    "Tall buildings sway in the wind; the goal is to keep accelerations low enough that occupants do not feel uncomfortable. Engineers use tuned mass dampers, huge weights that move to counteract sway. Taipei 101 has a 660-tonne steel sphere suspended between its 87th and 92nd floors, visible to visitors, which reduces swaying in typhoons.",
    "In earthquake zones, engineers also use base isolation (bearings that let the building move independently of the ground), energy-dissipating dampers, and flexible frames. Japan's buildings, influenced by the lessons of traditional pagodas, are among the most advanced in seismic design. Vertical transportation is another challenge: double-deck elevators, sky lobbies, and new lightweight cables such as KONE's carbon-fiber UltraRope allow longer elevator runs."]],
  ["Pencil towers and new forms",[
    "In New York, extremely slender residential towers have risen on small sites since the 2010s, sometimes called 'pencil towers' or 'Billionaires' Row' along 57th Street. Steinway Tower (111 West 57th Street, completed 2021), by SHoP Architects, has a slenderness ratio of about 1:24, among the most slender skyscrapers in the world.",
    "Others explore new shapes: twisting towers, towers with sky gardens, and clusters linked by skybridges, such as Marina Bay Sands in Singapore (2010), with a rooftop park spanning three towers. Mass timber high-rises, such as Ascent in Milwaukee (2022, about 87 meters), show a new direction for tall buildings."]],
  ["Debating the skyscraper",[
    "Supporters argue that tall buildings make efficient use of land, support public transport, and create dense, vibrant cities. Critics point to high embodied carbon (the emissions from producing steel, concrete, and glass), heavy energy use, shadows on streets and parks, wind at ground level, and the social effects of luxury towers that are often sparsely occupied.",
    "Research suggests that medium-rise, high-density neighborhoods, like Paris or Barcelona, can achieve high densities with less embodied carbon per square meter than supertall towers. The skyscraper remains a powerful symbol, but its role in sustainable cities is actively debated."]]
  ],
  terms:[["Supertall","A building over 300 meters tall, by CTBUH definition."],["Megatall","A building over 600 meters tall."],["Buttressed core","A central core braced by wings, used in the Burj Khalifa."],["Outrigger truss","A stiff truss linking a building's core to its perimeter columns."],["Tuned mass damper","A large mass that moves to counteract a building's sway."],["Base isolation","Bearings that separate a building from ground motion in earthquakes."],["Embodied carbon","Greenhouse gas emissions from producing and building materials."]],
  w:"Supertall buildings push engineering to its limits and raise important questions about density, sustainability, and the image of cities.",
  src:["Burj Khalifa","Taipei 101","Shanghai Tower","Tuned mass damper","Council on Tall Buildings and Urban Habitat","Jeddah Tower"],
  q:[["What height defines a 'supertall' building?","Over 300 meters","Over 100 meters","Over 600 meters","Over 1,000 meters"],
     ["Which building has been the world's tallest since 2010?","Burj Khalifa","Shanghai Tower","Taipei 101","Petronas Towers"],
     ["Why do the Burj Khalifa's wings step back in a spiral?","To 'confuse the wind' and reduce swaying","To create more balconies","To follow a religious tradition","To save on glass"],
     ["What does Taipei 101's huge steel sphere do?","Acts as a tuned mass damper reducing sway","Stores water","Generates electricity","Holds an observation deck"],
     ["How much does Shanghai Tower's twisting skin reduce wind loads?","About a quarter","About 90 percent","Not at all","It doubles them"],
     ["A key criticism of supertall buildings is their…","High embodied carbon","Low cost","Lack of elevators","Use of timber only"]]},

{ t:"Sustainable Architecture", s:"Designing for a changing climate",
  sec:[
  ["Why buildings matter for climate",[
    "Buildings are central to the climate challenge. According to UN Environment Programme reports, the buildings and construction sector accounts for roughly a third of global energy-related carbon dioxide emissions when operations and the production of materials like cement and steel are included. Cement production alone is responsible for roughly 7–8 percent of global CO2 emissions.",
    "Architects distinguish operational carbon, emissions from heating, cooling, lighting, and running buildings, from embodied carbon, emissions from extracting, manufacturing, transporting, and assembling materials, and from eventual demolition. As operational energy becomes cleaner and buildings more efficient, embodied carbon becomes a larger share of a building's lifetime impact."]],
  ["Passive design",[
    "The first rule of sustainable design is to reduce demand through passive design, using the building's form and materials rather than machines. Key strategies include orienting buildings to the sun, shading windows from high summer sun while admitting low winter sun, insulating well, using thermal mass (heavy materials that absorb and release heat slowly), and designing for natural cross-ventilation and stack ventilation (warm air rising and escaping high, drawing cool air in low).",
    "These principles are ancient. Persian windcatchers (badgir) catch breezes and draw air through buildings; courtyard houses create shaded, cool microclimates; thick adobe walls moderate desert temperatures. Modern architects often rediscover such vernacular wisdom. Daylighting, bringing natural light deep into buildings, reduces electric lighting and improves wellbeing."]],
  ["Passivhaus and net zero",[
    "Passivhaus (Passive House), a standard developed in Germany in the early 1990s by Wolfgang Feist and Bo Adamson, achieves very low heating and cooling needs through super-insulation, airtight construction, high-performance windows, elimination of thermal bridges, and mechanical ventilation with heat recovery. A certified Passivhaus typically uses a small fraction of the heating energy of a conventional building.",
    "A 'net zero energy' building produces as much renewable energy, for example through solar panels, as it uses over a year. 'Net zero carbon' goals also address embodied carbon. Rating systems such as LEED (US), BREEAM (UK), and others assess buildings on energy, water, materials, and health, though critics note that ratings do not always reflect real performance once buildings are in use."]],
  ["Materials and mass timber",[
    "Reducing embodied carbon involves using less material, choosing lower-carbon materials, and reusing what exists. Mass timber, engineered wood products such as cross-laminated timber (CLT, layers of boards glued crosswise into large panels) and glued-laminated timber (glulam), can replace concrete and steel in many buildings. Wood stores carbon absorbed by trees, provided forests are sustainably managed.",
    "Other approaches include low-carbon concrete with cement substitutes, rammed earth, straw bales, hempcrete, recycled steel, and designing for disassembly so components can be reused. The idea of a circular economy treats buildings as 'material banks'."]],
  ["Reuse: the greenest building",[
    "Architects often say 'the greenest building is the one that already exists'. Renovating and adapting existing buildings usually emits far less carbon than demolishing and rebuilding. The French architects Anne Lacaton and Jean-Philippe Vassal, Pritzker laureates in 2021, made this a principle: 'never demolish'. Their transformation of social housing blocks in Bordeaux (Grand Parc, completed 2016, with Frédéric Druot and Christophe Hutin) added winter gardens and balconies to apartments while residents stayed in their homes.",
    "Adaptive reuse transforms old buildings for new purposes: Tate Modern in London (2000), a former power station converted by Herzog & de Meuron; the High Line in New York (2009), an elevated railway turned into a park by James Corner Field Operations and Diller Scofidio + Renfro; and countless factories turned into homes, offices, and cultural centers."]],
  ["Resilience and adaptation",[
    "As the climate changes, buildings must also adapt to heat waves, floods, wildfires, storms, and rising seas. Strategies include raised floors and floodable ground levels, cool roofs and green roofs that reduce urban heat, fire-resistant materials and defensible space, and planning that avoids the most vulnerable locations.",
    "Cities are adopting 'sponge city' approaches (a term popularized in China by Kongjian Yu) that use parks, wetlands, and permeable surfaces to absorb floodwater. Biophilic design brings nature into buildings to improve health. Sustainability in architecture now encompasses energy, carbon, water, health, resilience, and social equity."]]
  ],
  terms:[["Operational carbon","Emissions from running a building: heating, cooling, lighting, and equipment."],["Passive design","Using form, orientation, and materials to control climate without machines."],["Thermal mass","Heavy materials that absorb and release heat slowly."],["Passivhaus","A rigorous standard for very low-energy buildings."],["Cross-laminated timber (CLT)","Large panels of wood boards glued in crosswise layers."],["Adaptive reuse","Converting an existing building to a new use."],["Sponge city","Urban design that absorbs and stores rainwater to reduce flooding."]],
  w:"Because buildings account for a large share of global emissions, sustainable design is now a core responsibility of every architect.",
  src:["Sustainable architecture","Passive house","Cross-laminated timber","Embodied energy","Adaptive reuse","Lacaton & Vassal"],
  q:[["What is embodied carbon?","Emissions from producing, transporting, and building with materials","Emissions from heating a building","Carbon stored in soil","Carbon in the air inside a building"],
     ["What is stack ventilation?","Warm air rising and escaping high, drawing cool air in low","Stacking fans on top of each other","Ventilation through stacked windows only","Pumping air with chimneys of fire"],
     ["Passivhaus relies heavily on…","Super-insulation, airtightness, and heat-recovery ventilation","Large air conditioners","Single-glazed windows","Open fires"],
     ["What is CLT?","Cross-laminated timber panels","Concrete-lined tunnels","Carbon light technology","A type of steel"],
     ["Which architects said 'never demolish' and won the 2021 Pritzker?","Anne Lacaton and Jean-Philippe Vassal","Herzog & de Meuron","SANAA","Diller Scofidio + Renfro"],
     ["Tate Modern in London was originally…","A power station","A railway station","A prison","A warehouse for tea"]]},

{ t:"Architecture Today", s:"Digital design, new materials, and a plural world",
  sec:[
  ["Digital design",[
    "Computers transformed architecture from the 1990s onward. Computer-aided design (CAD) replaced hand drafting, and 3D modeling allowed complex shapes. Building Information Modeling (BIM), using software such as Revit or ArchiCAD, creates a shared digital model containing geometry plus information about every component, its materials, cost, and performance, used by architects, engineers, and contractors to coordinate and reduce errors.",
    "Parametric design uses algorithms and rules, in tools like Grasshopper for Rhino, to generate forms that respond to variables such as sunlight, structure, or views. Changing a parameter updates the whole design. Computational tools also simulate daylight, energy use, airflow, acoustics, and structural behavior before anything is built. Artificial intelligence tools are increasingly used for generating options, analyzing designs, and producing images, raising debates about authorship and the architect's role."]],
  ["Digital fabrication",[
    "Digital models can be sent directly to machines: CNC (computer numerical control) cutters, laser cutters, robotic arms, and 3D printers. This 'file-to-factory' process enables unique, non-repeating components at reasonable cost, making complex curved facades and custom structures possible.",
    "3D printing of buildings in concrete or earth has been demonstrated for houses and small structures in many countries. Robotic construction, prefabrication, and modular building, in which entire rooms or apartments are made in factories and assembled on site, aim to make construction faster, cheaper, and less wasteful."]],
  ["Contemporary masters",[
    "No single style dominates contemporary architecture, but many approaches flourish. Herzog & de Meuron of Switzerland are famous for inventive skins and materials: the 'Bird's Nest' National Stadium for the 2008 Beijing Olympics, the Elbphilharmonie concert hall in Hamburg (2017), built on an old warehouse with a glass top like waves. SANAA (Kazuyo Sejima and Ryue Nishizawa) creates ethereal, light-filled spaces, as at the Rolex Learning Center in Lausanne.",
    "Peter Zumthor's Therme Vals in Switzerland (1996), a bath built of local quartzite layered like stone strata, is celebrated for its atmosphere and materiality. Tadao Ando's concrete buildings, like the Church of the Light in Osaka (1989) with a cross cut into the wall, use light and silence powerfully. Bjarke Ingels Group (BIG) combines playful forms with practical ideas, like CopenHill (2019), a waste-to-energy plant with a ski slope on its roof."]],
  ["Social architecture",[
    "A strong movement emphasizes architecture's social responsibility. Alejandro Aravena's firm Elemental in Chile built 'half a good house' for low-income families at Quinta Monroy in Iquique (2004): a solid structure with kitchen and bathroom, with space for residents to complete the other half themselves. He won the Pritzker in 2016 and made the designs open source.",
    "Shigeru Ban uses paper tubes and simple materials for disaster-relief shelters and temporary buildings, such as the Cardboard Cathedral in Christchurch, New Zealand (2013), built after the 2011 earthquake. Architects such as Yasmeen Lari in Pakistan, with low-cost, low-carbon bamboo and lime shelters after floods, and MASS Design Group in Rwanda, with the Butaro Hospital (2011) designed to reduce airborne infection, show architecture as a tool for health and justice."]],
  ["Contemporary Chinese and global architecture",[
    "China's rapid urbanization since the 1990s produced the largest construction boom in history, attracting foreign architects but also producing a generation of Chinese architects with distinctive voices. Wang Shu, who won the Pritzker in 2012, uses reclaimed tiles and bricks from demolished villages, as at the Ningbo History Museum (2008). Liu Jiakun, the 2025 Pritzker laureate, works in Chengdu, designing buildings rooted in everyday urban life, such as the West Village (2015), a block that combines sports, culture, and public space.",
    "Architects from Africa, Latin America, and South Asia are increasingly prominent internationally, from Diébédo Francis Kéré to Mexico's Tatiana Bilbao and Ghanaian-British David Adjaye, designer of the National Museum of African American History and Culture in Washington (2016). Architecture today is a global conversation."]],
  ["Themes of the present",[
    "Current debates in architecture include decarbonization and reuse, housing affordability, the integration of AI and digital tools, equity and diversity within the profession, participatory design with communities, resilience to climate change, and how to build beautiful places people love.",
    "Contemporary architecture is plural: it can be high-tech or low-tech, iconic or modest, global or local. What unites the best work is careful attention to context, materials, people, and the long life of buildings."]]
  ],
  terms:[["CAD","Computer-aided design, using software to draw and model."],["BIM","Building Information Modeling: a shared digital model with information about all building components."],["Parametric design","Design generated by algorithms responding to variables."],["CNC","Computer numerical control: machines cutting or shaping materials from digital files."],["Modular construction","Building with factory-made room or apartment units assembled on site."],["Incremental housing","Housing designed for residents to complete and expand over time."]],
  w:"Contemporary architecture combines digital tools, new materials, and a renewed social and environmental purpose in a plural, global field.",
  src:["Building information modeling","Parametric design","Herzog & de Meuron","Alejandro Aravena","Shigeru Ban","Liu Jiakun"],
  q:[["What does BIM stand for?","Building Information Modeling","Basic Interior Measurement","Building Infrastructure Management","Brick and Iron Masonry"],
     ["Parametric design uses…","Algorithms and variables to generate forms","Only hand drawings","Historical pattern books","Random guesses"],
     ["Who designed the Elbphilharmonie in Hamburg?","Herzog & de Meuron","SANAA","BIG","Zaha Hadid Architects"],
     ["What was Elemental's approach at Quinta Monroy?","Building 'half a good house' for residents to complete","Building luxury towers","Using 3D printing only","Demolishing old homes"],
     ["Shigeru Ban is known for buildings made with…","Paper tubes","Titanium panels","Gold leaf","Marble"],
     ["Who won the Pritzker Prize in 2025?","Liu Jiakun","Wang Shu","Riken Yamamoto","David Adjaye"]]}

);


/* ---- from arch-15.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 15: Unit 8 Cities and Landscapes, chapters 1-3 */
COURSES.architecture.units.push({ t:"Cities and Landscapes", ch:[

{ t:"Twentieth-Century Planning", s:"Towers in parks, highways, Jane Jacobs, and New Urbanism",
  sec:[
  ["Planning becomes a profession",[
    "Town planning emerged as a profession in the early 20th century, building on the reforms of the 19th. Britain's Housing, Town Planning, &c. Act of 1909 gave local authorities planning powers, and the US saw its first zoning laws in the 1910s. In 1926, the US Supreme Court's decision in Village of Euclid v. Ambler Realty upheld zoning that separated land uses, such as industry, commerce, and housing, into distinct districts, a pattern that spread across America.",
    "Planners had good intentions: separating dirty factories from homes, ensuring light and air, and controlling chaotic growth. But rigid use separation also produced car-dependent landscapes, and in the US, zoning and lending practices were used to enforce racial segregation. 'Redlining' maps of the 1930s rated Black and immigrant neighborhoods as hazardous for lending, denying investment for decades."]],
  ["The modernist city",[
    "CIAM's Athens Charter (developed from 1933, published by Le Corbusier in 1943) divided the city into four functions: dwelling, work, recreation, and circulation. It promoted high-rise housing set in green space, separated from fast traffic routes. After World War II, these ideas guided the rebuilding of bombed cities and the 'slum clearance' of older neighborhoods worldwide.",
    "Large housing estates of towers and slabs, ring roads, and urban motorways appeared in many cities. Brasília and Chandigarh were entire new capitals planned on modernist lines. Britain built new towns such as Stevenage, Harlow, and Milton Keynes, the last famous for its grid of roads and roundabouts."]],
  ["Robert Moses and urban renewal",[
    "In New York, Robert Moses, who held many public offices from the 1920s to the 1960s without ever being elected to one, built an astonishing amount: parks, beaches, bridges, more than 400 miles of parkways and expressways, public housing, Lincoln Center, and the UN site. Robert Caro's 1974 biography 'The Power Broker' documented his methods, including the displacement of hundreds of thousands of people, disproportionately poor and nonwhite residents, for highways and projects like the Cross Bronx Expressway.",
    "Across America, the Housing Act of 1949 and Federal-Aid Highway Act of 1956 funded 'urban renewal' and interstate highways that often cut through and destroyed established Black and immigrant neighborhoods. The demolition of vibrant districts, such as Detroit's Black Bottom and Paradise Valley, left lasting scars."]],
  ["Jane Jacobs",[
    "Jane Jacobs (1916–2006), a writer and activist living in Greenwich Village, attacked modernist planning in 'The Death and Life of Great American Cities' (1961). She argued that healthy city neighborhoods need mixed uses throughout the day, short blocks, buildings of varied ages including old cheap ones, and sufficient density. She championed the 'sidewalk ballet' of ordinary street life and 'eyes on the street', residents and shopkeepers whose natural watchfulness keeps streets safe.",
    "Jacobs helped defeat Moses's plan for a Lower Manhattan Expressway that would have cut through SoHo and Little Italy. Her ideas transformed planning, encouraging mixed use, historic neighborhood preservation, and community participation. The 'freeway revolts' in cities like San Francisco, Toronto (where Jacobs later lived), and Boston stopped several urban highways."]],
  ["New Urbanism and its cousins",[
    "From the 1980s, New Urbanism promoted walkable neighborhoods with a mix of housing types, shops within walking distance, connected street grids, public spaces, and traditional architecture. Andrés Duany and Elizabeth Plater-Zyberk designed Seaside, Florida (begun 1981), a small resort town that became famous, and the Congress for the New Urbanism was founded in 1993. Critics say many New Urbanist developments became expensive enclaves or suburban developments with nostalgic styling.",
    "Related ideas include Transit-Oriented Development, concentrating housing and jobs near public transport stations; 'smart growth' to limit sprawl; and Jan Gehl's 'cities for people', which uses careful study of how people use streets and squares to improve public space. Gehl's work helped transform Copenhagen's streets and influenced the pedestrianization of Times Square in New York (2009 onward)."]],
  ["Planning today",[
    "Contemporary planning focuses on sustainability, density, public transport, walkability, cycling, affordable housing, and resilience. The '15-minute city', promoted by Carlos Moreno and adopted in Paris under Mayor Anne Hidalgo, aims for daily needs to be reachable within a short walk or bike ride.",
    "Many cities are reforming zoning to allow more housing, ending single-family-only zoning (Minneapolis in 2019 was an early example) and reducing parking requirements. Planners also seek to repair the damage of past highways and segregation, for instance by removing urban freeways, as Seoul did with the Cheonggyecheon stream restoration (2005), replacing an elevated highway with a linear park."]]
  ],
  terms:[["Zoning","Regulations dividing a city into districts with permitted uses and building sizes."],["Redlining","Discriminatory denial of loans to areas, often based on race."],["Urban renewal","Mid-20th-century programs clearing older neighborhoods for redevelopment."],["Eyes on the street","Jane Jacobs's idea that people watching the street naturally keep it safe."],["New Urbanism","A movement for walkable, mixed-use neighborhoods with traditional street patterns."],["Transit-Oriented Development","Concentrating housing and jobs near public transport."],["15-minute city","A city where daily needs are within a 15-minute walk or bike ride."]],
  w:"Twentieth-century planning shows how decisions about zoning, highways, and housing shape cities and lives for generations.",
  src:["Urban planning","Jane Jacobs","Robert Moses","Urban renewal","New Urbanism","15-minute city"],
  q:[["What did the 1926 Euclid v. Ambler decision uphold?","Zoning separating land uses","Federal highway funding","Public housing","Historic preservation"],
     ["What was redlining?","Discriminatory denial of loans to certain neighborhoods","Painting fire lanes","A highway design standard","A zoning height limit"],
     ["Who wrote 'The Death and Life of Great American Cities'?","Jane Jacobs","Robert Caro","Lewis Mumford","Jan Gehl"],
     ["Jacobs's 'eyes on the street' refers to…","People whose watchfulness keeps streets safe","Security cameras","Police patrols","Street lighting"],
     ["Seaside, Florida is associated with…","New Urbanism","Brutalism","Metabolism","The Garden City"],
     ["Seoul's Cheonggyecheon project replaced an elevated highway with…","A restored stream and linear park","A subway line","A shopping mall","A wider highway"]]},

{ t:"Housing", s:"How people live, from row houses to social housing",
  sec:[
  ["Housing as architecture's biggest task",[
    "Housing makes up most of the built environment in any city. Its design affects health, family life, community, affordability, and the environment. Yet most housing is built by developers and builders without architects, following market forces, regulations, and local traditions.",
    "Throughout history, typical housing types reflect climate, culture, technology, and economics: the courtyard house of the Middle East and China, the row house of northern Europe, the apartment block of Paris and Berlin, the detached house of American suburbs, and the informal self-built houses in which roughly a billion people live today."]],
  ["Housing types",[
    "Architects classify housing by type. Detached houses stand alone on their own plots. Semi-detached houses share one wall. Row houses (terraced houses, townhouses) share walls on both sides and have their own entrances. Low-rise apartments, such as walk-ups, have shared stairs and typically three to five stories. Mid-rise and high-rise apartment buildings require elevators.",
    "'Missing middle' housing, a term coined by Daniel Parolek, refers to types between single-family houses and large apartment blocks, such as duplexes, triplexes, courtyard apartments, and small multiplexes, that were common before World War II but were made illegal by much American zoning. Many cities now encourage them to increase housing supply in walkable neighborhoods."]],
  ["Social housing in Europe",[
    "After World War I, European cities built large amounts of public housing. In 'Red Vienna' (1919–1934), the socialist city government built over 60,000 apartments, many in large courtyard blocks called Höfe, with gardens, laundries, kindergartens, and libraries. The Karl-Marx-Hof (1927–1930), over a kilometer long, is the most famous. Vienna still houses a large share of its residents in municipal and subsidized housing, often cited as a model of affordable housing.",
    "In Frankfurt, Ernst May's 'New Frankfurt' program (1925–1930) built about 12,000 modern homes with efficient designs, including Margarete Schütte-Lihotzky's 'Frankfurt Kitchen', a compact, fitted kitchen designed like a laboratory, the ancestor of the modern fitted kitchen. Berlin's modernist housing estates, including Bruno Taut's Horseshoe Estate (Hufeisensiedlung), are a UNESCO World Heritage Site."]],
  ["The American suburb",[
    "After World War II, the US built millions of suburban houses, supported by federally insured mortgages and highways. Levittown on Long Island (1947–1951) used assembly-line methods to build over 17,000 nearly identical houses, sold initially only to white buyers due to racial covenants. The suburb, with detached houses, lawns, garages, and cul-de-sacs, became the dominant American housing form.",
    "Suburbs gave many families space and homeownership, but they also increased car dependence, energy use, segregation, and infrastructure costs. Today, debates about suburbs focus on how to make them more walkable, diverse, and sustainable, for example by adding accessory dwelling units (ADUs), small second homes on a single lot."]],
  ["Informal settlements",[
    "UN-Habitat estimates that over a billion people live in informal settlements or slums, often self-built on land without legal title and lacking adequate water, sanitation, or secure tenure. These settlements, such as favelas in Brazil or Dharavi in Mumbai, are also places of enterprise, community, and ingenuity.",
    "Approaches have shifted from demolition to upgrading: providing infrastructure, legal security, and services while allowing residents to stay. Projects like Elemental's incremental housing, Medellín's cable cars and library parks connecting hillside neighborhoods in Colombia, and Thailand's Baan Mankong program, which supported community-led upgrading, show alternatives."]],
  ["Designing good housing",[
    "Good housing design considers daylight, cross-ventilation, privacy, acoustic separation, storage, flexibility for changing families, accessibility, outdoor space, and the relationship between private homes and shared spaces. Space standards, such as minimum room sizes, protect residents from cramped conditions.",
    "Contemporary approaches include co-housing, where residents share common facilities while keeping private homes, cooperative housing, and community land trusts that keep housing permanently affordable. Housing affordability is one of the defining challenges facing cities today, and architects are increasingly involved in policy as well as design."]]
  ],
  terms:[["Row house","A house sharing side walls with its neighbors in a row."],["Missing middle","Housing types between detached houses and large apartment buildings."],["Social housing","Housing provided at below-market cost by governments or nonprofits."],["Frankfurt Kitchen","A compact, efficient fitted kitchen designed by Margarete Schütte-Lihotzky."],["Accessory dwelling unit (ADU)","A small second home on a single residential lot."],["Informal settlement","Housing built without formal planning or legal title, often lacking services."]],
  w:"Housing is architecture's largest and most important task, shaping health, community, and equality.",
  src:["Public housing","Red Vienna","Frankfurt kitchen","Levittown, New York","Missing middle housing","Slum upgrading"],
  q:[["What is 'missing middle' housing?","Types between detached houses and large apartment blocks","Housing for middle-aged people","Houses without hallways","Apartments in the middle of towers"],
     ["The Karl-Marx-Hof is a famous example of…","Red Vienna's social housing","American suburbs","Le Corbusier's Unité","Brutalist towers"],
     ["Who designed the Frankfurt Kitchen?","Margarete Schütte-Lihotzky","Ernst May","Lilly Reich","Charlotte Perriand"],
     ["How did Levittown build houses so quickly?","Assembly-line construction methods","3D printing","Prefabricated steel towers","Volunteer labor"],
     ["About how many people live in informal settlements worldwide, according to UN-Habitat?","Over a billion","About 10 million","About 100,000","Nearly everyone"],
     ["What is an ADU?","A small second home on a residential lot","A type of apartment tower","A zoning district","A housing agency"]]},

{ t:"Landscape Architecture and Gardens", s:"Designing with living things",
  sec:[
  ["What landscape architects do",[
    "Landscape architecture is the design of outdoor spaces: parks, gardens, plazas, campuses, streets, waterfronts, and entire regions. It combines art and ecology, working with land, water, plants, climate, and time. Unlike buildings, landscapes grow and change, and good landscape design anticipates how they will mature over decades.",
    "The term 'landscape architect' was popularized by Frederick Law Olmsted and Calvert Vaux in the 19th century. Today, landscape architects work on stormwater management, ecological restoration, urban heat reduction, and public health, as well as beauty and recreation."]],
  ["Historic garden traditions",[
    "Gardens are among humanity's oldest designed environments. Persian gardens, divided into four parts by water channels (the charbagh), symbolized paradise; the word 'paradise' derives from an Old Persian word for an enclosed garden. Chinese scholars' gardens, such as those of Suzhou (a UNESCO site), compose rocks, water, plants, and pavilions into miniature landscapes for contemplation, using 'borrowed scenery' to frame distant views.",
    "Italian Renaissance gardens like Villa d'Este and Villa Lante used terraces, axes, and water features on hillsides. French formal gardens, perfected by Le Nôtre at Versailles, extended geometry across the landscape. Japanese gardens include stroll gardens, dry gardens of rock and gravel, and tea gardens with stepping stones and lanterns."]],
  ["The English landscape garden",[
    "In 18th-century England, a new style rejected formal geometry in favor of idealized natural landscapes: rolling lawns, clumps of trees, serpentine lakes, and carefully placed temples and bridges, inspired by landscape paintings of Claude Lorrain and Nicolas Poussin. William Kent and later Lancelot 'Capability' Brown, who designed around 170 parks, including Blenheim's lake and Stowe, were its masters.",
    "The ha-ha, a sunken wall or ditch, kept livestock away from the house without interrupting the view, so the garden seemed to merge with the countryside. Humphry Repton later produced 'Red Books' with before-and-after watercolors to show clients proposed changes. This English style influenced parks worldwide, including Olmsted's Central Park."]],
  ["Modern landscape architecture",[
    "In the 20th century, landscape architects adapted modernist ideas. Roberto Burle Marx in Brazil used bold, abstract patterns of tropical plants and mosaic paving, as along Copacabana Beach's wave-patterned promenade. Thomas Church and Garrett Eckbo in California designed gardens for modern outdoor living. Dan Kiley collaborated with modernist architects on geometric landscapes.",
    "Ian McHarg's 'Design with Nature' (1969) introduced ecological planning, mapping layers of soil, water, vegetation, and habitats to decide where to build. Lawrence Halprin designed participatory, choreographed spaces like the Lovejoy Fountain in Portland and the FDR Memorial in Washington. Peter Walker and Michael Arad designed the National September 11 Memorial in New York (2011), with two vast reflecting pools in the footprints of the Twin Towers."]],
  ["Contemporary landscapes",[
    "Recent landscape architecture often transforms post-industrial sites. Landschaftspark Duisburg-Nord in Germany (1990s), by Latz + Partner, turned a steelworks into a park, keeping blast furnaces as climbing walls and gardens. The High Line in New York converted a disused elevated railway into a planted promenade inspired by the wild plants that had grown there, with planting by Piet Oudolf, a leader of naturalistic 'New Perennial' planting.",
    "Kongjian Yu's firm Turenscape in China designs 'sponge' parks that absorb floodwater and restore wetlands, as at Qunli Stormwater Park in Harbin. Waterfront parks, green roofs, urban forests, and rewilding projects show landscape architecture at the center of climate adaptation."]],
  ["Principles for designing landscapes",[
    "Landscape design considers topography (the shape of the land), drainage, soil, microclimate, plant selection suited to local conditions, maintenance, seasonal change, and how people will use and move through spaces. Native plants support local wildlife and often need less water. Trees provide shade and cooling, reducing urban heat.",
    "Landscape and architecture are deeply connected: the approach to a building, the views from inside, the outdoor rooms around it, and the setting it creates. The best architects think of building and landscape as one design."]]
  ],
  terms:[["Landscape architecture","The design of outdoor spaces, parks, and landscapes."],["Charbagh","A Persian four-part garden divided by water channels."],["Borrowed scenery","Incorporating distant views into a garden's composition."],["Ha-ha","A sunken wall or ditch that keeps animals out without blocking the view."],["English landscape garden","An 18th-century style of idealized naturalistic parkland."],["Ecological planning","Planning based on mapping natural systems, as advocated by Ian McHarg."]],
  w:"Landscape architecture designs the outdoor world, and it is now central to cities' ecology, health, and climate resilience.",
  src:["Landscape architecture","English landscape garden","Capability Brown","Roberto Burle Marx","Ian McHarg","High Line"],
  q:[["The word 'paradise' comes from an Old Persian word for…","An enclosed garden","A mountain","A palace","A river"],
     ["Who designed around 170 English parks, including Blenheim's lake?","Capability Brown","William Kent","Humphry Repton","Joseph Paxton"],
     ["What is a ha-ha?","A sunken wall or ditch that does not block views","A garden fountain","A Japanese tea house","A type of hedge maze"],
     ["Who designed Copacabana's wave-patterned promenade?","Roberto Burle Marx","Oscar Niemeyer","Lúcio Costa","Luis Barragán"],
     ["Ian McHarg's 'Design with Nature' introduced…","Ecological planning using mapped layers","The garden city","The 15-minute city","Formal French gardens"],
     ["Landschaftspark Duisburg-Nord was formerly…","A steelworks","An airport","A railway","A royal hunting ground"]]}

]});


/* ---- from arch-16.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 16: Unit 8 Cities and Landscapes, chapters 4-6 */
COURSES.architecture.units[7].ch.push(

{ t:"Bridges and Infrastructure", s:"Spanning, moving, and serving the city",
  sec:[
  ["The main bridge types",[
    "Bridges show structural principles with exceptional clarity. A beam bridge is a horizontal beam on supports; simple, but limited in span because beams bend. A truss bridge uses a framework of triangles to make a lighter, stiffer beam. An arch bridge carries loads in compression to its abutments, which must resist outward thrust.",
    "A cantilever bridge uses arms projecting from piers, sometimes supporting a central suspended span, as in Scotland's Forth Bridge (1890). A suspension bridge hangs its deck from vertical cables attached to main cables draped over towers and anchored at the ends. A cable-stayed bridge connects the deck directly to towers with straight diagonal cables."]],
  ["Great bridges",[
    "The Golden Gate Bridge in San Francisco (1937), designed by a team led by Joseph Strauss with Charles Ellis and Leon Moisseiff, was the world's longest suspension span at about 1,280 meters, and its 'International Orange' color and Art Deco towers made it an icon. The Akashi Kaikyō Bridge in Japan (1998) held the record for the longest suspension span for over two decades until Turkey's 1915 Çanakkale Bridge (2022), with a main span of about 2,023 meters.",
    "The Millau Viaduct in France (2004), designed by Norman Foster with engineer Michel Virlogeux, is a cable-stayed bridge whose tallest pier reaches about 343 meters including its mast, making it the tallest bridge structure in the world. Santiago Calatrava, an architect-engineer, designed sculptural bridges in many cities, such as the Puente del Alamillo in Seville (1992)."]],
  ["Lessons from failure",[
    "Engineers have learned much from failures. The Tacoma Narrows Bridge in Washington State collapsed in 1940, just months after opening, because wind caused aeroelastic flutter, twisting the slender, shallow deck until it broke. Film of 'Galloping Gertie' became a famous lesson. Since then, bridges are tested in wind tunnels and designed with aerodynamic decks.",
    "London's Millennium Bridge (2000) swayed sideways when crowds crossed on opening day, because pedestrians unconsciously synchronized their steps with its motion. It was closed and fitted with dampers, reopening in 2002. The 2018 collapse of the Morandi Bridge in Genoa, killing 43 people, highlighted the importance of maintenance and inspection of aging concrete infrastructure."]],
  ["Infrastructure as architecture",[
    "Infrastructure includes transport (roads, railways, subways, airports, ports), water supply and sewers, energy (power plants, grids), and communications. Its design shapes cities' form and quality of life. Great infrastructure has often been designed with architectural ambition, such as the stations of the Moscow Metro, the Stockholm subway's painted caves, or Washington, D.C.'s coffered concrete Metro stations by Harry Weese.",
    "Airports are modern gateways and complex machines. Eero Saarinen's Dulles International Airport (1962) has a sweeping suspended roof; Foster's Stansted Airport (1991) put services below the floor so the roof could be light and transparent, a model for later terminals. Singapore's Changi Airport added the 'Jewel' (2019), with an indoor waterfall about 40 meters high."]],
  ["Water and energy",[
    "Dams, reservoirs, and aqueducts remain major works. The Hoover Dam (1936) on the Colorado River was a triumph of engineering with Art Deco detailing by architect Gordon Kaufmann. China's Three Gorges Dam (completed 2006, with full operation by 2012) is the world's largest hydropower station by installed capacity, though it displaced over a million people.",
    "Energy infrastructure is changing rapidly with the shift to renewables: solar farms, wind turbines, battery storage, and new transmission lines. Designers increasingly consider how such infrastructure fits into landscapes and communities, and how it can serve multiple purposes, as with Copenhagen's CopenHill, a waste-to-energy plant with a ski slope."]],
  ["Green and blue infrastructure",[
    "Traditional 'gray' infrastructure uses pipes and concrete. 'Green infrastructure' uses natural systems: trees, rain gardens, bioswales (planted channels), green roofs, and wetlands to manage stormwater, cool cities, and support biodiversity. 'Blue infrastructure' refers to rivers, canals, and water bodies.",
    "The Netherlands' 'Room for the River' program (completed around 2015) gave rivers more space to flood safely rather than building ever-higher dikes. New York's plans after Hurricane Sandy in 2012 included landscaped berms and parks designed to protect lower Manhattan. Infrastructure design today aims to be multifunctional, resilient, and beautiful."]]
  ],
  terms:[["Beam bridge","A bridge carried by horizontal beams on supports."],["Truss","A framework of triangles that forms a light, stiff structure."],["Suspension bridge","A bridge whose deck hangs from cables draped over towers."],["Cable-stayed bridge","A bridge whose deck is supported by straight cables running directly to towers."],["Aeroelastic flutter","A wind-driven oscillation that can destroy slender structures."],["Green infrastructure","Natural systems used to manage water, heat, and ecology in cities."]],
  w:"Bridges and infrastructure reveal structure most clearly and shape how cities work, move, and survive.",
  src:["Bridge","Golden Gate Bridge","1915 Çanakkale Bridge","Millau Viaduct","Tacoma Narrows Bridge (1940)","Green infrastructure"],
  q:[["In a cable-stayed bridge, the deck is supported by…","Straight cables running directly to towers","Vertical hangers from draped main cables","Stone arches","Floating pontoons"],
     ["Which bridge has the longest suspension span as of its 2022 opening?","1915 Çanakkale Bridge","Golden Gate Bridge","Akashi Kaikyō Bridge","Brooklyn Bridge"],
     ["Why did the Tacoma Narrows Bridge collapse in 1940?","Wind-induced aeroelastic flutter","An earthquake","A ship collision","Overloading by trucks"],
     ["Why did London's Millennium Bridge sway on opening?","Pedestrians synchronized their steps with its motion","A storm hit it","Its cables snapped","It was built on sand"],
     ["The Millau Viaduct is known as…","The tallest bridge structure in the world","The oldest bridge in France","A wooden bridge","An underwater tunnel"],
     ["The Dutch 'Room for the River' program…","Gave rivers more space to flood safely","Built higher dikes everywhere","Drained all rivers","Moved cities inland"]]},

{ t:"Heritage and Preservation", s:"Keeping the past alive",
  sec:[
  ["Why preserve buildings?",[
    "Historic buildings carry memory, identity, craftsmanship, and meaning for communities. They also embody energy and materials already spent. Preservation (or conservation) aims to protect significant buildings, places, and landscapes for future generations, while allowing them to remain in use.",
    "Modern preservation grew in the 19th century. In France, Prosper Mérimée, as inspector-general of historic monuments from 1834, catalogued and protected buildings. In Britain, William Morris's Society for the Protection of Ancient Buildings (1877) argued for repair rather than restoration. The US preservation movement grew after the demolition of Penn Station in the 1960s, leading to the National Historic Preservation Act of 1966."]],
  ["Restoration, conservation, and reconstruction",[
    "Different approaches exist. Conservation aims to keep as much original material as possible, with minimal intervention. Restoration returns a building to an earlier appearance, sometimes removing later additions. Reconstruction rebuilds a lost building, which raises questions of authenticity. Adaptive reuse changes a building's function while preserving its character.",
    "International charters guide practice. The Venice Charter (1964) emphasized respecting original material and making new additions distinguishable from the old. The Nara Document on Authenticity (1994), drafted in Japan, recognized that authenticity varies by culture, for example, the ritual rebuilding of Ise Shrine preserves authenticity through form and craft rather than original material."]],
  ["World Heritage",[
    "UNESCO's World Heritage Convention (1972) recognizes sites of 'outstanding universal value'. The list includes well over a thousand sites, cultural and natural, from the pyramids to modernist buildings. The campaign to save the Abu Simbel temples in the 1960s helped inspire the convention.",
    "World Heritage status brings prestige and tourism but also pressures, such as over-tourism in Venice or Dubrovnik. Sites can be placed on the List of World Heritage in Danger due to war, neglect, or development. Liverpool lost its World Heritage status in 2021 because of waterfront development, and Dresden's Elbe Valley lost its status in 2009 after a new bridge was built."]],
  ["War, disaster, and rebuilding",[
    "War and disaster have destroyed countless monuments. After World War II, Warsaw's historic center, deliberately destroyed by German forces in 1944, was meticulously reconstructed, partly using 18th-century paintings by Bernardo Bellotto; it became a UNESCO site in 1980 as an example of reconstruction. Dresden's Frauenkirche, destroyed in 1945, was rebuilt from 1994 to 2005, incorporating original blackened stones.",
    "More recent destruction includes the Bamiyan Buddhas in Afghanistan (2001), the ancient city of Palmyra in Syria (2015), and the Old City of Mosul, where the al-Nuri Mosque and its leaning minaret were destroyed in 2017. UNESCO's 'Revive the Spirit of Mosul' project supported reconstruction using traditional techniques and local craftspeople. Notre-Dame's restoration after the 2019 fire showed the importance of traditional craft skills and good documentation, including laser scans made before the fire."]],
  ["Modern heritage",[
    "Preserving 20th-century buildings presents special challenges. Modernist buildings often used experimental materials that age badly, like early curtain walls or thin concrete, and they may not meet modern energy standards. Organizations like Docomomo (founded 1988) advocate for modern heritage.",
    "Debates continue about which recent buildings deserve protection: Brutalist housing estates, postmodern offices, or even fast-food restaurants and gas stations that represent everyday history. Preservation also increasingly includes 'intangible heritage', such as building skills and traditions, and places significant to communities whose histories were once overlooked."]],
  ["Preservation and change",[
    "Cities must balance preservation with the need for new housing and development. Critics argue that excessive historic designation can limit housing supply and raise prices; supporters argue that historic neighborhoods are valuable and that new development can be designed to fit.",
    "Good practice involves understanding a building's significance, documenting it carefully, and intervening thoughtfully. Successful projects, like David Chipperfield's restoration of the Neues Museum in Berlin (2009), combine repair of damaged historic fabric with clearly modern additions, honoring both history and the present."]]
  ],
  terms:[["Conservation","Protecting and maintaining historic material with minimal intervention."],["Restoration","Returning a building to an earlier state."],["Reconstruction","Rebuilding a lost or destroyed building."],["Venice Charter","A 1964 international charter guiding conservation practice."],["World Heritage Site","A site of outstanding universal value listed by UNESCO."],["Intangible heritage","Traditions, skills, and practices passed through generations."]],
  w:"Preservation keeps the meaning and memory of places alive and is an essential part of responsible, sustainable architecture.",
  src:["Historic preservation","Venice Charter","World Heritage Site","Nara Document on Authenticity","Historic Centre of Warsaw","Neues Museum"],
  q:[["What is the difference between conservation and restoration?","Conservation minimizes intervention; restoration returns to an earlier state","They are identical","Restoration demolishes buildings","Conservation always rebuilds"],
     ["Which 1964 charter guides conservation practice?","The Venice Charter","The Athens Charter","The Nara Charter","The Paris Accord"],
     ["What did the Nara Document recognize?","Authenticity varies across cultures","All buildings must be original material","Modern buildings cannot be heritage","Reconstruction is always wrong"],
     ["Which city lost World Heritage status in 2021?","Liverpool","Venice","Warsaw","Paris"],
     ["How was Warsaw's historic center reconstructed?","Partly using 18th-century paintings by Bellotto","Using photographs from the 1990s","By copying Kraków","With entirely modern designs"],
     ["Who restored Berlin's Neues Museum, blending old and new?","David Chipperfield","Norman Foster","Daniel Libeskind","Rem Koolhaas"]]},

{ t:"Cities of the Future", s:"Density, technology, and the challenges ahead",
  sec:[
  ["An urban planet",[
    "According to the United Nations, over half of the world's population has lived in cities since around 2007, and roughly two-thirds are projected to by 2050. Most urban growth will occur in Africa and Asia. Megacities of over ten million people, such as Tokyo, Delhi, Shanghai, São Paulo, Lagos, and Cairo, face enormous demands for housing, transport, water, and energy.",
    "How these cities are built will shape the climate, economy, and wellbeing of billions. Urban sprawl increases car dependence and land consumption; well-planned density supports public transport and efficient services."]],
  ["Smart cities",[
    "'Smart city' initiatives use sensors, data, and digital networks to manage traffic, energy, water, waste, and public services more efficiently. Examples include real-time transit information, adaptive traffic lights, and sensors detecting water leaks. Singapore has invested heavily in such systems.",
    "Critics warn that smart city technology can increase surveillance, concentrate power in technology companies, and distract from basic needs. Sidewalk Labs' plan for Toronto's waterfront, cancelled in 2020 amid privacy concerns and economic uncertainty, became a cautionary example. The most successful approaches put residents' needs, privacy, and participation first."]],
  ["New cities",[
    "Governments continue to build entirely new cities. Some succeed; others remain underpopulated. Examples include Songdo in South Korea, planned as a business hub; Masdar City in Abu Dhabi, launched in 2006 as a low-carbon city, whose ambitions were scaled back; Egypt's New Administrative Capital east of Cairo; and Indonesia's planned new capital Nusantara on Borneo.",
    "Saudi Arabia's NEOM project included 'The Line', proposed as a linear city 170 km long between two mirrored walls; by 2024–2025, reports indicated its plans were being substantially scaled back. Such projects raise questions about cost, environmental impact, human rights, and whether top-down planned cities can create genuine urban life."]],
  ["Mobility",[
    "Transport shapes cities. Many cities are reducing car dominance by investing in public transit, cycling infrastructure, and pedestrian space. Copenhagen and Amsterdam are famous for cycling; Paris has added extensive bike lanes and pedestrianized streets; Barcelona's superblocks reclaim streets for people.",
    "Electric vehicles reduce tailpipe emissions but not congestion or the space taken by cars. Autonomous vehicles could change parking needs and street design, though their impact remains uncertain. Planners increasingly emphasize 'access' rather than 'mobility': bringing destinations closer rather than making travel faster."]],
  ["Climate adaptation",[
    "Cities must adapt to rising seas, heat waves, and extreme storms. Coastal cities from Jakarta to Miami face flooding; Jakarta is sinking partly due to groundwater extraction, one reason Indonesia is relocating its capital. Rotterdam has built 'water squares' that hold stormwater during heavy rain and serve as public spaces otherwise.",
    "Heat is a growing danger; urban heat islands make cities several degrees hotter than surrounding areas. Strategies include planting trees, cool and green roofs, shaded streets, and reflective surfaces. Some cities have appointed 'chief heat officers'. Architects play a key role in designing buildings that stay cool with less energy."]],
  ["The role of the architect",[
    "The future city will be shaped by many forces: politics, economics, technology, ecology, and the choices of millions of people. Architects contribute by designing buildings and spaces that are adaptable, sustainable, beautiful, and humane, and by engaging communities in shaping their environments.",
    "Perhaps the most important lesson from history is humility: cities are complex systems that evolve over centuries, and the best plans leave room for change, diversity, and the unplanned richness of human life, the qualities Jane Jacobs celebrated."]]
  ],
  terms:[["Megacity","A city with over ten million inhabitants."],["Smart city","A city using digital technology and data to manage services."],["Urban heat island","A city area significantly warmer than its surroundings."],["Superblock","A group of city blocks where through traffic is restricted to create pedestrian space."],["Water square","A public plaza designed to store stormwater during heavy rain."]],
  w:"The world is urbanizing rapidly, and the design of cities will determine how billions of people live in a changing climate.",
  src:["Urbanization","Smart city","Masdar City","The Line, Saudi Arabia","Urban heat island","Superblock (Barcelona)"],
  q:[["Since about 2007, what share of the world's people has lived in cities?","Over half","About 10 percent","About a quarter","Over 95 percent"],
     ["A key criticism of smart cities is…","Increased surveillance and corporate power","They have too many trees","They ban computers","They are always too small"],
     ["Masdar City was launched as…","A low-carbon city in Abu Dhabi","A Korean business hub","A Brazilian capital","A floating city"],
     ["Why is Indonesia relocating its capital from Jakarta?","Partly because Jakarta is sinking and flooding","Because of an earthquake","Because Jakarta is too small","Because of a volcano"],
     ["Rotterdam's 'water squares' are…","Public spaces that store stormwater in heavy rain","Swimming pools","Fountains for tourists","Canals for boats"],
     ["Planners emphasizing 'access' rather than 'mobility' aim to…","Bring destinations closer to people","Build faster highways","Increase car ownership","Remove public transport"]]}

);


/* ---- from arch-17.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 17: Unit 9 The Practice of Architecture, chapters 1-4 */
COURSES.architecture.units.push({ t:"The Practice of Architecture", ch:[

{ t:"Architectural Drawing and Representation", s:"Plans, sections, elevations, and models",
  sec:[
  ["Why drawings matter",[
    "Architects rarely build with their own hands. They communicate designs through drawings, models, and digital files that builders, clients, engineers, and officials can understand. Learning to read and make architectural drawings is the first technical skill of the profession. Drawings are also thinking tools: sketching helps architects explore ideas quickly.",
    "Architectural drawings follow conventions so they can be read universally. They are drawn to scale, a fixed ratio between the drawing and reality, such as 1:100 (one centimeter on paper equals one meter in reality) or, in US practice, 1/4 inch = 1 foot. Line weights (thickness) distinguish what is cut through from what is seen beyond."]],
  ["Plans",[
    "A floor plan is a horizontal section: an imaginary cut through a building, typically about 1.2–1.5 meters above the floor, viewed from above. It shows walls (drawn with thick lines where cut), doors (with arcs showing swing), windows, stairs (with an arrow indicating 'up'), fixtures, and room labels. A site plan shows the building on its plot with landscape, access, and orientation, usually with a north arrow.",
    "Plans reveal the organization of spaces, circulation, and relationships between rooms. Architectural historians often study plans first because they show the logic of a building most clearly; Le Corbusier wrote that 'the plan is the generator'. A reflected ceiling plan shows the ceiling as if reflected in a mirror on the floor, including lighting fixtures."]],
  ["Sections and elevations",[
    "A section is a vertical cut through a building, showing floor levels, ceiling heights, stairs, roofs, foundations, and how spaces stack and connect vertically. Sections are essential for understanding light, volume, and structure, for example, how a double-height space or a clerestory works.",
    "An elevation is a straight-on view of one face of a building, without perspective, showing its exterior or an interior wall: windows, doors, materials, and proportions. Elevations are named by compass direction (north elevation) or by what they face (street elevation). Details are large-scale drawings, such as 1:5 or 1:10, that show how materials and components connect, like a window meeting a wall."]],
  ["Three-dimensional drawings",[
    "Axonometric drawings, including isometric drawings, show three dimensions without perspective: parallel lines remain parallel, and measurements can be taken along the axes. They are useful for explaining assemblies and spatial organization; exploded axonometrics pull apart components to show how they fit together.",
    "Perspective drawings depict a building as the eye sees it, with lines converging toward vanishing points. One-point perspective has one vanishing point (good for a corridor or street view), two-point perspective two (good for a building corner). Today, computer renderings and visualizations produce photorealistic images, though many architects value hand sketches and diagrams for communicating ideas clearly."]],
  ["Models",[
    "Physical models made of cardboard, foam, wood, or 3D-printed materials allow designers and clients to understand forms in three dimensions. Concept models explore ideas quickly; massing models show the overall volumes of a building in its context; detailed presentation models show the final design; and large mock-ups test materials and details at full size.",
    "Digital models created in software such as Rhino, SketchUp, Revit, and ArchiCAD can be viewed from any angle, analyzed, and turned into drawings. Virtual reality allows clients to 'walk through' a design before it is built. Yet physical models remain popular in many offices, as Frank Gehry's and Renzo Piano's studios demonstrated, because they engage the hands and eyes in a direct way."]],
  ["Construction documents",[
    "As a design develops, drawings become more technical. Construction documents (working drawings) are a detailed, coordinated set including plans, sections, elevations, details, and schedules (tables listing doors, windows, and finishes), accompanied by written specifications describing materials, quality standards, and workmanship.",
    "These documents form part of the legal contract between the client and the builder. They must be precise and coordinated with engineers' drawings for structure, mechanical, electrical, and plumbing systems. Errors or omissions can lead to costly changes, so careful documentation is a core professional responsibility."]]
  ],
  terms:[["Scale","A fixed ratio between a drawing's dimensions and real dimensions."],["Floor plan","A horizontal section through a building viewed from above."],["Section","A vertical cut through a building showing interior relationships."],["Elevation","A flat, straight-on view of one side of a building."],["Axonometric","A 3D drawing without perspective where parallel lines stay parallel."],["Specifications","Written descriptions of materials and workmanship for construction."],["Construction documents","Detailed drawings and specifications used to build a project."]],
  w:"Drawings are the language of architecture: reading and making them is essential for designing, communicating, and building.",
  src:["Architectural drawing","Plan (drawing)","Section drawing","Axonometric projection","Architectural model","Construction documents"],
  q:[["What does a scale of 1:100 mean?","One unit on paper equals 100 units in reality","The building is 100 meters tall","There are 100 drawings","Each room is 100 square meters"],
     ["A floor plan is essentially…","A horizontal section viewed from above","A view of the roof","A straight-on view of a facade","A perspective sketch"],
     ["What is a section?","A vertical cut through a building","A part of a city","A type of window","A list of materials"],
     ["Which drawing keeps parallel lines parallel in 3D?","Axonometric","Two-point perspective","One-point perspective","Freehand sketch"],
     ["What is a massing model?","A model showing a building's overall volumes in context","A full-size mock-up of a window","A structural analysis","A digital rendering"],
     ["Specifications are…","Written descriptions of materials and workmanship","Sketches of ideas","Photographs of the site","Zoning maps"]]},

{ t:"How a Building Gets Built", s:"Phases, teams, contracts, and costs",
  sec:[
  ["The project team",[
    "A building project involves many parties. The client (owner) pays for and commissions the building. The architect leads the design, coordinates consultants, and often oversees construction on the client's behalf. Engineers design structure (structural engineer), building services such as heating, ventilation, air conditioning, plumbing, and electrical systems (MEP engineers), and civil works such as drainage and roads.",
    "Other consultants may include landscape architects, interior designers, acoustic, lighting, facade, fire, and sustainability specialists, cost consultants (quantity surveyors), and planners. The contractor (builder) constructs the building, usually with many specialist subcontractors. Government authorities review plans and inspect work for compliance with zoning and building codes."]],
  ["Phases of design",[
    "Architectural services are typically divided into phases. In the US, the American Institute of Architects (AIA) uses schematic design, design development, construction documents, bidding or negotiation, and construction administration. In the UK, the RIBA Plan of Work has eight stages, from 0 (strategic definition) to 7 (use).",
    "The process usually begins with the brief (program), defining the client's needs, budget, and goals, and with site analysis. Schematic design explores options and establishes the basic concept. Design development refines systems, materials, and dimensions. Construction documents provide complete instructions for building. Throughout, the architect works with the client to make decisions and manage tradeoffs between cost, quality, and time."]],
  ["Procurement and contracts",[
    "Procurement is how a client hires a builder. In traditional design-bid-build, the architect completes the design, contractors submit bids, and the client hires one, usually the lowest qualified bidder. In design-build, a single entity provides both design and construction, which can be faster but gives the client less independent design control.",
    "Construction management at-risk involves hiring a construction manager early to advise on cost and buildability, who then guarantees a maximum price. Contracts allocate risks and responsibilities among parties; standard forms, such as those published by the AIA or the UK's JCT, are widely used. Disputes over delays, changes, and costs are common, so clear contracts and documentation are crucial."]],
  ["Cost and value",[
    "Cost is one of the main constraints on any project. Construction costs depend on size, complexity, quality of materials, location, market conditions, and timing. Cost consultants estimate costs at each stage, and value engineering seeks to reduce costs while preserving function, though it is sometimes criticized for cutting quality.",
    "Architects must also consider lifecycle costs: not only the initial construction cost but long-term operation, maintenance, energy, and eventual replacement. A cheaper building can be more expensive over its life if it uses much energy or requires frequent repair."]],
  ["On the construction site",[
    "Construction typically follows a sequence: site preparation and excavation; foundations; the structural frame (concrete, steel, timber, or masonry); the building envelope (roof, walls, windows), which makes the building weathertight; then interior systems and finishes; and finally commissioning, testing that systems like heating and ventilation work as designed.",
    "During construction, the architect answers contractors' questions (requests for information, or RFIs), reviews shop drawings (detailed drawings made by fabricators), visits the site, checks work against the contract documents, and certifies payments. Changes to the design during construction are made through change orders, which often add cost and time."]],
  ["Handover and use",[
    "At the end of construction, the architect inspects the work and produces a punch list (snag list) of items to fix. After the building is handed over, a warranty or defects period follows. Increasingly, architects conduct post-occupancy evaluations (POE), studying how buildings perform in use, including energy use and occupant satisfaction, to learn lessons.",
    "Understanding the whole process is essential: great design ideas only matter if they can be built well, on budget and on time, and if the building serves its occupants for decades."]]
  ],
  terms:[["Client (owner)","The person or organization that commissions and pays for a building."],["MEP","Mechanical, electrical, and plumbing systems and engineering."],["Brief (program)","The statement of a client's needs and requirements for a project."],["Design-bid-build","Procurement where design is completed before contractors bid."],["Design-build","Procurement where one entity provides both design and construction."],["Value engineering","Reducing costs while trying to preserve function."],["Change order","A formal change to the construction contract."],["Post-occupancy evaluation","Studying how a building performs after people use it."]],
  w:"Knowing how buildings are procured, priced, and built is essential to turning designs into reality.",
  src:["Construction","Design–bid–build","Design–build","RIBA Plan of Work","Value engineering","Post-occupancy evaluation"],
  q:[["Who typically designs heating, ventilation, and electrical systems?","MEP engineers","Landscape architects","Quantity surveyors","Planners"],
     ["What is the brief or program?","A statement of the client's needs and requirements","The final construction drawing","The building permit","The contractor's invoice"],
     ["In design-bid-build…","Design is completed before contractors bid","One firm does design and construction","The client builds the project","No architect is involved"],
     ["What does value engineering seek to do?","Reduce costs while preserving function","Increase the building's size","Add ornament","Speed up permits"],
     ["When does a building become weathertight?","When the envelope, roof, walls, and windows are complete","After the foundations","After painting","When the furniture arrives"],
     ["What is a post-occupancy evaluation?","A study of how a building performs in use","A final inspection by the fire department","The first design sketch","A survey of the site before design"]]},

{ t:"Building Systems: Comfort, Light, and Sound", s:"The invisible architecture",
  sec:[
  ["Buildings as systems",[
    "A building is not just a structure and a skin; it is a complex system that provides comfort, safety, and services. Heating, ventilation, and air conditioning (HVAC), plumbing, electrical power, lighting, data, fire protection, elevators, and controls can account for a large share of a building's cost and much of its environmental impact.",
    "Good architects understand these systems and integrate them from the start, rather than treating them as afterthoughts. Space for ducts, risers (vertical shafts), plant rooms, and ceiling voids must be planned carefully, as Louis Kahn's 'servant spaces' emphasized."]],
  ["Thermal comfort",[
    "Thermal comfort depends on air temperature, the temperature of surrounding surfaces (radiant temperature), humidity, air movement, clothing, and activity level. People can feel cold near a large cold window even if the air is warm. Standards such as ASHRAE 55 in the US define comfort ranges.",
    "Heating can be delivered by radiators, warm air, or radiant floors; cooling by air conditioning, chilled ceilings, or natural ventilation. Heat pumps, which move heat rather than generating it by burning fuel, are increasingly used to heat and cool buildings efficiently with electricity. Willis Carrier's invention of modern air conditioning in 1902 transformed architecture, enabling deep-plan, sealed office buildings and the growth of cities in hot climates."]],
  ["Ventilation and air quality",[
    "Buildings need fresh air to remove carbon dioxide, moisture, odors, and pollutants. Ventilation can be natural, through windows and vents using wind and the stack effect, or mechanical, using fans and ducts. Mechanical ventilation with heat recovery (MVHR) recovers warmth from outgoing air.",
    "The COVID-19 pandemic heightened awareness of indoor air quality and the role of ventilation in reducing airborne disease transmission. Materials also matter: some paints, adhesives, and furnishings release volatile organic compounds (VOCs), so healthy building design selects low-emission materials."]],
  ["Lighting",[
    "Daylighting uses natural light to illuminate interiors, improving wellbeing and reducing energy use. Architects control daylight with window size and placement, skylights, light shelves that bounce light deeper into rooms, and shading to prevent glare and overheating. The rule of thumb is that useful daylight penetrates about twice the height of a window head into a room.",
    "Artificial lighting combines ambient (general), task, and accent lighting. Light quantity is measured in lux; color temperature in kelvins (warm light around 2,700K, cool daylight-like light around 5,000K and above). LED technology has dramatically reduced lighting energy use. Lighting design shapes mood and atmosphere as much as visibility."]],
  ["Acoustics",[
    "Acoustics affects how spaces sound and how well people can hear, concentrate, and rest. Key concerns are sound insulation (preventing noise from passing between spaces, achieved through mass, airtightness, and separation), and room acoustics (how sound behaves within a space). Reverberation time, how long sound takes to decay, should be short in classrooms and offices for clarity, and longer in concert halls for richness.",
    "Wallace Clement Sabine, a Harvard physicist, founded architectural acoustics around 1900 by developing a formula for reverberation; he then advised on Boston's Symphony Hall (1900), still considered one of the world's best concert halls. Shoebox-shaped halls, such as Vienna's Musikverein, are often praised for acoustics; 'vineyard' halls, with terraced seating around the stage, as in Berlin's Philharmonie (1963) by Hans Scharoun, offer intimacy."]],
  ["Water, power, fire, and movement",[
    "Plumbing brings clean water in and carries wastewater out, with traps preventing sewer gases from entering. Rainwater harvesting and greywater reuse can reduce water consumption. Electrical systems distribute power and data; increasingly buildings include solar panels and batteries.",
    "Fire safety includes means of escape (protected stairs, exits, maximum travel distances), compartmentation to contain fire, fire-resistant materials, alarms, and sprinklers. Tragedies like the Grenfell Tower fire in London (2017), in which 72 people died and combustible cladding contributed to the rapid spread of fire, showed the deadly consequences of failures in material choice, regulation, and oversight. Elevators, escalators, and ramps provide vertical movement and accessibility."]]
  ],
  terms:[["HVAC","Heating, ventilation, and air conditioning."],["Radiant temperature","The temperature of surrounding surfaces, which affects comfort."],["Heat pump","A device that moves heat from one place to another using electricity."],["Daylighting","Using natural light to illuminate building interiors."],["Reverberation time","The time it takes for sound to decay in a space."],["Compartmentation","Dividing a building into fire-resistant sections to contain fire."]],
  w:"Building systems determine comfort, health, safety, and energy use, and must be integrated into design from the start.",
  src:["HVAC","Thermal comfort","Daylighting","Architectural acoustics","Wallace Clement Sabine","Grenfell Tower fire"],
  q:[["What is radiant temperature?","The temperature of surrounding surfaces","The outdoor air temperature","The temperature of the water supply","The temperature of lights"],
     ["A heat pump works by…","Moving heat using electricity","Burning gas","Storing ice","Reflecting sunlight"],
     ["Who invented modern air conditioning in 1902?","Willis Carrier","Thomas Edison","Elisha Otis","Wallace Sabine"],
     ["Useful daylight typically reaches about how far into a room?","About twice the window head height","Ten times the room width","Only one meter","The full depth of any building"],
     ["Who founded architectural acoustics around 1900?","Wallace Clement Sabine","Hans Scharoun","Alvar Aalto","Leo Beranek"],
     ["What contributed to the rapid spread of fire at Grenfell Tower?","Combustible cladding","Too many sprinklers","Concrete walls","Wide stairs"]]},

{ t:"Interiors and Furniture", s:"Designing the spaces we inhabit",
  sec:[
  ["Interior architecture",[
    "Most people spend the great majority of their time indoors, so interior spaces strongly affect daily life. Interior architecture and interior design shape rooms' layout, proportions, materials, color, lighting, furniture, and fittings. Interior designers in many countries are trained professionals working on homes, offices, hotels, shops, restaurants, and public buildings.",
    "Architects have long designed interiors and furniture as part of a unified whole, from Robert Adam's coordinated rooms to Frank Lloyd Wright's built-in furniture and Charles Rennie Mackintosh's high-backed chairs. Many famous chairs were designed by architects, because a chair is a small structure that relates directly to the human body."]],
  ["A brief history of interiors",[
    "Historic interiors reflected social life. Medieval great halls were multipurpose spaces for eating, sleeping, and gathering. The Renaissance and Baroque developed suites of rooms for ceremony, and the 18th century introduced specialized, comfortable rooms. The Victorian era favored dense decoration, heavy fabrics, and many objects.",
    "Modernism promoted open plans, simple surfaces, light, and built-in storage. Elsie de Wolfe, often called the first professional interior decorator in America, lightened Victorian interiors in the early 20th century. The open-plan office, the 'office landscape' (Bürolandschaft) developed in Germany in the late 1950s, and later the cubicle, invented from Robert Propst's 'Action Office' for Herman Miller (1968), transformed workplaces."]],
  ["Iconic modern furniture",[
    "Modern furniture design is a rich field closely linked to architecture. Michael Thonet's bentwood Chair No. 14 (1859) was mass-produced in the tens of millions, shipped flat and assembled. Bauhaus designers developed tubular steel chairs; Le Corbusier, Pierre Jeanneret, and Charlotte Perriand designed the LC4 chaise longue (1928). Eileen Gray designed furniture and the house E-1027 on the French Riviera (1926–1929).",
    "Mid-century designers, including Charles and Ray Eames (molded plywood and fiberglass chairs, the Eames Lounge Chair of 1956), Arne Jacobsen, Hans Wegner, Eero Saarinen (the Tulip chair), and Isamu Noguchi, created furniture still produced today. Ikea, founded in Sweden in 1943, democratized modern design through flat-pack furniture."]],
  ["Ergonomics and human factors",[
    "Ergonomics studies the relationship between the human body and the designed environment. Architects use anthropometric data, body measurements, to set dimensions: typical seat heights around 45 cm, table heights around 72–75 cm, kitchen counters around 90 cm, and door widths that accommodate wheelchairs.",
    "Books such as Ernst Neufert's 'Architects' Data' (first published in German in 1936 and still updated) provide dimensions for spaces and furniture. Universal design aims to make spaces usable by everyone, regardless of age, size, or ability, considering reach, clearances, lighting, contrast, and wayfinding."]],
  ["Materials, color, and atmosphere",[
    "Interior materials affect touch, sound, light, durability, and health. Wood feels warm; stone and concrete feel cool and solid; textiles soften sound. Color influences perceived size, mood, and orientation: light colors make spaces feel larger, while warm colors can create intimacy.",
    "Peter Zumthor's book 'Atmospheres' (2006) describes how architects create the overall feeling of a space through materials, sound, temperature, light, and the relationship between things. Lighting, acoustics, scent, and views all contribute to how an interior is experienced."]],
  ["Interiors and sustainability",[
    "Interiors are changed far more often than building structures, as shops, offices, and homes are refitted every few years. This 'churn' generates large amounts of waste and embodied carbon. Sustainable interior design favors durable, repairable, recycled, and low-emission materials, flexible layouts, and the reuse of furniture and fittings.",
    "Workplace design has changed significantly with the rise of remote and hybrid work, especially since the COVID-19 pandemic. Offices are being redesigned around collaboration, focus spaces, and wellbeing, and some are converted to housing. Interiors respond quickly to social change, making interior design a dynamic field."]]
  ],
  terms:[["Interior architecture","The design of interior spaces, often involving structural or spatial changes."],["Open plan","A layout with few interior walls dividing spaces."],["Ergonomics","The study of designing for the human body and its capabilities."],["Anthropometrics","Measurements of the human body used in design."],["Universal design","Design usable by all people, regardless of age or ability."],["Bürolandschaft","The 'office landscape', an open, organic office layout developed in Germany."]],
  w:"Interiors are where life actually happens, and their design shapes comfort, health, and how people live and work.",
  src:["Interior design","Thonet No. 14 chair","Charles and Ray Eames","Ergonomics","Ernst Neufert","Eileen Gray"],
  q:[["Why have so many famous chairs been designed by architects?","A chair is a small structure directly related to the body","Architects were required by law to design chairs","Chairs are easier than buildings","Furniture designers did not exist"],
     ["What was revolutionary about Thonet's Chair No. 14?","It was mass-produced and shipped flat","It was made of steel","It folded into a table","It was carved from one log"],
     ["Who designed the house E-1027?","Eileen Gray","Charlotte Perriand","Ray Eames","Lilly Reich"],
     ["Anthropometrics refers to…","Measurements of the human body","The study of ancient buildings","Building codes","Types of wood"],
     ["Which book provides standard dimensions for spaces and furniture?","Neufert's 'Architects' Data'","Vitruvius's 'Ten Books'","Palladio's 'Four Books'","Zumthor's 'Atmospheres'"],
     ["Why do interiors have a large environmental impact?","They are refitted frequently, generating waste","They use steel frames","They require foundations","They have no impact"]]}

]});


/* ---- from arch-18.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 18: Unit 9 The Practice of Architecture, chapters 5-8 */
COURSES.architecture.units[8].ch.push(

{ t:"Architectural Theory and Criticism", s:"How architects think and argue",
  sec:[
  ["What theory is for",[
    "Architectural theory is the body of ideas about what architecture is, what it should do, and how it should be made. Theory guides design choices, explains buildings, and connects architecture to philosophy, politics, science, and culture. Every building embodies some theory, even if unspoken.",
    "The tradition begins with Vitruvius's firmitas, utilitas, venustas (strength, usefulness, beauty), and continues through Alberti, Palladio, Laugier, Pugin, Ruskin, Viollet-le-Duc, Sullivan, Le Corbusier, and many others. Many theories are written as manifestos, short, passionate statements of belief, such as Adolf Loos's 'Ornament and Crime' or the Bauhaus manifesto."]],
  ["Key debates",[
    "Several debates recur throughout history. Form and function: should a building's shape derive from its use (Sullivan's 'form follows function') or from artistic intention? Ornament: is decoration essential to meaning and delight, or a dishonest addition? Tradition and innovation: should architecture continue historical forms or invent new ones?",
    "Other debates concern context (should new buildings fit in or stand out?), honesty (should structure and materials be expressed truthfully?), autonomy (is architecture an art with its own internal logic, or a social practice serving users?), and the role of the architect (artist, technician, or social servant?). There are no final answers; each generation reframes these questions."]],
  ["Phenomenology and experience",[
    "In the late 20th century, many theorists turned to how buildings are experienced through the body and senses, drawing on the philosophy of phenomenology (Martin Heidegger, Maurice Merleau-Ponty). Christian Norberg-Schulz wrote about genius loci, the 'spirit of place'. Juhani Pallasmaa's 'The Eyes of the Skin' (1996) criticized the dominance of vision in architecture and argued for an architecture of all the senses, touch, sound, smell, and movement.",
    "Steven Holl, Peter Zumthor, and Tadao Ando are often associated with this approach, emphasizing materials, light, atmosphere, and the bodily experience of space. Gaston Bachelard's 'The Poetics of Space' (1958), a philosophical study of the house, cellars, attics, and corners as places of memory and dreams, remains widely read by architects."]],
  ["Critical and social theory",[
    "Other theorists have examined architecture's relationship to power, economics, and society. Michel Foucault discussed the panopticon, Jeremy Bentham's 18th-century prison design allowing one guard to watch all inmates, as a model of modern surveillance. Henri Lefebvre's 'The Production of Space' (1974) argued that space is socially produced, and he proposed a 'right to the city' for all inhabitants.",
    "Feminist theorists have examined how buildings and cities reflect gendered assumptions, for example about domestic work and safety, and how women's contributions to architecture were overlooked. Postcolonial scholars study how colonial architecture expressed and enforced power, and how architecture in formerly colonized nations has responded. Disability scholars have reshaped understanding of access and inclusion."]],
  ["Architectural criticism",[
    "Architectural critics evaluate buildings for the public, much like film or book critics, in newspapers, magazines, and online. Influential critics have included Lewis Mumford, who wrote 'The Sky Line' column in The New Yorker from 1931 to 1963, Ada Louise Huxtable, the first full-time architecture critic of The New York Times, who won the first Pulitzer Prize for Criticism in 1970, Reyner Banham, and Charles Jencks. Contemporary critics continue this tradition.",
    "Good criticism describes a building accurately, places it in context, considers how it serves users and the city, evaluates its design and craft, and explains its significance. Critics can influence public debate about urban change, preservation, and architectural quality."]],
  ["How to think critically about a building",[
    "To analyze a building, ask: What is its purpose and who uses it? How does it relate to its site, city, and climate? How is it organized in plan and section? What is its structure, and are its materials and construction expressed? How does it feel to move through it, with its light, scale, and sound? What does it mean, and what history or ideas does it draw on?",
    "Also ask: Does it work well for its users? Is it sustainable? Who benefited from it, and who might have been excluded or displaced? Thinking critically means considering both the art of a building and its social and environmental consequences."]]
  ],
  terms:[["Architectural theory","Ideas about what architecture is and how it should be made."],["Manifesto","A short, passionate public declaration of principles."],["Genius loci","The 'spirit of place', the distinctive character of a location."],["Phenomenology","A philosophical approach to how things are experienced by the senses and body."],["Panopticon","A prison design allowing a single guard to observe all inmates."],["Right to the city","Henri Lefebvre's idea that all inhabitants should shape urban life."]],
  w:"Theory and criticism give architects and the public the tools to understand, judge, and debate the built environment.",
  src:["Architectural theory","Juhani Pallasmaa","Genius loci","Panopticon","Ada Louise Huxtable","The Production of Space"],
  q:[["Which phrase summarizes Vitruvius's theory of architecture?","Strength, usefulness, and beauty","Less is more","Form follows function","A machine for living in"],
     ["What does 'genius loci' mean?","The spirit of place","A brilliant architect","A type of column","The center of a city"],
     ["Juhani Pallasmaa's 'The Eyes of the Skin' argues for…","An architecture of all the senses","Building only with glass","Eliminating ornament","Taller skyscrapers"],
     ["What is the panopticon?","A prison design allowing one guard to watch all inmates","A domed church","A kind of camera","A panoramic window"],
     ["Who was the first full-time architecture critic of The New York Times?","Ada Louise Huxtable","Lewis Mumford","Jane Jacobs","Vincent Scully"],
     ["Henri Lefebvre proposed…","A 'right to the city'","The garden city","The International Style","The Five Points"]]},

{ t:"Architecture, Power, and Society", s:"Who builds, for whom, and why",
  sec:[
  ["Architecture as power",[
    "Throughout history, rulers have used architecture to express and consolidate power. Pyramids, palaces, cathedrals, and capitols impress viewers with scale, permanence, and wealth. Versailles controlled the nobility; Haussmann's Paris projected imperial order; and 20th-century dictatorships, from Mussolini's Rome to Stalin's Moscow, used monumental architecture as propaganda.",
    "Even democratic governments use architecture symbolically: parliaments, courthouses, and memorials express ideals of law, transparency, and national identity. Architecture's cost and permanence mean it is almost always tied to those who hold economic and political power."]],
  ["Architecture and exclusion",[
    "Buildings and cities can include or exclude. Segregation has been built into urban form through zoning, highways, and housing policy. 'Hostile architecture' or 'defensive design', such as benches with armrests to prevent lying down or spikes on ledges, aims to discourage homeless people or skateboarders, raising ethical questions about who public space is for.",
    "Physical barriers exclude disabled people. The disability rights movement fought for laws such as the Americans with Disabilities Act (1990) and the UK Equality Act (2010), which require accessible design. Gender also matters: the lack of women's restrooms in some public buildings and safety concerns in poorly lit spaces show how design can overlook half the population."]],
  ["Psychology and wellbeing",[
    "Environmental psychology studies how environments affect people. A famous 1984 study by Roger Ulrich found that hospital patients recovering from surgery with a view of trees had shorter stays and needed fewer strong painkillers than those facing a brick wall. Access to daylight, nature, quiet, and a sense of control improve wellbeing.",
    "Research on cities suggests people prefer complexity, coherence, human scale, and active street frontages. Some research has found that long, blank facades can make pedestrians feel bored or stressed. Neuroscience and architecture is an emerging field, with the Academy of Neuroscience for Architecture founded in 2003. Designing for wellbeing is now a central concern in healthcare, schools, workplaces, and housing."]],
  ["Who designs?",[
    "Historically, architecture as a profession was dominated by white men, especially in Europe and North America. Women architects faced exclusion; Julia Morgan, the first woman admitted to the architecture section of the École des Beaux-Arts in Paris, went on to design Hearst Castle and hundreds of other buildings in California. Eileen Gray, Lilly Reich, Charlotte Perriand, Lina Bo Bardi, and Denise Scott Brown were long underrecognized.",
    "Black architects in the US, such as Paul R. Williams, who designed thousands of buildings, most of them in Southern California, and Norma Merrick Sklarek, the first Black woman licensed as an architect in New York (1954) and California, overcame significant discrimination. Today, the profession is more diverse, but underrepresentation persists. Diversity matters because architects' experiences shape what they notice and value in design."]],
  ["Participation and community",[
    "Participatory design involves future users and communities in the design process, through workshops, consultations, and co-design. It can help buildings serve real needs and give communities ownership of their environments. Ralph Erskine's Byker Wall in Newcastle (1969–1982) involved residents in designing their new housing.",
    "Community-led and self-build movements, like those of Walter Segal in London, who developed a simple timber system allowing people to build their own homes in Lewisham in the 1970s–80s, show alternatives to top-down development. Architecture firms increasingly include engagement specialists, and public projects often require consultation."]],
  ["Ethics and the architect",[
    "Architects have ethical responsibilities to clients, the public, users, and future generations. Professional codes require protecting public health, safety, and welfare. Contemporary ethical questions include working for authoritarian regimes, labor conditions on construction sites (concerns were raised, for example, about migrant workers building venues for the 2022 FIFA World Cup in Qatar), designing prisons, and responding to the climate emergency.",
    "Architects cannot solve social problems alone, but their choices matter. They decide which projects to accept, how to allocate resources, how to involve communities, and whether to design for inclusion, health, and sustainability."]]
  ],
  terms:[["Hostile architecture","Design intended to discourage certain uses or users of public space."],["Environmental psychology","The study of how environments affect human behavior and wellbeing."],["Participatory design","Design involving future users and communities."],["Accessibility","Design allowing people with disabilities to use buildings and spaces."],["Public health, safety, and welfare","The core public responsibilities of the architecture profession."]],
  w:"Architecture is never neutral: it expresses power, includes or excludes people, and shapes wellbeing, which gives architects real ethical responsibilities.",
  src:["Hostile architecture","Environmental psychology","Julia Morgan","Paul R. Williams (architect)","Norma Merrick Sklarek","Participatory design"],
  q:[["What is 'hostile architecture'?","Design intended to discourage certain users of public space","Fortified castles","Buildings in war zones","Architecture critics' reviews"],
     ["Roger Ulrich's 1984 study found that patients with a view of trees…","Had shorter hospital stays","Needed more painkillers","Recovered more slowly","Complained more"],
     ["Who was the first woman admitted to the architecture section of the École des Beaux-Arts?","Julia Morgan","Eileen Gray","Zaha Hadid","Norma Merrick Sklarek"],
     ["Most of Paul R. Williams's thousands of buildings are in…","Southern California","New York","Chicago","London"],
     ["Walter Segal developed a system allowing people to…","Build their own timber homes","Design skyscrapers","3D print houses","Restore castles"],
     ["Architects' core public responsibility is to protect…","Public health, safety, and welfare","Their own reputation","The client's profits only","Historical styles"]]},

{ t:"Becoming an Architect", s:"Education, licensure, careers, and skills",
  sec:[
  ["Education",[
    "Architecture education typically combines design studio, the central activity where students develop projects under critique, with courses in history and theory, structures, building technology, environmental systems, representation, and professional practice. In studio, students present their work to juries of faculty and practitioners in reviews (crits), learning to explain and defend their ideas.",
    "In the US, professional degrees are accredited by the National Architectural Accrediting Board (NAAB): typically a five-year Bachelor of Architecture (B.Arch) or a Master of Architecture (M.Arch). In the UK, the traditional route has three parts: an undergraduate degree (Part 1), a further postgraduate degree (Part 2), and practical experience with professional exams (Part 3), though new routes are emerging. Programs vary worldwide, but most professional training takes about five to seven years including practice."]],
  ["Licensure",[
    "The title 'architect' is legally protected in many countries, meaning only licensed or registered individuals can use it. In the US, licensure requires an accredited degree (in most states), documented practical experience through the Architectural Experience Program (AXP), and passing the six-part Architect Registration Examination (ARE), administered by NCARB. Licenses are granted by individual states.",
    "In the UK, architects must register with the Architects Registration Board (ARB). In the EU, qualifications are mutually recognized under a directive. Licensure exists to protect public safety, because buildings that fail can kill. Licensed architects may stamp drawings submitted for permits, taking legal responsibility."]],
  ["Career paths",[
    "Architects work in practices of all sizes, from sole practitioners to global firms with thousands of employees. Roles progress from junior designer or architectural assistant to project architect, project manager, associate, and partner or principal. Many specialize in particular building types, such as healthcare, housing, education, or cultural buildings.",
    "Architectural training also leads to many related careers: urban design and planning, landscape architecture, interior design, preservation, real estate development, construction management, computational design, visualization, set design for film and games, academia, journalism, and public policy. The design thinking taught in architecture school is valued in many fields."]],
  ["Skills of an architect",[
    "Architects need a mix of creative, technical, and interpersonal skills. Creative skills include spatial imagination, drawing and modeling, and design synthesis, combining many requirements into a coherent whole. Technical skills include knowledge of structures, materials, building systems, codes, and digital tools.",
    "Equally important are communication, listening to clients and communities, presenting ideas clearly, writing, collaboration with engineers and builders, and project management, keeping track of time, budgets, and coordination. Business skills such as fee negotiation, marketing, and contracts are crucial for running a practice."]],
  ["The realities of the profession",[
    "Architecture can be immensely rewarding, but it has challenges: long hours, especially in school and around deadlines; salaries that are often modest compared with other professions requiring similar training; vulnerability to economic cycles, as construction slows in recessions; and long timelines, as buildings can take many years from design to completion.",
    "The profession is changing with digital tools and AI, new procurement methods, pressure to decarbonize, and efforts to improve diversity and working conditions. Many architects find deep satisfaction in seeing their designs built and used, and in contributing to places that improve people's lives."]],
  ["Learning architecture on your own",[
    "Anyone can learn to see architecture well. Practical steps include walking cities and visiting buildings, sketching what you see, reading plans in books and online, visiting open-house events (Open House festivals occur in many cities), and reading critics and historians.",
    "Classic introductions include Steen Eiler Rasmussen's 'Experiencing Architecture' (1959), Francis D. K. Ching's 'Architecture: Form, Space, and Order' (first edition 1975), and histories such as those by Kenneth Frampton ('Modern Architecture: A Critical History') and Spiro Kostof ('A History of Architecture'). Learning to draw, even simply, sharpens observation."]]
  ],
  terms:[["Design studio","The core course in architecture school where students develop design projects."],["Crit (review)","A presentation of student work to critics for feedback."],["Licensure","Legal authorization to practice as an architect."],["ARE","The Architect Registration Examination in the US."],["Design synthesis","Combining many requirements into a coherent design."],["Project architect","An architect responsible for the design and technical delivery of a project."]],
  w:"Understanding how architects are trained and work helps anyone navigate the profession or work effectively with architects.",
  src:["Architect","Architectural education","Architect Registration Examination","National Architectural Accrediting Board","Architects Registration Board","Design studio"],
  q:[["What is the central activity of architecture education?","Design studio","Lecture-only classes","Construction labor","Real estate sales"],
     ["Which US exam must architects pass for licensure?","The Architect Registration Examination (ARE)","The Bar Exam","The GRE","The PE exam"],
     ["Why is the title 'architect' legally protected?","To protect public safety","To limit competition only","For tax purposes","Because of copyright"],
     ["In the UK, architects must register with…","The Architects Registration Board","The Royal Academy","The National Trust","UNESCO"],
     ["What is design synthesis?","Combining many requirements into a coherent design","Copying historical styles","Drawing only facades","Calculating costs"],
     ["Which book is a classic introduction to experiencing buildings?","Steen Eiler Rasmussen's 'Experiencing Architecture'","The Power Broker","Delirious New York","The Production of Space"]]},

{ t:"Seeing Like an Architect", s:"Putting it all together",
  sec:[
  ["Looking at any building",[
    "You now have the tools to understand almost any building. When you encounter one, start with its purpose and context: what it is for, who built it and when, and how it sits in its street, landscape, and climate. Then look at its form: its massing, proportions, and silhouette, and its relationship to neighbors.",
    "Next, consider structure and materials: what holds it up (walls, frames, arches, vaults, cables), and what it is made of. Ask how it was built and how materials are joined. Look at its facade: openings, rhythms, ornament, and how it presents itself to the public."]],
  ["Moving through space",[
    "Architecture is experienced in motion and over time. Notice how you approach and enter a building: the path, threshold, and sequence of spaces. Pay attention to compression and release, as a low entrance gives way to a tall hall, a technique used by architects from Egyptian temple builders to Frank Lloyd Wright.",
    "Notice light: where it comes from, how it changes during the day, and how it reveals materials. Notice sound, temperature, smell, and touch. Ask how the building makes you feel, and why. These sensory qualities are as much a part of architecture as its form."]],
  ["Recognizing styles and periods",[
    "Styles are tools for understanding, not rigid boxes. Classical buildings use columns, pediments, and symmetry; Romanesque has round arches and thick walls; Gothic has pointed arches, rib vaults, and large windows; Renaissance has calm proportions and classical orders; Baroque has curves, drama, and movement; Neoclassical has severe classical forms.",
    "The 19th century revived all of these; Art Nouveau introduced organic curves; modernism stripped ornament and expressed structure; Art Deco added geometric glamour; Brutalism used raw concrete; postmodernism playfully returned historical references; High-Tech exposed structure and services; and contemporary architecture is plural, often focused on sustainability and context. Most buildings mix influences, and many vernacular buildings follow no 'style' at all."]],
  ["Judging quality",[
    "What makes architecture good? Vitruvius's three qualities remain useful: Is it sound and durable? Does it serve its users and purpose well? Does it delight? Contemporary criteria add: Is it sustainable and adaptable? Is it accessible and inclusive? Does it contribute to its city and community?",
    "Great buildings often achieve a sense of inevitability, where form, function, structure, and context seem to fit perfectly. But quality also lies in ordinary buildings: well-proportioned row houses, a sunny school classroom, a comfortable library, or a street that is pleasant to walk. Architecture is the backdrop of daily life."]],
  ["Architecture as a continuous conversation",[
    "Every building responds to earlier buildings. Greek temples echoed timber construction; Roman builders adapted Greek orders; Renaissance architects studied Rome; modernists rejected history yet learned from Gothic structure and Japanese houses; contemporary architects reuse and reinterpret everything. The history of architecture is a long conversation across millennia and cultures.",
    "Knowing this history allows you to see connections: Hagia Sophia's pendentives in Renaissance domes, Palladio's porticoes on American homes, the Crystal Palace in glass skyscrapers, Persian iwans in Mughal tombs, and vernacular courtyards in modern passive design."]],
  ["Where to go from here",[
    "This foundation course has covered how architecture works, its history from prehistory to today across the world, cities and landscapes, and the practice of architecture. Each topic can be explored much more deeply, through visiting buildings, reading, drawing, and studying particular architects, regions, or building types.",
    "Keep looking. Walk through your own town with fresh eyes; notice details, materials, proportions, and how places make you feel. Architecture surrounds us constantly, and learning to see it enriches every day."]]
  ],
  terms:[["Massing","The overall shape, form, and size of a building."],["Compression and release","Moving from a low, narrow space into a large, open one to create drama."],["Threshold","The transition point of entry into a building or space."],["Silhouette","The outline of a building against the sky."],["Vernacular","Ordinary building traditions that follow local customs rather than formal styles."]],
  w:"Seeing like an architect turns every street, room, and journey into a lesson in history, engineering, and art.",
  src:["Architecture","Architectural style","History of architecture","Vitruvius","Spatial sequence","Vernacular architecture"],
  q:[["What should you consider first when analyzing a building?","Its purpose and context","Only its color","Its price","The architect's age"],
     ["What is 'compression and release'?","Moving from a low space into a large open one","A structural failure","A type of concrete","A ventilation strategy"],
     ["Which style uses pointed arches, rib vaults, and large windows?","Gothic","Romanesque","Neoclassical","Brutalist"],
     ["Which three qualities did Vitruvius name?","Strength, usefulness, and beauty","Height, width, and color","Wood, stone, and glass","Cost, speed, and size"],
     ["What does 'massing' describe?","A building's overall shape and size","A church service","The number of occupants","A type of mortar"],
     ["The history of architecture can be described as…","A long conversation across time and cultures","A series of unrelated events","Only European","Finished and complete"]]}

);


/* ---- from arch-19.js ---- */
/* ARCHITECTURE FOUNDATIONS, part 19: extra chapters spliced into Units 1 and 9 */
(function(){
const U=COURSES.architecture.units;
function after(u,title,chs){const i=U[u].ch.findIndex(c=>c.t===title);U[u].ch.splice(i<0?U[u].ch.length:i+1,0,...chs);}

after(0,"Building Materials",[
{ t:"The Building Envelope", s:"Foundations, walls, roofs, and keeping the weather out",
  sec:[
  ["From the ground up",[
    "Every building has to meet the ground, enclose space, and keep out rain, wind, cold, and heat. Together the outer layers, the walls, roof, windows, and lowest floor, are called the building envelope. The envelope is where most of the battles of building are fought: against water, heat loss, condensation, fire, and decay.",
    "Foundations transfer the building's weight safely into the ground. Shallow foundations, such as strip footings under walls, pad footings under columns, or a raft (a thick slab under the whole building), work where good soil is near the surface. Deep foundations, piles driven or drilled down to firmer soil or rock, are needed on weak ground. Much of Venice stands on wooden piles driven into the lagoon mud centuries ago, and Mexico City's soft lakebed soil has caused many buildings to sink unevenly."]],
  ["Walls",[
    "Walls can be load-bearing, carrying floors and roof as in traditional masonry, or non-load-bearing, hung on or filling in a frame, as with curtain walls. A wall must keep out water, resist wind, insulate, and often let in light and air. Traditional thick masonry walls absorb rain and dry out slowly; modern walls are usually built in layers, each with a job.",
    "A typical modern wall might have an outer cladding (brick, stone, timber, metal, or render) that sheds most rain, a ventilated cavity behind it that lets water drain and the wall dry, a water-resistant membrane, a layer of insulation, the structure, and an inner finish. Getting the order of layers right prevents water vapor from condensing inside the wall, where it can rot timber and grow mold."]],
  ["Roofs",[
    "Roofs are the most exposed part of a building. Pitched (sloping) roofs shed water quickly; their steepness traditionally depended on the covering material and climate: steep for thatch and in snowy regions, gentler for clay tiles in the Mediterranean. Common forms include the gable (two slopes meeting at a ridge, with triangular end walls), the hip (slopes on all four sides), the mansard, the gambrel (a barn roof with two slopes per side), and the shed or lean-to (a single slope).",
    "Flat roofs, popularized by modernism, are never perfectly flat; they need a slight fall to drains, and their waterproof membranes must be carefully detailed. Many early modernist flat roofs leaked, which gave the style a bad reputation. Today, flat roofs often carry solar panels, plant equipment, or green roofs that absorb rainwater and insulate."]],
  ["Openings",[
    "Windows and doors are the weakest points in the envelope, where heat escapes and water gets in, yet they are essential for light, air, views, and access. Above every opening, a lintel or arch carries the wall's load across the gap. Flashing, thin strips of metal or membrane, directs water away at joints, sills, and junctions. A drip, a small groove under a projecting sill, stops water from running back toward the wall.",
    "Glass technology has transformed buildings. Medieval glass was small and expensive; the float-glass process, invented by Alastair Pilkington in the 1950s, made large, flat, cheap panes possible. Double and triple glazing with gas-filled gaps and low-emissivity (low-e) coatings now insulate far better than single glass, though still much worse than an insulated wall."]],
  ["Insulation and airtightness",[
    "Insulation slows the flow of heat through the envelope. Common types include mineral wool, rigid foam boards, cellulose (recycled paper), wood fiber, cork, sheep's wool, and straw. Its effectiveness is measured by thermal resistance (R-value) or by thermal transmittance (U-value): the lower the U-value, the better a wall, roof, or window insulates.",
    "A thermal bridge is a weak spot where heat bypasses insulation, for example a concrete balcony slab running straight from a warm interior to the cold outside. Airtightness also matters: uncontrolled drafts through gaps can waste more heat than poor insulation. Modern practice is often summarized as 'build tight, ventilate right': seal the envelope carefully and then provide controlled fresh air."]],
  ["The envelope and architecture",[
    "The envelope is not only technical; it is the face of the building, the part most people see. Choices of cladding, window proportion, roof form, and detail give a building its character and relate it to its neighbors. Many regional traditions, like the deep eaves of Japanese houses, the steep slate roofs of Wales, or the whitewashed walls of the Greek islands, are envelope solutions to local weather.",
    "Most building failures, leaks, rot, mold, cracking, and overheating, happen in the envelope. That is why architects spend so much effort on the details where materials meet. As the old saying goes, a building's first job is to keep the rain out."]]
  ],
  terms:[["Building envelope","The outer layers separating inside from outside: walls, roof, windows, and lowest floor."],["Footing","The widened base of a foundation that spreads load into the soil."],["Pile","A long column driven or drilled into the ground to reach firmer soil."],["Flashing","A strip of metal or membrane that directs water away at joints."],["U-value","A measure of heat flow through an element; lower is better insulated."],["Thermal bridge","A path where heat bypasses insulation."],["Gable roof","A roof with two slopes meeting at a ridge and triangular end walls."]],
  w:"Most building problems begin in the envelope, and its design shapes both a building's performance and its appearance.",
  src:["Building envelope","Foundation (engineering)","Roof","Flashing (weatherproofing)","Thermal insulation","Thermal bridge"],
  q:[["When are deep foundations such as piles needed?","When good soil is too far below the surface","Only for one-story houses","When there is no rain","When walls are made of timber"],
     ["What is the purpose of a ventilated cavity behind cladding?","To let water drain and the wall dry out","To hide electrical wiring","To store tools","To hold up the roof"],
     ["A hip roof has…","Slopes on all four sides","A single slope","Two slopes and triangular end walls","No slope at all"],
     ["What does flashing do?","Directs water away at joints and openings","Lights up the facade","Carries the load of a window","Insulates the roof"],
     ["A lower U-value means…","Better insulation","More heat loss","A heavier wall","A taller roof"],
     ["What is a thermal bridge?","A path where heat bypasses insulation","A heated footbridge","A roof beam","A type of window"]]},

{ t:"Elements of a Building", s:"Stairs, doors, windows, and the parts we touch",
  sec:[
  ["A building's vocabulary of parts",[
    "Buildings are assembled from a limited set of elements that every architect learns to design: floors, walls, roofs, columns, beams, stairs, ramps, doors, windows, and the fixtures and fittings inside. The Dutch architect Rem Koolhaas's 2014 Venice Biennale exhibition, 'Elements of Architecture', examined fifteen such elements, from the fireplace to the toilet, showing how each has a long history.",
    "These elements are where people physically meet architecture. We rarely touch the structure, but we grip handrails, push doors, climb stairs, open windows, and sit on window seats. Designing them well requires knowledge of the human body, building codes, and craft."]],
  ["Stairs",[
    "A stair must be safe, comfortable, and fit its space. Each step has a riser (the vertical part) and a tread or 'going' (the horizontal part you step on). Since the 17th century, builders have used rules relating the two; a common version, from the French architect François Blondel, says that twice the riser plus the tread should equal roughly one comfortable stride, about 60–65 cm. Codes set maximum riser heights and minimum tread depths, require handrails, and limit the number of steps in a single flight before a landing.",
    "Stair types include straight flights, L-shaped and U-shaped (dog-leg) stairs with landings, spiral stairs, and helical stairs. Stairs can be dramatic architectural features, from Michelangelo's flowing stair in the Laurentian Library and the double-helix stair at Chambord to the grand staircase of the Paris Opéra. Ramps, with gentle slopes typically no steeper than 1:12 in accessibility codes, allow wheelchair users and others to move between levels."]],
  ["Doors and thresholds",[
    "Doors control movement, privacy, security, sound, and fire. Types include hinged (swing) doors, sliding doors, pocket doors that slide into a wall, revolving doors (patented in the US by Theophilus Van Kannel in 1888, which reduce drafts), folding doors, and automatic doors. Fire doors are rated to resist fire for a set time and must close automatically.",
    "The threshold, the point of crossing, is rich in meaning in many cultures, from carrying a bride across it to removing shoes before entering a Japanese home at the genkan, a lowered entry area. Architects design entrances to signal welcome, importance, or privacy through porches, canopies, steps, and changes of light."]],
  ["Windows",[
    "Window types include fixed windows, casements (hinged at the side), sash windows (sliding up and down, typical of Georgian houses), awning and hopper windows (hinged at top or bottom), pivot windows, and bay and oriel windows that project from the wall. The placement and proportion of windows strongly define a facade's character and a room's atmosphere.",
    "Windows frame views and bring light, but also cause glare, heat gain, and heat loss. Le Corbusier and Auguste Perret famously argued about horizontal versus vertical windows: Le Corbusier favored the ribbon window for even light, while Perret defended the tall window that frames a person standing and connects the view of sky and ground."]],
  ["Columns, floors, and ceilings",[
    "Columns and beams organize space as well as carry loads. A regular structural grid sets the rhythm of a building and determines where rooms, stairs, and openings can go. Floors must be strong, stiff enough not to bounce, and often carry services within or beneath them. Ceiling height strongly affects how a room feels; higher ceilings feel grander, lower ones more intimate.",
    "Architects also design built-in elements: fireplaces, which for centuries were the heart of the home; kitchens and bathrooms; storage; and window seats and alcoves. Christopher Alexander's influential book 'A Pattern Language' (1977), with Sara Ishikawa and Murray Silverstein, describes 253 'patterns', such as 'window place', 'light on two sides of every room', and 'stair seats', as practical wisdom for creating comfortable places."]],
  ["Details",[
    "Details are the small-scale decisions where materials and elements meet: how a handrail is fixed, how a floor meets a wall, how a window sits in its opening. They determine durability and quality and are where much of an architect's craft lies. Carlo Scarpa, an Italian architect of the mid-20th century, became famous for exquisite details in projects such as the Castelvecchio Museum in Verona and the Brion tomb.",
    "Good details often go unnoticed because they simply work. Poor details are noticed quickly: doors that stick, stairs that trip, windows that leak, handles that hurt. Paying attention to these elements is a good way to start appreciating the craft of architecture in everyday buildings."]]
  ],
  terms:[["Riser","The vertical face of a stair step."],["Tread (going)","The horizontal part of a stair step."],["Landing","A level platform between flights of stairs."],["Casement window","A window hinged at the side."],["Threshold","The point of entry into a building or room."],["Pattern language","Christopher Alexander's collection of design patterns for comfortable places."],["Detail","The design of how materials and elements meet at small scale."]],
  w:"Stairs, doors, windows, and details are where people physically meet architecture, and designing them well is central to the craft.",
  src:["Stairs","Door","Window","A Pattern Language","Carlo Scarpa","Threshold (architecture)"],
  q:[["What is a stair riser?","The vertical face of a step","The handrail","The horizontal part of a step","A landing"],
     ["Blondel's stair rule relates twice the riser plus the tread to…","A comfortable stride","The ceiling height","The width of the stair","The number of floors"],
     ["What maximum slope do many accessibility codes set for ramps?","About 1:12","1:2","1:1","1:50 only"],
     ["A casement window is…","Hinged at the side","A sliding sash","A fixed pane","A roof skylight"],
     ["Who wrote 'A Pattern Language' with colleagues?","Christopher Alexander","Le Corbusier","Robert Venturi","Kevin Lynch"],
     ["Carlo Scarpa is famous for…","Exquisite details","The tallest skyscrapers","Garden cities","Steel suspension bridges"]]}
]);

after(8,"Interiors and Furniture",[
{ t:"Designing for Culture and Community", s:"Museums, theaters, libraries, schools, and hospitals",
  sec:[
  ["Building types as design problems",[
    "Each building type has its own needs, history, and conventions. Designing a museum, theater, library, school, or hospital requires understanding how people use these places, along with technical requirements for light, sound, security, and safety. Architects often specialize in particular types because of this specialized knowledge.",
    "Building types also evolve with society. The public museum, library, and school spread in the 18th and 19th centuries alongside ideas of public education and citizenship; the modern hospital developed with advances in medicine and hygiene."]],
  ["Museums",[
    "Early museums grew from royal and aristocratic collections; the Louvre opened to the public in 1793 during the French Revolution, and the British Museum in 1759. 19th-century museums were often temple-like classical buildings with top-lit galleries. In the 20th century, museums experimented: Wright's spiral Guggenheim, the flexible loft-like spaces of the Pompidou, and Gehry's sculptural Guggenheim Bilbao.",
    "Museum design must balance the needs of art and artifacts (controlled light, temperature, humidity, and security) with visitors' experience, including circulation, orientation, rest, and social spaces like cafés and shops. Debates continue between the 'white cube', a neutral gallery space, and expressive museum buildings that may compete with the art. Kahn's Kimbell, Piano's Menil Collection, and Tadao Ando's museums are admired for their handling of natural light."]],
  ["Theaters and concert halls",[
    "Theater design has evolved from Greek open-air theaters to Roman freestanding theaters, Elizabethan playhouses like Shakespeare's Globe (reconstructed in London in 1997), Baroque opera houses with horseshoe-shaped tiers of boxes, and modern auditoriums. Key concerns are sightlines (every seat must see the stage), acoustics, stage machinery, and audience flow.",
    "Stage types include the proscenium (the audience faces the stage through a framed opening), the thrust stage (projecting into the audience on three sides), and theater-in-the-round. Concert halls, as discussed under acoustics, range from classic 'shoebox' halls to 'vineyard' halls. Opera houses such as Sydney's, Oslo's (2008, by Snøhetta, whose sloping marble roof can be walked on by the public), and Copenhagen's are civic landmarks."]],
  ["Libraries",[
    "Libraries have changed from closed collections to public institutions. The Laurentian Library of Michelangelo, Labrouste's Bibliothèque Sainte-Geneviève, and the great domed reading room of the British Museum (1857) show earlier ideals. Andrew Carnegie funded more than 2,500 public libraries worldwide between 1883 and 1929, spreading the free public library.",
    "Contemporary libraries are community centers as much as book collections, with spaces for study, technology, events, children, and meeting. Examples include OMA's Seattle Central Library, Helsinki's Oodi Central Library (2018) by ALA Architects, with a vast open 'book heaven' upper floor, and Toyo Ito's Sendai Mediatheque (2001), whose tubular steel columns survived the 2011 earthquake."]],
  ["Schools",[
    "School design reflects ideas about education. 19th-century schools were often rigid rows of classrooms; the 'open-air school' movement of the early 20th century promoted fresh air and light to fight tuberculosis. Mid-century schools experimented with flexible, light-filled classrooms connected to gardens; Hans Scharoun's Geschwister-Scholl School in Lünen, Germany (1956–1962) organized classrooms as 'homes' by age group.",
    "Research has linked daylight, air quality, acoustics, and temperature to students' comfort and performance. Contemporary schools often include varied learning spaces for group work, quiet study, and outdoor learning. Francis Kéré's Gando Primary School showed how passive cooling and community construction can create excellent schools at low cost."]],
  ["Hospitals and healthcare",[
    "Florence Nightingale's 'Notes on Hospitals' (1859) promoted pavilion-plan wards with cross-ventilation, daylight, and space between beds, in the belief, common at the time, that 'miasma' or bad air caused disease. Although germ theory replaced miasma theory, her emphasis on light, air, and cleanliness proved beneficial. Alvar Aalto's Paimio Sanatorium carried these ideas into modernism.",
    "Modern hospitals are among the most complex buildings, with operating theaters, imaging, laboratories, intensive care, and complex logistics. Healthcare architecture today emphasizes infection control, flexibility for changing medical technology, wayfinding, family spaces, and 'healing environments' with daylight, nature views, and art. Maggie's Centres in the UK, cancer support centers designed by architects including Frank Gehry, Zaha Hadid, and Richard Rogers, show how architecture can provide comfort in difficult times."]]
  ],
  terms:[["Building type","A category of buildings sharing a common purpose and form, such as a school or museum."],["White cube","A neutral, white-walled gallery space."],["Sightline","An unobstructed line of view from a seat to a stage or screen."],["Proscenium","A frame or arch separating the stage from the audience."],["Thrust stage","A stage projecting into the audience on three sides."],["Pavilion plan","A hospital layout of separate ventilated wings."]],
  w:"Every building type is a specialized design problem that reflects how a society learns, heals, gathers, and remembers.",
  src:["Museum","Theatre","Library","School building design","Hospital","Florence Nightingale"],
  q:[["When did the Louvre open to the public?","1793","1659","1851","1900"],
     ["The 'white cube' refers to…","A neutral gallery space","A type of hospital ward","A cube-shaped library","An ice rink"],
     ["Which stage type projects into the audience on three sides?","Thrust stage","Proscenium","Theater-in-the-round","Orchestra pit"],
     ["Who funded more than 2,500 public libraries worldwide?","Andrew Carnegie","John D. Rockefeller","Florence Nightingale","Henry Ford"],
     ["Florence Nightingale promoted hospital wards with…","Cross-ventilation and daylight","No windows","Underground rooms","Shared beds"],
     ["Oslo's Opera House is famous for…","A sloping roof the public can walk on","A golden dome","A glass pyramid","Twin towers"]]},

{ t:"Sacred Architecture Across Faiths", s:"Designing places for the spiritual",
  sec:[
  ["What makes space sacred",[
    "Religious buildings are among architecture's most ambitious and long-lasting works. Across faiths, sacred architecture uses common strategies: separation from everyday space through walls, gates, and thresholds; a path or axis leading to a holy center; light, often from above or behind; verticality reaching toward the heavens; and rich materials, symbols, and acoustics.",
    "The historian of religion Mircea Eliade described sacred places as an axis mundi, a world axis connecting earth and heaven. Mountains, towers, domes, and spires often express this idea, from ziggurats and stupas to cathedral spires and minarets."]],
  ["Christian churches",[
    "Christian church plans developed from the basilica (long nave toward the altar) and the central plan (dome over the center). The Latin cross became standard in the West, while Orthodox churches favored the cross-in-square with domes. After the Reformation, Protestant churches often emphasized the pulpit and preaching, bringing congregations closer, as in Wren's London churches and simple Puritan meetinghouses.",
    "The Second Vatican Council (1962–1965) encouraged Catholic churches to bring the altar closer to the people, leading to new, more centralized plans. Modern churches range from Le Corbusier's Ronchamp to Tadao Ando's Church of the Light and Rafael Moneo's Cathedral of Our Lady of the Angels in Los Angeles (2002)."]],
  ["Synagogues",[
    "Synagogues are places of prayer, study, and assembly. Key elements include the ark (aron kodesh), a cabinet holding the Torah scrolls, usually on the wall facing Jerusalem, and the bimah, a raised platform from which the Torah is read. Historically, many synagogues placed the bimah at the center, while some Reform synagogues moved it toward the front.",
    "Because Jewish communities lived in many countries, synagogue architecture absorbed local styles: Gothic in medieval Prague's Old-New Synagogue (13th century), Moorish Revival in 19th-century Europe and America (Budapest's Dohány Street Synagogue, among the largest in the world), and modernism in the 20th century. Wooden synagogues of Poland, nearly all destroyed in the Holocaust, were remarkable folk architecture."]],
  ["Mosques, temples, and gurdwaras",[
    "As covered earlier, mosques are oriented toward Mecca, with a mihrab and often a courtyard and minaret. Hindu temples center on a dark sanctum beneath a tower, approached through halls; Buddhist architecture includes stupas, pagodas, and monasteries. Shinto shrines mark sacred places in nature with torii gates.",
    "Sikh gurdwaras are open to all, typically with doors on all sides symbolizing welcome, and include a langar, a communal kitchen serving free meals. The Harmandir Sahib (Golden Temple) in Amritsar, India, stands in a sacred pool, approached by a causeway, and serves free meals to tens of thousands of people every day."]],
  ["Contemporary sacred space",[
    "Contemporary sacred architecture often seeks simplicity, light, and silence. Examples include the Rothko Chapel in Houston (1971), a non-denominational space for Mark Rothko's dark paintings; the Bahá'í Lotus Temple in New Delhi (1986), by Fariborz Sahba, with 27 marble-clad petals; and Peter Zumthor's Bruder Klaus Field Chapel in Germany (2007), whose interior was formed by burning out a timber framework inside rammed concrete.",
    "Interfaith spaces, such as the House of One in Berlin, under construction as of the mid-2020s, aim to combine a church, a mosque, and a synagogue around a shared central hall. Memorials and contemplative spaces, like the Vietnam Veterans Memorial in Washington (1982) by Maya Lin, create quasi-sacred experiences for secular societies."]],
  ["Designing the sacred",[
    "Designing sacred space requires understanding liturgy (the forms of worship), community traditions, symbolism, and acoustics for speech and music. Light is often central: hidden sources, colored glass, or a single shaft of daylight can create a sense of transcendence.",
    "Even non-religious people often feel something special in great sacred buildings. Studying them teaches how architecture can create atmosphere, focus attention, and support ritual, lessons valuable for any building that aims to move people."]]
  ],
  terms:[["Axis mundi","A 'world axis' connecting earth and heaven, expressed in towers and domes."],["Liturgy","The prescribed forms of public worship."],["Ark (aron kodesh)","The cabinet holding Torah scrolls in a synagogue."],["Bimah","The raised platform for reading the Torah."],["Gurdwara","A Sikh place of worship."],["Langar","The communal free kitchen of a gurdwara."]],
  w:"Sacred architecture shows how buildings can create atmosphere and meaning, lessons that apply to all architecture.",
  src:["Sacred architecture","Synagogue architecture","Gurdwara","Golden Temple","Rothko Chapel","Lotus Temple"],
  q:[["What is an axis mundi?","A world axis linking earth and heaven","A street grid","A type of column","A garden path"],
     ["What did the Second Vatican Council encourage in Catholic churches?","Bringing the altar closer to the people","Building taller spires","Removing all windows","Using only Gothic forms"],
     ["In a synagogue, the bimah is…","A raised platform for reading the Torah","A cabinet for scrolls","A bell tower","A ritual bath"],
     ["What is a langar?","The communal free kitchen of a gurdwara","A Hindu temple tower","A Japanese gate","A mosque pulpit"],
     ["The Lotus Temple in New Delhi belongs to which faith?","Bahá'í","Hindu","Sikh","Buddhist"],
     ["Who designed the Vietnam Veterans Memorial?","Maya Lin","Peter Zumthor","Tadao Ando","Louis Kahn"]]}
]);
})();
