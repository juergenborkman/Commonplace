/* ---- from lit-01.js ---- */
/* LITERATURE FOUNDATIONS, part 1: Unit 1 How Literature Works, chapters 1-5 */
COURSES.literature = { units: [] };
COURSES.literature.units.push({ t:"How Literature Works", ch:[

{ t:"What Is Literature?", s:"Words made to last",
  sec:[
  ["Defining literature",[
    "Literature, from the Latin littera ('letter'), originally meant anything written. Today it usually refers to imaginative and artistic writing, poetry, fiction, and drama, along with essays, memoirs, and other prose valued for their craft and insight. What counts as literature has always been debated: Shakespeare's plays were popular entertainment, and novels were once dismissed as trivial.",
    "Literature is not only written. Oral literature, epics, myths, folktales, songs, and proverbs passed down by voice, came first and remains vital in many cultures. Homer's epics and West African griot epics were composed and performed orally long before they were written down."]],
  ["What literature does",[
    "Literature entertains, but it also lets readers live other lives, see through other eyes, and think about questions with no easy answers: love, death, justice, faith, power, and identity. Psychologists have studied whether reading fiction increases empathy; some studies suggest it can improve our ability to understand others' minds, though findings are debated.",
    "Literature also preserves memory and language. The poet Ezra Pound called literature 'news that stays news.'"]],
  ["The three great modes",[
    "Since ancient Greece, literature has often been divided into three modes. Poetry (lyric) uses concentrated, rhythmic language, often expressing a speaker's feelings. Narrative (epic and later fiction) tells stories, through a narrator. Drama presents action directly through characters speaking and acting on stage.",
    "Modern categories include fiction (novels, short stories), poetry, drama, and creative nonfiction (essays, memoir, travel writing), though many works mix forms."]],
  ["The canon",[
    "The literary canon is the body of works considered most important and widely taught, such as Homer, Dante, Shakespeare, Cervantes, Tolstoy, and Woolf. Critics such as Harold Bloom (The Western Canon, 1994) defended it as a tradition of greatness; others argued it has excluded women, people of color, non-Western writers, and working-class voices.",
    "Since the late 20th century, canons have expanded to include more diverse writers and world literatures. A useful view is that the canon is an ongoing conversation, constantly revised."]],
  ["Literature and its readers",[
    "The meaning of a work depends partly on its readers. A Victorian reader and a modern reader may find very different things in the same novel. Literary works are shaped by their historical moment but can speak across centuries.",
    "Reading literature well involves both enjoyment and attention: noticing how words, structures, and images create meaning and feeling."]]
  ],
  terms:[["Literature","Imaginative and artistic writing valued for craft and insight."],["Oral literature","Stories and poems passed down by voice."],["Canon","Works considered most important and widely taught."],["Genre","Category of literature, such as poetry or the novel."],["Lyric","Poetry expressing a speaker's thoughts and feelings."]],
  w:"Knowing what literature is and does frames every book, poem, and play you read.",
  src:["Literature","Oral literature","Western canon","Literary genre","The Western Canon"],
  q:[
  ["What does the Latin word littera mean?","Letter","Book","Story","Word"],
  ["Which poet called literature 'news that stays news'?","Ezra Pound","T. S. Eliot","W. B. Yeats","Walt Whitman"],
  ["What are the three classic modes of literature?","Poetry, narrative, and drama","Fiction, history, and science","Epic, essay, and letter","Novel, story, and comic"],
  ["Who wrote The Western Canon (1994)?","Harold Bloom","Northrop Frye","Edward Said","Susan Sontag"],
  ["What is oral literature?","Stories and poems passed down by voice","Literature read aloud in schools","Audiobooks","Speeches by politicians"],
  ["What criticism has been made of the traditional canon?","It excluded many women and non-Western writers","It is too short","It contains no poetry","It is too modern"]]},

{ t:"Narrative: How Stories Work", s:"Plot, structure, and time",
  sec:[
  ["Story and plot",[
    "Critics distinguish story (the events in chronological order) from plot (how the events are arranged and presented). E. M. Forster, in Aspects of the Novel (1927), explained: 'The king died and then the queen died' is a story; 'The king died, and then the queen died of grief' is a plot, because it adds causality.",
    "Russian formalists used the terms fabula (story) and syuzhet (plot) for the same distinction."]],
  ["Classic structure",[
    "Aristotle's Poetics described a plot with a beginning, middle, and end, unified by cause and effect. In the 19th century, German writer Gustav Freytag described dramatic structure as a pyramid: exposition (introduction), rising action, climax (turning point), falling action, and resolution (or dénouement, 'untying').",
    "Conflict drives plot: a character versus another character, versus society, versus nature, versus fate or God, or versus themselves."]],
  ["Playing with time",[
    "Writers manipulate time: in medias res ('into the middle of things') begins mid-action, as Homer's epics do; flashbacks (analepsis) and flash-forwards (prolepsis) move backward and forward; foreshadowing hints at what will come. Some novels span centuries; James Joyce's Ulysses covers a single day.",
    "Pacing varies the speed of narration: a summary covers years in a sentence, while a scene may spend pages on minutes."]],
  ["Story patterns",[
    "Scholars have identified recurring patterns. Joseph Campbell's The Hero with a Thousand Faces (1949) described the 'monomyth' or hero's journey: departure, initiation, and return, a pattern that influenced George Lucas's Star Wars. Folklorist Vladimir Propp analyzed recurring functions in Russian folktales.",
    "Common plot types include the quest, rags to riches, tragedy, comedy (ending in harmony, often marriage), voyage and return, and rebirth. Such patterns are tools, not rules; great works often subvert them."]],
  ["Frames and openings",[
    "A frame narrative contains stories within a story, as in One Thousand and One Nights, Boccaccio's Decameron, Chaucer's Canterbury Tales, and Mary Shelley's Frankenstein. Openings set tone and hook readers; famous first lines include 'Call me Ishmael' (Moby-Dick) and 'It was the best of times, it was the worst of times' (A Tale of Two Cities).",
    "Endings can be closed (resolving all conflicts) or open (leaving questions unanswered); a twist ending reverses expectations."]]
  ],
  terms:[["Plot","Arrangement of events with causality."],["Exposition","Introductory background information."],["Climax","Turning point of highest tension."],["In medias res","Beginning in the middle of the action."],["Frame narrative","A story containing other stories."]],
  w:"Understanding narrative structure reveals how writers create suspense, meaning, and satisfaction.",
  src:["Plot (narrative)","Freytag's pyramid","In medias res","Hero's journey","Frame story"],
  q:[
  ["Who distinguished story from plot using the king and queen example?","E. M. Forster","Aristotle","Joseph Campbell","Vladimir Propp"],
  ["What does 'in medias res' mean?","Into the middle of things","At the end","In the beginning","Through the eyes of"],
  ["Who described the 'hero's journey' or monomyth?","Joseph Campbell","Gustav Freytag","Northrop Frye","Carl Jung"],
  ["What is the climax of a plot?","The turning point of highest tension","The introduction","The final page","A minor subplot"],
  ["Which work is a famous frame narrative?","One Thousand and One Nights","Hamlet","Pride and Prejudice","The Odyssey only"],
  ["What is a flashback also called?","Analepsis","Prolepsis","Catharsis","Hubris"]]},

{ t:"Character and Point of View", s:"Who acts and who tells",
  sec:[
  ["Characters",[
    "Characters are the people (or beings) in a story. The protagonist is the central character; the antagonist opposes them. Forster distinguished 'flat' characters, built around a single idea and easily summarized, from 'round' characters, complex enough to surprise the reader convincingly.",
    "Dynamic characters change over the story; static characters do not. A foil contrasts with another character to highlight their qualities, as the hot-headed Laertes contrasts with the hesitant Hamlet."]],
  ["Characterization",[
    "Writers reveal character directly (telling us a character is generous) or indirectly, through speech, actions, thoughts, appearance, and how others react. 'Show, don't tell' is common writing advice, favoring indirect characterization.",
    "Archetypes are recurring character types, such as the trickster, the mentor, the innocent, or the femme fatale; stock characters are stereotyped types, such as the miser or the braggart soldier of comedy."]],
  ["Point of view",[
    "Point of view is the perspective from which a story is told. First-person narration ('I') gives intimacy but limited knowledge; examples include Jane Eyre and The Catcher in the Rye. Second person ('you') is rare. Third-person narration may be omniscient (knowing all characters' thoughts, as in Middlemarch or War and Peace) or limited (following one character closely).",
    "Free indirect discourse blends a third-person narrator's voice with a character's thoughts without quotation marks, a technique perfected by Jane Austen and Gustave Flaubert."]],
  ["Unreliable narrators",[
    "An unreliable narrator cannot be fully trusted, because of naivety, madness, self-deception, or deceit. Examples include Edgar Allan Poe's narrator in 'The Tell-Tale Heart,' Nelly Dean in Wuthering Heights, Humbert Humbert in Nabokov's Lolita, and Stevens the butler in Kazuo Ishiguro's The Remains of the Day.",
    "Readers must read 'against' such narrators, noticing gaps between what they say and what the story reveals."]],
  ["Stream of consciousness",[
    "Stream of consciousness represents the flow of a character's thoughts, sensations, and memories, often with loose grammar and associative leaps. The term comes from psychologist William James. Modernists such as James Joyce, Virginia Woolf, and William Faulkner used it; the final chapter of Joyce's Ulysses, Molly Bloom's monologue, runs for pages without conventional punctuation.",
    "The choice of point of view profoundly shapes what readers know, feel, and believe."]]
  ],
  terms:[["Protagonist","Central character of a story."],["Round character","Complex, surprising character."],["Omniscient narrator","Narrator who knows all characters' thoughts."],["Unreliable narrator","Narrator whose account can't be trusted."],["Free indirect discourse","Narration blending narrator and character voices."]],
  w:"Who tells a story, and how, shapes everything readers understand about it.",
  src:["Character (arts)","Narration","Unreliable narrator","Free indirect speech","Stream of consciousness"],
  q:[
  ["Who distinguished 'flat' and 'round' characters?","E. M. Forster","Henry James","Aristotle","Virginia Woolf"],
  ["What is a foil?","A character contrasting with another to highlight qualities","A villain","A narrator","A plot twist"],
  ["Which novel has a famous unreliable narrator named Humbert Humbert?","Lolita","Jane Eyre","Moby-Dick","Emma"],
  ["Which writers perfected free indirect discourse?","Jane Austen and Gustave Flaubert","Homer and Virgil","Shakespeare and Marlowe","Poe and Hawthorne"],
  ["Who coined the term 'stream of consciousness'?","William James","James Joyce","Sigmund Freud","Henry James"],
  ["What does an omniscient narrator know?","All characters' thoughts","Only their own thoughts","Nothing about characters","Only the future"]]},

{ t:"Setting, Theme, and Symbol", s:"Where, what about, and what it means",
  sec:[
  ["Setting",[
    "Setting is the time, place, and social environment of a story. It can be a backdrop or almost a character itself: Thomas Hardy's Wessex, Faulkner's Yoknapatawpha County, Dickens's London, and the moors of Wuthering Heights shape characters' lives and moods.",
    "Setting establishes atmosphere and can reflect inner states; the 'pathetic fallacy,' a term coined by John Ruskin, attributes human feelings to nature, as when a storm mirrors turmoil."]],
  ["Theme",[
    "Theme is a central idea or insight a work explores, such as ambition, love, injustice, coming of age, or the nature of good and evil. A theme is not just a topic ('war') but a perspective on it ('war destroys innocence'). Most rich works have multiple themes and resist being reduced to a single 'message.'",
    "Readers infer themes from patterns: recurring images, conflicts, character changes, and titles."]],
  ["Symbol and motif",[
    "A symbol is an object, character, or event that stands for something beyond itself: the green light in F. Scott Fitzgerald's The Great Gatsby suggests Gatsby's longing and the American Dream; the white whale in Moby-Dick has been read as nature, God, evil, or the unknowable.",
    "A motif is a recurring element, image, phrase, or situation, that develops a theme, such as blood in Macbeth or birds in Jane Eyre. Allegory is an extended symbolic narrative where characters and events stand for abstract ideas, as in John Bunyan's The Pilgrim's Progress and George Orwell's Animal Farm."]],
  ["Tone and mood",[
    "Tone is the author's or narrator's attitude toward the subject: ironic, playful, solemn, angry, nostalgic. Mood is the feeling created in the reader. Diction (word choice) and syntax (sentence structure) create tone.",
    "Irony is central to much literature: verbal irony says the opposite of what is meant; situational irony occurs when outcomes contradict expectations; dramatic irony occurs when the audience knows something characters do not, as when the audience knows Juliet is alive but Romeo does not."]],
  ["Reading for meaning",[
    "Interpreting symbols and themes involves evidence from the text, awareness of context, and openness to multiple readings. Over-reading, finding hidden meaning everywhere, is a risk; the saying 'Sometimes a cigar is just a cigar' is often (perhaps falsely) attributed to Freud.",
    "Good interpretation is persuasive, grounded in details, and attentive to the whole work."]]
  ],
  terms:[["Setting","Time, place, and environment of a story."],["Theme","Central idea a work explores."],["Symbol","Something standing for more than itself."],["Motif","Recurring element developing a theme."],["Dramatic irony","Audience knows what characters don't."]],
  w:"Setting, theme, and symbol turn a story's surface into layers of meaning.",
  src:["Setting (narrative)","Theme (narrative)","Symbolism (arts)","Motif (narrative)","Irony"],
  q:[
  ["What does the green light in The Great Gatsby often symbolize?","Gatsby's longing and the American Dream","Envy","Safety","Money only"],
  ["Who coined the term 'pathetic fallacy'?","John Ruskin","Samuel Johnson","Matthew Arnold","Aristotle"],
  ["What is dramatic irony?","When the audience knows what characters don't","Saying the opposite of what is meant","An unexpected ending","A sad play"],
  ["Which work is an allegory?","Animal Farm","Pride and Prejudice","Ulysses","Hamlet"],
  ["What is a motif?","A recurring element developing a theme","The main character","The setting","A rhyme scheme"],
  ["Whose fictional county is Yoknapatawpha?","William Faulkner","Thomas Hardy","Mark Twain","John Steinbeck"]]},

{ t:"Figurative Language and Style", s:"How words do more than say",
  sec:[
  ["Simile and metaphor",[
    "Figurative language uses words beyond their literal meaning. A simile compares two things using 'like' or 'as': Robert Burns's 'O my Luve is like a red, red rose.' A metaphor states the comparison directly: Shakespeare's 'All the world's a stage.' An extended metaphor develops a comparison at length; a conceit is an elaborate, surprising one, typical of John Donne.",
    "Dead metaphors are so familiar we no longer notice them ('the leg of a table'). Mixed metaphors combine incompatible images, usually by accident."]],
  ["Other figures",[
    "Personification gives human qualities to non-human things ('the wind whispered'). Metonymy substitutes something associated with a thing ('the Crown' for the monarchy); synecdoche uses a part for the whole ('all hands on deck'). Hyperbole exaggerates; understatement (litotes) deliberately minimizes ('not bad at all').",
    "Apostrophe addresses an absent person or abstraction ('O Death'). Oxymoron combines contradictory terms ('sweet sorrow'); paradox expresses a seemingly self-contradictory truth."]],
  ["Imagery",[
    "Imagery appeals to the senses: sight, sound, smell, taste, and touch. Concrete images often carry more power than abstract statements. The Imagist poets of the early 20th century, such as Ezra Pound in 'In a Station of the Metro,' sought direct, precise images.",
    "Synesthesia mixes senses ('a loud color')."]],
  ["Sound devices",[
    "Writers use sound: alliteration (repeated initial consonants: 'Peter Piper picked'), assonance (repeated vowel sounds), consonance (repeated consonants within words), onomatopoeia (words that imitate sounds: 'buzz'), and rhyme. Rhythm, the pattern of stressed and unstressed syllables, matters in prose as well as poetry.",
    "Old English poetry was built on alliteration rather than rhyme."]],
  ["Rhetoric and style",[
    "Rhetorical devices include anaphora (repeating words at the start of clauses, as in Martin Luther King Jr.'s 'I have a dream'), antithesis (contrasting ideas in parallel structure), rhetorical questions, and chiasmus (reversing structure: 'Ask not what your country can do for you...').",
    "Style is a writer's distinctive use of language: Hemingway's spare sentences, Henry James's elaborate clauses, Toni Morrison's lyrical intensity. Register ranges from formal to colloquial, and dialect reproduces regional or social speech."]]
  ],
  terms:[["Metaphor","Direct comparison without 'like' or 'as.'"],["Simile","Comparison using 'like' or 'as.'"],["Metonymy","Substituting an associated term."],["Alliteration","Repetition of initial consonant sounds."],["Anaphora","Repetition at the start of successive clauses."]],
  w:"Figurative language is the toolkit of literary power; recognizing it deepens every reading.",
  src:["Figure of speech","Metaphor","Imagery","Alliteration","Rhetorical device"],
  q:[
  ["Which is a simile?","O my Luve is like a red, red rose","All the world's a stage","The Crown decided","Sweet sorrow"],
  ["What is metonymy?","Substituting something associated with a thing","An exaggeration","A sound imitation","A contradiction"],
  ["What is an oxymoron?","A combination of contradictory terms","A long metaphor","A repeated sound","An address to the dead"],
  ["Which device repeats initial consonant sounds?","Alliteration","Assonance","Onomatopoeia","Chiasmus"],
  ["Which poetic movement sought direct, precise images?","Imagism","Romanticism","Metaphysical poetry","Symbolism"],
  ["What is anaphora?","Repetition of words at the start of successive clauses","A type of rhyme","A reversed structure","A question"]]}

]});


/* ---- from lit-02.js ---- */
/* LITERATURE FOUNDATIONS, part 2: Unit 1 chapters 6-10 */
COURSES.literature.units[0].ch.push(

{ t:"Poetry: Meter, Rhyme, and Sound", s:"The music of verse",
  sec:[
  ["Lines and stanzas",[
    "Poetry is organized in lines, and lines into stanzas: a couplet (two lines), tercet (three), quatrain (four), sestet (six), and octave (eight). Where a line ends matters: an end-stopped line finishes with a pause; enjambment carries a sentence over the line break, creating tension and momentum.",
    "A caesura is a pause within a line, often marked by punctuation."]],
  ["Meter",[
    "Meter is the regular pattern of stressed and unstressed syllables. The basic unit is the foot: the iamb (da-DUM, as in 'a-LONE'), trochee (DUM-da), anapest (da-da-DUM), dactyl (DUM-da-da), and spondee (DUM-DUM). Lines are named by the number of feet: trimeter (three), tetrameter (four), pentameter (five), hexameter (six).",
    "Iambic pentameter, five iambs per line, is the most important meter in English poetry, used by Chaucer, Shakespeare, Milton, and Wordsworth: 'Shall I compare thee to a summer's day?' Scansion is the practice of marking a line's meter."]],
  ["Rhyme",[
    "Rhyme repeats sounds at the ends of words. Rhyme schemes are marked with letters: ABAB, AABB. Perfect rhymes match exactly ('cat/hat'); slant or half rhymes approximate ('soul/all'), as Emily Dickinson often used. Internal rhyme occurs within a line. Masculine rhyme falls on a stressed final syllable; feminine rhyme on two syllables ('motion/ocean').",
    "Blank verse is unrhymed iambic pentameter, used in Shakespeare's plays and Milton's Paradise Lost."]],
  ["Free verse",[
    "Free verse has no regular meter or rhyme, relying on natural speech rhythms, line breaks, and repetition. Walt Whitman's Leaves of Grass (1855) pioneered it in English, inspired partly by the King James Bible's rhythms; it became dominant in the 20th century.",
    "Robert Frost famously said writing free verse was 'like playing tennis with the net down,' while its defenders argued that it allows organic form shaped by meaning."]],
  ["Other traditions",[
    "Other languages have different prosody: classical Greek and Latin verse was quantitative, based on long and short syllables; French verse counts syllables (the 12-syllable alexandrine); Chinese regulated verse uses tonal patterns; Japanese poetry counts sound units (morae); Arabic poetry uses meters described by the 8th-century scholar al-Khalil ibn Ahmad.",
    "Reading poetry aloud brings out its sound, which is inseparable from its meaning."]]
  ],
  terms:[["Iambic pentameter","Five iambs per line."],["Enjambment","Sentence running past a line break."],["Blank verse","Unrhymed iambic pentameter."],["Free verse","Poetry without regular meter or rhyme."],["Scansion","Marking the meter of a line."]],
  w:"Understanding meter and rhyme lets you hear the music that shapes a poem's meaning.",
  src:["Meter (poetry)","Iambic pentameter","Rhyme scheme","Free verse","Enjambment"],
  q:[
  ["What is an iamb?","An unstressed syllable followed by a stressed one","A stressed then unstressed syllable","Two stressed syllables","Three syllables"],
  ["What is blank verse?","Unrhymed iambic pentameter","Poetry with no words","Rhymed couplets","Free verse"],
  ["Who pioneered free verse in English with Leaves of Grass?","Walt Whitman","Emily Dickinson","Robert Frost","Ezra Pound"],
  ["What is enjambment?","A sentence running past a line break","A pause within a line","A rhyme","A stanza of four lines"],
  ["How many lines are in a quatrain?","Four","Two","Six","Eight"],
  ["Who compared free verse to 'playing tennis with the net down'?","Robert Frost","T. S. Eliot","W. H. Auden","Sylvia Plath"]]},

{ t:"Poetic Forms", s:"Sonnets, odes, haiku, and more",
  sec:[
  ["The sonnet",[
    "The sonnet is a 14-line poem, usually in iambic pentameter. The Italian (Petrarchan) sonnet, perfected by Francesco Petrarch in the 14th century, has an octave (ABBAABBA) presenting a problem and a sestet answering it, with a 'turn' (volta) between them. The English (Shakespearean) sonnet has three quatrains and a final rhyming couplet (ABAB CDCD EFEF GG), often delivering a twist.",
    "Sonnet sequences tell stories or explore themes: Shakespeare's 154 sonnets, Elizabeth Barrett Browning's Sonnets from the Portuguese ('How do I love thee?')."]],
  ["Lyric forms",[
    "The ode is an elevated poem addressing a subject, from Pindar's victory odes to John Keats's 'Ode to a Nightingale' and 'Ode on a Grecian Urn.' The elegy mourns the dead, as in Thomas Gray's 'Elegy Written in a Country Churchyard' and Walt Whitman's 'O Captain! My Captain!' for Lincoln.",
    "The ballad tells a story in simple quatrains, often with a refrain, rooted in folk tradition; the dramatic monologue, mastered by Robert Browning in 'My Last Duchess,' reveals a speaker's character through a speech to a silent listener."]],
  ["Fixed forms",[
    "The villanelle has 19 lines with two repeating refrains and only two rhymes, as in Dylan Thomas's 'Do not go gentle into that good night' and Elizabeth Bishop's 'One Art.' The sestina repeats six end-words in shifting order over six stanzas. The limerick is a comic five-line form (AABBA) popularized by Edward Lear.",
    "The ghazal, from Arabic and Persian tradition, consists of couplets with a repeated refrain, often about love and longing; Hafez and Rumi wrote famous ghazals."]],
  ["East Asian forms",[
    "The Japanese haiku has three phrases of 5, 7, and 5 sound units, usually with a seasonal reference (kigo) and a cutting word creating a pause; Matsuo Bashō's 'old pond / a frog jumps in / sound of water' is the most famous. The tanka (5-7-5-7-7) is older. Chinese regulated verse (lüshi) of the Tang dynasty used strict tonal patterns and parallel couplets.",
    "Haiku inspired the Imagist poets and countless modern writers."]],
  ["Epic and narrative poetry",[
    "The epic is a long narrative poem about heroic deeds, often involving gods and the fate of a people: Gilgamesh, the Iliad, the Odyssey, the Aeneid, the Mahabharata, Beowulf, and Paradise Lost. Epics use elevated style, invocations to the Muse, catalogs, and epic similes.",
    "The mock-epic applies epic style to trivial subjects for comedy, as in Alexander Pope's The Rape of the Lock."]]
  ],
  terms:[["Sonnet","Fourteen-line poem, usually in iambic pentameter."],["Volta","The turn in a sonnet."],["Villanelle","Nineteen-line form with two refrains."],["Haiku","Japanese three-phrase form of 5-7-5 sound units."],["Ghazal","Couplet form with refrain from Arabic and Persian poetry."]],
  w:"Knowing poetic forms reveals how poets use and break traditional patterns to create meaning.",
  src:["Sonnet","Villanelle","Haiku","Ghazal","Ode"],
  q:[
  ["How many lines does a sonnet have?","Fourteen","Twelve","Nineteen","Sixteen"],
  ["How does a Shakespearean sonnet end?","With a rhyming couplet","With a sestet","With a refrain","With an octave"],
  ["Which poem is a villanelle?","Do not go gentle into that good night","Ode to a Nightingale","My Last Duchess","The Raven"],
  ["Who wrote the famous haiku about an old pond and a frog?","Matsuo Bashō","Kobayashi Issa","Yosa Buson","Masaoka Shiki"],
  ["What is a dramatic monologue?","A speech revealing a speaker's character to a silent listener","A play with one actor","A long epic","A song"],
  ["Which poet popularized the limerick?","Edward Lear","Lewis Carroll","Ogden Nash","Dr. Seuss"]]},

{ t:"Drama: How Plays Work", s:"Literature for the stage",
  sec:[
  ["Drama as performance",[
    "Drama is literature written to be performed. A play's script includes dialogue and stage directions; its full meaning emerges through actors, directors, design, and audiences. Plays are divided into acts and scenes.",
    "Dramatic speech includes dialogue between characters, the soliloquy (a character alone, speaking thoughts aloud, as in Hamlet's 'To be, or not to be'), the monologue (a long speech to others), and the aside (a remark to the audience unheard by other characters)."]],
  ["Tragedy",[
    "Aristotle's Poetics defined tragedy as the imitation of a serious action that, through pity and fear, achieves catharsis (purgation or clarification of these emotions). The tragic hero is of high standing and falls through hamartia, an error or flaw, often linked to hubris (excessive pride), leading to reversal (peripeteia) and recognition (anagnorisis).",
    "Classical rules, later called the 'unities' of action, time, and place, were emphasized by Renaissance and French neoclassical critics, though Shakespeare often ignored them."]],
  ["Comedy",[
    "Comedy typically moves from confusion to harmony, often ending in marriage or celebration. Forms include Old Comedy (Aristophanes's political satire), New Comedy (Menander's domestic plots of lovers and tricky servants, adapted by the Romans Plautus and Terence), romantic comedy (Shakespeare's Twelfth Night), comedy of manners (satirizing society, from Molière to Oscar Wilde's The Importance of Being Earnest), and farce (physical humor and absurd situations).",
    "Tragicomedy mixes serious and comic elements."]],
  ["Modern drama",[
    "In the 19th century, realism brought ordinary people and social problems to the stage (Henrik Ibsen, Anton Chekhov). The 20th century added expressionism, Bertolt Brecht's 'epic theater' (which used 'alienation effects' to make audiences think critically), the Theatre of the Absurd (Samuel Beckett's Waiting for Godot), and American realism (Tennessee Williams, Arthur Miller).",
    "The fourth wall is the imaginary barrier between stage and audience; some plays break it deliberately."]],
  ["World theater traditions",[
    "Theater traditions worldwide include Sanskrit drama (Kalidasa's Shakuntala), Japanese Noh and kabuki, Chinese opera, Indonesian shadow puppetry, and Yoruba traveling theater. Each has its own conventions of story, music, movement, and audience participation.",
    "Reading a play well means imagining it staged: voices, movement, silence, and space."]]
  ],
  terms:[["Soliloquy","Character speaking thoughts alone on stage."],["Catharsis","Emotional purgation through tragedy."],["Hamartia","Tragic error or flaw."],["Hubris","Excessive pride."],["Fourth wall","Imaginary barrier between stage and audience."]],
  w:"Drama's forms and conventions explain how plays move audiences, from Greek tragedy to modern theater.",
  src:["Drama","Tragedy","Comedy","Poetics (Aristotle)","Soliloquy"],
  q:[
  ["What is a soliloquy?","A character alone speaking thoughts aloud","A dialogue","A stage direction","A chorus song"],
  ["According to Aristotle, tragedy achieves what through pity and fear?","Catharsis","Hubris","Comedy","Recognition"],
  ["What is hamartia?","A tragic error or flaw","A happy ending","A comic servant","A stage machine"],
  ["Who developed 'epic theater' with alienation effects?","Bertolt Brecht","Henrik Ibsen","Anton Chekhov","Samuel Beckett"],
  ["Which play is part of the Theatre of the Absurd?","Waiting for Godot","A Doll's House","Death of a Salesman","Hamlet"],
  ["What is an aside?","A remark to the audience unheard by other characters","A long speech","A set change","An intermission"]]},

{ t:"Fiction and Nonfiction Forms", s:"Novels, stories, essays, and lives",
  sec:[
  ["The novel",[
    "The novel is an extended prose fiction. Precursors include ancient Greek romances, Lady Murasaki's The Tale of Genji (early 11th century, often called the first novel), and Cervantes's Don Quixote (1605–15), often called the first modern novel. The English novel rose in the 18th century with Defoe, Richardson, and Fielding.",
    "Subtypes include the Bildungsroman (coming-of-age novel), the epistolary novel (told through letters, like Dracula), the historical novel, the picaresque (episodic adventures of a roguish hero), the social novel, and the novel of ideas."]],
  ["The short story",[
    "The short story developed as a distinct form in the 19th century. Edgar Allan Poe argued that a story should create a 'single effect' readable in one sitting. Masters include Nikolai Gogol, Guy de Maupassant (known for twist endings), Anton Chekhov (subtle, open-ended stories), O. Henry, James Joyce (Dubliners, with its 'epiphanies'), Katherine Mansfield, Jorge Luis Borges, Flannery O'Connor, Alice Munro (Nobel Prize 2013), and Raymond Carver.",
    "The novella is between a short story and a novel in length: Kafka's The Metamorphosis, Conrad's Heart of Darkness."]],
  ["The essay",[
    "Michel de Montaigne invented the essay (from French essai, 'attempt') in the 1580s, exploring his own thoughts on everything from friendship to cannibals. Francis Bacon wrote concise essays in English. Later essayists include Samuel Johnson, William Hazlitt, Ralph Waldo Emerson, Virginia Woolf, George Orwell ('Politics and the English Language'), James Baldwin, and Joan Didion.",
    "Essays range from personal reflection to argument, criticism, and journalism."]],
  ["Life writing",[
    "Autobiography and memoir tell the author's own life: Augustine's Confessions (about 400), Rousseau's Confessions, Frederick Douglass's Narrative (1845), Maya Angelou's I Know Why the Caged Bird Sings. Biography tells another's life, as in James Boswell's Life of Samuel Johnson (1791).",
    "Diaries and letters can become literature too, such as Samuel Pepys's diary and Anne Frank's diary."]],
  ["Blurred boundaries",[
    "Many works mix forms: the nonfiction novel (Truman Capote's In Cold Blood), autofiction blending autobiography and fiction (Karl Ove Knausgaard's My Struggle), prose poetry, and the graphic novel. Literary journalism uses fiction techniques for factual reporting.",
    "Debates continue about truth and invention in memoir and nonfiction."]]
  ],
  terms:[["Novel","Extended prose fiction."],["Bildungsroman","Coming-of-age novel."],["Epistolary novel","Novel told through letters or documents."],["Novella","Fiction between short story and novel length."],["Essay","Prose exploration of a topic, invented by Montaigne."]],
  w:"Knowing literature's prose forms helps readers recognize what each kind of writing does best.",
  src:["Novel","Short story","Essay","Bildungsroman","Memoir"],
  q:[
  ["Which work is often called the first novel?","The Tale of Genji","Don Quixote","Robinson Crusoe","Pamela"],
  ["Who invented the essay?","Michel de Montaigne","Francis Bacon","Samuel Johnson","Voltaire"],
  ["What is a Bildungsroman?","A coming-of-age novel","A novel in letters","A historical novel","A detective story"],
  ["Who argued a short story should create a 'single effect'?","Edgar Allan Poe","Anton Chekhov","O. Henry","Guy de Maupassant"],
  ["Which short story writer won the 2013 Nobel Prize?","Alice Munro","Raymond Carver","Flannery O'Connor","Lydia Davis"],
  ["Which work is an epistolary novel?","Dracula","Moby-Dick","Ulysses","Don Quixote"]]},

{ t:"Literary Criticism and Theory", s:"Ways of reading",
  sec:[
  ["Classical and early criticism",[
    "Literary criticism began with Plato, who distrusted poets as imitators who stirred emotions, and Aristotle, whose Poetics analyzed tragedy and epic. Horace's Ars Poetica advised that poetry should 'delight and instruct.' Later critics include Philip Sidney (An Apology for Poetry), Samuel Johnson, Samuel Taylor Coleridge, and Matthew Arnold, who saw literature as 'the best that has been thought and said.'",
    "Practical criticism focused on close reading of texts."]],
  ["New Criticism and formalism",[
    "In the mid-20th century, the New Critics (Cleanth Brooks, John Crowe Ransom, W. K. Wimsatt) focused on the text itself, its tensions, ambiguities, and irony, rather than the author's biography or intentions. Wimsatt and Beardsley called using the author's intention to judge meaning the 'intentional fallacy.' Russian formalists studied literary devices and 'defamiliarization,' making the familiar strange.",
    "Close reading remains a foundation of literary study."]],
  ["Structuralism and poststructuralism",[
    "Structuralism, inspired by linguist Ferdinand de Saussure, analyzed literature as systems of signs and recurring structures. Roland Barthes declared 'the death of the author' (1967), arguing that meaning is made by readers. Jacques Derrida's deconstruction showed how texts undermine their own apparent meanings through internal contradictions.",
    "Michel Foucault examined how discourse shapes power and knowledge."]],
  ["Political and cultural readings",[
    "Marxist criticism examines class, ideology, and economic conditions. Feminist criticism, from Virginia Woolf's A Room of One's Own (1929) and Simone de Beauvoir to Sandra Gilbert and Susan Gubar's The Madwoman in the Attic (1979), explores gender and recovers women writers. Postcolonial criticism, launched by Edward Said's Orientalism (1978), studies empire and its aftermath; Chinua Achebe criticized racism in Conrad's Heart of Darkness.",
    "Queer theory, critical race theory, new historicism (reading texts alongside other documents of their time), ecocriticism, and psychoanalytic criticism (drawing on Freud and Lacan) offer further lenses."]],
  ["Reader-response and beyond",[
    "Reader-response theory focuses on how readers create meaning; Stanley Fish described 'interpretive communities.' Digital humanities use computers to analyze large bodies of texts ('distant reading,' Franco Moretti).",
    "No single theory is 'correct'; each lens reveals different aspects of a work, and good readers can move between them."]]
  ],
  terms:[["Close reading","Careful analysis of a text's details."],["Intentional fallacy","Judging meaning by the author's intent."],["Death of the author","Barthes's idea that readers make meaning."],["Deconstruction","Derrida's method exposing texts' contradictions."],["Postcolonial criticism","Study of literature and empire."]],
  w:"Critical theories are lenses that reveal hidden dimensions of texts and how we read them.",
  src:["Literary criticism","New Criticism","Death of the Author","Deconstruction","Orientalism (book)"],
  q:[
  ["Who wrote that poetry should 'delight and instruct'?","Horace","Plato","Aristotle","Longinus"],
  ["Who declared 'the death of the author'?","Roland Barthes","Jacques Derrida","Michel Foucault","Stanley Fish"],
  ["Which book launched postcolonial criticism in 1978?","Orientalism","The Madwoman in the Attic","A Room of One's Own","The Western Canon"],
  ["What did the New Critics focus on?","The text itself","The author's biography","The economy","Readers' feelings"],
  ["Who developed deconstruction?","Jacques Derrida","Ferdinand de Saussure","Roland Barthes","Edward Said"],
  ["Which feminist work examines 19th-century women writers?","The Madwoman in the Attic","Orientalism","Mythologies","Anatomy of Criticism"]]}

);


/* ---- from lit-03.js ---- */
/* LITERATURE FOUNDATIONS, part 3: Unit 2 The Ancient World, chapters 1-4 */
COURSES.literature.units.push({ t:"Literature of the Ancient World", ch:[

{ t:"The First Literatures: Mesopotamia and Egypt", s:"Gilgamesh and the birth of writing",
  sec:[
  ["The invention of writing",[
    "Writing was invented in Mesopotamia (modern Iraq) around 3200 BCE, in the form of cuneiform, wedge-shaped marks pressed into clay tablets. It began as a tool for accounting and administration, recording grain, livestock, and taxes, and only gradually came to record stories, prayers, laws, and poems.",
    "Egyptian hieroglyphs developed at about the same time. These systems allowed oral traditions to be preserved, copied, and transmitted across generations and distances."]],
  ["The first named author",[
    "The earliest author known by name is Enheduanna, a priestess of the moon god Nanna at Ur and daughter of King Sargon of Akkad, who lived around 2300 BCE. She composed hymns to the goddess Inanna, including the 'Exaltation of Inanna,' which combine devotion with personal voice, describing her own exile and restoration.",
    "Sumerian literature also includes proverbs, laments for destroyed cities, debate poems, and myths such as Inanna's descent to the underworld."]],
  ["The Epic of Gilgamesh",[
    "The Epic of Gilgamesh, often called the oldest great work of literature, developed from Sumerian poems about Gilgamesh, a historical king of Uruk around 2700 BCE. The standard Babylonian version, attributed to the scholar Sîn-lēqi-unninni (around 1200 BCE), was preserved on twelve tablets found in the library of the Assyrian king Ashurbanipal at Nineveh, rediscovered in the 1850s.",
    "The epic tells how the arrogant Gilgamesh befriends the wild man Enkidu; together they slay the monster Humbaba and the Bull of Heaven. When Enkidu dies, the grieving Gilgamesh searches for immortality, meeting Utnapishtim, survivor of a great flood strikingly similar to Noah's story in Genesis. He fails to gain eternal life, and returns home to accept mortality and take pride in the walls of his city."]],
  ["The flood tablet",[
    "In 1872, George Smith, a self-taught Assyriologist at the British Museum, deciphered the tablet describing the flood and was reportedly so excited that he began undressing in the reading room. His discovery caused a sensation, showing that biblical stories had older Mesopotamian parallels.",
    "The Atrahasis epic and the Babylonian creation epic Enuma Elish are other major Mesopotamian works."]],
  ["Egyptian literature",[
    "Ancient Egyptian literature includes the Pyramid Texts and the Book of the Dead (spells to guide the dead through the afterlife), wisdom literature such as the Instructions of Ptahhotep (advice from a father to his son), love poetry, hymns such as Akhenaten's 'Great Hymn to the Aten,' and narratives.",
    "The Story of Sinuhe (about 1900 BCE), about an official who flees Egypt and longs to return home to be buried, was a classic studied by Egyptian scribes for centuries. The Tale of the Shipwrecked Sailor is among the earliest adventure stories."]],
  ["Why these works matter",[
    "These earliest literatures already explore the great themes, friendship, death, power, love, justice, and the search for meaning, that literature still addresses.",
    "They also show that literature emerges alongside cities, kingship, religion, and schools of scribes."]]
  ],
  terms:[["Cuneiform","Wedge-shaped writing on clay tablets."],["Enheduanna","Earliest named author, a Sumerian priestess."],["Epic of Gilgamesh","Mesopotamian epic about a king seeking immortality."],["Utnapishtim","Flood survivor in Gilgamesh."],["Story of Sinuhe","Classic Egyptian tale of exile and return."]],
  w:"The first literatures show that humanity's deepest questions are as old as writing itself.",
  src:["Epic of Gilgamesh","Enheduanna","Cuneiform","Story of Sinuhe","Ancient Egyptian literature"],
  q:[
  ["Who is the earliest author known by name?","Enheduanna","Homer","Gilgamesh","Sîn-lēqi-unninni"],
  ["Where were the tablets of Gilgamesh found?","Ashurbanipal's library at Nineveh","The pyramids","Babylon's ziggurat","Jerusalem"],
  ["Who is Gilgamesh's wild companion?","Enkidu","Humbaba","Utnapishtim","Ishtar"],
  ["Who deciphered the flood tablet in 1872?","George Smith","Henry Rawlinson","Howard Carter","Jean-François Champollion"],
  ["What is the Story of Sinuhe about?","An official who flees Egypt and longs to return","A pharaoh's war","A flood","A love affair"],
  ["Around when was writing invented in Mesopotamia?","3200 BCE","1200 BCE","500 BCE","8000 BCE"]]},

{ t:"The Hebrew Bible as Literature", s:"Story, poetry, and prophecy",
  sec:[
  ["A library of books",[
    "The Hebrew Bible (called the Tanakh in Judaism and, in a different arrangement, the Old Testament in Christianity) is a collection of texts composed over many centuries, roughly from the 10th to the 2nd century BCE, edited and compiled from earlier sources. It is divided into the Torah (the five books of Moses), the Nevi'im (Prophets), and the Ketuvim (Writings).",
    "Beyond its religious significance, it is one of the most influential bodies of literature in history, shaping language, imagery, and storytelling in Western and many other cultures."]],
  ["Narrative art",[
    "Biblical narrative is famously spare: it gives few descriptions or explanations, leaving gaps that invite interpretation. Critic Erich Auerbach, in Mimesis (1946), contrasted the 'fraught with background' style of the binding of Isaac with Homer's fully illuminated scenes. Robert Alter's The Art of Biblical Narrative (1981) analyzed its techniques of repetition, type-scenes, and dialogue.",
    "Memorable stories include Creation and the Garden of Eden, Cain and Abel, Noah's flood, the Tower of Babel, Abraham and Isaac, Jacob and Esau, Joseph and his brothers, Moses and the Exodus, Ruth, David and Goliath, and David's affair with Bathsheba."]],
  ["Poetry and wisdom",[
    "Biblical Hebrew poetry is based on parallelism: a line is echoed, contrasted, or extended by the next ('The heavens declare the glory of God; and the firmament sheweth his handywork'). The Psalms, 150 songs of praise, lament, and thanksgiving traditionally associated with King David, are among the most read poems in the world; Psalm 23 ('The Lord is my shepherd') is especially famous.",
    "The Song of Songs is a sensual love poem. Wisdom literature includes Proverbs, the questioning and melancholy Ecclesiastes ('Vanity of vanities; all is vanity'), and the Book of Job, a profound poetic drama about the suffering of a righteous man that has influenced writers from Milton to Kafka."]],
  ["Prophecy",[
    "The prophets, Isaiah, Jeremiah, Ezekiel, Amos, and others, combined poetry, vision, and social criticism, denouncing injustice and idolatry and imagining a future of peace ('they shall beat their swords into plowshares'). Their language of justice influenced later movements, including the civil rights movement: Martin Luther King Jr. quoted Amos, 'let justice roll down like waters.'",
    "Apocalyptic literature, such as the Book of Daniel, uses symbolic visions of the end of history."]],
  ["Translation and influence",[
    "The Hebrew Bible was translated into Greek (the Septuagint, from the 3rd century BCE), Latin (Jerome's Vulgate, about 400 CE), and later vernacular languages. The King James Version (1611), building heavily on William Tyndale's earlier translation, deeply shaped English prose; phrases like 'the salt of the earth' and 'a drop in the bucket' come from biblical translations.",
    "The New Testament, written in Greek in the 1st century CE, adds the Gospels, letters, and the Book of Revelation, and its parables, such as the Prodigal Son and the Good Samaritan, are also landmarks of storytelling."]]
  ],
  terms:[["Tanakh","Jewish name for the Hebrew Bible."],["Torah","The five books of Moses."],["Parallelism","Echoing structure of Hebrew poetry."],["Wisdom literature","Books like Proverbs, Job, and Ecclesiastes."],["King James Version","1611 English translation."]],
  w:"The Bible's stories, poetry, and phrases run through literature, art, and language worldwide.",
  src:["Hebrew Bible","Bible as literature","Book of Job","Psalms","King James Version"],
  q:[
  ["What is the foundation of biblical Hebrew poetry?","Parallelism","Rhyme","Meter","Alliteration"],
  ["Which book is a poetic drama about a righteous man's suffering?","Job","Ruth","Proverbs","Genesis"],
  ["Which critic contrasted biblical narrative with Homer in Mimesis?","Erich Auerbach","Robert Alter","Northrop Frye","Harold Bloom"],
  ["When was the King James Version published?","1611","1526","1450","1789"],
  ["Which book says 'Vanity of vanities; all is vanity'?","Ecclesiastes","Psalms","Isaiah","Song of Songs"],
  ["What is the Septuagint?","A Greek translation of the Hebrew Bible","A Latin translation","A collection of psalms","A prophetic book"]]},

{ t:"Homer: The Iliad and the Odyssey", s:"The foundations of Western literature",
  sec:[
  ["Who was Homer?",[
    "Homer is the name traditionally given to the poet of the Iliad and the Odyssey, composed in Greek probably in the 8th or 7th century BCE. Ancient tradition pictured him as a blind bard from Ionia; little is actually known, and scholars debate whether a single poet composed both.",
    "In the 1920s–30s, American scholar Milman Parry, with Albert Lord, studied oral poets in Yugoslavia and showed that Homeric poems used formulas, repeated phrases like 'rosy-fingered Dawn' and 'swift-footed Achilles,' typical of oral composition, which helped bards improvise long poems in performance."]],
  ["The Iliad",[
    "The Iliad, about 15,700 lines in dactylic hexameter, covers a few weeks in the tenth year of the Trojan War, which began when the Trojan prince Paris abducted Helen, wife of the Greek king Menelaus. It opens: 'Sing, goddess, the wrath of Achilles.' Achilles, the greatest Greek warrior, withdraws from battle after King Agamemnon takes his prize, the captive woman Briseis.",
    "Without Achilles, the Greeks suffer. When the Trojan hero Hector kills Achilles's beloved companion Patroclus, Achilles returns in fury, kills Hector, and drags his body behind his chariot. The poem ends with a moving scene in which Hector's father, King Priam, comes secretly to Achilles's tent to beg for his son's body, and the two enemies weep together for their losses."]],
  ["Themes of the Iliad",[
    "The Iliad explores honor and glory (kleos), rage, mortality, friendship, and the horror and grandeur of war. It is unusually sympathetic to both sides; Hector's farewell to his wife Andromache and baby son is one of literature's most tender scenes.",
    "The gods take sides and intervene, yet human choices and suffering remain central. Famous stories like the Trojan Horse and the fall of Troy are not in the Iliad; they appear in the Odyssey and later works such as Virgil's Aeneid."]],
  ["The Odyssey",[
    "The Odyssey follows Odysseus, the clever king of Ithaca, on his ten-year journey home after the war. It begins with his son Telemachus searching for news, while suitors overrun the palace pressing his faithful wife Penelope to remarry. Odysseus's adventures, told in flashback, include the Cyclops Polyphemus (whom he tricks by calling himself 'Nobody'), the witch Circe, the Sirens, Scylla and Charybdis, a visit to the underworld, and years with the nymph Calypso.",
    "Returning disguised as a beggar, Odysseus is recognized by his old dog Argos and his nurse Eurycleia; he wins an archery contest with his great bow, kills the suitors, and is reunited with Penelope, who tests him with the secret of their bed built from a living olive tree."]],
  ["Legacy",[
    "Homer's epics were the foundation of Greek education and culture and have influenced literature for nearly three thousand years, from Virgil to James Joyce's Ulysses (1922), Derek Walcott's Omeros, and recent retellings such as Madeline Miller's The Song of Achilles and Circe and Pat Barker's The Silence of the Girls. 'Odyssey' has become a word for any long journey.",
    "Modern translations by Robert Fagles, Richmond Lattimore, Emily Wilson (the first published English translation of the Odyssey by a woman, 2017), and others continue to bring Homer to new readers."]]
  ],
  terms:[["Epic","Long narrative poem about heroic deeds."],["Dactylic hexameter","Six-foot meter of Greek epic."],["Kleos","Glory or fame won through great deeds."],["Oral-formulaic","Composition using repeated phrases in performance."],["Epithet","Descriptive phrase like 'swift-footed Achilles.'"]],
  w:"Homer's epics are the foundation of Western storytelling and still among the most powerful poems ever written.",
  src:["Iliad","Odyssey","Homer","Milman Parry","Homeric Question"],
  q:[
  ["How does the Iliad begin?","With the wrath of Achilles","With the Trojan Horse","With Odysseus's journey","With Helen's abduction"],
  ["Who kills Patroclus?","Hector","Paris","Achilles","Agamemnon"],
  ["What name does Odysseus give the Cyclops?","Nobody","Somebody","Ithacus","Wanderer"],
  ["Who showed that Homeric poetry used oral formulas?","Milman Parry","Heinrich Schliemann","Erich Auerbach","Robert Fagles"],
  ["How does Penelope test Odysseus?","With the secret of their bed built from an olive tree","With a riddle","With an archery contest only","With a song"],
  ["Who published the first English translation of the Odyssey by a woman in 2017?","Emily Wilson","Madeline Miller","Mary Beard","Anne Carson"]]},

{ t:"Greek Lyric Poetry and Tragedy", s:"Sappho, Aeschylus, Sophocles, Euripides",
  sec:[
  ["Lyric poets",[
    "Greek lyric poetry, sung to the lyre, expressed personal feeling. Sappho of Lesbos (about 630–570 BCE) wrote passionate love poems, many addressed to women; Plato reportedly called her 'the tenth Muse.' Most of her nine books are lost; we have one complete poem and fragments, some recovered from papyri as recently as 2014. The word 'lesbian' derives from her island.",
    "Other lyric poets include Archilochus, a soldier-poet who wrote bitterly witty verse; Alcaeus; Anacreon, who sang of wine and love; and Pindar, whose victory odes celebrated athletic winners."]],
  ["The birth of tragedy",[
    "Greek tragedy developed in Athens in the 6th century BCE from choral songs performed at festivals for Dionysus. Thespis is said to have been the first actor to step out of the chorus, giving us the word 'thespian.' Tragedies were performed at the City Dionysia in competitions, in open-air theaters before thousands of citizens.",
    "Actors (all male) wore masks; a chorus sang and danced, commenting on the action. Plays drew on myths familiar to the audience; violence typically happened offstage and was reported by messengers."]],
  ["Aeschylus",[
    "Aeschylus (about 525–456 BCE), who fought at the Battle of Marathon, added a second actor, increasing dramatic conflict. His only surviving trilogy, the Oresteia (458 BCE), traces a cycle of revenge in the house of Atreus: Agamemnon is murdered by his wife Clytemnestra; their son Orestes kills her; and the Furies pursue him until the goddess Athena establishes a court of law in Athens, replacing vengeance with justice.",
    "The Persians (472 BCE), about Athens's victory at Salamis told from the Persian side, is the oldest surviving play."]],
  ["Sophocles",[
    "Sophocles (about 497–406 BCE) added a third actor and wrote over 120 plays, of which seven survive. Oedipus Rex (Oedipus the King) is often considered the greatest Greek tragedy; Aristotle used it as his model. Oedipus, king of Thebes, investigates a plague's cause and discovers that he himself unknowingly killed his father and married his mother, fulfilling a prophecy he tried to escape. He blinds himself.",
    "In Antigone, Oedipus's daughter defies King Creon's decree by burying her brother, choosing divine law and family duty over the state's law, a conflict that has inspired debates about conscience and authority ever since."]],
  ["Euripides",[
    "Euripides (about 480–406 BCE), the most 'modern' of the three, questioned traditional values, portrayed gods critically, and gave voice to women, slaves, and outsiders. In Medea, a foreign woman abandoned by Jason takes horrifying revenge by killing their children. The Trojan Women depicts the suffering of women after Troy's fall, a powerful anti-war play. The Bacchae shows the god Dionysus destroying King Pentheus, who resists his worship.",
    "Of some 90 plays, 18 or 19 survive, more than Aeschylus and Sophocles combined, because he became popular in later centuries."]],
  ["Legacy",[
    "Greek tragedy's exploration of fate, justice, family, pride, and suffering shaped Western drama, from Seneca and Shakespeare to Racine, Eugene O'Neill, and modern adaptations worldwide. Freud named the 'Oedipus complex' after Sophocles's play.",
    "Aristotle's analysis of these plays in the Poetics shaped dramatic theory for over two thousand years."]]
  ],
  terms:[["Lyric","Poetry sung to the lyre, expressing personal feeling."],["Chorus","Group commenting on the action in Greek drama."],["City Dionysia","Athenian festival where tragedies competed."],["Oresteia","Aeschylus's trilogy about the house of Atreus."],["Thespian","Actor, from Thespis."]],
  w:"Greek lyric and tragedy created forms and questions that literature still explores.",
  src:["Sappho","Greek tragedy","Oresteia","Oedipus Rex","Euripides"],
  q:[
  ["Who was called 'the tenth Muse'?","Sappho","Pindar","Euripides","Homer"],
  ["What is the only surviving Greek tragic trilogy?","The Oresteia","The Theban Plays","The Trojan Women","The Persians"],
  ["Which play shows a daughter defying a king to bury her brother?","Antigone","Medea","Electra","The Bacchae"],
  ["Who wrote Medea?","Euripides","Sophocles","Aeschylus","Aristophanes"],
  ["Who added a third actor to tragedy?","Sophocles","Aeschylus","Thespis","Euripides"],
  ["At which festival were Athenian tragedies performed?","City Dionysia","Panathenaea","Olympic Games","Eleusinian Mysteries"]]}

]});


/* ---- from lit-04.js ---- */
/* LITERATURE FOUNDATIONS, part 4: Unit 2 chapters 5-9 */
COURSES.literature.units[1].ch.push(

{ t:"Greek Comedy and Prose", s:"Aristophanes, historians, and philosophers",
  sec:[
  ["Aristophanes and Old Comedy",[
    "Aristophanes (about 446–386 BCE) is the master of Athenian Old Comedy, a riotous mix of political satire, fantasy, obscenity, and lyrical choral song. His plays mocked politicians, generals, philosophers, and poets by name. In The Clouds (423 BCE), he caricatured Socrates as a fraudulent teacher, a portrayal Plato later suggested contributed to prejudice against him.",
    "In Lysistrata (411 BCE), the women of Greece go on a sex strike to force their men to end the Peloponnesian War; The Birds imagines a city in the sky ('Cloudcuckooland'); and The Frogs stages a contest in the underworld between Aeschylus and Euripides, an early work of literary criticism."]],
  ["New Comedy",[
    "After Athens's decline, New Comedy turned to domestic plots: young lovers, stern fathers, clever slaves, mistaken identities, and happy endings. Menander (about 342–290 BCE) was its master; only one complete play, Dyskolos (The Grouch), survives, rediscovered on papyrus in the 1950s.",
    "New Comedy, through Roman adaptations by Plautus and Terence, became the ancestor of European comedy, from Shakespeare's The Comedy of Errors to modern sitcoms."]],
  ["History as literature",[
    "Herodotus (about 484–425 BCE), called 'the Father of History' by Cicero, wrote the Histories about the Persian Wars, filled with vivid stories, customs of foreign peoples, and digressions; his aim was to preserve great deeds from oblivion. Critics also called him 'the Father of Lies' for including fabulous tales.",
    "Thucydides (about 460–400 BCE) wrote the History of the Peloponnesian War with rigorous analysis of power and politics. Its speeches, including Pericles's Funeral Oration praising Athenian democracy, and the Melian Dialogue ('the strong do what they can and the weak suffer what they must') remain central to political thought."]],
  ["Philosophy as literature",[
    "Plato (about 428–348 BCE) wrote philosophy as dramatic dialogues starring his teacher Socrates. The Apology portrays Socrates's defense at his trial; the Symposium presents speeches about love at a drinking party; and the Republic includes the famous Allegory of the Cave. Plato's literary artistry, myths, characters, irony, made philosophy a literary form.",
    "Aristotle's Poetics and Rhetoric became foundational texts of literary theory and persuasive speech."]],
  ["Hellenistic literature",[
    "After Alexander the Great, Greek culture spread across the Mediterranean and Near East. In Alexandria, scholars at the great Library edited Homer, and poets such as Callimachus valued short, polished poems. Theocritus invented pastoral poetry, idealized songs of shepherds, which influenced Virgil and centuries of European verse.",
    "Apollonius of Rhodes wrote the Argonautica about Jason and the Golden Fleece, and Greek novels such as Longus's Daphnis and Chloe (romantic adventures) emerged in the Roman period."]]
  ],
  terms:[["Old Comedy","Athenian political satire, especially Aristophanes."],["New Comedy","Domestic comedy of Menander."],["Funeral Oration","Pericles's speech praising Athens."],["Dialogue","Philosophical conversation form used by Plato."],["Pastoral","Poetry idealizing rural shepherd life."]],
  w:"Greek comedy, history, and philosophy created literary forms still used today, from satire to political analysis.",
  src:["Aristophanes","Menander","Herodotus","Thucydides","Theocritus"],
  q:[
  ["Which Aristophanes play features a sex strike to end war?","Lysistrata","The Clouds","The Birds","The Frogs"],
  ["Who is called 'the Father of History'?","Herodotus","Thucydides","Xenophon","Plutarch"],
  ["Which Thucydides passage says 'the strong do what they can'?","The Melian Dialogue","The Funeral Oration","The Plague","The Sicilian Expedition"],
  ["Who mocked Socrates in The Clouds?","Aristophanes","Menander","Euripides","Plato"],
  ["Who invented pastoral poetry?","Theocritus","Callimachus","Sappho","Pindar"],
  ["Which is a Plato dialogue about love?","Symposium","Republic","Apology","Phaedo"]]},

{ t:"Virgil and the Roman Epic", s:"The Aeneid and Augustan Rome",
  sec:[
  ["Roman literature begins",[
    "Roman literature developed from the 3rd century BCE under strong Greek influence. Early writers adapted Greek drama and epic; Plautus and Terence wrote lively comedies based on Greek New Comedy. Lucretius's On the Nature of Things (1st century BCE) set Epicurean philosophy, including atomic theory, in magnificent verse.",
    "Cicero (106–43 BCE), statesman and orator, shaped Latin prose style through his speeches, letters, and philosophical works; his eloquent style became the model for European prose for centuries."]],
  ["Virgil's life and early works",[
    "Publius Vergilius Maro, known as Virgil (70–19 BCE), was born near Mantua and became the leading poet of the Augustan age under Rome's first emperor, Augustus. His Eclogues adapted Theocritus's pastoral poetry; the Fourth Eclogue's prophecy of a child bringing a golden age was later read by Christians as foretelling Christ.",
    "The Georgics, a poem about farming, celebrated agricultural labor and the Italian land."]],
  ["The Aeneid",[
    "The Aeneid, Rome's national epic in twelve books, tells of Aeneas, a Trojan prince who escapes burning Troy carrying his father Anchises and leading his son, and journeys to Italy to found the Roman people. The first six books echo the Odyssey (wanderings), the last six the Iliad (war in Italy). It opens: 'Arms and the man I sing.'",
    "In Carthage, Queen Dido falls in love with Aeneas; when the gods command him to leave, she curses him and kills herself, explaining the later enmity between Rome and Carthage. In Book 6, Aeneas visits the underworld, where his father shows him the future heroes of Rome. The epic ends abruptly with Aeneas killing his enemy Turnus in rage."]],
  ["Duty and its cost",[
    "Aeneas's defining quality is pietas, duty to the gods, family, and country, which requires sacrificing personal desires. Readers have long debated whether the Aeneid celebrates Augustus's empire or mourns its costs; the famous phrase 'lacrimae rerum' ('the tears of things') captures its sense of sorrow.",
    "Virgil died before finishing revisions and asked that the poem be burned; Augustus ordered it published."]],
  ["Influence",[
    "The Aeneid became the central text of Latin education for nearly two thousand years. Dante chose Virgil as his guide through Hell and Purgatory in the Divine Comedy, and poets from Milton to modern writers drew on him. Henry Purcell's opera Dido and Aeneas retold its most famous episode.",
    "Phrases such as 'I fear Greeks even bearing gifts' (about the Trojan Horse) entered proverbial use."]]
  ],
  terms:[["Aeneid","Virgil's Roman national epic."],["Pietas","Roman virtue of duty to gods, family, and country."],["Augustan age","Literary golden age under Augustus."],["Georgics","Virgil's poem on farming."],["Lacrimae rerum","'The tears of things.'"]],
  w:"Virgil's Aeneid shaped European ideas of duty, empire, and epic poetry for two thousand years.",
  src:["Aeneid","Virgil","Lucretius","Cicero","Dido"],
  q:[
  ["Who is the hero of the Aeneid?","Aeneas","Achilles","Odysseus","Romulus"],
  ["Which queen kills herself after Aeneas leaves?","Dido","Cleopatra","Helen","Penelope"],
  ["What is pietas?","Duty to gods, family, and country","Pity","Courage in battle","Love"],
  ["Which poet chose Virgil as his guide in the Divine Comedy?","Dante","Petrarch","Chaucer","Milton"],
  ["Who wrote On the Nature of Things?","Lucretius","Ovid","Horace","Seneca"],
  ["How does the Aeneid open?","Arms and the man I sing","Sing, goddess, the wrath","In the beginning","Tell me, Muse, of the man"]]},

{ t:"Ovid, Horace, Catullus, and Latin Prose", s:"Love, wit, and transformation",
  sec:[
  ["Catullus",[
    "Gaius Valerius Catullus (about 84–54 BCE) wrote intensely personal poems, many about his passionate, tormented love for a woman he called Lesbia (probably the aristocrat Clodia). His two-line poem 'Odi et amo' ('I hate and I love... I am tortured') is one of the most famous in Latin.",
    "His witty, sometimes obscene epigrams and elegant longer poems influenced love poetry for centuries."]],
  ["Horace",[
    "Horace (65–8 BCE), friend of Virgil and supported by the patron Maecenas, wrote Odes, Satires, and Epistles. His Odes, perfect in form, celebrate friendship, wine, the countryside, and moderation; they gave us 'carpe diem' ('seize the day') and 'dulce et decorum est pro patria mori' ('it is sweet and fitting to die for one's country'), later bitterly quoted by Wilfred Owen in World War I.",
    "His Ars Poetica gave advice on writing that shaped literary theory for centuries."]],
  ["Ovid",[
    "Ovid (43 BCE–17/18 CE) was the wittiest Roman poet. His Amores and Ars Amatoria (Art of Love) playfully instructed readers on seduction. His masterpiece, the Metamorphoses, in fifteen books, weaves some 250 myths of transformation from the creation of the world to Julius Caesar's deification: Daphne becomes a laurel tree fleeing Apollo, Narcissus falls in love with his reflection, Pygmalion's statue comes to life, and Pyramus and Thisbe die for love.",
    "In 8 CE Augustus exiled Ovid to Tomis on the Black Sea for reasons he described only as 'a poem and a mistake'; he wrote mournful poems from exile. The Metamorphoses became a storehouse of myths for Shakespeare, painters, and writers through the centuries."]],
  ["Satire and the novel",[
    "Satire, which Romans claimed as their own invention, mocked vice and folly. Juvenal (around 100 CE) wrote fierce satires on Roman corruption, coining 'bread and circuses' and asking 'who will guard the guards themselves?'",
    "Two Roman novels survive: Petronius's Satyricon, a comic picaresque about rogues including the famous feast of the vulgar millionaire Trimalchio; and Apuleius's The Golden Ass (2nd century CE), in which a man turned into a donkey has adventures, including the beautiful tale of Cupid and Psyche."]],
  ["Prose masters",[
    "Julius Caesar's Commentaries on the Gallic War are models of clear prose. Historians Livy (the history of Rome from its founding) and Tacitus (sharp, ironic accounts of the early emperors) shaped how later ages saw Rome. Seneca wrote philosophical letters on Stoicism and violent tragedies that influenced Elizabethan revenge drama.",
    "Marcus Aurelius's Meditations, written in Greek by an emperor, and Plutarch's Parallel Lives, comparing Greek and Roman figures (a key source for Shakespeare), round out the classical inheritance."]]
  ],
  terms:[["Carpe diem","'Seize the day,' from Horace."],["Metamorphoses","Ovid's epic of transformations."],["Satire","Mocking of vice and folly."],["Epigram","Short, witty poem."],["Stoicism","Philosophy of virtue and acceptance, voiced by Seneca."]],
  w:"Latin poets and prose writers gave Europe its love poetry, myths, satire, and models of style.",
  src:["Ovid","Metamorphoses","Horace","Catullus","Juvenal"],
  q:[
  ["Which poet wrote 'Odi et amo'?","Catullus","Horace","Ovid","Virgil"],
  ["Which Roman poet coined 'carpe diem'?","Horace","Catullus","Juvenal","Lucretius"],
  ["Which work weaves myths of transformation?","Metamorphoses","Aeneid","Satyricon","Georgics"],
  ["Where was Ovid exiled?","Tomis on the Black Sea","Athens","Carthage","Britain"],
  ["Who coined 'bread and circuses'?","Juvenal","Martial","Seneca","Tacitus"],
  ["Which Roman novel features a man turned into a donkey?","The Golden Ass","Satyricon","Metamorphoses","Daphnis and Chloe"]]},

{ t:"Ancient India", s:"Vedas, epics, and Sanskrit poetry",
  sec:[
  ["The Vedas and Upanishads",[
    "The Vedas, composed in Sanskrit from roughly 1500 BCE, are among the oldest religious texts still in use. The Rig Veda contains over a thousand hymns to gods such as Agni (fire) and Indra; its 'Hymn of Creation' asks with striking skepticism whether even the highest god knows how the world began. The Vedas were transmitted orally with extraordinary precision for centuries before being written down.",
    "The Upanishads (from about 800 BCE) are philosophical dialogues exploring the nature of reality, the self (atman), and ultimate reality (brahman), teaching that they are one."]],
  ["The Mahabharata",[
    "The Mahabharata, traditionally attributed to the sage Vyasa, is the longest epic poem in the world, about 100,000 couplets in its longest versions, several times longer than the Iliad and Odyssey combined. It tells of the rivalry between two branches of a royal family, the five Pandava brothers and their cousins the Kauravas, culminating in the catastrophic war at Kurukshetra.",
    "It contains countless stories, discussions of dharma (duty, righteousness), and the Bhagavad Gita, a dialogue in which the god Krishna counsels the warrior Arjuna, reluctant to fight his kinsmen, about duty, action without attachment to results, and devotion. The Gita inspired Mahatma Gandhi, Henry David Thoreau, and J. Robert Oppenheimer, who recalled its line 'Now I am become Death, the destroyer of worlds' after the first atomic test."]],
  ["The Ramayana",[
    "The Ramayana, attributed to the poet Valmiki, tells of Prince Rama, exiled from his kingdom, whose wife Sita is abducted by the demon king Ravana of Lanka. With his brother Lakshmana and the monkey god Hanuman, Rama rescues Sita. Rama and Sita are models of virtue in Hindu tradition.",
    "The Ramayana spread across South and Southeast Asia, retold in Tamil (Kamban), Hindi (Tulsidas's 16th-century Ramcharitmanas), Thai (the Ramakien), and Indonesian versions, and is performed in dance, puppetry, and the annual Ramlila dramas."]],
  ["Classical Sanskrit literature",[
    "Kalidasa (probably 4th–5th century CE), the greatest classical Sanskrit poet and dramatist, wrote the play Shakuntala, about a king who marries a forest maiden, forgets her through a curse, and later recognizes her. When it was translated in the 18th century, Goethe praised it rapturously. His poem Meghaduta (The Cloud Messenger) has an exiled lover send a message to his wife via a cloud.",
    "The Panchatantra, animal fables teaching practical wisdom, traveled across the world through Persian and Arabic translations and influenced collections like Aesop's and La Fontaine's fables."]],
  ["Tamil and Buddhist literature",[
    "Tamil Sangam poetry (roughly 300 BCE–300 CE) is a separate classical tradition, divided into akam (love, interior) and puram (war, public) poems. The Tirukkural, a collection of 1,330 couplets on ethics, is revered in Tamil culture.",
    "Buddhist literature includes the Jataka tales of the Buddha's previous lives and the Dhammapada, a collection of verses on the path to enlightenment."]]
  ],
  terms:[["Vedas","Ancient Sanskrit hymns."],["Upanishads","Philosophical texts on atman and brahman."],["Mahabharata","Longest epic, about the Kurukshetra war."],["Bhagavad Gita","Krishna's counsel to Arjuna."],["Dharma","Duty, righteousness, cosmic order."]],
  w:"India's ancient literature, from the Vedas to the great epics, remains living scripture and story for over a billion people.",
  src:["Mahabharata","Ramayana","Bhagavad Gita","Kalidasa","Panchatantra"],
  q:[
  ["Which is the longest epic poem in the world?","Mahabharata","Ramayana","Iliad","Shahnameh"],
  ["In the Bhagavad Gita, who counsels Arjuna?","Krishna","Rama","Vyasa","Hanuman"],
  ["Who abducts Sita in the Ramayana?","Ravana","Hanuman","Lakshmana","Duryodhana"],
  ["Who wrote Shakuntala?","Kalidasa","Valmiki","Vyasa","Tulsidas"],
  ["Which fable collection traveled from India across the world?","Panchatantra","Jataka","Dhammapada","Tirukkural"],
  ["Which scientist recalled a Gita line after the first atomic test?","J. Robert Oppenheimer","Albert Einstein","Enrico Fermi","Niels Bohr"]]},

{ t:"Ancient China", s:"Odes, sages, and historians",
  sec:[
  ["The Classic of Poetry",[
    "The Shijing (Classic of Poetry or Book of Songs), compiled between about 1000 and 600 BCE, is China's oldest poetry collection, with 305 poems: folk songs about love, work, and war, courtly odes, and ritual hymns. Tradition holds that Confucius selected them. They use repetition, natural imagery, and simple four-character lines.",
    "Knowledge of the Shijing was essential to Chinese education and diplomacy for millennia; officials quoted it to make subtle points."]],
  ["Confucius and the classics",[
    "Confucius (551–479 BCE) emphasized moral cultivation, filial piety, ritual, and good government. His sayings, recorded by disciples in the Analects, are concise and memorable ('Is it not a pleasure to learn and practice what you have learned?'). Mencius developed his thought, arguing human nature is good.",
    "The Five Classics and Four Books became the basis of Chinese education and the imperial civil service examinations for some two thousand years, shaping East Asian culture."]],
  ["Daoist literature",[
    "The Daodejing, attributed to Laozi, is a short, poetic text about the Dao ('the Way'), opening: 'The Dao that can be spoken is not the eternal Dao.' It praises softness, simplicity, and effortless action (wu wei). It is among the most translated books in the world.",
    "The Zhuangzi, attributed to Zhuangzi (4th century BCE), uses playful stories, paradoxes, and humor; in the most famous, Zhuangzi dreams he is a butterfly and wakes unsure whether he is a man who dreamed of being a butterfly or a butterfly dreaming he is a man."]],
  ["The Songs of Chu and early poetry",[
    "The Chuci (Songs of Chu), associated with the poet Qu Yuan (about 340–278 BCE), are more emotional and shamanistic than the Shijing. In 'Li Sao' ('Encountering Sorrow'), a loyal minister rejected by his king takes a fantastic spiritual journey. According to legend, Qu Yuan drowned himself in despair, and the Dragon Boat Festival commemorates him.",
    "Han dynasty rhapsodies (fu) and folk ballads (yuefu) developed further poetic forms."]],
  ["Sima Qian",[
    "Sima Qian (about 145–86 BCE) wrote the Records of the Grand Historian (Shiji), a history of China from legendary times to his own day, combining annals, biographies, and essays. He completed it after suffering castration as punishment for defending a disgraced general, choosing to live in shame to finish his work. Its vivid biographies of emperors, rebels, assassins, and merchants made it a literary masterpiece and the model for later official histories.",
    "Together, these works laid foundations for a literary tradition of unbroken continuity spanning three thousand years."]]
  ],
  terms:[["Shijing","Classic of Poetry, China's oldest anthology."],["Analects","Sayings of Confucius."],["Daodejing","Laozi's text on the Way."],["Wu wei","Effortless, non-forcing action."],["Shiji","Sima Qian's Records of the Grand Historian."]],
  w:"Ancient Chinese texts created a literary and philosophical tradition that shaped East Asia for millennia.",
  src:["Classic of Poetry","Analects","Tao Te Ching","Zhuangzi (book)","Sima Qian"],
  q:[
  ["What is China's oldest poetry anthology?","Shijing (Classic of Poetry)","Chuci","Analects","Daodejing"],
  ["Who dreamed he was a butterfly?","Zhuangzi","Confucius","Laozi","Mencius"],
  ["Which festival commemorates Qu Yuan?","Dragon Boat Festival","Spring Festival","Lantern Festival","Mid-Autumn Festival"],
  ["Who wrote the Records of the Grand Historian?","Sima Qian","Confucius","Ban Gu","Sun Tzu"],
  ["What does 'Dao' mean?","The Way","Virtue","Heaven","Ritual"],
  ["Which collection records the sayings of Confucius?","Analects","Mencius","Shijing","Book of Rites"]]}

);


/* ---- from lit-05.js ---- */
/* LITERATURE FOUNDATIONS, part 5: Unit 3 The Medieval World, chapters 1-4 */
COURSES.literature.units.push({ t:"The Medieval World", ch:[

{ t:"Late Antiquity: Augustine and Boethius", s:"Faith, philosophy, and the self",
  sec:[
  ["A world in transition",[
    "Between about 300 and 600 CE, the Roman Empire became Christian and its western half collapsed. Literature in this period blended classical learning with Christian faith. Writers adapted Greek and Roman forms, rhetoric, dialogue, poetry, to new spiritual concerns, and monasteries began preserving and copying ancient texts.",
    "Jerome's Latin translation of the Bible, the Vulgate, completed around 405, became the standard Bible of Western Christianity for over a thousand years."]],
  ["Augustine's Confessions",[
    "Augustine of Hippo (354–430), born in North Africa, wrote the Confessions (about 397–400), often called the first Western autobiography. Addressed to God as a long prayer, it traces his restless youth, his stealing of pears from a neighbor's tree for the sheer pleasure of wrongdoing, his career as a teacher of rhetoric, his relationships, and his conversion in a Milan garden after hearing a child's voice chanting 'take up and read.'",
    "Its introspection and famous line 'our heart is restless until it rests in you' made it a model for later self-examination, from Petrarch to Rousseau. Augustine's The City of God, written after the sack of Rome in 410, contrasted the earthly and heavenly cities and shaped medieval political thought."]],
  ["Boethius's Consolation",[
    "Boethius (about 477–524), a Roman statesman serving the Ostrogothic king Theodoric in Italy, was imprisoned on charges of treason and executed. Awaiting death, he wrote The Consolation of Philosophy, a dialogue in alternating prose and verse in which Lady Philosophy visits him in prison and teaches that true happiness lies in virtue and God, not in fortune.",
    "Its image of the 'Wheel of Fortune,' which raises people up and casts them down, became one of the most common images in medieval art and literature. The Consolation was among the most widely read books of the Middle Ages; King Alfred the Great, Geoffrey Chaucer, and Queen Elizabeth I all translated it."]],
  ["Preserving the classics",[
    "Monks in Ireland, Britain, and continental monasteries copied manuscripts, preserving many classical texts. Illuminated manuscripts such as the Book of Kells (around 800) became masterpieces of art. Without this copying, much of ancient Latin literature would have been lost.",
    "Meanwhile, the Byzantine Empire preserved Greek literature, and Arabic scholars translated Greek philosophy and science, which later returned to Western Europe."]],
  ["Hymns and saints' lives",[
    "Early Christian poets wrote hymns, such as those of Ambrose of Milan and Prudentius, and saints' lives (hagiography), which were among the most popular medieval genres, mixing biography, miracle stories, and moral example.",
    "These forms carried storytelling and poetry through the early Middle Ages until new vernacular literatures emerged."]]
  ],
  terms:[["Confessions","Augustine's spiritual autobiography."],["Consolation of Philosophy","Boethius's prison dialogue."],["Wheel of Fortune","Image of fortune's rise and fall."],["Vulgate","Jerome's Latin Bible."],["Hagiography","Writing about saints' lives."]],
  w:"Augustine and Boethius bridged classical and Christian worlds and shaped medieval thought and literature.",
  src:["Confessions (Augustine)","The Consolation of Philosophy","Augustine of Hippo","Boethius","Vulgate"],
  q:[
  ["Which work is often called the first Western autobiography?","Augustine's Confessions","The Consolation of Philosophy","The City of God","Meditations"],
  ["Who visits Boethius in prison in his Consolation?","Lady Philosophy","An angel","Augustine","Fortune"],
  ["Which image did Boethius make famous?","The Wheel of Fortune","The Cave","The Ladder of Love","The Ship of Fools"],
  ["What prompted Augustine's conversion in the garden?","A child's voice chanting 'take up and read'","A vision of light","A sermon","A dream"],
  ["Who translated the Bible into Latin as the Vulgate?","Jerome","Augustine","Ambrose","Boethius"],
  ["Which English king translated Boethius?","Alfred the Great","William the Conqueror","Henry VIII","Edward I"]]},

{ t:"Beowulf and Old English Literature", s:"Heroes, monsters, and the mead-hall",
  sec:[
  ["Old English",[
    "Old English (Anglo-Saxon) was the language of England from about 450 to 1100, brought by Germanic settlers; it looks like a foreign language to modern readers ('Hwæt! We Gardena in geardagum...'). Old English poetry used alliterative verse: each line has four stresses split by a caesura, with alliteration linking the halves. It used kennings, compound metaphors such as 'whale-road' for the sea and 'bone-house' for the body.",
    "Most Old English poetry survives in just four manuscripts; much was lost."]],
  ["Beowulf: the story",[
    "Beowulf, about 3,200 lines, is the greatest Old English poem, composed sometime between the 8th and early 11th centuries and surviving in a single manuscript damaged in a 1731 library fire. Set in Scandinavia, it tells how the Geatish hero Beowulf comes to help the Danish king Hrothgar, whose great hall Heorot is terrorized by the monster Grendel. Beowulf tears off Grendel's arm in a wrestling match, then kills Grendel's vengeful mother in her underwater lair.",
    "Fifty years later, as king of the Geats, Beowulf fights a dragon awakened when a thief steals from its treasure hoard. With the help of his loyal young kinsman Wiglaf, he kills the dragon but is mortally wounded; the poem ends with his funeral pyre and a sense of the coming end of his people."]],
  ["Themes",[
    "Beowulf explores heroism, loyalty between lord and warriors (the comitatus), the obligations of gift-giving, fame after death, feuds and vengeance, and the transience of glory. It combines pagan heroic values with Christian reflections added by its poet.",
    "In his 1936 lecture 'Beowulf: The Monsters and the Critics,' J. R. R. Tolkien argued that the monsters were central to the poem's meaning, not a distraction, transforming its study; the poem deeply influenced his own fiction. Seamus Heaney's 1999 translation became a bestseller."]],
  ["Other Old English poems",[
    "Caedmon's Hymn, a short poem of praise reportedly composed by an illiterate cowherd at Whitby Abbey who received the gift of song in a dream, is the earliest recorded English poem (7th century), preserved by the historian Bede. Elegies such as The Wanderer and The Seafarer express exile and the passing of all earthly things ('Where has the horse gone? Where the rider?').",
    "The Dream of the Rood portrays the cross of Christ speaking as a loyal warrior; The Battle of Maldon recounts a heroic defeat against Vikings in 991. Riddles in the Exeter Book are playful and sometimes bawdy."]],
  ["Prose and Bede",[
    "The Venerable Bede's Ecclesiastical History of the English People (731), written in Latin, is a foundational work of English history and includes the memorable image of human life as a sparrow flying briefly through a warm hall in winter.",
    "King Alfred promoted translations into English and began the Anglo-Saxon Chronicle. After the Norman Conquest of 1066, French became the language of the elite, and English changed into Middle English."]]
  ],
  terms:[["Alliterative verse","Old English meter linked by alliteration."],["Kenning","Compound metaphor like 'whale-road.'"],["Comitatus","Bond between lord and warriors."],["Heorot","Hrothgar's great hall in Beowulf."],["Elegy","Mournful poem of loss."]],
  w:"Beowulf and Old English poetry are the roots of English literature and still powerful stories of heroism and loss.",
  src:["Beowulf","Old English literature","Kenning","Cædmon's Hymn","The Seafarer (poem)"],
  q:[
  ["What monster attacks Hrothgar's hall?","Grendel","The dragon","Fafnir","Humbaba"],
  ["What is a kenning?","A compound metaphor like 'whale-road'","A rhyme scheme","A type of hero","An Old English letter"],
  ["Who helps Beowulf against the dragon?","Wiglaf","Hrothgar","Unferth","Hygelac"],
  ["Who gave the 1936 lecture 'The Monsters and the Critics'?","J. R. R. Tolkien","C. S. Lewis","Seamus Heaney","Bede"],
  ["What is the earliest recorded English poem?","Caedmon's Hymn","Beowulf","The Seafarer","The Wanderer"],
  ["Who wrote the Ecclesiastical History of the English People?","Bede","Alfred the Great","Caedmon","Alcuin"]]},

{ t:"Norse and Celtic Literature", s:"Sagas, Eddas, and Irish heroes",
  sec:[
  ["The Eddas",[
    "Norse mythology is preserved mainly in Icelandic texts of the 13th century. The Poetic Edda is a collection of anonymous poems about gods and heroes; the Völuspá ('Prophecy of the Seeress') describes the creation of the world and its destruction at Ragnarök. The Hávamál offers the wisdom of Odin ('Cattle die, kinsmen die... but fame never dies for one who has earned it').",
    "The Prose Edda, written by the Icelandic chieftain and scholar Snorri Sturluson (1179–1241), retells the myths of Odin, Thor, Loki, and Baldr and explains skaldic poetry for aspiring poets. These stories inspired Wagner, Tolkien, and modern films and comics."]],
  ["The Icelandic sagas",[
    "The sagas of Icelanders (13th–14th centuries) are prose narratives about Icelandic families in the 9th–11th centuries. Written in a terse, understated, realistic style, they depict feuds, law, honor, and fate with remarkable psychological depth, and are often seen as forerunners of the modern novel.",
    "Njál's Saga tells of a wise lawyer whose attempts at peace end with him burned in his house with his family; Egil's Saga follows a violent warrior-poet; and the Vinland sagas describe voyages to North America around 1000, confirmed by archaeology at L'Anse aux Meadows in Newfoundland."]],
  ["Skaldic poetry",[
    "Skalds were court poets of Norway and Iceland who composed intricate verse praising kings, using complex meters and kennings. Their poems, such as those attributed to Egil Skallagrímsson, were difficult and highly prized.",
    "Iceland's literacy and saga tradition remain a source of national pride; Icelanders can still read the medieval texts with relative ease."]],
  ["Irish literature",[
    "Ireland has the oldest vernacular literature in Western Europe after Greek and Latin. The Ulster Cycle includes the Táin Bó Cúailnge (The Cattle Raid of Cooley), in which Queen Medb of Connacht invades Ulster to seize a prize bull, opposed single-handedly by the young hero Cú Chulainn.",
    "The Fenian Cycle tells of Fionn mac Cumhaill and his warrior band; the Voyage of Saint Brendan and other 'immram' voyage tales describe journeys to marvelous islands. Early Irish lyric poetry includes delicate nature poems written in manuscript margins by monks."]],
  ["Welsh literature",[
    "The Mabinogion, a collection of medieval Welsh prose tales preserved in 14th-century manuscripts, includes the Four Branches of the Mabinogi, full of magic and transformation, and some of the earliest Arthurian stories, such as Culhwch and Olwen.",
    "The Welsh poets Aneirin (Y Gododdin, a lament for warriors) and Taliesin are among the earliest named British poets, and the bardic tradition continues in the Eisteddfod festival."]]
  ],
  terms:[["Poetic Edda","Collection of Old Norse mythological poems."],["Ragnarök","Norse end of the world."],["Saga","Icelandic prose narrative."],["Táin Bó Cúailnge","Irish epic of Cú Chulainn."],["Mabinogion","Medieval Welsh tales."]],
  w:"Norse and Celtic literatures preserve myths and heroic stories that still inspire fantasy and national cultures.",
  src:["Poetic Edda","Prose Edda","Sagas of Icelanders","Táin Bó Cúailnge","Mabinogion"],
  q:[
  ["Who wrote the Prose Edda?","Snorri Sturluson","Egil Skallagrímsson","Njál","Leif Erikson"],
  ["What is Ragnarök?","The Norse end of the world","Thor's hammer","A saga hero","A Viking ship"],
  ["Which saga ends with the hero burned in his house?","Njál's Saga","Egil's Saga","Grettir's Saga","Laxdæla Saga"],
  ["Who defends Ulster in the Táin?","Cú Chulainn","Fionn mac Cumhaill","Medb","Brendan"],
  ["Which Welsh collection includes early Arthurian tales?","Mabinogion","Táin","Eddas","Annals of Ulster"],
  ["Where in North America did archaeology confirm Norse voyages?","L'Anse aux Meadows","Plymouth Rock","Jamestown","Greenland's east coast"]]},

{ t:"Epic and Romance: Roland, Arthur, and the Nibelungs", s:"Knights, quests, and courtly love",
  sec:[
  ["Chansons de geste",[
    "In France, epic 'songs of deeds' (chansons de geste) celebrated warriors of Charlemagne's era. The Song of Roland (about 1100), the oldest major French literary work, transforms a minor 778 defeat at Roncevaux Pass into a heroic tragedy: Roland, Charlemagne's nephew, betrayed by his stepfather Ganelon, refuses to blow his horn for help until too late, dying heroically against overwhelming Saracen forces.",
    "Spain's Poem of the Cid (Cantar de mio Cid) celebrates the Castilian warrior Rodrigo Díaz de Vivar, El Cid, with notable realism."]],
  ["Courtly love and troubadours",[
    "In 12th-century southern France, troubadours composed lyric poems in Occitan celebrating fin'amor ('refined love'), a noble knight's devotion to an often unattainable, married lady. The term 'courtly love' was coined later, in 1883, by Gaston Paris. These ideals spread to northern France, Germany (Minnesänger), and Italy.",
    "Eleanor of Aquitaine and her daughter Marie de Champagne were influential patrons of this literature."]],
  ["Arthurian romance",[
    "Romance was a new narrative genre about knights, quests, love, and marvels. Geoffrey of Monmouth's History of the Kings of Britain (about 1136) popularized King Arthur. Chrétien de Troyes (late 12th century) wrote romances introducing Lancelot's love for Queen Guinevere and the Grail in Perceval. Wolfram von Eschenbach's Parzival and Gottfried von Strassburg's Tristan extended the tradition in German.",
    "Marie de France, the earliest known French woman poet, wrote lais, short romances, in the late 12th century."]],
  ["Gawain and Malory",[
    "Sir Gawain and the Green Knight (late 14th century), by an anonymous English poet, tells of a giant green knight who challenges Arthur's court to a beheading game; Gawain accepts, and a year later must seek the knight to receive the return blow, facing tests of courage, courtesy, and chastity along the way. It is admired for its intricate structure and moral subtlety.",
    "Sir Thomas Malory's Le Morte d'Arthur (printed by William Caxton in 1485) compiled Arthurian stories into one English prose narrative, from Arthur's drawing of the sword from the stone to the Round Table's destruction through Lancelot and Guinevere's love and Mordred's treachery. It became the main source for later retellings, from Tennyson's Idylls of the King to T. H. White's The Once and Future King."]],
  ["The Nibelungenlied",[
    "The German Nibelungenlied (about 1200) tells of Siegfried, the dragon-slayer, his marriage to Kriemhild, his murder by Hagen, and Kriemhild's devastating revenge that destroys the Burgundians. Related Norse versions tell of Sigurd and Brynhild. Wagner drew on both for his Ring cycle.",
    "These medieval epics and romances created enduring archetypes: the loyal knight, the quest, the forbidden love, and the fall of a fellowship."]]
  ],
  terms:[["Chanson de geste","Old French heroic epic."],["Courtly love","Ideal of a knight's devotion to a lady."],["Romance","Medieval tale of knights, love, and marvels."],["Grail","Sacred object of Arthurian quest."],["Lai","Short narrative poem, as by Marie de France."]],
  w:"Medieval epic and romance invented the knightly quest and courtly love, still central to storytelling.",
  src:["The Song of Roland","Courtly love","Sir Gawain and the Green Knight","Le Morte d'Arthur","Nibelungenlied"],
  q:[
  ["Who betrays Roland in the Song of Roland?","Ganelon","Oliver","Charlemagne","Turpin"],
  ["Who introduced Lancelot's love for Guinevere?","Chrétien de Troyes","Thomas Malory","Geoffrey of Monmouth","Marie de France"],
  ["What game does the Green Knight propose?","A beheading game","A jousting match","A riddle contest","A chess game"],
  ["Who printed Le Morte d'Arthur in 1485?","William Caxton","Johannes Gutenberg","Wynkyn de Worde","Aldus Manutius"],
  ["Who kills Siegfried in the Nibelungenlied?","Hagen","Kriemhild","Gunther","Brynhild"],
  ["What were troubadours?","Lyric poets of southern France","Knights of the Round Table","Monks","Viking poets"]]}

]});


/* ---- from lit-06.js ---- */
/* LITERATURE FOUNDATIONS, part 6: Unit 3 chapters 5-10 */
COURSES.literature.units[2].ch.push(

{ t:"Dante and the Divine Comedy", s:"A journey through the afterlife",
  sec:[
  ["Dante's life",[
    "Dante Alighieri (1265–1321) was born in Florence. As a boy he met Beatrice Portinari, who became his lifelong ideal of love and spiritual beauty; his early book La Vita Nuova (The New Life) mixes poems and prose about his love for her and grief at her early death in 1290.",
    "Active in Florentine politics during violent factional strife, Dante was exiled in 1302 and never returned, dying in Ravenna. He wrote the Divine Comedy in exile."]],
  ["Structure of the Comedy",[
    "The Divine Comedy (called simply Commedia by Dante; 'Divine' was added later) recounts a journey through the three realms of the Christian afterlife over Easter weekend in 1300: Inferno (Hell), Purgatorio (Purgatory), and Paradiso (Heaven). It is written in terza rima, interlocking three-line stanzas (ABA BCB CDC), a form Dante invented, with 100 cantos total (one introductory plus 33 per part).",
    "It is called a comedy because it moves from misery to happiness and is written in the vernacular, not because it is funny. Writing in Tuscan Italian rather than Latin, Dante helped establish the Italian literary language."]],
  ["Inferno",[
    "'Midway upon the journey of our life, I found myself within a dark wood.' Lost, Dante is guided by the Roman poet Virgil through Hell, a funnel of nine circles descending to the center of the Earth, where punishments fit the sins (contrapasso). The gate reads 'Abandon all hope, ye who enter here.'",
    "Dante meets unforgettable souls: the lovers Paolo and Francesca, swept forever by winds as they were swept by passion; Ulysses, who urged his men to sail beyond known limits; and Count Ugolino, starved with his children in a tower. At the bottom, Satan, frozen in ice, chews the traitors Judas, Brutus, and Cassius."]],
  ["Purgatorio and Paradiso",[
    "In Purgatorio, souls climb a mountain, purging their sins through penance, with hope of heaven. At the top, in the Earthly Paradise, Virgil, as a pagan, must leave, and Beatrice appears to guide Dante. In Paradiso, he ascends through the heavenly spheres, meeting saints and theologians, until, guided at last by Saint Bernard, he glimpses God, the 'love that moves the sun and the other stars,' the poem's final line.",
    "The poem combines theology, philosophy, astronomy, politics, and personal history into an encyclopedic vision of the medieval universe."]],
  ["Legacy",[
    "The Comedy is considered one of the greatest poems in any language. It influenced Chaucer, Milton, the Romantics, T. S. Eliot (who said 'Dante and Shakespeare divide the modern world between them; there is no third'), Samuel Beckett, and countless artists, including Botticelli, Blake, Doré, and Rodin, whose sculpture The Thinker originally represented Dante.",
    "Dante's portrayal of real contemporaries, popes and politicians, in Hell made the poem politically daring."]]
  ],
  terms:[["Terza rima","Interlocking ABA BCB rhyme scheme."],["Contrapasso","Punishment fitting the sin."],["Canto","Section of a long poem."],["Beatrice","Dante's beloved and heavenly guide."],["Vernacular","Everyday spoken language rather than Latin."]],
  w:"Dante's Divine Comedy is a summit of world literature and a map of the medieval imagination.",
  src:["Divine Comedy","Dante Alighieri","Inferno (Dante)","Terza rima","Beatrice Portinari"],
  q:[
  ["Who guides Dante through Hell and Purgatory?","Virgil","Beatrice","Saint Bernard","Homer"],
  ["What rhyme scheme did Dante invent for the Comedy?","Terza rima","Ottava rima","Rhyming couplets","Sonnet form"],
  ["What is at the very bottom of Dante's Hell?","Satan frozen in ice","A lake of fire","Paolo and Francesca","Limbo"],
  ["Why is the work called a 'comedy'?","It moves from misery to happiness and is in the vernacular","It is humorous","It is a play","It mocks the Church"],
  ["Which lovers are swept by winds in the Inferno?","Paolo and Francesca","Tristan and Isolde","Dido and Aeneas","Romeo and Juliet"],
  ["Which sculpture originally represented Dante?","Rodin's The Thinker","Michelangelo's David","Bernini's Apollo","Donatello's Saint George"]]},

{ t:"Petrarch and Boccaccio", s:"Love sonnets and a hundred tales",
  sec:[
  ["Petrarch",[
    "Francesco Petrarca, Petrarch (1304–1374), was a scholar who searched monasteries for lost classical manuscripts, rediscovered Cicero's letters, and is often called the 'Father of Humanism.' He coined the idea of the preceding centuries as 'dark ages.' In 1341 he was crowned poet laureate in Rome.",
    "His climb of Mont Ventoux in 1336, described in a famous letter, has been seen as a symbolic moment of the Renaissance spirit, though at the summit he turned inward, reading Augustine."]],
  ["The Canzoniere",[
    "Petrarch's Canzoniere (Song Book), 366 Italian poems, mostly sonnets, records his love for Laura, whom he first saw in a church in Avignon in 1327 and who died of plague in 1348. The poems explore contradictory feelings, 'I burn and freeze,' using paradoxes, idealized beauty, and introspection.",
    "Petrarchism, imitation of his style, swept across Europe for three centuries: Wyatt, Surrey, Sidney, Spenser, and Shakespeare all wrote sonnets in his wake, sometimes parodying his conventions, as in Shakespeare's 'My mistress' eyes are nothing like the sun.'"]],
  ["Boccaccio and the Decameron",[
    "Giovanni Boccaccio (1313–1375), friend and admirer of Petrarch, wrote the Decameron (completed around 1353). During the Black Death of 1348, ten young Florentines, seven women and three men, flee to a country villa, where over ten days each tells one story a day, totaling 100 tales.",
    "The opening describes the plague's horrors with vivid realism. The tales range from bawdy comedies of clever wives and lustful friars to tragic love stories and tales of generosity, such as the patient Griselda, presenting a vivid panorama of merchants, nobles, clergy, and common people."]],
  ["Influence",[
    "The Decameron was a model for European prose fiction; Chaucer, Shakespeare (who drew on it for All's Well That Ends Well and Cymbeline), and Marguerite de Navarre (Heptaméron) borrowed from it. Its frame structure and realism made it a forerunner of the short story and novel.",
    "Boccaccio also wrote the first biography of Dante and lectured on the Divine Comedy in Florence, and his works on famous women and the genealogy of the gods were important humanist reference books."]],
  ["The three crowns",[
    "Dante, Petrarch, and Boccaccio are called the 'Three Crowns' (tre corone) of Italian literature. Together, they established Tuscan as the basis of the Italian literary language and bridged medieval and Renaissance culture.",
    "Their combination of classical learning and vernacular creativity launched the Renaissance in literature."]]
  ],
  terms:[["Humanism","Renaissance movement reviving classical learning."],["Petrarchan sonnet","Sonnet with octave and sestet."],["Laura","Petrarch's idealized beloved."],["Decameron","Boccaccio's 100 tales."],["Three Crowns","Dante, Petrarch, and Boccaccio."]],
  w:"Petrarch and Boccaccio shaped the love sonnet and prose storytelling, launching Renaissance literature.",
  src:["Petrarch","Il Canzoniere","Giovanni Boccaccio","The Decameron","Renaissance humanism"],
  q:[
  ["Who is often called the 'Father of Humanism'?","Petrarch","Boccaccio","Dante","Erasmus"],
  ["Who was Petrarch's beloved in his poems?","Laura","Beatrice","Fiammetta","Griselda"],
  ["How many tales are in the Decameron?","100","24","1,001","10"],
  ["Why do the storytellers in the Decameron leave Florence?","To escape the Black Death","To attend a wedding","For a pilgrimage","To avoid war"],
  ["Which Shakespeare sonnet parodies Petrarchan conventions?","My mistress' eyes are nothing like the sun","Shall I compare thee","When in disgrace with fortune","Let me not to the marriage"],
  ["Who are the 'Three Crowns' of Italian literature?","Dante, Petrarch, Boccaccio","Virgil, Ovid, Horace","Ariosto, Tasso, Dante","Machiavelli, Petrarch, Dante"]]},

{ t:"Chaucer and Medieval English Literature", s:"The Canterbury Tales",
  sec:[
  ["Middle English",[
    "After 1066, English absorbed thousands of French words and lost many inflections, becoming Middle English (about 1100–1500). By the 14th century, English was reasserting itself as a literary language alongside French and Latin.",
    "Major Middle English works include William Langland's allegorical Piers Plowman, John Gower's Confessio Amantis, the Gawain poet's works, and mystery plays."]],
  ["Chaucer's life",[
    "Geoffrey Chaucer (about 1343–1400) was a London wine merchant's son who served as a courtier, diplomat, soldier, and customs official. Travels to France and Italy introduced him to Dante, Petrarch, and Boccaccio. His Troilus and Criseyde, a tragic love story set in the Trojan War, is a masterpiece of psychological depth.",
    "He is called the 'Father of English literature,' and was the first poet buried in what became Poets' Corner in Westminster Abbey."]],
  ["The Canterbury Tales",[
    "The Canterbury Tales (begun about 1387, unfinished) presents a group of about thirty pilgrims traveling from the Tabard Inn in Southwark to the shrine of Thomas Becket at Canterbury, who agree to a storytelling contest proposed by the innkeeper Harry Bailly. Only 24 tales were completed.",
    "The General Prologue, beginning 'Whan that Aprill with his shoures soote,' sketches the pilgrims with sharp, ironic portraits: the noble Knight, the corrupt Pardoner selling fake relics, the dainty Prioress, the drunken Miller, and the Wife of Bath, a bold widow of five husbands who argues for women's 'maistrye' (sovereignty) in marriage."]],
  ["Variety of the tales",[
    "The tales cover nearly every medieval genre: chivalric romance (the Knight's Tale), bawdy fabliaux (the Miller's Tale, a raucous comedy of adultery), saints' lives, beast fables (the Nun's Priest's Tale of Chauntecleer the rooster), moral sermons, and Breton lays. Tales often respond to one another, creating comic quarrels between pilgrims.",
    "The Pardoner's Tale, in which three men seeking Death find gold and kill each other, illustrates 'Greed is the root of all evil' while the Pardoner himself is greedy, a masterpiece of irony."]],
  ["Chaucer's achievement",[
    "Chaucer brought iambic pentameter and rhyming couplets into English, mixed comedy and seriousness, and created vivid individual characters drawn from all classes of society. His narrator, a naive, genial observer, adds layers of irony.",
    "Printed by William Caxton in the 1470s, the Canterbury Tales became one of the first books printed in England and a cornerstone of English literature."]]
  ],
  terms:[["Middle English","English of about 1100–1500."],["Fabliau","Bawdy comic tale."],["General Prologue","Opening portraits of the Canterbury pilgrims."],["Wife of Bath","Chaucer's bold, much-married pilgrim."],["Poets' Corner","Westminster Abbey burial place of writers."]],
  w:"Chaucer created a vivid gallery of English society and established English as a great literary language.",
  src:["Geoffrey Chaucer","The Canterbury Tales","Middle English literature","The Wife of Bath's Tale","Piers Plowman"],
  q:[
  ["To whose shrine do Chaucer's pilgrims travel?","Thomas Becket's at Canterbury","Saint Paul's in London","Saint James's in Spain","Saint Alban's"],
  ["Which pilgrim argues for women's sovereignty in marriage?","The Wife of Bath","The Prioress","The Second Nun","The Knight"],
  ["What is a fabliau?","A bawdy comic tale","A saint's life","A romance","A sermon"],
  ["Who proposes the storytelling contest?","Harry Bailly, the innkeeper","The Knight","Chaucer","The Pardoner"],
  ["Which Chaucer work is a tragic love story set in the Trojan War?","Troilus and Criseyde","The Book of the Duchess","The Parliament of Fowls","The House of Fame"],
  ["Who wrote the allegorical Piers Plowman?","William Langland","John Gower","Thomas Malory","John Lydgate"]]},

{ t:"Literature of the Islamic World", s:"Arabic and Persian classics",
  sec:[
  ["Arabic poetry and the Quran",[
    "Pre-Islamic Arabic poetry was highly prized; the most celebrated odes (qasidas), the Mu'allaqat ('suspended odes'), by poets such as Imru' al-Qais, begin with a lament over an abandoned campsite and move to journeys and praise. The Quran (7th century), regarded by Muslims as the word of God revealed to Muhammad, is considered the supreme model of Arabic eloquence, and its language shaped Arabic literature and culture.",
    "Under the Abbasid caliphs in Baghdad, poets such as Abu Nuwas (famous for wine poems) and al-Mutanabbi (proud, eloquent panegyrics) flourished."]],
  ["One Thousand and One Nights",[
    "One Thousand and One Nights (Alf Layla wa-Layla), also called the Arabian Nights, is a collection of stories from Persian, Indian, Arabic, and other sources, assembled over centuries. In the frame story, King Shahryar, betrayed by his wife, marries a new bride each night and executes her at dawn, until Scheherazade tells him a story each night, leaving it unfinished at dawn so he spares her to hear the end.",
    "Famous stories such as 'Aladdin' and 'Ali Baba and the Forty Thieves' were added by the French translator Antoine Galland in the early 18th century, reportedly from a Syrian storyteller, Hanna Diyab. The collection influenced European writers from the Romantics to Borges."]],
  ["Persian epic: Ferdowsi",[
    "Ferdowsi (about 940–1020) spent some 30 years writing the Shahnameh (Book of Kings), an epic of about 50,000 couplets recounting Persia's mythical and historical kings up to the Arab conquest. Its greatest hero is Rostam, whose tragic combat with his unknown son Sohrab is one of its most famous episodes. Ferdowsi wrote in Persian with few Arabic loanwords, helping preserve the language and Iranian identity.",
    "The Shahnameh remains central to Iranian culture, recited in teahouses and celebrated in illustrated manuscripts."]],
  ["Persian lyric and mysticism",[
    "Omar Khayyam (1048–1131), a mathematician and astronomer, is credited with quatrains (rubaiyat) on fate and pleasure, made famous in English by Edward FitzGerald's free 1859 version ('A Jug of Wine, a Loaf of Bread, and Thou'). Nizami wrote romances such as Layla and Majnun, the story of a man driven mad by love.",
    "Jalal al-Din Rumi (1207–1273), a Sufi mystic, wrote the Masnavi, a vast spiritual poem, and passionate ghazals inspired by his friendship with the wandering dervish Shams of Tabriz; he is among the best-selling poets in America today. Saadi's Gulistan (Rose Garden) blends prose and verse wisdom, and Hafez (14th century) perfected the ghazal; Iranians still consult his Divan for guidance."]],
  ["Al-Andalus and beyond",[
    "In Muslim Spain (al-Andalus), poetry flourished in Arabic and Hebrew; Ibn Hazm's The Ring of the Dove analyzed love, and Ibn Tufayl's philosophical novel Hayy ibn Yaqzan imagined a man reasoning his way to truth alone on an island. Historian Ibn Khaldun's Muqaddimah (1377) analyzed the rise and fall of dynasties.",
    "Ottoman Turkish and Urdu literatures later drew heavily on these Persian and Arabic models."]]
  ],
  terms:[["Qasida","Classical Arabic ode."],["Scheherazade","Storyteller of the Thousand and One Nights."],["Shahnameh","Ferdowsi's Persian Book of Kings."],["Rubaiyat","Quatrains attributed to Omar Khayyam."],["Sufism","Islamic mysticism."]],
  w:"Arabic and Persian classics are among the world's richest literatures and deeply influenced Europe and Asia.",
  src:["One Thousand and One Nights","Shahnameh","Rumi","Hafez","Rubaiyat of Omar Khayyam"],
  q:[
  ["Who tells the stories in One Thousand and One Nights?","Scheherazade","Shahryar","Sinbad","Aladdin"],
  ["Who wrote the Shahnameh?","Ferdowsi","Rumi","Hafez","Saadi"],
  ["Who is the great hero of the Shahnameh?","Rostam","Sohrab","Majnun","Shams"],
  ["Who translated the Rubaiyat into famous English verse in 1859?","Edward FitzGerald","Richard Burton","Antoine Galland","Coleman Barks"],
  ["Which Sufi poet wrote the Masnavi?","Rumi","Hafez","Omar Khayyam","Nizami"],
  ["Who added 'Aladdin' to the Nights collection?","Antoine Galland","Richard Burton","Edward Lane","Ferdowsi"]]},

{ t:"Classical China and Japan", s:"Tang poets, Genji, and the Pillow Book",
  sec:[
  ["Tang poetry",[
    "The Tang dynasty (618–907) is the golden age of Chinese poetry; an 18th-century anthology preserved some 48,900 poems by over 2,200 poets. Li Bai (701–762), a carefree, romantic Daoist, wrote of wine, the moon, and nature; his 'Quiet Night Thought' ('Before my bed, bright moonlight... I lower my head and think of home') is memorized by Chinese schoolchildren.",
    "Du Fu (712–770), considered the 'poet-sage,' wrote with moral seriousness about war, poverty, and the suffering caused by the An Lushan Rebellion. Wang Wei combined poetry, painting, and Buddhist calm; Bai Juyi wrote in plain language so that, legend says, an old woman could understand his poems."]],
  ["Song dynasty and the novel",[
    "During the Song dynasty (960–1279), the ci, lyrics set to music, flourished; Su Shi and Li Qingzhao, the greatest Chinese woman poet, excelled in it.",
    "Later, during the Ming and Qing dynasties, vernacular novels emerged; the 'Four Great Classical Novels' are Romance of the Three Kingdoms (historical warfare), Water Margin (outlaw heroes), Journey to the West (the monkey king Sun Wukong escorting a monk to India), and Dream of the Red Chamber (Cao Xueqin's 18th-century masterpiece about the decline of an aristocratic family)."]],
  ["The Tale of Genji",[
    "In Heian Japan (794–1185), court women created some of the world's first great prose literature, writing in Japanese kana script while men often wrote in Chinese. Murasaki Shikibu, a lady-in-waiting, wrote The Tale of Genji (early 11th century), about the life and loves of the 'Shining Prince' Genji and his descendants, in 54 chapters.",
    "Genji is admired for psychological subtlety and its sense of mono no aware, a gentle sadness at the impermanence of things. It is often called the world's first novel."]],
  ["The Pillow Book and diaries",[
    "Sei Shōnagon, a rival lady-in-waiting, wrote The Pillow Book, a witty collection of observations, anecdotes, and lists ('Things That Make One's Heart Beat Faster,' 'Hateful Things'), a forerunner of the essay. Court diaries and poetry anthologies such as the Kokinshū (905) showcased the 31-syllable waka poem.",
    "The Man'yōshū (8th century) is the oldest Japanese poetry anthology."]],
  ["Medieval Japan",[
    "The Tale of the Heike (13th–14th century), sung by blind monks with the biwa lute, recounts the fall of the Taira clan in the Genpei War, opening with the Buddhist theme of impermanence. Kamo no Chōmei's Hōjōki (An Account of My Hut) and Yoshida Kenkō's Essays in Idleness are classic reflective prose.",
    "Noh drama, perfected by Zeami in the 14th–15th centuries, combined poetry, music, and masked dance."]]
  ],
  terms:[["Tang poetry","Golden age of Chinese verse."],["Ci","Song lyrics of the Song dynasty."],["Mono no aware","Gentle sadness at impermanence."],["Waka","31-syllable Japanese poem."],["Journey to the West","Classic novel of the Monkey King."]],
  w:"Chinese and Japanese classics include some of the world's greatest poetry and the earliest novels.",
  src:["Tang poetry","Li Bai","Du Fu","The Tale of Genji","The Pillow Book"],
  q:[
  ["Who wrote The Tale of Genji?","Murasaki Shikibu","Sei Shōnagon","Ono no Komachi","Izumi Shikibu"],
  ["Which Tang poet is called the 'poet-sage'?","Du Fu","Li Bai","Wang Wei","Bai Juyi"],
  ["Which novel features the Monkey King Sun Wukong?","Journey to the West","Dream of the Red Chamber","Water Margin","Romance of the Three Kingdoms"],
  ["Who wrote The Pillow Book?","Sei Shōnagon","Murasaki Shikibu","Kenkō","Zeami"],
  ["Who is considered the greatest Chinese woman poet?","Li Qingzhao","Ban Zhao","Xue Tao","Cai Wenji"],
  ["What does 'mono no aware' express?","Gentle sadness at impermanence","Courage in battle","Joy of spring","Religious devotion"]]},

{ t:"Medieval Women Writers and Drama", s:"Mystics, poets, and mystery plays",
  sec:[
  ["Women's voices",[
    "Medieval women wrote despite limited access to education. Hildegard of Bingen (1098–1179) wrote visionary theology, science, music, and a morality play. Héloïse's letters to her former lover Peter Abelard are passionate and intellectually brilliant. Marie de France wrote lais and fables.",
    "Mechthild of Magdeburg and Hadewijch wrote mystical poetry in German and Dutch."]],
  ["Christine de Pizan",[
    "Christine de Pizan (1364–about 1430), born in Venice and raised at the French court, was widowed young and became perhaps the first European woman to support her family by writing. The Book of the City of Ladies (1405) imagines Reason, Rectitude, and Justice helping her build an allegorical city populated by famous women, refuting misogynist writers.",
    "She engaged in the 'Querelle de la Rose,' criticizing the misogyny of the popular Romance of the Rose, and wrote a poem celebrating Joan of Arc in 1429."]],
  ["English mystics",[
    "Julian of Norwich (1343–after 1416), an anchoress living in a cell attached to a church, wrote Revelations of Divine Love, the earliest surviving book in English known to be written by a woman. It describes visions during illness and contains the famous assurance 'All shall be well, and all shall be well, and all manner of thing shall be well.'",
    "Margery Kempe (about 1373–after 1438), a mother of fourteen and pilgrim, dictated The Book of Margery Kempe, often called the first autobiography in English, rediscovered in 1934."]],
  ["Medieval drama",[
    "Drama reemerged within church liturgy, with short Latin scenes such as the Easter dialogue at Christ's tomb. By the 14th–15th centuries, English towns staged mystery cycles, sequences of plays from Creation to Doomsday, each performed by a craft guild (shipwrights performing Noah's Ark), on pageant wagons moving through the streets, as in York, Chester, and Wakefield. The Second Shepherds' Play mixes nativity with comic sheep-stealing.",
    "Morality plays personified virtues and vices; in Everyman (about 1500), Everyman, summoned by Death, finds that Fellowship, Kindred, and Goods abandon him, and only Good Deeds accompanies him to the grave."]],
  ["Toward the Renaissance",[
    "François Villon (1431–after 1463), a Parisian poet and criminal, wrote bitterly witty verse, including the 'Ballad of the Hanged Men' and the line 'Where are the snows of yesteryear?'",
    "With the invention of printing by Johannes Gutenberg around 1450, the spread of literature accelerated dramatically, opening the way to the Renaissance."]]
  ],
  terms:[["City of Ladies","Christine de Pizan's defense of women."],["Anchoress","Woman enclosed in a cell for prayer."],["Mystery play","Medieval biblical drama by guilds."],["Morality play","Allegorical drama of virtues and vices."],["Everyman","Famous English morality play."]],
  w:"Medieval women writers and community drama broadened literature's voices and audiences.",
  src:["Christine de Pizan","Julian of Norwich","Margery Kempe","Mystery play","Everyman (play)"],
  q:[
  ["Who wrote The Book of the City of Ladies?","Christine de Pizan","Marie de France","Héloïse","Hildegard of Bingen"],
  ["Who wrote 'All shall be well, and all manner of thing shall be well'?","Julian of Norwich","Margery Kempe","Hildegard","Christine de Pizan"],
  ["Who performed English mystery plays?","Craft guilds","Monks only","Royal courts","Traveling knights"],
  ["In Everyman, who accompanies Everyman to the grave?","Good Deeds","Fellowship","Goods","Kindred"],
  ["Which book is often called the first autobiography in English?","The Book of Margery Kempe","Revelations of Divine Love","Confessions","The City of Ladies"],
  ["Which poet asked 'Where are the snows of yesteryear?'","François Villon","Petrarch","Chaucer","Christine de Pizan"]]}

);


/* ---- from lit-07.js ---- */
/* LITERATURE FOUNDATIONS, part 7: Unit 4 The Renaissance, chapters 1-5 */
COURSES.literature.units.push({ t:"The Renaissance and Seventeenth Century", ch:[

{ t:"Humanism and the Printed Book", s:"Erasmus, More, Machiavelli, Montaigne",
  sec:[
  ["Printing changes everything",[
    "Johannes Gutenberg's movable-type printing press, developed in Mainz around 1450 (his Bible was printed about 1455), made books cheaper and more plentiful. By 1500, presses in over 200 European towns had printed millions of copies. Printing spread humanist learning, standardized languages, enabled the Protestant Reformation, and created a reading public.",
    "Venetian printer Aldus Manutius published affordable editions of Greek and Latin classics in a portable format and introduced italic type."]],
  ["Erasmus",[
    "Desiderius Erasmus (about 1466–1536), the Dutch scholar, was the most famous humanist in Europe. His Praise of Folly (1511), narrated by Folly herself, satirizes the vanity of scholars, monks, popes, and kings. He produced a new Greek edition of the New Testament (1516), used by Luther and later translators.",
    "Erasmus championed education, peace, and reform within the Church, but refused to join Luther's break with Rome."]],
  ["Thomas More's Utopia",[
    "Erasmus's friend Thomas More (1478–1535), an English lawyer and statesman, wrote Utopia (1516), describing an imaginary island society with communal property, religious tolerance, and rational institutions, contrasting it with the injustices of England. 'Utopia' is a pun: Greek for 'no place' and 'good place.'",
    "More later became Lord Chancellor but was executed for refusing to accept Henry VIII as head of the English Church. Utopia gave its name to a genre of ideal societies and, later, dystopias."]],
  ["Machiavelli and Castiglione",[
    "Niccolò Machiavelli (1469–1527), a Florentine official, wrote The Prince (1513, published 1532), advising rulers to be practical rather than idealistic: it is safer to be feared than loved, if one cannot be both. Its realism earned 'Machiavellian' its sinister meaning, though Machiavelli also wrote the republican Discourses on Livy and the comic play The Mandrake.",
    "Baldassare Castiglione's The Book of the Courtier (1528) described the ideal courtier, accomplished, graceful, and displaying sprezzatura, effortless nonchalance; it shaped manners across Europe."]],
  ["Montaigne",[
    "Michel de Montaigne (1533–1592) retired to his library tower and wrote his Essays (from 1580), exploring himself as a way of understanding humanity: 'I am myself the matter of my book.' He wrote on friendship, cannibals (questioning European assumptions of superiority), education, experience, and death, with skepticism summed up in his motto 'Que sais-je?' ('What do I know?').",
    "His frank, conversational style created the essay as a genre and influenced Shakespeare, Bacon, Emerson, Nietzsche, and Virginia Woolf."]],
  ["Renaissance ideals",[
    "Renaissance humanism emphasized classical languages and texts, the dignity and potential of humans (as in Pico della Mirandola's Oration on the Dignity of Man), education, eloquence, and civic life. It combined with Christian faith and new discoveries, from the Americas to Copernican astronomy, that unsettled old certainties.",
    "These ideas created the context for the great literature of the 16th and 17th centuries."]]
  ],
  terms:[["Humanism","Movement reviving classical learning."],["Utopia","More's ideal society; 'no place.'"],["Machiavellian","Cunning, ruthless in politics."],["Sprezzatura","Effortless nonchalance."],["Essay","Montaigne's form of personal exploration."]],
  w:"Printing and humanism transformed reading and writing, creating forms and ideas still central today.",
  src:["Printing press","Erasmus","Utopia (book)","The Prince","Michel de Montaigne"],
  q:[
  ["Who wrote The Praise of Folly?","Erasmus","Thomas More","Machiavelli","Montaigne"],
  ["What does 'Utopia' mean in Greek puns?","'No place' and 'good place'","'Island' and 'perfect'","'Future' and 'peace'","'Dream' and 'law'"],
  ["Who advised that it is safer to be feared than loved?","Machiavelli","Castiglione","Erasmus","Thomas More"],
  ["What was Montaigne's motto?","'What do I know?'","'Seize the day'","'Know thyself'","'Faith alone'"],
  ["Around when was Gutenberg's Bible printed?","1455","1350","1520","1600"],
  ["What is sprezzatura?","Effortless nonchalance","Political cunning","Religious devotion","A type of poem"]]},

{ t:"Renaissance Epic and Satire", s:"Rabelais, Ariosto, Tasso, Camões, Spenser",
  sec:[
  ["Rabelais",[
    "François Rabelais (about 1494–1553), a French monk, doctor, and humanist, wrote Gargantua and Pantagruel, comic novels about two giants, father and son. Full of bawdy humor, gigantic feasts, wordplay, lists, and satire of scholasticism, monks, and lawyers, they also express humanist ideals of education and freedom. The Abbey of Thélème has only one rule: 'Do what you will.'",
    "The adjective 'Rabelaisian' describes earthy, exuberant humor. The Russian critic Mikhail Bakhtin later analyzed Rabelais's 'carnivalesque' world, where hierarchies are overturned through laughter."]],
  ["Italian romance epics",[
    "Ludovico Ariosto's Orlando Furioso (1516–32) continues the story of Roland (Orlando), who goes mad with love for the princess Angelica. Its playful, ironic interweaving of dozens of storylines, knights, sorceresses, hippogriffs, and a trip to the moon to recover Orlando's lost wits, delighted readers across Europe.",
    "Torquato Tasso's Jerusalem Delivered (1581) is a more serious epic of the First Crusade, with tragic love stories such as that of Tancredi and the Muslim warrior-maiden Clorinda; it inspired operas and paintings."]],
  ["Camões and the Lusiads",[
    "Luís de Camões (about 1524–1580), Portugal's national poet, wrote Os Lusíadas (The Lusiads, 1572), an epic celebrating Vasco da Gama's voyage to India in 1497–98 and Portuguese history. Camões lost an eye fighting in North Africa and, legend says, saved his manuscript by swimming from a shipwreck in the Mekong delta.",
    "The poem mixes classical gods with real navigation, including the giant Adamastor, personifying the Cape of Good Hope's storms."]],
  ["Spenser's Faerie Queene",[
    "Edmund Spenser (about 1552–1599) wrote The Faerie Queene (1590–96), an allegorical epic dedicated to Queen Elizabeth I, in which knights each represent a virtue: the Redcrosse Knight (holiness) fights the dragon of Error; Sir Guyon (temperance) destroys the Bower of Bliss. Gloriana, the Faerie Queene, represents Elizabeth.",
    "Spenser invented the nine-line Spenserian stanza, later used by Keats, Shelley, and Byron, and deliberately used archaic language. His sonnet sequence Amoretti and wedding poem Epithalamion are also celebrated."]],
  ["Sidney and courtly poetry",[
    "Sir Philip Sidney (1554–1586), soldier and courtier, wrote Astrophil and Stella, the first major English sonnet sequence, the pastoral romance Arcadia, and An Apology for Poetry (The Defence of Poesy), arguing that poetry teaches virtue more effectively than philosophy or history. He died of a wound received at the Battle of Zutphen, reportedly giving his water to a dying soldier.",
    "Thomas Wyatt and Henry Howard, Earl of Surrey, had earlier introduced the sonnet into English; Surrey also pioneered blank verse."]]
  ],
  terms:[["Rabelaisian","Earthy, exuberant humor."],["Carnivalesque","Overturning hierarchy through laughter."],["Orlando Furioso","Ariosto's romance epic."],["Lusiads","Camões's Portuguese national epic."],["Spenserian stanza","Nine-line stanza invented by Spenser."]],
  w:"Renaissance epics and satire blended classical models with new humor, nations, and discoveries.",
  src:["Gargantua and Pantagruel","Orlando Furioso","Os Lusíadas","The Faerie Queene","Philip Sidney"],
  q:[
  ["What is the only rule of Rabelais's Abbey of Thélème?","Do what you will","Pray always","Love thy neighbor","Obey the abbot"],
  ["Which epic celebrates Vasco da Gama's voyage?","The Lusiads","Orlando Furioso","Jerusalem Delivered","The Faerie Queene"],
  ["To whom was The Faerie Queene dedicated?","Elizabeth I","Henry VIII","James I","Mary I"],
  ["Who goes mad with love for Angelica?","Orlando","Tancredi","Redcrosse","Gargantua"],
  ["Who wrote An Apology for Poetry?","Philip Sidney","Edmund Spenser","Thomas Wyatt","Ben Jonson"],
  ["Which critic analyzed Rabelais's 'carnivalesque'?","Mikhail Bakhtin","Erich Auerbach","Roland Barthes","Northrop Frye"]]},

{ t:"Cervantes and Don Quixote", s:"The first modern novel",
  sec:[
  ["Cervantes's life",[
    "Miguel de Cervantes (1547–1616) lived an adventurous life: he fought at the naval Battle of Lepanto (1571), where a wound left his left hand useless; was captured by Barbary pirates and held for five years in Algiers, attempting escape four times; and later worked as a tax collector, landing in prison. He died in Madrid in April 1616, days before Shakespeare (though Spain and England then used different calendars).",
    "He wrote plays, poems, a pastoral novel, and the Exemplary Novels (short fiction), but his masterpiece is Don Quixote."]],
  ["The story",[
    "Don Quixote (Part One 1605, Part Two 1615) tells of Alonso Quixano, a minor nobleman in La Mancha who reads so many chivalric romances that he loses his mind and sets out as a knight-errant, Don Quixote, with his old horse Rocinante and a simple farmer, Sancho Panza, as his squire. He dedicates his deeds to Dulcinea, an idealized version of a peasant woman.",
    "His adventures include attacking windmills he believes are giants, giving us the phrase 'tilting at windmills,' freeing galley slaves, and battling flocks of sheep he thinks are armies. Sancho, practical and proverb-loving, is promised the governorship of an island."]],
  ["Part Two and metafiction",[
    "In Part Two, the characters know that a book about them, Part One, has been published, and they meet readers who have read it. Cervantes also mocks a fake sequel by another author that appeared in 1614. This self-awareness makes Don Quixote an early masterpiece of metafiction, fiction that reflects on itself.",
    "Gradually Sancho becomes wiser and more idealistic, and Quixote more realistic; critics call this the 'Quixotization' of Sancho and 'Sanchification' of Quixote. At the end, Quixote recovers his sanity, renounces chivalry, and dies."]],
  ["Why it matters",[
    "Don Quixote is often called the first modern novel: it explores the clash between imagination and reality, the power of books, the variety of social life in Spain, and complex characters who change. It was immediately popular and translated into English (1612) and French.",
    "In a 2002 poll of 100 writers organized by the Norwegian Book Clubs, it was voted the best literary work ever written. 'Quixotic' means idealistic and impractical."]],
  ["Influence",[
    "Writers from Fielding, Sterne, and Smollett to Flaubert (Madame Bovary, another reader ruined by romance), Dostoevsky (The Idiot), Twain, Borges ('Pierre Menard, Author of the Quixote'), and Salman Rushdie (Quichotte) have responded to Cervantes. The musical Man of La Mancha and Picasso's sketch of Quixote and Sancho show its reach.",
    "Spanish is often called 'la lengua de Cervantes,' and the Cervantes Prize is the most prestigious award in Spanish-language literature."]]
  ],
  terms:[["Knight-errant","Wandering knight seeking adventures."],["Tilting at windmills","Fighting imaginary enemies."],["Metafiction","Fiction aware of itself as fiction."],["Quixotic","Idealistic and impractical."],["Picaresque","Episodic tale of a rogue's adventures."]],
  w:"Don Quixote created the modern novel's concern with reality, imagination, and character growth.",
  src:["Don Quixote","Miguel de Cervantes","Sancho Panza","Metafiction","Battle of Lepanto"],
  q:[
  ["What does Don Quixote mistake for giants?","Windmills","Sheep","Trees","Castles"],
  ["Who is Don Quixote's squire?","Sancho Panza","Rocinante","Dulcinea","Sansón Carrasco"],
  ["Where was Cervantes held captive for five years?","Algiers","Constantinople","Tunis","Lisbon"],
  ["What makes Part Two an example of metafiction?","Characters know a book about them exists","It has no narrator","It is written in verse","It takes place in the future"],
  ["At which battle was Cervantes wounded?","Lepanto","Pavia","Armada","Vienna"],
  ["What does 'quixotic' mean?","Idealistic and impractical","Cruel","Wise","Fast"]]},

{ t:"The Spanish Golden Age", s:"Lope, Calderón, and the picaresque",
  sec:[
  ["The Siglo de Oro",[
    "The Spanish Golden Age (Siglo de Oro), roughly 1500 to 1680, coincided with Spain's imperial power. Besides Cervantes, it produced the picaresque novel, a flourishing popular theater, and great poetry, both religious and secular.",
    "Garcilaso de la Vega introduced Italian forms such as the sonnet into Spanish poetry in the early 16th century."]],
  ["The picaresque",[
    "The anonymous Lazarillo de Tormes (1554), the first picaresque novel, is told by Lázaro, a poor boy who serves a series of masters, a cruel blind beggar, a stingy priest, and a starving but proud squire, learning to survive by cunning. It satirizes hypocrisy and the obsession with honor.",
    "Mateo Alemán's Guzmán de Alfarache and Francisco de Quevedo's El Buscón continued the genre, which influenced later novels such as Defoe's Moll Flanders and Fielding's Tom Jones."]],
  ["Lope de Vega",[
    "Lope de Vega (1562–1635), called 'the Phoenix of Wits' and a 'monster of nature' by Cervantes, claimed to have written about 1,500 plays; several hundred survive. His The New Art of Writing Plays (1609) defended mixing comedy and tragedy and pleasing audiences rather than following classical rules.",
    "His Fuenteovejuna (about 1614), in which villagers collectively kill a tyrannical commander and, under torture, answer only 'Fuenteovejuna did it,' is a landmark of collective resistance. Spanish public theaters (corrales) were lively spaces where all classes watched together."]],
  ["Tirso and the Don Juan legend",[
    "Tirso de Molina's The Trickster of Seville and the Stone Guest (about 1630) introduced Don Juan, the seducer who deceives women and finally invites a statue of a man he killed to dinner, which drags him to Hell. The legend inspired Molière, Mozart and Da Ponte's Don Giovanni, Byron's Don Juan, and many others.",
    "Honor plays, in which husbands avenge perceived threats to their honor, were a popular genre."]],
  ["Calderón",[
    "Pedro Calderón de la Barca (1600–1681) wrote philosophical dramas and religious allegories (autos sacramentales). His masterpiece Life Is a Dream (La vida es sueño, 1635) tells of Prince Segismundo, imprisoned from birth because of a prophecy, briefly released, then made to believe his freedom was a dream; he learns to act well whether life is real or dream ('all life is a dream, and dreams are dreams').",
    "Golden Age poets include the mystics Saint Teresa of Ávila and Saint John of the Cross ('Dark Night of the Soul'), the ornate Luis de Góngora, the satirical Quevedo, and in Mexico, Sor Juana Inés de la Cruz (1648–1695), a brilliant nun-poet and scholar who defended women's right to learning."]]
  ],
  terms:[["Siglo de Oro","Spanish Golden Age of literature."],["Picaresque","Episodic novel of a rogue's adventures."],["Corral","Spanish open-air public theater."],["Don Juan","Legendary seducer from Tirso de Molina."],["Auto sacramental","Spanish religious allegorical play."]],
  w:"Spain's Golden Age created the picaresque, Don Juan, and some of Europe's richest drama and poetry.",
  src:["Spanish Golden Age","Lazarillo de Tormes","Lope de Vega","Life Is a Dream","Sor Juana Inés de la Cruz"],
  q:[
  ["Which work is the first picaresque novel?","Lazarillo de Tormes","Don Quixote","El Buscón","Guzmán de Alfarache"],
  ["Who claimed to have written about 1,500 plays?","Lope de Vega","Calderón","Tirso de Molina","Cervantes"],
  ["Which play features villagers saying 'Fuenteovejuna did it'?","Fuenteovejuna","Life Is a Dream","The Trickster of Seville","The Mayor of Zalamea"],
  ["Who introduced the Don Juan character?","Tirso de Molina","Molière","Byron","Calderón"],
  ["Who wrote Life Is a Dream?","Calderón de la Barca","Lope de Vega","Quevedo","Góngora"],
  ["Which Mexican nun-poet defended women's right to learning?","Sor Juana Inés de la Cruz","Teresa of Ávila","Gabriela Mistral","Rosario Castellanos"]]},

{ t:"Elizabethan Drama and Marlowe", s:"The London stage",
  sec:[
  ["The public theaters",[
    "In 1576 James Burbage built The Theatre, one of London's first purpose-built public playhouses. Others followed: the Rose, the Swan, and in 1599 the Globe, built partly from The Theatre's timbers. These open-air, polygonal theaters held up to about 3,000 spectators; 'groundlings' paid a penny to stand in the yard, while wealthier patrons sat in galleries.",
    "Performances happened in daylight with minimal scenery, elaborate costumes, and all-male companies; boys played women's roles. Companies were protected by noble patrons, such as the Lord Chamberlain's Men (later the King's Men), Shakespeare's company."]],
  ["University Wits and Kyd",[
    "A group of university-educated playwrights, the 'University Wits,' including Christopher Marlowe, Robert Greene, John Lyly, and George Peele, shaped early Elizabethan drama. Thomas Kyd's The Spanish Tragedy (about 1587) popularized the revenge tragedy, with a ghost, madness, a play-within-a-play, and bloody vengeance, elements later used in Hamlet.",
    "Plays were written quickly, often collaboratively, and printed cheaply, if at all."]],
  ["Christopher Marlowe",[
    "Christopher Marlowe (1564–1593), son of a Canterbury shoemaker and Cambridge graduate, transformed English drama with his 'mighty line,' powerful blank verse. Tamburlaine the Great (about 1587) portrays a Scythian shepherd who conquers empires through boundless ambition. The Jew of Malta presents a scheming villain, Barabas, and Edward II depicts a king's downfall and his love for his favorite Piers Gaveston.",
    "Doctor Faustus tells of a scholar who sells his soul to the devil for 24 years of knowledge and power; seeing Helen of Troy, he asks, 'Was this the face that launched a thousand ships?' and in his final hour pleads for time to stop before being dragged to Hell."]],
  ["Marlowe's mysterious death",[
    "Marlowe was rumored to be a government spy and was accused of atheism. In May 1593 he was stabbed to death at age 29 in a house in Deptford, in an argument reportedly over the bill (the 'reckoning'). The circumstances, involving men with intelligence connections, have prompted endless speculation.",
    "His influence on the young Shakespeare was enormous."]],
  ["Ben Jonson and Jacobean drama",[
    "Ben Jonson (1572–1637), bricklayer, soldier, and scholar, wrote satirical 'comedies of humours' such as Volpone (about 1606), in which a greedy Venetian fakes illness to swindle legacy-hunters, and The Alchemist. He was effectively England's first poet laureate and wrote court masques. He praised Shakespeare as 'not of an age, but for all time.'",
    "Jacobean tragedy, under James I, grew darker: John Webster's The Duchess of Malfi and The White Devil, Thomas Middleton's The Changeling, and John Ford's 'Tis Pity She's a Whore explore corruption, lust, and violence. In 1642 the Puritan-led Parliament closed the theaters."]]
  ],
  terms:[["Globe Theatre","Shakespeare's company's playhouse, built 1599."],["Groundlings","Spectators standing in the yard."],["Revenge tragedy","Drama of bloody vengeance."],["Marlowe's mighty line","Powerful blank verse."],["Comedy of humours","Jonson's satirical character comedy."]],
  w:"The Elizabethan and Jacobean stage produced an explosion of drama that culminated in Shakespeare.",
  src:["English Renaissance theatre","Christopher Marlowe","Doctor Faustus (play)","Ben Jonson","The Spanish Tragedy"],
  q:[
  ["When was the Globe Theatre built?","1599","1576","1613","1642"],
  ["Who wrote Doctor Faustus?","Christopher Marlowe","Ben Jonson","Thomas Kyd","John Webster"],
  ["Which play popularized revenge tragedy?","The Spanish Tragedy","Volpone","Tamburlaine","The Alchemist"],
  ["Who called Shakespeare 'not of an age, but for all time'?","Ben Jonson","Christopher Marlowe","John Milton","Samuel Johnson"],
  ["Who wrote The Duchess of Malfi?","John Webster","Thomas Middleton","John Ford","Ben Jonson"],
  ["When did Parliament close the theaters?","1642","1603","1660","1616"]]}

]});


/* ---- from lit-08.js ---- */
/* LITERATURE FOUNDATIONS, part 8: Unit 4 Shakespeare */
COURSES.literature.units[3].ch.push(

{ t:"Shakespeare's Life and World", s:"The man from Stratford",
  sec:[
  ["Early life",[
    "William Shakespeare was baptized on 26 April 1564 in Stratford-upon-Avon, a market town in Warwickshire; his father John was a glove-maker and town official. He probably attended the local grammar school, learning Latin and reading Ovid, Virgil, and Seneca. In 1582, at 18, he married Anne Hathaway, eight years older; they had a daughter, Susanna, and twins, Hamnet and Judith. Hamnet died in 1596, aged eleven.",
    "The 'lost years' (1585–1592) are undocumented. By 1592 he was in London, where a rival, Robert Greene, mocked him as an 'upstart Crow' who thought himself 'the only Shake-scene in a country.'"]],
  ["Career in London",[
    "Shakespeare was an actor, playwright, and shareholder in the Lord Chamberlain's Men, which became the King's Men when James I took the throne in 1603. The company performed at the Globe from 1599 and later at the indoor Blackfriars theater. He also published two narrative poems, Venus and Adonis and The Rape of Lucrece, dedicated to the Earl of Southampton.",
    "Shakespeare grew wealthy, bought New Place, one of the largest houses in Stratford, and retired there around 1613. He died on 23 April 1616, traditionally said to be his birthday, and was buried in Holy Trinity Church, Stratford. His will famously left his wife his 'second best bed.'"]],
  ["The First Folio",[
    "About 37 to 39 plays are attributed to Shakespeare, some written with collaborators such as John Fletcher and Thomas Middleton. In 1623, his fellow actors John Heminges and Henry Condell published the First Folio, collecting 36 plays, 18 of which had never been printed and might otherwise have been lost, including Macbeth, The Tempest, Twelfth Night, and Julius Caesar.",
    "Plays are grouped as comedies, histories, and tragedies, with critics later adding 'problem plays' and 'romances.'"]],
  ["The authorship question",[
    "Since the 19th century, some have claimed that someone else, such as Francis Bacon or Edward de Vere, Earl of Oxford, wrote the plays, often arguing that a glover's son lacked the education. Mainstream scholars reject these theories: contemporary documents, the First Folio's testimony, and stylistic evidence support Shakespeare's authorship, and Oxford died in 1604, before several plays were written.",
    "Grammar school education was rigorous, and many writers of the era came from modest backgrounds."]],
  ["Shakespeare's language",[
    "Shakespeare wrote mostly in blank verse, with prose for comic or lower-status characters and rhyme for songs, spells, and scene endings. He had an enormous vocabulary and is credited with first recorded uses of many words and phrases, such as 'swagger,' 'lonely,' 'break the ice,' 'wild-goose chase,' and 'the green-eyed monster,' though some were likely already in spoken use.",
    "His plays have been translated into every major language and are performed more than those of any other playwright."]]
  ],
  terms:[["First Folio","1623 collection of Shakespeare's plays."],["King's Men","Shakespeare's company under James I."],["Blank verse","Unrhymed iambic pentameter."],["Lost years","Undocumented period of Shakespeare's life."],["Authorship question","Disputed theories about who wrote the plays."]],
  w:"Knowing Shakespeare's life and theater explains how his plays were made and why they survived.",
  src:["William Shakespeare","First Folio","Shakespeare authorship question","Globe Theatre","Anne Hathaway (wife of Shakespeare)"],
  q:[
  ["Where was Shakespeare born?","Stratford-upon-Avon","London","Oxford","Canterbury"],
  ["Who published the First Folio in 1623?","John Heminges and Henry Condell","Ben Jonson","Anne Hathaway","James I"],
  ["Which rival called Shakespeare an 'upstart Crow'?","Robert Greene","Christopher Marlowe","Ben Jonson","Thomas Kyd"],
  ["What did Shakespeare famously leave his wife in his will?","His 'second best bed'","His house","His plays","Nothing"],
  ["What was Shakespeare's company called under James I?","The King's Men","The Admiral's Men","The Queen's Men","The Lord Chamberlain's Men"],
  ["What was the name of Shakespeare's son who died young?","Hamnet","Hamlet","Henry","John"]]},

{ t:"Shakespeare's Comedies and Histories", s:"Love, disguise, and kingship",
  sec:[
  ["The comedies",[
    "Shakespeare's comedies typically involve young lovers overcoming obstacles, confusion, disguise, and mistaken identity, often in a 'green world' such as a forest, ending in reconciliation and marriage. A Midsummer Night's Dream combines Athenian lovers lost in an enchanted wood, quarreling fairy royalty Oberon and Titania, the mischievous Puck, and workmen rehearsing a play; the weaver Bottom is given a donkey's head.",
    "Much Ado About Nothing features the sparring, witty lovers Beatrice and Benedick. As You Like It sends Rosalind, disguised as a young man, into the Forest of Arden, where the melancholy Jaques reflects that 'All the world's a stage.' Twelfth Night involves the shipwrecked twins Viola and Sebastian, a lovesick Duke, and the pompous steward Malvolio."]],
  ["Problem comedies",[
    "The Merchant of Venice, with the Jewish moneylender Shylock demanding a 'pound of flesh,' raises troubling questions of antisemitism and mercy; Shylock's speech 'Hath not a Jew eyes?' asserts shared humanity. The Taming of the Shrew provokes debate over gender roles. Measure for Measure and All's Well That Ends Well, called 'problem plays,' have dark moral complexities.",
    "Shakespeare's comic women, Rosalind, Beatrice, Viola, Portia, are often wiser and wittier than the men."]],
  ["The histories",[
    "Shakespeare's history plays dramatize English kings from Richard II to Henry VIII, drawing heavily on Raphael Holinshed's Chronicles. The 'second tetralogy' traces Richard II's deposition, the troubled reign of Henry IV, and the rise of Prince Hal, who carouses with the fat, witty knight Sir John Falstaff before becoming the heroic Henry V, rejecting Falstaff ('I know thee not, old man').",
    "Henry V includes the Saint Crispin's Day speech before Agincourt ('We few, we happy few, we band of brothers'). The 'first tetralogy' covers the Wars of the Roses, ending with Richard III, a charismatic villain who murders his way to the throne and dies crying 'A horse! a horse! my kingdom for a horse!'"]],
  ["Politics and history",[
    "The histories explore legitimacy, rebellion, the burdens of power, and national identity. Tudor ideology shaped them; Richard III's villainy served the Tudors who defeated him. Yet the plays also show the human cost of power and the gap between public roles and private selves.",
    "The Roman plays, Julius Caesar, Antony and Cleopatra, and Coriolanus, based on Plutarch, examine republican politics, rhetoric (Mark Antony's 'Friends, Romans, countrymen'), and ambition."]],
  ["Falstaff",[
    "Falstaff is one of Shakespeare's greatest creations: a cowardly, lying, drinking knight full of irresistible wit and vitality, who mocks honor as 'a word... air.' According to legend, Queen Elizabeth enjoyed him so much she asked to see Falstaff in love, resulting in The Merry Wives of Windsor.",
    "Verdi's opera Falstaff and Orson Welles's film Chimes at Midnight celebrate him."]]
  ],
  terms:[["Green world","Magical or rural setting of comic transformation."],["Problem play","Comedy with troubling moral complexity."],["Tetralogy","Group of four related plays."],["Holinshed's Chronicles","Main historical source for Shakespeare's histories."],["Falstaff","Shakespeare's great comic knight."]],
  w:"Shakespeare's comedies and histories reveal his wit, his understanding of love, and his insight into power.",
  src:["Shakespearean comedy","A Midsummer Night's Dream","Twelfth Night","Henry V (play)","Falstaff"],
  q:[
  ["Which character is given a donkey's head?","Bottom","Puck","Oberon","Lysander"],
  ["Which play features Beatrice and Benedick?","Much Ado About Nothing","As You Like It","Twelfth Night","The Tempest"],
  ["Who says 'We few, we happy few, we band of brothers'?","Henry V","Richard III","Prince Hal as Falstaff","Julius Caesar"],
  ["Who demands a 'pound of flesh'?","Shylock","Antonio","Malvolio","Iago"],
  ["Which play contains 'All the world's a stage'?","As You Like It","Hamlet","The Tempest","Macbeth"],
  ["Who cries 'my kingdom for a horse'?","Richard III","Henry IV","Richard II","Macbeth"]]},

{ t:"Shakespeare's Great Tragedies", s:"Hamlet, Othello, King Lear, Macbeth",
  sec:[
  ["Romeo and Juliet",[
    "Romeo and Juliet (about 1595), an early tragedy, tells of 'star-crossed lovers' from feuding Verona families, the Montagues and Capulets, who marry secretly and die through a chain of misfortunes. It contains the balcony scene ('O Romeo, Romeo, wherefore art thou Romeo?', meaning 'why are you Romeo,' a Montague) and the witty Mercutio's Queen Mab speech.",
    "Its intensity and youthful passion made it one of the most adapted stories ever, from West Side Story to ballets and films."]],
  ["Hamlet",[
    "Hamlet (about 1600), Shakespeare's longest play, follows Prince Hamlet of Denmark, ordered by his father's ghost to avenge his murder by Claudius, Hamlet's uncle, who has married his mother Gertrude and taken the throne. Hamlet's delays, feigned madness, and reflections, including the soliloquy 'To be, or not to be, that is the question,' make him the archetype of the introspective hero.",
    "He stages a play ('The Mousetrap') to 'catch the conscience of the king,' accidentally kills Polonius, and drives Ophelia toward madness and death. The play ends with nearly all the main characters dead. Hamlet is probably the most written-about work in literature."]],
  ["Othello",[
    "Othello, a Moorish general in Venice, marries Desdemona, a senator's daughter. His ensign Iago, resentful and endlessly manipulative, convinces him that Desdemona is unfaithful, using a handkerchief as false proof. Othello smothers her, discovers the truth, and kills himself.",
    "Iago, whose motives remain enigmatic (Coleridge spoke of his 'motive-hunting of a motiveless malignity'), is one of literature's great villains. The play's treatment of race, jealousy, and outsider status remains powerful."]],
  ["King Lear",[
    "King Lear divides his kingdom among his daughters according to their professions of love. Goneril and Regan flatter him; honest Cordelia refuses, and is banished. Rejected by the elder daughters, Lear goes mad on a stormy heath with his Fool and the disguised Edgar. A parallel plot shows the Earl of Gloucester betrayed by his illegitimate son Edmund and blinded.",
    "The ending, with Cordelia's death and Lear's grief ('Never, never, never, never, never'), is among the bleakest in literature; for over a century, audiences preferred Nahum Tate's 1681 version with a happy ending."]],
  ["Macbeth",[
    "Macbeth, a Scottish general, meets three witches who prophesy he will be king. Spurred by ambition and by his wife, Lady Macbeth ('unsex me here'), he murders King Duncan. Guilt and tyranny follow: Banquo's ghost appears at a feast; Lady Macbeth sleepwalks, trying to wash away imagined blood ('Out, damned spot!'). Macbeth reflects that life is 'a tale told by an idiot, full of sound and fury, signifying nothing.'",
    "Theater superstition calls it 'the Scottish play,' considering it bad luck to say its name in a theater. Its themes of ambition, guilt, and fate remain urgent."]],
  ["The tragic vision",[
    "Shakespeare's tragedies combine poetry, psychological depth, and moral complexity. Critic A. C. Bradley's Shakespearean Tragedy (1904) emphasized tragic flaws in character; later critics stress politics, language, and staging.",
    "Antony and Cleopatra, Coriolanus, Julius Caesar, and Timon of Athens extend his tragic range."]]
  ],
  terms:[["Star-crossed","Ill-fated, from Romeo and Juliet."],["To be, or not to be","Hamlet's soliloquy on existence."],["Iago","Othello's manipulative ensign."],["The Scottish play","Theater name for Macbeth."],["Tragic flaw","Character weakness leading to downfall."]],
  w:"Shakespeare's tragedies are among the deepest explorations of human nature ever written.",
  src:["Hamlet","Othello","King Lear","Macbeth","Romeo and Juliet"],
  q:[
  ["Who murders Hamlet's father?","Claudius","Polonius","Laertes","Fortinbras"],
  ["What false proof does Iago use against Desdemona?","A handkerchief","A letter","A ring","A portrait"],
  ["Which daughter refuses to flatter King Lear?","Cordelia","Goneril","Regan","Ophelia"],
  ["Who sleepwalks saying 'Out, damned spot!'?","Lady Macbeth","Ophelia","Gertrude","Desdemona"],
  ["What does 'wherefore art thou Romeo' mean?","Why are you Romeo","Where are you Romeo","How are you Romeo","Who are you Romeo"],
  ["Who described Iago's 'motiveless malignity'?","Samuel Taylor Coleridge","Samuel Johnson","A. C. Bradley","Harold Bloom"]]},

{ t:"The Romances and the Sonnets", s:"Late plays and lyric genius",
  sec:[
  ["The late romances",[
    "In his final years, Shakespeare wrote 'romances' (a later critical label): Pericles, Cymbeline, The Winter's Tale, and The Tempest. These plays feature long separations, journeys, lost children, apparent deaths, and miraculous reunions and forgiveness, blending tragedy and comedy.",
    "In The Winter's Tale, King Leontes's insane jealousy destroys his family; sixteen years later, his lost daughter Perdita is found, and a statue of his wife Hermione comes to life. It contains the famous stage direction 'Exit, pursued by a bear.'"]],
  ["The Tempest",[
    "The Tempest (about 1611), possibly Shakespeare's last solo play, is set on an island where Prospero, the exiled Duke of Milan and a magician, controls the spirit Ariel and the enslaved Caliban. He raises a storm to bring his enemies ashore, arranges his daughter Miranda's marriage to Ferdinand ('O brave new world, that has such people in't!'), and ultimately forgives his enemies and renounces his magic.",
    "Many have read Prospero's farewell, 'Our revels now are ended... We are such stuff as dreams are made on,' as Shakespeare's farewell to the stage. Postcolonial writers such as Aimé Césaire (Une Tempête) reinterpreted Caliban as a colonized subject."]],
  ["The sonnets",[
    "Shakespeare's 154 sonnets, published in 1609, are among the greatest love poems in English. Sonnets 1–126 address a beautiful young man (the 'Fair Youth'), urging him to marry and have children, then promising to immortalize him in verse ('So long as men can breathe or eyes can see, / So long lives this, and this gives life to thee'). Sonnets 127–154 concern a 'Dark Lady,' an unidealized, sensual mistress.",
    "The sonnets explore time, beauty, mortality, jealousy, and art's power to outlast death. The identities of the Fair Youth, the Dark Lady, a 'Rival Poet,' and the 'Mr. W. H.' of the dedication remain mysteries."]],
  ["Famous sonnets",[
    "Sonnet 18 ('Shall I compare thee to a summer's day?') celebrates the beloved's eternal beauty in verse. Sonnet 116 ('Let me not to the marriage of true minds / Admit impediments') defines love as constant. Sonnet 130 ('My mistress' eyes are nothing like the sun') mocks conventional praise. Sonnet 73 ('That time of year thou mayst in me behold') meditates on aging.",
    "The sonnets' complex arguments, wordplay, and emotional range rewarded centuries of interpretation."]],
  ["Shakespeare's afterlife",[
    "Shakespeare's reputation grew steadily: 18th-century critics such as Samuel Johnson praised his 'just representations of general nature'; actor David Garrick's 1769 Jubilee made him a national icon; Romantics revered him as a genius. Today his plays are performed worldwide, adapted into films (from Kurosawa's Throne of Blood, based on Macbeth, to The Lion King, echoing Hamlet), and taught in schools globally.",
    "Ben Jonson's prediction that he was 'for all time' has proved true."]]
  ],
  terms:[["Romance","Shakespeare's late plays of loss and reunion."],["Prospero","Magician-duke of The Tempest."],["Fair Youth","Young man addressed in Sonnets 1–126."],["Dark Lady","Mistress of Sonnets 127–154."],["Bardolatry","Excessive worship of Shakespeare."]],
  w:"Shakespeare's late plays and sonnets show his range from forgiveness and wonder to intimate lyric passion.",
  src:["The Tempest","The Winter's Tale","Shakespeare's sonnets","Sonnet 18","Shakespeare's late romances"],
  q:[
  ["Which play contains the stage direction 'Exit, pursued by a bear'?","The Winter's Tale","The Tempest","Cymbeline","Pericles"],
  ["Who is the magician in The Tempest?","Prospero","Ariel","Caliban","Oberon"],
  ["How many sonnets did Shakespeare publish?","154","100","126","200"],
  ["Which sonnet begins 'Shall I compare thee to a summer's day?'","Sonnet 18","Sonnet 116","Sonnet 130","Sonnet 73"],
  ["Who exclaims 'O brave new world'?","Miranda","Ariel","Prospero","Ferdinand"],
  ["Which writer reinterpreted The Tempest from Caliban's perspective?","Aimé Césaire","Chinua Achebe","Derek Walcott","Jean Rhys"]]}

);


/* ---- from lit-09.js ---- */
/* LITERATURE FOUNDATIONS, part 9: Unit 4 chapters 10-13 */
COURSES.literature.units[3].ch.push(

{ t:"Donne and the Metaphysical Poets", s:"Wit, passion, and devotion",
  sec:[
  ["John Donne",[
    "John Donne (1572–1631), raised Catholic in Protestant England, wrote daring love poems in his youth and later became an Anglican priest and Dean of St Paul's Cathedral, famous for his sermons. His secret marriage to Anne More cost him his career for years; he reportedly summed it up as 'John Donne, Anne Donne, Un-done.'",
    "His love poems, such as 'The Flea' (in which a flea that has bitten both lovers becomes an argument for sleeping together) and 'The Sun Rising' ('Busy old fool, unruly sun'), are dramatic, argumentative, and witty. 'A Valediction: Forbidding Mourning' compares separated lovers to the two legs of a drawing compass."]],
  ["Holy Sonnets and Meditations",[
    "Donne's Holy Sonnets wrestle with sin, death, and God: 'Death, be not proud' declares that death itself shall die; 'Batter my heart, three-personed God' asks God to overwhelm him by force. His prose Devotions upon Emergent Occasions (1624), written during serious illness, contains the famous passage 'No man is an island... never send to know for whom the bell tolls; it tolls for thee.'",
    "Donne's mix of intellect and emotion was neglected in the 18th and 19th centuries, then championed by T. S. Eliot in the 1920s."]],
  ["The metaphysical style",[
    "Samuel Johnson coined the term 'metaphysical poets' critically, complaining that in their verse 'the most heterogeneous ideas are yoked by violence together.' Their hallmarks include the metaphysical conceit (an elaborate, surprising comparison drawn from science, law, or theology), colloquial and dramatic openings, argument, paradox, and fusion of thought and feeling.",
    "Eliot praised them for a 'unified sensibility' that later poets lost."]],
  ["Herbert, Marvell, and others",[
    "George Herbert (1593–1633), a country parson, wrote devotional poems collected in The Temple, including 'Love (III)' and pattern poems shaped like their subjects ('Easter Wings,' 'The Altar'). Andrew Marvell (1621–1678) wrote 'To His Coy Mistress,' a witty carpe diem argument ('Had we but world enough and time... But at my back I always hear / Time's wingèd chariot hurrying near'), and 'The Garden.'",
    "Other poets of the period include Richard Crashaw, Henry Vaughan, and the 'Cavalier poets' such as Robert Herrick ('Gather ye rosebuds while ye may') and Richard Lovelace ('Stone walls do not a prison make')."]],
  ["Women poets",[
    "Aemilia Lanyer's Salve Deus Rex Judaeorum (1611) defended Eve and women, and is among the first books of original poetry published by an Englishwoman. Lady Mary Wroth wrote the first sonnet sequence by an Englishwoman, and Katherine Philips ('the Matchless Orinda') wrote poems celebrating female friendship.",
    "In colonial America, Anne Bradstreet's The Tenth Muse (1650) made her the first published poet in the English colonies."]]
  ],
  terms:[["Metaphysical conceit","Elaborate, surprising comparison."],["Holy Sonnets","Donne's devotional sonnets."],["Carpe diem poem","Poem urging enjoyment of the present."],["Pattern poem","Poem shaped like its subject."],["Cavalier poets","Royalist lyric poets of the 17th century."]],
  w:"Donne and the Metaphysicals fused intellect and passion in ways that transformed English poetry.",
  src:["John Donne","Metaphysical poets","George Herbert","To His Coy Mistress","Anne Bradstreet"],
  q:[
  ["Which Donne poem uses a flea as an argument for love?","The Flea","The Sun Rising","The Canonization","Air and Angels"],
  ["Who wrote 'No man is an island'?","John Donne","George Herbert","Andrew Marvell","John Milton"],
  ["Who coined the term 'metaphysical poets'?","Samuel Johnson","T. S. Eliot","John Dryden","Alexander Pope"],
  ["Which poem contains 'Had we but world enough and time'?","To His Coy Mistress","The Garden","Easter Wings","Death, be not proud"],
  ["Who wrote pattern poems like 'Easter Wings'?","George Herbert","Henry Vaughan","Robert Herrick","Richard Crashaw"],
  ["Who was the first published poet in the English American colonies?","Anne Bradstreet","Phillis Wheatley","Edward Taylor","Mary Rowlandson"]]},

{ t:"Milton and Paradise Lost", s:"Justifying the ways of God to men",
  sec:[
  ["Milton's life",[
    "John Milton (1608–1674), a brilliant scholar of languages, wrote early poems including 'L'Allegro,' 'Il Penseroso,' and the elegy 'Lycidas.' During the English Civil War he served the Puritan Commonwealth as Latin Secretary under Oliver Cromwell and wrote prose pamphlets defending the execution of Charles I, divorce, and freedom of the press.",
    "His Areopagitica (1644) argued against government licensing of books: 'Who kills a man kills a reasonable creature... but he who destroys a good book, kills reason itself.' By 1652 he was totally blind; after the Restoration of Charles II in 1660 he was briefly imprisoned and narrowly escaped execution."]],
  ["Paradise Lost",[
    "Blind and in political defeat, Milton dictated Paradise Lost (1667; revised 1674), an epic in twelve books of blank verse. Its stated aim is to 'justify the ways of God to men.' It tells of Satan's rebellion and fall from Heaven, his journey to Earth, his temptation of Eve in the Garden of Eden, and the Fall of Adam and Eve, ending with their departure from Paradise: 'The world was all before them... hand in hand with wandering steps and slow, / Through Eden took their solitary way.'",
    "The epic draws on Homer, Virgil, the Bible, and classical and Renaissance learning, and its long, Latinate sentences create a grand style."]],
  ["Satan",[
    "Milton's Satan is the poem's most dramatic character: defiant, eloquent, and tragic, declaring 'Better to reign in Hell, than serve in Heaven' and 'The mind is its own place, and in itself / Can make a Heaven of Hell, a Hell of Heaven.' The Romantic poet William Blake wrote that Milton 'was of the Devil's party without knowing it,' and Percy Shelley admired Satan as a rebel.",
    "Other critics argue that Satan's grandeur gradually degrades, as he shrinks into a toad and a serpent, revealing the hollowness of pride."]],
  ["Adam and Eve",[
    "Milton portrays Adam and Eve's love, conversation, and work in Eden with tenderness, and their fall with psychological depth: Eve is persuaded by the serpent's arguments; Adam eats the fruit knowingly, out of love for her. After mutual blame, they reconcile and repent, and the archangel Michael shows Adam the future of humanity and redemption.",
    "The poem's treatment of gender hierarchy has been widely debated by feminist critics."]],
  ["Later works and influence",[
    "Milton also wrote Paradise Regained, about Christ's temptation in the wilderness, and Samson Agonistes, a tragedy about the blind Samson's final act. His sonnet on his blindness ends 'They also serve who only stand and wait.'",
    "Paradise Lost influenced Pope, the Romantics, Mary Shelley's Frankenstein (whose creature reads it), and Philip Pullman's His Dark Materials, whose title comes from the poem."]]
  ],
  terms:[["Paradise Lost","Milton's epic of the Fall."],["Areopagitica","Milton's defense of press freedom."],["Grand style","Elevated, Latinate epic style."],["Restoration","Return of the monarchy in 1660."],["Epic invocation","Opening call to a Muse."]],
  w:"Paradise Lost is the greatest English epic, raising questions about freedom, rebellion, and faith.",
  src:["John Milton","Paradise Lost","Areopagitica","Satan (Paradise Lost)","Samson Agonistes"],
  q:[
  ["What does Paradise Lost aim to do, in Milton's words?","Justify the ways of God to men","Celebrate England","Mock the king","Retell Homer"],
  ["Who says 'Better to reign in Hell, than serve in Heaven'?","Satan","Adam","Beelzebub","Michael"],
  ["Which Milton work defends freedom of the press?","Areopagitica","Lycidas","Samson Agonistes","Il Penseroso"],
  ["Who said Milton 'was of the Devil's party without knowing it'?","William Blake","Percy Shelley","Samuel Johnson","T. S. Eliot"],
  ["In what verse form is Paradise Lost written?","Blank verse","Rhymed couplets","Terza rima","Spenserian stanzas"],
  ["Which modern trilogy takes its title from Paradise Lost?","His Dark Materials","The Lord of the Rings","Narnia","Earthsea"]]},

{ t:"French Classicism", s:"Molière, Racine, and the age of Louis XIV",
  sec:[
  ["The classical ideal",[
    "Under Louis XIV (reigned 1643–1715), French literature pursued classical ideals of order, clarity, reason, and decorum. The Académie française, founded in 1635 by Cardinal Richelieu, regulated the French language. Dramatists followed the 'three unities' of action, time (a single day), and place.",
    "This 'Grand Siècle' (great century) made French the prestige language of European culture."]],
  ["Corneille",[
    "Pierre Corneille (1606–1684) wrote Le Cid (1637), a tragicomedy about Rodrigue, who must choose between love for Chimène and duty to avenge his father against her father; its success sparked the 'Quarrel of Le Cid' over classical rules. His heroes are noble figures who choose duty and glory over passion.",
    "His tragedies Horace, Cinna, and Polyeucte developed this heroic ideal."]],
  ["Racine",[
    "Jean Racine (1639–1699) wrote tragedies of passion in perfect alexandrine verse with a small vocabulary and intense psychological focus. In Phèdre (1677), the queen Phèdre is consumed by forbidden love for her stepson Hippolytus, leading to his death and her suicide. Andromaque and Britannicus are also masterpieces.",
    "Racine's characters are destroyed by passions they cannot control, reflecting the Jansenist Catholic belief in human weakness without grace."]],
  ["Molière",[
    "Molière (Jean-Baptiste Poquelin, 1622–1673), actor-manager and France's greatest comic dramatist, satirized hypocrisy and folly. Tartuffe (1664) exposes a religious hypocrite who deceives a credulous family man; it was banned for years by religious authorities. The Misanthrope portrays Alceste, who despises social falsity; The Miser, The Imaginary Invalid, and The Bourgeois Gentleman mock greed, hypochondria, and social climbing.",
    "Molière collapsed while performing the title role of The Imaginary Invalid and died hours later. French is sometimes called 'la langue de Molière.'"]],
  ["Fables, maxims, and the first psychological novel",[
    "Jean de La Fontaine's Fables (1668–94), verse retellings of Aesop and others ('The Grasshopper and the Ant,' 'The Fox and the Crow'), are learned by French schoolchildren. La Rochefoucauld's Maxims distilled cynical insights ('Our virtues are most often only vices in disguise'); Blaise Pascal's Pensées meditated on faith ('The heart has its reasons which reason knows nothing of').",
    "Madame de La Fayette's The Princess of Clèves (1678), about a married woman who resists her passion for a duke, is considered the first French psychological novel. Charles Perrault's Tales of Mother Goose (1697) fixed the classic versions of 'Cinderella,' 'Sleeping Beauty,' 'Little Red Riding Hood,' and 'Puss in Boots.'"]]
  ],
  terms:[["Three unities","Rules of action, time, and place in drama."],["Alexandrine","Twelve-syllable French verse line."],["Académie française","French language academy founded 1635."],["Tartuffe","Molière's religious hypocrite."],["Maxim","Short statement of a general truth."]],
  w:"French classicism produced masterpieces of tragedy, comedy, and psychological insight that shaped European taste.",
  src:["Molière","Jean Racine","Pierre Corneille","Jean de La Fontaine","The Princess of Clèves"],
  q:[
  ["Which Molière play exposes a religious hypocrite?","Tartuffe","The Misanthrope","The Miser","The Imaginary Invalid"],
  ["Who wrote Phèdre?","Racine","Corneille","Molière","La Fontaine"],
  ["Which play sparked a quarrel over classical rules in 1637?","Le Cid","Phèdre","Tartuffe","Horace"],
  ["Who wrote 'The heart has its reasons which reason knows nothing of'?","Blaise Pascal","La Rochefoucauld","Descartes","Montaigne"],
  ["Which novel is considered the first French psychological novel?","The Princess of Clèves","Candide","Les Liaisons dangereuses","Manon Lescaut"],
  ["Who fixed classic versions of 'Cinderella' and 'Sleeping Beauty' in 1697?","Charles Perrault","La Fontaine","the Brothers Grimm","Hans Christian Andersen"]]},

{ t:"The Restoration", s:"Dryden, Behn, Bunyan, and the diarists",
  sec:[
  ["Restoration theater",[
    "When Charles II returned in 1660, the theaters reopened, and for the first time women acted professionally on the English stage. Restoration comedy was witty, sexually frank, and satirical of fashionable society: William Wycherley's The Country Wife, George Etherege's The Man of Mode, and later William Congreve's The Way of the World (1700).",
    "Heroic tragedy, with grand verse and noble conflicts, was also popular."]],
  ["Dryden",[
    "John Dryden (1631–1700), the first official Poet Laureate (1668), dominated the age as poet, dramatist, critic, and translator. His satire Absalom and Achitophel (1681) used a biblical story to attack political enemies; Mac Flecknoe mocked a rival poet as the heir of dullness. His Essay of Dramatic Poesy discussed English and French drama, and his translation of Virgil was celebrated.",
    "Dryden perfected the heroic couplet, rhymed iambic pentameter couplets, which dominated English poetry for the next century."]],
  ["Aphra Behn",[
    "Aphra Behn (1640–1689), possibly a former spy for Charles II in Antwerp, was among the first Englishwomen to earn a living by writing. She wrote popular comedies such as The Rover and the short novel Oroonoko (1688), about an enslaved African prince in Surinam, an early literary treatment of slavery.",
    "Virginia Woolf wrote that 'all women together ought to let flowers fall upon the tomb of Aphra Behn... for it was she who earned them the right to speak their minds.'"]],
  ["Bunyan",[
    "John Bunyan (1628–1688), a Puritan tinker and preacher imprisoned for 12 years for unlicensed preaching, wrote The Pilgrim's Progress (1678), an allegory of the Christian journey. Christian travels from the City of Destruction to the Celestial City, passing through the Slough of Despond and Vanity Fair, and meeting characters such as Mr. Worldly Wiseman and Giant Despair.",
    "It became one of the most widely read books in English, translated into over 200 languages, and influenced the novel's development."]],
  ["Diaries and science",[
    "Samuel Pepys (1633–1703), a naval administrator, kept a diary (1660–69) in shorthand describing the Great Plague of 1665, the Great Fire of London in 1666, court gossip, theater-going, and his own affairs with candor. John Evelyn also kept a valuable diary.",
    "The founding of the Royal Society (1660) encouraged plain, clear prose for science, influencing English style."]]
  ],
  terms:[["Restoration comedy","Witty, frank comedy after 1660."],["Heroic couplet","Rhymed pairs of iambic pentameter lines."],["Poet Laureate","Official national poet; Dryden first, 1668."],["Pilgrim's Progress","Bunyan's Christian allegory."],["Oroonoko","Behn's story of an enslaved prince."]],
  w:"The Restoration revived theater, launched professional women writers, and produced lasting satire and allegory.",
  src:["Restoration comedy","John Dryden","Aphra Behn","The Pilgrim's Progress","Samuel Pepys"],
  q:[
  ["Who was England's first official Poet Laureate?","John Dryden","Ben Jonson","John Milton","Alexander Pope"],
  ["Which Aphra Behn work concerns an enslaved African prince?","Oroonoko","The Rover","The Country Wife","Love-Letters"],
  ["Who wrote The Pilgrim's Progress?","John Bunyan","John Milton","Daniel Defoe","John Dryden"],
  ["Whose diary describes the Great Fire of London?","Samuel Pepys","John Evelyn","Daniel Defoe","Aphra Behn"],
  ["What changed on the English stage after 1660?","Women acted professionally","Plays were banned","Only tragedies were allowed","Theaters moved indoors only"],
  ["Which Congreve comedy appeared in 1700?","The Way of the World","The Country Wife","The Man of Mode","The Rover"]]}

);


/* ---- from lit-10.js ---- */
/* LITERATURE FOUNDATIONS, part 10: Unit 5 Enlightenment and Romanticism, chapters 1-4 */
COURSES.literature.units.push({ t:"Enlightenment and Romanticism", ch:[

{ t:"The Age of Satire: Swift, Pope, and Voltaire", s:"Reason and ridicule",
  sec:[
  ["The Enlightenment",[
    "The Enlightenment of the late 17th and 18th centuries championed reason, science, tolerance, and skepticism toward tradition and authority. Its writers used wit and satire to expose folly, superstition, and injustice. Coffeehouses, periodicals such as Joseph Addison and Richard Steele's The Spectator (1711–12), and salons spread ideas to a growing reading public.",
    "Neoclassical writers admired Roman models, especially Horace and Juvenal, valuing order, balance, and correctness."]],
  ["Jonathan Swift",[
    "Jonathan Swift (1667–1745), an Anglo-Irish clergyman and Dean of St Patrick's Cathedral in Dublin, was the greatest prose satirist in English. Gulliver's Travels (1726) sends ship's surgeon Lemuel Gulliver to Lilliput (tiny people whose petty politics mirror England's, with wars over which end to break an egg), Brobdingnag (giants who find European civilization appalling), the flying island of Laputa (absurd scientists), and the land of the Houyhnhnms, rational horses who rule over the brutish human-like Yahoos.",
    "A Modest Proposal (1729) ironically proposes that poor Irish families sell their babies as food for the rich, a savage attack on English policy and indifference to Irish poverty, and the classic example of deadpan satire."]],
  ["Alexander Pope",[
    "Alexander Pope (1688–1744), small and disabled by a childhood illness and barred from university as a Catholic, became the dominant poet of his age, master of the heroic couplet. His Essay on Criticism gave us 'To err is human, to forgive divine' and 'A little learning is a dangerous thing'; An Essay on Man declared 'Whatever is, is right.'",
    "The Rape of the Lock (1712–14) is a mock-epic about a real quarrel after a young lord snipped a lock of a lady's hair, treating it with Homeric grandeur. The Dunciad satirized dull writers. Pope's translations of Homer made him financially independent, one of the first English poets to live by writing."]],
  ["Voltaire",[
    "Voltaire (François-Marie Arouet, 1694–1778) was the most famous writer of the French Enlightenment, a tireless campaigner against religious intolerance and injustice. Imprisoned in the Bastille and exiled, he spent years in England, admiring its relative freedom, and later lived near the Swiss border.",
    "His satirical novella Candide (1759) follows a naive young man whose tutor Pangloss insists 'all is for the best in the best of all possible worlds,' mocking the philosopher Leibniz's optimism, as Candide endures war, earthquake (the 1755 Lisbon earthquake), the Inquisition, and slavery. It ends with the practical advice 'we must cultivate our garden.' Voltaire also fought for justice in the Calas affair, defending a Protestant family wrongly persecuted."]],
  ["Other Enlightenment writers",[
    "Montesquieu's Persian Letters satirized France through the eyes of Persian visitors. Denis Diderot edited the Encyclopédie and wrote the experimental novel Jacques the Fatalist. Jean-Jacques Rousseau's Julie, or the New Heloise, Émile, and Confessions celebrated feeling and nature, anticipating Romanticism.",
    "In England, Samuel Johnson and the essayists continued the tradition of moral and critical prose."]]
  ],
  terms:[["Satire","Using humor and irony to criticize folly or vice."],["Mock-epic","Treating a trivial subject in epic style."],["Heroic couplet","Rhymed iambic pentameter pairs."],["Candide","Voltaire's satire of optimism."],["Neoclassicism","Style modeled on classical ideals."]],
  w:"Enlightenment satire showed how wit can attack injustice, and its classics remain sharply funny.",
  src:["Gulliver's Travels","A Modest Proposal","Alexander Pope","Candide","Voltaire"],
  q:[
  ["Where are the inhabitants tiny in Gulliver's Travels?","Lilliput","Brobdingnag","Laputa","Houyhnhnmland"],
  ["What does A Modest Proposal ironically suggest?","Selling poor babies as food for the rich","Abolishing Parliament","Planting more potatoes","Moving Ireland to America"],
  ["Who wrote 'To err is human, to forgive divine'?","Alexander Pope","Jonathan Swift","John Dryden","Samuel Johnson"],
  ["What philosophy does Candide mock?","Leibniz's optimism","Stoicism","Puritanism","Skepticism"],
  ["How does Candide end?","'We must cultivate our garden'","With Candide's death","With a wedding feast","With a war"],
  ["Which Pope poem is a mock-epic about a stolen lock of hair?","The Rape of the Lock","The Dunciad","An Essay on Man","Windsor-Forest"]]},

{ t:"The Rise of the English Novel", s:"Defoe, Richardson, Fielding, Sterne",
  sec:[
  ["Why the novel rose",[
    "The novel became the dominant English literary form in the 18th century. Historian Ian Watt's The Rise of the Novel (1957) linked it to a growing middle class, increased literacy (especially among women), individualism, Protestant self-examination, and 'formal realism,' detailed depictions of ordinary people in specific times and places.",
    "Circulating libraries and cheaper printing helped create a mass readership."]],
  ["Daniel Defoe",[
    "Daniel Defoe (about 1660–1731), a merchant, journalist, and government agent, wrote Robinson Crusoe (1719), presented as the true memoir of a castaway who spends 28 years on an island, building a life through practical labor, faith, and later his relationship with Friday, whom he rescues and makes his servant. Inspired partly by the real castaway Alexander Selkirk, it became one of the most translated books ever.",
    "Moll Flanders (1722) is the first-person story of a woman who survives as a thief and through multiple marriages, and A Journal of the Plague Year (1722) is a vivid semi-fictional account of 1665 London."]],
  ["Samuel Richardson",[
    "Samuel Richardson (1689–1761), a printer, wrote epistolary novels told in letters. Pamela (1740) tells of a servant girl who resists her master's advances and is rewarded by marriage, a huge bestseller that sparked parodies. Clarissa (1747–48), one of the longest novels in English, is a tragic story of a virtuous young woman abused by the libertine Lovelace.",
    "Richardson's letter technique gave readers intimate access to characters' thoughts."]],
  ["Henry Fielding",[
    "Henry Fielding (1707–1754), playwright and magistrate who helped found London's first police force (the Bow Street Runners), parodied Pamela in Shamela and Joseph Andrews. His masterpiece Tom Jones (1749) follows a good-hearted foundling's comic adventures through English society, narrated by a witty, intrusive narrator who addresses readers directly.",
    "Fielding called his work a 'comic epic poem in prose,' contrasting his panoramic, humorous approach with Richardson's intense moral psychology."]],
  ["Laurence Sterne and others",[
    "Laurence Sterne's Tristram Shandy (1759–67) is a wildly experimental novel in which the narrator, trying to tell his life story, keeps digressing so that he isn't born until Volume 3. It includes a black page mourning a character, a marbled page, squiggly lines charting the plot, and blank pages for readers to draw on, anticipating modernism and postmodernism.",
    "Tobias Smollett wrote picaresque novels; Oliver Goldsmith wrote The Vicar of Wakefield; and Frances Burney's Evelina (1778) and Cecilia, novels of a young woman entering society, influenced Jane Austen."]]
  ],
  terms:[["Formal realism","Detailed depiction of ordinary life."],["Epistolary novel","Novel told in letters."],["Robinson Crusoe","Defoe's castaway novel."],["Intrusive narrator","Narrator who comments directly to readers."],["Tristram Shandy","Sterne's experimental, digressive novel."]],
  w:"The 18th-century novel invented realistic fiction about ordinary lives, the form that dominates literature today.",
  src:["Robinson Crusoe","Pamela; or, Virtue Rewarded","The History of Tom Jones, a Foundling","Tristram Shandy","The Rise of the Novel"],
  q:[
  ["Who wrote Robinson Crusoe?","Daniel Defoe","Henry Fielding","Samuel Richardson","Jonathan Swift"],
  ["In what form is Pamela written?","Letters","Diary entries","Verse","Dialogue"],
  ["Which novel has a black page and digresses so the narrator is born late?","Tristram Shandy","Tom Jones","Clarissa","Moll Flanders"],
  ["Who called his novel a 'comic epic poem in prose'?","Henry Fielding","Laurence Sterne","Daniel Defoe","Tobias Smollett"],
  ["Who wrote The Rise of the Novel (1957)?","Ian Watt","F. R. Leavis","E. M. Forster","Raymond Williams"],
  ["Which Frances Burney novel influenced Jane Austen?","Evelina","Pamela","Joseph Andrews","Clarissa"]]},

{ t:"The Age of Johnson", s:"Dictionaries, biography, and conversation",
  sec:[
  ["Samuel Johnson",[
    "Samuel Johnson (1709–1784), son of a Lichfield bookseller, overcame poverty, illness, and depression to become the leading man of letters in 18th-century England. He wrote poetry ('The Vanity of Human Wishes'), essays in The Rambler and The Idler, the philosophical tale Rasselas (1759), written in a week to pay for his mother's funeral, and Lives of the Poets, biographical and critical studies of English poets.",
    "His edition of Shakespeare (1765), with a famous preface, defended Shakespeare against neoclassical critics."]],
  ["The Dictionary",[
    "Johnson's A Dictionary of the English Language (1755), compiled over about nine years with a few assistants, defined some 42,000 words, illustrated with over 100,000 quotations from English literature. Though not the first English dictionary, it was the most authoritative until the Oxford English Dictionary.",
    "Some definitions show his humor: 'Lexicographer: a writer of dictionaries; a harmless drudge' and 'Oats: a grain, which in England is generally given to horses, but in Scotland supports the people.'"]],
  ["Boswell's Life of Johnson",[
    "James Boswell (1740–1795), a young Scottish lawyer, met Johnson in 1763 and recorded his conversations obsessively. His Life of Samuel Johnson (1791) is often called the greatest biography in English, capturing Johnson's wit: 'When a man is tired of London, he is tired of life' and 'Patriotism is the last refuge of a scoundrel.'",
    "Boswell's own journals, discovered in the 20th century, revealed him as a vivid diarist."]],
  ["The Club and the circle",[
    "Johnson's 'Literary Club' (founded 1764) included painter Joshua Reynolds, statesman Edmund Burke, actor David Garrick, Oliver Goldsmith, and historian Edward Gibbon, whose The History of the Decline and Fall of the Roman Empire (1776–89) is a masterpiece of ironic historical prose.",
    "Richard Brinsley Sheridan's comedies The Rivals (introducing Mrs. Malaprop, who misuses words, giving us 'malapropism') and The School for Scandal, and Goldsmith's She Stoops to Conquer, revived stage comedy."]],
  ["Graveyard poets and sensibility",[
    "Mid-century poets turned toward melancholy and feeling. Thomas Gray's 'Elegy Written in a Country Churchyard' (1751) honors the obscure villagers buried there ('Full many a flower is born to blush unseen'). The 'cult of sensibility' valued emotional responsiveness, seen in Henry Mackenzie's The Man of Feeling.",
    "James Macpherson's Ossian poems (1760s), claimed as translations of an ancient Scottish bard but largely invented, and Thomas Chatterton's forged medieval poems fed a taste for the past and the primitive that led to Romanticism."]]
  ],
  terms:[["Dictionary of the English Language","Johnson's 1755 dictionary."],["Life of Johnson","Boswell's great biography."],["Malapropism","Comic misuse of a similar-sounding word."],["Sensibility","18th-century cult of emotional responsiveness."],["Ossian","Invented 'ancient' Scottish poems by Macpherson."]],
  w:"Johnson's age shaped the English dictionary, biography, and criticism, and prepared the ground for Romanticism.",
  src:["Samuel Johnson","A Dictionary of the English Language","Life of Samuel Johnson","Elegy Written in a Country Churchyard","Ossian"],
  q:[
  ["When was Johnson's Dictionary published?","1755","1700","1791","1828"],
  ["How did Johnson define 'lexicographer'?","A harmless drudge","A learned scholar","A master of words","A useless man"],
  ["Who wrote the Life of Samuel Johnson?","James Boswell","Edmund Burke","Oliver Goldsmith","Edward Gibbon"],
  ["Who said 'When a man is tired of London, he is tired of life'?","Samuel Johnson","James Boswell","David Garrick","Joshua Reynolds"],
  ["Which character gave us the word 'malapropism'?","Mrs. Malaprop","Lady Teazle","Mr. Hardcastle","Tony Lumpkin"],
  ["Who wrote 'Elegy Written in a Country Churchyard'?","Thomas Gray","William Collins","Oliver Goldsmith","Edward Young"]]},

{ t:"Goethe and German Literature", s:"Sturm und Drang to Weimar Classicism",
  sec:[
  ["Sturm und Drang",[
    "In the 1770s, young German writers launched Sturm und Drang ('Storm and Stress'), rebelling against Enlightenment rationalism in favor of passion, nature, individual genius, and national folk culture. Johann Gottfried Herder championed folk songs and the idea that each people has its own spirit, influencing nationalism and folklore collecting.",
    "Gotthold Ephraim Lessing had earlier developed German drama and criticism; his play Nathan the Wise (1779) is a plea for religious tolerance."]],
  ["Werther",[
    "Johann Wolfgang von Goethe (1749–1832) became famous with The Sorrows of Young Werther (1774), an epistolary novel about a sensitive young man who falls hopelessly in love with Lotte, who is engaged to another, and finally shoots himself. It caused a sensation across Europe: young men dressed like Werther in blue coats and yellow waistcoats, and it was blamed for imitative suicides (the 'Werther effect').",
    "Napoleon reportedly read it seven times and discussed it with Goethe in 1808."]],
  ["Goethe the universal genius",[
    "Goethe settled in the small duchy of Weimar, serving as minister, theater director, and scientist (studying color theory, botany, and anatomy). His novel Wilhelm Meister's Apprenticeship became the model Bildungsroman. He wrote lyric poems ('Erlkönig,' set by Schubert) and late in life the West-Eastern Divan, inspired by the Persian poet Hafez, and coined the idea of Weltliteratur, 'world literature.'",
    "With his friend Friedrich Schiller he developed Weimar Classicism, seeking harmony and humanity inspired by ancient Greece."]],
  ["Faust",[
    "Goethe worked on Faust for nearly sixty years. In Part One (1808), the scholar Faust, despairing of knowledge, makes a pact with the devil Mephistopheles: if Faust ever finds a moment so satisfying that he wishes it to last ('Stay, you are so beautiful'), Mephistopheles may take his soul. Faust seduces the innocent Gretchen, who is destroyed, condemned for killing her child, but saved by heaven.",
    "Part Two (published 1832, after Goethe's death) is a vast, symbolic drama including classical mythology, Helen of Troy, and Faust's grand land-reclamation project; ultimately Faust is saved through striving and divine love. Faust is the central work of German literature."]],
  ["Schiller and the Romantics",[
    "Friedrich Schiller (1759–1805) wrote dramas of freedom and history: The Robbers, Don Carlos, Mary Stuart, and William Tell, about the Swiss hero who shoots an apple from his son's head. His poem 'Ode to Joy' became the finale of Beethoven's Ninth Symphony.",
    "German Romanticism followed: Novalis, Friedrich Hölderlin's visionary odes, E. T. A. Hoffmann's uncanny tales (including The Nutcracker and the Mouse King), Heinrich Heine's ironic lyrics, and the Brothers Grimm's Children's and Household Tales (1812), collecting folktales such as 'Hansel and Gretel' and 'Snow White.'"]]
  ],
  terms:[["Sturm und Drang","'Storm and Stress' movement of passion and genius."],["Werther effect","Imitative suicides after publicized cases."],["Weltliteratur","Goethe's concept of world literature."],["Faust","Goethe's drama of a pact with the devil."],["Weimar Classicism","Goethe and Schiller's classical ideal."]],
  w:"Goethe and German writers shaped Romanticism, the Bildungsroman, fairy tales, and the idea of world literature.",
  src:["Johann Wolfgang von Goethe","The Sorrows of Young Werther","Goethe's Faust","Friedrich Schiller","Grimms' Fairy Tales"],
  q:[
  ["Which novel caused a European sensation in 1774?","The Sorrows of Young Werther","Faust","Wilhelm Meister","The Robbers"],
  ["Who is the devil in Goethe's Faust?","Mephistopheles","Lucifer","Beelzebub","Gretchen"],
  ["Who coined the idea of 'world literature' (Weltliteratur)?","Goethe","Herder","Schiller","Heine"],
  ["Which Schiller poem became the finale of Beethoven's Ninth?","Ode to Joy","William Tell","The Robbers","Mary Stuart"],
  ["What does 'Sturm und Drang' mean?","Storm and Stress","Light and Reason","Faith and Hope","Love and Death"],
  ["Who collected 'Hansel and Gretel' and 'Snow White'?","The Brothers Grimm","E. T. A. Hoffmann","Novalis","Hans Christian Andersen"]]}

]});


/* ---- from lit-11.js ---- */
/* LITERATURE FOUNDATIONS, part 11: Unit 5 chapters 5-9 */
COURSES.literature.units[4].ch.push(

{ t:"Romantic Poetry I: Blake, Wordsworth, Coleridge", s:"Imagination and nature",
  sec:[
  ["What Romanticism was",[
    "Romanticism (roughly 1790s–1840s) was a broad movement that valued imagination, emotion, nature, the individual, childhood, the past, and the sublime (awe-inspiring grandeur) over Enlightenment reason and neoclassical rules. It was shaped by the French Revolution's hopes and disappointments and by the Industrial Revolution.",
    "In Britain, Romantic poetry is often divided into two generations: Blake, Wordsworth, and Coleridge; then Byron, Shelley, and Keats."]],
  ["William Blake",[
    "William Blake (1757–1827), a London engraver, poet, and painter, created illuminated books combining text and image, printed by his own methods. Songs of Innocence (1789) and Songs of Experience (1794) contrast paired poems: 'The Lamb' and 'The Tyger' ('Tyger Tyger, burning bright... What immortal hand or eye / Could frame thy fearful symmetry?'). 'London' denounces the 'mind-forg'd manacles' of a city of poverty and exploitation.",
    "Blake developed a private mythology in prophetic books and wrote the lines now sung as the hymn 'Jerusalem' ('And did those feet in ancient time'). Largely ignored in his life, he is now seen as a visionary genius."]],
  ["Lyrical Ballads",[
    "In 1798, William Wordsworth (1770–1850) and Samuel Taylor Coleridge (1772–1834) published Lyrical Ballads, often seen as the start of English Romanticism. In the preface to the 1800 edition, Wordsworth declared poetry should use 'the real language of men' about common life, and defined it as 'the spontaneous overflow of powerful feelings' that 'takes its origin from emotion recollected in tranquillity.'",
    "Wordsworth contributed poems of rural life and nature, including 'Tintern Abbey'; Coleridge contributed 'The Rime of the Ancient Mariner,' about a sailor cursed for shooting an albatross ('Water, water, every where, / Nor any drop to drink')."]],
  ["Wordsworth",[
    "Wordsworth, who lived in the Lake District with his sister Dorothy (whose journals inspired his poems), wrote of nature's moral and spiritual power and of childhood memory. 'I wandered lonely as a cloud' (the 'daffodils' poem), the 'Ode: Intimations of Immortality,' and the long autobiographical poem The Prelude, published after his death in 1850, trace the growth of a poet's mind.",
    "As a young man he was inspired by the French Revolution ('Bliss was it in that dawn to be alive'); later he grew conservative and became Poet Laureate."]],
  ["Coleridge",[
    "Coleridge, a brilliant talker and critic plagued by opium addiction, wrote the mysterious 'Kubla Khan,' which he claimed came to him in an opium dream and was interrupted by 'a person on business from Porlock,' and the eerie unfinished 'Christabel.' His Biographia Literaria (1817) distinguished imagination from fancy and described 'that willing suspension of disbelief' readers grant to fiction.",
    "His lectures on Shakespeare helped shape Romantic criticism."]]
  ],
  terms:[["Romanticism","Movement valuing imagination, emotion, and nature."],["Sublime","Awe-inspiring grandeur."],["Lyrical Ballads","1798 collection by Wordsworth and Coleridge."],["Illuminated book","Blake's combined text and image."],["Suspension of disbelief","Readers' acceptance of fiction, Coleridge's phrase."]],
  w:"The first Romantic poets redefined poetry as the voice of imagination, feeling, and nature.",
  src:["Romanticism","William Blake","Lyrical Ballads","William Wordsworth","Samuel Taylor Coleridge"],
  q:[
  ["Which poem asks about 'fearful symmetry'?","The Tyger","The Lamb","London","Jerusalem"],
  ["Who wrote 'The Rime of the Ancient Mariner'?","Samuel Taylor Coleridge","William Wordsworth","William Blake","Lord Byron"],
  ["How did Wordsworth define poetry's origin?","Emotion recollected in tranquillity","Reason and order","Divine inspiration","Imitation of classics"],
  ["Which poem was interrupted by a 'person from Porlock'?","Kubla Khan","Christabel","Tintern Abbey","The Prelude"],
  ["When were Lyrical Ballads first published?","1798","1789","1812","1820"],
  ["Who coined 'willing suspension of disbelief'?","Coleridge","Wordsworth","Keats","Shelley"]]},

{ t:"Romantic Poetry II: Byron, Shelley, Keats", s:"Rebels and beauty",
  sec:[
  ["Lord Byron",[
    "George Gordon, Lord Byron (1788–1824), became a celebrity overnight with Childe Harold's Pilgrimage (1812): 'I awoke one morning and found myself famous.' Handsome, scandalous, and 'mad, bad, and dangerous to know' (in Lady Caroline Lamb's words), he created the 'Byronic hero,' brooding, proud, rebellious, and mysterious.",
    "Leaving England amid scandal in 1816, he wrote the comic epic Don Juan, a satirical, digressive masterpiece, and died of fever in Greece while supporting the Greek War of Independence, becoming a Greek national hero. His poem 'She walks in beauty, like the night' is widely loved."]],
  ["Percy Bysshe Shelley",[
    "Percy Bysshe Shelley (1792–1822), expelled from Oxford for a pamphlet on atheism, was a radical idealist who championed political freedom, free love, and vegetarianism. His poems include 'Ozymandias' (1818), about a ruined statue of a forgotten king ('Look on my works, ye Mighty, and despair!'), 'Ode to the West Wind' ('If Winter comes, can Spring be far behind?'), 'To a Skylark,' and the lyrical drama Prometheus Unbound.",
    "His Defence of Poetry ends: 'Poets are the unacknowledged legislators of the world.' He drowned in a boating accident off Italy at 29."]],
  ["John Keats",[
    "John Keats (1795–1821), son of a stable keeper, trained as a surgeon before devoting himself to poetry. Hostile reviews, illness, and his love for Fanny Brawne marked his short life. In 1819 he wrote his great odes: 'Ode to a Nightingale,' 'Ode on a Grecian Urn' (ending 'Beauty is truth, truth beauty'), 'To Autumn,' and 'Ode on Melancholy.'",
    "He died of tuberculosis in Rome at 25; his gravestone reads 'Here lies One Whose Name was writ in Water.' His letters, discussing 'negative capability,' the ability to remain in uncertainty without 'irritable reaching after fact and reason,' are classics of literary thought. Shelley's elegy 'Adonais' mourned him."]],
  ["Other Romantic voices",[
    "Scotland's Robert Burns (1759–1796) wrote in Scots dialect: 'Auld Lang Syne,' 'A Red, Red Rose,' and 'To a Mouse' ('The best-laid schemes o' mice an' men / Gang aft agley'). John Clare, a farm laborer poet, wrote of rural life and loss. Romantic essayists Charles Lamb, William Hazlitt, and Thomas De Quincey (Confessions of an English Opium-Eater) shaped prose.",
    "Across Europe, Romanticism produced Pushkin and Lermontov in Russia, Adam Mickiewicz in Poland, Giacomo Leopardi in Italy, and Alphonse de Lamartine and Victor Hugo in France."]],
  ["The Romantic legacy",[
    "The Romantics' ideas of the poet as visionary, the value of personal experience, the love of nature, and the image of the doomed young genius remain influential. Their early deaths, Keats at 25, Shelley at 29, Byron at 36, fed the myth.",
    "Environmental thought, the idea of authenticity, and modern celebrity culture all have Romantic roots."]]
  ],
  terms:[["Byronic hero","Brooding, rebellious, mysterious hero."],["Ozymandias","Shelley's poem on a ruined statue."],["Negative capability","Keats's idea of embracing uncertainty."],["Ode","Elevated lyric addressing a subject."],["Scots","Language of Burns's poems."]],
  w:"The younger Romantics left some of English poetry's most beloved poems and enduring ideas of the poet.",
  src:["Lord Byron","Percy Bysshe Shelley","John Keats","Ozymandias","Robert Burns"],
  q:[
  ["Who was called 'mad, bad, and dangerous to know'?","Lord Byron","Percy Shelley","John Keats","Robert Burns"],
  ["Which poem says 'Look on my works, ye Mighty, and despair!'?","Ozymandias","Ode to the West Wind","Don Juan","Adonais"],
  ["Which Keats ode ends 'Beauty is truth, truth beauty'?","Ode on a Grecian Urn","Ode to a Nightingale","To Autumn","Ode on Melancholy"],
  ["What is 'negative capability'?","Remaining in uncertainty without reaching for fact and reason","Pessimism","Writing negative reviews","Lack of talent"],
  ["Where did Byron die?","Greece","Italy","England","Switzerland"],
  ["Who wrote 'Auld Lang Syne'?","Robert Burns","Walter Scott","John Clare","James Hogg"]]},

{ t:"Jane Austen", s:"Irony, marriage, and manners",
  sec:[
  ["Life",[
    "Jane Austen (1775–1817) was the daughter of a clergyman in Steventon, Hampshire, and grew up in a large, lively family that loved reading and amateur theatricals. She never married, accepting and then withdrawing from a proposal in one night in 1802. She lived quietly in Bath, Southampton, and finally Chawton, writing in the family sitting room.",
    "Her novels were published anonymously ('By a Lady'); she died at 41 in Winchester."]],
  ["The six novels",[
    "Sense and Sensibility (1811) contrasts the prudent Elinor and the passionate Marianne Dashwood. Pride and Prejudice (1813), opening 'It is a truth universally acknowledged, that a single man in possession of a good fortune, must be in want of a wife,' follows Elizabeth Bennet and the proud Mr. Darcy as they overcome misjudgments. Mansfield Park (1814) centers on the quiet, principled Fanny Price.",
    "Emma (1815) features 'a heroine whom no one but myself will much like,' the matchmaking, self-deceived Emma Woodhouse. Northanger Abbey (published 1817) parodies Gothic novels, and Persuasion (1817), her most melancholy, reunites Anne Elliot with the naval captain she was persuaded to reject eight years earlier."]],
  ["Style and irony",[
    "Austen's genius lies in irony, precise dialogue, and free indirect discourse, letting readers inhabit characters' minds while seeing their errors. She called her art working on 'a little bit (two Inches wide) of Ivory' with a fine brush, focusing on 'three or four families in a country village.'",
    "Her novels examine marriage as an economic necessity for women, inheritance laws (the Bennet estate is 'entailed' away from daughters), class, money, and moral growth through self-knowledge."]],
  ["Context and criticism",[
    "Though she rarely mentions the Napoleonic Wars directly, her brothers served in the navy, and her world is shaped by the period. Critic Edward Said argued that Mansfield Park's wealth depends on a slave plantation in Antigua, prompting debate about empire in her fiction.",
    "Sir Walter Scott praised her 'exquisite touch,' while Charlotte Brontë found her too restrained."]],
  ["Austen today",[
    "Austen is one of the most adapted authors ever: the 1995 BBC Pride and Prejudice, Clueless (based on Emma), Bridget Jones's Diary, and countless sequels and retellings. 'Janeites' form devoted fan societies worldwide.",
    "Her portrait appeared on the Bank of England £10 note in 2017, the 200th anniversary of her death."]]
  ],
  terms:[["Novel of manners","Fiction about social customs and class."],["Irony","Gap between appearance and reality, or words and meaning."],["Entail","Legal restriction on inheritance."],["Free indirect discourse","Narration blending character's thoughts."],["Janeite","Devoted Austen fan."]],
  w:"Austen's wit and moral insight made the novel of manners a lasting art and remain endlessly popular.",
  src:["Jane Austen","Pride and Prejudice","Emma (novel)","Persuasion (novel)","Mansfield Park"],
  q:[
  ["Which novel begins 'It is a truth universally acknowledged'?","Pride and Prejudice","Emma","Persuasion","Sense and Sensibility"],
  ["Which Austen heroine is a matchmaker?","Emma Woodhouse","Elizabeth Bennet","Anne Elliot","Fanny Price"],
  ["Which Austen novel parodies Gothic fiction?","Northanger Abbey","Mansfield Park","Persuasion","Emma"],
  ["Which critic linked Mansfield Park to a slave plantation?","Edward Said","Harold Bloom","F. R. Leavis","Lionel Trilling"],
  ["How were Austen's novels published in her lifetime?","Anonymously, 'By a Lady'","Under her full name","Under a male pseudonym","In magazines only"],
  ["Which Austen novel reunites Anne Elliot with a naval captain?","Persuasion","Pride and Prejudice","Sense and Sensibility","Emma"]]},

{ t:"The Gothic and Frankenstein", s:"Terror, the supernatural, and monsters",
  sec:[
  ["The Gothic novel",[
    "The Gothic novel began with Horace Walpole's The Castle of Otranto (1764), featuring a cursed castle, a giant helmet that falls from the sky, and dark secrets. Gothic fiction typically includes gloomy castles, ruined abbeys, persecuted heroines, villains, family curses, and the supernatural, evoking terror and the sublime.",
    "Ann Radcliffe's The Mysteries of Udolpho (1794) perfected 'explained supernatural' terror, while Matthew Lewis's The Monk (1796) was lurid horror."]],
  ["Mary Shelley",[
    "Mary Wollstonecraft Shelley (1797–1851) was the daughter of feminist philosopher Mary Wollstonecraft (A Vindication of the Rights of Woman, 1792), who died days after her birth, and the radical philosopher William Godwin. At 16 she eloped with Percy Bysshe Shelley.",
    "In June 1816, the 'year without a summer,' Mary, Percy, Lord Byron, and Byron's doctor John Polidori stayed near Lake Geneva. Kept indoors by storms, Byron proposed they each write a ghost story. Mary's became Frankenstein; Polidori's became The Vampyre (1819), the first modern vampire story."]],
  ["Frankenstein",[
    "Frankenstein; or, The Modern Prometheus (1818) is a frame narrative: the explorer Walton writes letters recounting the tale of Victor Frankenstein, a young scientist who creates a living being from dead matter and abandons it in horror. The creature (unnamed in the novel) educates himself by reading Paradise Lost, Plutarch, and Goethe's Werther and longs for companionship, but rejection turns him to revenge, killing Victor's brother, friend, and bride.",
    "The novel explores scientific ambition, responsibility of creators, isolation, and what makes us human. It is often called the first science fiction novel."]],
  ["Later Gothic",[
    "Gothic themes flowed into Victorian fiction: the Brontës' moors and madwomen, Edgar Allan Poe's tales, Robert Louis Stevenson's Strange Case of Dr Jekyll and Mr Hyde (1886), Oscar Wilde's The Picture of Dorian Gray, and Bram Stoker's Dracula (1897), an epistolary novel about the Transylvanian count's invasion of England.",
    "Sheridan Le Fanu's Carmilla, a female vampire novella, preceded Dracula."]],
  ["The Gothic legacy",[
    "Gothic fiction gave rise to horror as a genre and influenced American Southern Gothic (Faulkner, Flannery O'Connor), Daphne du Maurier's Rebecca, Shirley Jackson, Stephen King, and Anne Rice. Its exploration of fear, desire, and the repressed made it a rich field for psychoanalytic and feminist criticism.",
    "Frankenstein's creature, through the 1931 film with Boris Karloff, became a pop-culture icon, though the novel's articulate creature is very different."]]
  ],
  terms:[["Gothic","Fiction of terror, ruins, and the supernatural."],["Explained supernatural","Seemingly supernatural events given rational causes."],["Frankenstein","Mary Shelley's 1818 novel of a created being."],["Year without a summer","Cold 1816 when Frankenstein was conceived."],["Southern Gothic","Gothic fiction set in the American South."]],
  w:"Gothic fiction and Frankenstein created horror and science fiction, exploring fears that still haunt us.",
  src:["Gothic fiction","The Castle of Otranto","Mary Shelley","Frankenstein","Dracula"],
  q:[
  ["Which novel began the Gothic genre in 1764?","The Castle of Otranto","The Monk","Udolpho","Frankenstein"],
  ["Who proposed the ghost-story contest in 1816?","Lord Byron","Percy Shelley","John Polidori","Mary Shelley"],
  ["What is Frankenstein's subtitle?","The Modern Prometheus","A Gothic Tale","The Monster","The Creator"],
  ["Who was Mary Shelley's mother?","Mary Wollstonecraft","Jane Austen","Ann Radcliffe","Fanny Burney"],
  ["What did John Polidori write?","The Vampyre","Carmilla","Dracula","The Monk"],
  ["Which book does Frankenstein's creature read and learn from?","Paradise Lost","The Bible only","Robinson Crusoe","Hamlet"]]},

{ t:"The Historical Novel: Scott, Hugo, Dumas", s:"The past brought to life",
  sec:[
  ["Walter Scott",[
    "Sir Walter Scott (1771–1832), a Scottish lawyer and poet, essentially invented the historical novel with Waverley (1814), about a young Englishman caught up in the 1745 Jacobite rising. His novels, including Rob Roy, The Heart of Midlothian, and Ivanhoe (1819, set in the age of Richard the Lionheart and Robin Hood), were international bestsellers.",
    "Scott depicted ordinary people swept up in historical change, giving history a human face. The critic Georg Lukács praised him for showing how history shapes individuals. He helped create the romantic image of Scotland, kilts and Highlands, and Edinburgh's main station is named Waverley."]],
  ["Victor Hugo",[
    "Victor Hugo (1802–1885), leader of French Romanticism, was poet, dramatist, and novelist. His play Hernani (1830) caused a battle between classicists and Romantics in the theater. The Hunchback of Notre-Dame (1831) tells of the deaf bell-ringer Quasimodo's love for the dancer Esmeralda in medieval Paris, and helped spark efforts to preserve the cathedral.",
    "Opposing Napoleon III, Hugo lived in exile on Guernsey for nearly 20 years, where he completed Les Misérables (1862), following the ex-convict Jean Valjean, pursued by the relentless police inspector Javert, through decades of French history, including the 1832 June Rebellion. Millions attended Hugo's state funeral in 1885."]],
  ["Alexandre Dumas",[
    "Alexandre Dumas (1802–1870), grandson of a French nobleman and an enslaved woman of African descent in Saint-Domingue (Haiti), wrote swashbuckling adventures, often with collaborator Auguste Maquet. The Three Musketeers (1844) follows d'Artagnan joining Athos, Porthos, and Aramis ('All for one, one for all'). The Count of Monte Cristo tells of Edmond Dantès, wrongly imprisoned, who escapes, finds treasure, and takes elaborate revenge.",
    "Serialized in newspapers, his novels built huge readerships."]],
  ["Other historical novels",[
    "Alessandro Manzoni's The Betrothed (1827), about two lovers in 17th-century Lombardy, became Italy's national novel and helped standardize Italian. James Fenimore Cooper's The Last of the Mohicans (1826) brought the frontier to American fiction. Tolstoy's War and Peace raised the form to epic heights.",
    "Later practitioners include Hilary Mantel, whose Wolf Hall trilogy about Thomas Cromwell won two Booker Prizes."]],
  ["History and fiction",[
    "Historical novels raise questions about accuracy and invention: they combine real figures and events with fictional characters, often illuminating the past's texture while taking liberties.",
    "They remain one of fiction's most popular genres."]]
  ],
  terms:[["Historical novel","Fiction set in a past era."],["Waverley","Scott's first novel, 1814."],["Les Misérables","Hugo's epic of Jean Valjean."],["Serialization","Publishing a novel in installments."],["Swashbuckler","Adventure story of sword-fighting heroes."]],
  w:"The historical novel turned the past into living drama and remains one of fiction's most popular forms.",
  src:["Walter Scott","Les Misérables","Victor Hugo","Alexandre Dumas","The Betrothed (Manzoni novel)"],
  q:[
  ["Who invented the historical novel with Waverley?","Walter Scott","Victor Hugo","Alexandre Dumas","James Fenimore Cooper"],
  ["Who pursues Jean Valjean in Les Misérables?","Javert","Thénardier","Marius","Quasimodo"],
  ["Where did Hugo live in exile?","Guernsey","London","Brussels only","Switzerland"],
  ["Which Dumas novel follows Edmond Dantès?","The Count of Monte Cristo","The Three Musketeers","Twenty Years After","The Black Tulip"],
  ["Which novel became Italy's national novel?","The Betrothed","The Leopard","Ivanhoe","The Name of the Rose"],
  ["Whose Wolf Hall trilogy won two Booker Prizes?","Hilary Mantel","Pat Barker","A. S. Byatt","Sarah Waters"]]}

);


/* ---- from lit-12.js ---- */
/* LITERATURE FOUNDATIONS, part 12: Unit 5 chapters 10-13 (American literature) */
COURSES.literature.units[4].ch.push(

{ t:"Early American Voices", s:"Puritans, revolutionaries, and the enslaved",
  sec:[
  ["Colonial writing",[
    "Early American literature includes Native American oral traditions, explorers' accounts, and Puritan writing in New England: sermons, histories such as William Bradford's Of Plymouth Plantation, and captivity narratives like Mary Rowlandson's (1682). Jonathan Edwards's sermon 'Sinners in the Hands of an Angry God' (1741) is a famous example of Great Awakening preaching.",
    "Anne Bradstreet and Edward Taylor wrote the first significant American poetry."]],
  ["The Revolution's writers",[
    "Benjamin Franklin's Autobiography and Poor Richard's Almanack ('Early to bed and early to rise...') embodied practical self-improvement. Thomas Paine's pamphlet Common Sense (1776) argued for independence in plain, powerful prose and sold over 100,000 copies; Thomas Jefferson's Declaration of Independence is also a literary landmark.",
    "Washington Irving's 'Rip Van Winkle' and 'The Legend of Sleepy Hollow' (1819–20) were among the first American short stories to win international fame."]],
  ["Phillis Wheatley",[
    "Phillis Wheatley (about 1753–1784), kidnapped from West Africa as a child and enslaved in Boston, learned to read English, Latin, and Greek and published Poems on Various Subjects, Religious and Moral (1773), the first book of poetry by an African American. Doubts about her authorship led to her being examined by a panel of prominent Bostonians, who attested to it.",
    "She corresponded with George Washington and was later freed but died in poverty."]],
  ["Slave narratives",[
    "Slave narratives, autobiographies by formerly enslaved people, were powerful abolitionist literature. Olaudah Equiano's Interesting Narrative (1789) described capture in Africa, the Middle Passage, and eventual freedom. Frederick Douglass's Narrative of the Life of Frederick Douglass, an American Slave (1845) recounts learning to read in secret, fighting back against a 'slave breaker,' and escaping; he became the era's greatest orator.",
    "Harriet Jacobs's Incidents in the Life of a Slave Girl (1861) exposed the sexual abuse of enslaved women; she hid for seven years in a tiny attic crawlspace before escaping."]],
  ["Uncle Tom's Cabin",[
    "Harriet Beecher Stowe's Uncle Tom's Cabin (1852), a sentimental novel depicting the cruelty of slavery, became the best-selling novel of the 19th century in the United States and inflamed antislavery feeling. Lincoln reportedly greeted Stowe as 'the little woman who wrote the book that started this great war,' though the remark is likely apocryphal.",
    "Its characters later became stereotypes ('Uncle Tom' as an insult), and James Baldwin criticized its sentimentality, but its historical impact was enormous."]]
  ],
  terms:[["Captivity narrative","Account of capture by Native Americans."],["Common Sense","Paine's 1776 pamphlet for independence."],["Slave narrative","Autobiography of a formerly enslaved person."],["Middle Passage","Atlantic voyage of enslaved Africans."],["Abolitionism","Movement to end slavery."]],
  w:"Early American writing, especially slave narratives, shaped the nation's conscience and literary voice.",
  src:["Phillis Wheatley","Narrative of the Life of Frederick Douglass, an American Slave","Uncle Tom's Cabin","Slave narrative","Common Sense"],
  q:[
  ["Who published the first book of poetry by an African American?","Phillis Wheatley","Harriet Jacobs","Frederick Douglass","Olaudah Equiano"],
  ["Which 1845 narrative recounts learning to read in secret?","Frederick Douglass's Narrative","Incidents in the Life of a Slave Girl","Uncle Tom's Cabin","Equiano's Narrative"],
  ["Who wrote Common Sense?","Thomas Paine","Benjamin Franklin","Thomas Jefferson","John Adams"],
  ["Which novel was the best-selling US novel of the 19th century?","Uncle Tom's Cabin","Moby-Dick","The Scarlet Letter","Little Women"],
  ["Who hid for seven years in an attic crawlspace before escaping slavery?","Harriet Jacobs","Harriet Tubman","Sojourner Truth","Phillis Wheatley"],
  ["Who wrote 'The Legend of Sleepy Hollow'?","Washington Irving","Nathaniel Hawthorne","Edgar Allan Poe","James Fenimore Cooper"]]},

{ t:"Poe, Hawthorne, and Melville", s:"The dark side of American Romanticism",
  sec:[
  ["Edgar Allan Poe",[
    "Edgar Allan Poe (1809–1849), orphaned young and plagued by poverty and drinking, wrote tales of horror and psychological torment: 'The Fall of the House of Usher,' 'The Tell-Tale Heart' (a murderer undone by the imagined beating of his victim's heart), 'The Masque of the Red Death,' and 'The Cask of Amontillado.' His poem 'The Raven' (1845), with its refrain 'Quoth the Raven, Nevermore,' made him famous.",
    "Poe invented the detective story with 'The Murders in the Rue Morgue' (1841), featuring C. Auguste Dupin, a model for Sherlock Holmes, and was a pioneering critic of the short story. He died mysteriously in Baltimore at 40. French poets Baudelaire and Mallarmé revered him."]],
  ["Nathaniel Hawthorne",[
    "Nathaniel Hawthorne (1804–1864), descended from a judge in the Salem witch trials, explored Puritan New England's legacy of sin, guilt, and hypocrisy. The Scarlet Letter (1850) tells of Hester Prynne, forced to wear a scarlet 'A' for adultery, who bears her shame with dignity; her secret lover, the minister Arthur Dimmesdale, is destroyed by hidden guilt, tormented by Hester's vengeful husband Roger Chillingworth.",
    "His short stories, such as 'Young Goodman Brown' and 'The Minister's Black Veil,' and The House of the Seven Gables use symbolism and allegory."]],
  ["Herman Melville",[
    "Herman Melville (1819–1891) sailed on a whaler and lived among Pacific islanders, experiences that inspired his early bestselling adventures Typee and Omoo. Moby-Dick (1851), dedicated to his friend Hawthorne, begins 'Call me Ishmael' and recounts Captain Ahab's obsessive quest for the white whale that took his leg, ending in the destruction of the ship Pequod.",
    "Moby-Dick mixes adventure, encyclopedic whaling lore, philosophy, Shakespearean soliloquies, and symbolism. It sold poorly and Melville died in obscurity as a customs inspector; a 1920s revival made it a candidate for the 'Great American Novel.'"]],
  ["Bartleby and Billy Budd",[
    "Melville's story 'Bartleby, the Scrivener' (1853) is about a Wall Street copyist who answers every request with 'I would prefer not to,' a haunting study of alienation. Billy Budd, left unfinished at his death and published in 1924, tells of an innocent sailor executed under naval law, later made into an opera by Benjamin Britten.",
    "His late poetry, including Civil War verse, has also gained recognition."]],
  ["Dark Romanticism",[
    "Poe, Hawthorne, and Melville are often grouped as 'Dark Romantics,' contrasting with the optimistic Transcendentalists by emphasizing sin, evil, madness, and the limits of human understanding.",
    "Their symbolic, psychological fiction established American literature's independence from European models."]]
  ],
  terms:[["Dark Romanticism","American Romanticism focused on sin and evil."],["Scarlet letter","Hester Prynne's 'A' for adultery."],["Ahab","Obsessed captain of Moby-Dick."],["Detective story","Genre invented by Poe."],["Bartleby","Clerk who 'would prefer not to.'"]],
  w:"Poe, Hawthorne, and Melville gave American literature its dark, symbolic depths and invented lasting genres.",
  src:["Edgar Allan Poe","The Scarlet Letter","Moby-Dick","Bartleby, the Scrivener","Dark romanticism"],
  q:[
  ["Who invented the detective story?","Edgar Allan Poe","Arthur Conan Doyle","Wilkie Collins","Nathaniel Hawthorne"],
  ["What does Hester Prynne wear?","A scarlet 'A'","A black veil","A white dress","A raven's feather"],
  ["How does Moby-Dick begin?","Call me Ishmael","It was a dark and stormy night","Quoth the Raven","In the beginning"],
  ["What does Bartleby say to every request?","I would prefer not to","Nevermore","Not today","I refuse"],
  ["To whom did Melville dedicate Moby-Dick?","Nathaniel Hawthorne","Ralph Waldo Emerson","Edgar Allan Poe","Walt Whitman"],
  ["What is the refrain of 'The Raven'?","Nevermore","Evermore","Forever","No more"]]},

{ t:"Emerson, Thoreau, and the Transcendentalists", s:"Self-reliance and nature",
  sec:[
  ["Transcendentalism",[
    "Transcendentalism was a philosophical and literary movement centered in Concord, Massachusetts, in the 1830s–50s. Influenced by German Idealism, Romanticism, and Hindu scriptures, Transcendentalists believed in the inherent goodness of people and nature, intuition over reason, and that each individual can access spiritual truth directly.",
    "The movement included Ralph Waldo Emerson, Henry David Thoreau, Margaret Fuller, Bronson Alcott, and others; they published the journal The Dial."]],
  ["Emerson",[
    "Ralph Waldo Emerson (1803–1882), a former Unitarian minister, published Nature (1836), describing becoming 'a transparent eye-ball' in communion with the universe. His essay 'Self-Reliance' urged 'Trust thyself' and declared 'A foolish consistency is the hobgoblin of little minds.' 'The American Scholar' (1837), called America's 'intellectual Declaration of Independence,' urged Americans to stop imitating Europe.",
    "Emerson was a celebrated lecturer and encouraged younger writers, famously greeting Walt Whitman's Leaves of Grass 'at the beginning of a great career.'"]],
  ["Thoreau",[
    "Henry David Thoreau (1817–1862) lived in a small cabin he built at Walden Pond, on land owned by Emerson, from 1845 to 1847, to 'live deliberately' and 'front only the essential facts of life.' Walden (1854) describes his experiment in simplicity and close observation of nature: 'The mass of men lead lives of quiet desperation.'",
    "Jailed for a night for refusing to pay a poll tax that supported slavery and the Mexican–American War, Thoreau wrote 'Civil Disobedience' (1849), arguing that individuals should not let governments override their conscience; it influenced Gandhi, Martin Luther King Jr., and environmentalists."]],
  ["Margaret Fuller",[
    "Margaret Fuller (1810–1850), editor of The Dial and the first full-time female book reviewer in American journalism, wrote Woman in the Nineteenth Century (1845), a pioneering feminist work. She reported from Europe on the 1848 Italian revolution and drowned in a shipwreck off New York with her husband and child.",
    "Louisa May Alcott, daughter of Bronson Alcott, grew up in this circle and later wrote Little Women (1868–69)."]],
  ["Legacy",[
    "Transcendentalist ideas of individualism, nonconformity, simplicity, and reverence for nature shaped American culture, environmentalism (John Muir), and civil rights movements. Critics pointed to their naivety about evil and social structures.",
    "Their essays remain central texts of American thought."]]
  ],
  terms:[["Transcendentalism","Movement valuing intuition, nature, and the individual."],["Self-Reliance","Emerson's essay on trusting oneself."],["Walden","Thoreau's account of simple living."],["Civil disobedience","Refusing unjust laws on principle."],["The Dial","Transcendentalist journal."]],
  w:"The Transcendentalists' ideas of self-reliance, nature, and conscience shaped American culture and protest.",
  src:["Transcendentalism","Ralph Waldo Emerson","Walden","Civil Disobedience (Thoreau)","Margaret Fuller"],
  q:[
  ["Where did Thoreau build his cabin?","Walden Pond","Concord River","Cape Cod","Lake Champlain"],
  ["Who wrote 'Self-Reliance'?","Ralph Waldo Emerson","Henry David Thoreau","Margaret Fuller","Bronson Alcott"],
  ["Which essay influenced Gandhi and Martin Luther King Jr.?","Civil Disobedience","Nature","The American Scholar","Walden"],
  ["Who wrote Woman in the Nineteenth Century?","Margaret Fuller","Louisa May Alcott","Harriet Beecher Stowe","Emily Dickinson"],
  ["What did Emerson call consistency in 'Self-Reliance'?","The hobgoblin of little minds","A great virtue","The key to wisdom","A Puritan value"],
  ["Which novel did Louisa May Alcott write?","Little Women","The Scarlet Letter","Walden","Uncle Tom's Cabin"]]},

{ t:"Whitman and Dickinson", s:"Two founders of modern American poetry",
  sec:[
  ["Walt Whitman",[
    "Walt Whitman (1819–1892), a Brooklyn printer, journalist, and carpenter's son, self-published Leaves of Grass in 1855 and revised and expanded it throughout his life. Its long free-verse lines, catalogs, and celebration of the body, democracy, and ordinary Americans were revolutionary: 'I celebrate myself, and sing myself, / And what I assume you shall assume, / For every atom belonging to me as good belongs to you' ('Song of Myself').",
    "Whitman embraced multitudes: 'Do I contradict myself? / Very well then I contradict myself, / (I am large, I contain multitudes.)' His frank sexuality, including homoerotic poems in the 'Calamus' section, shocked readers; he was fired from a government job when his boss read the book."]],
  ["Whitman and the Civil War",[
    "During the Civil War, Whitman nursed wounded soldiers in Washington hospitals, an experience recorded in Drum-Taps. His elegies for Abraham Lincoln, 'When Lilacs Last in the Dooryard Bloom'd' and the more conventional 'O Captain! My Captain!', are among the most famous American poems.",
    "Whitman influenced poets worldwide, from Pablo Neruda and Fernando Pessoa to Allen Ginsberg and Langston Hughes."]],
  ["Emily Dickinson",[
    "Emily Dickinson (1830–1886) lived almost all her life in her family home in Amherst, Massachusetts, becoming increasingly reclusive and dressing in white. She wrote nearly 1,800 poems, but fewer than a dozen were published in her lifetime, anonymously and altered by editors. After her death, her sister Lavinia discovered hundreds of poems in a locked box, many sewn into small handmade booklets ('fascicles').",
    "Her short poems, often in hymn meter (alternating four- and three-beat lines), use dashes, slant rhyme, unconventional capitalization, and startling compression: 'Because I could not stop for Death – / He kindly stopped for me'; 'Hope is the thing with feathers'; 'Tell all the truth but tell it slant.'"]],
  ["Dickinson's themes",[
    "Dickinson wrote about death, immortality, nature, love, faith and doubt, and the mind's inner life ('I felt a Funeral, in my Brain'). Her wit and philosophical depth reward endless rereading.",
    "Early editors 'corrected' her punctuation and rhymes; Thomas H. Johnson's 1955 edition and R. W. Franklin's 1998 edition restored her original texts."]],
  ["Two opposite founders",[
    "Whitman and Dickinson represent two paths for modern poetry: Whitman expansive, public, oceanic; Dickinson compressed, private, enigmatic. Both broke with conventional forms and are considered founders of modern American poetry.",
    "Neither knew the other's work, though Dickinson reportedly heard Whitman's book was 'disgraceful.'"]]
  ],
  terms:[["Leaves of Grass","Whitman's lifelong poetry book."],["Catalog","Long poetic list."],["Fascicle","Dickinson's handmade booklet of poems."],["Hymn meter","Alternating four- and three-beat lines."],["Slant rhyme","Approximate rhyme."]],
  w:"Whitman and Dickinson created two radically different models for modern poetry, both still deeply influential.",
  src:["Walt Whitman","Leaves of Grass","Emily Dickinson","Song of Myself","Because I could not stop for Death"],
  q:[
  ["Who wrote 'I contain multitudes'?","Walt Whitman","Emily Dickinson","Ralph Waldo Emerson","Henry Wadsworth Longfellow"],
  ["How many of Dickinson's poems were published in her lifetime?","Fewer than a dozen","About 100","Almost all","None"],
  ["Which Whitman poem is an elegy for Lincoln?","When Lilacs Last in the Dooryard Bloom'd","Song of Myself","I Sing the Body Electric","Crossing Brooklyn Ferry"],
  ["Who 'kindly stopped for' Dickinson's speaker?","Death","Hope","Love","God"],
  ["What punctuation is characteristic of Dickinson?","Dashes","Semicolons","Exclamation marks","Parentheses"],
  ["What did Whitman do during the Civil War?","Nursed wounded soldiers","Fought as a general","Fled to Canada","Wrote speeches for Lincoln"]]}

);


/* ---- from lit-13.js ---- */
/* LITERATURE FOUNDATIONS, part 13: Unit 6 The Age of Realism, chapters 1-4 */
COURSES.literature.units.push({ t:"The Age of the Novel: Realism and the Nineteenth Century", ch:[

{ t:"Charles Dickens", s:"The great Victorian storyteller",
  sec:[
  ["A difficult childhood",[
    "Charles Dickens (1812–1870) was born in Portsmouth to a navy clerk who was imprisoned for debt in London's Marshalsea prison when Charles was twelve. Charles was sent to work in a blacking (boot polish) factory, pasting labels on pots, a humiliation he kept secret all his life but drew on repeatedly in his fiction.",
    "He became a court reporter and journalist before his comic Pickwick Papers (1836–37) made him famous at 24."]],
  ["Serial publication",[
    "Dickens published most novels in monthly or weekly installments, often with illustrations, building suspense and huge readerships across classes. Legend says crowds in New York awaited the ship carrying the final installment of The Old Curiosity Shop, shouting 'Is Little Nell dead?' He also founded and edited magazines and gave enormously popular public readings that exhausted his health.",
    "Serialization shaped his style: large casts, cliffhangers, memorable names, and comic and sentimental scenes."]],
  ["The novels",[
    "Oliver Twist (1837–39) exposed workhouses and the criminal underworld of Fagin and the Artful Dodger ('Please, sir, I want some more'). A Christmas Carol (1843), in which the miser Ebenezer Scrooge is transformed by three ghosts, helped shape the modern celebration of Christmas. David Copperfield (1849–50), his most autobiographical novel, includes the debt-ridden optimist Mr. Micawber.",
    "Later, darker novels include Bleak House (1852–53), satirizing the endless Chancery lawsuit Jarndyce and Jarndyce; Hard Times, attacking utilitarian education ('Facts alone are wanted in life'); Little Dorrit, set partly in a debtors' prison; A Tale of Two Cities (1859), set in the French Revolution; and Great Expectations (1860–61), where the orphan Pip's expectations of wealth come from an unexpected benefactor, the convict Magwitch, and where the jilted Miss Havisham sits in her rotting wedding dress."]],
  ["Social criticism",[
    "Dickens attacked poverty, child labor, debtors' prisons, harsh schools, bureaucracy, and the legal system, combining outrage with comedy and compassion. His work contributed to public debates and reforms, and his portrait of Victorian London shaped how later generations imagined the era.",
    "Critics have noted sentimentality and his often idealized, passive heroines, while George Orwell praised his 'generous anger.'"]],
  ["Legacy",[
    "'Dickensian' describes squalid poverty or a teeming cast of eccentric characters. His characters, Scrooge, Fagin, Uriah Heep, Mr. Micawber, Miss Havisham, have become part of the language.",
    "Dickens is buried in Westminster Abbey and remains one of the most adapted novelists, on stage, film, and television."]]
  ],
  terms:[["Serialization","Publishing a novel in installments."],["Dickensian","Evoking poverty or eccentric characters, as in Dickens."],["Workhouse","Victorian institution for the poor."],["Marshalsea","Debtors' prison where Dickens's father was held."],["Chancery","Court whose endless suits Dickens satirized."]],
  w:"Dickens combined storytelling genius with social conscience, shaping how we imagine the Victorian world.",
  src:["Charles Dickens","Great Expectations","Bleak House","A Christmas Carol","Oliver Twist"],
  q:[
  ["Where did Dickens work as a child?","A blacking factory","A coal mine","A cotton mill","A bakery"],
  ["Which novel contains 'Please, sir, I want some more'?","Oliver Twist","David Copperfield","Bleak House","Hard Times"],
  ["Who is Pip's secret benefactor in Great Expectations?","Magwitch","Miss Havisham","Joe Gargery","Jaggers"],
  ["Which novel satirizes the lawsuit Jarndyce and Jarndyce?","Bleak House","Little Dorrit","Our Mutual Friend","Hard Times"],
  ["Which Dickens novel is set during the French Revolution?","A Tale of Two Cities","Barnaby Rudge","Dombey and Son","Martin Chuzzlewit"],
  ["How did Dickens mostly publish his novels?","In serial installments","As single volumes","In newspapers abroad only","As plays"]]},

{ t:"The Brontës", s:"Passion on the moors",
  sec:[
  ["The family",[
    "Charlotte (1816–1855), Emily (1818–1848), and Anne (1820–1849) Brontë grew up in the parsonage at Haworth on the Yorkshire moors, children of an Irish-born clergyman, Patrick Brontë. Their mother and two elder sisters died young, the sisters after a harsh boarding school. With their brother Branwell, the children created elaborate imaginary kingdoms, Angria and Gondal, in tiny handwritten books.",
    "To be taken seriously, they published under male-sounding pseudonyms: Currer, Ellis, and Acton Bell."]],
  ["Jane Eyre",[
    "Charlotte's Jane Eyre (1847) is narrated by an orphaned, plain, fiercely independent governess. After a cruel childhood and the grim Lowood school, Jane falls in love with her employer, the brooding Mr. Rochester of Thornfield Hall, but discovers on their wedding day that he is married to Bertha Mason, a mad woman confined in the attic. Jane leaves, refusing to become his mistress, and returns only after Bertha's death in a fire leaves Rochester blinded: 'Reader, I married him.'",
    "Its passionate first-person voice and assertion of a woman's equal soul ('I am no bird; and no net ensnares me') made it a sensation. Charlotte also wrote Villette and Shirley."]],
  ["Wuthering Heights",[
    "Emily's only novel, Wuthering Heights (1847), tells of the wild, consuming bond between Catherine Earnshaw and Heathcliff, a foundling raised by her family. Catherine marries the gentle Edgar Linton for status ('I am Heathcliff,' she declares of their unity), and the embittered Heathcliff takes revenge on both families across two generations.",
    "Narrated through layered voices, the housekeeper Nelly Dean and the visitor Lockwood, it was considered savage and immoral at first and is now regarded as one of the most original English novels. Emily also wrote powerful poems ('No coward soul is mine')."]],
  ["Anne Brontë",[
    "Anne's Agnes Grey drew on her own experience as a governess, and The Tenant of Wildfell Hall (1848) depicts a woman who flees her abusive, alcoholic husband with her son, slamming her bedroom door against him, a scene contemporaries found shocking; it is considered an early feminist novel.",
    "Within months in 1848–49, Branwell, Emily, and Anne died, mostly of tuberculosis; Charlotte, who later married, died in pregnancy in 1855."]],
  ["Legacy",[
    "Elizabeth Gaskell's Life of Charlotte Brontë (1857) began the Brontë legend. The parsonage is now a museum. Jean Rhys's Wide Sargasso Sea (1966) retold the story of Bertha Mason from her own perspective as a Creole woman from Jamaica, and Gilbert and Gubar's The Madwoman in the Attic took its title from her.",
    "Kate Bush's 1978 song 'Wuthering Heights' and countless film adaptations show the novels' continuing hold."]]
  ],
  terms:[["Haworth","Yorkshire village of the Brontës."],["Bell pseudonyms","Currer, Ellis, and Acton Bell."],["Governess","Woman employed to educate children at home."],["Byronic hero","Brooding hero like Rochester or Heathcliff."],["Wide Sargasso Sea","Jean Rhys's prequel to Jane Eyre."]],
  w:"The Brontës brought fierce passion and female independence to the Victorian novel.",
  src:["Brontë family","Jane Eyre","Wuthering Heights","The Tenant of Wildfell Hall","Wide Sargasso Sea"],
  q:[
  ["Who is confined in the attic in Jane Eyre?","Bertha Mason","Grace Poole","Adèle","Blanche Ingram"],
  ["Who wrote Wuthering Heights?","Emily Brontë","Charlotte Brontë","Anne Brontë","Elizabeth Gaskell"],
  ["What pseudonyms did the Brontës use?","Currer, Ellis, and Acton Bell","George Eliot","Boz","Michael Field"],
  ["Who declares 'I am Heathcliff'?","Catherine Earnshaw","Isabella Linton","Nelly Dean","Cathy Linton"],
  ["Which Anne Brontë novel depicts a woman fleeing an abusive husband?","The Tenant of Wildfell Hall","Agnes Grey","Villette","Shirley"],
  ["Which novel retells Bertha Mason's story?","Wide Sargasso Sea","Rebecca","Jamaica Inn","Villette"]]},

{ t:"George Eliot and Thomas Hardy", s:"Moral realism and tragic fate",
  sec:[
  ["George Eliot",[
    "Mary Ann Evans (1819–1880) wrote as George Eliot to be taken seriously and to shield her private life: she lived openly for 24 years with the critic George Henry Lewes, who was married, scandalizing society. A translator of German philosophy and an editor of the Westminster Review, she brought exceptional intellect to fiction.",
    "Her early novels, Adam Bede, The Mill on the Floss (1860, about the bond between Maggie Tulliver and her brother Tom), and Silas Marner (about a miser redeemed by love for an orphan girl), depict rural English life with sympathy and moral seriousness."]],
  ["Middlemarch",[
    "Middlemarch: A Study of Provincial Life (1871–72) interweaves the lives of a provincial town around 1830: idealistic Dorothea Brooke, who marries the dry scholar Mr. Casaubon, and the ambitious doctor Tertius Lydgate, trapped by marriage and debt. Its omniscient narrator explores how individual lives are shaped by society, choices, and chance.",
    "Virginia Woolf called it 'one of the few English novels written for grown-up people.' Its ending honors those 'who lived faithfully a hidden life, and rest in unvisited tombs.' Many critics consider it the greatest English novel."]],
  ["Eliot's ethics",[
    "Eliot believed the novel's purpose was to enlarge sympathy: 'If art does not enlarge men's sympathies, it does nothing morally.' Her last novel, Daniel Deronda (1876), explored Jewish identity and early Zionism with unusual sympathy for the time.",
    "Her realism combines psychological depth, social breadth, and philosophical reflection."]],
  ["Thomas Hardy",[
    "Thomas Hardy (1840–1928), a stonemason's son trained as an architect, set his novels in 'Wessex,' a fictionalized southwest England, depicting rural life disrupted by modern change. Far from the Madding Crowd (1874) follows Bathsheba Everdene and her three suitors; The Mayor of Casterbridge (1886) opens with Michael Henchard drunkenly selling his wife and daughter at a fair.",
    "Tess of the d'Urbervilles (1891), subtitled 'A Pure Woman,' tells of a poor girl seduced (or raped) by Alec d'Urberville, rejected by her husband Angel Clare, and finally hanged for murder. Jude the Obscure (1895), about a stonemason barred from university and doomed in love, provoked such outrage (a bishop reportedly burned it) that Hardy abandoned novels."]],
  ["Hardy the poet",[
    "Hardy then devoted himself to poetry for over thirty years, writing nearly a thousand poems, including 'The Darkling Thrush' and the 'Poems of 1912–13' mourning his first wife Emma. His bleak view of fate and indifferent cosmic forces ('crass casualty') bridges Victorian and modern sensibilities.",
    "Both Eliot and Hardy shaped the serious realist novel's concern with ethics, society, and the individual."]]
  ],
  terms:[["George Eliot","Pen name of Mary Ann Evans."],["Middlemarch","Eliot's study of provincial life."],["Wessex","Hardy's fictional region."],["Realism","Faithful depiction of ordinary life."],["Omniscient narrator","All-knowing narrator."]],
  w:"Eliot and Hardy deepened the realist novel's moral seriousness and its portrait of changing English society.",
  src:["George Eliot","Middlemarch","Thomas Hardy","Tess of the d'Urbervilles","Jude the Obscure"],
  q:[
  ["What was George Eliot's real name?","Mary Ann Evans","Charlotte Brontë","Elizabeth Gaskell","Marian Lewes"],
  ["Who called Middlemarch 'one of the few English novels written for grown-up people'?","Virginia Woolf","Henry James","D. H. Lawrence","T. S. Eliot"],
  ["Whom does Dorothea Brooke marry in Middlemarch?","Mr. Casaubon","Lydgate","Will Ladislaw first","Bulstrode"],
  ["What is Hardy's fictional region called?","Wessex","Barsetshire","Middlemarch","Loamshire"],
  ["Which Hardy character sells his wife at a fair?","Michael Henchard","Angel Clare","Jude Fawley","Gabriel Oak"],
  ["After which novel did Hardy abandon fiction?","Jude the Obscure","Tess of the d'Urbervilles","The Return of the Native","Far from the Madding Crowd"]]},

{ t:"Victorian Poetry", s:"Tennyson, the Brownings, Rossetti, Hopkins",
  sec:[
  ["Tennyson",[
    "Alfred, Lord Tennyson (1809–1892), Poet Laureate for 42 years, was the most popular poet of the Victorian age. In Memoriam A.H.H. (1850), a long elegy for his friend Arthur Hallam, struggles with faith in an age of geology and evolution ('Nature, red in tooth and claw') and gives us 'Tis better to have loved and lost / Than never to have loved at all.'",
    "'Ulysses' imagines the aged hero longing to sail again ('To strive, to seek, to find, and not to yield'); 'The Charge of the Light Brigade' commemorates a disastrous cavalry charge in the Crimean War; and Idylls of the King retells Arthurian legend."]],
  ["The Brownings",[
    "Robert Browning (1812–1889) perfected the dramatic monologue, in which a speaker unknowingly reveals his character, as in 'My Last Duchess,' where a Renaissance duke implies he had his wife killed. His long poem The Ring and the Book retells a 17th-century murder trial through multiple perspectives.",
    "Elizabeth Barrett Browning (1806–1861), more famous than Robert when they met, eloped with him to Italy in 1846. Her Sonnets from the Portuguese include 'How do I love thee? Let me count the ways'; her verse novel Aurora Leigh explored a woman poet's life, and her poems protested child labor and slavery."]],
  ["Pre-Raphaelites and Christina Rossetti",[
    "The Pre-Raphaelite Brotherhood (1848), led by the painter-poet Dante Gabriel Rossetti, sought vivid detail and medieval inspiration. His sister Christina Rossetti (1830–1894) wrote 'Goblin Market,' a strange, sensual narrative of two sisters and goblin fruit, devotional poems, and the Christmas carol 'In the Bleak Midwinter.'",
    "William Morris, poet and designer, and Algernon Swinburne, whose sensual poems scandalized readers, were associated with the movement."]],
  ["Doubt and innovation",[
    "Matthew Arnold's 'Dover Beach' (1867) mourns the retreat of the 'Sea of Faith' and ends with a vision of humanity 'on a darkling plain... where ignorant armies clash by night.' As a critic, Arnold argued for culture as 'the best which has been thought and said.'",
    "Gerard Manley Hopkins (1844–1889), a Jesuit priest, wrote startlingly original poems in 'sprung rhythm,' counting stresses rather than syllables, celebrating nature's 'inscape' ('Glory be to God for dappled things,' 'The Windhover'). Unpublished until 1918, he was hailed as a forerunner of modernism."]],
  ["Nonsense and popular verse",[
    "Edward Lear's limericks and nonsense poems ('The Owl and the Pussy-cat') and Lewis Carroll's verse in Alice's Adventures in Wonderland (1865) and Through the Looking-Glass ('Jabberwocky') created a tradition of joyful nonsense.",
    "Rudyard Kipling's ballads and A. E. Housman's A Shropshire Lad (1896) were hugely popular at the century's end."]]
  ],
  terms:[["In Memoriam","Tennyson's elegy for Arthur Hallam."],["Dramatic monologue","Poem revealing a speaker's character."],["Pre-Raphaelites","1848 artistic brotherhood."],["Sprung rhythm","Hopkins's stress-based meter."],["Nonsense verse","Playful, absurd poetry."]],
  w:"Victorian poets wrestled with faith, love, and change, and invented forms that shaped modern poetry.",
  src:["Alfred, Lord Tennyson","Robert Browning","Elizabeth Barrett Browning","Christina Rossetti","Gerard Manley Hopkins"],
  q:[
  ["Who wrote 'Tis better to have loved and lost'?","Tennyson","Robert Browning","Matthew Arnold","Christina Rossetti"],
  ["Which poem is a famous dramatic monologue by Browning?","My Last Duchess","Dover Beach","Ulysses","Goblin Market"],
  ["Who wrote 'How do I love thee? Let me count the ways'?","Elizabeth Barrett Browning","Christina Rossetti","Emily Brontë","George Eliot"],
  ["Who wrote 'Goblin Market'?","Christina Rossetti","Dante Gabriel Rossetti","William Morris","Swinburne"],
  ["Which poet invented 'sprung rhythm'?","Gerard Manley Hopkins","Matthew Arnold","Tennyson","Thomas Hardy"],
  ["Which poem mourns the retreat of the 'Sea of Faith'?","Dover Beach","In Memoriam","The Windhover","Ulysses"]]}

]});


/* ---- from lit-14.js ---- */
/* LITERATURE FOUNDATIONS, part 14: Unit 6 chapters 5-9 (France and Russia) */
COURSES.literature.units[5].ch.push(

{ t:"Balzac, Stendhal, and Flaubert", s:"French realism",
  sec:[
  ["Stendhal",[
    "Stendhal (Marie-Henri Beyle, 1783–1842), a former officer under Napoleon, wrote The Red and the Black (1830), following Julien Sorel, a carpenter's son who rises through seduction and hypocrisy in Restoration France; 'red' and 'black' are often read as army and church, the two careers open to ambition. The Charterhouse of Parma (1839) opens with a famous, chaotic depiction of the Battle of Waterloo from a confused young man's point of view.",
    "Stendhal described the novel as 'a mirror carried along a highway,' reflecting both sky and mud."]],
  ["Balzac",[
    "Honoré de Balzac (1799–1850), fueled by vast quantities of coffee, wrote some 90 interconnected novels and stories called The Human Comedy (La Comédie humaine), depicting French society from peasants to aristocrats, with recurring characters. Père Goriot (1835) shows an old man ruined by devotion to his ungrateful daughters, and the ambitious Rastignac, who ends by challenging Paris: 'It's between the two of us now!'",
    "Eugénie Grandet, Lost Illusions, and Cousin Bette show money, ambition, and social climbing as driving forces of modern life. Balzac's detailed descriptions of houses, clothes, and finances made him a founder of realism; Marx and Engels admired his social analysis."]],
  ["Flaubert and Madame Bovary",[
    "Gustave Flaubert (1821–1880) labored for years over each sentence, seeking le mot juste ('the exact word'). Madame Bovary (1857) portrays Emma Bovary, a doctor's wife in provincial Normandy whose romantic dreams, nourished by novels, lead her to adultery, debt, and suicide by arsenic. Flaubert was prosecuted for offending public morals and acquitted.",
    "Its impersonal narration, free indirect discourse, and irony transformed the novel. Flaubert is said to have remarked 'Madame Bovary, c'est moi' ('Madame Bovary is me'), though the attribution is uncertain. 'Bovarysm' names romantic self-delusion."]],
  ["Flaubert's other works",[
    "Sentimental Education (1869) follows a young man's drifting life and unrealized love during the 1848 Revolution; Salammbô is set in ancient Carthage; and 'A Simple Heart' tells of a humble servant's devotion to her parrot. Bouvard and Pécuchet, unfinished, satirizes two clerks' attempts to master all knowledge.",
    "Flaubert's devotion to craft influenced Henry James, Joyce, and modern writers who saw the novel as an art form."]],
  ["Realism's principles",[
    "Realism aimed to depict contemporary life truthfully, including the middle and lower classes, with careful observation, avoiding idealization and melodrama. It paralleled painting (Gustave Courbet) and the rise of social science.",
    "French realism influenced novelists across Europe and the Americas."]]
  ],
  terms:[["Realism","Truthful depiction of contemporary life."],["The Human Comedy","Balzac's cycle of interconnected works."],["Le mot juste","The exact word."],["Bovarysm","Romantic self-delusion."],["Free indirect discourse","Narration blending narrator and character."]],
  w:"French realists made the novel a precise instrument for depicting modern society and inner life.",
  src:["Stendhal","The Red and the Black","Honoré de Balzac","Madame Bovary","Gustave Flaubert"],
  q:[
  ["Who wrote The Human Comedy?","Balzac","Flaubert","Stendhal","Zola"],
  ["Who is the ambitious hero of The Red and the Black?","Julien Sorel","Rastignac","Frédéric Moreau","Emma Bovary"],
  ["What does 'le mot juste' mean?","The exact word","The right moment","The just law","The final word"],
  ["Why was Flaubert prosecuted?","For offending public morals with Madame Bovary","For treason","For plagiarism","For debt"],
  ["Who described the novel as 'a mirror carried along a highway'?","Stendhal","Balzac","Zola","Flaubert"],
  ["How does Emma Bovary die?","By arsenic","In a duel","Of tuberculosis","By drowning"]]},

{ t:"Zola, Naturalism, and Late French Writers", s:"Heredity, environment, and decadence",
  sec:[
  ["Naturalism",[
    "Émile Zola (1840–1902) led naturalism, which applied scientific ideas, especially heredity and environment, to fiction, depicting characters shaped by forces beyond their control, often among the poor. His essay 'The Experimental Novel' compared the novelist to a scientist.",
    "His 20-novel cycle Les Rougon-Macquart traces a family across the Second Empire."]],
  ["Zola's novels",[
    "L'Assommoir (1877) depicts alcoholism in Paris's working class through the laundress Gervaise. Germinal (1885), about a coal miners' strike in northern France, is his masterpiece; at his funeral miners chanted 'Germinal!' Nana portrays a courtesan; The Ladies' Paradise depicts a department store; La Bête humaine a railway murderer.",
    "Naturalism influenced writers including Theodore Dreiser, Frank Norris, and Stephen Crane in America."]],
  ["J'accuse",[
    "In 1898 Zola published 'J'Accuse...!', an open letter to France's president defending Captain Alfred Dreyfus, a Jewish army officer falsely convicted of treason amid antisemitism. Zola was convicted of libel and fled to England. Dreyfus was eventually exonerated (1906).",
    "The episode created the modern idea of the intellectual intervening in public life."]],
  ["Maupassant and Daudet",[
    "Guy de Maupassant (1850–1893), Flaubert's protégé, wrote about 300 short stories, including 'Boule de Suif' (a prostitute sacrificed by her hypocritical fellow travelers during the Franco-Prussian War) and 'The Necklace,' whose twist ending is famous. His novel Bel-Ami satirizes an ambitious journalist.",
    "Alphonse Daudet's Letters from My Windmill depicted Provence with charm."]],
  ["Baudelaire and the Symbolists",[
    "Charles Baudelaire's The Flowers of Evil (Les Fleurs du mal, 1857) explored urban modernity, sin, beauty, and ennui; six poems were banned for obscenity. He introduced the figure of the flâneur, the urban stroller, and translated Poe into French.",
    "The Symbolists, Paul Verlaine, Arthur Rimbaud (who wrote revolutionary poems, including 'The Drunken Boat' and the prose poems of Illuminations, before abandoning poetry at about 21 to become a trader in Africa), and Stéphane Mallarmé, sought suggestion and musicality rather than description, profoundly influencing modernist poetry. Joris-Karl Huysmans's Against Nature (1884) became the bible of decadence."]]
  ],
  terms:[["Naturalism","Fiction showing characters shaped by heredity and environment."],["Les Rougon-Macquart","Zola's 20-novel family cycle."],["J'Accuse","Zola's letter defending Dreyfus."],["Flâneur","Urban stroller-observer."],["Symbolism","Poetry of suggestion and music."]],
  w:"Naturalism and Symbolism took French literature to its extremes of social realism and poetic innovation.",
  src:["Émile Zola","Germinal (novel)","J'Accuse…!","Guy de Maupassant","Les Fleurs du mal"],
  q:[
  ["Which Zola novel is about a coal miners' strike?","Germinal","L'Assommoir","Nana","La Bête humaine"],
  ["Whom did Zola defend in 'J'Accuse'?","Alfred Dreyfus","Victor Hugo","Émile Loubet","Ferdinand Esterhazy"],
  ["Which Maupassant story has a famous twist ending about jewelry?","The Necklace","Boule de Suif","Bel-Ami","The Horla"],
  ["Who wrote The Flowers of Evil?","Charles Baudelaire","Arthur Rimbaud","Paul Verlaine","Stéphane Mallarmé"],
  ["At about what age did Rimbaud abandon poetry?","About 21","About 40","About 15","About 30"],
  ["What did naturalism emphasize?","Heredity and environment","Supernatural forces","Aristocratic life","Fantasy"]]},

{ t:"Pushkin, Gogol, and Turgenev", s:"The birth of Russian literature",
  sec:[
  ["Pushkin",[
    "Alexander Pushkin (1799–1837) is considered the founder of modern Russian literature and Russia's national poet. His great-grandfather, Abram Gannibal, was an African taken to Russia who became a general under Peter the Great. Pushkin's novel in verse Eugene Onegin (1825–32) tells of a bored dandy who rejects the sincere Tatyana's love, kills his friend Lensky in a duel, and years later falls in love with Tatyana, now married, who rejects him.",
    "He also wrote the historical drama Boris Godunov, the narrative poem The Bronze Horseman, and short stories including 'The Queen of Spades.' Exiled for political verse, he died at 37 after a duel with a French officer who was pursuing his wife."]],
  ["Lermontov",[
    "Mikhail Lermontov (1814–1841), Pushkin's successor as Russia's leading poet, wrote A Hero of Our Time (1840), a novel told in linked episodes about Pechorin, a cynical, bored officer, the 'superfluous man' type. Like Pushkin, Lermontov died in a duel, at 26.",
    "The 'superfluous man,' a talented but aimless aristocrat, became a key type in Russian fiction."]],
  ["Gogol",[
    "Nikolai Gogol (1809–1852), born in Ukraine, combined comedy, the grotesque, and fantasy. His play The Government Inspector (1836) satirizes corrupt provincial officials who mistake a penniless traveler for an inspector. His story 'The Overcoat,' about a poor clerk whose new coat is stolen, inspired a saying attributed to Dostoevsky: 'We all came out from Gogol's Overcoat.' 'The Nose' tells of a nose that leaves its owner and wanders St Petersburg.",
    "Dead Souls (1842) follows the swindler Chichikov, who buys the names of dead serfs still listed in the census to use as collateral. Gogol burned the second part before his death."]],
  ["Turgenev",[
    "Ivan Turgenev (1818–1883), elegant and Westernized, lived much of his life in France. A Sportsman's Sketches (1852), depicting serfs with dignity, reportedly influenced Tsar Alexander II's emancipation of the serfs in 1861. Fathers and Sons (1862) portrays the generational conflict through Bazarov, a young 'nihilist' who rejects all authority, popularizing the word.",
    "His play A Month in the Country anticipates Chekhov."]],
  ["The Russian golden age",[
    "Russian literature developed amid autocracy, censorship, and serfdom, and writers became the nation's conscience, debating Russia's relationship with the West (Westernizers versus Slavophiles), religion, and social justice.",
    "This set the stage for the great novels of Tolstoy and Dostoevsky."]]
  ],
  terms:[["Eugene Onegin","Pushkin's novel in verse."],["Superfluous man","Aimless, talented aristocrat in Russian fiction."],["Dead Souls","Gogol's satire of a swindler buying dead serfs."],["Nihilist","One who rejects all authority."],["Slavophiles","Russian thinkers favoring native traditions over the West."]],
  w:"Pushkin, Gogol, and Turgenev created Russian literature's voice and its central types and themes.",
  src:["Alexander Pushkin","Eugene Onegin","Nikolai Gogol","Dead Souls","Fathers and Sons (novel)"],
  q:[
  ["Who is considered the founder of modern Russian literature?","Alexander Pushkin","Leo Tolstoy","Nikolai Gogol","Ivan Turgenev"],
  ["What is Eugene Onegin?","A novel in verse","A play","A short story collection","An opera libretto"],
  ["Who buys 'dead souls' in Gogol's novel?","Chichikov","Akaky Akakievich","Khlestakov","Bazarov"],
  ["Which novel popularized the word 'nihilist'?","Fathers and Sons","A Hero of Our Time","Dead Souls","Oblomov"],
  ["How did Pushkin die?","In a duel","Of tuberculosis","In exile in Siberia","In battle"],
  ["Who said 'We all came out from Gogol's Overcoat' (attributed)?","Dostoevsky","Tolstoy","Chekhov","Turgenev"]]},

{ t:"Leo Tolstoy", s:"War and Peace and Anna Karenina",
  sec:[
  ["Life",[
    "Count Leo Tolstoy (1828–1910) was born on his family estate, Yasnaya Polyana. After a dissolute youth, he served as an artillery officer in the Caucasus and in the Crimean War, writing the Sevastopol Sketches. In 1862 he married Sophia Behrs, who bore 13 children and copied his manuscripts, reportedly copying War and Peace multiple times.",
    "He ran a school for peasant children and managed his estate while writing his great novels."]],
  ["War and Peace",[
    "War and Peace (1865–69) is an epic of Russian society during the Napoleonic Wars, from 1805 to the 1812 invasion and burning of Moscow. It follows several aristocratic families and some 500 characters, especially the searching, awkward Pierre Bezukhov, the proud Prince Andrei Bolkonsky, and the vibrant Natasha Rostova.",
    "Tolstoy mixes intimate scenes, balls, love, family life, with vast battle panoramas (Austerlitz, Borodino) and essays arguing that history is shaped not by great men like Napoleon but by countless individual actions. Tolstoy said it was 'not a novel, even less is it a poem, and still less a historical chronicle.'"]],
  ["Anna Karenina",[
    "Anna Karenina (1875–77) opens: 'All happy families are alike; each unhappy family is unhappy in its own way.' Anna, married to the cold official Karenin, falls passionately in love with the officer Vronsky; their affair leads to social exclusion, jealousy, and her suicide under a train.",
    "A parallel plot follows Konstantin Levin, a landowner seeking meaning through farming, marriage to Kitty, and faith, partly a self-portrait of Tolstoy. William Faulkner called it the best novel ever written; it frequently tops such lists."]],
  ["Conversion and later works",[
    "In the late 1870s, Tolstoy underwent a spiritual crisis, described in A Confession. He developed a radical Christian philosophy rejecting church dogma, violence, private property, and the state, advocating nonresistance to evil by force. His book The Kingdom of God Is Within You influenced Gandhi, with whom he corresponded.",
    "Later fiction includes The Death of Ivan Ilyich (1886), about a judge confronting death and the emptiness of his conventional life, and Resurrection. He was excommunicated by the Orthodox Church in 1901."]],
  ["Death and influence",[
    "At 82, after conflict with his wife over his property and copyrights, Tolstoy secretly left home and died of pneumonia at a remote railway station, Astapovo, in 1910, as reporters gathered from around the world.",
    "Tolstoy's realism, moral seriousness, and psychological insight make him one of the supreme novelists; his nonviolence shaped 20th-century politics."]]
  ],
  terms:[["Yasnaya Polyana","Tolstoy's family estate."],["War and Peace","Tolstoy's epic of the Napoleonic Wars."],["Anna Karenina","Tolstoy's novel of adultery and meaning."],["Nonresistance","Refusing to resist evil by force."],["Death of Ivan Ilyich","Novella about confronting death."]],
  w:"Tolstoy's novels are summits of realism, and his moral ideas helped inspire nonviolent movements worldwide.",
  src:["Leo Tolstoy","War and Peace","Anna Karenina","The Death of Ivan Ilyich","Tolstoyan movement"],
  q:[
  ["Which novel begins 'All happy families are alike'?","Anna Karenina","War and Peace","Resurrection","Crime and Punishment"],
  ["In which war is War and Peace set?","The Napoleonic Wars","The Crimean War","World War I","The Russo-Turkish War"],
  ["Who is Anna Karenina's lover?","Vronsky","Levin","Pierre","Karenin"],
  ["Which leader was influenced by Tolstoy's nonviolence?","Gandhi","Lenin","Stalin","Napoleon"],
  ["Where did Tolstoy die?","Astapovo railway station","Moscow","Yasnaya Polyana","Paris"],
  ["Which novella concerns a judge confronting death?","The Death of Ivan Ilyich","Hadji Murat","The Kreutzer Sonata","Master and Man"]]},

{ t:"Fyodor Dostoevsky", s:"Faith, freedom, and the underground",
  sec:[
  ["A dramatic life",[
    "Fyodor Dostoevsky (1821–1881) won early fame with Poor Folk (1846). In 1849 he was arrested for belonging to a radical discussion group, the Petrashevsky Circle, and sentenced to death. On the execution ground, moments before shooting, a messenger announced that the Tsar had commuted the sentence, a staged mock execution. He served four years of hard labor in Siberia, described in Notes from the House of the Dead.",
    "Epilepsy, gambling addiction, debts, and grief marked his life; he dictated The Gambler in 26 days to meet a deadline, marrying his stenographer Anna Snitkina."]],
  ["Notes from Underground",[
    "Notes from Underground (1864) is narrated by a bitter, spiteful former official living in isolation, who attacks rational utopias and argues that humans value free will even above their own advantage: they would rather act irrationally than become 'piano keys.' It is often considered the first existentialist novel.",
    "Its unreliable, self-lacerating voice influenced Nietzsche, Kafka, Sartre, and Camus."]],
  ["Crime and Punishment",[
    "Crime and Punishment (1866) follows Rodion Raskolnikov, a poor former student in St Petersburg who murders an old pawnbroker, theorizing that 'extraordinary' people like Napoleon may overstep moral law for a greater good. Tormented by guilt and fever, cat-and-mouse dialogues with the investigator Porfiry Petrovich, and the love of Sonya, a gentle young woman forced into prostitution, he confesses and finds the beginning of redemption in Siberia.",
    "The novel's psychological intensity made it a model for crime fiction and philosophical novels."]],
  ["The Idiot and Demons",[
    "The Idiot (1869) imagines a 'positively beautiful man,' the Christ-like Prince Myshkin, whose innocence leads to catastrophe in a corrupt society. Demons (also translated The Possessed, 1872) satirizes revolutionary radicals, inspired by a real political murder, and foresees the dangers of ideological fanaticism.",
    "Dostoevsky's novels are 'polyphonic,' in critic Mikhail Bakhtin's term: many independent voices and ideas clash without the author's final word."]],
  ["The Brothers Karamazov",[
    "The Brothers Karamazov (1879–80), his final novel, centers on the murder of the depraved father Fyodor Karamazov and his sons: passionate Dmitri, the intellectual skeptic Ivan, the gentle novice Alyosha, and the illegitimate Smerdyakov. Ivan's prose poem 'The Grand Inquisitor,' in which Christ returns during the Spanish Inquisition and is arrested, debates freedom, faith, and suffering.",
    "Freud called it the most magnificent novel ever written. Dostoevsky's exploration of faith, doubt, guilt, and freedom made him a prophet of modern anxieties."]]
  ],
  terms:[["Underground man","Bitter narrator of Notes from Underground."],["Raskolnikov","Murderer-hero of Crime and Punishment."],["Polyphonic novel","Bakhtin's term for many independent voices."],["Grand Inquisitor","Ivan Karamazov's parable about freedom."],["Existentialism","Philosophy of freedom and meaning, anticipated by Dostoevsky."]],
  w:"Dostoevsky probed the depths of guilt, faith, and freedom, anticipating modern psychology and existentialism.",
  src:["Fyodor Dostoevsky","Crime and Punishment","The Brothers Karamazov","Notes from Underground","The Grand Inquisitor"],
  q:[
  ["What happened to Dostoevsky in 1849?","A mock execution before Siberian hard labor","He won a prize","He fled to Paris","He married"],
  ["Whom does Raskolnikov murder?","An old pawnbroker","His father","A police officer","A student"],
  ["Which character is a Christ-like innocent?","Prince Myshkin","Ivan Karamazov","Stavrogin","Raskolnikov"],
  ["Who tells 'The Grand Inquisitor'?","Ivan Karamazov","Alyosha","Dmitri","Zosima"],
  ["Who coined the term 'polyphonic novel' for Dostoevsky?","Mikhail Bakhtin","Vladimir Nabokov","Sigmund Freud","Albert Camus"],
  ["Which work is often called the first existentialist novel?","Notes from Underground","The Idiot","Demons","Poor Folk"]]}

);


/* ---- from lit-15.js ---- */
/* LITERATURE FOUNDATIONS, part 15: Unit 6 chapters 10-12 */
COURSES.literature.units[5].ch.push(

{ t:"Ibsen, Strindberg, and Chekhov", s:"The birth of modern drama",
  sec:[
  ["Henrik Ibsen",[
    "Henrik Ibsen (1828–1906), Norway's great dramatist, is often called the 'father of modern drama.' After early verse dramas such as Peer Gynt (1867), he turned to realistic prose plays about middle-class life that exposed hypocrisy and social constraints, written in Italy and Germany during 27 years of self-imposed exile.",
    "His 'well-made' plays reveal hidden pasts that erupt into the present."]],
  ["A Doll's House and others",[
    "In A Doll's House (1879), Nora Helmer, treated as a pretty plaything by her condescending husband Torvald, secretly forged a signature to save his life. When the secret emerges and Torvald reacts with selfish fury, Nora realizes she has never been treated as a person and leaves him and her children, slamming the door, a sound critics said 'reverberated across the roof of the world.' Its ending was so controversial that Ibsen was forced to write an alternative for a German production.",
    "Ghosts (1881) dealt with inherited syphilis and was banned in many places; An Enemy of the People portrays a doctor denounced for revealing that the town's baths are contaminated; Hedda Gabler (1890) presents a frustrated, manipulative woman who destroys a manuscript and shoots herself."]],
  ["Strindberg",[
    "Sweden's August Strindberg (1849–1912) wrote naturalistic dramas of sexual conflict, such as The Father and Miss Julie (1888), in which an aristocrat's daughter and her father's valet struggle over power, class, and desire during a Midsummer night. Later, his dreamlike plays A Dream Play and The Ghost Sonata anticipated expressionism and surrealism.",
    "His tormented life and misogyny are inseparable from his intense dramatic vision."]],
  ["Anton Chekhov",[
    "Anton Chekhov (1860–1904), a doctor who wrote to support his family ('Medicine is my lawful wife, and literature is my mistress'), revolutionized both the short story and drama. His hundreds of stories, such as 'The Lady with the Dog' and 'Ward No. 6,' capture ordinary lives with understatement, compassion, and open endings.",
    "His plays, staged by Konstantin Stanislavski at the Moscow Art Theatre, include The Seagull (1896), Uncle Vanya, Three Sisters (whose sisters dream of going to Moscow but never do), and The Cherry Orchard (1904), in which an aristocratic family loses its estate to a merchant whose father was their serf, ending with the sound of axes."]],
  ["Chekhov's art",[
    "Chekhov's drama works through subtext: characters talk about trivial things while their real feelings lie beneath, and major events often happen offstage. He insisted his plays were comedies, though many productions play them as melancholy. 'Chekhov's gun,' his principle that a gun shown in the first act must go off by the last, is a famous rule of storytelling.",
    "Stanislavski's acting 'system,' developed in staging Chekhov, influenced modern 'method' acting. Chekhov died of tuberculosis at 44."]]
  ],
  terms:[["A Doll's House","Ibsen's play of Nora's awakening."],["Well-made play","Tightly constructed play revealing hidden pasts."],["Subtext","Unspoken meaning beneath dialogue."],["Chekhov's gun","Every element introduced must matter."],["Moscow Art Theatre","Stanislavski's company that staged Chekhov."]],
  w:"Ibsen, Strindberg, and Chekhov created modern drama's realism, subtext, and social challenge.",
  src:["Henrik Ibsen","A Doll's House","August Strindberg","Anton Chekhov","The Cherry Orchard"],
  q:[
  ["How does A Doll's House end?","Nora leaves, slamming the door","Nora dies","Torvald leaves","They reconcile"],
  ["Who is called the 'father of modern drama'?","Henrik Ibsen","Anton Chekhov","August Strindberg","George Bernard Shaw"],
  ["Which Chekhov play ends with the sound of axes?","The Cherry Orchard","The Seagull","Three Sisters","Uncle Vanya"],
  ["What is 'Chekhov's gun'?","Every element introduced must matter","A plot twist","A stage prop rule about safety","A type of comedy"],
  ["Which Strindberg play involves an aristocrat's daughter and a valet?","Miss Julie","The Father","A Dream Play","The Ghost Sonata"],
  ["Who directed Chekhov's plays at the Moscow Art Theatre?","Konstantin Stanislavski","Vsevolod Meyerhold","Sergei Diaghilev","Maxim Gorky"]]},

{ t:"American Realism: Twain, James, Wharton", s:"The Gilded Age in fiction",
  sec:[
  ["Mark Twain",[
    "Mark Twain (Samuel Clemens, 1835–1910) grew up in Hannibal, Missouri, on the Mississippi River, and worked as a riverboat pilot, miner, and journalist; his pen name was a riverboat call meaning two fathoms deep. His humor and use of American vernacular speech created a distinctly American voice.",
    "The Adventures of Tom Sawyer (1876) celebrates boyhood; Adventures of Huckleberry Finn (1884), narrated by the uneducated, runaway Huck, follows his raft journey down the Mississippi with Jim, an enslaved man escaping to freedom. When Huck decides to help Jim rather than turn him in, declaring 'All right, then, I'll go to hell,' he defies his society's morality. Hemingway said 'All modern American literature comes from one book by Mark Twain called Huckleberry Finn.'"]],
  ["Twain's legacy and controversy",[
    "Huckleberry Finn has been both praised for its anti-racist satire and criticized and banned for its racial slurs and stereotypes, making it one of the most debated books in American schools. Twain's later works, such as The Mysterious Stranger, grew bitter, and he was a vocal anti-imperialist.",
    "Other works include A Connecticut Yankee in King Arthur's Court and Life on the Mississippi."]],
  ["Henry James",[
    "Henry James (1843–1916), born in New York and long resident in England, wrote psychologically subtle novels, often about Americans encountering European society (the 'international theme'): Daisy Miller, The Portrait of a Lady (1881, about Isabel Archer, who chooses freedom but is trapped by a manipulative husband), The Wings of the Dove, and The Ambassadors.",
    "His ghost story The Turn of the Screw (1898) is famously ambiguous: are the ghosts real or the governess's delusion? James's late style, with long, intricate sentences, and his criticism, such as 'The Art of Fiction,' shaped the novel as an art form."]],
  ["Edith Wharton",[
    "Edith Wharton (1862–1937), from wealthy old New York society, dissected its rigid codes. The House of Mirth (1905) follows Lily Bart's decline as she fails to secure a wealthy marriage; Ethan Frome is a stark tragedy in rural New England; and The Age of Innocence (1920) depicts Newland Archer's frustrated love for the unconventional Countess Ellen Olenska. It made Wharton the first woman to win the Pulitzer Prize for Fiction (1921).",
    "William Dean Howells, editor of The Atlantic, championed realism in America."]],
  ["Other realists and naturalists",[
    "Kate Chopin's The Awakening (1899), about a woman seeking independence and sexual freedom in New Orleans, was condemned in its day and rediscovered as a feminist classic. Stephen Crane's The Red Badge of Courage (1895) depicts a young soldier's fear in the Civil War, written before he had seen combat. Theodore Dreiser's Sister Carrie and Frank Norris's McTeague brought naturalism to American cities.",
    "Regionalist writers such as Sarah Orne Jewett and Bret Harte captured local life, while Charles Chesnutt and Paul Laurence Dunbar depicted African American experience after the Civil War."]]
  ],
  terms:[["Vernacular","Everyday spoken language."],["International theme","James's Americans in Europe."],["Gilded Age","Late 19th-century era of wealth and inequality."],["Regionalism","Fiction capturing local life and dialect."],["The Awakening","Chopin's novel of a woman's independence."]],
  w:"American realists gave the nation's literature its own voices, from Twain's vernacular to James's psychological depth.",
  src:["Mark Twain","Adventures of Huckleberry Finn","Henry James","Edith Wharton","The Awakening (Chopin novel)"],
  q:[
  ["What does 'Mark Twain' mean?","A riverboat call meaning two fathoms deep","A riverboat captain's name","A Mississippi town","A nickname from school"],
  ["Who escapes with Huck on the raft?","Jim","Tom Sawyer","Pap","Injun Joe"],
  ["Who said all modern American literature comes from Huckleberry Finn?","Ernest Hemingway","William Faulkner","T. S. Eliot","F. Scott Fitzgerald"],
  ["Which Henry James story is a famously ambiguous ghost story?","The Turn of the Screw","Daisy Miller","The Ambassadors","Washington Square"],
  ["Who was the first woman to win the Pulitzer Prize for Fiction?","Edith Wharton","Willa Cather","Kate Chopin","Pearl Buck"],
  ["Who wrote The Red Badge of Courage?","Stephen Crane","Theodore Dreiser","Frank Norris","Jack London"]]},

{ t:"The Fin de Siècle", s:"Wilde, Stevenson, Conan Doyle, Conrad, Kipling",
  sec:[
  ["Aestheticism and Oscar Wilde",[
    "The Aesthetic movement championed 'art for art's sake,' beauty valued for itself rather than moral purpose; Walter Pater urged readers 'to burn always with this hard, gem-like flame.' Oscar Wilde (1854–1900), the brilliant Irish wit, embodied it. His novel The Picture of Dorian Gray (1890) tells of a young man whose portrait ages and records his sins while he stays beautiful.",
    "His comedies, especially The Importance of Being Earnest (1895), sparkle with epigrams ('The truth is rarely pure and never simple'). In 1895 Wilde was convicted of 'gross indecency' for homosexual relationships and sentenced to two years' hard labor, which produced The Ballad of Reading Gaol and the letter De Profundis. He died in poverty in Paris in 1900; the UK pardoned men convicted under such laws in 2017."]],
  ["Stevenson and adventure",[
    "Robert Louis Stevenson (1850–1894), a Scottish writer plagued by illness, wrote Treasure Island (1883), creating Long John Silver and the pirate map with 'X marks the spot,' Kidnapped, and Strange Case of Dr Jekyll and Mr Hyde (1886), about a respectable doctor whose potion releases his evil self, a story of the divided self. He died in Samoa.",
    "H. Rider Haggard's King Solomon's Mines and adventure fiction reflected and reinforced imperial attitudes."]],
  ["Sherlock Holmes",[
    "Arthur Conan Doyle (1859–1930), a Scottish doctor, created Sherlock Holmes in A Study in Scarlet (1887). Holmes, the brilliant, eccentric consulting detective of 221B Baker Street, solves cases through observation and deduction, chronicled by his friend Dr. Watson. Stories in The Strand Magazine made him enormously popular.",
    "When Doyle killed Holmes at the Reichenbach Falls in 1893, readers protested; he revived him in The Hound of the Baskervilles and later stories. Holmes became the model fictional detective."]],
  ["Conrad and Kipling",[
    "Joseph Conrad (1857–1924), born in Poland, became a sea captain and learned English as an adult, then wrote some of its finest prose. Heart of Darkness (1899) follows Marlow up the Congo River in search of the ivory trader Kurtz, whose final words are 'The horror! The horror!' It exposes the brutality of colonialism in King Leopold's Congo, though Chinua Achebe criticized its dehumanizing portrayal of Africans. Lord Jim and Nostromo are other masterpieces.",
    "Rudyard Kipling (1865–1936), born in Bombay, wrote The Jungle Book (1894), Kim, the Just So Stories, and poems such as 'If—' and 'Gunga Din.' In 1907 he became the first English-language writer to win the Nobel Prize; his celebration of empire ('The White Man's Burden') makes him controversial."]],
  ["Shaw and the new century",[
    "George Bernard Shaw (1856–1950), Irish playwright and socialist, wrote witty plays of ideas: Mrs Warren's Profession (about prostitution's economic causes), Man and Superman, Major Barbara, and Pygmalion (1913), in which phonetics professor Henry Higgins transforms the Cockney flower girl Eliza Doolittle, later the musical My Fair Lady. He won the Nobel Prize in 1925.",
    "H. G. Wells's The Time Machine (1895) and The War of the Worlds (1898) founded modern science fiction, and Bram Stoker's Dracula (1897) defined the vampire myth, as the Victorian era closed."]]
  ],
  terms:[["Art for art's sake","Aesthetic belief in beauty for its own sake."],["Epigram","Brief, witty saying."],["Divided self","Theme of Jekyll and Hyde."],["Deduction","Holmes's method of reasoning."],["Heart of Darkness","Conrad's novella of colonial Congo."]],
  w:"The fin de siècle produced iconic characters and questioned empire, morality, and the self on the eve of modernism.",
  src:["Oscar Wilde","Strange Case of Dr Jekyll and Mr Hyde","Sherlock Holmes","Heart of Darkness","Pygmalion (play)"],
  q:[
  ["In which novel does a portrait age instead of its subject?","The Picture of Dorian Gray","Dr Jekyll and Mr Hyde","Dracula","The Time Machine"],
  ["What are Kurtz's final words?","The horror! The horror!","Rosebud","It is finished","Mistah Kurtz—he dead"],
  ["Where does Sherlock Holmes live?","221B Baker Street","10 Downing Street","Reichenbach Falls","Scotland Yard"],
  ["Who was the first English-language writer to win the Nobel Prize?","Rudyard Kipling","George Bernard Shaw","W. B. Yeats","Thomas Hardy"],
  ["Which Shaw play became My Fair Lady?","Pygmalion","Man and Superman","Major Barbara","Saint Joan"],
  ["Who wrote The War of the Worlds?","H. G. Wells","Jules Verne","Arthur Conan Doyle","Robert Louis Stevenson"]]}

);


/* ---- from lit-16.js ---- */
/* LITERATURE FOUNDATIONS, part 16: Unit 7 Modernism, chapters 1-4 */
COURSES.literature.units.push({ t:"Modernism", ch:[

{ t:"What Was Modernism?", s:"'Make it new'",
  sec:[
  ["A break with the past",[
    "Modernism, roughly 1900 to 1940, was an international movement in the arts responding to rapid change: industrialization, cities, new technologies (cars, airplanes, cinema, radio), Einstein's physics, Freud's psychoanalysis, the decline of religious certainty, and above all the catastrophe of World War I. Ezra Pound's slogan 'Make it new' captured its spirit.",
    "Virginia Woolf wrote, provocatively, that 'on or about December 1910 human character changed.'"]],
  ["Features of modernist writing",[
    "Modernist literature often features fragmentation and collage; stream of consciousness and interior monologue; multiple or unreliable perspectives; nonlinear time; allusion to myths and earlier literature; free verse and experimental forms; ambiguity and difficulty; and a focus on consciousness, memory, and perception rather than external plot.",
    "Many modernists felt that traditional forms could not represent a shattered, complex modern world."]],
  ["The war and disillusion",[
    "World War I (1914–18) killed some 9 to 10 million soldiers and destroyed faith in progress. Soldier-poets such as Wilfred Owen ('Dulce et Decorum Est,' which calls Horace's line about dying for one's country 'the old Lie'), Siegfried Sassoon, Isaac Rosenberg, and Rupert Brooke wrote of the trenches. Owen was killed a week before the Armistice.",
    "Erich Maria Remarque's All Quiet on the Western Front (1929), from the German side, became a worldwide anti-war classic."]],
  ["Movements and centers",[
    "Modernism encompassed many 'isms': Imagism (precise images in poetry), Futurism (celebrating speed and machines, founded by Filippo Marinetti in 1909), Dada (anti-art absurdity born in Zurich in 1916), Surrealism (exploring the unconscious, led by André Breton from 1924), Expressionism, and Vorticism.",
    "Paris, London, Vienna, Berlin, New York, and Dublin were key centers; little magazines and small presses, such as Sylvia Beach's Shakespeare and Company bookshop in Paris, published difficult new work."]],
  ["Annus mirabilis: 1922",[
    "The year 1922 is often called modernism's miracle year: James Joyce's Ulysses, T. S. Eliot's The Waste Land, and Virginia Woolf's Jacob's Room appeared, and Marcel Proust died that year with his great novel nearly complete.",
    "Modernism's legacy shapes literature today, even as later writers reacted against its difficulty and elitism."]]
  ],
  terms:[["Modernism","Early 20th-century experimental movement."],["Make it new","Pound's modernist slogan."],["Interior monologue","Direct presentation of a character's thoughts."],["Dada","Anti-art movement born in 1916."],["Surrealism","Movement exploring the unconscious."]],
  w:"Modernism transformed literature's forms to capture a fractured modern world, and its experiments still shape writing.",
  src:["Modernist literature","Wilfred Owen","All Quiet on the Western Front","Surrealism","1922 in literature"],
  q:[
  ["Whose slogan was 'Make it new'?","Ezra Pound","T. S. Eliot","Virginia Woolf","James Joyce"],
  ["Who wrote that 'on or about December 1910 human character changed'?","Virginia Woolf","D. H. Lawrence","E. M. Forster","Gertrude Stein"],
  ["Which war poet called a Horace line 'the old Lie'?","Wilfred Owen","Rupert Brooke","Siegfried Sassoon","Isaac Rosenberg"],
  ["Which year is called modernism's miracle year?","1922","1914","1900","1939"],
  ["Who wrote All Quiet on the Western Front?","Erich Maria Remarque","Ernst Jünger","Thomas Mann","Hermann Hesse"],
  ["Who led Surrealism?","André Breton","Filippo Marinetti","Tristan Tzara","Ezra Pound"]]},

{ t:"James Joyce", s:"Dublin and the revolution of the novel",
  sec:[
  ["Life",[
    "James Joyce (1882–1941) was born in Dublin, educated by Jesuits, and left Ireland in 1904 with Nora Barnacle, living in exile in Trieste, Zurich, and Paris, often in poverty and suffering eye disease. Yet all his major works are set in Dublin: 'I always write about Dublin, because if I can get to the heart of Dublin I can get to the heart of all the cities of the world.'",
    "He famously said he put so many puzzles into Ulysses that it would 'keep the professors busy for centuries.'"]],
  ["Dubliners and Portrait",[
    "Dubliners (1914), fifteen stories, depicts the 'paralysis' of Dublin life with precise realism; characters often reach 'epiphanies,' sudden moments of insight. The final story, 'The Dead,' ends with snow 'falling faintly through the universe... upon all the living and the dead.'",
    "A Portrait of the Artist as a Young Man (1916) follows Stephen Dedalus from childhood to his decision to leave Ireland and become a writer, rejecting family, nation, and church, its style evolving with his maturity: 'I will not serve.'"]],
  ["Ulysses",[
    "Ulysses (1922) follows Leopold Bloom, a Jewish advertising salesman, Stephen Dedalus, and Bloom's wife Molly through a single day in Dublin, 16 June 1904, now celebrated worldwide as 'Bloomsday.' Each of its 18 episodes parallels an episode of Homer's Odyssey and uses a different style, from newspaper headlines to a drama script to parodies of English prose through history.",
    "It ends with Molly Bloom's unpunctuated monologue concluding 'yes I said yes I will Yes.' Its frankness led to bans in the US and UK; a 1933 US court ruling by Judge John Woolsey found it not obscene. Many critics rank it the greatest novel of the 20th century."]],
  ["Finnegans Wake",[
    "Finnegans Wake (1939), on which Joyce worked for 17 years, is written in a dream-language of puns and portmanteau words drawn from dozens of languages, following the cyclical history of a Dublin family. Its first sentence completes its last, making it a circle.",
    "Physicists named the 'quark' after a line in it ('Three quarks for Muster Mark!')."]],
  ["Influence",[
    "Joyce's techniques, stream of consciousness, mythic parallels, stylistic experiment, and the elevation of an ordinary day to epic significance, transformed fiction, influencing writers from Faulkner and Beckett (his assistant in Paris) to Salman Rushdie.",
    "His insistence on the dignity of ordinary experience is as revolutionary as his style."]]
  ],
  terms:[["Epiphany","Sudden moment of insight."],["Bloomsday","16 June, the day of Ulysses."],["Stream of consciousness","Representation of flowing thought."],["Mythic method","Paralleling modern life with myth."],["Portmanteau word","Word blending two others."]],
  w:"Joyce revolutionized the novel and showed that a single ordinary day could hold epic depth.",
  src:["James Joyce","Ulysses (novel)","Dubliners","A Portrait of the Artist as a Young Man","Finnegans Wake"],
  q:[
  ["On what date is Ulysses set?","16 June 1904","1 January 1900","4 July 1922","17 March 1916"],
  ["Who is the main character of Ulysses?","Leopold Bloom","Stephen Dedalus only","Buck Mulligan","Gabriel Conroy"],
  ["What is an epiphany in Joyce's stories?","A sudden moment of insight","A Christmas feast","A dream","A stylistic parody"],
  ["How does Ulysses end?","With Molly Bloom's 'yes'","With Bloom's death","With a funeral","With Stephen leaving Ireland"],
  ["Which subatomic particle is named from Finnegans Wake?","Quark","Neutrino","Boson","Gluon"],
  ["Which story ends Dubliners?","The Dead","Araby","Eveline","Clay"]]},

{ t:"Virginia Woolf and Bloomsbury", s:"Consciousness, time, and a room of one's own",
  sec:[
  ["Life and Bloomsbury",[
    "Virginia Woolf (1882–1941), daughter of the critic Leslie Stephen, was a central figure of the Bloomsbury Group, a circle of writers, artists, and thinkers in London including the economist John Maynard Keynes, novelist E. M. Forster, critic Lytton Strachey, and her sister, painter Vanessa Bell. With her husband Leonard she founded the Hogarth Press (1917), which published T. S. Eliot and translations of Freud.",
    "She suffered recurring episodes of severe depression, and in 1941 she drowned herself in the River Ouse."]],
  ["Mrs Dalloway",[
    "Mrs Dalloway (1925) follows Clarissa Dalloway on a single June day in London as she prepares for a party, interwoven with Septimus Warren Smith, a shell-shocked war veteran who takes his own life. Through stream of consciousness and shifting perspectives, Woolf links inner lives with the city's rhythms, marked by the chimes of Big Ben.",
    "It opens: 'Mrs Dalloway said she would buy the flowers herself.' Michael Cunningham's The Hours (1998) reimagined it."]],
  ["To the Lighthouse and The Waves",[
    "To the Lighthouse (1927), drawing on Woolf's childhood summers in Cornwall, centers on the Ramsay family and a planned trip to a lighthouse. Its middle section, 'Time Passes,' compresses ten years, war and deaths, into a few pages describing an empty house; in the final part, the painter Lily Briscoe completes her painting.",
    "The Waves (1931), her most experimental novel, consists of interwoven soliloquies of six friends across their lives. Orlando (1928), a playful mock-biography inspired by her lover Vita Sackville-West, follows a hero who lives for centuries and changes sex from man to woman."]],
  ["A Room of One's Own",[
    "Woolf's essay A Room of One's Own (1929) argues that 'a woman must have money and a room of her own if she is to write fiction.' She imagines Shakespeare's equally gifted sister, Judith, denied education and opportunity, ending in tragedy, and traces women writers' history. Three Guineas (1938) linked patriarchy and war.",
    "These essays became foundational texts of feminist criticism."]],
  ["Forster and others",[
    "E. M. Forster (1879–1970) wrote humane novels about class, connection, and empire: A Room with a View, Howards End (epigraph 'Only connect...'), and A Passage to India (1924), about misunderstanding between British and Indians, centered on an alleged assault in the Marabar Caves. Maurice, about gay love, was published posthumously in 1971.",
    "D. H. Lawrence (1885–1930), a miner's son, explored sexuality, class, and instinct in Sons and Lovers, Women in Love, and Lady Chatterley's Lover, the subject of a famous 1960 British obscenity trial won by Penguin Books."]]
  ],
  terms:[["Bloomsbury Group","Circle of London writers and thinkers."],["Hogarth Press","Publisher founded by the Woolfs."],["Time Passes","Middle section of To the Lighthouse."],["A Room of One's Own","Woolf's essay on women and writing."],["Only connect","Epigraph of Howards End."]],
  w:"Woolf transformed the novel of consciousness and laid foundations for feminist literary thought.",
  src:["Virginia Woolf","Mrs Dalloway","To the Lighthouse","A Room of One's Own","E. M. Forster"],
  q:[
  ["How does Mrs Dalloway open?","Mrs Dalloway said she would buy the flowers herself","It was a bright cold day in April","Call me Ishmael","Stately, plump Buck Mulligan"],
  ["Which section of To the Lighthouse compresses ten years?","Time Passes","The Window","The Lighthouse","The Party"],
  ["What does Woolf say a woman needs to write fiction?","Money and a room of her own","A husband","A university degree","A publisher"],
  ["Which Woolf novel features a character who changes sex across centuries?","Orlando","The Waves","Jacob's Room","Between the Acts"],
  ["Which Forster novel involves the Marabar Caves?","A Passage to India","Howards End","A Room with a View","Maurice"],
  ["Which novel was the subject of a famous 1960 obscenity trial?","Lady Chatterley's Lover","Ulysses","Orlando","Women in Love"]]},

{ t:"Proust, Kafka, and Mann", s:"Memory, alienation, and ideas",
  sec:[
  ["Proust's In Search of Lost Time",[
    "Marcel Proust (1871–1922), a wealthy, asthmatic Parisian, spent his final years in a cork-lined bedroom writing In Search of Lost Time (À la recherche du temps perdu, 1913–27), a seven-volume novel of over a million words, narrated by a man recalling his life in French high society. Its sentences can run for pages, exploring memory, love, jealousy, art, snobbery, and time.",
    "In the most famous scene, the taste of a madeleine cake dipped in lime-blossom tea suddenly brings back the narrator's childhood in Combray, an example of 'involuntary memory.' The final volume, Time Regained, reveals that art can recover lost time; 'Proustian' describes vivid sensory memory."]],
  ["Franz Kafka",[
    "Franz Kafka (1883–1924), a German-speaking Jewish insurance clerk in Prague, wrote nightmarish, absurd fiction in a calm, precise style. The Metamorphosis (1915) opens: 'As Gregor Samsa awoke one morning from uneasy dreams he found himself transformed in his bed into a gigantic insect.' His family's revulsion gradually turns to relief at his death.",
    "In The Trial, Josef K. is arrested and prosecuted by an inaccessible court without ever learning his crime; The Castle shows a land surveyor endlessly failing to reach the authorities. 'Kafkaesque' describes oppressive, illogical bureaucracy."]],
  ["Kafka's survival",[
    "Kafka published little in life and asked his friend Max Brod to burn his manuscripts. Brod refused and published The Trial, The Castle, and Amerika, preserving some of the most influential fiction of the century. Kafka's three sisters later died in the Holocaust.",
    "His work has been read as religious allegory, existential parable, critique of bureaucracy, and premonition of totalitarianism."]],
  ["Thomas Mann",[
    "Thomas Mann (1875–1955) wrote Buddenbrooks (1901), chronicling the decline of a Lübeck merchant family over four generations, and Death in Venice (1912), about an aging writer's obsession with a beautiful boy during a cholera outbreak. The Magic Mountain (1924) follows Hans Castorp, who visits a Swiss tuberculosis sanatorium for three weeks and stays seven years amid debates about Europe's ideas on the eve of World War I.",
    "Mann won the Nobel Prize in 1929, opposed the Nazis from exile in the United States, and wrote Doctor Faustus, about a composer who makes a pact with the devil, as an allegory of Germany's fall."]],
  ["Other European modernists",[
    "Robert Musil's unfinished The Man Without Qualities satirizes the dying Austro-Hungarian Empire; Hermann Hesse's Siddhartha and Steppenwolf explored spiritual quests and became cult books; Rainer Maria Rilke's Duino Elegies and Letters to a Young Poet are classics of German poetry.",
    "Italy's Italo Svevo (Zeno's Conscience) and Luigi Pirandello (Six Characters in Search of an Author, 1921, in which characters invade a rehearsal demanding their story be told) and Portugal's Fernando Pessoa, who wrote under dozens of 'heteronyms' with separate personalities, show modernism's range."]]
  ],
  terms:[["Involuntary memory","Memory triggered unexpectedly by the senses."],["Kafkaesque","Nightmarishly illogical and bureaucratic."],["The Metamorphosis","Kafka's story of Gregor Samsa."],["Magic Mountain","Mann's sanatorium novel."],["Heteronym","Pessoa's invented alternate authors."]],
  w:"Proust, Kafka, and Mann explored memory, alienation, and the crisis of European civilization in enduring masterpieces.",
  src:["In Search of Lost Time","Franz Kafka","The Metamorphosis","Thomas Mann","The Magic Mountain"],
  q:[
  ["What triggers the narrator's memory in Proust?","A madeleine dipped in tea","A song","A photograph","A smell of roses"],
  ["What does Gregor Samsa become?","A gigantic insect","A bird","A statue","A dog"],
  ["Who refused Kafka's request to burn his manuscripts?","Max Brod","Felice Bauer","Thomas Mann","Milena Jesenská"],
  ["Where is The Magic Mountain set?","A Swiss tuberculosis sanatorium","Venice","Lübeck","Prague"],
  ["Which Pirandello play has characters invading a rehearsal?","Six Characters in Search of an Author","Henry IV","Right You Are","The Rules of the Game"],
  ["What does 'Kafkaesque' describe?","Oppressive, illogical bureaucracy","Romantic longing","Comic misunderstanding","Natural beauty"]]}

]});


/* ---- from lit-17.js ---- */
/* LITERATURE FOUNDATIONS, part 17: Unit 7 chapters 5-9 */
COURSES.literature.units[6].ch.push(

{ t:"T. S. Eliot and Ezra Pound", s:"The Waste Land and modern poetry",
  sec:[
  ["Ezra Pound",[
    "Ezra Pound (1885–1972), an American in London and Paris, was modernism's great promoter, editor, and impresario, helping launch Joyce, Eliot, Hemingway, and Frost. He founded Imagism with H.D. (Hilda Doolittle), calling for direct treatment of the image and no superfluous words; his two-line 'In a Station of the Metro' ('The apparition of these faces in the crowd: / Petals on a wet, black bough') is the classic Imagist poem.",
    "His vast, fragmentary epic The Cantos occupied him for decades. During World War II, he broadcast fascist and antisemitic propaganda from Italy; charged with treason, he was judged mentally unfit and confined to a psychiatric hospital in Washington for 12 years."]],
  ["T. S. Eliot",[
    "Thomas Stearns Eliot (1888–1965), born in St. Louis, moved to England, worked in a bank, became a British citizen, and joined the Church of England. 'The Love Song of J. Alfred Prufrock' (1915) portrays a timid, self-conscious man ('I have measured out my life with coffee spoons') in fragmented, ironic monologue, beginning 'Let us go then, you and I, / When the evening is spread out against the sky / Like a patient etherized upon a table.'",
    "His essay 'Tradition and the Individual Talent' argued that poets write within the whole tradition of literature, and that poetry is 'an escape from personality.'"]],
  ["The Waste Land",[
    "The Waste Land (1922), heavily edited by Pound, is a 434-line poem of fragments, voices, and quotations in several languages, portraying postwar Europe as spiritually barren. It opens 'April is the cruellest month' and draws on the Grail legend, the Upanishads, Dante, Shakespeare, music-hall songs, and pub conversation, ending with the Sanskrit 'Shantih shantih shantih.'",
    "Eliot added explanatory notes. Its difficulty, collage method, and despair made it the emblematic modernist poem: 'These fragments I have shored against my ruins.'"]],
  ["Later Eliot",[
    "'The Hollow Men' (1925) ends 'This is the way the world ends / Not with a bang but a whimper.' After his conversion, Eliot wrote religious poetry, culminating in Four Quartets (1936–42), meditations on time and eternity ('In my end is my beginning'). He wrote verse plays, including Murder in the Cathedral, and won the Nobel Prize in 1948.",
    "His light verse collection Old Possum's Book of Practical Cats became the musical Cats. Critics have examined antisemitic passages in some of his poems."]],
  ["American modernist poets",[
    "Other American modernists include Wallace Stevens, an insurance executive who wrote philosophical, imaginative poems ('Thirteen Ways of Looking at a Blackbird'); William Carlos Williams, a doctor who favored plain American speech ('no ideas but in things,' 'The Red Wheelbarrow'); Marianne Moore; E. E. Cummings, with his playful typography; Hart Crane; and Gertrude Stein ('Rose is a rose is a rose is a rose').",
    "Robert Frost (1874–1963), more traditional in form, wrote deceptively simple poems of New England life, such as 'The Road Not Taken' and 'Stopping by Woods on a Snowy Evening,' and won four Pulitzer Prizes."]]
  ],
  terms:[["Imagism","Poetry of precise, direct images."],["The Waste Land","Eliot's 1922 fragmented poem."],["Collage","Assembling fragments and quotations."],["Four Quartets","Eliot's meditative late poems."],["Tradition and the Individual Talent","Eliot's essay on tradition."]],
  w:"Eliot and Pound reinvented English poetry for the modern age, and their influence still shapes verse.",
  src:["T. S. Eliot","The Waste Land","Ezra Pound","Imagism","Robert Frost"],
  q:[
  ["Which poem opens 'April is the cruellest month'?","The Waste Land","Prufrock","Four Quartets","The Hollow Men"],
  ["Who edited The Waste Land heavily?","Ezra Pound","Virginia Woolf","James Joyce","W. B. Yeats"],
  ["Who 'measured out my life with coffee spoons'?","J. Alfred Prufrock","Leopold Bloom","Hugh Selwyn Mauberley","Sweeney"],
  ["How does 'The Hollow Men' say the world ends?","Not with a bang but a whimper","In fire","In ice","With a song"],
  ["Which Eliot book became the musical Cats?","Old Possum's Book of Practical Cats","The Waste Land","Four Quartets","Prufrock and Other Observations"],
  ["Who wrote 'The Road Not Taken'?","Robert Frost","Wallace Stevens","William Carlos Williams","Carl Sandburg"]]},

{ t:"Yeats and the Irish Literary Revival", s:"Poetry, myth, and nation",
  sec:[
  ["The Revival",[
    "In the late 19th and early 20th centuries, the Irish Literary Revival sought to create a national literature drawing on Irish myth, folklore, and the Irish language. Douglas Hyde founded the Gaelic League in 1893. W. B. Yeats, Lady Augusta Gregory, and others founded the Abbey Theatre in Dublin (1904) as a national theater.",
    "The movement intertwined with the struggle for Irish independence."]],
  ["Yeats's early work",[
    "William Butler Yeats (1865–1939) began with dreamy, Celtic-mythological poems such as 'The Lake Isle of Innisfree' ('I will arise and go now, and go to Innisfree'). He was deeply interested in mysticism and the occult, and long, unrequitedly loved the revolutionary Maud Gonne, who inspired many poems.",
    "His style hardened into modern directness and power after 1910."]],
  ["Politics and the great poems",[
    "'Easter, 1916' responds to the failed Easter Rising and the execution of its leaders: 'All changed, changed utterly: / A terrible beauty is born.' 'The Second Coming' (1919) gives a vision of collapse: 'Things fall apart; the centre cannot hold; / Mere anarchy is loosed upon the world... And what rough beast, its hour come round at last, / Slouches towards Bethlehem to be born?'",
    "'Sailing to Byzantium' and 'Among School Children' meditate on aging, art, and the soul. Yeats served as a senator in the Irish Free State and won the Nobel Prize in 1923, the first Irish writer to do so."]],
  ["Synge and O'Casey",[
    "J. M. Synge's The Playboy of the Western World (1907), about a young man who becomes a village hero by claiming to have killed his father, provoked riots at the Abbey Theatre by nationalists offended by its portrayal of Irish peasants. His Riders to the Sea is a short tragedy of fishermen's deaths.",
    "Seán O'Casey's Dublin plays, including Juno and the Paycock and The Plough and the Stars (which also caused riots), depicted tenement life during the revolutionary years."]],
  ["Irish literary legacy",[
    "Ireland's remarkable literary output includes Swift, Wilde, Shaw, Yeats, Joyce, Beckett, Seamus Heaney, and many contemporary writers; four Irish writers have won the Nobel Prize in Literature (Yeats, Shaw, Beckett, Heaney).",
    "Irish-language literature, from medieval poetry to Máirtín Ó Cadhain's modern novel Graveyard Clay, is also rich."]]
  ],
  terms:[["Irish Literary Revival","Movement for a national Irish literature."],["Abbey Theatre","Ireland's national theater, founded 1904."],["Easter Rising","1916 Irish rebellion."],["The Second Coming","Yeats's apocalyptic poem."],["Playboy riots","1907 protests at Synge's play."]],
  w:"Yeats and the Irish Revival created a national literature whose lines echo through modern culture.",
  src:["W. B. Yeats","Irish Literary Revival","Abbey Theatre","The Second Coming (poem)","The Playboy of the Western World"],
  q:[
  ["Which poem says 'A terrible beauty is born'?","Easter, 1916","The Second Coming","Sailing to Byzantium","Innisfree"],
  ["Which poem contains 'Things fall apart; the centre cannot hold'?","The Second Coming","Easter, 1916","The Wild Swans at Coole","Leda and the Swan"],
  ["When was the Abbey Theatre founded?","1904","1916","1893","1922"],
  ["Which play provoked riots in 1907?","The Playboy of the Western World","Juno and the Paycock","Riders to the Sea","Cathleen ni Houlihan"],
  ["Whom did Yeats long and unrequitedly love?","Maud Gonne","Lady Gregory","Constance Markievicz","Nora Barnacle"],
  ["When did Yeats win the Nobel Prize?","1923","1907","1939","1948"]]},

{ t:"The Lost Generation", s:"Hemingway, Fitzgerald, and the Jazz Age",
  sec:[
  ["Paris in the 1920s",[
    "Gertrude Stein reportedly told Ernest Hemingway, 'You are all a lost generation,' describing young Americans disillusioned by World War I. Many expatriates gathered in 1920s Paris, drawn by cheap living and artistic freedom, in Stein's salon, at Sylvia Beach's bookshop, and in cafés.",
    "Hemingway's memoir A Moveable Feast recalls this world."]],
  ["F. Scott Fitzgerald",[
    "F. Scott Fitzgerald (1896–1940) chronicled and named the 'Jazz Age' of the 1920s, its parties, wealth, and disillusion. The Great Gatsby (1925), narrated by Nick Carraway, tells of the mysterious millionaire Jay Gatsby, who throws lavish parties on Long Island hoping to win back Daisy Buchanan, the wealthy woman he loved before the war. The green light at the end of Daisy's dock symbolizes his longing.",
    "Gatsby ends: 'So we beat on, boats against the current, borne back ceaselessly into the past.' Fitzgerald and his wife Zelda lived glamorously but suffered alcoholism and mental illness; Tender Is the Night drew on their decline. Gatsby sold modestly in his lifetime but became a defining American novel."]],
  ["Ernest Hemingway",[
    "Ernest Hemingway (1899–1961), wounded as an ambulance driver in Italy in World War I, developed a spare style of short, declarative sentences and the 'iceberg theory': the deeper meaning lies beneath the surface, in what is left unsaid. The Sun Also Rises (1926) follows expatriates to the bullfights of Pamplona; A Farewell to Arms (1929) tells of love and war in Italy.",
    "For Whom the Bell Tolls (1940) draws on the Spanish Civil War; The Old Man and the Sea (1952), about an aged Cuban fisherman's struggle with a giant marlin, won the Pulitzer, and Hemingway won the Nobel Prize in 1954. His macho public persona of hunting, fishing, and war masked a troubled man; he died by suicide in 1961."]],
  ["Other American writers of the era",[
    "Sinclair Lewis satirized small-town conformity in Main Street and Babbitt and became the first American to win the Nobel Prize in Literature (1930). John Dos Passos's U.S.A. trilogy used collage techniques. Willa Cather's My Ántonia and O Pioneers! celebrated immigrant pioneers on the Great Plains.",
    "In the 1930s, the Great Depression inspired social realism: John Steinbeck's The Grapes of Wrath (1939) follows the Joad family's migration from the Oklahoma Dust Bowl to California; Of Mice and Men portrays two migrant workers' doomed dream. Steinbeck won the Nobel Prize in 1962."]],
  ["Drama",[
    "Eugene O'Neill (1888–1953), America's first major playwright and Nobel laureate (1936), wrote tragedies including Mourning Becomes Electra and the autobiographical Long Day's Journey into Night, about a family's addiction and grief.",
    "Thornton Wilder's Our Town (1938) depicted life and death in a small New Hampshire town with a bare stage and a Stage Manager narrator."]]
  ],
  terms:[["Lost Generation","Disillusioned post-WWI generation."],["Jazz Age","Fitzgerald's name for the 1920s."],["Iceberg theory","Hemingway's principle of omission."],["The Great Gatsby","Fitzgerald's novel of longing and wealth."],["Dust Bowl","1930s drought on the Great Plains."]],
  w:"The writers of the 1920s and 30s defined American modern fiction and its themes of disillusion and dreams.",
  src:["Lost Generation","The Great Gatsby","Ernest Hemingway","The Grapes of Wrath","Eugene O'Neill"],
  q:[
  ["Who reportedly coined 'lost generation'?","Gertrude Stein","Ernest Hemingway","F. Scott Fitzgerald","Ezra Pound"],
  ["What does the green light in Gatsby symbolize?","Gatsby's longing for Daisy and the dream","Danger","Money","Envy"],
  ["What is Hemingway's 'iceberg theory'?","Meaning lies beneath the surface in what is unsaid","Writing about cold places","Using long sentences","Writing quickly"],
  ["Which novel follows the Joad family from the Dust Bowl?","The Grapes of Wrath","Of Mice and Men","East of Eden","Tortilla Flat"],
  ["Who was the first American to win the Nobel Prize in Literature?","Sinclair Lewis","Ernest Hemingway","Eugene O'Neill","Pearl Buck"],
  ["Which Hemingway novella won the Pulitzer Prize?","The Old Man and the Sea","A Farewell to Arms","The Sun Also Rises","For Whom the Bell Tolls"]]},

{ t:"Faulkner and the Southern Renaissance", s:"The past is never dead",
  sec:[
  ["William Faulkner",[
    "William Faulkner (1897–1962) set most of his fiction in Yoknapatawpha County, a fictional Mississippi county modeled on his home of Oxford, Mississippi, tracing its families from Native American times through slavery, the Civil War, and modern decline. He wrote: 'The past is never dead. It's not even past.'",
    "He won the Nobel Prize in 1949, declaring in his speech that 'man will not merely endure: he will prevail.'"]],
  ["The Sound and the Fury",[
    "The Sound and the Fury (1929), its title from Macbeth, tells of the decaying Compson family in four sections; the first is narrated by Benjy, a cognitively disabled man whose mind moves freely between past and present, followed by his brothers Quentin (on the day of his suicide at Harvard in 1910) and Jason, and a final third-person section centered on Dilsey, the family's Black servant, who 'endured.'",
    "As I Lay Dying (1930), written in six weeks, uses 59 sections by 15 narrators as the poor Bundren family carries their mother's coffin to be buried in town; one chapter by the young Vardaman consists only of 'My mother is a fish.'"]],
  ["Race and history",[
    "Light in August, Absalom, Absalom! (1936, the story of Thomas Sutpen's ambition and his dynasty's destruction, pieced together by several narrators), and Go Down, Moses confront the South's legacy of slavery and racial violence. Faulkner's long, complex sentences and shifting time challenge readers.",
    "His treatment of race remains debated; he opposed segregation in principle but made ambivalent public statements."]],
  ["The Southern Renaissance",[
    "The Southern Renaissance of the 1920s–50s included Robert Penn Warren (All the King's Men, about a populist governor), Thomas Wolfe (Look Homeward, Angel), Eudora Welty's stories of Mississippi, Carson McCullers's The Heart Is a Lonely Hunter, and the playwright Tennessee Williams.",
    "Flannery O'Connor (1925–1964), a devout Catholic in Georgia, wrote violent, darkly comic 'Southern Gothic' stories such as 'A Good Man Is Hard to Find,' in which grace arrives through shocking events."]],
  ["Mockingbird and beyond",[
    "Harper Lee's To Kill a Mockingbird (1960), narrated by young Scout Finch, whose father Atticus defends a Black man, Tom Robinson, falsely accused of rape in 1930s Alabama, became one of the most widely read American novels. Margaret Mitchell's Gone with the Wind (1936) romanticized the Old South and has been widely criticized for its portrayal of slavery.",
    "Southern literature continued with writers such as Cormac McCarthy and Jesmyn Ward."]]
  ],
  terms:[["Yoknapatawpha County","Faulkner's fictional Mississippi county."],["The Sound and the Fury","Faulkner's four-part Compson novel."],["Southern Renaissance","Flowering of Southern US literature."],["Southern Gothic","Dark, grotesque Southern fiction."],["To Kill a Mockingbird","Harper Lee's novel of justice and race."]],
  w:"Faulkner and Southern writers confronted history, race, and memory, creating some of America's richest fiction.",
  src:["William Faulkner","The Sound and the Fury","As I Lay Dying","Flannery O'Connor","To Kill a Mockingbird"],
  q:[
  ["Who wrote 'The past is never dead. It's not even past'?","William Faulkner","Thomas Wolfe","Robert Penn Warren","Harper Lee"],
  ["Who narrates the first section of The Sound and the Fury?","Benjy","Quentin","Jason","Dilsey"],
  ["Which novel follows a family carrying their mother's coffin?","As I Lay Dying","Light in August","Absalom, Absalom!","Sanctuary"],
  ["Who wrote 'A Good Man Is Hard to Find'?","Flannery O'Connor","Eudora Welty","Carson McCullers","Katherine Anne Porter"],
  ["Who defends Tom Robinson in To Kill a Mockingbird?","Atticus Finch","Boo Radley","Bob Ewell","Heck Tate"],
  ["Which novel is about a populist governor?","All the King's Men","Look Homeward, Angel","The Heart Is a Lonely Hunter","Wise Blood"]]},

{ t:"The Harlem Renaissance", s:"The New Negro",
  sec:[
  ["A cultural flowering",[
    "The Harlem Renaissance (about 1918 to the mid-1930s) was an explosion of African American literature, music, art, and thought centered in Harlem, New York, fueled by the Great Migration from the South. Philosopher Alain Locke's anthology The New Negro (1925) proclaimed a new spirit of pride and self-expression.",
    "W. E. B. Du Bois, whose The Souls of Black Folk (1903) described 'double consciousness,' the sense of 'always looking at one's self through the eyes of others,' and edited the NAACP's magazine The Crisis, was a guiding intellectual."]],
  ["Langston Hughes",[
    "Langston Hughes (1901–1967), the movement's leading poet, wove jazz and blues rhythms and everyday speech into poetry celebrating Black life. 'The Negro Speaks of Rivers' (written at 17) connects African American identity to ancient rivers; 'I, Too' declares 'I, too, sing America'; 'Harlem' asks 'What happens to a dream deferred? / Does it dry up / like a raisin in the sun?'",
    "His essay 'The Negro Artist and the Racial Mountain' (1926) urged Black artists to express themselves without shame."]],
  ["Other voices",[
    "Claude McKay's sonnet 'If We Must Die' (1919) responded to racist violence; Countee Cullen wrote formal lyrics; Jean Toomer's Cane (1923) blended poetry and prose about Southern and Northern Black life. Nella Larsen's Passing (1929) explored women who pass as white.",
    "Writers and artists were supported (and sometimes constrained) by white patrons, and gathered in salons and clubs while jazz musicians like Duke Ellington played the Cotton Club."]],
  ["Zora Neale Hurston",[
    "Zora Neale Hurston (1891–1960), novelist and anthropologist, collected African American folklore in the South and Caribbean. Their Eyes Were Watching God (1937) follows Janie Crawford's search for love and selfhood through three marriages in Florida, written in vivid Black Southern vernacular.",
    "Criticized by some contemporaries and forgotten at her death, Hurston was rediscovered after Alice Walker's 1975 essay 'In Search of Zora Neale Hurston,' and is now a canonical author."]],
  ["Legacy and later writers",[
    "The Harlem Renaissance laid the foundation for later African American literature: Richard Wright's Native Son (1940), about Bigger Thomas, a young man in Chicago trapped by racism and violence; Ralph Ellison's Invisible Man (1952), whose nameless narrator declares 'I am an invisible man'; and James Baldwin.",
    "It also influenced the Négritude movement in the French-speaking world, led by Aimé Césaire and Léopold Sédar Senghor."]]
  ],
  terms:[["Harlem Renaissance","1920s–30s African American cultural flowering."],["New Negro","Locke's term for a new Black pride."],["Double consciousness","Du Bois's concept of seeing oneself through others' eyes."],["Dream deferred","Image from Hughes's 'Harlem.'"],["Négritude","Francophone movement of Black cultural pride."]],
  w:"The Harlem Renaissance gave African American voices a central place in modern literature and culture.",
  src:["Harlem Renaissance","Langston Hughes","Zora Neale Hurston","The Souls of Black Folk","Their Eyes Were Watching God"],
  q:[
  ["Who described 'double consciousness'?","W. E. B. Du Bois","Alain Locke","Langston Hughes","Booker T. Washington"],
  ["Which poem asks 'What happens to a dream deferred?'","Harlem","I, Too","The Negro Speaks of Rivers","If We Must Die"],
  ["Who wrote Their Eyes Were Watching God?","Zora Neale Hurston","Nella Larsen","Jessie Fauset","Alice Walker"],
  ["Who edited the anthology The New Negro (1925)?","Alain Locke","W. E. B. Du Bois","Countee Cullen","Claude McKay"],
  ["Whose essay helped rediscover Hurston in 1975?","Alice Walker","Toni Morrison","Maya Angelou","bell hooks"],
  ["Which novel's narrator declares 'I am an invisible man'?","Invisible Man","Native Son","Cane","Passing"]]}

);


/* ---- from lit-18.js ---- */
/* LITERATURE FOUNDATIONS, part 18: Unit 7 chapters 10-11 */
COURSES.literature.units[6].ch.push(

{ t:"Russian Literature in the Soviet Century", s:"Poets, censors, and witnesses",
  sec:[
  ["The Silver Age",[
    "Before and after the 1917 Revolution, Russia's 'Silver Age' produced brilliant poetry: Alexander Blok's The Twelve, Vladimir Mayakovsky's futurist verse celebrating the revolution, Marina Tsvetaeva's passionate lyrics, Osip Mandelstam, and Anna Akhmatova. Andrei Bely's novel Petersburg is a modernist masterpiece.",
    "Maxim Gorky's realist plays and novels about the poor made him the father of Soviet literature."]],
  ["Under Stalin",[
    "In 1934 the Soviet state imposed 'socialist realism,' requiring literature to glorify the revolution and depict reality 'in its revolutionary development.' Writers who did not conform faced censorship, imprisonment, or death. Mandelstam, who wrote a satirical epigram about Stalin, died in a transit camp in 1938; the writer Isaac Babel, author of Red Cavalry, was shot in 1940; Tsvetaeva died by suicide in 1941.",
    "Anna Akhmatova (1889–1966) composed Requiem (1935–40) about waiting in prison lines for news of her arrested son; poems were memorized by friends and burned to avoid discovery: 'I was with my people then, / There, where my people, unfortunately, were.'"]],
  ["Bulgakov and Pasternak",[
    "Mikhail Bulgakov's The Master and Margarita, written in secret from 1928 until his death in 1940 and published in censored form only in 1966–67, imagines the devil, Woland, and his entourage (including a giant talking cat, Behemoth) wreaking havoc in Stalin's Moscow, interwoven with a novel about Pontius Pilate. Its line 'Manuscripts don't burn' became a motto of resistance.",
    "Boris Pasternak's Doctor Zhivago, about a poet-doctor's life and love for Lara during the revolution and civil war, was refused publication in the USSR, smuggled to Italy, and published there in 1957. Awarded the Nobel Prize in 1958, Pasternak was forced to decline it under official pressure."]],
  ["Solzhenitsyn and dissent",[
    "Aleksandr Solzhenitsyn (1918–2008), imprisoned in the Gulag labor camps for criticizing Stalin in a private letter, published One Day in the Life of Ivan Denisovich (1962) during Khrushchev's 'thaw,' a sensation describing a single day in a camp. The Gulag Archipelago (1973), a vast history of the Soviet camp system based on hundreds of testimonies, was published abroad; he was expelled from the USSR in 1974.",
    "Samizdat ('self-publishing') circulated forbidden texts in typewritten copies, and tamizdat ('published there') smuggled works abroad. Vasily Grossman's Life and Fate, an epic of Stalingrad comparing Nazism and Stalinism, was 'arrested' by the KGB but survived on microfilm."]],
  ["Nabokov and later writers",[
    "Vladimir Nabokov (1899–1977) fled the revolution and wrote Russian novels in Berlin before switching to English in America; his work is discussed elsewhere. Poet Joseph Brodsky, tried in 1964 as a 'social parasite' and exiled in 1972, won the Nobel Prize in 1987.",
    "After the Soviet collapse, writers such as Svetlana Alexievich (Belarusian, Nobel 2015), whose oral histories record ordinary people's experiences of war, Chernobyl, and Soviet life, continued the tradition of witness."]]
  ],
  terms:[["Socialist realism","Soviet doctrine for state-approved art."],["Samizdat","Underground self-published literature."],["Gulag","Soviet labor camp system."],["Requiem","Akhmatova's poem of the Terror."],["Manuscripts don't burn","Line from The Master and Margarita."]],
  w:"Soviet-era writers kept truth and imagination alive under censorship and terror, often at great cost.",
  src:["Anna Akhmatova","The Master and Margarita","Doctor Zhivago","Aleksandr Solzhenitsyn","Samizdat"],
  q:[
  ["Which novel features the devil Woland in Moscow?","The Master and Margarita","Doctor Zhivago","Life and Fate","Petersburg"],
  ["Who was forced to decline the 1958 Nobel Prize?","Boris Pasternak","Solzhenitsyn","Bulgakov","Akhmatova"],
  ["Which book describes one day in a labor camp?","One Day in the Life of Ivan Denisovich","The Gulag Archipelago","Requiem","Kolyma Tales"],
  ["What is samizdat?","Underground self-published literature","State publishing","A Soviet prize","A type of poem"],
  ["Who wrote Requiem about waiting outside prisons?","Anna Akhmatova","Marina Tsvetaeva","Osip Mandelstam","Joseph Brodsky"],
  ["Which Belarusian oral historian won the 2015 Nobel?","Svetlana Alexievich","Lyudmila Ulitskaya","Tatyana Tolstaya","Herta Müller"]]},

{ t:"Modern Drama: Brecht, Lorca, and the American Stage", s:"Theater remade",
  sec:[
  ["Bertolt Brecht",[
    "Bertolt Brecht (1898–1956), German Marxist playwright, created 'epic theater,' using the 'Verfremdungseffekt' (alienation or distancing effect), with songs, placards, and actors stepping out of roles, to make audiences think critically rather than identify emotionally. The Threepenny Opera (1928, with Kurt Weill) satirized capitalism.",
    "In exile from the Nazis he wrote Mother Courage and Her Children (1939), about a canteen woman who profits from the Thirty Years' War while losing all her children, The Life of Galileo, and The Caucasian Chalk Circle."]],
  ["Lorca",[
    "Federico García Lorca (1898–1936), Spain's great poet-dramatist, drew on Andalusian folk culture, flamenco, and Romani traditions in Gypsy Ballads and Poet in New York. His 'rural trilogy,' Blood Wedding, Yerma, and The House of Bernarda Alba (finished 1936), depicts passion, honor, and repression of women.",
    "At the start of the Spanish Civil War in 1936, Lorca was murdered by Nationalist forces near Granada; his body has never been found."]],
  ["Tennessee Williams",[
    "Tennessee Williams (1911–1983) wrote poetic dramas of fragile, wounded people. The Glass Menagerie (1944), a 'memory play,' portrays Tom, his faded Southern mother Amanda, and his shy sister Laura with her glass animal collection. A Streetcar Named Desire (1947) sets the fading Southern belle Blanche DuBois against her brutal brother-in-law Stanley Kowalski ('I have always depended on the kindness of strangers').",
    "Cat on a Hot Tin Roof explored family lies and repressed sexuality."]],
  ["Arthur Miller",[
    "Arthur Miller (1915–2005) wrote moral dramas about responsibility and society. Death of a Salesman (1949) portrays Willy Loman, an aging salesman whose faith in the American Dream of popularity and success collapses, leading to suicide; his wife insists 'attention must be paid.' Miller called it a tragedy of the common man.",
    "The Crucible (1953), about the 1692 Salem witch trials, was an allegory of McCarthyism's anti-communist hunts; Miller himself was convicted of contempt of Congress for refusing to name names (overturned on appeal)."]],
  ["Later American and British drama",[
    "Edward Albee's Who's Afraid of Virginia Woolf? (1962) exposed a marriage's cruel games. Lorraine Hansberry's A Raisin in the Sun (1959), its title from Langston Hughes, was the first play by a Black woman produced on Broadway. August Wilson's ten-play Pittsburgh Cycle chronicled African American life decade by decade through the 20th century, including Fences and The Piano Lesson.",
    "In Britain, John Osborne's Look Back in Anger (1956) launched the 'angry young men'; Harold Pinter's menacing pauses (The Birthday Party, The Homecoming) and Tom Stoppard's witty plays of ideas (Rosencrantz and Guildenstern Are Dead, Arcadia) followed. Caryl Churchill's Top Girls examined women and power."]]
  ],
  terms:[["Epic theater","Brecht's critical, distancing theater."],["Verfremdungseffekt","Alienation effect preventing identification."],["Memory play","Drama shaped by a narrator's memory."],["Tragedy of the common man","Miller's idea of ordinary tragic heroes."],["Pinter pause","Charged silence in Pinter's plays."]],
  w:"Modern dramatists reinvented theater as a place of critique, poetry, and moral reckoning.",
  src:["Bertolt Brecht","Federico García Lorca","A Streetcar Named Desire","Death of a Salesman","August Wilson"],
  q:[
  ["Which Brecht play follows a woman profiting from the Thirty Years' War?","Mother Courage and Her Children","The Threepenny Opera","Galileo","The Caucasian Chalk Circle"],
  ["How did Lorca die?","Murdered by Nationalist forces in 1936","In exile","Of illness","In a car accident"],
  ["Who depends 'on the kindness of strangers'?","Blanche DuBois","Amanda Wingfield","Maggie the Cat","Laura Wingfield"],
  ["Which play allegorized McCarthyism through the Salem witch trials?","The Crucible","Death of a Salesman","All My Sons","A View from the Bridge"],
  ["Which was the first play by a Black woman on Broadway?","A Raisin in the Sun","Fences","for colored girls","Trouble in Mind"],
  ["Who wrote the ten-play Pittsburgh Cycle?","August Wilson","Lorraine Hansberry","Amiri Baraka","Suzan-Lori Parks"]]}

);


/* ---- from lit-19.js ---- */
/* LITERATURE FOUNDATIONS, part 19: Unit 8 Postwar and Contemporary, chapters 1-4 */
COURSES.literature.units.push({ t:"Postwar and Contemporary Literature", ch:[

{ t:"Dystopias: Huxley, Orwell, and Beyond", s:"Warnings from the future",
  sec:[
  ["Utopia's dark twin",[
    "Dystopian fiction imagines nightmarish societies to warn about tendencies in the present. Yevgeny Zamyatin's We (1920–21), banned in the Soviet Union, depicted a glass-walled totalitarian state where people are numbers, and influenced later dystopias.",
    "The 20th century's totalitarian regimes, world wars, and technologies of control made dystopia one of its most important genres."]],
  ["Brave New World",[
    "Aldous Huxley's Brave New World (1932), its title from The Tempest, imagines a World State where humans are mass-produced in hatcheries and conditioned into castes (Alphas to Epsilons), kept content by consumerism, casual sex, and the drug soma. Henry Ford is revered as a god ('Our Ford').",
    "When John 'the Savage,' raised outside the system and steeped in Shakespeare, enters this world, he rejects its shallow happiness and claims 'the right to be unhappy.' Huxley's dystopia warns of control through pleasure rather than fear."]],
  ["George Orwell",[
    "George Orwell (Eric Blair, 1903–1950) was a journalist and essayist who fought in the Spanish Civil War (Homage to Catalonia) and committed himself to 'democratic socialism' and plain, honest prose ('Good prose is like a windowpane'). Animal Farm (1945) is an allegorical fable in which farm animals overthrow their human master but are betrayed by the pigs, led by Napoleon (representing Stalin): 'All animals are equal, but some animals are more equal than others.'",
    "Nineteen Eighty-Four (1949) depicts Oceania, ruled by the Party and its leader Big Brother, where Winston Smith works at the Ministry of Truth rewriting history. Concepts such as Newspeak, doublethink, thoughtcrime, the Thought Police, and Room 101 entered the language. 'Orwellian' describes propaganda and surveillance."]],
  ["Later dystopias",[
    "Ray Bradbury's Fahrenheit 451 (1953) imagines firemen who burn books; Anthony Burgess's A Clockwork Orange (1962) questions whether forced goodness is moral; Margaret Atwood's The Handmaid's Tale (1985) depicts Gilead, a theocracy that forces fertile women to bear children for elite men; Kazuo Ishiguro's Never Let Me Go (2005) portrays clones raised for organ donation; and Suzanne Collins's The Hunger Games (2008) brought dystopia to young adult readers.",
    "William Golding's Lord of the Flies (1954), about schoolboys stranded on an island descending into savagery, explores similar fears about human nature."]],
  ["Why dystopias matter",[
    "Dystopias sharpen our awareness of threats to freedom: surveillance, propaganda, inequality, technology, and environmental collapse. Sales of Nineteen Eighty-Four and The Handmaid's Tale have surged during political crises.",
    "Orwell's essay 'Politics and the English Language' (1946) warned how vague language enables political deception."]]
  ],
  terms:[["Dystopia","Imagined nightmarish society."],["Big Brother","Nineteen Eighty-Four's ever-watching leader."],["Doublethink","Holding two contradictory beliefs."],["Soma","Pleasure drug in Brave New World."],["Orwellian","Evoking propaganda and surveillance."]],
  w:"Dystopian fiction gives us the language to recognize and resist threats to freedom.",
  src:["Nineteen Eighty-Four","Brave New World","Animal Farm","Fahrenheit 451","The Handmaid's Tale"],
  q:[
  ["Which novel features Big Brother?","Nineteen Eighty-Four","Brave New World","We","Fahrenheit 451"],
  ["What drug keeps people content in Brave New World?","Soma","Victory Gin","Melange","Moloko"],
  ["Who says 'some animals are more equal than others'?","The pigs in Animal Farm","Big Brother","The Savage","Winston Smith"],
  ["In Fahrenheit 451, what do firemen do?","Burn books","Fight fires","Arrest poets","Guard libraries"],
  ["Who wrote The Handmaid's Tale?","Margaret Atwood","Ursula K. Le Guin","Octavia Butler","Doris Lessing"],
  ["Which Russian dystopia influenced Orwell and Huxley?","We","The Master and Margarita","Doctor Zhivago","Petersburg"]]},

{ t:"Existentialism and the Absurd", s:"Sartre, Camus, Beckett",
  sec:[
  ["Existentialism",[
    "Existentialism, flourishing in postwar France, held that humans have no fixed essence or divinely given purpose: 'existence precedes essence,' in Jean-Paul Sartre's formula. We are 'condemned to be free,' responsible for creating meaning through choices, and must avoid 'bad faith,' self-deception about our freedom.",
    "Sartre (1905–1980) expressed these ideas in the novel Nausea (1938) and plays such as No Exit (Huis Clos, 1944), in which three dead people trapped in a room discover that 'Hell is other people.' He declined the Nobel Prize in 1964. Simone de Beauvoir's The Second Sex (1949) applied existentialism to women: 'One is not born, but rather becomes, a woman.'"]],
  ["Albert Camus",[
    "Albert Camus (1913–1960), born in French Algeria to a poor family, explored 'the absurd,' the clash between humanity's longing for meaning and the universe's silence. In The Myth of Sisyphus (1942), he concluded that, like Sisyphus endlessly pushing his boulder uphill, 'one must imagine Sisyphus happy.'",
    "The Stranger (L'Étranger, 1942) opens 'Today, Mother died. Or maybe yesterday, I don't know' and follows Meursault, who kills an Arab man on a beach and is condemned as much for not weeping at his mother's funeral as for the murder. The Plague (1947), about an epidemic in Oran, is read as an allegory of the Nazi occupation and of solidarity. Camus won the Nobel Prize in 1957 and died in a car crash in 1960."]],
  ["Theatre of the Absurd",[
    "Critic Martin Esslin coined 'Theatre of the Absurd' (1961) for playwrights who dramatized meaninglessness through illogical situations, repetitive dialogue, and circular plots: Eugène Ionesco (The Bald Soprano, Rhinoceros, in which townspeople turn into rhinoceroses, an allegory of conformity to fascism), Jean Genet, Arthur Adamov, and early Harold Pinter.",
    "Samuel Beckett is the greatest of these writers."]],
  ["Samuel Beckett",[
    "Samuel Beckett (1906–1989), an Irishman in Paris who wrote in both French and English, served in the French Resistance. Waiting for Godot (1953) shows two tramps, Vladimir and Estragon, waiting by a bare tree for someone named Godot who never arrives; a critic called it a play in which 'nothing happens, twice.' Its last lines: 'Well, shall we go?' 'Yes, let's go.' (They do not move.)",
    "Endgame, Krapp's Last Tape, and Happy Days (a woman buried up to her waist, then her neck) are similarly stark; his novels include Molloy and The Unnamable ('I can't go on, I'll go on'). He won the Nobel Prize in 1969."]],
  ["Legacy",[
    "Existential and absurdist ideas influenced novelists, filmmakers, and popular culture, raising questions about freedom, authenticity, and meaning without religion.",
    "Beckett's minimalism shaped later theater and art, while Camus remains one of the most widely read 20th-century authors."]]
  ],
  terms:[["Existence precedes essence","Sartre's existentialist principle."],["Bad faith","Self-deception about one's freedom."],["The absurd","Clash between our search for meaning and a silent universe."],["Theatre of the Absurd","Drama of meaninglessness."],["Waiting for Godot","Beckett's play of endless waiting."]],
  w:"Existentialist and absurdist writers asked how to live meaningfully in a universe without given meaning.",
  src:["Existentialism","Albert Camus","The Stranger (Camus novel)","Waiting for Godot","Theatre of the Absurd"],
  q:[
  ["Which play says 'Hell is other people'?","No Exit","Waiting for Godot","Rhinoceros","The Bald Soprano"],
  ["Who wrote 'one must imagine Sisyphus happy'?","Albert Camus","Jean-Paul Sartre","Simone de Beauvoir","Samuel Beckett"],
  ["Which novel opens 'Today, Mother died'?","The Stranger","The Plague","Nausea","The Fall"],
  ["Who wrote 'One is not born, but rather becomes, a woman'?","Simone de Beauvoir","Virginia Woolf","Betty Friedan","Hélène Cixous"],
  ["Who never arrives in Waiting for Godot?","Godot","Pozzo","Lucky","Estragon"],
  ["Who declined the Nobel Prize in 1964?","Jean-Paul Sartre","Albert Camus","Samuel Beckett","Eugène Ionesco"]]},

{ t:"Postwar American Fiction", s:"Salinger, Nabokov, Bellow, Roth, and others",
  sec:[
  ["The postwar novel",[
    "After World War II, American fiction explored affluence, conformity, alienation, Jewish and immigrant identity, war, and the inner lives of the middle class. Norman Mailer's The Naked and the Dead and Joseph Heller's Catch-22 (1961), whose title names a bureaucratic paradox (a pilot can be excused from missions for insanity, but asking to be excused proves sanity), portrayed war's absurdity.",
    "Kurt Vonnegut's Slaughterhouse-Five (1969), drawing on his survival of the 1945 firebombing of Dresden as a prisoner of war, mixed science fiction and anti-war satire ('So it goes')."]],
  ["Salinger",[
    "J. D. Salinger's The Catcher in the Rye (1951) is narrated by Holden Caulfield, a 16-year-old who, after being expelled from prep school, wanders New York denouncing 'phonies' and dreaming of catching children before they fall from a cliff. It became a defining novel of adolescent alienation and was frequently banned.",
    "Salinger withdrew from public life and stopped publishing after 1965."]],
  ["Nabokov",[
    "Vladimir Nabokov's Lolita (1955), narrated by the eloquent, self-justifying Humbert Humbert, a European scholar who abuses his twelve-year-old stepdaughter Dolores Haze, was published first in Paris after American publishers refused it. Its dazzling style and monstrous narrator make it a disturbing study of manipulation and an unreliable narrator.",
    "Pale Fire (1962), a 999-line poem with a mad commentator's notes, and the memoir Speak, Memory show his playful brilliance; Nabokov was also an expert on butterflies."]],
  ["Jewish American writers",[
    "Saul Bellow (Nobel 1976) wrote energetic, philosophical novels: The Adventures of Augie March ('I am an American, Chicago born'), Herzog, and Humboldt's Gift. Bernard Malamud's The Assistant and Isaac Bashevis Singer's Yiddish stories (Nobel 1978) explored Jewish life. Philip Roth (1933–2018) moved from the comic Portnoy's Complaint (1969) to the 'American trilogy,' including American Pastoral, and The Plot Against America, imagining Charles Lindbergh as a pro-Nazi president.",
    "Cynthia Ozick and Grace Paley also enriched this tradition."]],
  ["Suburbs and the South",[
    "John Cheever's stories ('The Swimmer') and John Updike's Rabbit novels chronicled suburban America; Richard Yates's Revolutionary Road depicted a marriage destroyed by conformity. Jack Kerouac's On the Road (1957) celebrated restless freedom.",
    "Later, Cormac McCarthy (Blood Meridian, The Road) and Don DeLillo (White Noise, Underworld) explored violence, media, and modern anxiety."]]
  ],
  terms:[["Catch-22","A no-win bureaucratic paradox."],["The Catcher in the Rye","Salinger's novel of adolescent alienation."],["Lolita","Nabokov's novel with a monstrous narrator."],["American Pastoral","Roth novel about a shattered American dream."],["So it goes","Refrain of Slaughterhouse-Five."]],
  w:"Postwar American fiction captured affluence, alienation, war, and identity in a rapidly changing nation.",
  src:["The Catcher in the Rye","Catch-22","Slaughterhouse-Five","Lolita","Saul Bellow"],
  q:[
  ["Who narrates The Catcher in the Rye?","Holden Caulfield","Nick Carraway","Augie March","Yossarian"],
  ["Which novel coined a term for a no-win paradox?","Catch-22","Slaughterhouse-Five","The Naked and the Dead","Herzog"],
  ["What event did Vonnegut survive that inspired Slaughterhouse-Five?","The firebombing of Dresden","Pearl Harbor","D-Day","Hiroshima"],
  ["Where was Lolita first published?","Paris","New York","London","Berlin"],
  ["Which Roth novel imagines Lindbergh as president?","The Plot Against America","American Pastoral","Portnoy's Complaint","The Human Stain"],
  ["Which Yiddish writer won the 1978 Nobel Prize?","Isaac Bashevis Singer","Sholem Aleichem","Saul Bellow","Bernard Malamud"]]},

{ t:"Baldwin, Morrison, and African American Literature", s:"Witness and imagination",
  sec:[
  ["Richard Wright and Ralph Ellison",[
    "Richard Wright's Native Son (1940), about Bigger Thomas, a young Black man in Chicago whose life is shaped by racism and poverty and who commits murder, was a bestseller and protest novel; his memoir Black Boy describes growing up in the Jim Crow South.",
    "Ralph Ellison's Invisible Man (1952), winner of the National Book Award, follows a nameless narrator through the South, Harlem, and a political 'Brotherhood,' discovering that white society refuses to see him. Its jazz-like improvisational style and symbolism made it a classic."]],
  ["James Baldwin",[
    "James Baldwin (1924–1987), raised in Harlem and briefly a teenage preacher, moved to Paris in 1948 to escape American racism. Go Tell It on the Mountain (1953) drew on his Pentecostal upbringing; Giovanni's Room (1956) portrayed love between men. His essays, Notes of a Native Son and The Fire Next Time (1963), combined personal testimony and prophetic urgency about race in America: 'If we... do not falter in our duty now, we may be able... to end the racial nightmare.'",
    "Baldwin became a leading voice of the civil rights era; the documentary I Am Not Your Negro (2016) revived interest in his work."]],
  ["Poetry and drama",[
    "Gwendolyn Brooks became the first Black poet to win the Pulitzer Prize (1950); her poem 'We Real Cool' is widely anthologized. The Black Arts Movement of the 1960s–70s, led by Amiri Baraka, called for art serving Black liberation. Maya Angelou's memoir I Know Why the Caged Bird Sings (1969) and poems such as 'Still I Rise' became beloved.",
    "Ntozake Shange's for colored girls who have considered suicide / when the rainbow is enuf (1976) combined poetry and dance."]],
  ["Toni Morrison",[
    "Toni Morrison (1931–2019), an editor at Random House, wrote novels of lyrical intensity exploring Black American history and identity. The Bluest Eye (1970) tells of Pecola Breedlove, who longs for blue eyes; Song of Solomon (1977) follows Milkman Dead's search for his ancestry; Beloved (1987), inspired by the real story of Margaret Garner, depicts Sethe, a formerly enslaved woman haunted by the ghost of the daughter she killed rather than let her be taken back into slavery.",
    "Beloved won the Pulitzer Prize, and in 1993 Morrison became the first Black woman to win the Nobel Prize in Literature."]],
  ["Contemporary voices",[
    "Alice Walker's The Color Purple (1982, Pulitzer Prize), told through Celie's letters to God, depicts a Black woman's journey from abuse to selfhood. Later writers include Octavia Butler (Kindred, the Parable novels), August Wilson, Colson Whitehead (The Underground Railroad, The Nickel Boys, both Pulitzer winners), Jesmyn Ward (two National Book Awards), Ta-Nehisi Coates, and poets Rita Dove and Natasha Trethewey.",
    "African American literature has been central to American literature's exploration of freedom, memory, and identity."]]
  ],
  terms:[["Protest novel","Fiction attacking social injustice."],["Invisible Man","Ellison's novel of racial invisibility."],["The Fire Next Time","Baldwin's essays on race."],["Beloved","Morrison's novel of slavery's haunting legacy."],["Black Arts Movement","1960s–70s movement of Black artistic expression."]],
  w:"African American writers have given American literature many of its most powerful works of witness and imagination.",
  src:["James Baldwin","Toni Morrison","Beloved (novel)","Native Son","The Color Purple"],
  q:[
  ["Who wrote The Fire Next Time?","James Baldwin","Richard Wright","Ralph Ellison","Malcolm X"],
  ["Who became the first Black woman to win the Nobel Prize in Literature (1993)?","Toni Morrison","Maya Angelou","Alice Walker","Gwendolyn Brooks"],
  ["Which novel is inspired by the story of Margaret Garner?","Beloved","Song of Solomon","The Bluest Eye","Jazz"],
  ["Who was the first Black poet to win the Pulitzer Prize?","Gwendolyn Brooks","Langston Hughes","Rita Dove","Countee Cullen"],
  ["Which novel is told through Celie's letters?","The Color Purple","Their Eyes Were Watching God","Kindred","Jazz"],
  ["Whose novel Native Son features Bigger Thomas?","Richard Wright","James Baldwin","Ralph Ellison","Chester Himes"]]}

]});


/* ---- from lit-20.js ---- */
/* LITERATURE FOUNDATIONS, part 20: Unit 8 chapters 5-8 */
COURSES.literature.units[7].ch.push(

{ t:"Postwar Poetry: Beats, Confessionals, and Beyond", s:"New voices after 1945",
  sec:[
  ["W. H. Auden and the transition",[
    "W. H. Auden (1907–1973), the leading English poet of the 1930s, wrote political and moral poems ('September 1, 1939': 'We must love one another or die'), the elegy 'In Memory of W. B. Yeats' ('poetry makes nothing happen'), and 'Funeral Blues' ('Stop all the clocks'). He moved to America in 1939.",
    "Welsh poet Dylan Thomas's lush, musical verse ('Do not go gentle into that good night,' the radio play Under Milk Wood) made him a celebrated performer."]],
  ["The Beat Generation",[
    "The Beats rejected postwar conformity, celebrating spontaneity, jazz, drugs, Eastern spirituality, and sexual freedom. Allen Ginsberg's 'Howl' (1956) opens 'I saw the best minds of my generation destroyed by madness'; its publisher, Lawrence Ferlinghetti of City Lights Books, was tried for obscenity and acquitted in 1957.",
    "Jack Kerouac's On the Road, reportedly typed on a 120-foot scroll, and William S. Burroughs's Naked Lunch complete the Beat canon; their influence on 1960s counterculture was enormous."]],
  ["Confessional poetry",[
    "Confessional poets wrote openly about mental illness, family, sexuality, and suicide. Robert Lowell's Life Studies (1959) launched the mode; Anne Sexton and John Berryman followed. Sylvia Plath (1932–1963), married to the English poet Ted Hughes, wrote the searing poems of Ariel ('Daddy,' 'Lady Lazarus': 'Dying / Is an art, like everything else') in the months before her suicide, and the novel The Bell Jar.",
    "Her posthumous fame and Hughes's role in editing her work became a long-running controversy."]],
  ["Other major poets",[
    "Elizabeth Bishop's precise, restrained poems ('One Art': 'The art of losing isn't hard to master') contrast with the confessionals. Philip Larkin wrote wry, melancholy poems of English life ('This Be The Verse,' 'An Arundel Tomb': 'What will survive of us is love'). Ted Hughes wrote violent poems of nature and animals (Crow) and Birthday Letters about Plath.",
    "Seamus Heaney (1939–2013), from Northern Ireland, wrote of rural childhood, history, and the Troubles ('Digging,' 'Punishment') and won the Nobel Prize in 1995. Derek Walcott, Adrienne Rich, Audre Lorde, John Ashbery, and Mary Oliver also shaped the period."]],
  ["Contemporary poetry",[
    "Recent decades have brought spoken word and slam poetry, Instagram poets such as Rupi Kaur, and celebrated poets including Louise Glück (Nobel 2020), Carol Ann Duffy (first woman UK Poet Laureate, 2009), Ocean Vuong, Tracy K. Smith, Claudia Rankine (Citizen), and Amanda Gorman, who read 'The Hill We Climb' at President Biden's 2021 inauguration.",
    "Poetry remains vibrant in performance, print, and online."]]
  ],
  terms:[["Beat Generation","1950s countercultural writers."],["Howl","Ginsberg's landmark Beat poem."],["Confessional poetry","Poetry of intimate personal experience."],["Ariel","Plath's final collection."],["Spoken word","Poetry written for performance."]],
  w:"Postwar poets broke taboos and expanded who and what poetry could speak for.",
  src:["Beat Generation","Howl","Confessional poetry","Sylvia Plath","Seamus Heaney"],
  q:[
  ["Which poem opens 'I saw the best minds of my generation destroyed by madness'?","Howl","Daddy","Lady Lazarus","September 1, 1939"],
  ["Who wrote The Bell Jar?","Sylvia Plath","Anne Sexton","Elizabeth Bishop","Adrienne Rich"],
  ["Whose Life Studies (1959) launched confessional poetry?","Robert Lowell","John Berryman","Allen Ginsberg","Ted Hughes"],
  ["Which Northern Irish poet won the 1995 Nobel Prize?","Seamus Heaney","Paul Muldoon","Derek Mahon","Louis MacNeice"],
  ["Who wrote 'The art of losing isn't hard to master'?","Elizabeth Bishop","Sylvia Plath","Marianne Moore","Mary Oliver"],
  ["Who read 'The Hill We Climb' at the 2021 inauguration?","Amanda Gorman","Maya Angelou","Elizabeth Alexander","Rita Dove"]]},

{ t:"Postmodernism", s:"Borges, Calvino, Pynchon, and play",
  sec:[
  ["What is postmodernism?",[
    "Postmodern literature (roughly 1950s onward) responded to modernism and to a world of mass media, consumerism, and skepticism about grand narratives. Philosopher Jean-François Lyotard defined the postmodern as 'incredulity toward metanarratives.' Postmodern fiction features metafiction, pastiche, parody, irony, playfulness, unreliable realities, and mixing of high and popular culture.",
    "Where modernism often mourned lost unity, postmodernism tends to play with fragmentation."]],
  ["Jorge Luis Borges",[
    "Argentine writer Jorge Luis Borges (1899–1986), director of Argentina's National Library despite becoming blind, wrote short, erudite 'fictions' that are philosophical puzzles. 'The Library of Babel' imagines a universe-library containing every possible book; 'The Garden of Forking Paths' imagines a novel in which all possible outcomes occur; 'Pierre Menard, Author of the Quixote' describes a man who rewrites Don Quixote word for word, yet whose text is 'richer.'",
    "His collections Ficciones (1944) and The Aleph made him a forerunner of postmodernism and magical realism."]],
  ["Calvino and Eco",[
    "Italo Calvino (1923–1985) moved from neorealism to fantastic fiction: Invisible Cities, in which Marco Polo describes imaginary cities to Kublai Khan, and If on a Winter's Night a Traveler (1979), written in the second person about 'you,' the reader, trying to read a novel that keeps breaking off into the beginnings of ten different novels.",
    "Umberto Eco, a semiotician, wrote The Name of the Rose (1980), a medieval monastery murder mystery full of philosophy and puzzles, and a huge bestseller."]],
  ["American postmodernists",[
    "Thomas Pynchon's Gravity's Rainbow (1973) is an immense, paranoid novel about V-2 rockets and conspiracy at the end of World War II; The Crying of Lot 49 is a short entry point. John Barth, Donald Barthelme, and William Gaddis experimented with form. Don DeLillo's White Noise (1985) satirized consumer culture and media.",
    "David Foster Wallace's Infinite Jest (1996), over a thousand pages with nearly 400 endnotes, explored addiction and entertainment, and moved toward 'new sincerity.'"]],
  ["Elsewhere",[
    "Georges Perec's Life: A User's Manual and his novel La Disparition, written entirely without the letter 'e,' came from the French Oulipo group, which used constraints to generate literature. John Fowles's The French Lieutenant's Woman offered alternative endings; Milan Kundera's The Unbearable Lightness of Being mixed philosophy and narrative.",
    "Critics debate whether postmodernism has ended; terms like 'metamodernism' and 'post-postmodernism' describe newer writing that combines irony with sincerity."]]
  ],
  terms:[["Postmodernism","Playful, skeptical literature after modernism."],["Metanarrative","Grand story claiming to explain everything."],["Pastiche","Imitation mixing styles."],["Oulipo","French group writing under constraints."],["Metafiction","Fiction about fiction."]],
  w:"Postmodern writers turned literature into a playground for ideas about reality, language, and reading itself.",
  src:["Postmodern literature","Jorge Luis Borges","Italo Calvino","Gravity's Rainbow","Oulipo"],
  q:[
  ["Who wrote 'The Library of Babel'?","Jorge Luis Borges","Italo Calvino","Umberto Eco","Julio Cortázar"],
  ["Which Calvino novel is written in the second person about the reader?","If on a Winter's Night a Traveler","Invisible Cities","The Baron in the Trees","Cosmicomics"],
  ["Who wrote The Name of the Rose?","Umberto Eco","Italo Calvino","Primo Levi","Alessandro Baricco"],
  ["Which novel was written without the letter 'e'?","La Disparition","Gravity's Rainbow","Infinite Jest","Ficciones"],
  ["How did Lyotard define the postmodern?","Incredulity toward metanarratives","Love of tradition","Return to realism","Faith in progress"],
  ["Who wrote Gravity's Rainbow?","Thomas Pynchon","Don DeLillo","John Barth","David Foster Wallace"]]},

{ t:"The Latin American Boom", s:"Magical realism and beyond",
  sec:[
  ["The Boom",[
    "In the 1960s and 70s, Latin American novelists achieved worldwide fame in what became known as the 'Boom.' Its writers experimented with form, blended history and myth, and confronted dictatorship, inequality, and colonial legacies. Spanish publisher Carlos Barral and literary agent Carmen Balcells promoted them internationally.",
    "Earlier writers paved the way: Borges; Cuba's Alejo Carpentier, who coined 'lo real maravilloso' (the marvelous real); Guatemala's Miguel Ángel Asturias (Nobel 1967); and Mexico's Juan Rulfo, whose short novel Pedro Páramo (1955), set in a village of ghosts, deeply influenced García Márquez."]],
  ["García Márquez",[
    "Gabriel García Márquez (1927–2014) of Colombia wrote One Hundred Years of Solitude (1967), tracing seven generations of the Buendía family in the fictional town of Macondo, where miraculous events, a girl ascending to heaven while hanging laundry, a rain lasting nearly five years, are told matter-of-factly. It opens: 'Many years later, as he faced the firing squad, Colonel Aureliano Buendía was to remember that distant afternoon when his father took him to discover ice.'",
    "Also Love in the Time of Cholera and Chronicle of a Death Foretold; he won the Nobel Prize in 1982. His style became known worldwide as 'magical realism.'"]],
  ["Other Boom writers",[
    "Julio Cortázar of Argentina wrote Hopscotch (Rayuela, 1963), a novel that can be read in different orders. Peru's Mario Vargas Llosa (Nobel 2010) wrote The Time of the Hero, Conversation in the Cathedral, and The Feast of the Goat about Dominican dictator Trujillo. Mexico's Carlos Fuentes wrote The Death of Artemio Cruz.",
    "The 'dictator novel' became a genre, including Augusto Roa Bastos's I, the Supreme and García Márquez's The Autumn of the Patriarch."]],
  ["Women and later writers",[
    "Chile's Isabel Allende (The House of the Spirits, 1982) brought a family saga of magical realism and Chilean politics to millions of readers. Mexico's Elena Poniatowska documented the 1968 Tlatelolco massacre, and Clarice Lispector of Brazil wrote intense, philosophical fiction (The Hour of the Star).",
    "Later writers reacted against magical realism: Roberto Bolaño's 2666 and The Savage Detectives; the 'McOndo' generation; and contemporary writers such as Valeria Luiselli, Samanta Schweblin, and Mariana Enríquez."]],
  ["Poetry",[
    "Latin America also produced great 20th-century poets: Chile's Gabriela Mistral, the first Latin American Nobel laureate (1945); Pablo Neruda (Nobel 1971), whose Twenty Love Poems and a Song of Despair and epic Canto General are beloved; Peru's César Vallejo; and Mexico's Octavio Paz (Nobel 1990), whose essay The Labyrinth of Solitude examined Mexican identity.",
    "Brazil's modernist movement, launched with the 1922 Modern Art Week in São Paulo, produced writers such as Mário de Andrade and the poet Carlos Drummond de Andrade."]]
  ],
  terms:[["The Boom","1960s–70s international rise of Latin American fiction."],["Magical realism","Marvelous events told as ordinary reality."],["Macondo","García Márquez's fictional town."],["Dictator novel","Genre about Latin American dictators."],["Lo real maravilloso","Carpentier's 'marvelous real.'"]],
  w:"The Latin American Boom changed world literature, blending myth, history, and politics in new forms.",
  src:["Latin American Boom","One Hundred Years of Solitude","Gabriel García Márquez","Pedro Páramo","Pablo Neruda"],
  q:[
  ["In which town is One Hundred Years of Solitude set?","Macondo","Comala","Santa Teresa","Aracataca"],
  ["Which Juan Rulfo novel is set in a village of ghosts?","Pedro Páramo","Hopscotch","The Death of Artemio Cruz","2666"],
  ["Which novel can be read in different orders?","Hopscotch","The House of the Spirits","The Feast of the Goat","Love in the Time of Cholera"],
  ["Who was the first Latin American to win the Nobel Prize in Literature?","Gabriela Mistral","Pablo Neruda","Miguel Ángel Asturias","Octavio Paz"],
  ["Who wrote The House of the Spirits?","Isabel Allende","Elena Poniatowska","Clarice Lispector","Laura Esquivel"],
  ["When did García Márquez win the Nobel Prize?","1982","1967","1990","2010"]]},

{ t:"Postcolonial Literatures", s:"Writing back to empire",
  sec:[
  ["The empire writes back",[
    "As colonized nations in Africa, Asia, and the Caribbean won independence after World War II, their writers explored colonialism's effects, national identity, language, and the hybrid cultures empire created. The 1989 critical book The Empire Writes Back described how they appropriated and transformed the colonizer's language.",
    "Frantz Fanon's The Wretched of the Earth (1961) and Edward Said's Orientalism (1978) gave intellectual frameworks."]],
  ["Chinua Achebe and Africa",[
    "Nigeria's Chinua Achebe (1930–2013) wrote Things Fall Apart (1958), the most widely read African novel, about Okonkwo, a proud Igbo leader whose world collapses with the arrival of British missionaries and colonial government; its title quotes Yeats's 'The Second Coming.' It portrayed precolonial African society with complexity, countering European stereotypes.",
    "Wole Soyinka of Nigeria, playwright and poet (Death and the King's Horseman), became the first African Nobel laureate in literature (1986). Kenya's Ngũgĩ wa Thiong'o, after writing in English (A Grain of Wheat), switched to his native Gikuyu, arguing in Decolonising the Mind (1986) that African literature should be in African languages. South Africa's Nadine Gordimer and J. M. Coetzee (Disgrace) won Nobels; Egypt's Naguib Mahfouz won in 1988."]],
  ["The Caribbean",[
    "Caribbean writers explored slavery, migration, and creole identity. Derek Walcott of Saint Lucia (Nobel 1992) wrote Omeros, an epic transposing Homer to Caribbean fishermen. V. S. Naipaul of Trinidad (Nobel 2001) wrote A House for Mr Biswas. Jean Rhys's Wide Sargasso Sea retold Jane Eyre from the Creole perspective; Jamaica Kincaid, Edwidge Danticat, and Kamau Brathwaite are other important voices.",
    "Aimé Césaire's Notebook of a Return to the Native Land launched Négritude."]],
  ["South Asia",[
    "Indian writing in English includes R. K. Narayan's gentle stories of the fictional town Malgudi and Mulk Raj Anand's Untouchable. Salman Rushdie's Midnight's Children (1981, Booker Prize and later the 'Booker of Bookers') follows Saleem Sinai, born at the stroke of midnight on India's independence, 15 August 1947, with telepathic powers linking him to other 'midnight's children.'",
    "Rushdie's The Satanic Verses (1988) led Iran's Ayatollah Khomeini to issue a fatwa calling for his death in 1989; he lived under protection for years and was seriously injured in a stabbing attack in New York in 2022. Arundhati Roy's The God of Small Things (1997) and Vikram Seth's A Suitable Boy are other landmarks."]],
  ["Language and identity",[
    "Postcolonial writers debate which language to write in, how to represent oral traditions, and how to address both local and global audiences. Many use English, French, or Portuguese creatively, mixing in local languages and rhythms.",
    "Their work has reshaped world literature, prizes, and university curricula."]]
  ],
  terms:[["Postcolonial literature","Writing from formerly colonized nations."],["Things Fall Apart","Achebe's novel of colonial disruption."],["Decolonising the Mind","Ngũgĩ's argument for African languages."],["Midnight's Children","Rushdie's novel of Indian independence."],["Fatwa","Religious ruling; issued against Rushdie in 1989."]],
  w:"Postcolonial writers reclaimed their histories and remade the languages of empire into new literatures.",
  src:["Postcolonial literature","Things Fall Apart","Wole Soyinka","Midnight's Children","Derek Walcott"],
  q:[
  ["Who is the protagonist of Things Fall Apart?","Okonkwo","Saleem Sinai","Mr Biswas","Obi"],
  ["Who was the first African Nobel laureate in literature?","Wole Soyinka","Chinua Achebe","Nadine Gordimer","Naguib Mahfouz"],
  ["Which writer switched from English to Gikuyu?","Ngũgĩ wa Thiong'o","Chinua Achebe","Ben Okri","Chimamanda Ngozi Adichie"],
  ["When is Saleem Sinai born?","At midnight on India's independence","At dawn on New Year's Day","During the Partition riots","In 1900"],
  ["Who wrote Omeros?","Derek Walcott","V. S. Naipaul","Aimé Césaire","Kamau Brathwaite"],
  ["Where does Achebe's title Things Fall Apart come from?","Yeats's 'The Second Coming'","The Bible","Shakespeare","An Igbo proverb"]]}

);


/* ---- from lit-21.js ---- */
/* LITERATURE FOUNDATIONS, part 21: Unit 8 chapters 9-12 */
COURSES.literature.units[7].ch.push(

{ t:"Literature of Witness: The Holocaust and War", s:"Writing after catastrophe",
  sec:[
  ["Testimony",[
    "The Holocaust, the Nazi murder of six million Jews and millions of others, posed profound questions for literature. Philosopher Theodor Adorno wrote in 1949 that 'to write poetry after Auschwitz is barbaric,' a provocation he later qualified; survivors and writers nonetheless created a literature of witness.",
    "Anne Frank's diary, written while hiding in an Amsterdam annex from 1942 to 1944, was published by her father Otto in 1947 after her death in Bergen-Belsen; it is among the most read books in the world."]],
  ["Survivors' accounts",[
    "Primo Levi (1919–1987), an Italian Jewish chemist, survived Auschwitz and wrote If This Is a Man (Survival in Auschwitz, 1947) with scientific clarity and moral depth, followed by The Periodic Table and The Drowned and the Saved, which reflected on the 'gray zone' of moral compromise in the camps.",
    "Elie Wiesel's Night (1956/1960), about his experience as a teenager in Auschwitz and Buchenwald, became a classic; Wiesel received the Nobel Peace Prize in 1986. Imre Kertész's Fatelessness (Nobel 2002) and Viktor Frankl's Man's Search for Meaning are other key works."]],
  ["Poetry and fiction",[
    "Paul Celan, a Romanian-born Jewish poet who lost his parents in the camps, wrote 'Death Fugue' ('Todesfuge'), with its haunting refrain 'Black milk of daybreak,' in German, the language of the murderers. Nelly Sachs won the Nobel Prize in 1966.",
    "Later fiction and graphic works include Art Spiegelman's Maus, W. G. Sebald's Austerlitz (2001), and novels by the children of survivors, raising questions about 'postmemory' and how to represent the unrepresentable."]],
  ["Other wars and atrocities",[
    "Literature has borne witness to other catastrophes: the Armenian genocide; the atomic bombings, as in Masuji Ibuse's Black Rain and the testimonies of Hiroshima survivors; the Gulag; the Vietnam War, in Tim O'Brien's The Things They Carried (1990), which blurs fact and fiction; the Cambodian genocide; and the Rwandan genocide of 1994, explored in Scholastique Mukasonga's memoirs.",
    "Writers from Syria, Ukraine, and elsewhere continue this tradition."]],
  ["Ethics of representation",[
    "Writing about atrocity raises ethical questions: Who may tell these stories? How can art avoid exploiting suffering or making it into entertainment? What is the difference between testimony and fiction?",
    "Many writers argue that literature preserves memory and humanizes victims, countering denial and forgetting."]]
  ],
  terms:[["Literature of witness","Writing that testifies to atrocity."],["Gray zone","Levi's term for moral ambiguity in the camps."],["Death Fugue","Celan's Holocaust poem."],["Postmemory","Inherited memory of trauma by later generations."],["Testimony","First-hand account of events."]],
  w:"Literature of witness preserves memory and confronts the hardest questions about human cruelty and survival.",
  src:["Primo Levi","Night (memoir)","The Diary of a Young Girl","Paul Celan","The Things They Carried"],
  q:[
  ["Who wrote If This Is a Man?","Primo Levi","Elie Wiesel","Viktor Frankl","Imre Kertész"],
  ["Which poem's refrain is 'Black milk of daybreak'?","Death Fugue","Night","Todesfuge's sequel","Shema"],
  ["Who published Anne Frank's diary?","Her father, Otto Frank","Miep Gies","Primo Levi","The Dutch government"],
  ["Which memoir did Elie Wiesel write?","Night","Maus","Austerlitz","Fatelessness"],
  ["Which Vietnam War book blurs fact and fiction?","The Things They Carried","Catch-22","Slaughterhouse-Five","Black Rain"],
  ["Who wrote that 'to write poetry after Auschwitz is barbaric'?","Theodor Adorno","Hannah Arendt","Paul Celan","Primo Levi"]]},

{ t:"Women's Writing and Feminist Literature", s:"Voices reclaimed and new",
  sec:[
  ["Second-wave feminism",[
    "The women's movement of the 1960s–70s transformed literature. Betty Friedan's The Feminine Mystique (1963) described 'the problem that has no name' afflicting suburban housewives. Doris Lessing's The Golden Notebook (1962), structured through a writer's notebooks, explored politics, mental breakdown, and women's lives; Lessing won the Nobel Prize in 2007.",
    "Feminist presses such as Virago (1973) republished forgotten women writers, and critics recovered authors from Aphra Behn to Zora Neale Hurston."]],
  ["Major novelists",[
    "Margaret Atwood (born 1939) of Canada wrote The Edible Woman, Surfacing, The Handmaid's Tale, Alias Grace, and The Blind Assassin (Booker Prize 2000); its sequel The Testaments shared the Booker in 2019. Iris Murdoch wrote philosophical novels (The Sea, The Sea); Muriel Spark wrote The Prime of Miss Jean Brodie; and Angela Carter's The Bloody Chamber rewrote fairy tales from feminist perspectives.",
    "Alice Munro (Nobel 2013) transformed the short story; Annie Ernaux of France (Nobel 2022) wrote spare autobiographical works such as The Years about women's lives and class."]],
  ["Poetry and memoir",[
    "Adrienne Rich's Diving into the Wreck, Audre Lorde's poems and essays ('The Master's Tools Will Never Dismantle the Master's House'), and Maya Angelou's memoirs gave voice to women's experiences of race, sexuality, and power.",
    "Memoir became a central feminist form, from Maxine Hong Kingston's The Woman Warrior (1976), blending Chinese myth and Chinese American girlhood, to Jeanette Winterson's Oranges Are Not the Only Fruit."]],
  ["Global women writers",[
    "Women writers worldwide have reshaped their literatures: Nawal El Saadawi in Egypt, Mariama Bâ's So Long a Letter (Senegal), Tsitsi Dangarembga's Nervous Conditions (Zimbabwe), Chimamanda Ngozi Adichie's Half of a Yellow Sun and her essay 'We Should All Be Feminists' (Nigeria), Han Kang's The Vegetarian (South Korea; Nobel 2024), Olga Tokarczuk (Poland; Nobel 2018), and Elena Ferrante's Neapolitan novels (Italy).",
    "Bernardine Evaristo's Girl, Woman, Other (2019) made her the first Black woman to win the Booker Prize, sharing it with Atwood."]],
  ["Ongoing questions",[
    "Debates continue about women's representation in reviews, prizes, and the canon (the VIDA Count tracked gender imbalance in literary publications), intersectionality (a term coined by legal scholar Kimberlé Crenshaw), and how literature represents gender and sexuality.",
    "Today, women write and read a large share of fiction, and their works shape literature's central conversations."]]
  ],
  terms:[["Second-wave feminism","1960s–70s women's movement."],["Virago","Feminist publisher founded 1973."],["The Golden Notebook","Lessing's experimental novel."],["Intersectionality","Overlapping forms of discrimination."],["Feminist rewriting","Retelling stories from women's perspectives."]],
  w:"Women writers and feminist criticism have transformed what literature is read, written, and valued.",
  src:["Feminist literature","Margaret Atwood","Doris Lessing","Annie Ernaux","Han Kang"],
  q:[
  ["Which Lessing novel is structured through a writer's notebooks?","The Golden Notebook","The Grass Is Singing","Martha Quest","The Fifth Child"],
  ["Who described 'the problem that has no name'?","Betty Friedan","Simone de Beauvoir","Gloria Steinem","Germaine Greer"],
  ["Which South Korean author won the 2024 Nobel Prize?","Han Kang","Shin Kyung-sook","Bae Suah","Cho Nam-joo"],
  ["Who was the first Black woman to win the Booker Prize?","Bernardine Evaristo","Toni Morrison","Zadie Smith","Chimamanda Ngozi Adichie"],
  ["Who rewrote fairy tales in The Bloody Chamber?","Angela Carter","Margaret Atwood","Jeanette Winterson","Iris Murdoch"],
  ["Which French writer won the 2022 Nobel Prize?","Annie Ernaux","Marguerite Duras","Marie NDiaye","Leïla Slimani"]]},

{ t:"Contemporary Fiction in English", s:"From the 1980s to today",
  sec:[
  ["British fiction",[
    "Late 20th-century British fiction included Ian McEwan (Atonement, 2001, about a girl's false accusation and its lifelong consequences), Martin Amis, Julian Barnes, Hilary Mantel, and Kazuo Ishiguro, born in Nagasaki and raised in England, whose The Remains of the Day (1989) portrays a butler's quiet self-deception and Never Let Me Go (2005) clones raised for organ donation. Ishiguro won the Nobel Prize in 2017.",
    "Zadie Smith's White Teeth (2000) captured multicultural London; Sarah Waters, Ali Smith, and Sally Rooney (Normal People, 2018) are other prominent voices."]],
  ["Irish fiction",[
    "Irish writers continued a remarkable tradition: John McGahern, William Trevor, Edna O'Brien (The Country Girls, banned in Ireland in 1960), Roddy Doyle, Anne Enright, Colm Tóibín (Brooklyn), Anna Burns (Milkman, Booker 2018), and Paul Lynch (Prophet Song, Booker 2023).",
    "Northern Ireland's Troubles inspired fiction and poetry by Bernard MacLaverty, Seamus Heaney, and others."]],
  ["American fiction",[
    "Contemporary American fiction includes Toni Morrison, Cormac McCarthy (The Road, 2006, Pulitzer), Marilynne Robinson (Gilead), Jonathan Franzen (The Corrections), Jhumpa Lahiri (Interpreter of Maladies), Junot Díaz (The Brief Wondrous Life of Oscar Wao), Jennifer Egan, George Saunders (Lincoln in the Bardo, Booker 2017), and Colson Whitehead.",
    "Immigrant and diaspora narratives, autofiction, and genre-blending have been major trends."]],
  ["Commonwealth and global English",[
    "Writers from across the English-speaking world have won major prizes: Australia's Peter Carey and Richard Flanagan, New Zealand's Keri Hulme and Eleanor Catton (The Luminaries, Booker 2013, at 28 the youngest winner then), South Africa's J. M. Coetzee and Damon Galgut, India's Arundhati Roy and Arvind Adiga, Nigeria's Ben Okri and Chimamanda Ngozi Adichie, Canada's Michael Ondaatje (The English Patient), and Sri Lanka's Shehan Karunatilaka.",
    "The Booker Prize (from 1969) opened to American writers in 2014, prompting debate."]],
  ["Trends",[
    "Recent fiction has engaged with climate change ('cli-fi,' such as Richard Powers's The Overstory), technology and the internet, identity, migration, pandemic, and history. Autofiction, novels closely based on the author's life, has flourished (Rachel Cusk, Ben Lerner).",
    "Audiobooks, e-books, social media communities such as 'BookTok,' and book clubs shape what people read."]]
  ],
  terms:[["Autofiction","Fiction closely based on the author's life."],["Cli-fi","Climate fiction."],["Booker Prize","Major prize for fiction in English, since 1969."],["Diaspora narrative","Story of migrant communities."],["BookTok","TikTok community driving book trends."]],
  w:"Contemporary fiction in English spans the globe and engages the urgent questions of our time.",
  src:["Kazuo Ishiguro","Booker Prize","Atonement (novel)","Zadie Smith","Autofiction"],
  q:[
  ["Who wrote The Remains of the Day?","Kazuo Ishiguro","Ian McEwan","Julian Barnes","Martin Amis"],
  ["Which novel portrays a girl's false accusation and its consequences?","Atonement","Normal People","White Teeth","Brooklyn"],
  ["Which Cormac McCarthy novel won the Pulitzer Prize?","The Road","Blood Meridian","No Country for Old Men","All the Pretty Horses"],
  ["Who wrote White Teeth?","Zadie Smith","Monica Ali","Sally Rooney","Ali Smith"],
  ["What is autofiction?","Fiction closely based on the author's life","Fiction about cars","Self-published fiction","Fiction written by AI"],
  ["When did the Booker Prize open to American writers?","2014","1969","2000","2020"]]},

{ t:"World Fiction in Translation", s:"Murakami, Ferrante, Pamuk, and more",
  sec:[
  ["A global readership",[
    "Translation has made world literature accessible to readers everywhere. The International Booker Prize (from 2016 in its current form) shares its prize equally between author and translator, recognizing translators' creative role.",
    "Yet only a small share of books published in English are translations, often estimated at about 3%, compared with much higher proportions in many other languages."]],
  ["Japan and East Asia",[
    "Haruki Murakami (born 1949) became a global phenomenon with surreal, melancholic novels mixing pop culture, jazz, and dreamlike mysteries: Norwegian Wood, The Wind-Up Bird Chronicle, Kafka on the Shore, and 1Q84. Earlier Japanese masters include Yasunari Kawabata (Nobel 1968), Yukio Mishima, and Kenzaburō Ōe (Nobel 1994).",
    "Korean literature has gained global attention through Han Kang, and Chinese writers Mo Yan (Nobel 2012), Yu Hua (To Live), and Liu Cixin's science fiction (The Three-Body Problem) have large international followings."]],
  ["Europe",[
    "Elena Ferrante, the pseudonymous Italian author of the four Neapolitan novels (beginning with My Brilliant Friend, 2011), tracing a lifelong friendship between two women from a poor Naples neighborhood, became an international bestseller. Norway's Karl Ove Knausgaard's six-volume My Struggle brought autofiction to wide audiences, and Jon Fosse (Nobel 2023) wrote meditative plays and prose.",
    "Other notable European writers include Germany's Günter Grass (The Tin Drum, Nobel 1999), Portugal's José Saramago (Blindness, Nobel 1998), Hungary's László Krasznahorkai (Nobel 2025), Czech-born Milan Kundera, and Poland's Olga Tokarczuk."]],
  ["Turkey, the Middle East, and Africa",[
    "Turkey's Orhan Pamuk (Nobel 2006) explored East and West in My Name Is Red and Snow and the melancholy of Istanbul. Egypt's Naguib Mahfouz chronicled Cairo in the Cairo Trilogy. Lebanese, Iraqi, Iranian, and Palestinian writers, including Mahmoud Darwish's poetry, address exile and conflict.",
    "African writers in French, Portuguese, and African languages, such as Senegal's Mohamed Mbougar Sarr (Prix Goncourt 2021) and Mozambique's Mia Couto, reach global readers in translation, while Tanzanian-born Abdulrazak Gurnah (writing in English) won the Nobel Prize in 2021."]],
  ["The translator's art",[
    "Translation involves countless choices about meaning, rhythm, culture, and tone; there is no perfect translation. Famous translators include Constance Garnett, who introduced Russian classics to English readers; Gregory Rabassa, whose translation of One Hundred Years of Solitude García Márquez said was better than the original; and Edith Grossman.",
    "Reading multiple translations of a classic reveals how much the translator shapes our experience."]]
  ],
  terms:[["International Booker Prize","Prize for translated fiction, shared with translators."],["Neapolitan novels","Ferrante's four novels of friendship."],["Translation","Rendering a text in another language."],["Pseudonym","Pen name, as Elena Ferrante."],["Three Percent","Estimated share of translations in English publishing."]],
  w:"Translated literature opens windows onto the whole world; noticing the translator deepens appreciation.",
  src:["Haruki Murakami","Elena Ferrante","Orhan Pamuk","International Booker Prize","Translation"],
  q:[
  ["Who wrote Kafka on the Shore and 1Q84?","Haruki Murakami","Kenzaburō Ōe","Yukio Mishima","Banana Yoshimoto"],
  ["Which novel begins Ferrante's Neapolitan series?","My Brilliant Friend","The Story of a New Name","The Lost Daughter","Troubling Love"],
  ["Which Turkish writer won the 2006 Nobel Prize?","Orhan Pamuk","Elif Shafak","Yaşar Kemal","Nazım Hikmet"],
  ["How does the International Booker Prize divide its prize money?","Equally between author and translator","All to the author","All to the publisher","To the translator only"],
  ["Who wrote The Three-Body Problem?","Liu Cixin","Mo Yan","Yu Hua","Yan Lianke"],
  ["Who translated One Hundred Years of Solitude into acclaimed English?","Gregory Rabassa","Edith Grossman","Constance Garnett","Lydia Davis"]]}

);


/* ---- from lit-22.js ---- */
/* LITERATURE FOUNDATIONS, part 22: Unit 9 Modern World Literatures, chapters 1-4 */
COURSES.literature.units.push({ t:"Modern World Literatures", ch:[

{ t:"Modern Chinese Literature", s:"From Lu Xun to Mo Yan",
  sec:[
  ["The May Fourth movement",[
    "Modern Chinese literature began with the New Culture and May Fourth movements (1915–1920s), when intellectuals rejected Confucian tradition and classical Chinese, advocating writing in vernacular language (baihua). Hu Shi championed the vernacular; writers sought to modernize China through literature.",
    "Lu Xun (1881–1936), the father of modern Chinese literature, wrote 'A Madman's Diary' (1918), the first major story in vernacular Chinese, in which a madman perceives that traditional society is cannibalistic, ending 'Save the children...' 'The True Story of Ah Q' satirizes a peasant who rationalizes every humiliation as victory."]],
  ["The Republican era",[
    "Writers of the 1920s–40s include Ba Jin (Family), Lao She (Rickshaw Boy, about a Beijing rickshaw puller's struggle), Shen Congwen's lyrical rural stories, the poet Xu Zhimo, and Eileen Chang (Zhang Ailing), whose stories of love and decline in wartime Shanghai and Hong Kong, such as 'Lust, Caution,' are now celebrated.",
    "After the 1949 Communist revolution, Mao Zedong's 1942 Yan'an Talks required literature to serve politics."]],
  ["The Cultural Revolution and after",[
    "During the Cultural Revolution (1966–76), writers were persecuted; Lao She died after being beaten by Red Guards. Afterward, 'scar literature' depicted the trauma of those years, and in the 1980s 'root-seeking' and avant-garde writers experimented with form and tradition.",
    "Bei Dao and the 'Misty Poets' wrote ambiguous, personal poetry; Bei Dao's 'The Answer' ('Baseness is the password of the base') became an anthem of the 1976 and 1989 protests."]],
  ["Contemporary writers",[
    "Mo Yan (Nobel 2012), whose pen name means 'don't speak,' wrote Red Sorghum and Life and Death Are Wearing Me Out with 'hallucinatory realism.' Yu Hua's To Live follows one man's survival through decades of upheaval; Yan Lianke's satires have been banned in China; Gao Xingjian (Nobel 2000, writing in exile in France) wrote Soul Mountain.",
    "Liu Cixin's The Three-Body Problem (2008) made Chinese science fiction a global phenomenon. Taiwan and Hong Kong have their own vibrant literatures, and Chinese diaspora writers such as Ha Jin and Yiyun Li write in English."]],
  ["Censorship and creativity",[
    "Chinese writers navigate censorship and self-censorship; some publish abroad or online. Online literature platforms in China host millions of serialized web novels with vast readerships, a new literary ecosystem.",
    "Classical poetry remains part of education, linking modern readers to three thousand years of tradition."]]
  ],
  terms:[["May Fourth movement","1919 cultural and political reform movement."],["Baihua","Vernacular written Chinese."],["A Madman's Diary","Lu Xun's pioneering 1918 story."],["Scar literature","Fiction about Cultural Revolution trauma."],["Misty Poets","Post-Mao poets of ambiguous imagery."]],
  w:"Modern Chinese literature tracks a century of revolution and change, from Lu Xun to global science fiction.",
  src:["Lu Xun","A Madman's Diary","Mo Yan","Eileen Chang","Misty Poets"],
  q:[
  ["Who is called the father of modern Chinese literature?","Lu Xun","Mo Yan","Ba Jin","Lao She"],
  ["Which story ends 'Save the children...'?","A Madman's Diary","The True Story of Ah Q","Rickshaw Boy","Family"],
  ["What does Mo Yan's pen name mean?","Don't speak","Red Sorghum","Great Talker","Silent River"],
  ["What was 'scar literature' about?","Trauma of the Cultural Revolution","War with Japan","Love stories","Science fiction"],
  ["Which Chinese writer won the Nobel Prize in 2000 while in exile?","Gao Xingjian","Bei Dao","Yu Hua","Ha Jin"],
  ["Who wrote 'Lust, Caution'?","Eileen Chang","Shen Congwen","Xiao Hong","Ding Ling"]]},

{ t:"Modern Japanese Literature", s:"From Natsume Sōseki to Murakami",
  sec:[
  ["Meiji modernization",[
    "After Japan opened to the West in the Meiji era (1868–1912), writers absorbed Western realism while preserving Japanese sensibilities. Natsume Sōseki (1867–1916), whose face once appeared on the 1,000-yen note, wrote I Am a Cat (narrated by a sardonic cat), Botchan, and Kokoro (1914), a moving novel about a student, his mysterious mentor 'Sensei,' and guilt over a friend's suicide.",
    "Mori Ōgai and the 'I-novel' (watakushi shōsetsu), confessional autobiographical fiction, were other important developments."]],
  ["Akutagawa and Tanizaki",[
    "Ryūnosuke Akutagawa (1892–1927) wrote stories such as 'Rashōmon' and 'In a Grove' (in which several witnesses give contradictory accounts of a murder), the basis of Akira Kurosawa's film Rashomon. Japan's top literary prize for new writers is named after him.",
    "Jun'ichirō Tanizaki explored desire and tradition in The Makioka Sisters and the essay In Praise of Shadows, which celebrates the beauty of dimness in Japanese aesthetics."]],
  ["Kawabata and Mishima",[
    "Yasunari Kawabata (1899–1972), the first Japanese Nobel laureate (1968), wrote spare, lyrical novels such as Snow Country, about a Tokyo man's affair with a geisha at a hot-spring resort, and The Sound of the Mountain. Yukio Mishima (1925–1970) wrote Confessions of a Mask, The Temple of the Golden Pavilion, and The Sea of Fertility tetralogy; obsessed with beauty, death, and imperial tradition, he died by ritual suicide after a failed attempt to inspire a military coup in 1970.",
    "Kenzaburō Ōe (Nobel 1994) wrote of postwar Japan, nuclear weapons, and his relationship with his disabled son (A Personal Matter)."]],
  ["Contemporary Japan",[
    "Haruki Murakami became the most internationally famous Japanese writer. Banana Yoshimoto (Kitchen), Yoko Ogawa (The Memory Police), Sayaka Murata (Convenience Store Woman, about a woman content working in a convenience store against society's expectations), and Mieko Kawakami (Breasts and Eggs) have found wide audiences abroad.",
    "Japanese manga and light novels are a massive literary culture of their own."]],
  ["Korea",[
    "Korean literature, long shaped by Chinese classics and the Korean alphabet Hangul (created in 1443), developed modern fiction in the 20th century amid Japanese colonization, war, and dictatorship. Writers such as Pak Kyongni (the saga Land), Hwang Sok-yong, poet Ko Un, Shin Kyung-sook (Please Look After Mom), and Han Kang (The Vegetarian, Human Acts, about the 1980 Gwangju massacre; Nobel 2024) have gained global recognition.",
    "Cho Nam-joo's Kim Jiyoung, Born 1982 sparked debate on gender in Korea."]]
  ],
  terms:[["I-novel","Japanese confessional autobiographical fiction."],["Kokoro","Sōseki's novel of guilt and friendship."],["In a Grove","Akutagawa story of conflicting testimony."],["Snow Country","Kawabata's lyrical novel."],["Hangul","Korean alphabet created in 1443."]],
  w:"Modern Japanese and Korean literatures blend tradition and modernity and now reach readers worldwide.",
  src:["Natsume Sōseki","Ryūnosuke Akutagawa","Yasunari Kawabata","Yukio Mishima","Korean literature"],
  q:[
  ["Which Sōseki novel is narrated by a cat?","I Am a Cat","Kokoro","Botchan","Sanshirō"],
  ["Which Akutagawa story inspired the film Rashomon?","In a Grove","The Nose","Hell Screen","Kappa"],
  ["Who was the first Japanese Nobel laureate in literature?","Yasunari Kawabata","Kenzaburō Ōe","Yukio Mishima","Haruki Murakami"],
  ["Which novel is about a contented convenience store worker?","Convenience Store Woman","Kitchen","The Memory Police","Breasts and Eggs"],
  ["Which Han Kang novel concerns the Gwangju massacre?","Human Acts","The Vegetarian","The White Book","Greek Lessons"],
  ["Whose essay is In Praise of Shadows?","Jun'ichirō Tanizaki","Mishima","Kawabata","Sōseki"]]},

{ t:"Literatures of South Asia", s:"Tagore, Ghalib, Premchand, and Partition",
  sec:[
  ["Many languages",[
    "South Asia has dozens of literary languages: Sanskrit, Tamil, Bengali, Hindi, Urdu, Marathi, Punjabi, Malayalam, Kannada, Telugu, Sinhala, Nepali, and English, among others. Medieval devotional (bhakti) poets such as Kabir, Mirabai, and Tulsidas wrote in vernaculars accessible to ordinary people, and Sufi poets wrote in Punjabi and Sindhi.",
    "Kabir's couplets, mocking religious hypocrisy and celebrating inner devotion, are still sung across India."]],
  ["Urdu poetry",[
    "Urdu poetry flourished at the Mughal court. Mirza Ghalib (1797–1869), the greatest Urdu poet, wrote ghazals of love, longing, and philosophical wit, witnessing the fall of Mughal Delhi after the 1857 rebellion. Muhammad Iqbal, philosopher-poet, inspired the idea of Pakistan.",
    "Faiz Ahmed Faiz (1911–1984) combined romantic imagery with revolutionary politics; his poems of hope ('Hum Dekhenge,' 'We shall see') remain protest anthems."]],
  ["Rabindranath Tagore",[
    "Rabindranath Tagore (1861–1941), a Bengali poet, novelist, composer, painter, and educator, became in 1913 the first non-European to win the Nobel Prize in Literature, for Gitanjali (Song Offerings), devotional poems he translated into English. He wrote over 2,000 songs (Rabindrasangeet), including the national anthems of both India and Bangladesh, as well as novels such as The Home and the World and short stories.",
    "He founded Visva-Bharati University at Santiniketan and renounced his knighthood after the 1919 Amritsar massacre."]],
  ["Premchand and Partition",[
    "Munshi Premchand (1880–1936), writing in Hindi and Urdu, depicted village life, caste, and poverty with realism; his novel Godaan (The Gift of a Cow) is a classic. The Progressive Writers' Association (1936) linked literature to social reform.",
    "The 1947 Partition of India and Pakistan, with mass migrations and violence that killed hundreds of thousands to perhaps two million people, produced searing literature: Saadat Hasan Manto's short stories, such as 'Toba Tek Singh' (in which asylum inmates are divided between the new countries), Khushwant Singh's Train to Pakistan, and Amrita Pritam's poem calling on the poet Waris Shah to speak from his grave."]],
  ["Modern South Asian writing",[
    "Later writers include Ismat Chughtai, whose story 'Lihaaf' ('The Quilt,' 1942) led to an obscenity trial; Mahasweta Devi, who wrote of tribal and oppressed communities; U. R. Ananthamurthy in Kannada; Sri Lanka's Michael Ondaatje and Shyam Selvadurai; Pakistan's Mohsin Hamid (Exit West) and Kamila Shamsie; and Bangladesh's Tahmima Anam.",
    "Geetanjali Shree's Tomb of Sand, translated from Hindi by Daisy Rockwell, won the 2022 International Booker Prize, the first for a book translated from an Indian language."]]
  ],
  terms:[["Bhakti","Devotional movement and poetry."],["Ghazal","Urdu and Persian love lyric in couplets."],["Gitanjali","Tagore's Nobel-winning poems."],["Partition","1947 division of India and Pakistan."],["Toba Tek Singh","Manto's story of Partition's madness."]],
  w:"South Asia's many literatures, from bhakti poetry to Partition fiction, form one of the world's richest traditions.",
  src:["Rabindranath Tagore","Mirza Ghalib","Premchand","Saadat Hasan Manto","Partition of India in literature"],
  q:[
  ["Who was the first non-European to win the Nobel Prize in Literature?","Rabindranath Tagore","Premchand","Muhammad Iqbal","R. K. Narayan"],
  ["Tagore wrote the national anthems of which two countries?","India and Bangladesh","India and Pakistan","Bangladesh and Sri Lanka","India and Nepal"],
  ["Who is considered the greatest Urdu poet?","Mirza Ghalib","Faiz Ahmed Faiz","Kabir","Iqbal"],
  ["Which Manto story concerns asylum inmates divided after Partition?","Toba Tek Singh","Lihaaf","Godaan","Train to Pakistan"],
  ["Which novel won the 2022 International Booker, translated from Hindi?","Tomb of Sand","Godaan","Exit West","The God of Small Things"],
  ["Which bhakti poet's couplets mock religious hypocrisy?","Kabir","Mirabai","Tulsidas","Surdas"]]},

{ t:"Modern Arabic, Hebrew, and Persian Literature", s:"Renaissance, exile, and resistance",
  sec:[
  ["The Nahda",[
    "The Nahda ('awakening'), an Arab cultural renaissance of the 19th and early 20th centuries centered in Cairo and Beirut, modernized Arabic prose, journalism, and fiction. The Lebanese-American Kahlil Gibran's The Prophet (1923), poetic essays on love, work, and death, became one of the best-selling books ever.",
    "Taha Hussein, a blind Egyptian scholar, wrote the autobiography The Days and challenged traditional views of classical poetry."]],
  ["Naguib Mahfouz",[
    "Naguib Mahfouz (1911–2006) of Egypt, the first Arabic-language Nobel laureate (1988), wrote over 30 novels. The Cairo Trilogy (Palace Walk, Palace of Desire, Sugar Street) follows a family across Egypt's 20th-century transformation. His allegorical Children of the Alley, depicting figures resembling prophets, was banned in Egypt, and in 1994 he survived an assassination attempt by an extremist.",
    "Other major Arab novelists include Sudan's Tayeb Salih (Season of Migration to the North, reversing Heart of Darkness), Lebanon's Hanan al-Shaykh and Elias Khoury, and Saudi Arabian Abdul Rahman Munif (Cities of Salt, about oil's transformation of the Gulf)."]],
  ["Poetry and Palestine",[
    "Modern Arabic poetry broke from classical meters in the free-verse movement of the late 1940s led by Iraqi poets Nazik al-Mala'ika and Badr Shakir al-Sayyab. Syrian poet Adonis and Nizar Qabbani (love poems) became celebrated.",
    "Mahmoud Darwish (1941–2008), Palestine's national poet, wrote of exile, memory, and identity ('Identity Card': 'Write down! I am an Arab'). Ghassan Kanafani's Men in the Sun is a classic of Palestinian fiction."]],
  ["Hebrew and Yiddish literature",[
    "Modern Hebrew literature revived Hebrew as a literary and spoken language. S. Y. Agnon (Nobel 1966) wove Jewish tradition into fiction; Yehuda Amichai wrote humane, ironic poems of love and war in Jerusalem; Amos Oz's memoir A Tale of Love and Darkness and David Grossman's novels explore Israeli life and conflict.",
    "Yiddish literature flourished in Eastern Europe and America: Sholem Aleichem's stories of Tevye the Dairyman inspired Fiddler on the Roof; Isaac Bashevis Singer won the Nobel Prize in 1978. The Holocaust destroyed much of the Yiddish-speaking world."]],
  ["Persian and Turkish",[
    "Modern Persian literature includes Sadegh Hedayat's haunting novella The Blind Owl (1937) and the poetry of Forough Farrokhzad, whose frank, feminine voice was revolutionary, and Ahmad Shamlou. Marjane Satrapi's graphic memoir Persepolis depicts growing up during the Iranian Revolution.",
    "Turkish literature includes the poet Nazım Hikmet, imprisoned for his politics, Yaşar Kemal's Memed, My Hawk, Orhan Pamuk, and Elif Shafak."]]
  ],
  terms:[["Nahda","Arab cultural renaissance."],["Cairo Trilogy","Mahfouz's family saga."],["The Prophet","Gibran's best-selling poetic essays."],["Free-verse movement","Modern Arabic break from classical meters."],["Yiddish","Language of Ashkenazi Jews."]],
  w:"Modern Middle Eastern literatures voice renewal, exile, and resistance in some of the world's oldest literary languages.",
  src:["Naguib Mahfouz","Mahmoud Darwish","Kahlil Gibran","Yehuda Amichai","The Blind Owl"],
  q:[
  ["Who was the first Arabic-language Nobel laureate?","Naguib Mahfouz","Mahmoud Darwish","Taha Hussein","Adonis"],
  ["Who wrote The Prophet (1923)?","Kahlil Gibran","Mikhail Naimy","Nizar Qabbani","Ameen Rihani"],
  ["Who is known as Palestine's national poet?","Mahmoud Darwish","Ghassan Kanafani","Edward Said","Samih al-Qasim"],
  ["Whose stories inspired Fiddler on the Roof?","Sholem Aleichem","S. Y. Agnon","Isaac Bashevis Singer","Amos Oz"],
  ["Which Sudanese novel reverses Heart of Darkness?","Season of Migration to the North","Cities of Salt","Men in the Sun","The Days"],
  ["Who wrote The Blind Owl?","Sadegh Hedayat","Forough Farrokhzad","Ahmad Shamlou","Marjane Satrapi"]]}

]});


/* ---- from lit-23.js ---- */
/* LITERATURE FOUNDATIONS, part 23: Unit 9 chapters 5-8 */
COURSES.literature.units[8].ch.push(

{ t:"African Literatures", s:"Oral epics, many languages, new voices",
  sec:[
  ["Oral traditions",[
    "Africa's literary heritage is vast and largely oral: epics, praise poetry, proverbs, riddles, and folktales performed by griots and storytellers. The Epic of Sundiata, about the founder of the 13th-century Mali Empire, is performed by Mande griots; the Mwindo epic of the Nyanga people of Congo and Yoruba praise poetry (oríkì) are other examples.",
    "Trickster tales, such as those of Anansi the spider from the Akan of Ghana, traveled with enslaved Africans to the Caribbean and Americas."]],
  ["Written traditions",[
    "Africa also has old written traditions: Ge'ez literature in Ethiopia, Arabic-script writing in Timbuktu's manuscript libraries, and Swahili poetry along the East African coast written in Arabic script from the 17th century. Thomas Mofolo's Chaka (1925), written in Sesotho, is an early African novel.",
    "South Africa's Sol Plaatje wrote Mhudi (1930), one of the first novels in English by a Black South African."]],
  ["Independence-era classics",[
    "Beyond Achebe, Soyinka, and Ngũgĩ, mid-century classics include Camara Laye's The Dark Child (Guinea, in French), Ferdinand Oyono's Houseboy (Cameroon), Cheikh Hamidou Kane's Ambiguous Adventure (Senegal), Sembène Ousmane's God's Bits of Wood about a railway strike, Ayi Kwei Armah's The Beautyful Ones Are Not Yet Born (Ghana), and Ama Ata Aidoo's plays and stories.",
    "Senegal's Léopold Sédar Senghor, a Négritude poet, became his country's first president."]],
  ["Southern and East Africa",[
    "In South Africa, writers confronted apartheid: Alan Paton's Cry, the Beloved Country (1948), Nadine Gordimer (Nobel 1991), J. M. Coetzee (Waiting for the Barbarians, Disgrace; Nobel 2003), Athol Fugard's plays, Bessie Head, and poet Dennis Brutus. Zimbabwe's Tsitsi Dangarembga and Yvonne Vera, and Somalia's Nuruddin Farah, also stand out.",
    "Abdulrazak Gurnah, born in Zanzibar, won the 2021 Nobel Prize for novels such as Paradise about colonialism and refugees."]],
  ["New generations",[
    "Contemporary African literature is flourishing: Chimamanda Ngozi Adichie (Purple Hibiscus, Half of a Yellow Sun about the Biafran War, Americanah), Ben Okri (The Famished Road, Booker 1991), Teju Cole, Helon Habila, NoViolet Bulawayo, Yaa Gyasi (Homegoing), and Akwaeke Emezi. Prizes such as the Caine Prize for African Writing (from 2000) support new writers.",
    "African-language writing continues in Swahili, Yoruba, Amharic, isiZulu, and many others, while debates about language and audience remain central."]]
  ],
  terms:[["Griot","West African oral historian-musician."],["Anansi","Akan spider trickster."],["Négritude","Movement of Black cultural pride."],["Biafran War","1967–70 Nigerian civil war."],["Caine Prize","Award for African short fiction."]],
  w:"African literatures span ancient oral epics and dynamic contemporary fiction in many languages.",
  src:["African literature","Epic of Sundiata","Cry, the Beloved Country","Chimamanda Ngozi Adichie","Abdulrazak Gurnah"],
  q:[
  ["Which epic tells of the founder of the Mali Empire?","Epic of Sundiata","Mwindo epic","Chaka","Gilgamesh"],
  ["Who is the Akan spider trickster?","Anansi","Mwindo","Eshu","Sundiata"],
  ["Who wrote Cry, the Beloved Country?","Alan Paton","Nadine Gordimer","J. M. Coetzee","Athol Fugard"],
  ["Which Adichie novel is about the Biafran War?","Half of a Yellow Sun","Americanah","Purple Hibiscus","The Thing Around Your Neck"],
  ["Which Négritude poet became Senegal's first president?","Léopold Sédar Senghor","Aimé Césaire","Cheikh Hamidou Kane","Birago Diop"],
  ["Who won the 2021 Nobel Prize, born in Zanzibar?","Abdulrazak Gurnah","Ngũgĩ wa Thiong'o","Ben Okri","Nuruddin Farah"]]},

{ t:"Central and Eastern Europe", s:"Irony under pressure",
  sec:[
  ["Czech literature",[
    "Jaroslav Hašek's The Good Soldier Švejk (1921–23) follows a seemingly idiotic soldier who undermines the Austro-Hungarian army through absurd obedience, a classic of comic resistance. Karel Čapek's play R.U.R. (1920) introduced the word 'robot' (from robota, 'forced labor').",
    "Milan Kundera's The Joke and The Unbearable Lightness of Being (1984), set around the 1968 Prague Spring, combined love stories and philosophy; Bohumil Hrabal (Too Loud a Solitude) and playwright-president Václav Havel used irony against communist absurdity."]],
  ["Polish literature",[
    "Poland's tradition includes Adam Mickiewicz's Romantic epic Pan Tadeusz and Henryk Sienkiewicz's historical novels (Quo Vadis; Nobel 1905). Bruno Schulz wrote dreamlike stories (The Street of Crocodiles) before being shot by a Nazi officer in 1942.",
    "Postwar Polish poets became world-famous: Czesław Miłosz (Nobel 1980; The Captive Mind analyzed intellectuals under communism), Wisława Szymborska (Nobel 1996), whose ironic, wise poems ('Nothing Twice') are beloved, and Zbigniew Herbert, whose 'Mr. Cogito' poems embodied moral resistance. Olga Tokarczuk (Nobel 2018) wrote Flights and Drive Your Plow Over the Bones of the Dead."]],
  ["Hungary and the Balkans",[
    "Hungarian literature includes poets Sándor Petőfi and Attila József, novelist Sándor Márai (Embers), Imre Kertész (Nobel 2002), and László Krasznahorkai, known for long-sentenced apocalyptic novels such as Satantango (Nobel 2025).",
    "Yugoslav writer Ivo Andrić won the 1961 Nobel Prize for The Bridge on the Drina, a chronicle of centuries of Bosnian history around one bridge. Danilo Kiš (A Tomb for Boris Davidovich) and Romanian-born writers such as Herta Müller (Nobel 2009; The Land of Green Plums) depicted totalitarian violence."]],
  ["Ukraine and the Baltics",[
    "Ukrainian literature's national poet, Taras Shevchenko (1814–1861), born a serf, wrote Kobzar and suffered exile for his poetry. Writers such as Lesya Ukrainka, and in recent decades Serhiy Zhadan and Andrey Kurkov, have explored Ukrainian identity, war, and resistance, gaining wider attention since the 2022 Russian invasion.",
    "Baltic literatures preserved national languages under Russian and Soviet rule; folk song traditions, such as Latvia's dainas, are central to their cultures."]],
  ["Common themes",[
    "Central and Eastern European writing often combines irony, absurdity, and moral seriousness, shaped by empires, wars, occupations, and communism. The 'Kafkaesque' and the 'Švejkian' are two sides of its response to oppressive power.",
    "Since 1989 these literatures have engaged with freedom, memory, and new uncertainties."]]
  ],
  terms:[["Švejk","Comic soldier undermining authority by obedience."],["Robot","Word introduced by Čapek's R.U.R."],["Prague Spring","1968 Czech reform movement crushed by Soviets."],["The Captive Mind","Miłosz's analysis of intellectuals under communism."],["Kobzar","Shevchenko's poetry collection."]],
  w:"Central and Eastern European literature turned irony and moral courage into tools against oppression.",
  src:["The Good Soldier Švejk","Milan Kundera","Wisława Szymborska","Czesław Miłosz","Taras Shevchenko"],
  q:[
  ["Which work introduced the word 'robot'?","Čapek's R.U.R.","Švejk","The Joke","Quo Vadis"],
  ["Who wrote The Unbearable Lightness of Being?","Milan Kundera","Václav Havel","Bohumil Hrabal","Josef Škvorecký"],
  ["Which Polish poet won the 1996 Nobel Prize?","Wisława Szymborska","Czesław Miłosz","Zbigniew Herbert","Adam Zagajewski"],
  ["Who wrote The Bridge on the Drina?","Ivo Andrić","Danilo Kiš","Meša Selimović","Miroslav Krleža"],
  ["Who is Ukraine's national poet?","Taras Shevchenko","Lesya Ukrainka","Ivan Franko","Serhiy Zhadan"],
  ["Who wrote The Good Soldier Švejk?","Jaroslav Hašek","Franz Kafka","Karel Čapek","Milan Kundera"]]},

{ t:"Scandinavian and Nordic Literature", s:"From Andersen to Nordic noir",
  sec:[
  ["Hans Christian Andersen",[
    "Denmark's Hans Christian Andersen (1805–1875), a poor shoemaker's son, wrote some 150 fairy tales, including 'The Little Mermaid,' 'The Ugly Duckling,' 'The Emperor's New Clothes,' 'The Snow Queen' (which inspired Frozen), and 'The Little Match Girl.' Unlike folk collectors, he invented most of his tales, mixing wit and melancholy.",
    "Danish philosopher Søren Kierkegaard, writing under pseudonyms (Either/Or, Fear and Trembling), was a founder of existentialism."]],
  ["Ibsen and the Norwegians",[
    "Beyond Ibsen, Norway produced Knut Hamsun, whose Hunger (1890), about a starving writer in Christiania (Oslo), anticipated modernist interiority; he won the Nobel Prize in 1920 but disgraced himself by supporting Nazism. Sigrid Undset won the Nobel Prize in 1928 for Kristin Lavransdatter, a medieval trilogy.",
    "Jon Fosse (Nobel 2023) writes minimalist plays and the Septology novels."]],
  ["Sweden and Finland",[
    "Sweden's Selma Lagerlöf became the first woman to win the Nobel Prize in Literature (1909); her The Wonderful Adventures of Nils follows a boy flying across Sweden on a goose. Astrid Lindgren created Pippi Longstocking (1945), the super-strong, independent girl who lives alone with a horse and a monkey, translated into over 70 languages.",
    "Finland's Tove Jansson, writing in Swedish, created the Moomins, gentle troll-like creatures, and The Summer Book. Elias Lönnrot compiled the Kalevala (1835), Finland's national epic from oral songs, which inspired Tolkien. Poet Tomas Tranströmer of Sweden won the Nobel Prize in 2011."]],
  ["Iceland",[
    "Iceland, with its saga heritage, has one of the highest rates of book publishing per capita; the pre-Christmas 'Jólabókaflóð' (Christmas book flood) is a tradition of giving books. Halldór Laxness won the Nobel Prize in 1955 for novels such as Independent People, about a stubborn sheep farmer.",
    "Contemporary Icelandic writers include Sjón and the crime novelist Arnaldur Indriðason."]],
  ["Nordic noir",[
    "Scandinavian crime fiction, 'Nordic noir,' became a global phenomenon. Maj Sjöwall and Per Wahlöö's Martin Beck series (1960s–70s) used detective stories to critique Swedish society; Henning Mankell's Wallander novels and Stieg Larsson's The Girl with the Dragon Tattoo (2005), featuring hacker Lisbeth Salander, sold tens of millions.",
    "Jo Nesbø (Harry Hole novels) and the TV series The Killing and The Bridge spread the genre's bleak atmosphere and social critique."]]
  ],
  terms:[["Fairy tale","Story of magic and wonder; Andersen invented many."],["Kalevala","Finland's national epic."],["Moomins","Tove Jansson's creatures."],["Jólabókaflóð","Iceland's Christmas book flood."],["Nordic noir","Bleak Scandinavian crime fiction."]],
  w:"Nordic literature gave the world beloved fairy tales and children's classics, sagas, and the crime boom of Nordic noir.",
  src:["Hans Christian Andersen","Selma Lagerlöf","Astrid Lindgren","Kalevala","Nordic noir"],
  q:[
  ["Who wrote 'The Little Mermaid' and 'The Ugly Duckling'?","Hans Christian Andersen","The Brothers Grimm","Selma Lagerlöf","Charles Perrault"],
  ["Who was the first woman to win the Nobel Prize in Literature?","Selma Lagerlöf","Sigrid Undset","Grazia Deledda","Pearl Buck"],
  ["Who created Pippi Longstocking?","Astrid Lindgren","Tove Jansson","Selma Lagerlöf","Maria Gripe"],
  ["What is the Kalevala?","Finland's national epic","An Icelandic saga","A Danish fairy tale","A Swedish novel"],
  ["Who created Lisbeth Salander?","Stieg Larsson","Henning Mankell","Jo Nesbø","Camilla Läckberg"],
  ["Which Icelandic writer won the 1955 Nobel Prize?","Halldór Laxness","Sjón","Snorri Sturluson","Gunnar Gunnarsson"]]},

{ t:"Modern Spain, Portugal, and Italy", s:"Generations, dictators, and inventions",
  sec:[
  ["Spain's Generation of '98",[
    "After Spain lost its last major colonies in 1898, the 'Generation of '98,' including Miguel de Unamuno, Antonio Machado, and Ramón del Valle-Inclán, reflected on national identity. Machado's poems of Castile and Unamuno's novel Mist, in which a character confronts his author, were influential.",
    "The 'Generation of '27,' including Lorca, Rafael Alberti, Luis Cernuda, and Vicente Aleixandre (Nobel 1977), brought avant-garde poetry to Spain."]],
  ["Civil War and after",[
    "The Spanish Civil War (1936–39) drew writers from around the world (Orwell, Hemingway) and drove many Spanish writers into exile. Under Franco's dictatorship, censorship shaped literature; Camilo José Cela's The Family of Pascual Duarte (1942) and The Hive depicted harsh realities; he won the Nobel Prize in 1989. Carmen Laforet's Nada (1945) portrayed a bleak postwar Barcelona.",
    "Later Spanish writers include Javier Marías, Carlos Ruiz Zafón (The Shadow of the Wind), Almudena Grandes, and Rosa Montero."]],
  ["Portugal",[
    "Fernando Pessoa (1888–1935) wrote under some 75 heteronyms, invented poets with distinct biographies and styles: Alberto Caeiro (pastoral simplicity), Ricardo Reis (classical odes), and Álvaro de Campos (modernist energy), plus the semi-heteronym Bernardo Soares, 'author' of The Book of Disquiet, published posthumously from fragments found in a trunk.",
    "José Saramago (Nobel 1998) wrote allegorical novels with long sentences and little punctuation: Blindness (an epidemic of white blindness), The Year of the Death of Ricardo Reis, and The Gospel According to Jesus Christ. Lobo Antunes and Brazilian Portuguese writers such as Machado de Assis (The Posthumous Memoirs of Brás Cubas, narrated by a dead man) enriched the language's literature."]],
  ["Italy",[
    "Italian modern literature includes Giovanni Verga's verismo stories of Sicilian peasants, Grazia Deledda (Nobel 1926), Pirandello, Italo Svevo, and poets Eugenio Montale (Nobel 1975) and Giuseppe Ungaretti. Giuseppe Tomasi di Lampedusa's The Leopard (1958), about a Sicilian prince during Italian unification, contains the famous line 'If we want things to stay as they are, things will have to change.'",
    "Postwar writers include Alberto Moravia, Cesare Pavese, Natalia Ginzburg (Family Lexicon), Elsa Morante (History), Primo Levi, Italo Calvino, Umberto Eco, Dario Fo (Nobel 1997, satirical plays), and Elena Ferrante."]],
  ["Latin connections",[
    "Spanish, Portuguese, and Italian literatures connect closely with Latin American and lusophone African literatures through shared languages, migration, and exile; the Cervantes Prize and Camões Prize honor writers across the Spanish- and Portuguese-speaking worlds.",
    "Translation of these literatures into English has grown significantly."]]
  ],
  terms:[["Generation of '98","Spanish writers reflecting on national crisis."],["Generation of '27","Spanish avant-garde poets."],["Heteronym","Pessoa's fully invented alternate poets."],["The Leopard","Lampedusa's novel of Sicilian aristocracy."],["Verismo","Italian realism of ordinary lives."]],
  w:"Modern Iberian and Italian literatures combine inventive forms with reflection on history and dictatorship.",
  src:["Fernando Pessoa","José Saramago","The Leopard","Generation of '98","Machado de Assis"],
  q:[
  ["Who wrote under some 75 heteronyms?","Fernando Pessoa","José Saramago","Eça de Queirós","Camões"],
  ["Which Saramago novel describes an epidemic of white blindness?","Blindness","Seeing","The Cave","Death with Interruptions"],
  ["Which novel says things must change to stay the same?","The Leopard","The Name of the Rose","Nada","The Hive"],
  ["Whose novel is narrated by a dead man, Brás Cubas?","Machado de Assis","Jorge Amado","Clarice Lispector","Saramago"],
  ["Which Italian playwright won the 1997 Nobel Prize?","Dario Fo","Luigi Pirandello","Eduardo De Filippo","Carlo Goldoni"],
  ["Which group did Lorca belong to?","Generation of '27","Generation of '98","Generation of '68","The Boom"]]}

);


/* ---- from lit-24.js ---- */
/* LITERATURE FOUNDATIONS, part 24: Unit 10 Genres and Popular Forms, chapters 1-5 */
COURSES.literature.units.push({ t:"Genres and Popular Forms", ch:[

{ t:"Myths, Folktales, and Fairy Tales", s:"The oldest stories",
  sec:[
  ["Myth",[
    "Myths are traditional sacred stories explaining the origins of the world, gods, humans, and customs: Greek, Norse, Egyptian, Hindu, Chinese, Yoruba, Aboriginal Australian, and countless others. They shape literature across ages, from Homer and Ovid to modern retellings such as Neil Gaiman's Norse Mythology and Madeline Miller's Circe.",
    "Scholars have interpreted myths in many ways: as explanations of nature, as social charters, as expressions of the unconscious (Carl Jung's archetypes), or, in Claude Lévi-Strauss's structuralism, as ways of working through contradictions."]],
  ["Folktales",[
    "Folktales are traditional stories passed down orally: tricksters, animal fables, tales of clever peasants and foolish kings, ghost stories, and wonder tales. Folklorists classify them by type in the Aarne–Thompson–Uther index; for example, 'Cinderella' stories (type 510A) exist in hundreds of versions worldwide, including a Chinese version from the 9th century, 'Ye Xian.'",
    "Aesop's fables (attributed to a Greek storyteller of the 6th century BCE), such as 'The Tortoise and the Hare,' end with morals."]],
  ["Fairy-tale collectors",[
    "Literary fairy tales were shaped by collectors and writers: Giambattista Basile's Pentamerone (1634–36), Charles Perrault's Tales of Mother Goose (1697), the Brothers Grimm's Children's and Household Tales (1812–57), Hans Christian Andersen's original tales, and Andrew Lang's colored Fairy Books.",
    "The Grimms' early versions were often darker than later editions: Cinderella's stepsisters cut off parts of their feet to fit the slipper and have their eyes pecked out by birds."]],
  ["Meaning and interpretation",[
    "Psychologist Bruno Bettelheim's The Uses of Enchantment (1976) argued fairy tales help children work through fears; feminist critics have examined passive heroines and wicked stepmothers; folklorists emphasize historical contexts like famine and child abandonment (as in 'Hansel and Gretel').",
    "Vladimir Propp's Morphology of the Folktale (1928) identified 31 recurring 'functions' in Russian fairy tales, such as the hero's departure, a test, and receipt of a magical agent."]],
  ["Retellings",[
    "Writers continually reinvent myths and tales: Angela Carter's The Bloody Chamber, Disney animated films, Gregory Maguire's Wicked (retelling The Wizard of Oz from the Witch's view), and many novels reimagining Greek myths from women's perspectives.",
    "Myths and fairy tales remain a shared language of storytelling."]]
  ],
  terms:[["Myth","Traditional sacred story of origins."],["Folktale","Traditional story passed down orally."],["Fable","Short animal story with a moral."],["Archetype","Recurring universal pattern or character."],["Tale type","Folklorists' classification of story patterns."]],
  w:"Myths and fairy tales are the deep roots of storytelling, constantly retold and reinterpreted.",
  src:["Myth","Folklore","Fairy tale","Aarne–Thompson–Uther Index","Aesop's Fables"],
  q:[
  ["Who identified 31 recurring functions in Russian fairy tales?","Vladimir Propp","Claude Lévi-Strauss","Carl Jung","Bruno Bettelheim"],
  ["Which ancient Chinese story is a version of Cinderella?","Ye Xian","Mulan","The Butterfly Lovers","Journey to the West"],
  ["Who wrote The Uses of Enchantment?","Bruno Bettelheim","Joseph Campbell","Angela Carter","Marina Warner"],
  ["To whom are fables like 'The Tortoise and the Hare' attributed?","Aesop","Perrault","Andersen","La Fontaine"],
  ["What happens to Cinderella's stepsisters in the Grimms' version?","Birds peck out their eyes","They marry princes","They become fairies","Nothing"],
  ["Which novel retells The Wizard of Oz from the Witch's view?","Wicked","Circe","The Bloody Chamber","Stardust"]]},

{ t:"Children's Literature", s:"From Alice to Harry Potter",
  sec:[
  ["Early children's books",[
    "Books written specifically to delight children developed in the 18th century; John Newbery's A Little Pretty Pocket-Book (1744) combined instruction and amusement, and the Newbery Medal (US, from 1922) is named for him. Earlier children's reading was largely moral and religious instruction.",
    "The 19th century brought a 'golden age' of children's literature."]],
  ["The golden age",[
    "Lewis Carroll (Charles Dodgson, an Oxford mathematician) wrote Alice's Adventures in Wonderland (1865) and Through the Looking-Glass, full of logic games, nonsense, and characters like the Mad Hatter, the Cheshire Cat, and the Queen of Hearts ('Off with her head!'). Louisa May Alcott's Little Women, Mark Twain's Tom Sawyer, Robert Louis Stevenson's Treasure Island, Carlo Collodi's Pinocchio (1883), and Johanna Spyri's Heidi followed.",
    "Early 20th-century classics include J. M. Barrie's Peter Pan, Kenneth Grahame's The Wind in the Willows, Beatrix Potter's The Tale of Peter Rabbit, L. Frank Baum's The Wonderful Wizard of Oz (1900), L. M. Montgomery's Anne of Green Gables, Frances Hodgson Burnett's The Secret Garden, and A. A. Milne's Winnie-the-Pooh."]],
  ["Mid-century classics",[
    "Antoine de Saint-Exupéry's The Little Prince (1943), with its line 'what is essential is invisible to the eye,' is among the most translated books in the world. C. S. Lewis's Chronicles of Narnia, E. B. White's Charlotte's Web (1952), Roald Dahl's darkly funny books (Charlie and the Chocolate Factory, Matilda), Astrid Lindgren, and Maurice Sendak's picture book Where the Wild Things Are (1963) became beloved.",
    "Dr. Seuss (Theodor Geisel) transformed early reading with The Cat in the Hat (1957), written with a limited vocabulary of 236 words."]],
  ["Contemporary children's literature",[
    "J. K. Rowling's Harry Potter series (1997–2007), about a boy wizard at Hogwarts School, sold over 500 million copies, became one of the best-selling series in history, and revived reading among children worldwide. Philip Pullman's His Dark Materials, Jacqueline Wilson, and many others explored complex themes for young readers.",
    "Diverse children's books, reflecting children of many backgrounds, have expanded since the 1960s; Ezra Jack Keats's The Snowy Day (1962) was a landmark picture book with a Black protagonist."]],
  ["Why children's books matter",[
    "Children's literature shapes early imagination, language, and moral understanding, and many adults return to childhood favorites. Picture books combine word and image in a distinct art form.",
    "Major awards include the Newbery and Caldecott Medals (US), the Carnegie Medal (UK), and the Hans Christian Andersen Award (international)."]]
  ],
  terms:[["Golden age","19th–early 20th-century flowering of children's books."],["Picture book","Book combining text and illustrations."],["Newbery Medal","US award for children's literature."],["Nonsense","Playful absurd writing, as in Carroll."],["Hogwarts","Harry Potter's school of wizardry."]],
  w:"Children's literature is where most readers begin, and its classics shape imagination for life.",
  src:["Children's literature","Alice's Adventures in Wonderland","The Little Prince","Harry Potter","Golden Age of Children's Literature"],
  q:[
  ["What was Lewis Carroll's real profession?","Oxford mathematician","Doctor","Clergyman only","Banker"],
  ["Which book says 'what is essential is invisible to the eye'?","The Little Prince","Charlotte's Web","Peter Pan","The Secret Garden"],
  ["Who wrote Charlie and the Chocolate Factory?","Roald Dahl","C. S. Lewis","E. B. White","Dr. Seuss"],
  ["How many words did Dr. Seuss use in The Cat in the Hat?","236","50","1,000","100"],
  ["Who wrote Pinocchio?","Carlo Collodi","Johanna Spyri","Hans Christian Andersen","Italo Calvino"],
  ["Which picture book by Maurice Sendak appeared in 1963?","Where the Wild Things Are","The Snowy Day","Goodnight Moon","The Very Hungry Caterpillar"]]},

{ t:"Fantasy Literature", s:"Other worlds",
  sec:[
  ["Roots",[
    "Fantasy draws on myth, epic, romance, and fairy tale. Modern fantasy developed in the 19th century with George MacDonald's Phantastes, William Morris's medieval-style romances, and Lord Dunsany's invented mythologies.",
    "Robert E. Howard's Conan the Barbarian stories (1930s) created 'sword and sorcery.'"]],
  ["Tolkien",[
    "J. R. R. Tolkien (1892–1973), an Oxford professor of Old English, created Middle-earth with its own languages, histories, and maps. The Hobbit (1937) follows Bilbo Baggins on a quest with dwarves to reclaim treasure from the dragon Smaug. The Lord of the Rings (1954–55) tells of Frodo's quest to destroy the One Ring forged by the dark lord Sauron, aided by the Fellowship, including Gandalf, Aragorn, and Samwise Gamgee.",
    "Tolkien's 'secondary world' approach, deep world-building, and themes of power, friendship, and loss defined modern 'high fantasy.' Peter Jackson's films (2001–03) renewed its popularity."]],
  ["C. S. Lewis and others",[
    "Tolkien's friend C. S. Lewis, fellow member of the Oxford writers' group the Inklings, wrote The Chronicles of Narnia (1950–56), beginning with The Lion, the Witch and the Wardrobe, with its Christian allegory of the lion Aslan.",
    "Ursula K. Le Guin's Earthsea books (from 1968) followed a young wizard and explored balance and names; Terry Pratchett's comic Discworld series (41 novels) satirized everything; and Mervyn Peake's Gormenghast trilogy created a vast Gothic castle-world."]],
  ["Modern fantasy",[
    "George R. R. Martin's A Song of Ice and Fire (from 1996), basis of the TV series Game of Thrones, brought gritty, political 'grimdark' realism to fantasy. Other influential writers include Robert Jordan (The Wheel of Time), Neil Gaiman (American Gods, The Sandman comics), Brandon Sanderson, N. K. Jemisin (the first writer to win the Hugo Award for Best Novel three years in a row, 2016–18, for The Broken Earth trilogy), and Susanna Clarke (Jonathan Strange & Mr Norrell).",
    "Urban fantasy, romantasy, and fantasy drawing on African, Asian, and Indigenous traditions have broadened the genre."]],
  ["Why fantasy matters",[
    "Tolkien's essay 'On Fairy-Stories' (1947) defended fantasy as offering recovery (seeing the world freshly), escape (not of the deserter but of the prisoner), and consolation (the 'eucatastrophe,' the sudden joyous turn).",
    "Fantasy allows writers to explore power, morality, and identity through invented worlds, and is one of the best-selling genres."]]
  ],
  terms:[["High fantasy","Fantasy set in a fully invented world."],["World-building","Creating a fictional world's history and rules."],["Inklings","Oxford writers' group including Tolkien and Lewis."],["Grimdark","Dark, morally gray fantasy."],["Eucatastrophe","Tolkien's term for a sudden joyous turn."]],
  w:"Fantasy creates other worlds that let us see our own more clearly, and it is among literature's most popular genres.",
  src:["Fantasy literature","J. R. R. Tolkien","The Lord of the Rings","The Chronicles of Narnia","Ursula K. Le Guin"],
  q:[
  ["Who created Middle-earth?","J. R. R. Tolkien","C. S. Lewis","Ursula K. Le Guin","George MacDonald"],
  ["What is the name of the lion in Narnia?","Aslan","Smaug","Gandalf","Rincewind"],
  ["Which series became Game of Thrones?","A Song of Ice and Fire","The Wheel of Time","Discworld","Earthsea"],
  ["What was the Inklings?","An Oxford writers' group","A fantasy prize","A publisher","A Middle-earth language"],
  ["Who won three consecutive Hugo Awards for Best Novel (2016–18)?","N. K. Jemisin","Brandon Sanderson","Neil Gaiman","Ann Leckie"],
  ["Which series by Terry Pratchett is comic fantasy?","Discworld","Earthsea","Gormenghast","Narnia"]]},

{ t:"Science Fiction", s:"Imagining futures",
  sec:[
  ["Origins",[
    "Science fiction explores the impact of science and technology, real or imagined, on humans and societies. Precursors include Lucian's 2nd-century True History (a voyage to the moon), Kepler's Somnium, and Swift's Laputa; Mary Shelley's Frankenstein (1818) is often called the first true science fiction novel.",
    "Jules Verne (Twenty Thousand Leagues Under the Sea, Journey to the Center of the Earth) and H. G. Wells (The Time Machine, The War of the Worlds, The Invisible Man) founded the modern genre in the late 19th century."]],
  ["The Golden Age",[
    "American pulp magazines, starting with Hugo Gernsback's Amazing Stories (1926), popularized 'scientifiction'; the Hugo Awards are named after him. During the 'Golden Age' (late 1930s–1950s), editor John W. Campbell published Isaac Asimov (the Foundation series and robot stories with the Three Laws of Robotics), Robert A. Heinlein, and Arthur C. Clarke (2001: A Space Odyssey).",
    "Ray Bradbury's The Martian Chronicles and Fahrenheit 451 brought lyrical style to the genre."]],
  ["New Wave and beyond",[
    "The 1960s–70s 'New Wave' brought literary experimentation and social themes: Frank Herbert's Dune (1965), an ecological epic of the desert planet Arrakis; Ursula K. Le Guin's The Left Hand of Darkness (1969), about a planet whose people have no fixed sex, and The Dispossessed; Philip K. Dick's paranoid explorations of reality (Do Androids Dream of Electric Sheep?, basis of Blade Runner); and J. G. Ballard.",
    "Octavia E. Butler (Kindred, Parable of the Sower) brought race and gender to the center; William Gibson's Neuromancer (1984) launched cyberpunk and coined 'cyberspace' (earlier, in a 1982 story)."]],
  ["Contemporary science fiction",[
    "Recent science fiction explores climate change, artificial intelligence, genetic engineering, and space: Kim Stanley Robinson's The Ministry for the Future, Liu Cixin's The Three-Body Problem, Ted Chiang's stories (basis of the film Arrival), Ann Leckie's Ancillary Justice, Martha Wells's Murderbot Diaries, and Andy Weir's The Martian.",
    "'Afrofuturism' (Nnedi Okorafor) and 'solarpunk' imagine alternative futures. Literary novelists such as Kazuo Ishiguro (Klara and the Sun) increasingly use science fiction themes."]],
  ["Why science fiction matters",[
    "Science fiction asks 'what if?', examining how technology changes humanity and offering warnings and hopes. It has influenced real science and technology: submarines, rockets, communication satellites (proposed by Clarke in 1945), and the vocabulary of robots, cyberspace, and the metaverse.",
    "Le Guin argued that science fiction is not predictive but descriptive: it describes the present through metaphor."]]
  ],
  terms:[["Science fiction","Fiction exploring imagined science and technology."],["Three Laws of Robotics","Asimov's rules for robots."],["Cyberpunk","High-tech, low-life science fiction."],["Afrofuturism","Futures from African diasporic perspectives."],["Hugo Award","Major science fiction award."]],
  w:"Science fiction is literature's laboratory for imagining how technology and change could transform humanity.",
  src:["Science fiction","Isaac Asimov","Dune (novel)","Octavia E. Butler","Neuromancer"],
  q:[
  ["Who formulated the Three Laws of Robotics?","Isaac Asimov","Arthur C. Clarke","Robert Heinlein","Philip K. Dick"],
  ["On which planet is Dune set?","Arrakis","Gethen","Trantor","Mars"],
  ["Which Philip K. Dick novel became Blade Runner?","Do Androids Dream of Electric Sheep?","Ubik","The Man in the High Castle","A Scanner Darkly"],
  ["Who launched cyberpunk with Neuromancer?","William Gibson","Neal Stephenson","Bruce Sterling","Octavia Butler"],
  ["After whom is the Hugo Award named?","Hugo Gernsback","Victor Hugo","Hugo Grotius","Hugo Weaving"],
  ["Who wrote The Left Hand of Darkness?","Ursula K. Le Guin","Octavia Butler","Joanna Russ","Margaret Atwood"]]},

{ t:"Crime and Detective Fiction", s:"Whodunits and noir",
  sec:[
  ["Origins",[
    "Edgar Allan Poe invented the detective story with 'The Murders in the Rue Morgue' (1841), featuring the brilliant amateur C. Auguste Dupin. Wilkie Collins's The Moonstone (1868), about a stolen Indian diamond, was called by T. S. Eliot 'the first, the longest, and the best of modern English detective novels.'",
    "Arthur Conan Doyle's Sherlock Holmes (from 1887) established the brilliant detective and admiring sidekick formula."]],
  ["The Golden Age",[
    "The 'Golden Age' of detective fiction (1920s–30s), mostly British, featured puzzle-like 'whodunits' with closed settings and fair clues. Agatha Christie (1890–1976), the best-selling novelist of all time according to Guinness World Records, created Hercule Poirot and Miss Marple; The Murder of Roger Ackroyd (1926) shocked readers with its twist, and And Then There Were None is among the best-selling books ever. Her play The Mousetrap has run in London since 1952.",
    "Dorothy L. Sayers (Lord Peter Wimsey), Margery Allingham, and Ngaio Marsh were other 'Queens of Crime.' G. K. Chesterton created the priest-detective Father Brown."]],
  ["Hard-boiled and noir",[
    "American 'hard-boiled' fiction, from pulp magazines like Black Mask, featured tough private eyes in corrupt cities: Dashiell Hammett's The Maltese Falcon (1930), with Sam Spade, and Raymond Chandler's The Big Sleep (1939), with Philip Marlowe ('Down these mean streets a man must go'). James M. Cain's The Postman Always Rings Twice told crimes from the criminal's side.",
    "Film noir adapted this world. Patricia Highsmith's The Talented Mr. Ripley (1955) made a charming murderer the protagonist."]],
  ["Varieties of crime fiction",[
    "Crime fiction includes police procedurals (Ed McBain, P. D. James's Adam Dalgliesh), psychological thrillers (Gillian Flynn's Gone Girl, 2012), legal thrillers (John Grisham), spy fiction (John le Carré's The Spy Who Came in from the Cold, Ian Fleming's James Bond), cozy mysteries, Nordic noir, and true crime (Truman Capote's In Cold Blood).",
    "Georges Simenon's Inspector Maigret (Belgium/France), Andrea Camilleri's Montalbano (Sicily), and Japanese writers like Keigo Higashino show its global reach."]],
  ["Why crime fiction endures",[
    "Crime fiction offers puzzles, suspense, and the restoration of order, while also exploring society's darker sides: corruption, inequality, and violence. Writers such as Walter Mosley (Easy Rawlins) and Tana French use the genre to examine race, class, and trauma.",
    "It is consistently among the best-selling genres."]]
  ],
  terms:[["Whodunit","Puzzle mystery about identifying the culprit."],["Hard-boiled","Tough, cynical American crime fiction."],["Police procedural","Crime fiction following police work."],["Golden Age","1920s–30s era of classic detective puzzles."],["Noir","Dark, fatalistic crime style."]],
  w:"Crime fiction is one of the world's most popular genres, combining puzzles with social insight.",
  src:["Detective fiction","Agatha Christie","Raymond Chandler","The Moonstone","Hardboiled"],
  q:[
  ["Who created Hercule Poirot?","Agatha Christie","Dorothy L. Sayers","Arthur Conan Doyle","Ngaio Marsh"],
  ["Which novel did T. S. Eliot call the first and best detective novel?","The Moonstone","The Hound of the Baskervilles","The Murders in the Rue Morgue","Bleak House"],
  ["Who created Philip Marlowe?","Raymond Chandler","Dashiell Hammett","James M. Cain","Ross Macdonald"],
  ["Which Christie play has run in London since 1952?","The Mousetrap","Witness for the Prosecution","Murder on the Orient Express","And Then There Were None"],
  ["Who created Tom Ripley?","Patricia Highsmith","Gillian Flynn","Ruth Rendell","P. D. James"],
  ["Who wrote The Spy Who Came in from the Cold?","John le Carré","Ian Fleming","Graham Greene","Len Deighton"]]}

]});


/* ---- from lit-25.js ---- */
/* LITERATURE FOUNDATIONS, part 25: Unit 10 chapters 6-11 */
COURSES.literature.units[9].ch.push(

{ t:"Horror and Romance", s:"Popular genres of fear and love",
  sec:[
  ["Horror's roots",[
    "Horror grew from Gothic fiction, folklore, and ghost stories. Victorian ghost stories by M. R. James and Sheridan Le Fanu, Bram Stoker's Dracula, and Robert Louis Stevenson's Jekyll and Hyde shaped the genre. H. P. Lovecraft (1890–1937) created 'cosmic horror,' in which humanity is insignificant before vast, ancient beings such as Cthulhu.",
    "Shirley Jackson's 'The Lottery' (1948), a story about a village's annual ritual stoning, provoked hundreds of angry letters to The New Yorker; her The Haunting of Hill House (1959) is a classic of psychological horror."]],
  ["Modern horror",[
    "Stephen King (born 1947), author of Carrie, The Shining, It, and dozens of other books, became one of the best-selling authors in history, rooting horror in ordinary American small towns. Anne Rice's Interview with the Vampire (1976) gave vampires a sympathetic voice.",
    "Contemporary horror writers such as Mariana Enríquez, Paul Tremblay, and Silvia Moreno-Garcia (Mexican Gothic) explore social anxieties, and 'folk horror' and 'elevated horror' have gained literary respect."]],
  ["Why we enjoy fear",[
    "Psychologists suggest horror lets audiences experience fear safely, rehearse responses to threats, and confront taboos and anxieties, about death, disease, technology, or social change. Monsters often embody the fears of their era: Frankenstein's science, Dracula's foreign invasion, and zombies' mass consumerism or pandemic.",
    "Horror's emotional intensity and twists make it popular in fiction and film."]],
  ["Romance fiction",[
    "Romance fiction centers on a love story with an emotionally satisfying, optimistic ending ('happily ever after'). Its roots include Samuel Richardson's Pamela, Jane Austen, and the Brontës. Georgette Heyer created the Regency romance in the 1930s; Mills & Boon (UK, from 1908) and Harlequin (Canada) made category romance a mass market.",
    "Romance is among the best-selling fiction genres, with large, mostly female readerships; subgenres include historical, contemporary, paranormal, and 'romantasy' (romance plus fantasy)."]],
  ["Genre and prestige",[
    "Romance and horror have often been dismissed as 'lowbrow,' but critics increasingly recognize their craft and cultural significance. Janice Radway's Reading the Romance (1984) studied how women readers use romance novels.",
    "Many literary classics, such as Jane Eyre and Rebecca, blend romance, Gothic, and horror elements, showing that genre boundaries are porous."]]
  ],
  terms:[["Cosmic horror","Lovecraft's horror of human insignificance."],["Psychological horror","Horror rooted in the mind."],["Happily ever after","Romance's optimistic ending."],["Regency romance","Romance set in early 19th-century England."],["Romantasy","Blend of romance and fantasy."]],
  w:"Horror and romance are among the most widely read genres, revealing how stories satisfy fear and longing.",
  src:["Horror fiction","Stephen King","The Lottery","Romance novel","H. P. Lovecraft"],
  q:[
  ["Who created 'cosmic horror' and Cthulhu?","H. P. Lovecraft","Edgar Allan Poe","Stephen King","M. R. James"],
  ["Which story about an annual stoning provoked outraged letters?","The Lottery","The Yellow Wallpaper","Carrie","The Shining"],
  ["Who wrote The Shining and It?","Stephen King","Anne Rice","Clive Barker","Dean Koontz"],
  ["Who created the Regency romance?","Georgette Heyer","Barbara Cartland","Jane Austen","Nora Roberts"],
  ["What is romance fiction's defining ending?","Happily ever after","A tragic death","An open question","A wedding only"],
  ["Who wrote Reading the Romance (1984)?","Janice Radway","Angela Carter","Germaine Greer","Elaine Showalter"]]},

{ t:"Comics and Graphic Novels", s:"Words and pictures",
  sec:[
  ["A visual art of storytelling",[
    "Comics combine images and words in sequential panels; Scott McCloud's Understanding Comics (1993) called them 'juxtaposed pictorial and other images in deliberate sequence.' Readers fill in action between panels in the 'gutter,' an imaginative act called closure.",
    "Comics traditions include American comic strips and superhero comics, Franco-Belgian bandes dessinées, and Japanese manga."]],
  ["Superheroes and strips",[
    "Newspaper comic strips such as The Yellow Kid (1895), Little Nemo in Slumberland, Peanuts (Charles Schulz), and Calvin and Hobbes became beloved. Superman's debut in Action Comics #1 (1938), created by Jerry Siegel and Joe Shuster, launched the superhero genre; Batman, Wonder Woman, and Marvel's Spider-Man and X-Men (created with Stan Lee, Jack Kirby, and Steve Ditko in the 1960s) followed.",
    "The 1954 Comics Code, adopted after psychiatrist Fredric Wertham's attack on comics in Seduction of the Innocent, censored content for decades."]],
  ["Europe and Japan",[
    "Belgium's Hergé created Tintin (from 1929), with his clear-line drawing style; France's Goscinny and Uderzo created Asterix (1959). In Japan, Osamu Tezuka, the 'god of manga,' created Astro Boy and pioneered cinematic techniques; manga and anime became global phenomena, with series such as One Piece selling hundreds of millions of copies.",
    "Japanese manga is read right to left and spans every genre and age group."]],
  ["The graphic novel",[
    "Will Eisner popularized the term 'graphic novel' with A Contract with God (1978). Art Spiegelman's Maus, depicting his father's Holocaust experience with Jews as mice and Nazis as cats, won a special Pulitzer Prize in 1992. Alan Moore and Dave Gibbons's Watchmen (1986–87) deconstructed superheroes.",
    "Marjane Satrapi's Persepolis, Alison Bechdel's Fun Home (a memoir of her father and her coming out, later a Broadway musical), Chris Ware's Jimmy Corrigan, and Nick Drnaso's Sabrina (the first graphic novel longlisted for the Booker Prize, 2018) show the form's literary range."]],
  ["Comics today",[
    "Webcomics and digital platforms (such as Korean webtoons, read by scrolling on phones) reach huge audiences. Graphic novels for young readers, such as Raina Telgemeier's Smile, are among the best-selling children's books.",
    "Comics are now studied in universities and recognized as a major art form."]]
  ],
  terms:[["Panel","Single frame in a comic."],["Gutter","Space between panels where readers infer action."],["Manga","Japanese comics."],["Graphic novel","Book-length comic narrative."],["Bande dessinée","Franco-Belgian comics."]],
  w:"Comics and graphic novels are a major art form combining words and images, from Tintin to Maus.",
  src:["Comics","Graphic novel","Maus","Manga","Understanding Comics"],
  q:[
  ["Which graphic novel depicts Jews as mice and Nazis as cats?","Maus","Persepolis","Watchmen","Fun Home"],
  ["When did Superman debut?","1938","1929","1954","1962"],
  ["Who is called 'the god of manga'?","Osamu Tezuka","Hayao Miyazaki","Eiichiro Oda","Akira Toriyama"],
  ["Who created Tintin?","Hergé","Goscinny","Uderzo","Moebius"],
  ["Who popularized the term 'graphic novel'?","Will Eisner","Stan Lee","Art Spiegelman","Alan Moore"],
  ["What is the 'gutter' in comics?","The space between panels","A dark villain's lair","The cover","A speech balloon"]]},

{ t:"Young Adult Literature", s:"Stories of growing up",
  sec:[
  ["The birth of YA",[
    "Literature for teenagers emerged as a category in the mid-20th century. S. E. Hinton's The Outsiders (1967), written when she was a teenager, about rival gangs of greasers and Socs, is often called the first modern YA novel. Earlier, J. D. Salinger's The Catcher in the Rye and coming-of-age classics were adopted by young readers.",
    "Judy Blume's frank novels about puberty and family (Are You There God? It's Me, Margaret, 1970) addressed subjects previously avoided and were often challenged."]],
  ["Classics of the genre",[
    "Robert Cormier's The Chocolate War, Madeleine L'Engle's A Wrinkle in Time, Lois Lowry's The Giver (1993), Louis Sachar's Holes, and Mildred D. Taylor's Roll of Thunder, Hear My Cry (about a Black family in 1930s Mississippi) became widely taught.",
    "Phillip Pullman, J. K. Rowling, and Philip Reeve crossed between children's, YA, and adult readerships."]],
  ["The 21st-century boom",[
    "The 2000s saw a YA explosion: Stephenie Meyer's Twilight (vampire romance), Suzanne Collins's The Hunger Games (dystopia), John Green's The Fault in Our Stars (2012, about teenagers with cancer), and Angie Thomas's The Hate U Give (2017, about a girl who witnesses a police shooting). Many became blockbuster films.",
    "A large share of YA readers are adults, and YA has influenced adult fiction's themes and styles."]],
  ["Themes",[
    "YA literature typically features teenage protagonists, often narrated in first person, exploring identity, friendship, first love, family conflict, sexuality, mental health, and injustice. It tends to be emotionally direct and fast-paced.",
    "Diverse YA has grown through campaigns like We Need Diverse Books (2014), bringing stories of many races, cultures, sexualities, and abilities."]],
  ["Challenges and debates",[
    "YA books are frequently challenged in schools and libraries for content about sex, violence, race, or LGBTQ+ identities; challenges rose sharply in the early 2020s in the United States, according to the American Library Association.",
    "Supporters argue that honest YA books help teenagers navigate real problems and see themselves represented."]]
  ],
  terms:[["Young adult (YA)","Literature for teenage readers."],["Coming-of-age","Story of growth into adulthood."],["Crossover","Book appealing to multiple age groups."],["Book challenge","Attempt to remove a book from schools or libraries."],["We Need Diverse Books","Campaign for diversity in children's publishing."]],
  w:"Young adult literature speaks to readers at a formative age and has become a major force in publishing.",
  src:["Young adult fiction","The Outsiders (novel)","Judy Blume","The Hunger Games","The Hate U Give"],
  q:[
  ["Which novel is often called the first modern YA novel?","The Outsiders","The Catcher in the Rye","Twilight","The Giver"],
  ["Who wrote Are You There God? It's Me, Margaret?","Judy Blume","S. E. Hinton","Lois Lowry","Beverly Cleary"],
  ["Which 2017 YA novel concerns a police shooting?","The Hate U Give","The Fault in Our Stars","Holes","Speak"],
  ["Who wrote The Giver?","Lois Lowry","Madeleine L'Engle","Louis Sachar","Robert Cormier"],
  ["What campaign launched in 2014 for diversity in books?","We Need Diverse Books","Read Across America","Banned Books Week","BookTok"],
  ["Who wrote The Hunger Games?","Suzanne Collins","Stephenie Meyer","Veronica Roth","John Green"]]},

{ t:"Comedy, Satire, and Humor", s:"Literature that laughs",
  sec:[
  ["Why comedy matters",[
    "Comic literature ranges from gentle humor to savage satire. Philosophers have offered theories of laughter: superiority (laughing at others' misfortunes, Hobbes), incongruity (the surprise of mismatched expectations, Kant and Schopenhauer), and relief of tension (Freud). Henri Bergson saw laughter as a corrective to mechanical, rigid behavior.",
    "Comedy has often been considered inferior to tragedy, but many great works are comic."]],
  ["Satire through the ages",[
    "Satire uses humor to criticize vice and folly: Aristophanes, Juvenal, Rabelais, Cervantes, Swift, Voltaire, and Gogol. Modern satirists include Evelyn Waugh (Decline and Fall, Scoop, a satire of journalism), Joseph Heller's Catch-22, Kurt Vonnegut, and political satirists in journalism and television.",
    "Satire can be Horatian (gentle, amused) or Juvenalian (bitter, angry). It depends on audiences recognizing the target and the irony."]],
  ["Comic novels",[
    "P. G. Wodehouse's stories of the amiable idiot Bertie Wooster and his brilliant valet Jeeves (from 1915) are masterpieces of comic style. Jerome K. Jerome's Three Men in a Boat (1889), Stella Gibbons's Cold Comfort Farm (parodying rural melodrama: 'something nasty in the woodshed'), Kingsley Amis's Lucky Jim, John Kennedy Toole's A Confederacy of Dunces (published posthumously, Pulitzer 1981), and Douglas Adams's The Hitchhiker's Guide to the Galaxy (the answer to life, the universe, and everything is 42) are classics.",
    "Nikolai Gogol, Mark Twain, and Jaroslav Hašek are also comic giants."]],
  ["Comic verse and wit",[
    "Comic verse includes Edward Lear and Lewis Carroll's nonsense, W. S. Gilbert's lyrics for Gilbert and Sullivan operettas, Ogden Nash's playful rhymes, Hilaire Belloc's Cautionary Tales, and Dorothy Parker's acid wit ('Men seldom make passes / At girls who wear glasses').",
    "Oscar Wilde's epigrams and Mark Twain's aphorisms ('The reports of my death are greatly exaggerated' is a popular paraphrase of his remark) remain endlessly quoted."]],
  ["Dark comedy",[
    "Black comedy finds humor in death, war, and horror, as in Vonnegut, Heller, Beckett, and Muriel Spark. It can make unbearable subjects bearable and expose absurdity.",
    "Humor travels imperfectly across languages and times, making comic works especially challenging to translate."]]
  ],
  terms:[["Satire","Humor criticizing vice and folly."],["Horatian satire","Gentle, amused satire."],["Juvenalian satire","Bitter, angry satire."],["Black comedy","Humor about dark subjects."],["Incongruity theory","Laughter from mismatched expectations."]],
  w:"Comic literature delights and criticizes at once, and is among the hardest and most valuable arts.",
  src:["Comedy","Satire","P. G. Wodehouse","The Hitchhiker's Guide to the Galaxy","A Confederacy of Dunces"],
  q:[
  ["Who is Bertie Wooster's valet?","Jeeves","Bunter","Passepartout","Jenkins"],
  ["In Hitchhiker's Guide, what is the answer to life, the universe, and everything?","42","7","0","Infinity"],
  ["Which novel was published posthumously and won the 1981 Pulitzer?","A Confederacy of Dunces","Lucky Jim","Catch-22","Cold Comfort Farm"],
  ["What is Juvenalian satire?","Bitter, angry satire","Gentle satire","Satire of young people","Satire in verse only"],
  ["Which novel features 'something nasty in the woodshed'?","Cold Comfort Farm","Three Men in a Boat","Decline and Fall","Scoop"],
  ["Which philosopher saw laughter as a corrective to mechanical behavior?","Henri Bergson","Thomas Hobbes","Immanuel Kant","Plato"]]},

{ t:"Life, Travel, and Nature Writing", s:"Creative nonfiction",
  sec:[
  ["Creative nonfiction",[
    "Creative nonfiction uses literary techniques, narrative, scene, voice, imagery, to tell true stories. It includes memoir, biography, the personal essay, travel writing, nature writing, literary journalism, and history written for general readers.",
    "Debates about truth arise when memoirists embellish; James Frey's A Million Little Pieces was exposed in 2006 as containing fabrications."]],
  ["Memoir",[
    "Notable memoirs include Vladimir Nabokov's Speak, Memory, Maya Angelou's I Know Why the Caged Bird Sings, Frank McCourt's Angela's Ashes (about poverty in Limerick), Joan Didion's The Year of Magical Thinking (on grief after her husband's death), Tara Westover's Educated, and Michelle Obama's Becoming.",
    "Biography as an art includes Plutarch, Boswell, Lytton Strachey's ironic Eminent Victorians (1918), and Robert Caro's monumental The Power Broker and Lyndon Johnson volumes."]],
  ["Travel writing",[
    "Travel writing has ancient roots: Herodotus, Marco Polo's Travels (about 1300), and Ibn Battuta's Rihla, recounting about 30 years and some 120,000 km of journeys across the Islamic world and beyond in the 14th century. Later classics include Mark Twain's The Innocents Abroad, Patrick Leigh Fermor's A Time of Gifts (walking across Europe in 1933), Bruce Chatwin's In Patagonia, and Jan Morris's books on cities.",
    "Critics note that travel writing has often reflected colonial attitudes, and recent writers have challenged this perspective."]],
  ["Nature writing",[
    "Nature writing combines observation, science, and reflection. Gilbert White's The Natural History of Selborne (1789), Thoreau's Walden, John Muir, Aldo Leopold's A Sand County Almanac (with its 'land ethic'), and Annie Dillard's Pilgrim at Tinker Creek are classics. Rachel Carson's Silent Spring (1962), exposing the dangers of pesticides like DDT, helped launch the modern environmental movement.",
    "Recent nature writing includes Robert Macfarlane, Helen Macdonald's H Is for Hawk, and Robin Wall Kimmerer's Braiding Sweetgrass, which joins botany and Indigenous knowledge."]],
  ["Literary journalism",[
    "The 'New Journalism' of the 1960s–70s, by Tom Wolfe, Hunter S. Thompson (gonzo journalism), Joan Didion, Gay Talese, and Truman Capote's In Cold Blood, applied novelistic techniques to reporting. John Hersey's Hiroshima (1946), telling the stories of six survivors, filled an entire issue of The New Yorker.",
    "Today, long-form journalism, podcasts, and narrative nonfiction continue the tradition."]]
  ],
  terms:[["Creative nonfiction","True stories told with literary technique."],["Memoir","Account of the author's own life."],["Travel writing","Literature of journeys."],["Nature writing","Literature of the natural world."],["New Journalism","Reporting using novelistic techniques."]],
  w:"Creative nonfiction shows that true stories can have all the power and artistry of fiction.",
  src:["Creative nonfiction","Ibn Battuta","Silent Spring","New Journalism","Hiroshima (book)"],
  q:[
  ["Which book helped launch the modern environmental movement?","Silent Spring","Walden","A Sand County Almanac","Pilgrim at Tinker Creek"],
  ["Which 14th-century traveler wrote the Rihla?","Ibn Battuta","Marco Polo","Zheng He","Ibn Khaldun"],
  ["Which 1946 work filled an entire issue of The New Yorker?","Hiroshima","In Cold Blood","The Right Stuff","Silent Spring"],
  ["Who wrote The Year of Magical Thinking?","Joan Didion","Tara Westover","Maya Angelou","Annie Dillard"],
  ["Who practiced 'gonzo journalism'?","Hunter S. Thompson","Tom Wolfe","Gay Talese","Truman Capote"],
  ["Which book joins botany and Indigenous knowledge?","Braiding Sweetgrass","H Is for Hawk","The Overstory","Wild"]]},

{ t:"Sacred and Wisdom Literature of the World", s:"Scripture as literature",
  sec:[
  ["Reading scripture as literature",[
    "Sacred texts are central to religious life, and many are also literary masterpieces whose stories, poetry, and phrases shape cultures. Reading them as literature means attending to their forms, narratives, and imagery, while respecting their religious meaning to believers.",
    "Earlier chapters discussed the Hebrew Bible, the Vedas, the Bhagavad Gita, and the Analects."]],
  ["The New Testament and the Quran",[
    "The New Testament, written in Greek in the 1st century, includes four Gospels with distinctive styles, the parables of Jesus (the Prodigal Son, the Good Samaritan), the letters of Paul (including the hymn to love in 1 Corinthians 13: 'Love is patient, love is kind'), and the visionary Book of Revelation.",
    "The Quran, revealed in Arabic according to Muslim belief over about 23 years to the Prophet Muhammad, is organized in 114 suras (chapters), mostly arranged by length. Its rhymed prose (saj'), rhythm, and recitation are central to its power; Muslims consider its eloquence inimitable (i'jaz), and many hold that it can only be truly read in Arabic."]],
  ["Buddhist and Daoist texts",[
    "Buddhist literature includes the Pali Canon, the Dhammapada's verses, the Jataka tales of the Buddha's past lives, and Mahayana sutras such as the Lotus Sutra and the Heart Sutra ('form is emptiness, emptiness is form'). Zen literature includes koans, paradoxical questions such as 'What is the sound of one hand clapping?'",
    "The Daodejing and Zhuangzi combine philosophy with poetic imagery."]],
  ["Other traditions",[
    "The Guru Granth Sahib, Sikhism's scripture, is a collection of devotional hymns by Sikh Gurus and saints of other faiths, set to musical modes (ragas). The Avesta preserves Zoroastrian hymns (the Gathas). The Popol Vuh records Maya creation stories, preserved in K'iche' and Spanish in the 18th century.",
    "The Egyptian Book of the Dead, the Norse Eddas, and the Kojiki of Japan (712) record ancient sacred narratives."]],
  ["Wisdom literature",[
    "Wisdom literature, practical and philosophical sayings on how to live, appears across cultures: the Egyptian Instructions of Ptahhotep, biblical Proverbs and Ecclesiastes, the Tamil Tirukkural, Marcus Aurelius's Meditations, and proverbs worldwide.",
    "These texts have shaped ethics, law, and literature for millennia, and their imagery permeates secular writing."]]
  ],
  terms:[["Parable","Short story teaching a moral or spiritual lesson."],["Sura","Chapter of the Quran."],["Koan","Zen paradoxical question."],["Popol Vuh","Maya creation narrative."],["Wisdom literature","Sayings on how to live."]],
  w:"The world's sacred texts are among its greatest literature, shaping imagery and ideas across cultures.",
  src:["Religious text","Quran","Popol Vuh","Heart Sutra","Guru Granth Sahib"],
  q:[
  ["How many suras does the Quran contain?","114","66","150","99"],
  ["Which Buddhist text says 'form is emptiness'?","The Heart Sutra","The Dhammapada","The Lotus Sutra","The Jataka tales"],
  ["What is the Popol Vuh?","A Maya creation narrative","An Aztec calendar","An Inca law code","A Hindu epic"],
  ["What is a koan?","A Zen paradoxical question","A Sikh hymn","A Quranic verse","A Daoist poem"],
  ["Which New Testament passage says 'Love is patient, love is kind'?","1 Corinthians 13","Psalm 23","Revelation 21","John 3:16"],
  ["What is Sikhism's scripture?","Guru Granth Sahib","Avesta","Kojiki","Tirukkural"]]}

);


/* ---- from lit-26.js ---- */
/* LITERATURE FOUNDATIONS, part 26: Unit 11 The Life of Books, chapters 1-6 */
COURSES.literature.units.push({ t:"Reading, Writing, and the Life of Books", ch:[

{ t:"A History of the Book", s:"From clay to screens",
  sec:[
  ["Early writing surfaces",[
    "Writing has used many materials: clay tablets in Mesopotamia, papyrus scrolls in Egypt and the Greco-Roman world, bamboo and silk in ancient China, palm leaves in South and Southeast Asia, and parchment or vellum (prepared animal skin) in medieval Europe. The Great Library of Alexandria, founded in the 3rd century BCE, aimed to collect all Greek knowledge.",
    "The codex, pages bound along one edge, replaced the scroll in the Roman world between the 1st and 5th centuries CE, partly through Christian use; it allowed easy navigation and writing on both sides."]],
  ["Paper and printing in Asia",[
    "Paper was invented in China, traditionally credited to Cai Lun around 105 CE, and spread via the Islamic world, where Baghdad had paper mills by the 790s, to Europe by the 12th century. Woodblock printing developed in China; the Diamond Sutra (868 CE), found in a cave at Dunhuang, is the oldest dated printed book.",
    "Movable type was invented in China by Bi Sheng around 1040 using ceramic characters, and Korea printed the Jikji (1377) with metal movable type, before Gutenberg."]],
  ["Gutenberg and the print revolution",[
    "Johannes Gutenberg's press (about 1450) combined metal movable type, oil-based ink, and a screw press, making mass production of books possible in Europe; alphabetic scripts were well suited to movable type. Historian Elizabeth Eisenstein argued in The Printing Press as an Agent of Change (1979) that print transformed science, religion, and scholarship.",
    "Books printed before 1501 are called incunabula ('from the cradle')."]],
  ["Mass reading",[
    "The 19th century brought steam-powered presses, cheap paper from wood pulp, rising literacy, railway bookstalls, and serialized novels. Penguin Books' cheap paperbacks (1935), founded by Allen Lane, brought quality literature to mass audiences; American paperback publishing boomed after World War II.",
    "Public libraries, such as those funded by Andrew Carnegie (over 2,500 worldwide), expanded access to books."]],
  ["The digital age",[
    "E-books and e-readers (Amazon's Kindle launched in 2007), audiobooks, print-on-demand, and self-publishing have transformed the book's forms. Project Gutenberg (founded 1971) digitizes public-domain texts; Google Books scanned millions of volumes.",
    "Despite predictions of its death, the printed book has proved resilient, while reading habits continue to evolve with screens and social media."]]
  ],
  terms:[["Codex","Book with bound pages, replacing the scroll."],["Parchment","Prepared animal skin for writing."],["Incunabula","Books printed before 1501."],["Diamond Sutra","Oldest dated printed book, 868 CE."],["Movable type","Reusable individual characters for printing."]],
  w:"The history of the book shows how technologies of writing have shaped what and how we read.",
  src:["History of books","Codex","Diamond Sutra","Printing press","Penguin Books"],
  q:[
  ["What is the oldest dated printed book?","The Diamond Sutra (868 CE)","Gutenberg Bible","Jikji","Book of Kells"],
  ["Who invented movable type around 1040?","Bi Sheng","Cai Lun","Gutenberg","Sejong"],
  ["What are incunabula?","Books printed before 1501","Medieval manuscripts","Scrolls","E-books"],
  ["What replaced the scroll in the Roman world?","The codex","The tablet","Papyrus","Parchment rolls"],
  ["Who founded Penguin Books' cheap paperbacks in 1935?","Allen Lane","Andrew Carnegie","John Murray","Victor Gollancz"],
  ["Where was paper traditionally said to be invented around 105 CE?","China","Egypt","Baghdad","India"]]},

{ t:"Prizes, Publishing, and the Canon", s:"How books reach readers",
  sec:[
  ["How publishing works",[
    "Most books reach readers through publishers, who acquire manuscripts (often via literary agents), edit, design, print, market, and distribute them. The 'Big Five' English-language publishers are Penguin Random House, HarperCollins, Simon & Schuster, Hachette, and Macmillan; independent and small presses publish much innovative work.",
    "Authors typically receive an advance against royalties, a percentage of sales. Bestseller lists, such as the New York Times list (from 1931), shape visibility."]],
  ["The Nobel Prize",[
    "The Nobel Prize in Literature, established by Alfred Nobel's will and first awarded in 1901 (to French poet Sully Prudhomme), honors an author's body of work 'in an ideal direction.' The Swedish Academy chooses laureates. Famous omissions include Tolstoy, Ibsen, Chekhov, Joyce, Proust, Woolf, and Borges.",
    "Controversial choices include Bob Dylan (2016), the first songwriter. The prize was postponed in 2018 after a scandal at the Academy."]],
  ["Other major prizes",[
    "Major prizes include the Pulitzer Prize for Fiction and Poetry (US, from 1918 for novels), the National Book Award (US), the Booker Prize (UK, 1969), the International Booker Prize, France's Prix Goncourt (1903, worth only 10 euros but transformative for sales), Spain's Cervantes Prize, Germany's Georg Büchner Prize, Japan's Akutagawa Prize, and genre awards such as the Hugo, Nebula, and Edgar.",
    "Prizes raise sales and profiles but are criticized for biases, politics, and narrowing attention."]],
  ["Who makes the canon?",[
    "The canon is shaped by schools and universities, critics, anthologies (such as the Norton Anthologies), publishers' classic series, prizes, and readers over time. The 'culture wars' of the 1980s–90s debated whether to expand curricula beyond 'dead white men.'",
    "Many writers once neglected, Zora Neale Hurston, Kate Chopin, Herman Melville, have been 'canonized' later, while once-famous authors have faded."]],
  ["Readers' power",[
    "Readers shape literature through word of mouth, book clubs (Oprah's Book Club, from 1996, made many bestsellers), online reviews (Goodreads), and social media communities like BookTok. Independent bookstores and libraries remain vital curators.",
    "Literary festivals, such as the Hay Festival and Jaipur Literature Festival, bring authors and readers together."]]
  ],
  terms:[["Literary agent","Represents authors to publishers."],["Advance","Up-front payment against royalties."],["Royalties","Author's share of sales."],["Nobel Prize in Literature","Award for a body of work, since 1901."],["Prix Goncourt","Leading French literary prize."]],
  w:"Understanding publishing, prizes, and the canon explains which books we encounter and why.",
  src:["Publishing","Nobel Prize in Literature","Pulitzer Prize for Fiction","Prix Goncourt","Literary canon"],
  q:[
  ["Who won the first Nobel Prize in Literature in 1901?","Sully Prudhomme","Leo Tolstoy","Rudyard Kipling","Henrik Ibsen"],
  ["Which famous writer never won the Nobel Prize?","Leo Tolstoy","Thomas Mann","Hemingway","Faulkner"],
  ["What is the Prix Goncourt's cash value?","10 euros","1 million euros","100,000 euros","Nothing at all"],
  ["Which songwriter won the 2016 Nobel Prize?","Bob Dylan","Leonard Cohen","Paul Simon","Joni Mitchell"],
  ["What is an advance?","Up-front payment against royalties","A prize","A book review","A pre-order"],
  ["Which TV host's book club made many bestsellers from 1996?","Oprah Winfrey","Ellen DeGeneres","Jimmy Fallon","Reese Witherspoon"]]},

{ t:"Censorship and Banned Books", s:"The fight over what we may read",
  sec:[
  ["A long history",[
    "Censorship is as old as writing: Plato proposed censoring poets in his ideal Republic; the Chinese emperor Qin Shi Huang ordered the burning of books in 213 BCE; the Catholic Church's Index of Forbidden Books (1559–1966) banned works by Galileo, Descartes, and many novelists. Book burnings by the Nazis in 1933 targeted Jewish and 'un-German' authors; Heinrich Heine had written a century earlier, 'Where they burn books, they will in the end also burn people.'",
    "Censorship can be religious, political, or moral."]],
  ["Obscenity trials",[
    "Obscenity laws led to famous trials: Flaubert's Madame Bovary and Baudelaire's Les Fleurs du mal (1857); Joyce's Ulysses, cleared in the US in 1933; Allen Ginsberg's Howl (1957); and D. H. Lawrence's Lady Chatterley's Lover, whose 1960 acquittal in Britain, when the prosecutor asked jurors if it was a book 'you would wish your wife or your servants to read,' marked a cultural turning point.",
    "Radclyffe Hall's lesbian novel The Well of Loneliness was banned in Britain in 1928."]],
  ["Political censorship",[
    "Authoritarian states censor dissent: Soviet writers faced the Gulag; Ngũgĩ wa Thiong'o was imprisoned in Kenya; Iran's fatwa against Salman Rushdie in 1989 showed transnational threats; and contemporary governments ban books and jail writers. PEN International (founded 1921) defends persecuted writers.",
    "Writers have often used allegory, satire, and samizdat to evade censors."]],
  ["Challenges in schools and libraries",[
    "In democracies, censorship often takes the form of 'challenges' to remove books from schools and libraries. Frequently challenged books in the US include Huckleberry Finn, The Catcher in the Rye, To Kill a Mockingbird, Toni Morrison's The Bluest Eye, George M. Johnson's All Boys Aren't Blue, and Maia Kobabe's Gender Queer. The American Library Association reported record numbers of challenges in the early 2020s.",
    "Banned Books Week (since 1982) celebrates the freedom to read."]],
  ["Arguments and principles",[
    "Defenders of free expression, from Milton's Areopagitica to John Stuart Mill's On Liberty, argue that open debate serves truth and that readers should choose for themselves. Those seeking restrictions often cite protecting children, religious values, or preventing harm.",
    "Debates over age-appropriateness, hate speech, and representation continue, making censorship a living issue."]]
  ],
  terms:[["Censorship","Suppressing speech or writing."],["Index of Forbidden Books","Catholic list of banned works, 1559–1966."],["Obscenity trial","Legal case over sexual content."],["Book challenge","Attempt to remove a book from shelves."],["PEN International","Organization defending writers."]],
  w:"Censorship battles show how much power books are thought to hold, and why the freedom to read matters.",
  src:["Book censorship","Index Librorum Prohibitorum","Nazi book burnings","R v Penguin Books Ltd","Banned Books Week"],
  q:[
  ["Who wrote 'Where they burn books, they will in the end also burn people'?","Heinrich Heine","George Orwell","Ray Bradbury","John Milton"],
  ["When was the Catholic Index of Forbidden Books abolished?","1966","1789","1900","1517"],
  ["Which novel's 1960 British trial marked a cultural turning point?","Lady Chatterley's Lover","Ulysses","The Well of Loneliness","Lolita"],
  ["When did Banned Books Week begin?","1982","1933","1960","2001"],
  ["Which organization defends persecuted writers?","PEN International","UNESCO","Amnesty only","The Swedish Academy"],
  ["Which Chinese emperor ordered book burning in 213 BCE?","Qin Shi Huang","Han Wudi","Kublai Khan","Kangxi"]]},

{ t:"Literature on Screen and Stage", s:"Adaptation",
  sec:[
  ["Why adaptation",[
    "Many of the most famous films, plays, and TV series are adaptations of literature: The Godfather (Mario Puzo), Gone with the Wind, To Kill a Mockingbird, The Lord of the Rings, Harry Potter, Pride and Prejudice, The Handmaid's Tale, Game of Thrones, and countless Shakespeare and Dickens films.",
    "Adaptation theorist Linda Hutcheon described adaptation as 'repetition without replication,' a creative reinterpretation."]],
  ["Fidelity and transformation",[
    "Debates about adaptation often focus on 'fidelity': is the film faithful to the book? But film and literature work differently: novels can enter characters' minds directly and span long periods, while films use image, sound, performance, and time compression. Successful adaptations often transform their sources.",
    "Stanley Kubrick's The Shining departed so far from Stephen King's novel that King disliked it; Francis Ford Coppola's Apocalypse Now relocated Conrad's Heart of Darkness to the Vietnam War."]],
  ["Shakespeare on screen",[
    "Shakespeare is the most filmed author. Laurence Olivier's Henry V and Hamlet, Akira Kurosawa's Throne of Blood (Macbeth in feudal Japan) and Ran (King Lear), Franco Zeffirelli's Romeo and Juliet, Baz Luhrmann's Romeo + Juliet (1996), and modern updates like 10 Things I Hate About You (The Taming of the Shrew) show his adaptability.",
    "West Side Story and The Lion King draw on Romeo and Juliet and Hamlet."]],
  ["Musicals and opera",[
    "Literature inspires opera (Verdi's Otello and Falstaff, Bizet's Carmen from Mérimée, Britten's Billy Budd) and musicals: Les Misérables, The Phantom of the Opera, Cats, Wicked, and Hamilton (from Ron Chernow's biography).",
    "Theater adaptations, such as the stage versions of War Horse and The Curious Incident of the Dog in the Night-Time, bring novels to new audiences."]],
  ["Television and streaming",[
    "Long-form TV adaptations can do justice to big novels: BBC costume dramas (Pride and Prejudice, 1995), Normal People (2020), Shōgun, and Wolf Hall. Streaming platforms invest heavily in book adaptations, often boosting book sales dramatically.",
    "Adaptations can introduce readers to books and spark new interpretations; comparing book and adaptation is a rich way to understand both."]]
  ],
  terms:[["Adaptation","Reworking a story for another medium."],["Fidelity","Faithfulness to the source."],["Repetition without replication","Hutcheon's definition of adaptation."],["Throne of Blood","Kurosawa's Macbeth adaptation."],["Transposition","Moving a story to a new setting."]],
  w:"Adaptations show how stories transform across media, and comparing them reveals what each art form does best.",
  src:["Film adaptation","Linda Hutcheon","Shakespeare on screen","Throne of Blood","Apocalypse Now"],
  q:[
  ["How did Linda Hutcheon describe adaptation?","Repetition without replication","Faithful copying","Inferior imitation","Pure invention"],
  ["Which film relocated Heart of Darkness to the Vietnam War?","Apocalypse Now","Platoon","Full Metal Jacket","The Deer Hunter"],
  ["Which Kurosawa film adapts Macbeth?","Throne of Blood","Ran","Rashomon","Seven Samurai"],
  ["Which teen film updates The Taming of the Shrew?","10 Things I Hate About You","Clueless","She's the Man","Easy A"],
  ["Which musical is based on Ron Chernow's biography?","Hamilton","Les Misérables","Wicked","Cats"],
  ["Which author disliked Kubrick's adaptation of his novel?","Stephen King","Anthony Burgess","Vladimir Nabokov","Arthur C. Clarke"]]},

{ t:"How to Read a Poem", s:"Slow reading for big rewards",
  sec:[
  ["Read it aloud, more than once",[
    "Poems reward slow, repeated reading. Read the poem aloud to hear its sound and rhythm; then read it again, noticing what stands out. Poet Billy Collins's 'Introduction to Poetry' asks readers to 'hold it up to the light / like a color slide' rather than 'tie the poem to a chair with rope / and torture a confession out of it.'",
    "First impressions, puzzlement, delight, unease, are clues worth noting."]],
  ["Who is speaking, to whom, and where?",[
    "Identify the speaker (not necessarily the poet), the addressee, the situation, and the occasion. Is it a lament, a celebration, an argument, a description, a prayer? Notice changes: shifts in tone, a 'turn' (volta) in a sonnet, or a surprising final line.",
    "Ask what the poem's title adds."]],
  ["Look closely at language",[
    "Examine word choice (diction), images, figures of speech (metaphor, simile, personification), and repetition. Which words seem charged or ambiguous? Poets often exploit multiple meanings. Consider syntax: long, flowing sentences versus short, broken ones.",
    "Look up unfamiliar words and allusions; references to myths, the Bible, or history may unlock meaning."]],
  ["Notice form and sound",[
    "Consider the poem's form: Is it a sonnet, a villanelle, free verse? How long are its lines and stanzas? Where do line breaks fall, and what do they emphasize? Listen for meter, rhyme, alliteration, and assonance, and ask how sound reinforces sense, as when harsh consonants depict violence or long vowels slow the pace.",
    "Form often carries meaning: a poem about grief in a tightly controlled form may suggest an effort to contain emotion."]],
  ["Putting it together",[
    "After close attention, ask what the poem seems to be about, and how its parts work together to create meaning and feeling. Good interpretations account for details and acknowledge ambiguity. Comparing your reading with others' enriches understanding.",
    "Memorizing a favorite poem is a time-honored way to make it your own; poems carried in memory reveal new meanings over a lifetime."]]
  ],
  terms:[["Speaker","The voice in a poem, not necessarily the poet."],["Diction","Word choice."],["Volta","Turn in a poem's argument."],["Allusion","Reference to another text or event."],["Close reading","Careful attention to details."]],
  w:"Learning to read poems slowly unlocks one of literature's most concentrated pleasures.",
  src:["Poetry","Close reading","Billy Collins","Prosody (poetry)","Explication"],
  q:[
  ["Who should you identify as the 'speaker' of a poem?","The voice in the poem, not necessarily the poet","Always the poet","The reader","The publisher"],
  ["What is diction?","Word choice","Rhyme scheme","Meter","Stanza length"],
  ["Which poet urged readers not to 'torture a confession' out of a poem?","Billy Collins","Robert Frost","Mary Oliver","Seamus Heaney"],
  ["Why read a poem aloud?","To hear its sound and rhythm","To finish faster","Because it's required","To memorize rhymes only"],
  ["What is an allusion?","A reference to another text or event","A type of rhyme","A line break","An exaggeration"],
  ["What can a tightly controlled form in a grief poem suggest?","An effort to contain emotion","Lack of feeling","Comedy","Carelessness"]]},

{ t:"How to Read a Novel", s:"Attention, questions, and pleasure",
  sec:[
  ["Reading with attention",[
    "Novels can be read for pleasure, and attention deepens pleasure. Notice the opening pages carefully: they establish voice, setting, tone, and questions. Who is narrating, and how reliable are they? What is the narrative's relationship to time?",
    "Keeping brief notes on characters, key events, and striking passages helps with long or complex books."]],
  ["Questions to ask",[
    "Useful questions include: What does the protagonist want, and what stands in the way? How do characters change? What patterns recur, images, words, situations? How does the structure (chapters, sections, chronology) shape meaning? What is left unsaid?",
    "Consider the title, epigraph, and ending: endings often reframe everything that came before."]],
  ["Context",[
    "Knowing a novel's historical and cultural context, when and where it was written, for whom, and in response to what, can illuminate it. Yet great novels also speak beyond their time.",
    "Reading introductions, author interviews, or criticism after a first reading can deepen understanding without spoiling discovery."]],
  ["Difficult novels",[
    "Some novels, such as Ulysses, Moby-Dick, or One Hundred Years of Solitude, challenge readers with length, style, or structure. Strategies include reading in regular sessions, using guides, joining reading groups, listening to audiobooks alongside the text, and accepting that not everything must be understood at once.",
    "Rereading great novels at different stages of life often reveals new depths; Vladimir Nabokov said 'one cannot read a book: one can only reread it.'"]],
  ["Reading socially",[
    "Book clubs, classes, and online communities turn reading into conversation. Hearing others' interpretations exposes what we missed and challenges assumptions.",
    "Literature's meanings multiply through conversation across readers and generations."]]
  ],
  terms:[["Epigraph","Quotation at a book's beginning."],["Narrative structure","Arrangement of a story's parts."],["Context","Circumstances of a work's creation."],["Rereading","Returning to a work for new insight."],["Reading group","Group discussing books together."]],
  w:"A few habits of attention turn novel reading into deeper understanding and lasting pleasure.",
  src:["Novel","Reading","Book discussion club","Vladimir Nabokov","Literary analysis"],
  q:[
  ["Who said 'one cannot read a book: one can only reread it'?","Vladimir Nabokov","Virginia Woolf","Jorge Luis Borges","Harold Bloom"],
  ["What is an epigraph?","A quotation at a book's beginning","A final chapter","A table of contents","A blurb"],
  ["Which question helps analyze a protagonist?","What do they want, and what stands in their way?","What is their shoe size?","Who published the book?","How long is the book?"],
  ["What can endings often do?","Reframe everything that came before","Repeat the opening exactly","Introduce new characters only","Nothing important"],
  ["What is a good strategy for difficult novels?","Reading in regular sessions and accepting gradual understanding","Skipping to the end","Reading only summaries","Reading as fast as possible"],
  ["When might you read criticism to avoid spoiling discovery?","After a first reading","Before starting","Never","Only in school"]]}

]});


/* ---- from lit-27.js ---- */
/* LITERATURE FOUNDATIONS, part 27: Unit 11 chapters 7-12 */
COURSES.literature.units[10].ch.push(

{ t:"The Art of the Short Story", s:"Compression and revelation",
  sec:[
  ["What makes a short story",[
    "A short story can be read in one sitting and usually focuses on a single situation, a few characters, and a moment of change or revelation. Its compression demands that every detail count; endings may surprise, resolve, or simply stop, leaving resonance.",
    "Frank O'Connor's The Lonely Voice (1963) argued the form suits 'submerged population groups,' outsiders and the overlooked."]],
  ["Founders",[
    "Nikolai Gogol's 'The Overcoat,' Edgar Allan Poe's tales, and Nathaniel Hawthorne's allegories helped found the modern short story in the 1830s–40s. Guy de Maupassant perfected the tightly plotted story with a twist; O. Henry's 'The Gift of the Magi,' in which a poor couple each sell their treasure to buy the other a gift for it, became a classic.",
    "Anton Chekhov transformed the form with open-ended, understated stories of ordinary lives; 'The Lady with the Dog' ends with lovers realizing 'the most complicated and difficult part was only just beginning.'"]],
  ["Modern masters",[
    "James Joyce's Dubliners, Katherine Mansfield ('The Garden Party'), Ernest Hemingway ('Hills Like White Elephants,' a conversation in which the subject, an abortion, is never named), Jorge Luis Borges, Flannery O'Connor, John Cheever, Isaac Babel, and Ryūnosuke Akutagawa expanded the form's possibilities.",
    "Raymond Carver's minimalist stories of working-class lives (What We Talk About When We Talk About Love, 1981) were heavily cut by his editor Gordon Lish, a fact revealed later and still debated."]],
  ["Contemporary short fiction",[
    "Alice Munro (Nobel 2013) wrote stories that move across decades with the depth of novels. Lydia Davis writes stories sometimes only a sentence long. George Saunders's satirical stories (Tenth of December), Jhumpa Lahiri's Interpreter of Maladies (Pulitzer 2000), Edward P. Jones, and Chimamanda Ngozi Adichie show the form's vitality.",
    "Flash fiction (under about 1,000 words) and microfiction have flourished online. The six-word story 'For sale: baby shoes, never worn,' often attributed to Hemingway, is probably not his."]],
  ["Reading short stories",[
    "Short stories reward rereading: because they are compact, details, images, and the title often carry great weight. Look for the moment of change or epiphany, and what the story leaves unsaid.",
    "Many writers learn their craft in the short story, a form often called the most demanding in prose."]]
  ],
  terms:[["Short story","Brief fiction readable in one sitting."],["Twist ending","Surprising final reversal."],["Minimalism","Spare style leaving much unsaid."],["Flash fiction","Very short stories."],["Epiphany","Moment of sudden insight."]],
  w:"The short story's compression makes it one of literature's most powerful and demanding forms.",
  src:["Short story","The Gift of the Magi","Raymond Carver","Alice Munro","Flash fiction"],
  q:[
  ["Which O. Henry story features a couple who sell their treasures to buy each other gifts?","The Gift of the Magi","The Ransom of Red Chief","The Last Leaf","After Twenty Years"],
  ["Which Hemingway story never names its subject, an abortion?","Hills Like White Elephants","The Killers","Indian Camp","Big Two-Hearted River"],
  ["Whose stories were heavily cut by editor Gordon Lish?","Raymond Carver","John Cheever","Richard Ford","Tobias Wolff"],
  ["Which Chekhov story ends with lovers realizing the hard part is beginning?","The Lady with the Dog","The Bet","Gooseberries","Ward No. 6"],
  ["Who wrote Interpreter of Maladies?","Jhumpa Lahiri","Alice Munro","Lydia Davis","Edwidge Danticat"],
  ["What is flash fiction?","Very short stories, often under 1,000 words","Fast-paced novels","Comic strips","Poetry slams"]]},

{ t:"Song, Oral Poetry, and Performance", s:"Literature for the ear",
  sec:[
  ["Living oral traditions",[
    "Much of the world's literature has always been performed: epics sung by bards, ballads, work songs, lullabies, praise poetry, and sermons. Oral poets in Serbia, Kyrgyzstan (the Manas epic, among the longest in the world), West Africa, and India continue traditions of composing in performance.",
    "Walter Ong's Orality and Literacy (1982) explored how oral cultures think and remember differently from literate ones, through formulas, repetition, and rhythm."]],
  ["Ballads and folk song",[
    "English and Scottish ballads, collected by Francis James Child in the 19th century, tell stories of love, murder, and the supernatural ('Barbara Allen,' 'Sir Patrick Spens'). Ballads traveled to Appalachia and shaped American folk and country music.",
    "African American spirituals, work songs, and blues lyrics are major poetic traditions; the blues' AAB stanza form has influenced poets such as Langston Hughes."]],
  ["Song lyrics as poetry",[
    "Debates about whether song lyrics are literature intensified when Bob Dylan received the 2016 Nobel Prize 'for having created new poetic expressions within the great American song tradition.' Songwriters such as Leonard Cohen (also a published poet and novelist), Joni Mitchell, and Kendrick Lamar (Pulitzer Prize for Music, 2018) are often studied for their lyrics.",
    "Lyrics depend on music, voice, and performance, so they can seem diminished on the page, while some stand strongly alone."]],
  ["Hip-hop and spoken word",[
    "Hip-hop's rhyme schemes, wordplay, and storytelling have been compared to traditional poetry; scholars analyze rappers' internal rhymes and flow, and anthologies such as The Anthology of Rap (2010) present lyrics as literature. Lin-Manuel Miranda's Hamilton brought hip-hop verse to Broadway.",
    "Spoken word and slam poetry, which began in Chicago in the 1980s with Marc Smith's competitions, emphasize performance and audience response; poets such as Saul Williams and Kate Tempest (now Kae Tempest) bridge stage and page."]],
  ["Performance and literature",[
    "Public readings, from Dickens's tours to Dylan Thomas's recitations and today's literary festivals, show that literature lives in voices. Audiobooks and podcasts have revived listening as a primary way of experiencing stories.",
    "Recognizing literature's oral dimension reconnects reading with its oldest roots."]]
  ],
  terms:[["Oral tradition","Literature transmitted by voice."],["Ballad","Narrative folk song."],["Spoken word","Poetry written for performance."],["Slam poetry","Competitive performance poetry."],["Flow","Rhythm and delivery of rap lyrics."]],
  w:"Literature began as performance and remains alive in songs, ballads, rap, and spoken word.",
  src:["Oral tradition","Child Ballads","Spoken word","Poetry slam","Orality and Literacy"],
  q:[
  ["Which Kyrgyz epic is among the world's longest?","Manas","Sundiata","Shahnameh","Kalevala"],
  ["Who collected English and Scottish ballads in the 19th century?","Francis James Child","Cecil Sharp","Alan Lomax","Walter Scott"],
  ["Who wrote Orality and Literacy (1982)?","Walter Ong","Milman Parry","Albert Lord","Marshall McLuhan"],
  ["Where did slam poetry begin in the 1980s?","Chicago","New York","Los Angeles","London"],
  ["Which rapper won the Pulitzer Prize for Music in 2018?","Kendrick Lamar","Jay-Z","Kanye West","Lin-Manuel Miranda"],
  ["Why did Bob Dylan receive the Nobel Prize?","For new poetic expressions in the American song tradition","For his novels","For his paintings","For his memoir only"]]},

{ t:"Literature and the Law", s:"Trials, justice, and stories",
  sec:[
  ["Law in literature",[
    "Trials and justice have fascinated writers since Aeschylus's Oresteia, which ends with the founding of a court. Shakespeare's The Merchant of Venice turns on a contract and Portia's courtroom argument; Measure for Measure examines law, mercy, and hypocrisy.",
    "Dickens's Bleak House satirized the endless Court of Chancery; Dostoevsky's The Brothers Karamazov culminates in a murder trial; Kafka's The Trial depicts an incomprehensible legal system."]],
  ["Famous fictional trials",[
    "Harper Lee's To Kill a Mockingbird portrays Atticus Finch's defense of Tom Robinson; Camus's The Stranger shows Meursault condemned partly for his indifference; Richard Wright's Native Son includes a lengthy trial; Herman Melville's Billy Budd presents a naval court's agonizing duty.",
    "Courtroom drama is a popular genre in fiction and film, from Agatha Christie's Witness for the Prosecution to John Grisham's legal thrillers and Scott Turow's Presumed Innocent."]],
  ["The law and literature movement",[
    "The 'law and literature' movement, which grew in the 1970s–80s with scholars such as James Boyd White (The Legal Imagination) and Richard Posner, studies law in literature, law as literature (the interpretation, rhetoric, and narrative of legal texts), and law's regulation of literature (copyright, censorship, libel).",
    "Judges and lawyers interpret texts, constitutions and statutes, much as critics interpret literature; debates over textualism and intent mirror literary theory."]],
  ["Writing and rhetoric in law",[
    "Great legal writing has literary qualities: Lincoln's Gettysburg Address, Martin Luther King Jr.'s 'Letter from Birmingham Jail' (1963), and memorable judicial opinions. Justice Oliver Wendell Holmes Jr. and Justice Robert H. Jackson were celebrated stylists; Jackson's opinion in West Virginia v. Barnette (1943) declared that 'no official, high or petty, can prescribe what shall be orthodox.'",
    "Narrative matters in law: lawyers tell stories to juries, and how facts are framed shapes outcomes."]],
  ["Copyright and authors' rights",[
    "Copyright law emerged with the Statute of Anne (1710) in Britain, the first law granting authors rights over their works. The Berne Convention (1886), championed by Victor Hugo, established international copyright protection. Copyright terms, fair use, and public domain shape what can be quoted, adapted, and republished.",
    "Debates continue over copyright in the digital age, including the use of books to train artificial intelligence."]]
  ],
  terms:[["Law and literature","Field studying connections between law and literary texts."],["Courtroom drama","Fiction centered on trials."],["Statute of Anne","1710 British copyright law."],["Berne Convention","1886 international copyright treaty."],["Textualism","Interpreting law by its text."]],
  w:"Law and literature share concerns with language, interpretation, narrative, and justice.",
  src:["Law and literature","Legal drama","Statute of Anne","Berne Convention","Letter from Birmingham Jail"],
  q:[
  ["Which Greek trilogy ends with the founding of a court?","The Oresteia","The Theban Plays","The Trojan Women","The Bacchae"],
  ["Which Dickens novel satirizes the Court of Chancery?","Bleak House","Great Expectations","Oliver Twist","Little Dorrit"],
  ["What was the Statute of Anne (1710)?","The first copyright law granting authors rights","A censorship law","A law on libraries","A theater licensing law"],
  ["Who championed the Berne Convention?","Victor Hugo","Charles Dickens","Mark Twain","Émile Zola"],
  ["Which Supreme Court justice wrote that 'no official... can prescribe what shall be orthodox'?","Robert H. Jackson","Oliver Wendell Holmes Jr.","Earl Warren","Louis Brandeis"],
  ["Who wrote 'Letter from Birmingham Jail'?","Martin Luther King Jr.","Thurgood Marshall","James Baldwin","Malcolm X"]]},

{ t:"Writing About Literature", s:"From notes to essays",
  sec:[
  ["Start with questions",[
    "Good literary writing starts with genuine questions: Why does a character act this way? Why does the poem end with this image? What does a recurring symbol mean? Annotating while reading, underlining, writing in margins, keeping a reading journal, captures observations that become ideas.",
    "Freewriting and discussion help discover what you think."]],
  ["The thesis",[
    "A literary essay makes an argument, a thesis, that is interpretive and debatable, not merely a summary or obvious fact. 'Hamlet delays killing Claudius' is a fact; 'Hamlet's delay reflects the play's skepticism about certainty' is a thesis.",
    "A strong thesis is specific, focused, and supported by evidence from the text."]],
  ["Evidence and analysis",[
    "Support claims with quotations and details, then analyze them: explain how word choice, imagery, structure, or point of view supports the argument. A common pattern is to make a claim, present evidence, and analyze it, connecting back to the thesis.",
    "Avoid long plot summary; assume the reader knows the text, and focus on interpretation."]],
  ["Using criticism and context",[
    "Secondary sources, critics and historical context, can enrich an argument when used to support, extend, or challenge your interpretation, not replace it. Properly cite sources using styles such as MLA (common in literary studies) or Chicago, avoiding plagiarism.",
    "Engaging with counterarguments, acknowledging other readings and responding to them, strengthens an essay."]],
  ["Style and revision",[
    "Literary essays are written in the present tense when discussing texts ('Austen writes'). Clear, precise prose matters; vague praise ('beautiful,' 'powerful') should be replaced by specific description of effects.",
    "Revision is where good essays are made: rethink the argument, reorganize, cut repetition, and polish sentences. George Orwell's rules from 'Politics and the English Language,' such as 'Never use a long word where a short one will do,' remain useful."]]
  ],
  terms:[["Thesis","Arguable central claim of an essay."],["Annotation","Notes written while reading."],["Close analysis","Explaining how textual details create meaning."],["Literary present","Discussing texts in the present tense."],["MLA style","Citation format common in literary studies."]],
  w:"Writing about literature sharpens thinking and turns private reading into shared insight.",
  src:["Literary analysis","Thesis statement","MLA Handbook","Annotation","Politics and the English Language"],
  q:[
  ["What is a thesis in a literary essay?","An arguable interpretive claim","A plot summary","A list of quotations","A biography of the author"],
  ["Which tense is used to discuss literary texts?","Present tense","Past tense","Future tense","Any tense"],
  ["Which citation style is common in literary studies?","MLA","APA only","IEEE","Bluebook"],
  ["What should follow a quotation in an essay?","Analysis of how it supports the argument","Another quotation immediately","A new topic","Nothing"],
  ["Whose rule says 'Never use a long word where a short one will do'?","George Orwell","E. B. White","Samuel Johnson","Stephen King"],
  ["How can counterarguments help an essay?","By acknowledging and responding to other readings","By weakening it","By replacing the thesis","They should always be avoided"]]},

{ t:"Creative Writing: The Craft", s:"Learning from the inside",
  sec:[
  ["Reading like a writer",[
    "Writers learn by reading closely, noticing how others build scenes, voices, and structures; Francine Prose's Reading Like a Writer advocates this. Many great writers began by imitating models they admired.",
    "Daily practice matters: Anthony Trollope wrote a set number of words each morning before going to work at the Post Office."]],
  ["Fiction craft",[
    "Key elements of fiction craft include character (desires, contradictions, change), point of view, dialogue (which should reveal character and advance the story, often through subtext), scene versus summary, setting, and plot built on conflict and consequence.",
    "Advice such as 'show, don't tell' and 'write what you know' are useful guidelines, not absolute rules. Kurt Vonnegut's eight rules include 'Every character should want something, even if it is only a glass of water.'"]],
  ["Poetry craft",[
    "Poets work with images, sound, rhythm, line breaks, and form. Exercises include writing in fixed forms (sonnets, villanelles) to discover how constraints spark creativity, and close observation of the world.",
    "Mary Oliver's advice: 'Pay attention. Be astonished. Tell about it.'"]],
  ["Drafting and revision",[
    "Most writers draft quickly and revise extensively; Anne Lamott's Bird by Bird celebrates 'shitty first drafts' and taking things step by step. Hemingway said he rewrote the ending of A Farewell to Arms 39 times (and published editions later showed dozens of alternatives).",
    "Workshops, in which writers critique each other's drafts, became central to creative writing education after the Iowa Writers' Workshop (founded 1936) made creative writing an academic subject."]],
  ["The writing life",[
    "Writers face rejection, uncertainty, and long apprenticeships. Stephen King's On Writing combines memoir with practical advice, emphasizing reading a lot and writing a lot. Getting published typically involves submitting to literary magazines, finding an agent, or self-publishing.",
    "Writing for oneself, journals, letters, and personal essays, offers its own rewards of reflection and clarity."]]
  ],
  terms:[["Craft","Techniques of writing."],["Show, don't tell","Revealing through action and detail."],["Workshop","Group critique of drafts."],["Revision","Rethinking and rewriting a draft."],["Constraint","Formal limit sparking creativity."]],
  w:"Understanding the writer's craft deepens reading and opens the door to creating your own work.",
  src:["Creative writing","Iowa Writers' Workshop","Show, don't tell","On Writing: A Memoir of the Craft","Bird by Bird"],
  q:[
  ["Which writing program was founded in 1936?","Iowa Writers' Workshop","Bread Loaf","Clarion","Columbia MFA"],
  ["Who wrote Bird by Bird?","Anne Lamott","Stephen King","Natalie Goldberg","Francine Prose"],
  ["Whose rule says every character should want something, even a glass of water?","Kurt Vonnegut","Ernest Hemingway","Elmore Leonard","Ray Bradbury"],
  ["Who advised 'Pay attention. Be astonished. Tell about it.'?","Mary Oliver","Emily Dickinson","Rainer Maria Rilke","Billy Collins"],
  ["How many times did Hemingway say he rewrote A Farewell to Arms's ending?","39","3","100","12"],
  ["What does Stephen King's On Writing emphasize?","Reading a lot and writing a lot","Writing only when inspired","Avoiding revision","Writing only horror"]]},

{ t:"A Map of Literary Movements", s:"Putting it all together",
  sec:[
  ["Ancient to Renaissance",[
    "Literature's broad periods give a map for everything in these foundations. The ancient world produced epic (Gilgamesh, Homer, the Mahabharata), lyric, tragedy, and comedy, and the classics of China and India. Late antiquity and the Middle Ages brought Christian and Islamic literatures, sagas, romance, Dante, Chaucer, Arabic and Persian poetry, and the court literature of Heian Japan and Tang China.",
    "The Renaissance (about 1350–1650) revived classical learning and produced Petrarch, Montaigne, Cervantes, Shakespeare, and Spain's Golden Age."]],
  ["17th–18th centuries",[
    "The 17th century brought Metaphysical poetry, Milton, French classicism (Molière, Racine), and Restoration drama. The 18th-century Enlightenment and Neoclassicism produced satire (Swift, Pope, Voltaire), the rise of the novel (Defoe, Richardson, Fielding, Sterne), and Johnson's criticism.",
    "Sensibility and the Gothic pointed toward Romanticism."]],
  ["19th century",[
    "Romanticism (about 1790–1850) valued imagination, nature, and emotion (Wordsworth, Byron, Keats, Goethe, Pushkin, Hugo). Realism and naturalism (about 1830–1900) depicted society truthfully (Balzac, Flaubert, Dickens, George Eliot, Tolstoy, Zola, Twain). Victorian poetry, American Renaissance writers, Symbolism, and Aestheticism complicated the picture.",
    "Modern drama arose with Ibsen and Chekhov."]],
  ["20th century to now",[
    "Modernism (about 1900–1940) broke with tradition (Joyce, Woolf, Eliot, Kafka, Proust, Faulkner); the Harlem Renaissance gave African American literature new prominence. Postwar movements included existentialism and the absurd (Camus, Beckett), the Beats, confessional poetry, magical realism and the Latin American Boom, postcolonial literature, and postmodernism (Borges, Calvino, Pynchon).",
    "Contemporary literature is pluralistic and global, embracing autofiction, genre-blending, diverse voices, translation, and new media."]],
  ["Using the map",[
    "Periods and movements are useful generalizations, not rigid boxes: writers overlap, resist labels, and belong to several traditions. Different cultures have their own periodizations; 'Renaissance' and 'Romanticism' are largely European categories.",
    "Knowing the map helps place any work in context and see conversations across time."]]
  ],
  terms:[["Periodization","Dividing history into periods."],["Neoclassicism","18th-century classical ideals."],["Realism","19th-century truthful depiction."],["Modernism","Early 20th-century experiment."],["Postmodernism","Late 20th-century playfulness."]],
  w:"A map of literary movements ties together the foundations and places any work in context.",
  src:["Periodization","Literary movements","Romanticism","Modernist literature","Postmodern literature"],
  q:[
  ["Which movement valued imagination, nature, and emotion around 1800?","Romanticism","Realism","Neoclassicism","Modernism"],
  ["Which movement broke with tradition around 1900–1940?","Modernism","Romanticism","Neoclassicism","Naturalism"],
  ["Which writer belongs to 19th-century realism?","Gustave Flaubert","John Milton","Samuel Beckett","Petrarch"],
  ["Which movement produced the Latin American Boom's signature style?","Magical realism","Symbolism","Naturalism","Classicism"],
  ["When did the rise of the English novel occur?","The 18th century","The 14th century","The 20th century","Antiquity"],
  ["What caution applies to literary periods?","They are generalizations, not rigid boxes","They are exact and universal","They apply only to English","They never overlap"]]},

{ t:"A Lifelong Life of Reading", s:"Where the foundations lead",
  sec:[
  ["What you now know",[
    "These foundations have covered how literature works, poetry, narrative, drama, and criticism, and its history from Gilgamesh and Homer through the medieval world, the Renaissance, Romanticism, realism, modernism, and today, across many cultures and genres. Together they form the shared literacy of teachers, critics, writers, and serious readers.",
    "But literature is inexhaustible: each chapter opens onto entire libraries."]],
  ["Building a reading life",[
    "A rich reading life combines classics and contemporary books, familiar and unfamiliar cultures, fiction, poetry, drama, and nonfiction. Some readers follow lists or challenges; others follow curiosity from one book to another, guided by an author's influences or a period that fascinates them.",
    "Reading slowly and rereading great books, alongside reading widely, deepens understanding."]],
  ["Reading with others",[
    "Book clubs, classes, libraries, literary festivals, and online communities make reading social. Talking about books reveals what others see and sharpens your own interpretations.",
    "Supporting libraries, independent bookstores, and translated literature helps sustain literary culture."]],
  ["Why literature matters",[
    "Literature lets us inhabit other minds, times, and places; it preserves memory, challenges power, comforts in grief, and delights with language. As Franz Kafka wrote in a letter, 'A book must be the axe for the frozen sea within us.'",
    "Reading also trains attention, an increasingly precious skill in a world of distraction."]],
  ["Next steps",[
    "The specialized branches of this subject build on these foundations, with deeper study of particular periods, authors, genres, and national literatures. The books you bring will make those paths your own.",
    "As the Roman poet Horace advised, literature should both delight and instruct; may your reading do both for a lifetime."]]
  ],
  terms:[["Reading life","Lifelong habit of reading widely and deeply."],["Rereading","Returning to works for new insight."],["Book club","Group discussing books together."],["Literacy","Ability to read and understand texts deeply."],["Branch","Specialized path building on the foundations."]],
  w:"Literature is a lifelong companion; these foundations prepare you to read widely, deeply, and with joy.",
  src:["Reading","Literature","Book discussion club","Franz Kafka","Horace"],
  q:[
  ["Who wrote 'A book must be the axe for the frozen sea within us'?","Franz Kafka","Virginia Woolf","Jorge Luis Borges","Leo Tolstoy"],
  ["Which Roman poet said literature should delight and instruct?","Horace","Virgil","Ovid","Catullus"],
  ["What does a rich reading life combine?","Classics and contemporary books from many cultures","Only bestsellers","Only one genre","Only classics"],
  ["What skill does reading train that is precious in a distracted world?","Attention","Speed only","Memorization of dates","Typing"],
  ["What do the branches ahead offer?","Deeper study of periods, authors, and genres","A repeat of the foundations","Only quizzes","Nothing new"],
  ["Which helps sustain literary culture?","Supporting libraries and independent bookstores","Ignoring translations","Reading only alone","Avoiding new books"]]}

);


/* ---- from lit-28.js ---- */
/* LITERATURE FOUNDATIONS, part 28: extra chapters spliced across units */
(function(){
const U=COURSES.literature.units;
const after=(u,title,ch)=>{const a=U[u].ch;const i=a.findIndex(c=>c.t===title);a.splice(i+1,0,ch);};
const before=(u,title,ch)=>{const a=U[u].ch;const i=a.findIndex(c=>c.t===title);a.splice(i,0,ch);};

after(0,"Figurative Language and Style",
{ t:"Allusion, Intertextuality, and Influence", s:"Books talking to books",
  sec:[
  ["Allusion",[
    "An allusion is a brief reference to another text, person, event, or myth that the writer expects readers to recognize. Calling someone 'a Good Samaritan,' 'a Romeo,' or describing 'an Achilles' heel' are everyday allusions. T. S. Eliot's The Waste Land is dense with allusions to Dante, Shakespeare, the Bible, and Eastern scriptures.",
    "Recognizing allusions adds layers of meaning; missing them can leave puzzles. Annotated editions and footnotes help readers trace them."]],
  ["Intertextuality",[
    "The critic Julia Kristeva coined 'intertextuality' (1966) to describe how every text is woven from other texts, a 'mosaic of quotations.' Works respond to, imitate, parody, and transform earlier works: Joyce's Ulysses rewrites the Odyssey; Jean Rhys's Wide Sargasso Sea answers Jane Eyre; Tom Stoppard's Rosencrantz and Guildenstern Are Dead reimagines Hamlet from two minor characters' view.",
    "Parody imitates for comic or critical effect; pastiche imitates affectionately; homage pays tribute."]],
  ["Influence",[
    "Harold Bloom's The Anxiety of Influence (1973) argued that strong poets struggle against their great predecessors, 'misreading' them to create space for originality. T. S. Eliot instead stressed tradition as a living order that new works enter and subtly change.",
    "Influence crosses cultures: Persian poetry shaped Goethe; Japanese haiku shaped the Imagists; Faulkner influenced García Márquez, who influenced Rushdie and Morrison."]],
  ["Retellings and fan fiction",[
    "Retellings are among literature's oldest practices: Virgil reworked Homer, Shakespeare borrowed nearly all his plots, and contemporary novelists retell myths and classics. Fan fiction, in which readers write new stories with existing characters, is a vast modern form; E. L. James's Fifty Shades of Grey began as Twilight fan fiction.",
    "Questions of originality, borrowing, and plagiarism depend on how transformatively sources are used."]],
  ["Reading intertextually",[
    "Reading intertextually means asking: What earlier works does this text echo or answer? How does it change them? What would the original audience have recognized?",
    "The more one reads, the richer each new book becomes, as echoes multiply."]]
  ],
  terms:[["Allusion","Brief reference to another text or event."],["Intertextuality","Kristeva's term for texts woven from other texts."],["Parody","Mocking imitation."],["Anxiety of influence","Bloom's theory of poets' struggle with predecessors."],["Retelling","New version of an existing story."]],
  w:"Seeing how books talk to each other turns reading into an ever-expanding conversation.",
  src:["Allusion","Intertextuality","The Anxiety of Influence","Parody","Fan fiction"],
  q:[
  ["Who coined the term 'intertextuality'?","Julia Kristeva","Harold Bloom","Roland Barthes","Mikhail Bakhtin"],
  ["Which play reimagines Hamlet from two minor characters' view?","Rosencrantz and Guildenstern Are Dead","Waiting for Godot","Arcadia","The Real Inspector Hound"],
  ["Who wrote The Anxiety of Influence?","Harold Bloom","T. S. Eliot","Northrop Frye","Edward Said"],
  ["Which bestseller began as Twilight fan fiction?","Fifty Shades of Grey","The Hunger Games","Divergent","After"],
  ["What is an allusion?","A brief reference to another text, person, or event","A long quotation","A type of rhyme","A plot twist"],
  ["What does pastiche mean?","Affectionate imitation of a style","Harsh mockery","Plagiarism","Translation"]]});

after(5,"Victorian Poetry",
{ t:"Gaskell, Trollope, and the Victorian Novel's Range", s:"Industry, clergy, and sensation",
  sec:[
  ["The 'Condition of England'",[
    "Industrialization prompted 'condition of England' novels addressing poverty and class conflict. Elizabeth Gaskell (1810–1865), a Manchester minister's wife, wrote Mary Barton (1848) about factory workers' suffering and North and South (1855), contrasting the industrial North with the genteel South through the romance of Margaret Hale and the mill-owner John Thornton.",
    "Benjamin Disraeli, later prime minister, coined the idea of 'two nations,' the rich and the poor, in his novel Sybil (1845). Gaskell also wrote Cranford, a gentle comedy of village women, and a biography of her friend Charlotte Brontë."]],
  ["Anthony Trollope",[
    "Anthony Trollope (1815–1882), a Post Office official who invented the pillar box in Britain, wrote 47 novels, famously producing a set number of words before breakfast. His Chronicles of Barsetshire (including The Warden and Barchester Towers) satirize cathedral clergy, while his Palliser novels explore Parliament and politics.",
    "His autobiography's revelation of his businesslike writing habits damaged his reputation for a time, but his psychological realism has since been widely admired."]],
  ["Sensation fiction",[
    "The 1860s 'sensation novel' combined domestic settings with crime, bigamy, madness, and secrets: Wilkie Collins's The Woman in White (1859–60), Mary Elizabeth Braddon's Lady Audley's Secret, and Ellen Wood's East Lynne were bestsellers. Collins's The Moonstone pioneered detective fiction.",
    "Sensation fiction anticipated thrillers and fascinated critics with its depictions of women's transgressions."]],
  ["Thackeray and others",[
    "William Makepeace Thackeray's Vanity Fair (1847–48), subtitled 'A Novel without a Hero,' follows the ruthless, charming Becky Sharp climbing society during the Napoleonic era. George Meredith, Charles Kingsley, and Lewis Carroll added to the era's variety.",
    "Late Victorian novelists such as George Gissing (New Grub Street, about struggling writers) depicted the commercial pressures of literary life."]],
  ["The Victorian achievement",[
    "The Victorian novel, often serialized and read aloud in families, was the dominant entertainment of its age and tackled religion, science, class, gender, and empire. Its 'three-decker' format (three volumes) was driven by circulating libraries such as Mudie's.",
    "Its breadth of social observation remains a model for novelists depicting whole societies."]]
  ],
  terms:[["Condition of England novel","Victorian fiction on social problems."],["Two nations","Disraeli's phrase for rich and poor."],["Sensation novel","1860s fiction of crime and secrets."],["Three-decker","Victorian three-volume novel."],["Barsetshire","Trollope's fictional cathedral county."]],
  w:"The Victorian novel's range, from industrial realism to sensation, captured a whole society in transformation.",
  src:["Elizabeth Gaskell","Anthony Trollope","Sensation novel","Vanity Fair (novel)","The Woman in White (novel)"],
  q:[
  ["Who wrote North and South?","Elizabeth Gaskell","George Eliot","Charlotte Brontë","Anthony Trollope"],
  ["Which Trollope series satirizes cathedral clergy?","Chronicles of Barsetshire","Palliser novels","Pickwick Papers","Cranford"],
  ["Who coined the idea of 'two nations' in a novel?","Benjamin Disraeli","Charles Dickens","Thomas Carlyle","Elizabeth Gaskell"],
  ["Which novel is subtitled 'A Novel without a Hero'?","Vanity Fair","Middlemarch","Bleak House","Barchester Towers"],
  ["Who wrote The Woman in White?","Wilkie Collins","Mary Elizabeth Braddon","Ellen Wood","Sheridan Le Fanu"],
  ["What did Trollope invent in Britain while at the Post Office?","The pillar box","The postage stamp","The telegram","The postcard"]]});

before(10,"Writing About Literature",
{ t:"Literature, Mind, and Empathy", s:"What reading does to us",
  sec:[
  ["Theory of mind",[
    "Reading fiction requires imagining characters' thoughts, beliefs, and feelings, a capacity psychologists call 'theory of mind.' Literary scholar Lisa Zunshine, in Why We Read Fiction (2006), argued that fiction exercises this capacity, tracking layers like 'she knows that he thinks that she wants.'",
    "A 2013 study in Science by David Kidd and Emanuele Castano reported that reading literary fiction briefly improved performance on theory-of-mind tests; later replication attempts produced mixed results, a reminder that such findings are still debated."]],
  ["Empathy and moral imagination",[
    "Writers and philosophers have long claimed literature expands moral sympathy: George Eliot said art enlarges 'men's sympathies'; philosopher Martha Nussbaum argued novels cultivate the 'moral imagination' needed for justice. Historian Lynn Hunt suggested that 18th-century epistolary novels helped spread the idea of human rights by encouraging readers to identify with others.",
    "Skeptics note that empathy for fictional characters does not always translate into action, and that cruel people can also be avid readers."]],
  ["Reading and the brain",[
    "Neuroscience shows that reading is a recent cultural invention that repurposes brain regions for vision and language; Maryanne Wolf's Proust and the Squid explains how the 'reading brain' develops. Brain imaging suggests that reading vivid descriptions activates regions involved in sensory and motor experience.",
    "Wolf has warned that habitual skimming on screens may erode 'deep reading,' sustained attention to complex texts."]],
  ["Bibliotherapy and wellbeing",[
    "Bibliotherapy, using reading to support mental health, ranges from self-help books prescribed by doctors to shared reading groups. Programs such as The Reader in Britain bring people together to read literature aloud.",
    "Many readers report that books provide comfort, perspective, and companionship during difficult times, echoing Aristotle's idea of catharsis."]],
  ["Why it matters",[
    "Whether or not reading makes us better people, it gives access to experiences, voices, and ideas beyond our own lives. The pleasure of absorption in a story, called 'transportation' by psychologists, is itself a profound human good.",
    "Understanding these debates helps readers reflect on why literature matters to them."]]
  ],
  terms:[["Theory of mind","Understanding others' mental states."],["Moral imagination","Imagining others' lives to reason ethically."],["Deep reading","Sustained attention to complex texts."],["Bibliotherapy","Using reading to support wellbeing."],["Transportation","Absorption into a narrative."]],
  w:"Research and philosophy explore how reading shapes minds, empathy, and wellbeing, and why it matters.",
  src:["Theory of mind","Bibliotherapy","Martha Nussbaum","Maryanne Wolf","Narrative transportation"],
  q:[
  ["What is theory of mind?","Understanding others' mental states","A literary theory","Memorizing texts","A reading speed"],
  ["Who argued novels cultivate 'moral imagination'?","Martha Nussbaum","Lisa Zunshine","Maryanne Wolf","Lynn Hunt"],
  ["Who wrote Proust and the Squid about the reading brain?","Maryanne Wolf","Steven Pinker","Oliver Sacks","Daniel Kahneman"],
  ["What did later attempts to replicate the 2013 fiction-empathy study show?","Mixed results","Exact confirmation","That fiction harms empathy","No attempts were made"],
  ["Which historian linked epistolary novels to human rights ideas?","Lynn Hunt","Ian Watt","Eric Hobsbawm","Simon Schama"],
  ["What is bibliotherapy?","Using reading to support mental health","Repairing books","Library science","Book collecting"]]});

before(10,"Writing About Literature",
{ t:"Literature and Science", s:"Two cultures in conversation",
  sec:[
  ["Two cultures?",[
    "In 1959, scientist and novelist C. P. Snow lamented in his lecture 'The Two Cultures' that literary intellectuals and scientists no longer understood each other. Yet literature and science have long been intertwined.",
    "Lucretius's On the Nature of Things set atomic theory in verse; Dante's Paradiso followed medieval astronomy; and poets such as John Donne responded to the new astronomy of Copernicus and Galileo ('And new philosophy calls all in doubt')."]],
  ["Science in literature",[
    "Novelists have engaged science directly: Mary Shelley's Frankenstein (galvanism and creation), George Eliot's Middlemarch (medicine and the physician Lydgate), Thomas Hardy's interest in Darwinian evolution, H. G. Wells's science fiction, and Thomas Mann's The Magic Mountain (medicine and tuberculosis).",
    "Contemporary 'lab lit' and novels such as Ian McEwan's Saturday (a neurosurgeon's day), Richard Powers's The Overstory (trees and ecology), and Barbara Kingsolver's Flight Behavior (climate change) bring science into fiction."]],
  ["Darwin and literature",[
    "Charles Darwin's On the Origin of Species (1859) transformed Victorian literature, challenging religious certainties (as in Tennyson's 'Nature, red in tooth and claw,' written before Darwin, and Hardy's bleak cosmos). Critic Gillian Beer's Darwin's Plots (1983) showed how Darwin himself drew on literary narrative and how novelists absorbed evolutionary ideas.",
    "Darwin was a great prose writer; the final sentence of the Origin ('There is grandeur in this view of life') is often quoted."]],
  ["Scientists as writers",[
    "Many scientists are fine writers: Galileo's dialogues, Darwin's Voyage of the Beagle, Rachel Carson's Silent Spring, Carl Sagan's Cosmos, Oliver Sacks's case histories (The Man Who Mistook His Wife for a Hat), Stephen Jay Gould's essays, and Primo Levi's The Periodic Table, which ties each chapter to a chemical element.",
    "Popular science writing has become a major literary genre."]],
  ["Medicine and literature",[
    "Medicine has been a rich subject and source of writers: physicians such as Anton Chekhov, Arthur Conan Doyle, William Carlos Williams, and Mikhail Bulgakov wrote literature. The field of 'medical humanities' or 'narrative medicine,' developed by Rita Charon, uses literature to train doctors to listen to patients' stories.",
    "Illness narratives, such as Susan Sontag's Illness as Metaphor, examine how cultures interpret disease."]]
  ],
  terms:[["Two Cultures","Snow's lecture on the gap between sciences and humanities."],["Lab lit","Fiction about scientists and science."],["Darwin's Plots","Gillian Beer's study of evolution and literature."],["Narrative medicine","Using stories in medical practice."],["Popular science","Science writing for general readers."]],
  w:"Literature and science illuminate each other, from atomic poems to novels of climate change.",
  src:["The Two Cultures","Darwin's Plots","Narrative medicine","The Periodic Table (Levi book)","Literature and science"],
  q:[
  ["Who gave the 1959 lecture 'The Two Cultures'?","C. P. Snow","Aldous Huxley","F. R. Leavis","Carl Sagan"],
  ["Which Primo Levi book ties chapters to chemical elements?","The Periodic Table","If This Is a Man","The Drowned and the Saved","The Truce"],
  ["Who wrote Darwin's Plots?","Gillian Beer","Rachel Carson","Susan Sontag","Rita Charon"],
  ["Who developed 'narrative medicine'?","Rita Charon","Oliver Sacks","Atul Gawande","William Carlos Williams"],
  ["Which Roman poem set atomic theory in verse?","Lucretius's On the Nature of Things","Virgil's Georgics","Ovid's Metamorphoses","Horace's Odes"],
  ["Which doctor-writer wrote The Man Who Mistook His Wife for a Hat?","Oliver Sacks","Anton Chekhov","Atul Gawande","Siddhartha Mukherjee"]]});

})();
