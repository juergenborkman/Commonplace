/* ---- from cuisine-01.js ---- */
/* CUISINE FOUNDATIONS, part 1: Unit 1 How Cooking Works, chapters 1-5 */
COURSES.cuisine = { units: [] };
COURSES.cuisine.units.push({ t:"How Cooking Works", ch:[

{ t:"What Is Cuisine?", s:"Cooking, culture, and why humans cook",
  sec:[
  ["The cooking animal",[
    "Humans are the only species that cooks its food. The primatologist Richard Wrangham, in 'Catching Fire: How Cooking Made Us Human' (2009), argued that cooking shaped our evolution. Cooked food is softer and more digestible, releasing more energy from the same food. This may have allowed early humans to develop smaller guts and teeth and larger brains, and to spend less time chewing; chimpanzees spend around five to six hours a day chewing.",
    "When humans first controlled fire is debated. There is good evidence of fire use at sites such as Wonderwerk Cave in South Africa, about a million years ago, and widespread evidence of hearths from around 400,000 years ago. Whenever it began, cooking became universal: no known human society lives on raw food alone."]],
  ["Cooking versus cuisine",[
    "Cooking is the application of heat and other processes to make food edible, safe, and tasty. Cuisine is something larger: a style of cooking and eating shared by a group of people, with characteristic ingredients, techniques, flavor combinations, dishes, and rules about when, how, and with whom to eat. 'Cuisine' comes from the French word for kitchen.",
    "The food writer Elisabeth Rozin proposed that cuisines can be recognized by their 'flavor principles', characteristic combinations of seasonings: soy sauce, rice wine, and ginger in much Chinese cooking; olive oil, garlic, and tomato in parts of the Mediterranean; chili, lime, and cilantro in parts of Mexico. Such combinations make a dish taste like it belongs to a place."]],
  ["What shapes a cuisine",[
    "Cuisines grow from geography and climate, which determine what can be grown, raised, caught, and stored. Rice dominates monsoon Asia; wheat the Mediterranean and northern China; maize Mesoamerica; potatoes the Andes. Coastal peoples eat more fish; cold climates encourage preserved foods and fats; hot climates encourage spices and quick cooking.",
    "History adds layers: trade, migration, conquest, religion, and technology. Chilies, now essential in India, Thailand, and Sichuan, came from the Americas only after 1492. Religious rules, such as halal and kosher laws, Hindu vegetarianism, and Christian fasting days, shape what people eat. Social class matters too: many famous 'peasant dishes', like cassoulet or ramen, began as ways to stretch cheap ingredients."]],
  ["Food as identity",[
    "Food is one of the strongest markers of identity. Immigrants often keep their food traditions long after they have changed language or dress, and dishes become symbols of nations, regions, and families. The French gastronome Jean Anthelme Brillat-Savarin wrote in 'The Physiology of Taste' (1825): 'Tell me what you eat, and I will tell you what you are.'",
    "UNESCO now recognizes food traditions as intangible cultural heritage, including the gastronomic meal of the French and traditional Mexican cuisine (both 2010), the Mediterranean diet (2010, extended 2013), washoku in Japan (2013), and kimjang, Korean kimchi-making, (2013). These listings emphasize not just recipes but the social practices around food."]],
  ["Haute cuisine and home cooking",[
    "Sociologists such as Jack Goody have noted that some societies, like France, China, and India, developed distinct 'high' cuisines for elites alongside everyday home cooking, while others did not. Haute cuisine ('high cooking') refers to the elaborate, refined cooking of professional chefs in palaces and fine restaurants.",
    "Yet most of the world's great food has always come from home kitchens, markets, and street stalls, made mostly by women, often unrecorded. Many celebrated restaurant dishes are refinements of home cooking. A complete understanding of cuisine includes both."]],
  ["How to study food",[
    "This course studies cuisine from several angles: the science of how cooking works; the main ingredients and techniques; the history of food; the world's major cuisines; drinks; and the professional world of restaurants and chefs. Together they form the foundation a serious cook, food writer, or food lover needs.",
    "The best way to learn food is to taste attentively, cook often, and ask why: why a recipe uses a certain technique, why a combination works, and where a dish came from. Good cooks combine knowledge with practice, and both improve with every meal."]]
  ],
  terms:[["Cuisine","A characteristic style of cooking and eating shared by a group."],["Flavor principle","A characteristic combination of seasonings that identifies a cuisine."],["Haute cuisine","Elaborate, refined cooking of professional chefs."],["Gastronomy","The study of food, cooking, and eating, and their culture."],["Intangible cultural heritage","Traditions and practices, such as food customs, recognized by UNESCO."]],
  w:"Understanding what shapes a cuisine helps you understand both how to cook it and why people care so much about it.",
  src:["Cuisine","Catching Fire: How Cooking Made Us Human","Control of fire by early humans","Jean Anthelme Brillat-Savarin","Gastronomy"],
  q:[["Who argued that cooking shaped human evolution in 'Catching Fire'?","Richard Wrangham","Jack Goody","Elisabeth Rozin","Michael Pollan"],
     ["What is a 'flavor principle'?","A characteristic combination of seasonings identifying a cuisine","A law of chemistry","A rule of table manners","A cooking temperature"],
     ["Chilies arrived in India and Thailand…","From the Americas after 1492","From ancient Egypt","From Japan","They are native to India"],
     ["Who wrote 'Tell me what you eat, and I will tell you what you are'?","Brillat-Savarin","Escoffier","Carême","Julia Child"],
     ["Which food tradition did UNESCO inscribe in 2013?","Washoku (Japanese cuisine)","Pizza delivery","American barbecue","British fish and chips"],
     ["What does 'haute cuisine' mean?","High, refined cooking of professional chefs","Food cooked at high altitude","Very spicy food","Fast food"]]},

{ t:"Taste, Smell, and Flavor", s:"How we perceive food",
  sec:[
  ["The five basic tastes",[
    "The tongue detects five widely accepted basic tastes: sweet (sugars, signaling energy), salty (sodium, essential for body function), sour (acids, which can indicate ripeness or spoilage), bitter (often a warning of toxins, though many people learn to love bitter foods like coffee and dark greens), and umami (savory, from glutamate and certain nucleotides, signaling protein).",
    "Umami was identified in 1908 by the Japanese chemist Kikunae Ikeda, who isolated glutamate from kombu seaweed broth (dashi). It was long ignored in the West but was confirmed when taste receptors for glutamate were identified around 2000. Foods rich in umami include aged cheese, tomatoes, mushrooms, soy sauce, fish sauce, anchovies, and cured meats. Researchers continue to study possible additional tastes, such as a taste for fat."]],
  ["The tongue map myth",[
    "Many people learned that different parts of the tongue detect different tastes, with sweet at the tip and bitter at the back. This 'tongue map' is a myth, based on a misreading of a 1901 German paper by David Hänig. In fact, all areas of the tongue that have taste buds can detect all five tastes, with only slight differences in sensitivity.",
    "Humans have several thousand taste buds, mostly on the tongue but also on the palate and throat, and they are replaced about every one to two weeks. Sensitivity varies between people; 'supertasters', a term coined by Linda Bartoshuk, have more taste papillae and experience bitterness more intensely."]],
  ["Smell: the real source of flavor",[
    "Most of what we call 'taste' is actually smell. When we chew, aroma molecules travel from the back of the mouth up to the nose, called retronasal smell. That is why food tastes bland when you have a cold, and why a pinched nose makes it hard to tell an apple from a raw potato.",
    "Humans have around 400 types of functional smell receptors and can distinguish a very large number of odors. Aroma is what distinguishes strawberry from raspberry, or rosemary from thyme. Cooks build flavor largely by building aroma: toasting spices, browning meat, and adding herbs at the end so their volatile aromas are not lost."]],
  ["Mouthfeel, temperature, and pungency",[
    "Flavor also includes texture (crisp, creamy, chewy, tender), temperature, and chemical sensations. The burning of chilies comes from capsaicin, which activates the body's heat-sensing receptor (TRPV1); mint's coolness comes from menthol activating cold receptors. Sichuan pepper produces a tingling, numbing sensation (ma), while astringency, the drying feeling from tannins in tea and red wine, is a sensation of touch.",
    "Chili heat is measured on the Scoville scale, developed by pharmacist Wilbur Scoville in 1912. Bell peppers score zero; jalapeños a few thousand units; habaneros hundreds of thousands; and the hottest cultivated peppers well over a million."]],
  ["Flavor is in the brain",[
    "Flavor is constructed by the brain from taste, smell, touch, sight, sound, and expectation. Experiments show that coloring white wine red can lead tasters to describe red-wine aromas, and that the sound of crunching affects how fresh chips seem. Hunger, memory, culture, and context all change how food tastes.",
    "We also adapt: the first sip of something tastes strongest, and we stop noticing a smell after a while. This is why chefs taste repeatedly, cleanse their palates, and think about contrast and variety across a meal."]],
  ["Using this as a cook",[
    "Understanding taste helps you fix dishes. If a dish tastes flat, it may need salt, which enhances other flavors and suppresses bitterness. If it is heavy or dull, acid (lemon, vinegar) brightens it. Sweetness balances acidity and bitterness; umami adds depth and satisfaction; bitterness adds complexity.",
    "Great dishes often balance several tastes and contrast textures and temperatures: crisp with soft, rich with sharp, hot with cool. Thai cuisine famously balances sweet, sour, salty, and spicy in a single dish. Learning to taste analytically, asking 'what does this need?', is the most important skill a cook can develop."]]
  ],
  terms:[["Umami","The savory taste of glutamates, identified by Kikunae Ikeda in 1908."],["Retronasal smell","Smelling aromas from food in the mouth via the back of the throat."],["Capsaicin","The compound that makes chili peppers hot."],["Scoville scale","A measure of chili pepper heat."],["Astringency","A drying, puckering sensation caused by tannins."],["Supertaster","A person with heightened taste sensitivity."]],
  w:"Knowing how taste and smell work turns seasoning from guesswork into a skill.",
  src:["Taste","Umami","Tongue map","Olfaction","Capsaicin","Scoville scale"],
  q:[["Who identified umami in 1908?","Kikunae Ikeda","Wilbur Scoville","Linda Bartoshuk","Auguste Escoffier"],
     ["Is the 'tongue map' accurate?","No; all taste areas detect all five tastes","Yes; each zone detects one taste","Only for sweet and bitter","Only in children"],
     ["Why does food taste bland when you have a cold?","Retronasal smell is blocked","Taste buds die","Saliva stops","Food loses salt"],
     ["What makes chilies hot?","Capsaicin","Menthol","Glutamate","Tannin"],
     ["Astringency, as in strong tea, is caused by…","Tannins","Sugar","Salt","Starch"],
     ["If a dish tastes flat and dull, a good first fix is…","Adding salt or acid","Adding water","Cooking it longer","Serving it colder"]]},

{ t:"Heat and Cooking Methods", s:"Conduction, convection, radiation, and the main techniques",
  sec:[
  ["How heat moves",[
    "Cooking is controlled heat transfer. Heat moves in three ways. Conduction passes heat through direct contact, as from a hot pan into a steak or from the outside of a potato to its center. Convection carries heat by moving fluids, air or liquid, as in boiling water, deep-frying oil, or a fan oven. Radiation transfers heat as infrared energy, as from glowing coals, a broiler, or a toaster.",
    "Most cooking combines these. In an oven, hot air convects heat to the food, the walls radiate heat, and the pan conducts heat to the base. Microwaves work differently, causing water molecules in food to vibrate and produce heat directly, which is why microwaved food rarely browns. Induction cooktops use magnetic fields to heat the pan itself."]],
  ["Moist heat methods",[
    "Moist-heat methods cook food with water or steam. Their temperature is limited by the boiling point of water, 100°C (212°F) at sea level, and lower at altitude. Boiling uses vigorously bubbling water, good for pasta and some vegetables. Simmering uses gentler bubbles at roughly 85–95°C, ideal for stocks, stews, and delicate foods that would toughen or break apart in a rolling boil. Poaching is gentler still, used for eggs, fish, and fruit.",
    "Steaming cooks with water vapor and keeps food from becoming waterlogged, preserving texture and nutrients; it is central to Chinese cooking. Because moist-heat temperatures stay at or below 100°C, food does not brown, so these methods are often paired with a browning step for flavor."]],
  ["Dry heat methods",[
    "Dry-heat methods use hot air, fat, or direct heat, reaching temperatures well above 100°C, which allows browning. Roasting and baking use the hot air of an oven; roasting usually refers to meats and vegetables, baking to breads, cakes, and pastries. Grilling and broiling use intense radiant heat from below or above.",
    "Cooking in fat is also dry heat, since there is no water. Sautéing uses a small amount of fat in a hot pan with frequent movement ('sauter' means 'to jump' in French). Stir-frying, the Chinese technique, uses a very hot wok and constant tossing. Pan-frying uses more fat; deep-frying submerges food in hot oil, usually around 160–190°C, producing crisp exteriors as moisture escapes as steam."]],
  ["Combination methods",[
    "Braising and stewing combine both: food is first browned in dry heat, then cooked slowly in a covered pot with some liquid at a low temperature. This transforms tough cuts of meat rich in connective tissue into tender, flavorful dishes, as in beef bourguignon, osso buco, or adobo. Braises usually use larger pieces partly submerged; stews use smaller pieces fully covered.",
    "Other techniques include smoking (cooking and flavoring with smoke from smoldering wood), barbecue in the American sense (long, low, smoky cooking), sous vide (cooking food sealed in plastic in a precisely controlled water bath), and confit (cooking slowly submerged in fat, traditionally duck legs in their own fat)."]],
  ["Temperature and doneness",[
    "The internal temperature of food determines doneness. For beef, rare is about 50–52°C (125°F), medium-rare about 55–57°C, medium about 60–63°C, and well-done about 70°C and above. Food safety agencies set minimum temperatures, for example 74°C (165°F) for poultry in the US guidelines, though safety also depends on how long food is held at a temperature.",
    "Food keeps cooking after it leaves the heat, called carryover cooking, as heat continues moving from the hot exterior to the center; a large roast can rise several degrees while resting. An instant-read thermometer is one of the most useful tools a cook can own."]],
  ["Choosing a method",[
    "The right method depends on the food. Tender cuts of meat and fish suit quick, high-heat methods like grilling or sautéing; tough cuts suit slow, moist braising. Delicate vegetables suit steaming or quick blanching; hearty root vegetables suit roasting, which concentrates their sugars and browns them.",
    "Many recipes combine methods for the best of both: searing then roasting a steak, blanching then sautéing green beans, or browning then braising short ribs. Understanding heat transfer lets you adapt any recipe to your equipment and ingredients."]]
  ],
  terms:[["Conduction","Heat transfer through direct contact."],["Convection","Heat transfer through moving fluids such as air or water."],["Radiation","Heat transfer as infrared energy."],["Braising","Browning food, then cooking it slowly with some liquid in a covered pot."],["Sous vide","Cooking vacuum-sealed food in a precisely controlled water bath."],["Carryover cooking","Food continuing to cook after removal from heat."]],
  w:"Knowing how heat works lets you choose the right method for every ingredient and adapt any recipe.",
  src:["Cooking","Heat transfer","Braising","Sous vide","Deep frying","Doneness"],
  q:[["Heat passing from a hot pan into a steak is…","Conduction","Convection","Radiation","Induction"],
     ["Why don't boiled foods brown?","Moist heat stays near 100°C, too low for browning","Water removes flavor","Boiling uses radiation","Browning needs salt"],
     ["What does 'sauter' mean in French?","To jump","To burn","To boil","To stir slowly"],
     ["Braising is best for…","Tough cuts with connective tissue","Delicate fish fillets","Lettuce","Pasta"],
     ["What is carryover cooking?","Food continuing to cook after leaving the heat","Cooking food in two pans","Cooking leftovers","Transporting hot food"],
     ["The US guideline minimum internal temperature for poultry is…","74°C (165°F)","50°C (122°F)","100°C (212°F)","60°C (140°F)"]]},

{ t:"The Chemistry of Cooking", s:"Browning, proteins, starches, and emulsions",
  sec:[
  ["Food is chemistry",[
    "All food is made of water, proteins, carbohydrates (sugars and starches), fats, and smaller amounts of minerals, vitamins, and flavor compounds. Cooking changes these molecules: proteins unfold and bind, starches swell, sugars break down, fats melt, and new flavor compounds form. Understanding these changes explains why recipes work and how to fix them.",
    "The physicist Nicholas Kurti and the chemist Hervé This coined the term 'molecular gastronomy' in 1988 for the scientific study of cooking. Harold McGee's book 'On Food and Cooking' (1984, revised 2004) became the standard reference for cooks wanting to understand food science."]],
  ["The Maillard reaction",[
    "The Maillard reaction, named after the French chemist Louis-Camille Maillard, who described it in 1912, is a set of reactions between amino acids and certain sugars that produces hundreds of flavor and aroma compounds and brown color. It is responsible for the flavor of seared steak, toasted bread, roasted coffee, fried onions, and the crust of baked goods.",
    "Maillard browning happens quickly above about 140°C, which is why food must be relatively dry and the pan hot. Wet food steams instead of browning; crowding a pan releases too much moisture. Patting meat dry, preheating pans, and not overcrowding are practical applications of chemistry."]],
  ["Caramelization",[
    "Caramelization is the browning of sugar by itself when heated, beginning at around 160°C for table sugar (sucrose). As sugar breaks down it produces brown color and complex flavors: buttery, nutty, and slightly bitter. Caramel, toffee, and the crunchy top of crème brûlée are products of caramelization.",
    "In practice, browning often involves both caramelization and the Maillard reaction. So-called 'caramelized onions', cooked slowly until deep brown, owe much of their flavor to Maillard reactions as well as sugar browning."]],
  ["Proteins: coagulation and connective tissue",[
    "Proteins are long chains of amino acids folded into shapes. Heat, acid, salt, and agitation make them unfold (denature) and bond together (coagulate), turning liquid egg white into solid white, or making meat firm. Overcooking squeezes out water, making meat dry and eggs rubbery.",
    "Meat also contains collagen, the protein of connective tissue. In tough cuts like shoulder or shank, collagen converts slowly into gelatin when held at moderate temperatures in moist heat for hours, making meat tender and sauces silky. Gluten, formed when wheat proteins (glutenin and gliadin) are mixed with water and kneaded, gives bread its chewy, elastic structure."]],
  ["Starches",[
    "Starch granules, found in grains, potatoes, and legumes, absorb water and swell when heated, a process called gelatinization, which thickens sauces and softens rice and pasta. As cooked starch cools, it partially recrystallizes (retrogradation), which is why bread goes stale and why day-old rice is better for fried rice.",
    "Different starches behave differently. Cornstarch and arrowroot give clear, glossy sauces; flour gives opaque ones. Potatoes high in starch (russet, floury) become fluffy when baked or mashed; waxy potatoes hold their shape in salads. Risotto rice releases starch to create creaminess."]],
  ["Fats and emulsions",[
    "Fats carry flavor, transfer heat, create tenderness in pastry by coating flour proteins, and give richness. Each fat has a smoke point, the temperature at which it begins to break down and smoke; refined oils generally have higher smoke points than butter or extra-virgin olive oil.",
    "Oil and water don't mix, but an emulsion disperses tiny droplets of one in the other, stabilized by an emulsifier. Mayonnaise is oil dispersed in egg yolk, with lecithin from the yolk as emulsifier; vinaigrettes are temporary emulsions often stabilized with mustard. Butter sauces like hollandaise and beurre blanc are delicate emulsions that can 'break' if they get too hot. Understanding emulsions lets you rescue a broken sauce by whisking it slowly into a fresh egg yolk or a little water."]]
  ],
  terms:[["Maillard reaction","Browning reactions between amino acids and sugars creating flavor."],["Caramelization","The browning of sugar by heat."],["Denaturation","The unfolding of proteins by heat, acid, or other forces."],["Collagen","Connective tissue protein that converts to gelatin with slow moist heat."],["Gelatinization","The swelling of starch granules in water when heated."],["Emulsion","A mixture of two liquids that don't normally mix, such as oil and water."],["Smoke point","The temperature at which a fat begins to smoke and break down."]],
  w:"Kitchen chemistry explains browning, tenderness, thickening, and sauces, turning recipes into understanding.",
  src:["Maillard reaction","Caramelization","Molecular gastronomy","Gelatinization","Emulsion","On Food and Cooking"],
  q:[["The Maillard reaction occurs between…","Amino acids and sugars","Fat and water","Salt and acid","Starch and oil"],
     ["Why should you pat meat dry before searing?","Wet surfaces steam instead of browning","To remove salt","To make it cook slower","To tenderize it"],
     ["How does collagen make braised meat tender?","It converts to gelatin with slow moist heat","It melts into fat","It evaporates","It turns into sugar"],
     ["Why is day-old rice good for fried rice?","Retrograded starch makes grains firmer and separate","It has more flavor from bacteria","It absorbs more oil","It cooks faster"],
     ["What emulsifier is found in egg yolk?","Lecithin","Gluten","Capsaicin","Collagen"],
     ["Who wrote 'On Food and Cooking'?","Harold McGee","Hervé This","Nicholas Kurti","Louis-Camille Maillard"]]},

{ t:"Knives, Tools, and Equipment", s:"Setting up a kitchen",
  sec:[
  ["The essential knives",[
    "A cook's most important tool is a sharp knife. Most professional cooks rely mainly on a chef's knife (about 20–25 cm, 8–10 inches), used for most chopping and slicing; a paring knife for small, precise work; and a serrated knife for bread and tomatoes. Specialized knives include boning knives, fillet knives, cleavers, and slicers.",
    "Western knives typically have a blade sharpened at around 20 degrees per side; Japanese knives are often thinner and harder with more acute edges. Japanese knives include the gyuto (chef's knife), santoku (all-purpose), nakiri (vegetables), and the single-bevel yanagiba used for slicing raw fish. A sharp knife is safer than a dull one, because it requires less force and is less likely to slip."]],
  ["Knife skills",[
    "Basic knife technique includes the 'claw grip' for the guiding hand, curling fingertips under so the knuckles guide the blade, and the 'pinch grip' on the knife, holding the blade between thumb and forefinger for control. A stable cutting board, secured with a damp towel underneath, prevents slipping.",
    "Classic French cuts standardize sizes so food cooks evenly and looks neat. A brunoise is a tiny dice of about 3 mm; a small dice about 6 mm; julienne are thin matchsticks about 3 mm by 3 mm by 5–6 cm; a chiffonade is fine ribbons of rolled leafy herbs; and mince is very fine, irregular chopping. A honing steel realigns the edge between sharpenings; whetstones actually sharpen by removing metal."]],
  ["Pots and pans",[
    "Cookware materials conduct heat differently. Copper and aluminum conduct heat quickly and evenly; stainless steel is durable and non-reactive but a poor conductor, so good pans have aluminum or copper cores (clad or tri-ply). Cast iron heats slowly but holds heat well, ideal for searing; it must be seasoned with polymerized oil to resist sticking and rust. Carbon steel, used for woks and French omelet pans, is similar but lighter.",
    "Nonstick pans, coated with materials such as PTFE (Teflon) or ceramic, are good for eggs and delicate fish but should not be overheated. Essential pieces include a skillet or sauté pan, a saucepan, a large stockpot, a heavy Dutch oven for braising, and sheet pans for roasting. Reactive metals like aluminum and unlined copper can react with acidic foods, causing off flavors."]],
  ["Small tools",[
    "Useful tools include a cutting board (wood or plastic), measuring cups and spoons, a digital scale, mixing bowls, whisks, wooden spoons, a fish spatula, tongs, a ladle, a slotted spoon, a fine-mesh sieve, a colander, a vegetable peeler, a microplane grater, and an instant-read thermometer.",
    "Professional kitchens use additional equipment such as mandolines for thin, even slices (dangerous without a guard), immersion blenders, food processors, stand mixers, and combi ovens that combine convection and steam. Many cooks argue that a few high-quality tools are better than many gadgets."]],
  ["Stoves and ovens",[
    "Gas burners offer visible, instantly adjustable flames; electric coil and ceramic tops are slower to respond; induction cooktops heat pans directly through magnetism, responding quickly and efficiently, but require magnetic cookware (cast iron or magnetic stainless steel). Many regions are encouraging a shift to induction to reduce indoor air pollution and emissions.",
    "Ovens may be conventional (heat from elements or burners) or convection (with a fan circulating air for faster, more even cooking, typically requiring a lower temperature). Ovens often run hotter or cooler than their dials say; an oven thermometer helps. Traditional ovens, such as wood-fired pizza ovens, tandoors, and Chinese roasting ovens, reach much higher temperatures."]],
  ["Caring for tools",[
    "Knives should be washed by hand and dried, not left in the sink or dishwasher, and stored in a block, on a magnetic strip, or with guards. Cutting boards should be cleaned well, with separate boards ideally used for raw meat. Cast iron should be dried promptly and lightly oiled.",
    "Good tools last decades with care. Learning to use and maintain them, especially to sharpen a knife, is part of becoming a skilled cook."]]
  ],
  terms:[["Chef's knife","The main all-purpose kitchen knife, typically 20–25 cm long."],["Claw grip","Holding food with curled fingertips so the knuckles guide the knife."],["Brunoise","A very fine dice of about 3 mm."],["Julienne","Thin matchstick cuts."],["Chiffonade","Fine ribbons of rolled leafy herbs or greens."],["Seasoning (cast iron)","A layer of polymerized oil that protects cast iron and reduces sticking."],["Induction","A cooktop that heats magnetic pans directly using magnetic fields."]],
  w:"Good tools, used well, make cooking faster, safer, and more precise.",
  src:["Chef's knife","Knife skills","Cookware and bakeware","Cast-iron cookware","Induction cooking","Japanese kitchen knife"],
  q:[["Why is a sharp knife safer than a dull one?","It needs less force and is less likely to slip","It is heavier","It cuts only vegetables","It is always shorter"],
     ["What is a brunoise?","A very fine dice of about 3 mm","Ribbons of herbs","Thin matchsticks","Large chunks"],
     ["What does a honing steel do?","Realigns a knife's edge","Removes a lot of metal","Polishes the handle","Measures the blade"],
     ["Why are stainless pans often clad with aluminum or copper?","Stainless steel conducts heat poorly","For decoration","To make them lighter only","To prevent rust"],
     ["Induction cooktops require…","Magnetic cookware","Copper pots only","Glass pans","Clay pots"],
     ["Seasoning cast iron means…","Building a protective layer of polymerized oil","Adding salt and pepper","Painting it","Soaking it in water"]]}

]});


/* ---- from cuisine-02.js ---- */
/* CUISINE FOUNDATIONS, part 2: Unit 1 How Cooking Works, chapters 6-10 */
COURSES.cuisine.units[0].ch.push(

{ t:"The Professional Kitchen", s:"Mise en place, the brigade, and working clean",
  sec:[
  ["Mise en place",[
    "Mise en place, French for 'putting in place', means preparing and organizing everything before cooking begins: ingredients washed, cut, measured, and arranged; tools ready; and a plan. It is the foundation of professional cooking. In a restaurant kitchen, each cook prepares their station before service so they can cook hundreds of dishes quickly and accurately.",
    "For home cooks, mise en place means reading the recipe fully, gathering ingredients, and doing prep before turning on the heat. Many dishes, especially stir-fries, cook too quickly to chop while cooking. The chef Anthony Bourdain wrote that mise en place is 'the religion of all good line cooks'."]],
  ["The kitchen brigade",[
    "The brigade de cuisine, systematized by the French chef Auguste Escoffier in the late 19th century, organizes a kitchen like a military unit with a clear hierarchy. The executive chef (chef de cuisine) leads; the sous-chef ('under-chef') is second in command and runs the line; chefs de partie (station chefs) run specific stations; and commis (junior cooks) assist them.",
    "Traditional stations include the saucier (sauces and sautéed dishes, often the most prestigious), the rôtisseur (roasts), the poissonnier (fish), the entremetier (vegetables, soups, and starches), the garde manger (cold foods, salads, and charcuterie), and the pâtissier (pastry). The expediter (aboyeur, 'barker') calls orders and coordinates the pass, where finished plates are checked and sent out. Modern kitchens are usually smaller but keep this structure in simplified form."]],
  ["Service and communication",[
    "During service, orders arrive as tickets, and the expediter calls them out. Cooks reply 'Oui, chef' or 'Heard' to confirm. Timing is critical: all dishes for a table must be finished together. Cooks use phrases like 'Behind!' and 'Hot!' or 'Sharp!' to move safely in tight spaces.",
    "Pressure, heat, and speed make professional kitchens intense workplaces. Their culture has been portrayed in books like Bourdain's 'Kitchen Confidential' (2000) and television shows like 'The Bear'. In recent years, many chefs have worked to reduce abusive practices, long hours, and burnout in the industry."]],
  ["Working clean",[
    "Professional cooks 'work clean': wiping surfaces constantly, keeping stations organized, using separate towels for different tasks, and cleaning as they go. A clean station reduces mistakes and contamination and speeds up service.",
    "Organization extends to storage: labeling and dating everything, using the FIFO principle (first in, first out) so older stock is used first, and storing raw meats below ready-to-eat foods in the refrigerator to prevent drips. These habits are equally useful at home."]],
  ["Recipes and scaling",[
    "Professional kitchens use standardized recipes so dishes taste the same every time, with ingredients listed by weight rather than volume. Weighing is more accurate: a cup of flour can vary by 20 percent or more depending on how it is scooped. Bakers in particular rely on scales.",
    "Recipes are scaled up or down using a conversion factor (desired yield divided by original yield). Not everything scales perfectly, though: seasonings, leavening, and cooking times may need adjustment, and larger pots change evaporation rates. Food cost calculations ensure dishes are profitable, typically aiming for food costs of roughly a quarter to a third of the menu price in many restaurants."]],
  ["Thinking like a chef",[
    "Chefs think in systems: preparing components in advance, cooking efficiently, planning for timing, and tasting constantly. They use 'base preparations', stocks, sauces, doughs, and pickles, to build many dishes. They manage waste by using trimmings creatively, such as making stock from bones and vegetable scraps.",
    "Adopting these habits, planning, prepping, organizing, tasting, and cleaning as you go, can transform any home cook's efficiency and results."]]
  ],
  terms:[["Mise en place","Preparing and organizing all ingredients and tools before cooking."],["Brigade de cuisine","The hierarchical kitchen organization systematized by Escoffier."],["Sous-chef","The second-in-command in a kitchen."],["Chef de partie","A station chef responsible for one area."],["Garde manger","The station for cold foods, salads, and charcuterie."],["FIFO","First in, first out: using older stock first."]],
  w:"Professional organization makes cooking faster, more reliable, and safer, at home or in a restaurant.",
  src:["Mise en place","Brigade de cuisine","Auguste Escoffier","Chef","Kitchen Confidential (book)","Standardized recipe"],
  q:[["What does 'mise en place' mean?","Putting in place: preparing everything before cooking","Placing the dish on the table","The head chef","A type of sauce"],
     ["Who systematized the kitchen brigade?","Auguste Escoffier","Marie-Antoine Carême","Paul Bocuse","Fernand Point"],
     ["The sous-chef is…","Second in command","The pastry chef","The dishwasher","The owner"],
     ["Which station handles cold foods and charcuterie?","Garde manger","Saucier","Rôtisseur","Pâtissier"],
     ["Why do professional recipes use weights?","Weighing is more accurate than volume","Scales are cheaper than cups","Volume measures are illegal","To impress customers"],
     ["What does FIFO stand for?","First in, first out","Fresh ingredients for orders","Fry it, fold it","Food is fully organized"]]},

{ t:"Food Safety", s:"Keeping food safe to eat",
  sec:[
  ["Why it matters",[
    "Foodborne illness is common. The World Health Organization estimates that about 600 million people fall ill and around 420,000 die each year from contaminated food. Most cases cause unpleasant but temporary symptoms, but some, especially in children, older people, pregnant people, and those with weakened immune systems, can be severe.",
    "Hazards include biological contaminants (bacteria such as Salmonella, Campylobacter, Listeria, and E. coli; viruses such as norovirus; and parasites), chemical hazards (cleaning agents, pesticides, natural toxins), physical hazards (glass, bone, metal), and allergens."]],
  ["The danger zone",[
    "Bacteria multiply fastest at temperatures between about 5°C and 60°C (40°F and 140°F), often called the 'danger zone'. Under ideal conditions some bacteria can double in number roughly every 20 minutes. Food safety guidance generally says perishable food should not be left in this range for more than two hours (one hour in very hot weather).",
    "Keep cold food cold (refrigerators at 5°C/40°F or below, ideally around 3–4°C; freezers at -18°C/0°F) and hot food hot (above 60°C/140°F). Cool cooked food quickly by dividing it into shallow containers before refrigerating. Thaw frozen food in the refrigerator, under cold running water, or in the microwave, rather than on the counter."]],
  ["Cross-contamination",[
    "Cross-contamination occurs when harmful microbes transfer from one food or surface to another, often from raw meat, poultry, seafood, or eggs to ready-to-eat foods. Prevent it by using separate cutting boards and utensils, washing hands thoroughly with soap for about 20 seconds, cleaning surfaces, and storing raw meat on the bottom shelf.",
    "Washing raw chicken is discouraged by food safety agencies because splashing can spread bacteria around the sink and kitchen; cooking to the proper temperature kills them. Leafy greens and produce should be rinsed under running water, as they can also carry pathogens."]],
  ["Cooking temperatures",[
    "Cooking destroys most pathogens. Common US guidelines include 74°C (165°F) for poultry and leftovers, 71°C (160°F) for ground meats, and 63°C (145°F) for whole cuts of beef, pork, lamb, and fish, followed by a rest. Ground meat needs higher temperatures than steaks because grinding spreads surface bacteria throughout.",
    "Pasteurization, discovered by Louis Pasteur in the 1860s, heats liquids such as milk to kill pathogens while preserving quality. Pathogen reduction depends on both temperature and time, which is why sous vide cooks can safely cook chicken at lower temperatures for longer periods."]],
  ["Allergens",[
    "Food allergies can cause severe, even fatal, reactions (anaphylaxis). Major allergens in many countries include milk, eggs, fish, crustacean shellfish, tree nuts, peanuts, wheat, and soybeans; the US added sesame as the ninth major allergen in 2023. The EU requires labeling of 14 allergens, including celery, mustard, lupin, and sulfites.",
    "Restaurants must handle allergens carefully, avoiding cross-contact, communicating clearly with guests, and training staff. Food intolerances (such as lactose intolerance) and celiac disease (an autoimmune reaction to gluten) are different from allergies but also require care."]],
  ["Systems for safety",[
    "Professional kitchens use HACCP (Hazard Analysis and Critical Control Points), a system originally developed in the 1960s for NASA's space food program with the Pillsbury Company. HACCP identifies points where hazards can be controlled, such as cooking temperatures and cold storage, and monitors them with records.",
    "Food handlers often need certifications, and health inspectors check restaurants. At home, the four simple principles are: clean (wash hands and surfaces), separate (avoid cross-contamination), cook (to safe temperatures), and chill (refrigerate promptly)."]]
  ],
  terms:[["Foodborne illness","Illness caused by eating contaminated food."],["Danger zone","Temperatures of about 5–60°C where bacteria grow rapidly."],["Cross-contamination","Transfer of harmful microbes between foods or surfaces."],["Pasteurization","Heating to kill pathogens while preserving quality."],["Anaphylaxis","A severe, potentially fatal allergic reaction."],["HACCP","Hazard Analysis and Critical Control Points, a food safety management system."]],
  w:"Safe food handling protects everyone you cook for and is a basic responsibility of every cook.",
  src:["Foodborne illness","Danger zone (food safety)","Cross-contamination","Hazard analysis and critical control points","Food allergy","Pasteurization"],
  q:[["What is the food 'danger zone'?","About 5–60°C, where bacteria grow fastest","Below freezing","Above boiling","The area near the stove"],
     ["Why is washing raw chicken discouraged?","Splashing spreads bacteria around the kitchen","It removes flavor","It makes chicken tough","It is a waste of water only"],
     ["Why must ground meat be cooked hotter than steaks?","Grinding spreads surface bacteria throughout","It contains more fat","It is usually frozen","It is older meat"],
     ["Which allergen did the US add as the ninth major allergen in 2023?","Sesame","Mustard","Celery","Corn"],
     ["HACCP was originally developed for…","NASA's space food program","The French army","Fast food chains","Hospitals"],
     ["Who discovered pasteurization?","Louis Pasteur","Joseph Lister","Alexander Fleming","Robert Koch"]]},

{ t:"Seasoning and Balance", s:"Salt, acid, fat, heat, and building flavor",
  sec:[
  ["Salt",[
    "Salt is the most important seasoning. It enhances flavors, suppresses bitterness, and makes food taste more like itself. Salt also changes texture: it draws moisture from vegetables, firms proteins, and in brining or dry-salting (sometimes called dry brining) helps meat retain moisture during cooking.",
    "Common salts include table salt (fine, often with iodine and anti-caking agents), kosher salt (coarse flakes favored by many chefs; brands differ greatly in density, so a teaspoon of Diamond Crystal weighs about half as much as Morton), sea salt, and finishing salts like flaky Maldon or fleur de sel. Season throughout cooking rather than only at the end, and season pasta water generously."]],
  ["Acid",[
    "Acid brightens and balances flavors, cutting through richness and making dishes feel lively. Sources include citrus juice, vinegars (wine, rice, cider, sherry, balsamic), wine, tomatoes, yogurt, buttermilk, tamarind, and fermented foods. A squeeze of lemon or splash of vinegar at the end of cooking can transform a dull stew.",
    "Acid also has chemical effects: it denatures proteins (as in ceviche, where citrus 'cooks' fish), keeps cut fruits from browning, tenderizes in marinades (though mostly at the surface), helps set pectin in jams, and keeps green vegetables duller if added during cooking, so it is often added at the end."]],
  ["Fat",[
    "Fat carries flavor, since many aroma compounds dissolve in fat; creates texture, crispness when frying and tenderness in pastry; and adds satisfying richness. Different fats give distinct characters: butter, olive oil, lard, duck fat, ghee, coconut oil, sesame oil.",
    "Samin Nosrat's book 'Salt, Fat, Acid, Heat' (2017) popularized the idea that these four elements are the fundamentals of good cooking: salt enhances flavor, fat carries it, acid balances it, and heat determines texture. Mastering them lets cooks improvise without recipes."]],
  ["Aromatics and flavor bases",[
    "Many cuisines begin dishes by cooking aromatic vegetables and spices in fat to build a flavor base. French cooking uses mirepoix (onion, carrot, and celery, typically in a 2:1:1 ratio). Cajun and Creole cooking uses the 'holy trinity' of onion, celery, and green bell pepper. Italian soffritto, Spanish sofrito, Portuguese refogado, and Indian tadka (spices bloomed in hot fat) serve similar roles.",
    "Chinese cooking often begins with ginger, garlic, and scallions. Thai curries begin with pounded pastes of chilies, lemongrass, galangal, and shrimp paste. These bases explain why so many cuisines taste distinct even when using similar main ingredients."]],
  ["Herbs, spices, and timing",[
    "Spices are dried seeds, bark, roots, and fruits; herbs are leaves. Whole spices keep their flavor longer than ground ones; toasting them in a dry pan or blooming them in oil releases aromas. Hardy herbs like rosemary, thyme, and bay leaf can cook for a long time, while tender herbs like basil, cilantro, parsley, and mint are best added at the end.",
    "Timing matters for all seasoning. Garlic burns quickly and becomes bitter; onions need time to soften and sweeten; salt added early penetrates food, while salt added late gives a crunchy, bright accent."]],
  ["Tasting and adjusting",[
    "The key professional habit is to taste constantly and adjust. Ask: Is it salty enough? Does it need brightness (acid)? Is it too rich (add acid or bitterness)? Too sour (add sweetness or fat)? Too spicy (add dairy, sugar, or starch)? Lacking depth (add umami ingredients like soy, miso, parmesan, or anchovy)?",
    "Balance also involves texture and contrast: something crunchy on a soft dish, fresh herbs on a rich braise, or a cool yogurt on a spicy curry. A dish that is 'balanced' feels complete, with no single element overpowering the others."]]
  ],
  terms:[["Kosher salt","Coarse-grained salt favored by many cooks; brands vary in density."],["Dry brining","Salting meat in advance so it seasons deeply and retains moisture."],["Mirepoix","French aromatic base of onion, carrot, and celery."],["Holy trinity","Cajun/Creole base of onion, celery, and bell pepper."],["Soffritto","Italian aromatic base of onion, carrot, celery, and often garlic, cooked in fat."],["Tadka","Indian technique of blooming spices in hot fat."]],
  w:"Balancing salt, acid, fat, and heat, and tasting constantly, is the core skill of all good cooking.",
  src:["Salt","Mirepoix (cuisine)","Holy trinity (cuisine)","Salt Fat Acid Heat","Soffritto","Tempering (spices)"],
  q:[["Why do Diamond Crystal and Morton kosher salt measure differently?","Their crystals differ in density","One is not salt","One contains sugar","They are the same"],
     ["What does a squeeze of lemon do to a dull stew?","Brightens and balances the flavor","Thickens it","Makes it sweeter","Removes salt"],
     ["Mirepoix consists of…","Onion, carrot, and celery","Onion, celery, and bell pepper","Garlic, ginger, and scallion","Tomato, basil, and garlic"],
     ["The Cajun 'holy trinity' includes…","Onion, celery, and green bell pepper","Carrot, potato, and leek","Garlic, chili, and lime","Rice, beans, and corn"],
     ["When are tender herbs like basil usually added?","At the end of cooking","At the very beginning","Overnight before","Never cooked at all"],
     ["Who wrote 'Salt, Fat, Acid, Heat'?","Samin Nosrat","Julia Child","Harold McGee","Alice Waters"]]},

{ t:"Measuring, Ratios, and Baking Basics", s:"Precision and proportion",
  sec:[
  ["Cooking versus baking",[
    "Many cooks say that cooking is an art and baking is a science. In savory cooking, you can taste and adjust as you go; in baking, the chemical reactions happen inside the oven, and the proportions of flour, water, fat, sugar, eggs, and leavening must be right from the start. Small errors can lead to dense cakes or flat cookies.",
    "Professional bakers measure by weight, usually in grams, and often use baker's percentages, in which every ingredient is expressed as a percentage of the total flour weight. A simple bread might be 100% flour, 65% water, 2% salt, and 1% yeast. This makes recipes easy to scale and compare."]],
  ["Ratios",[
    "Many classic preparations follow simple ratios, as described in Michael Ruhlman's book 'Ratio' (2009). Basic bread dough is about five parts flour to three parts water by weight. Pie dough (pâte brisée) is roughly 3 parts flour, 2 parts fat, and 1 part water. A classic pound cake uses equal weights of flour, butter, sugar, and eggs, originally a pound of each.",
    "A vinaigrette is about three parts oil to one part vinegar; a roux is equal weights of fat and flour; and a standard custard uses about one egg to 250 ml of milk. Knowing ratios frees cooks from recipes and helps them troubleshoot."]],
  ["Flour and gluten",[
    "Wheat flours differ in protein content, which determines how much gluten they form. Bread flour (around 12–14% protein) forms strong gluten for chewy breads; all-purpose flour (around 10–12%) is versatile; cake and pastry flours (around 7–9%) give tender results. Italian '00' flour is very finely milled and used for pizza and pasta.",
    "Mixing and kneading develop gluten; for breads you want strong development, while for tender cakes, muffins, and pastry you mix minimally. Fat and sugar interfere with gluten formation, making baked goods more tender."]],
  ["Leavening",[
    "Leavening makes baked goods rise. Biological leavening uses yeast, a living fungus that ferments sugars into carbon dioxide and alcohol; sourdough uses a culture of wild yeasts and lactic acid bacteria. Chemical leavening uses baking soda (sodium bicarbonate), which needs an acid such as buttermilk, yogurt, or lemon juice to react, or baking powder, which contains both soda and a dry acid.",
    "Mechanical leavening traps air or steam: whipping egg whites for soufflés and meringues, creaming butter and sugar for cakes, and the steam that puffs choux pastry and laminated doughs like puff pastry and croissants. Most baked goods use a combination."]],
  ["Ovens and doneness in baking",[
    "Oven temperature affects rise, browning, and texture. Preheating is essential so that leavening and structure develop properly. Bakers judge doneness by color, by a skewer coming out clean from cakes, by internal temperature (many breads are done around 90–99°C internally), and by a hollow sound when the bottom of a loaf is tapped.",
    "At high altitude, lower air pressure makes water boil at lower temperatures and gases expand more, so baked goods may rise too fast and collapse; recipes adjust by reducing leavening and sugar and increasing oven temperature slightly."]],
  ["Units and conversions",[
    "Recipes use different measuring systems. The metric system uses grams and milliliters; the US customary system uses cups, tablespoons, teaspoons, ounces, and pounds. One US cup is about 240 ml; a tablespoon is about 15 ml; a teaspoon about 5 ml; an ounce is about 28 grams. Oven temperatures may be in Celsius or Fahrenheit: 180°C is about 350°F, and 220°C about 425°F.",
    "British recipes may use imperial measures, and older recipes may use 'gas marks'. A digital scale and a conversion chart solve most problems. Accuracy matters most in baking, confectionery, and preserving, where precise proportions determine success."]]
  ],
  terms:[["Baker's percentage","Expressing each ingredient as a percentage of flour weight."],["Gluten","An elastic protein network formed from wheat proteins and water."],["Leavening","Agents or methods that make dough or batter rise."],["Baking soda","Sodium bicarbonate, a chemical leavener requiring an acid."],["Baking powder","A leavener containing both baking soda and a dry acid."],["Roux","A cooked mixture of equal weights of fat and flour used to thicken sauces."]],
  w:"Understanding ratios and leavening makes baking predictable and lets you create your own recipes.",
  src:["Baker percentage","Gluten","Leavening agent","Baking powder","Pound cake","Cooking weights and measures"],
  q:[["In baker's percentages, all ingredients are expressed relative to…","Flour weight","Water weight","Total weight","Sugar weight"],
     ["A classic pound cake uses…","Equal weights of flour, butter, sugar, and eggs","A pound of flour only","Pounds of chocolate","No eggs"],
     ["Which flour has the most protein?","Bread flour","Cake flour","Pastry flour","Corn flour"],
     ["Baking soda needs what to react?","An acid","Yeast","Salt","Cold water"],
     ["What leavens puff pastry and choux?","Steam","Yeast","Baking soda","Egg yolks"],
     ["About how many milliliters are in a US cup?","240","100","500","1000"]]},

{ t:"Nutrition Basics", s:"What food does for the body",
  sec:[
  ["Macronutrients",[
    "Food provides energy and building materials through three macronutrients. Carbohydrates, including sugars, starches, and fiber, are the body's main energy source, providing about 4 kilocalories per gram. Proteins, made of amino acids, build and repair tissues and also provide about 4 kcal per gram; nine amino acids are 'essential' because the body cannot make them.",
    "Fats provide about 9 kcal per gram, carry fat-soluble vitamins (A, D, E, K), and supply essential fatty acids, including omega-3s. Fats include saturated fats (common in animal fats, butter, and coconut oil), unsaturated fats (olive oil, nuts, fish), and trans fats, many of which come from partially hydrogenated oils and raise heart disease risk; the WHO has called for their elimination, and many countries have banned industrial trans fats. Alcohol provides about 7 kcal per gram."]],
  ["Micronutrients and fiber",[
    "Vitamins and minerals, needed in small amounts, support countless body functions. Historical deficiency diseases show their importance: scurvy from lack of vitamin C, which killed many sailors until citrus was used (the British navy adopted lemon juice in 1795); rickets from lack of vitamin D; beriberi from lack of thiamine in diets of polished white rice; and pellagra from lack of niacin in diets based on untreated maize.",
    "Indigenous Mesoamericans avoided pellagra by nixtamalization, cooking maize with alkaline lime, which releases niacin. Fiber, found in whole grains, legumes, vegetables, and fruits, supports digestion and the gut microbiome and is linked to lower risk of several diseases."]],
  ["Dietary patterns",[
    "Nutrition science increasingly emphasizes overall dietary patterns rather than single nutrients. The Mediterranean diet, rich in vegetables, legumes, whole grains, olive oil, fish, and moderate wine, has been associated in many studies with lower heart disease risk. Japan's traditional diet and other plant-rich traditional diets are also studied for their health associations.",
    "Many national guidelines recommend eating plenty of vegetables, fruits, whole grains, and legumes; limiting added sugars, salt, and highly processed foods; and choosing healthy fats. The Harvard 'Healthy Eating Plate' and national food guides, like the US 'MyPlate', present these ideas visually."]],
  ["Processing and cooking",[
    "Food processing ranges from simple (washing, freezing, fermenting) to industrial. The NOVA classification, developed by Brazilian researchers led by Carlos Monteiro, groups foods by degree of processing; a growing body of research associates high consumption of 'ultra-processed foods', industrial formulations with many additives, with poorer health outcomes, though scientists debate the mechanisms.",
    "Cooking itself affects nutrition. It makes many nutrients more available, for example lycopene in cooked tomatoes and beta-carotene in cooked carrots, and makes starches and proteins digestible, but it can reduce some heat-sensitive vitamins like vitamin C. Steaming and quick cooking generally preserve more nutrients than long boiling."]],
  ["Special diets",[
    "People follow special diets for health, ethics, religion, or preference. Vegetarians avoid meat and fish; vegans avoid all animal products. Religious dietary laws include kashrut (kosher) in Judaism, halal in Islam, and vegetarianism common among Hindus and Jains, with Jains often also avoiding root vegetables.",
    "Medical diets include gluten-free diets for celiac disease, low-sodium diets for high blood pressure, and diabetic diets managing carbohydrate intake. Professional cooks must understand these requirements and cook for them safely and deliciously."]],
  ["Food, health, and pleasure",[
    "Good nutrition does not require giving up pleasure. Many of the world's healthiest traditional diets are also among its most delicious, built on fresh vegetables, legumes, grains, herbs, spices, and modest amounts of animal foods. The writer Michael Pollan summarized his advice in 'In Defense of Food' (2008): 'Eat food. Not too much. Mostly plants.'",
    "Cooking at home is consistently associated with better diet quality because cooks control ingredients and portions. Learning to cook well is therefore also one of the best ways to eat well."]]
  ],
  terms:[["Macronutrients","Carbohydrates, proteins, and fats, needed in large amounts."],["Micronutrients","Vitamins and minerals, needed in small amounts."],["Essential amino acids","Amino acids the body cannot produce and must get from food."],["Nixtamalization","Cooking maize with alkali, improving its nutrition and texture."],["Ultra-processed food","Industrial formulations typically containing many additives."],["Mediterranean diet","A dietary pattern rich in plants, olive oil, and fish."]],
  w:"Understanding nutrition lets cooks feed people well without sacrificing flavor.",
  src:["Nutrition","Macronutrient","Scurvy","Nixtamalization","Mediterranean diet","Ultra-processed food"],
  q:[["How many kilocalories does a gram of fat provide?","About 9","About 4","About 1","About 20"],
     ["Scurvy is caused by a lack of…","Vitamin C","Vitamin D","Iron","Protein"],
     ["How did Mesoamericans avoid pellagra?","Nixtamalization of maize","Eating rice","Drinking milk","Avoiding sunlight"],
     ["Who developed the NOVA classification of food processing?","Brazilian researchers led by Carlos Monteiro","The FDA","Michael Pollan","The WHO in 1950"],
     ["Cooking tomatoes makes which nutrient more available?","Lycopene","Vitamin C","Fiber","Water"],
     ["Michael Pollan's advice was…","Eat food. Not too much. Mostly plants.","Eat only meat","Count every calorie","Avoid all fats"]]}

);


/* ---- from cuisine-03.js ---- */
/* CUISINE FOUNDATIONS, part 3: Unit 2 Ingredients, chapters 1-5 */
COURSES.cuisine.units.push({ t:"Ingredients", ch:[

{ t:"Grains and Flour", s:"Wheat, corn, and the staples of civilization",
  sec:[
  ["The grass family",[
    "Cereal grains, the seeds of grasses, provide about half of all calories eaten by humans. The 'big three' are maize (corn), rice, and wheat, which together supply a large share of the world's food energy. Others include barley, oats, rye, sorghum, millet, and teff. Pseudocereals, seeds of non-grass plants used like grains, include quinoa, buckwheat, and amaranth.",
    "A whole grain kernel has three parts: the bran (fibrous outer layers with minerals and B vitamins), the germ (the embryo, rich in oils and vitamins), and the endosperm (the starchy bulk). Refined white flour and white rice keep only the endosperm, which stores better but loses much fiber and nutrients; many countries now enrich refined flour with added vitamins and iron."]],
  ["Wheat",[
    "Wheat was domesticated in the Fertile Crescent around 10,000 years ago, from wild einkorn and emmer. Modern bread wheat arose from hybridization with a wild grass. Hard wheats, high in protein, are used for bread; soft wheats for cakes and pastry; and durum wheat, very hard and yellow, is milled into semolina for dried pasta and couscous.",
    "Ancient varieties such as spelt, emmer (farro), and einkorn are now enjoying renewed interest. Wheat is processed into flour, bulgur (parboiled, dried, and cracked, used in tabbouleh), freekeh (roasted green wheat), and couscous (small pellets of semolina). Gluten-free diets exclude wheat, barley, and rye."]],
  ["Maize",[
    "Maize was domesticated in southern Mexico from a wild grass called teosinte, beginning around 9,000 years ago. It became the foundation of Mesoamerican civilization, and the Maya creation story tells of humans made from maize dough. After 1492, maize spread around the world; today it is the most produced grain globally, much of it used for animal feed and industrial products like corn syrup and ethanol.",
    "Types include dent corn (field corn), flint corn (hard, used for polenta and hominy), sweet corn (eaten fresh), and popcorn, whose hard hull traps steam until it bursts. Nixtamalized maize (masa) makes tortillas, tamales, and arepas (the latter often from precooked maize flour). Polenta in Italy and grits in the American South are maize porridges."]],
  ["Other grains",[
    "Barley, one of the earliest domesticated grains, is used in soups, for malting in beer and whisky, and in Tibet as roasted flour (tsampa). Oats thrive in cool, wet climates like Scotland, where they are traditional in porridge and oatcakes. Rye, tolerant of cold and poor soils, makes the dense, sour breads of Germany, Scandinavia, and Eastern Europe.",
    "Sorghum and millets are vital in Africa and India, drought-tolerant and used for porridges, flatbreads (like Indian bajra and jowar rotis), and beer. Teff, a tiny grain from Ethiopia and Eritrea, is fermented to make injera, the spongy flatbread central to Ethiopian meals. Quinoa, from the Andes, has become globally popular for its protein content."]],
  ["Milling and flour",[
    "Traditional stone milling grinds the whole grain, while modern roller mills, developed in 19th-century Hungary and adopted widely, separate bran and germ efficiently, producing fine white flour. White flour became a status symbol and then the standard, as it stored longer without the oily germ going rancid.",
    "Flour types are classified differently around the world: by protein content in the US (bread, all-purpose, cake), by ash content (mineral content) in France (T45 for pastry, T55 for baguettes, T65 and higher for more rustic breads), and by fineness and extraction in Italy (00, 0, 1, 2, integrale)."]],
  ["Cooking grains",[
    "Whole grains can be cooked by the absorption method (simmering in a measured amount of water until absorbed), the pasta method (boiling in plenty of water and draining), or pilaf style (toasting in fat before adding liquid, which keeps grains separate and adds flavor). Soaking and toasting can improve texture and flavor.",
    "Grains form the base of meals across the world: bread, porridge, pasta, flatbreads, dumplings, and pilafs. Learning to cook them well, with the right texture and seasoning, is fundamental to almost every cuisine."]]
  ],
  terms:[["Cereal grain","The edible seed of a cultivated grass."],["Bran","The fibrous outer layer of a grain kernel."],["Germ","The embryo of a grain, rich in oil and nutrients."],["Endosperm","The starchy interior of a grain kernel."],["Durum wheat","Hard wheat milled into semolina for pasta and couscous."],["Teosinte","The wild grass from which maize was domesticated."],["Injera","A spongy, fermented flatbread made from teff."]],
  w:"Grains are the foundation of most of the world's diets, and understanding them underlies bread, pasta, porridge, and more.",
  src:["Cereal","Wheat","Maize","Teff","Flour","Whole grain"],
  q:[["Which three grains supply a large share of the world's food energy?","Maize, rice, and wheat","Oats, rye, and barley","Quinoa, teff, and millet","Sorghum, buckwheat, and spelt"],
     ["Which part of the grain does white flour keep?","Only the endosperm","Only the bran","Only the germ","The whole kernel"],
     ["Maize was domesticated from…","Teosinte","Wild wheat","Rice","Barley"],
     ["Dried pasta is traditionally made from…","Durum wheat semolina","Rye flour","Cornmeal","Rice flour"],
     ["Injera is made from…","Teff","Maize","Oats","Quinoa"],
     ["French flour types like T55 are classified by…","Ash (mineral) content","Color only","Price","The mill's location"]]},

{ t:"Rice", s:"The grain that feeds half the world",
  sec:[
  ["A global staple",[
    "Rice is the staple food for more than half of the world's population, especially in Asia, where most of it is grown and eaten. Asian rice (Oryza sativa) was domesticated in China's Yangtze River valley perhaps around 9,000 years ago; a separate African rice (Oryza glaberrima) was domesticated in West Africa's Niger Delta region.",
    "Rice is usually grown in flooded paddies, which suppress weeds; terraced paddies, like those of the Philippine Cordilleras and Bali, are among the world's most remarkable agricultural landscapes. Rice culture shaped social life, festivals, and labor across Asia. Enslaved West Africans brought rice-growing expertise to the Carolinas in the American colonies, where 'Carolina Gold' rice became a major export."]],
  ["Types of rice",[
    "Rice varieties are often grouped by grain length and starch content. Long-grain rices, such as basmati (from India and Pakistan) and jasmine (from Thailand), are aromatic; basmati cooks into separate, fluffy grains, while jasmine is slightly stickier. Medium-grain rices, such as Spanish bomba (for paella) and Italian arborio and carnaroli (for risotto), absorb liquid well.",
    "Short-grain rices, such as Japanese japonica, become sticky and are used for sushi. Glutinous or 'sticky' rice, high in the starch amylopectin and containing almost no amylose, becomes very sticky and is eaten in Laos, northern Thailand, and in Chinese and Japanese sweets (mochi). Brown rice retains the bran; wild rice is actually the seed of a different aquatic grass native to North America."]],
  ["The science of stickiness",[
    "Rice starch is made of two molecules: amylose (long, straight chains) and amylopectin (branched). Rice high in amylose, such as basmati, cooks up firm and separate; rice high in amylopectin is soft and sticky. Rinsing rice removes surface starch, reducing stickiness, which is why many cooks rinse rice for pilafs but not for risotto.",
    "Cooking methods vary: the absorption method (common in Asia, with a set ratio of water to rice, often measured with the 'knuckle' method of covering rice by the first finger joint); boiling in excess water and draining (common in India); and steaming, especially for sticky rice. Electric rice cookers, introduced commercially in Japan in 1955 by Toshiba, transformed home cooking in Asia."]],
  ["Rice dishes of the world",[
    "Rice dishes show remarkable diversity: Persian chelow with its crispy crust (tahdig), Indian biryani layered with spiced meat, Spanish paella with its prized crust (socarrat), Italian risotto stirred into creaminess, West African jollof rice cooked in a tomato-pepper sauce (subject of friendly rivalry between Nigeria and Ghana), Japanese sushi, Chinese fried rice and congee (rice porridge), and Korean bibimbap.",
    "In Louisiana, rice is the base of jambalaya and gumbo; in the Caribbean, rice and peas (beans). Many cultures prize the crisp layer at the bottom of the pot, from Korean nurungji to Puerto Rican pegao."]],
  ["Rice products",[
    "Rice is transformed into many products: rice flour for noodles and cakes; rice noodles (like Vietnamese pho noodles and Thai rice noodles); rice paper wrappers; puffed rice; rice vinegar; and alcoholic drinks like Japanese sake, Chinese huangjiu (yellow wine), and Korean makgeolli. Koji, the mold Aspergillus oryzae grown on rice, is fundamental to Japanese fermentation, used in sake, miso, soy sauce, and mirin.",
    "Bran oil, rice crackers (senbei), and rice-based sweets are also common. In much of Asia, the word for 'cooked rice' is also the word for 'meal', as with Japanese gohan and Chinese fan."]],
  ["Rice and health",[
    "White rice is quickly digested and has a relatively high glycemic index; brown rice retains fiber and nutrients. Parboiling, partially boiling rice in the husk before milling, practiced in South Asia and West Africa, drives nutrients into the grain. 'Golden Rice', genetically modified to produce beta-carotene to combat vitamin A deficiency, was approved for cultivation in the Philippines in 2021, though it has faced legal challenges.",
    "Rice also tends to absorb arsenic from soil and water more than other grains; cooking it in excess water and draining reduces arsenic levels. Mastering rice, choosing the right variety and method, is essential for countless dishes."]]
  ],
  terms:[["Paddy","A flooded field used to grow rice."],["Amylose","A straight-chain starch making rice firm and separate."],["Amylopectin","A branched starch making rice sticky."],["Glutinous rice","Very sticky rice with almost no amylose; contains no gluten."],["Koji","The mold Aspergillus oryzae used in Japanese fermentation."],["Tahdig","The crispy rice crust of Persian rice dishes."]],
  w:"Rice feeds more people than any other food, and its many varieties and techniques define cuisines across the world.",
  src:["Rice","Oryza glaberrima","Basmati","Glutinous rice","Aspergillus oryzae","Jollof rice"],
  q:[["Where was Asian rice first domesticated?","China's Yangtze River valley","The Nile Delta","Mexico","Italy"],
     ["Which rice is traditionally used for risotto?","Arborio or carnaroli","Basmati","Jasmine","Wild rice"],
     ["Why is sticky rice sticky?","It is high in amylopectin and low in amylose","It contains gluten","It has sugar added","It is undercooked"],
     ["Wild rice is…","The seed of a different aquatic grass","Brown rice","A type of basmati","Rice grown without irrigation"],
     ["What is koji?","A mold used in Japanese fermentation","A rice cooker","A type of noodle","A rice wine"],
     ["Jollof rice is especially associated with…","West Africa","Japan","Spain","Persia"]]},

{ t:"Legumes and Soy", s:"Beans, lentils, and the power of pulses",
  sec:[
  ["What legumes are",[
    "Legumes are plants in the pea family (Fabaceae) that bear seeds in pods. Their dried seeds, called pulses, include beans, lentils, chickpeas, and dried peas. Legumes have a special ability: their roots host bacteria that fix nitrogen from the air, enriching soil, which is why farmers have long rotated them with grains.",
    "Pulses are rich in protein, fiber, and minerals, and they are inexpensive and store well. Paired with grains, as in rice and beans, dal and rice, or hummus with bread, they provide complementary amino acids. The UN declared 2016 the International Year of Pulses to promote them for nutrition and sustainability."]],
  ["Beans of the world",[
    "Common beans (Phaseolus vulgaris), domesticated in Mesoamerica and the Andes, include kidney, black, pinto, navy, and cannellini beans. They are central to Latin American cooking, from Mexican frijoles to Brazilian feijoada and Cuban black bean soup. The Old World has fava (broad) beans, among the oldest cultivated, used in Egyptian ful medames, and black-eyed peas, from Africa, traditional in the American South.",
    "Raw kidney beans contain a toxin (phytohaemagglutinin) destroyed by boiling vigorously for at least ten minutes; slow cookers at low temperatures may not destroy it, so beans should be boiled first. Soaking dried beans shortens cooking and can make them more digestible."]],
  ["Lentils and chickpeas",[
    "Lentils, among the earliest domesticated crops in the Fertile Crescent, cook quickly without soaking. Varieties include brown and green lentils, the small French green Puy lentils that hold their shape, red and yellow split lentils that collapse into a puree, and black beluga lentils. In India, split pulses called dal (including toor, moong, chana, and urad) are eaten daily, and India is the world's largest producer and consumer of pulses.",
    "Chickpeas (garbanzo beans) are central to the Middle East (hummus, falafel), India (chana masala, and gram flour made from chickpeas for pakoras), and the Mediterranean (Italian farinata, French socca). Aquafaba, the liquid from cooked chickpeas, can be whipped like egg whites, a discovery popularized by vegan cooks around 2014–2015."]],
  ["Soybeans",[
    "Soybeans, domesticated in northeastern China several thousand years ago, are the world's most important legume crop, used for oil, animal feed, and countless foods. Unlike most legumes, they are high in fat and protein but low in starch, and they are rarely eaten as plain cooked beans except as young green edamame.",
    "East Asian cooks transformed soy into a remarkable range of products. Soy milk is made by grinding soaked beans with water and straining; adding a coagulant such as nigari (magnesium chloride) or gypsum turns it into tofu, said by tradition to have been invented in China around the Han dynasty. The skin that forms on heated soy milk is yuba. Tempeh, from Indonesia, is whole soybeans bound by a mold into a firm cake."]],
  ["Fermented soy",[
    "Fermentation turns soybeans into powerful seasonings rich in umami. Soy sauce is made by fermenting soybeans and roasted wheat with koji mold and brine for months; Japanese styles include koikuchi (dark) and usukuchi (light), while tamari is a mostly wheat-free variety. Chinese soy sauces include light (for seasoning) and dark (aged, thicker, for color).",
    "Miso is a fermented paste of soybeans, salt, and koji, ranging from sweet white miso to strong red and dark varieties. Other fermented soy products include Chinese fermented black beans (douchi), doubanjiang (broad bean chili paste, essential in Sichuan cooking), Korean doenjang and gochujang (which contains chili and glutinous rice), and Japanese natto, sticky fermented beans with a strong flavor."]],
  ["Cooking legumes well",[
    "Good bean cooking involves soaking (optional for many beans but helpful), simmering gently rather than boiling hard to prevent splitting, and salting. Contrary to an old myth, salting the soaking or cooking water does not prevent beans from softening; in fact, brining makes skins more tender. Acidic ingredients like tomatoes and vinegar, however, slow softening, so they are often added later.",
    "Pressure cookers cook beans dramatically faster. Old beans may never soften fully, as they become harder with storage. Flavoring with aromatics, a bay leaf, garlic, or a ham hock, turns humble beans into celebrated dishes like cassoulet, feijoada, and red beans and rice."]]
  ],
  terms:[["Legume","A plant of the pea family bearing seeds in pods."],["Pulse","The dried edible seed of a legume."],["Nitrogen fixation","Converting nitrogen from air into a form usable by plants, done by bacteria on legume roots."],["Dal","Split pulses, and dishes made from them, in South Asia."],["Tofu","Coagulated soy milk pressed into blocks."],["Miso","A Japanese fermented paste of soybeans, salt, and koji."],["Aquafaba","The liquid from cooked chickpeas, usable as an egg-white substitute."]],
  w:"Legumes are nutritious, sustainable, and central to cuisines worldwide, and soy alone has generated an entire culinary universe.",
  src:["Legume","Pulse (legume)","Soybean","Tofu","Soy sauce","Miso"],
  q:[["Why do farmers rotate legumes with grains?","Legume roots host bacteria that fix nitrogen, enriching soil","Legumes repel all insects","Legumes need no water","They grow underground"],
     ["Why must raw kidney beans be boiled vigorously?","To destroy a natural toxin","To remove color","To add salt","To soften the pods"],
     ["Which country is the world's largest producer and consumer of pulses?","India","Brazil","China","Canada"],
     ["Tofu is made by…","Coagulating soy milk","Fermenting wheat","Drying soybeans","Mixing chickpeas and water"],
     ["What does salting the cooking water do to beans?","Helps make skins tender; it does not prevent softening","Makes them hard forever","Turns them purple","Has no effect at all"],
     ["Doubanjiang is essential in which cuisine?","Sichuan","Japanese","French","Mexican"]]},

{ t:"Vegetables and Fruits", s:"Choosing, storing, and cooking produce",
  sec:[
  ["Botany in the kitchen",[
    "Cooks and botanists classify produce differently. Botanically, a fruit is the seed-bearing structure of a flowering plant, so tomatoes, cucumbers, eggplants, peppers, squash, and beans are fruits. Culinarily, 'vegetables' are savory plant parts, and 'fruits' are sweet. In 1893, the US Supreme Court ruled in Nix v. Hedden that tomatoes should be taxed as vegetables, based on common usage.",
    "Vegetables come from every part of the plant: roots (carrots, beets), tubers (potatoes), bulbs (onions, garlic), stems (asparagus, celery), leaves (lettuce, spinach, cabbage), flowers (broccoli, cauliflower, artichokes), fruits (tomatoes, peppers), and seeds (peas, corn). Each part behaves differently in cooking."]],
  ["Seasonality and selection",[
    "Fresh produce varies in quality with the season. Seasonal, local produce is often picked riper and tastes better. Selection tips include choosing heavy, firm produce without bruises, fragrant fruit, and bright, crisp greens.",
    "Some fruits are climacteric: they continue ripening after picking, producing ethylene gas, including bananas, avocados, tomatoes, apples, pears, and peaches. Non-climacteric fruits, such as citrus, grapes, strawberries, and cherries, do not ripen further after picking. Storing ethylene-producing fruits near sensitive produce can speed ripening or spoilage."]],
  ["Storage",[
    "Most vegetables keep best cold and humid, in the crisper drawer. Exceptions include tomatoes (refrigeration dulls their flavor), potatoes and onions (cool, dark, dry places, kept apart), garlic, winter squash, bananas, and basil (which blackens in the cold). Herbs keep well stem-down in water like flowers or wrapped in damp paper towels.",
    "Cut produce oxidizes; enzymatic browning in apples, avocados, and potatoes can be slowed with acid, cold water, or reduced air exposure. Freezing preserves many vegetables well, especially if blanched first to deactivate enzymes."]],
  ["Cooking vegetables",[
    "Cooking softens vegetables by breaking down pectin and other cell-wall components, and changes color: green chlorophyll turns olive-drab with prolonged cooking or acid, while baking soda keeps it bright but makes vegetables mushy. Blanching, briefly boiling then plunging into ice water ('shocking'), sets bright color and stops cooking.",
    "Roasting at high heat concentrates sugars and browns vegetables, transforming Brussels sprouts, cauliflower, and carrots. Sautéing, stir-frying, grilling, braising, and steaming each produce different results. Many vegetables, like cabbage and onions, become sweeter with long cooking, while others, like broccoli, can develop sulfurous smells when overcooked."]],
  ["Potatoes and alliums",[
    "The potato, domesticated in the Andes of Peru and Bolivia around 8,000 years ago, spread worldwide after the Columbian exchange and became a staple in Europe. Ireland's dependence on a few potato varieties contributed to the catastrophe of the Great Famine (1845–1852), when potato blight struck. Floury potatoes (russet, Maris Piper) are best for baking, mashing, and fries; waxy potatoes (fingerlings, new potatoes) for salads and boiling.",
    "Alliums, onions, garlic, leeks, shallots, scallions, and chives, are among the most used flavorings in the world. Cutting them releases sulfur compounds; the tear-inducing compound in onions (syn-propanethial-S-oxide) forms when cells are damaged. Cooking onions slowly converts their sharpness into sweetness."]],
  ["Fruits in cooking",[
    "Fruits are used in desserts, preserves, and savory dishes: apples with pork, apricots in Moroccan tagines, mango in salsas, citrus in marinades, and pomegranate in Persian stews like fesenjan. Pectin, found in fruit cell walls, especially in apples, quinces, and citrus peel, forms the gel in jams when combined with sugar and acid.",
    "Citrus zest contains aromatic oils and is used widely; the white pith beneath is bitter. Tropical fruits like papaya and pineapple contain enzymes (papain and bromelain) that break down proteins, which is why fresh pineapple prevents gelatin from setting and why these fruits are used in meat tenderizers."]]
  ],
  terms:[["Climacteric fruit","Fruit that continues ripening after harvest, producing ethylene."],["Ethylene","A gas that triggers ripening in fruits."],["Blanching","Briefly boiling food, then cooling it quickly."],["Chlorophyll","The green pigment in plants, which dulls with long cooking or acid."],["Pectin","A substance in fruit cell walls that gels with sugar and acid."],["Allium","The onion family, including garlic, leeks, and shallots."]],
  w:"Choosing, storing, and cooking produce well is fundamental to flavor, nutrition, and seasonal cooking.",
  src:["Vegetable","Fruit","Climacteric (botany)","Blanching (cooking)","Potato","Allium"],
  q:[["Botanically, a tomato is…","A fruit","A root","A stem","A leaf"],
     ["Which fruit continues ripening after picking?","Banana","Orange","Grape","Strawberry"],
     ["Why should tomatoes usually not be refrigerated?","Cold dulls their flavor","They explode","They turn blue","They become poisonous"],
     ["What does 'shocking' vegetables after blanching do?","Stops cooking and sets color","Adds salt","Makes them softer","Removes vitamins"],
     ["The potato was domesticated in…","The Andes","Ireland","China","Egypt"],
     ["Why does fresh pineapple prevent gelatin from setting?","It contains an enzyme that breaks down proteins","It is too sweet","It contains too much water","It is too acidic only"]]},

{ t:"Herbs and Spices", s:"The aromatic engines of flavor",
  sec:[
  ["Herbs versus spices",[
    "Herbs are the leaves of plants, used fresh or dried; spices are other aromatic parts, such as seeds (cumin, coriander, mustard), bark (cinnamon), roots and rhizomes (ginger, turmeric), flower buds (cloves), stigmas (saffron), fruits and berries (black pepper, allspice, chili, vanilla pods), and arils (mace). Some plants provide both: coriander's leaves (cilantro) are an herb and its seeds a spice.",
    "Their aromas come from volatile compounds, such as the eugenol in cloves, cinnamaldehyde in cinnamon, and linalool in coriander and basil. Some people perceive cilantro as soapy, a trait partly linked to genetic variation in smell receptors."]],
  ["Essential herbs",[
    "Mediterranean herbs include basil, oregano, thyme, rosemary, sage, marjoram, parsley, bay leaf, and mint. Herbes de Provence is a dried blend of herbs from southern France; a bouquet garni is a bundle of herbs (typically parsley, thyme, and bay) tied together to flavor stocks and stews, removed before serving. Fines herbes, a delicate French blend, includes parsley, chives, tarragon, and chervil.",
    "Asian and Latin American cooking rely on cilantro, Thai basil, holy basil, mint, culantro, Vietnamese coriander, lemongrass, kaffir (makrut) lime leaves, curry leaves (essential in South Indian cooking), shiso, and epazote (used with beans in Mexico). Fresh herbs often provide the final bright note of a dish."]],
  ["The spice trade",[
    "Spices drove world history. Black pepper from India's Malabar Coast, cinnamon from Sri Lanka, and cloves, nutmeg, and mace from the Maluku (Molucca) Islands in Indonesia, the original 'Spice Islands', were carried by Arab, Indian, and later European traders. Roman sources record a large spice trade with India, and in the Middle Ages, Venice grew rich as a hub of spice distribution.",
    "The desire to bypass intermediaries in the spice trade motivated Portuguese and Spanish voyages, including Vasco da Gama's arrival in India in 1498 and Columbus's voyages. The Dutch East India Company (VOC), founded in 1602, violently monopolized nutmeg and cloves, including a brutal conquest of the Banda Islands in 1621. Spices were once so valuable that nutmeg could fetch enormous markups in European markets."]],
  ["Key spices",[
    "Black pepper, the 'king of spices', is the most traded spice. Cumin, coriander, turmeric, and chili form the backbone of many Indian and Middle Eastern dishes. Saffron, the stigmas of the crocus flower, is the most expensive spice by weight, as each flower yields only three stigmas, picked by hand; it colors and flavors paella, risotto alla milanese, and Persian rice.",
    "Vanilla, from the cured pods of a Mexican orchid, is the second most expensive spice. It was pollinated naturally only in Mexico until 1841, when Edmond Albius, a 12-year-old enslaved boy on the island of Réunion, invented a fast hand-pollination method still used today, enabling vanilla's global cultivation. Other important spices include cinnamon (true Ceylon cinnamon and the more common cassia), star anise, cardamom, cloves, nutmeg, paprika, and sumac."]],
  ["Spice blends",[
    "Cuisines around the world have characteristic blends. India has garam masala and countless regional masalas (Indian cooks rarely use a single 'curry powder', a British invention). China has five-spice powder (often star anise, cloves, cinnamon or cassia, Sichuan pepper, and fennel seed). The Middle East has za'atar (wild thyme, sumac, and sesame), baharat, and ras el hanout from Morocco, which may contain dozens of spices.",
    "Ethiopia has berbere (a fiery blend of chilies and spices) and mitmita; France has quatre épices; the Caribbean has jerk seasoning with allspice and Scotch bonnet chilies; and Mexico has a vast tradition of chile-based moles, combining dried chilies, spices, nuts, seeds, and sometimes chocolate."]],
  ["Using herbs and spices",[
    "Buy whole spices when possible and grind them as needed, as ground spices lose aroma within months. Toast whole spices in a dry pan to deepen their flavor, or bloom them in hot oil, as in Indian tadka, since many aroma compounds dissolve in fat. Add hardy herbs early and tender herbs late.",
    "Dried herbs are more concentrated than fresh; a common substitution is one part dried to three parts fresh. Store spices in airtight containers away from light and heat. Building a well-stocked, fresh spice collection opens up the world's cuisines."]]
  ],
  terms:[["Herb","The aromatic leaves of a plant used in cooking."],["Spice","Aromatic seeds, bark, roots, buds, or fruits used in cooking."],["Bouquet garni","A bundle of herbs used to flavor stocks and stews."],["Spice Islands","The Maluku Islands of Indonesia, origin of cloves, nutmeg, and mace."],["Garam masala","A warm Indian spice blend."],["Za'atar","A Middle Eastern blend of wild thyme, sumac, and sesame."]],
  w:"Herbs and spices give cuisines their identity and changed world history through the spice trade.",
  src:["Spice","Herb","Spice trade","Saffron","Vanilla","Edmond Albius"],
  q:[["Coriander seeds are a spice; coriander leaves (cilantro) are…","An herb","A root","A fruit","A spice too"],
     ["The original 'Spice Islands' are…","The Maluku Islands in Indonesia","The Canary Islands","Sri Lanka","Zanzibar"],
     ["Why is saffron so expensive?","Each flower yields only three stigmas picked by hand","It grows only underwater","It is a rare mineral","It must be aged for decades"],
     ["Who invented the hand-pollination method for vanilla in 1841?","Edmond Albius","Vasco da Gama","Christopher Columbus","Marco Polo"],
     ["'Curry powder' as a single blend is largely…","A British invention","An ancient Chinese spice","A Mexican mole","A French blend"],
     ["What is a common substitution ratio of dried to fresh herbs?","One part dried to three parts fresh","Equal amounts","Ten parts dried to one fresh","Dried herbs cannot substitute"]]}

]});


/* ---- from cuisine-04.js ---- */
/* CUISINE FOUNDATIONS, part 4: Unit 2 Ingredients, chapters 6-10 */
COURSES.cuisine.units[1].ch.push(

{ t:"Meat and Butchery", s:"Beef, pork, lamb, and how to cook each cut",
  sec:[
  ["What meat is",[
    "Meat is mostly muscle tissue: about 75 percent water, 20 percent protein, and varying fat. Muscle fibers are bundled by connective tissue made of collagen and elastin. Muscles that work hard, like legs, shoulders, and necks, have more connective tissue and flavor but are tougher; muscles that do little work, like the tenderloin along the spine, are tender but milder.",
    "This leads to the basic rule of meat cookery: tender cuts suit fast, dry, high-heat cooking (grilling, searing, roasting), while tough cuts suit slow, moist cooking (braising, stewing, smoking) that converts collagen to gelatin. Marbling, intramuscular fat, adds flavor and juiciness and is prized in grading systems."]],
  ["Beef",[
    "Beef carcasses are divided into primal cuts, which differ by country. In American butchery, the rib gives ribeye and prime rib; the short loin gives strip steaks, T-bones, porterhouses, and the tenderloin (filet mignon); the sirloin gives sirloin steaks; the chuck (shoulder) gives pot roasts and ground beef; the brisket and plate give brisket and short ribs; and the round (rear leg) gives lean roasts. The flank gives flank steak.",
    "Beef grading in the US (by the USDA) includes Prime, Choice, and Select, based mainly on marbling and age. Japan's Wagyu breeds are famous for extreme marbling, with Kobe beef, from Tajima-strain cattle raised in Hyōgo Prefecture, the best known. Dry aging, holding beef in controlled cold, dry conditions for weeks, concentrates flavor and tenderizes through enzymes."]],
  ["Pork",[
    "Pork is the most widely eaten meat in the world, central to Chinese, European, and many other cuisines, though forbidden in Islam and Judaism. Major cuts include the shoulder (Boston butt and picnic), ideal for pulled pork and braises; the loin, giving chops and roasts, and the tenderloin; the belly, used for bacon, Chinese red-braised pork, and Korean samgyeopsal; and the leg, for ham.",
    "Modern pork is leaner than in the past, so it can dry out; US guidelines lowered the recommended temperature for whole cuts to 63°C (145°F) with a rest in 2011, allowing slightly pink, juicier pork. Heritage breeds like Berkshire (Kurobuta) and Iberian pigs offer richer flavor."]],
  ["Lamb, goat, and others",[
    "Lamb is meat from sheep under about a year old; mutton is from older sheep and has a stronger flavor. Lamb is important in the Middle East, North Africa, South Asia, Greece, Britain, Australia, and New Zealand. Cuts include the rack, loin chops, leg (often roasted whole), and shoulder and shanks for braising.",
    "Goat is the most widely eaten red meat in parts of Africa, South Asia, the Caribbean, and Latin America, as in Jamaican curry goat and Mexican birria. Other meats include veal (young cattle), venison and other game, rabbit, and, in different cultures, horse, camel, and guinea pig (cuy, a traditional Andean food)."]],
  ["Butchery and whole-animal cooking",[
    "Butchery is the skill of breaking down animals into cuts. Different traditions cut differently: French butchery follows muscle seams more closely, producing cuts like the bavette and onglet (hanger steak). Nose-to-tail eating, promoted by British chef Fergus Henderson in 'Nose to Tail Eating' (1999), uses the whole animal, including offal (organ meats) such as liver, kidneys, heart, tongue, tripe, and sweetbreads.",
    "Offal is prized in many cuisines: French foie gras and andouillette, Scottish haggis, Mexican tacos de lengua, Italian lampredotto, Chinese braised intestines, and Filipino dinuguan. Using the whole animal reduces waste and honors traditional cooking."]],
  ["Cooking meat well",[
    "Key techniques include bringing meat closer to room temperature before cooking thick cuts (though this matters less than often claimed), seasoning in advance, searing for flavor, using a thermometer, and resting meat after cooking so juices redistribute and carryover cooking finishes. Slicing against the grain, across muscle fibers, makes meat more tender to chew.",
    "The 'reverse sear', cooking thick steaks slowly in a low oven and then searing, gives even doneness. Marinades flavor the surface; acidic marinades can make meat mushy if left too long. Salting or brining helps lean meats stay juicy. Understanding the cut is the key to choosing the right method."]]
  ],
  terms:[["Primal cut","A large section into which a carcass is first divided."],["Marbling","Fat within the muscle, adding flavor and juiciness."],["Dry aging","Holding meat in cold, dry conditions to concentrate flavor and tenderize."],["Offal","Organ meats such as liver, heart, and tripe."],["Against the grain","Slicing across muscle fibers to make meat tender to chew."],["Nose-to-tail","Using the whole animal in cooking."]],
  w:"Matching each cut of meat to the right cooking method is a fundamental skill of the cook.",
  src:["Meat","Cut of beef","Cut of pork","Wagyu","Dry-aged beef","Offal"],
  q:[["Which cuts suit slow, moist cooking?","Tough, hard-working muscles like the shoulder","The tenderloin","Thin fish fillets","All steaks"],
     ["Which part of the cow gives filet mignon?","The tenderloin","The chuck","The brisket","The round"],
     ["Kobe beef comes from which Japanese prefecture?","Hyōgo","Hokkaido","Okinawa","Kyoto"],
     ["What did US guidelines change about pork in 2011?","Lowered whole-cut temperature to 63°C (145°F) with rest","Banned pink pork","Raised it to 90°C","Required freezing"],
     ["Who promoted 'nose to tail eating'?","Fergus Henderson","Anthony Bourdain","Gordon Ramsay","Alice Waters"],
     ["Why slice meat against the grain?","It shortens muscle fibers, making it tender to chew","It looks prettier only","It cooks faster","It removes fat"]]},

{ t:"Poultry and Eggs", s:"The world's most versatile proteins",
  sec:[
  ["Chicken",[
    "Chicken was domesticated from the red junglefowl of Southeast Asia, probably several thousand years ago, and originally may have been kept as much for cockfighting and ritual as for food. Today it is the most widely produced meat in the world by number of animals, with tens of billions of chickens raised each year, and it is eaten in almost every culture.",
    "White meat (breast) comes from muscles used little and is lean; dark meat (thighs, legs) comes from muscles used for standing and walking, which contain more myoglobin, fat, and connective tissue, making them more flavorful and forgiving to cook. Spatchcocking, removing the backbone and flattening the bird, helps it cook quickly and evenly."]],
  ["Other poultry",[
    "Ducks have rich, dark meat and a thick layer of fat beneath the skin, rendered to crisp the skin. Famous duck dishes include Peking duck (with lacquered crispy skin, served with pancakes), French duck confit and magret (the breast of ducks raised for foie gras), and Cantonese roast duck. Goose is traditional for Christmas in parts of Europe.",
    "Turkey, domesticated in Mexico, is central to American Thanksgiving. Its large size makes even cooking a challenge, since breast meat is done before leg meat; solutions include brining, spatchcocking, and cooking parts separately. Other poultry includes quail, pigeon (squab), guinea fowl, and pheasant."]],
  ["Cooking poultry",[
    "Roast chicken is a test of a cook's skill. Crisp skin comes from dry skin (air-drying in the refrigerator helps), salt, and high heat. Brining in salt water or dry-brining with salt improves juiciness. Thighs are done at higher temperatures than breasts; many cooks prefer dark meat at around 80°C or more for tenderness.",
    "Poultry is used in countless dishes: French coq au vin, Indian butter chicken, Japanese yakitori and karaage, Korean fried chicken, American fried chicken, Jamaican jerk chicken, Peruvian pollo a la brasa, and Chinese white-cut chicken. Chicken stock, made from bones and carcasses, is a foundation of many cuisines."]],
  ["The egg",[
    "An egg consists of the shell, the white (albumen, about 90 percent water and the rest protein), and the yolk (containing fats, proteins, lecithin, and most of the vitamins). Egg proteins coagulate at different temperatures: whites begin setting at about 62–65°C and yolks around 65–70°C, which is why soft-boiled eggs can have firm whites and runny yolks.",
    "Eggs perform many functions in cooking: binding (meatballs), leavening (whipped whites in soufflés and meringues), emulsifying (mayonnaise, hollandaise), thickening (custards), glazing (egg wash), and clarifying (egg whites trap impurities in consommé)."]],
  ["Egg techniques",[
    "Classic egg preparations include boiled (soft, medium, or hard), poached (cracked into simmering water; fresher eggs hold their shape better), fried (sunny-side up or over easy), scrambled (cooked gently for soft curds, or more firmly), and omelets (the French style is pale, smooth, and rolled; the American style is folded and browned). The Japanese tamagoyaki is a rolled, layered omelet.",
    "Whipped egg whites form a foam as proteins unfold around air bubbles; a copper bowl, a little acid like cream of tartar, and the absence of fat help stabilize the foam. Overwhipped whites become grainy. Custards (crème anglaise, crème brûlée, flan) cook egg yolks gently with milk or cream; too much heat curdles them."]],
  ["Egg safety and grades",[
    "Raw eggs can carry Salmonella. Many countries treat this differently: in the US, eggs are washed and must be refrigerated, while in the UK and much of Europe, hens are commonly vaccinated against Salmonella and eggs are not washed, preserving the protective cuticle, so they can be stored at room temperature. Pasteurized eggs are available for raw preparations.",
    "Egg freshness can be checked by placing an egg in water: fresh eggs sink and lie flat, while older eggs stand up or float as the air cell inside enlarges. Shell color depends on hen breed, not nutrition. Labels such as free-range, cage-free, and pasture-raised describe hen welfare and vary by country."]]
  ],
  terms:[["Myoglobin","A protein in muscle that stores oxygen and makes meat darker."],["Spatchcock","Removing a bird's backbone to flatten it for even cooking."],["Albumen","The egg white."],["Coagulation","Proteins setting when heated."],["Meringue","Whipped egg whites and sugar."],["Custard","A mixture of eggs and milk or cream thickened by gentle heat."]],
  w:"Poultry and eggs are everyday staples whose versatility makes them essential to master.",
  src:["Chicken as food","Peking duck","Egg as food","Turkey as food","Custard","Meringue"],
  q:[["Chicken was domesticated from…","The red junglefowl","The wild turkey","The pheasant","The guinea fowl"],
     ["Why is dark meat more flavorful?","It comes from muscles with more myoglobin, fat, and connective tissue","It is cooked longer","It has more sugar","It is aged"],
     ["Turkey was domesticated in…","Mexico","Turkey","China","England"],
     ["Which part of an egg sets at a lower temperature?","The white","The yolk","The shell","The air cell"],
     ["Why are UK eggs often stored unrefrigerated?","Hens are vaccinated and eggs are not washed","They are boiled first","The UK is cold","They are coated in wax"],
     ["How can you check an egg's freshness?","Fresh eggs sink and lie flat in water","Fresh eggs float","Shake it loudly","Look at shell color"]]},

{ t:"Fish and Seafood", s:"From the sea to the plate",
  sec:[
  ["Why fish is different",[
    "Fish muscle differs from land animals' muscle. Fish live in water, supported by buoyancy, so their muscles have little connective tissue; collagen in fish breaks down at lower temperatures. This makes fish cook quickly and flake easily, and makes it easy to overcook. Most fish is done at around 50–60°C internally.",
    "Fish fats are often rich in omega-3 fatty acids, especially in oily fish like salmon, mackerel, sardines, herring, and anchovies. These fats oxidize quickly, contributing to fishy smells, so freshness is crucial. Fresh fish should smell of the sea, not 'fishy', with bright, clear eyes, red gills, and firm flesh."]],
  ["Types of fish",[
    "Cooks group fish by fat content and texture. Lean white fish include cod, haddock, halibut, sole, flounder, sea bass, and snapper, with mild flavor and delicate flakes. Oily fish include salmon, tuna, mackerel, sardines, and herring, with rich flavor. Flatfish (sole, plaice, turbot, halibut) swim on their sides with both eyes on one side; round fish swim upright.",
    "Freshwater fish include trout, carp (important in China and Central Europe), tilapia, catfish, and pike. Many cuisines also prize fish roe: caviar (sturgeon roe), salmon roe (ikura), and mullet roe (bottarga)."]],
  ["Shellfish",[
    "Shellfish include crustaceans (shrimp, prawns, crabs, lobsters, crayfish) and mollusks: bivalves (oysters, clams, mussels, scallops) and cephalopods (squid, octopus, cuttlefish). Crustaceans turn red when cooked as heat frees the pigment astaxanthin from proteins.",
    "Live bivalves should be tightly closed or close when tapped; discard any that stay open before cooking. Squid and octopus must be cooked either very briefly (a minute or two) or for a long time (an hour or more) to avoid toughness. Oysters are often eaten raw; their flavor reflects their waters, like wine's terroir."]],
  ["Cooking fish",[
    "Fish suits many methods: pan-searing (skin-side down for crisp skin), roasting, grilling (whole fish or firm steaks), poaching (in court-bouillon, an aromatic broth), steaming (classic in Chinese cuisine, often with ginger and scallions), frying (fish and chips, tempura), and en papillote (baked in parchment so it steams in its own juices).",
    "Raw and cured fish are central to many cuisines: Japanese sashimi and sushi, Peruvian ceviche (marinated in lime juice), Hawaiian poke, Scandinavian gravlax (cured with salt, sugar, and dill), and smoked salmon. Fish for raw consumption is often frozen first to kill parasites, as required in some jurisdictions."]],
  ["Preserved fish",[
    "Before refrigeration, fish was preserved by drying, salting, smoking, and fermenting. Salt cod (bacalhau in Portugal, baccalà in Italy) and dried stockfish fed Europe and its colonies; Portugal is said to have 365 ways to cook bacalhau. Pickled and smoked herring sustained northern Europe.",
    "Fermented fish products include fish sauce (nuoc mam in Vietnam, nam pla in Thailand), Roman garum (a similar fermented sauce), Swedish surströmming (fermented herring, famously pungent), and Japanese katsuobushi (dried, smoked, fermented skipjack tuna, shaved into flakes for dashi). Anchovies, salted and packed in oil, add umami to many dishes."]],
  ["Sustainability",[
    "Many of the world's fish stocks are overfished. According to the UN Food and Agriculture Organization's assessments, roughly a third of assessed marine fish stocks are fished at biologically unsustainable levels. The collapse of the Grand Banks cod fishery off Newfoundland, which led to a moratorium in 1992, is a famous example.",
    "Aquaculture (fish farming) now supplies about half of the seafood humans eat, with benefits and concerns, such as pollution, disease, and use of wild fish for feed. Consumers can use guides such as the Monterey Bay Aquarium's Seafood Watch and certifications like the Marine Stewardship Council (MSC) to choose more sustainable options."]]
  ],
  terms:[["Omega-3 fatty acids","Healthy fats abundant in oily fish."],["Flatfish","Fish that swim on their sides with both eyes on one side."],["Bivalve","A mollusk with two hinged shells, such as an oyster or clam."],["Cephalopod","A mollusk like squid or octopus."],["En papillote","Cooking food sealed in parchment."],["Aquaculture","The farming of fish and other aquatic organisms."]],
  w:"Fish and seafood are delicate and diverse, and buying and cooking them well requires knowledge of freshness, technique, and sustainability.",
  src:["Fish as food","Seafood","Shellfish","Ceviche","Fish sauce","Overfishing"],
  q:[["Why does fish cook quickly and flake easily?","It has little connective tissue","It contains more water than meat","It is always thin","It is cooked colder"],
     ["Which of these is an oily fish?","Mackerel","Cod","Sole","Haddock"],
     ["Why do crustaceans turn red when cooked?","Heat frees the pigment astaxanthin","They absorb tomato","Their blood boils","They are painted"],
     ["How should squid be cooked to avoid toughness?","Very briefly or for a long time","For exactly ten minutes","Only frozen","Never cooked"],
     ["Katsuobushi is…","Dried, smoked, fermented skipjack tuna","A type of seaweed","Fermented herring","Salted cod"],
     ["The Grand Banks cod fishery moratorium began in…","1992","1950","2010","1900"]]},

{ t:"Dairy and Cheese", s:"Milk, butter, yogurt, and the art of cheese",
  sec:[
  ["Milk",[
    "Humans in many parts of the world have consumed the milk of cattle, sheep, goats, water buffalo, yaks, camels, and horses for thousands of years. Most adult mammals lose the ability to digest lactose (milk sugar), but some human populations, especially in northern Europe, East Africa, and parts of the Middle East, evolved lactase persistence, the ability to digest lactose into adulthood. Globally, however, most adults have reduced lactose digestion.",
    "Milk is an emulsion of fat globules in water containing proteins (mainly casein and whey), lactose, and minerals. Homogenization breaks fat globules into tiny particles so cream does not rise to the top. Fermentation and cheesemaking reduce lactose, which is why many lactose-intolerant people can eat aged cheese and yogurt."]],
  ["Cream and butter",[
    "Cream is the fat-rich portion of milk. Types differ in fat content: in the US, light cream, heavy (whipping) cream around 36%; in the UK, single, double (about 48%), and clotted cream. Higher-fat creams whip better and are less likely to curdle in sauces. Crème fraîche and sour cream are cultured creams.",
    "Butter is made by churning cream until fat globules clump, leaving buttermilk. It is about 80% fat in most countries, with European-style butters often slightly higher. Cultured butter is made from fermented cream for tangier flavor. Clarified butter has the milk solids and water removed, raising its smoke point; ghee, used in South Asia, is clarified butter cooked until the milk solids brown, giving a nutty flavor. Beurre noisette (brown butter) has a similar flavor."]],
  ["Fermented milk",[
    "Yogurt is milk fermented by bacteria, typically Lactobacillus delbrueckii subsp. bulgaricus and Streptococcus thermophilus, which convert lactose into lactic acid, thickening the milk. Strained yogurt (Greek yogurt, labneh) is thicker. Other fermented milks include kefir (fermented with a mix of yeasts and bacteria), Indian dahi, Icelandic skyr (technically a fresh cheese), and buttermilk.",
    "Fermented milks have long been ways to preserve milk in hot climates. Yogurt is used in marinades (tandoori chicken), sauces (tzatziki, raita), and drinks (lassi, ayran, doogh)."]],
  ["How cheese is made",[
    "Cheese is concentrated milk. Cheesemakers acidify milk with bacterial cultures, then add rennet, an enzyme traditionally from calves' stomachs (now often microbial), which coagulates casein into curds. The curds are cut, sometimes cooked, drained of whey, salted, shaped, and aged. Each step changes the final cheese.",
    "Factors that create cheese diversity include the type of milk, whether it is raw or pasteurized, the cultures and molds used, curd treatment, size, salting, and aging conditions. Over time, enzymes and microbes break down proteins and fats into complex flavors. There are hundreds of named cheeses in France alone; Charles de Gaulle reportedly asked how one could govern a country with 246 kinds of cheese."]],
  ["Families of cheese",[
    "Fresh cheeses, unaged, include ricotta, mozzarella (traditionally from water buffalo milk in Campania), feta, paneer, and cottage cheese. Soft-ripened cheeses like Brie and Camembert develop a white bloomy rind of Penicillium candidum mold. Washed-rind cheeses like Époisses and Taleggio are rubbed with brine, developing pungent orange rinds.",
    "Semi-hard and hard cheeses include Cheddar (named after a village in Somerset, made by 'cheddaring', stacking curds), Gruyère, Comté, Emmental (with holes from carbon dioxide produced by bacteria), Manchego (sheep's milk), and Parmigiano-Reggiano, aged at least 12 months, often 24 or more. Blue cheeses like Roquefort (sheep's milk, aged in caves in France), Gorgonzola, and Stilton are pierced to let Penicillium roqueforti grow inside."]],
  ["Protected cheeses and cooking with cheese",[
    "Many traditional cheeses have protected designations, such as the EU's PDO (Protected Designation of Origin), ensuring they are made in specific regions by traditional methods. Roquefort received legal protection in France in 1925, making it one of the earliest protected foods. Parmigiano-Reggiano, Comté, and Stilton are also protected.",
    "Cheese behaves differently when cooked. Young, moist cheeses like mozzarella melt and stretch; aged cheeses like Parmesan grate finely and add umami but can become grainy; cheeses like halloumi and paneer resist melting and can be grilled or fried. Fondue and raclette show the Swiss love of melted cheese; a little acid (wine) and starch help keep fondue smooth."]]
  ],
  terms:[["Lactase persistence","The ability to digest lactose into adulthood."],["Casein","The main protein in milk, which forms cheese curds."],["Rennet","An enzyme that coagulates milk for cheesemaking."],["Ghee","Clarified butter cooked until milk solids brown, used in South Asia."],["Curds and whey","The solid and liquid parts of coagulated milk."],["PDO","Protected Designation of Origin, an EU label for regional products."]],
  w:"Dairy, and cheese in particular, represents one of humanity's oldest and most diverse food crafts.",
  src:["Milk","Lactase persistence","Butter","Yogurt","Cheese","Protected designation of origin"],
  q:[["What is lactase persistence?","The ability to digest lactose as an adult","A type of cheese","Milk that never spoils","A bacteria in yogurt"],
     ["Ghee is…","Clarified butter cooked until the milk solids brown","Fermented cream","A fresh cheese","Sour milk"],
     ["What does rennet do in cheesemaking?","Coagulates milk proteins into curds","Adds color","Removes fat","Creates holes"],
     ["Which mold gives Brie its white rind?","Penicillium candidum","Penicillium roqueforti","Aspergillus oryzae","Lactobacillus"],
     ["Why does Emmental have holes?","Bacteria produce carbon dioxide","It is drilled","Air is whipped in","Mice eat it"],
     ["Which cheese received legal protection in France in 1925?","Roquefort","Camembert","Brie","Comté"]]},

{ t:"Fats, Oils, Sugar, and Chocolate", s:"Richness and sweetness",
  sec:[
  ["Cooking fats",[
    "Fats used in cooking include animal fats (butter, lard, tallow, duck and goose fat, schmaltz) and plant oils. Their character depends on their fatty acids: saturated fats like butter, lard, and coconut oil are solid at room temperature; unsaturated oils like olive, canola, and sunflower are liquid. Fats give flavor, carry heat, and create texture.",
    "Choosing a fat depends on the cooking method and cuisine. High-heat searing and deep frying need fats with high smoke points, like refined peanut, canola, or rice bran oil. Flavorful fats like butter, extra-virgin olive oil, and toasted sesame oil are often used at lower temperatures or to finish dishes."]],
  ["Olive oil",[
    "Olive oil has been central to Mediterranean life for thousands of years, used for food, light, medicine, and religious ritual. Extra-virgin olive oil is mechanically extracted without heat or chemicals and must meet standards for low acidity and absence of defects; it has fruity, peppery, bitter notes from polyphenols. Spain is the largest producer, followed by countries including Italy, Greece, and Tunisia.",
    "Contrary to a common myth, good extra-virgin olive oil can be used for most everyday cooking, including sautéing, as its smoke point is moderate and its antioxidants protect it. However, its delicate flavors are best appreciated raw, drizzled over finished dishes."]],
  ["Other oils",[
    "Different cuisines rely on different oils: sesame oil (toasted for flavor in East Asia, untoasted in South India), mustard oil (pungent, used in Bengal and Punjab), coconut oil (Kerala, Southeast Asia), peanut oil (Chinese stir-frying and Southern US frying), palm oil (West Africa, where red palm oil gives dishes color and flavor), and avocado, walnut, and pumpkin seed oils.",
    "Oils go rancid as their fats oxidize, especially unsaturated oils exposed to light, heat, and air; store them in cool, dark places. Reusing frying oil many times degrades it. Industrial trans fats from partial hydrogenation have been phased out in many countries for health reasons."]],
  ["Sugar",[
    "Sugar cane, native to New Guinea, was first processed into crystalline sugar in India, perhaps around the early centuries CE; the word 'sugar' derives from Sanskrit śarkarā. Arab traders spread sugar to the Mediterranean. From the 16th century, European colonizers established sugar plantations in the Caribbean and Brazil using enslaved African labor, a brutal system that shaped the Atlantic world. Sidney Mintz's 'Sweetness and Power' (1985) traces this history.",
    "In the 19th century, Europeans developed sugar from sugar beets. Sugars used in cooking include white (granulated, caster or superfine, powdered or icing), brown (with molasses), raw sugars like demerara and turbinado, unrefined sugars like jaggery (India), panela (Latin America), and palm sugar (Southeast Asia), plus honey, maple syrup, and corn syrup."]],
  ["Sugar's roles",[
    "Sugar does far more than sweeten. It tenderizes baked goods by interfering with gluten and egg protein coagulation, retains moisture, helps browning, feeds yeast, stabilizes whipped egg whites in meringues, and preserves jams by binding water so microbes cannot grow. In savory cooking, a little sugar balances acidity and bitterness.",
    "Sugar syrups change as they are boiled and water evaporates, passing through stages measured by temperature: soft ball (about 112–116°C) for fudge, hard ball, soft crack, hard crack (about 146–154°C) for brittle and lollipops, and finally caramel (around 160°C and above). Candy thermometers make these stages precise."]],
  ["Chocolate",[
    "Chocolate comes from the seeds of the cacao tree, native to the Americas. Recent evidence suggests cacao was used in the upper Amazon of Ecuador over 5,000 years ago, and the Olmec, Maya, and Aztecs prepared it as a bitter, frothy drink, often with chili; the Aztecs used cacao beans as currency. The Spanish brought chocolate to Europe in the 16th century, where it was sweetened.",
    "Making chocolate involves fermenting, drying, roasting, and grinding cacao beans into chocolate liquor (cacao mass), which contains cocoa solids and cocoa butter. In 1828, Coenraad van Houten patented a press to separate cocoa butter and produce cocoa powder; Joseph Fry made one of the first chocolate bars in 1847; and Daniel Peter and Henri Nestlé developed milk chocolate in Switzerland in 1875. Rodolphe Lindt invented conching in 1879, which smooths chocolate. Tempering, carefully heating and cooling chocolate to form stable cocoa butter crystals (form V), gives a glossy finish and snap."]]
  ],
  terms:[["Smoke point","The temperature at which a fat starts to smoke and break down."],["Extra-virgin olive oil","Top-grade olive oil extracted mechanically without heat or chemicals."],["Rancidity","Spoilage of fats through oxidation."],["Jaggery","Unrefined cane or palm sugar from South Asia."],["Sugar stages","Temperature-based stages of boiled sugar syrup."],["Tempering (chocolate)","Controlled heating and cooling to form stable crystals for gloss and snap."],["Conching","Long mixing and aerating of chocolate to smooth it."]],
  w:"Fats and sugars shape texture, flavor, and preservation, and their histories reveal the global forces behind everyday foods.",
  src:["Cooking oil","Olive oil","Sugar","Sweetness and Power","Chocolate","Tempering (chocolate)"],
  q:[["Which fat is solid at room temperature?","Lard","Olive oil","Canola oil","Sunflower oil"],
     ["Which country is the largest producer of olive oil?","Spain","Italy","Greece","Tunisia"],
     ["Where was crystalline sugar first produced?","India","Brazil","Cuba","France"],
     ["Who wrote 'Sweetness and Power' about sugar's history?","Sidney Mintz","Michael Pollan","Harold McGee","Mark Kurlansky"],
     ["Which ancient Mesoamerican people used cacao beans as currency?","The Aztecs","The Inca","The Olmec only","The Romans"],
     ["What does tempering chocolate achieve?","Glossy finish and snap from stable crystals","Makes it sweeter","Removes cocoa butter","Turns it into powder"]]}

);


/* ---- from cuisine-05.js ---- */
/* CUISINE FOUNDATIONS, part 5: Unit 3 Core Techniques, chapters 1-5 */
COURSES.cuisine.units.push({ t:"Core Techniques", ch:[

{ t:"Stocks, Broths, and Soups", s:"The foundations of flavor",
  sec:[
  ["What stock is",[
    "Stock is a flavorful liquid made by simmering bones, vegetables, and aromatics in water. Escoffier called stocks the foundation of French cooking ('fonds de cuisine'), and they are the base of sauces, soups, braises, and risottos in many cuisines. Broth is similar but usually made with meat rather than just bones, and is often seasoned to be eaten on its own.",
    "Bones contribute gelatin, which gives stock body and a silky mouthfeel; a good stock sets into a jelly when chilled. Meat contributes flavor; aromatics add depth. Common stocks include white stock (from raw bones, light in color), brown stock (from roasted bones and vegetables, often with tomato paste, giving deep color and flavor), fish stock or fumet (cooked briefly, about 20–30 minutes, to avoid bitterness), and vegetable stock."]],
  ["Making good stock",[
    "Start with cold water, which helps extract proteins and allows impurities to rise as scum that can be skimmed off. Bring slowly to a simmer and never boil hard, which emulsifies fat and makes stock cloudy. Chicken stock typically simmers for several hours, beef or veal stock longer. Add mirepoix and aromatics like a bouquet garni and peppercorns; salt is usually left out so stock can be reduced later.",
    "Strain stock through a fine sieve, cool it quickly, and skim off solidified fat. Reducing stock concentrates it: demi-glace, a classic French preparation, is reduced brown stock (often combined with espagnole sauce) to a rich, glossy consistency; glace de viande is reduced further to a syrup. Pressure cookers can make stock in about an hour."]],
  ["Stocks around the world",[
    "Japanese dashi is a quick stock made from kombu (kelp) and katsuobushi (bonito flakes), providing glutamates and inosinates whose combination creates a powerful umami synergy. Vegetarian dashi uses kombu and shiitake mushrooms. Dashi is the base of miso soup, simmered dishes, and noodle broths.",
    "Chinese superior stock (shang tang) combines chicken, pork, and Jinhua ham. Vietnamese pho broth simmers beef bones with charred onion, ginger, star anise, cinnamon, and cloves. Ramen broths vary from clear shio and shoyu to tonkotsu, pork bones boiled hard for hours until milky and rich with emulsified fat and collagen."]],
  ["Clear soups and consommé",[
    "Consommé is a perfectly clear, intensely flavored broth. It is clarified by simmering stock with a 'raft', a mixture of egg whites, ground meat, and vegetables. As the egg whites coagulate, they trap impurities and float to the top, forming the raft, while the meat adds flavor. The liquid is carefully ladled out through a hole in the raft.",
    "Other clear soups include French onion soup (made with deeply caramelized onions and stock, topped with bread and Gruyère), Italian brodo with tortellini, chicken noodle soup, Jewish chicken soup with matzo balls, and Thai tom yum, a hot and sour broth with lemongrass, galangal, and lime leaves."]],
  ["Thick soups",[
    "Thick soups include purées (blended vegetable soups, thickened by the vegetables themselves), cream soups (thickened with roux or cream), velouté-based soups, bisques (traditionally made with shellfish shells and thickened with rice, finished with cream), and chowders (chunky soups, often with milk, potatoes, and seafood, such as New England clam chowder).",
    "Many soups are thickened with bread (Spanish salmorejo, Italian ribollita and pappa al pomodoro), legumes (lentil and split pea soups), or grains (barley soups, congee). Gazpacho, from Andalusia, is a cold soup of raw tomatoes, peppers, cucumber, garlic, olive oil, vinegar, and bread."]],
  ["Soup as culture",[
    "Nearly every culture has iconic soups: Russian and Ukrainian borscht (beet soup; Ukraine's tradition of cooking borscht was added to UNESCO's urgent safeguarding list in 2022), Korean galbitang and kimchi jjigae, Mexican pozole (hominy with pork or chicken) and sopa de tortilla, Hungarian goulash, Moroccan harira (eaten to break the Ramadan fast), Nigerian egusi and pepper soup, and Portuguese caldo verde.",
    "Soups are economical, nourishing, and adaptable, ways to use scraps and leftovers. Mastering stock is the single most valuable step toward restaurant-quality cooking at home."]]
  ],
  terms:[["Stock","Liquid made by simmering bones, vegetables, and aromatics."],["Fumet","A quick fish stock."],["Demi-glace","A rich, reduced brown stock sauce base."],["Dashi","A Japanese stock made from kombu and bonito flakes."],["Consommé","A perfectly clear, intensely flavored broth clarified with a raft."],["Bisque","A smooth, rich soup traditionally made from shellfish."]],
  w:"Stocks and soups are the foundation of flavor in many cuisines and teach the patience of building depth.",
  src:["Stock (food)","Dashi","Consommé","Demi-glace","Soup","Borscht"],
  q:[["What gives good stock its body?","Gelatin from bones","Flour","Sugar","Cream"],
     ["Why should stock not be boiled hard?","It emulsifies fat and makes stock cloudy","It becomes too salty","It turns brown","It loses all color"],
     ["Dashi is made from…","Kombu and katsuobushi","Chicken and pork","Beef bones and star anise","Shrimp shells"],
     ["How is consommé clarified?","With a raft of egg whites, meat, and vegetables","By filtering through charcoal","By freezing","By adding vinegar"],
     ["Tonkotsu ramen broth is made by…","Boiling pork bones hard for hours","Simmering kelp briefly","Using only vegetables","Using fish only"],
     ["Which soup tradition did UNESCO add to its urgent safeguarding list in 2022?","Ukrainian borscht","French onion soup","Gazpacho","Pho"]]},

{ t:"Sauces", s:"Mother sauces and the sauces of the world",
  sec:[
  ["Why sauces matter",[
    "Sauces add moisture, flavor, richness, color, and unity to dishes. In classical French cuisine, the saucier was the most prestigious station, and sauce-making was considered the highest skill. A good sauce can turn plain grilled meat or vegetables into a memorable dish.",
    "Sauces can be thickened in several ways: with starches (roux, cornstarch slurries, beurre manié of kneaded butter and flour), by reduction (boiling off water), with emulsions (butter, egg yolks, oil), with purées (vegetables, fruits, nuts), and with gelatin from stocks."]],
  ["The French mother sauces",[
    "In the 19th century, Antonin Carême classified sauces into families; Escoffier refined the list into five 'mother sauces' from which countless others ('daughter' sauces) derive. Béchamel is milk thickened with a white roux; adding cheese makes Mornay. Velouté is light stock (chicken, veal, or fish) thickened with a blond roux; it leads to sauce suprême and allemande.",
    "Espagnole is brown stock thickened with brown roux, with tomato and mirepoix; it leads to demi-glace, and from demi-glace to sauces like bordelaise. Hollandaise is an emulsion of egg yolks and butter with lemon; its daughter, béarnaise, adds tarragon, shallots, and vinegar. Tomato sauce, made with tomatoes and aromatics, completes the five."]],
  ["Roux and reduction",[
    "Roux is cooked flour and fat, typically equal parts by weight. White roux is cooked briefly; blond roux slightly longer; brown roux until nutty and brown, with less thickening power but deeper flavor. In Cajun and Creole cooking, roux is cooked to a deep brown, sometimes nearly chocolate-colored, for gumbo.",
    "Pan sauces are made by deglazing: after searing meat, the browned bits stuck to the pan (the fond) are dissolved with wine, stock, or other liquid, then reduced and often finished with butter (monter au beurre) for gloss and richness. This quick technique is one of the most useful in any kitchen."]],
  ["Emulsified sauces",[
    "Mayonnaise is a cold emulsion of oil in egg yolk, with acid; aioli is a garlicky version from Provence and Catalonia. Hollandaise and béarnaise are warm emulsions that must be held around 60°C; too hot and the eggs scramble, too cold and the butter solidifies. Beurre blanc ('white butter') emulsifies cold butter into a reduction of wine, vinegar, and shallots, without eggs.",
    "Vinaigrettes are temporary emulsions of oil and vinegar, often stabilized with mustard. Emulsions can break when the fat separates; they can often be rescued by whisking the broken sauce slowly into a fresh egg yolk, a spoon of water, or mustard."]],
  ["Sauces of the world",[
    "Italy has ragù (slow-cooked meat sauce, like Bolognese), pesto (basil, pine nuts, garlic, Parmigiano, and olive oil, pounded in a mortar in Genoa), salsa verde, and carbonara's egg-and-cheese emulsion. Mexico has salsas (raw or cooked chili sauces) and moles, complex sauces of dried chilies, seeds, spices, and sometimes chocolate; Oaxaca is called 'the land of seven moles'.",
    "Asia contributes soy-based sauces, oyster sauce, hoisin, Thai curry pastes, Vietnamese nuoc cham (fish sauce, lime, sugar, chili), Japanese teriyaki and ponzu, Korean gochujang-based sauces, and Indian curries, which are really sauce-based dishes. Argentina has chimichurri; Peru has ají amarillo sauces; the Middle East has tahini sauce and toum (garlic emulsion)."]],
  ["Building a sauce",[
    "A good sauce balances flavor, consistency, and appearance. It should coat the back of a spoon (nappe) when appropriate, taste well-seasoned, and complement rather than overwhelm the main ingredient. Straining sauces gives a smooth, professional finish.",
    "Modern cooks often favor lighter sauces than classic French cuisine: reductions, vinaigrettes, emulsions with less butter, purées, and broths. Understanding the classical framework, however, makes it easy to create and improvise new sauces."]]
  ],
  terms:[["Mother sauce","One of the five classic French base sauces."],["Roux","Cooked flour and fat used to thicken sauces."],["Deglazing","Dissolving browned bits from a pan with liquid."],["Fond","Browned bits stuck to the pan after searing."],["Monter au beurre","Finishing a sauce by whisking in cold butter."],["Nappe","Sauce consistency that coats the back of a spoon."],["Mole","A complex Mexican sauce of chilies, spices, and seeds."]],
  w:"Sauces are a test of skill and a way to unify and elevate any dish.",
  src:["Sauce","Mother sauce","Roux","Hollandaise sauce","Pesto","Mole (sauce)"],
  q:[["Who codified the five French mother sauces?","Escoffier","Julia Child","Paul Bocuse","Brillat-Savarin"],
     ["Béchamel is…","Milk thickened with a white roux","Egg yolks and butter","Brown stock and brown roux","Tomatoes and aromatics"],
     ["Béarnaise is a daughter sauce of…","Hollandaise","Béchamel","Velouté","Espagnole"],
     ["What is deglazing?","Dissolving browned bits from a pan with liquid","Removing ice from a freezer","Polishing glassware","Coating with sugar"],
     ["Pesto originated in…","Genoa","Naples","Rome","Venice"],
     ["Oaxaca is known as 'the land of seven…'","Moles","Pastas","Curries","Salsas verdes"]]},

{ t:"Roasting, Grilling, and Barbecue", s:"Cooking with fire and dry heat",
  sec:[
  ["Roasting",[
    "Originally, roasting meant cooking meat on a spit before an open fire, while baking happened in an enclosed oven. Today roasting usually means cooking in an oven with dry, circulating heat. High temperatures brown the exterior through the Maillard reaction, while lower temperatures cook large pieces more evenly.",
    "Many cooks start at high heat for browning and finish at lower heat, or vice versa (the reverse sear). Roasting on a rack allows air to circulate. Basting with fat or juices may add flavor, but it also lowers surface temperature. After roasting, meat should rest before carving. Roasting also transforms vegetables, concentrating sugars and creating crisp, caramelized edges."]],
  ["Grilling and broiling",[
    "Grilling cooks food over direct radiant heat, typically from charcoal, wood, or gas. Direct grilling, over the heat source, suits thin, tender foods like steaks, burgers, chops, fish, and vegetables. Indirect grilling, with the food beside the heat and the lid closed, works like an oven for larger items. A two-zone fire, hot on one side and cooler on the other, gives control.",
    "Broiling (grilling, in British usage) uses heat from above in an oven. Grill marks look attractive, but full-surface browning gives more flavor. Cooking over very high heat produces charred flavors, though heavily charred meat contains compounds like heterocyclic amines (HCAs) and polycyclic aromatic hydrocarbons (PAHs) that health agencies suggest limiting."]],
  ["Grilling traditions",[
    "Cultures around the world grill: Argentine asado (beef and offal over wood embers on a parrilla), Brazilian churrasco (skewered meats carved tableside at churrascarias), Japanese yakitori (skewered chicken over binchotan charcoal), Korean barbecue (cooked at the table), Turkish and Middle Eastern kebabs, South African braai, Indian tandoori (cooked in a clay oven reaching over 400°C), and Jamaican jerk (traditionally cooked over pimento wood).",
    "Satay, skewered marinated meat with peanut sauce, is popular in Indonesia, Malaysia, and Singapore. Greek souvlaki, Peruvian anticuchos (often beef heart), and Nigerian suya (spiced skewers with a peanut-based spice mix called yaji) show the universal appeal of meat on a stick over fire."]],
  ["American barbecue",[
    "In the United States, barbecue means cooking tough cuts slowly with indirect heat and wood smoke, typically at around 107–135°C (225–275°F), for many hours, until connective tissue breaks down. Barbecue traditions developed in the South, shaped by Indigenous, African, and European practices; enslaved Africans and their descendants were central to its development.",
    "Regional styles include the Carolinas (pork, whole hog in eastern North Carolina with vinegar sauce; Lexington style using shoulder with a tomato-tinged sauce; South Carolina's mustard sauce), Memphis (pork ribs, dry or wet), Kansas City (many meats with thick, sweet tomato sauce), and Texas (especially beef brisket in Central Texas, seasoned simply with salt and pepper). The 'stall' occurs when large cuts plateau in temperature for hours as moisture evaporates; wrapping in butcher paper or foil (the 'Texas crutch') pushes through it."]],
  ["Smoke",[
    "Wood smoke contains hundreds of aromatic compounds. Different woods give different flavors: hickory and mesquite are strong, oak is medium, and fruitwoods like apple and cherry are mild and sweet. Clean smoke, thin and blue, is desirable; thick white smoke from smoldering, oxygen-starved fires tastes acrid.",
    "The pink 'smoke ring' just under the surface of barbecued meat forms when gases in smoke, such as nitrogen dioxide, react with myoglobin. Cold smoking, below about 30°C, flavors foods like salmon and cheese without cooking them; hot smoking cooks and flavors at once."]],
  ["Safety and technique",[
    "Fire cooking requires attention: preheat the grill, clean and oil the grates, manage flare-ups from dripping fat, and use a thermometer. Let meat rest after grilling. Charcoal chimneys light coals without lighter fluid, which can leave off flavors.",
    "Fire is humanity's oldest cooking method, and grilling remains one of the most social ways of cooking, from backyard barbecues to street food stalls. Mastering heat zones and timing is the key."]]
  ],
  terms:[["Roasting","Cooking with dry heat in an oven or before a fire."],["Direct grilling","Cooking food directly over the heat source."],["Indirect grilling","Cooking beside, not over, the heat source with the lid closed."],["Barbecue (US)","Slow cooking with indirect heat and wood smoke."],["The stall","A temperature plateau in large cuts as moisture evaporates."],["Smoke ring","A pink layer under the surface of smoked meat."]],
  w:"Fire cooking connects modern cooks to the oldest human technique and to rich traditions worldwide.",
  src:["Roasting","Grilling","Barbecue in the United States","Asado","Tandoor","Smoking (cooking)"],
  q:[["What is indirect grilling?","Cooking beside the heat source with the lid closed","Grilling directly over coals","Grilling in a pan","Grilling without fire"],
     ["Which tradition cooks meat in a clay oven?","Indian tandoori","Argentine asado","Japanese yakitori","Korean barbecue"],
     ["Central Texas barbecue is especially known for…","Beef brisket with salt and pepper","Whole hog with vinegar sauce","Mustard sauce","Sweet glazed ribs only"],
     ["What is 'the stall' in barbecue?","A temperature plateau as moisture evaporates","A barbecue restaurant","A broken smoker","The resting period"],
     ["What causes the smoke ring?","Gases in smoke reacting with myoglobin","Paprika rubs","Food coloring","Undercooking"],
     ["What is suya?","Nigerian spiced skewers","Japanese chicken skewers","Peruvian beef heart","Brazilian barbecue"]]},

{ t:"Braising and Stewing", s:"Low and slow transformation",
  sec:[
  ["The method",[
    "Braising transforms tough, inexpensive cuts into tender, deeply flavored dishes. The classic method: season and brown the meat well (for flavor), remove it, cook aromatics in the fat, deglaze with wine, stock, or other liquid, return the meat partly submerged, cover, and cook gently, often in a low oven around 150–165°C, for hours until tender.",
    "Stewing is similar but uses smaller pieces fully covered with liquid. The long, gentle heat converts collagen into gelatin, which enriches the sauce. Cooking too hot causes muscle fibers to tighten and dry out even while submerged; gentle simmering is key."]],
  ["Choosing cuts",[
    "Good cuts for braising include beef chuck, short ribs, shank, brisket, and oxtail; pork shoulder and belly; lamb shoulder and shanks; veal shanks; and chicken thighs and legs. These cuts have abundant connective tissue and fat, which melt into rich textures. Lean, tender cuts like tenderloin or chicken breast become dry and stringy when braised.",
    "Vegetables can be braised too: leeks, fennel, endive, cabbage, and greens benefit from gentle cooking in liquid. Legumes and dried beans are often cooked in a similar slow, gentle manner."]],
  ["Classic braises and stews",[
    "France offers boeuf bourguignon (beef braised in Burgundy red wine with mushrooms, onions, and bacon), coq au vin, pot-au-feu (boiled beef and vegetables served in courses), blanquette de veau (veal in a white sauce), and cassoulet (white beans with confit duck, sausages, and pork from Languedoc). Belgium has carbonnade flamande, beef braised in beer.",
    "Italy has osso buco (braised veal shanks from Milan, served with gremolata of lemon zest, garlic, and parsley) and brasato al Barolo. Hungary has goulash (gulyás) and paprikash. Morocco has tagines, slow-cooked in conical clay pots that return condensed steam to the dish. Ireland has Irish stew; the Philippines adobo (meat braised in vinegar, soy sauce, garlic, and bay leaves); China red-braised pork (hong shao rou), famously associated with Mao Zedong's home province of Hunan."]],
  ["Curries and braises of Asia",[
    "Many curries are braises. Indian rogan josh (Kashmiri lamb in a spiced sauce), Thai massaman curry (a rich curry with Persian and Muslim influences, containing potatoes and peanuts), Indonesian rendang (beef cooked for hours in coconut milk and spices until the liquid evaporates and the meat fries in its own fat), and Japanese nikujaga (meat and potatoes simmered in a sweet soy broth) are slow-cooked dishes.",
    "Korean galbi-jjim (braised short ribs) and Vietnamese thit kho (pork caramelized and braised in coconut water) show the global range. In each, spices, aromatics, and liquids penetrate the meat over long cooking."]],
  ["Equipment",[
    "Heavy pots with tight lids, like enameled cast-iron Dutch ovens (cocottes), are ideal because they hold heat evenly. Traditional vessels include clay tagines, Spanish cazuelas, Japanese donabe, Chinese sand pots, and the bean pots of New England.",
    "Slow cookers (introduced commercially as the Crock-Pot in the early 1970s) and pressure cookers have made braising easier. Pressure cookers raise the boiling point to about 120°C, cutting cooking times by half or more; modern multicookers combine both functions."]],
  ["Why braises improve",[
    "Many braises and stews taste better the next day, as flavors meld and the gelatin-rich sauce can be skimmed of solidified fat. They are ideal for advance cooking and for feeding many people. Finishing with something fresh, such as herbs, citrus zest, or a splash of vinegar, brightens the rich dish.",
    "Braising embodies an important principle of good cooking: patience transforms humble ingredients. Some of the most loved dishes in the world are braises born from the need to make tough, cheap cuts delicious."]]
  ],
  terms:[["Braise","To brown food, then cook slowly with some liquid in a covered pot."],["Stew","Small pieces of food cooked slowly, fully covered in liquid."],["Tagine","A Moroccan conical clay pot, and the stews cooked in it."],["Gremolata","An Italian garnish of lemon zest, garlic, and parsley."],["Dutch oven","A heavy, lidded pot ideal for braising."],["Pressure cooker","A sealed pot that raises the boiling point to cook faster."]],
  w:"Braising teaches patience and turns cheap, tough cuts into some of the world's most beloved dishes.",
  src:["Braising","Stew","Boeuf bourguignon","Osso buco","Tagine","Rendang"],
  q:[["Why brown meat before braising?","For flavor through the Maillard reaction","To cook it fully","To remove fat","To make it tender"],
     ["Which cut is best for braising?","Beef chuck","Beef tenderloin","Chicken breast","Fish fillet"],
     ["Osso buco is made from…","Veal shanks","Pork belly","Lamb ribs","Chicken thighs"],
     ["Rendang is from…","Indonesia","Thailand","Japan","Korea"],
     ["Why are tagine pots conical?","They return condensed steam to the dish","For decoration only","To fit in ovens","To cook faster at high heat"],
     ["At about what temperature does a pressure cooker boil water?","About 120°C","100°C","80°C","200°C"]]},

{ t:"Frying, Sautéing, and Stir-Frying", s:"Cooking in fat",
  sec:[
  ["Sautéing",[
    "Sautéing cooks small or thin pieces of food quickly in a little fat over relatively high heat, tossing or stirring to ensure even cooking. A sauté pan or skillet should be preheated so food sizzles on contact. Overcrowding lowers the temperature and causes food to steam instead of brown.",
    "Searing is a related technique: browning the surface of meat, fish, or vegetables in a very hot pan for flavor, often before roasting or braising. Pan-roasting starts on the stove and finishes in the oven. A classic French technique is meunière: fish dredged in flour, sautéed in butter, and served with brown butter, lemon, and parsley."]],
  ["Stir-frying and the wok",[
    "Stir-frying, central to Chinese cooking, uses a wok, a round-bottomed pan typically of carbon steel, over intense heat. Ingredients are cut small and uniform and added in order of cooking time, then tossed constantly. Sauces are added at the end and thickened with cornstarch.",
    "Wok hei, Cantonese for 'breath of the wok', describes the smoky, charred flavor produced by very high heat in restaurant woks, partly from oil droplets igniting and vaporizing. Home stoves are less powerful, so cooking in small batches helps. The wok is used for frying, steaming, braising, deep-frying, and smoking, making it one of the most versatile tools in cooking."]],
  ["Shallow and pan-frying",[
    "Pan-frying uses more fat than sautéing, typically enough to come partway up the food, at moderate to high heat. It is used for breaded cutlets (Austrian Wiener schnitzel, Italian cotoletta alla milanese, Japanese tonkatsu), fritters, potato pancakes (latkes, rösti), and fried chicken in some traditions.",
    "Breading usually follows the standard procedure: flour, then egg wash, then breadcrumbs (Japanese panko gives an especially crisp coating). The coating protects the food, holds in moisture, and forms a crisp crust."]],
  ["Deep-frying",[
    "Deep-frying submerges food in hot oil, usually 160–190°C. Water in the food's surface turns to steam and escapes, creating a crisp crust while the interior cooks by the heat conducted inward. Oil that is too cool gives greasy food; oil that is too hot burns the outside before the inside cooks.",
    "Batters and coatings vary: Japanese tempura uses a light batter of flour and ice-cold water, mixed minimally to avoid gluten; British fish and chips use a thicker, often beer-based batter. French fries are best fried twice: first at lower temperature to cook the interior, then at higher temperature to crisp, a method associated with Belgium, which, like France, claims to have invented fries."]],
  ["Fried foods of the world",[
    "Nearly every cuisine has beloved fried foods: Southern fried chicken, Korean fried chicken (double-fried and glazed), Indian pakoras and samosas, Middle Eastern falafel, Spanish churros, Italian arancini and fritto misto, Brazilian coxinhas and pastéis, West African puff-puff, Chinese spring rolls and youtiao (fried dough sticks), and Japanese karaage.",
    "Doughnuts, beignets, and fritters show frying in sweets. Street food culture worldwide depends heavily on frying, which is fast and produces irresistible textures."]],
  ["Frying safety and oils",[
    "Frying requires care: never leave hot oil unattended, keep a lid nearby to smother a fire, never use water on an oil fire, and dry wet food before adding it to oil to prevent spattering. A deep, heavy pot filled no more than halfway, and a thermometer, are essential.",
    "Use oils with high smoke points, like peanut, canola, sunflower, or rice bran oil. Traditional frying fats include lard and beef tallow, the latter long used for fries by fast-food chains. Oil can be strained and reused a few times, but it degrades with each use, darkening and smoking at lower temperatures."]]
  ],
  terms:[["Sauté","To cook quickly in a little fat over high heat."],["Sear","To brown the surface of food at high heat."],["Wok hei","The smoky 'breath of the wok' from high-heat stir-frying."],["Standard breading","Coating food in flour, egg, and breadcrumbs."],["Panko","Japanese breadcrumbs that give a light, crisp coating."],["Tempura","Japanese battered and deep-fried food."]],
  w:"Frying techniques create the crisp, browned textures people love and are central to street food and home cooking worldwide.",
  src:["Sautéing","Stir frying","Wok","Deep frying","Tempura","Wiener schnitzel"],
  q:[["Why does overcrowding a pan prevent browning?","It lowers the temperature and causes steaming","It adds too much oil","It burns the food","It removes salt"],
     ["What does 'wok hei' mean?","Breath of the wok","Hot oil","Wok cleaning","Slow cooking"],
     ["What is the standard breading procedure?","Flour, egg wash, breadcrumbs","Breadcrumbs, flour, egg","Egg, water, salt","Batter only"],
     ["Why should tempura batter be mixed minimally?","To avoid developing gluten","To keep it warm","To add air","To dissolve salt"],
     ["Why are fries often fried twice?","First to cook inside, then to crisp outside","To add flavor from two oils","To remove water only","To make them softer"],
     ["What should you never use on an oil fire?","Water","A lid","Baking soda","A fire blanket"]]}

]});


/* ---- from cuisine-06.js ---- */
/* CUISINE FOUNDATIONS, part 6: Unit 3 Core Techniques, chapters 6-9 */
COURSES.cuisine.units[2].ch.push(

{ t:"Pasta, Noodles, and Dumplings", s:"Dough shaped around the world",
  sec:[
  ["Origins",[
    "Noodles appear across Asia and Europe. The oldest known noodles, made from millet, were found at the Lajia archaeological site in northwestern China and reported in 2005, dated to roughly 4,000 years ago. The story that Marco Polo brought pasta from China to Italy is a myth; Italians, and earlier Arab cooks in Sicily, were making dried pasta (itriyya) by the 12th century, as recorded by the geographer al-Idrisi around 1154.",
    "Dried pasta production flourished around Naples, where the climate suited drying; factory production expanded in the 19th century. Tomato sauce with pasta became common in Naples only in the late 18th and 19th centuries."]],
  ["Italian pasta",[
    "Italian pasta comes in two main types. Dried pasta (pasta secca), made of durum wheat semolina and water, is extruded through dies; bronze dies create a rough surface that holds sauce better than smooth Teflon dies. Fresh pasta (pasta fresca), especially in northern Italy, is often made with soft wheat flour and eggs, rolled into sheets for tagliatelle, lasagne, and filled pastas like tortellini and ravioli.",
    "There are hundreds of pasta shapes, each traditionally matched with sauces: long, thin pastas like spaghetti with olive oil or tomato sauces; ribbons like pappardelle with rich ragù; tubes like rigatoni and penne with chunky sauces; and small shapes in soups. Cook pasta in generously salted boiling water until al dente ('to the tooth'), still slightly firm, and finish it in the sauce with a splash of starchy pasta water to bind."]],
  ["Asian noodles",[
    "Chinese noodles include wheat noodles, from hand-pulled lamian (stretched and folded repeatedly into thin strands) to knife-cut daoxiao mian, and rice noodles. Lanzhou beef noodle soup, dan dan noodles from Sichuan, and Cantonese wonton noodles are famous dishes. Japanese noodles include thick wheat udon, buckwheat soba, and ramen, which uses alkaline water (kansui) to give its springy texture and yellow color.",
    "Southeast Asia relies heavily on rice noodles: Vietnamese pho and bún, Thai pad thai and pad see ew, and Malaysian char kway teow. Korean noodles include chewy sweet-potato starch glass noodles (japchae) and cold buckwheat noodles (naengmyeon). Instant noodles were invented by Momofuku Ando in Japan in 1958 and are now eaten in enormous quantities worldwide."]],
  ["Dumplings",[
    "Dumplings, pieces of dough wrapped around fillings or cooked on their own, exist almost everywhere. Chinese jiaozi are eaten especially at Lunar New Year; Cantonese dim sum includes har gow (shrimp dumplings) and siu mai; Shanghai's xiaolongbao contain soup made by adding gelled stock to the filling, which melts when steamed. Japanese gyoza are pan-fried; Korean mandu, Nepalese and Tibetan momos, and Central Asian manti are related.",
    "Europe has Polish pierogi, Russian pelmeni, Italian ravioli and gnocchi (potato or flour dumplings), German Spätzle and Knödel, and Jewish kreplach. Latin America has empanadas and tamales (masa steamed in corn husks or banana leaves). African cuisines have fufu and banku, starchy doughs of cassava, plantain, or corn, eaten by hand with soups."]],
  ["Making fresh pasta and dough",[
    "Classic Italian egg pasta uses about 100 grams of flour per large egg, mixed into a dough, kneaded until smooth, rested, and rolled thin by hand with a long rolling pin (mattarello) or with a machine. Southern Italian pastas like orecchiette use only semolina and water and are shaped by hand.",
    "Dumpling wrappers for jiaozi are made from flour and water, sometimes hot water for tenderness. Pleating dumplings is a skill; families gather to make them together, especially for festivals. Folding techniques vary by region and are often passed down through generations."]],
  ["The universal appeal",[
    "Pasta, noodles, and dumplings are cheap, filling, versatile, and endlessly adaptable, making them comfort food across cultures. They show how simple ingredients, flour, water, and sometimes egg, become hundreds of distinctive foods through technique and tradition.",
    "Learning to make them by hand connects cooks to centuries of craft, and learning to sauce and serve them properly is a key everyday skill."]]
  ],
  terms:[["Al dente","Cooked pasta that is still slightly firm to the bite."],["Pasta secca","Dried pasta made from durum wheat semolina."],["Bronze die","An extrusion die that gives pasta a rough, sauce-holding surface."],["Lamian","Chinese hand-pulled noodles."],["Kansui","Alkaline water giving ramen its texture."],["Xiaolongbao","Shanghai soup dumplings."]],
  w:"Pasta, noodles, and dumplings are among the world's most beloved comfort foods and teach essential dough skills.",
  src:["Pasta","Noodle","Ramen","Dumpling","Xiaolongbao","Instant noodle"],
  q:[["Did Marco Polo bring pasta to Italy?","No, that is a myth","Yes, in 1295","Yes, from Japan","Only spaghetti"],
     ["What does 'al dente' mean?","To the tooth: slightly firm","Fully soft","Overcooked","Raw"],
     ["Why are bronze dies prized for dried pasta?","They create a rough surface that holds sauce","They make pasta faster","They make it shiny","They add flavor"],
     ["What gives ramen its springy texture?","Alkaline water (kansui)","Eggs","Rice flour","Seaweed"],
     ["Who invented instant noodles?","Momofuku Ando","David Chang","Kikunae Ikeda","Marco Polo"],
     ["What makes xiaolongbao soupy?","Gelled stock in the filling melts when steamed","They are served in soup","They are filled with water","They are soaked in broth"]]},

{ t:"Bread", s:"Flour, water, salt, yeast, and time",
  sec:[
  ["An ancient food",[
    "Bread is one of humanity's oldest prepared foods. Charred remains of flatbread found at Shubayqa 1 in Jordan, reported in 2018, date to about 14,400 years ago, before agriculture, made from wild cereals and tubers. Ancient Egyptians developed leavened bread and large-scale baking; Romans had professional bakers' guilds.",
    "Bread became so central that it symbolized food itself: 'our daily bread', 'breadwinner', and 'companion' (from Latin, 'one who shares bread'). Bread prices sparked political unrest, including in the run-up to the French Revolution."]],
  ["The four ingredients",[
    "Basic bread needs only flour, water, salt, and yeast (or a sourdough starter). Flour provides starch and the proteins that form gluten. Water hydrates flour; the proportion of water (hydration) affects texture, with higher-hydration doughs giving more open, irregular crumb, as in ciabatta. Salt strengthens gluten, controls fermentation, and adds flavor.",
    "Yeast (Saccharomyces cerevisiae) consumes sugars and produces carbon dioxide, which inflates the gluten network, and alcohol and flavor compounds. Commercial yeast comes as fresh (cake) yeast, active dry yeast, and instant yeast. Louis Pasteur showed in the 1850s–60s that yeast is a living organism responsible for fermentation."]],
  ["Process",[
    "Breadmaking follows a sequence: mixing ingredients; kneading (or stretching and folding) to develop gluten; bulk fermentation (the first rise), during which flavor develops; dividing and shaping; proofing (the final rise); scoring (cutting the surface so the loaf expands in a controlled way); and baking, often with steam in the first minutes to keep the crust soft long enough for 'oven spring', then letting it crisp.",
    "Time builds flavor. Slow, cool fermentation, including overnight refrigeration (retardation) and preferments such as poolish (French/Polish liquid preferment) or biga (Italian stiff preferment), produces more complex flavors. The 'no-knead' method, popularized by Jim Lahey and the New York Times in 2006, uses a long fermentation instead of kneading."]],
  ["Sourdough",[
    "Sourdough relies on a starter, a culture of wild yeasts and lactic acid bacteria maintained by regular feeding with flour and water. The bacteria produce lactic and acetic acids, giving tangy flavor, better keeping qualities, and partial breakdown of some compounds that may make the bread easier for some people to digest. Sourdough was the main way to leaven bread for most of history.",
    "San Francisco sourdough is famous; its characteristic bacterium was named Lactobacillus sanfranciscensis (now Fructilactobacillus sanfranciscensis). Rye breads, common in Germany and Scandinavia, usually need sourdough because rye's proteins and starches behave differently from wheat's."]],
  ["Breads of the world",[
    "France's baguette, standardized in the 20th century and protected by the 1993 'Décret Pain', which defines a 'traditional French bread' as made only of flour, water, salt, and leavening, was added to UNESCO's intangible heritage list in 2022. Italy has ciabatta, focaccia, and Tuscan unsalted bread. Germany has hundreds of breads, including dark rye and pumpernickel, and pretzels.",
    "Flatbreads are the world's oldest and most common breads: Indian naan (baked in a tandoor), roti, chapati, and paratha; Middle Eastern pita, lavash, and markook; Mexican tortillas; Ethiopian injera; and Norwegian lefse. Enriched breads contain butter, eggs, milk, or sugar: French brioche, Jewish challah, Italian panettone, and Chinese steamed buns (mantou and bao)."]],
  ["Troubleshooting",[
    "Common problems include dense bread (under-proofed or weak gluten), collapsed loaves (over-proofed), pale crust (oven not hot enough or too little sugar or steam), and gummy interiors (underbaked or sliced too soon, since bread continues setting as it cools). Professional bakers judge dough by feel, appearance, and the 'poke test': gently pressed dough that springs back slowly is properly proofed.",
    "Baking bread rewards patience and practice. Home baking surged during the COVID-19 pandemic lockdowns of 2020, when sourdough starters and flour sold out in many countries."]]
  ],
  terms:[["Hydration","The ratio of water to flour in dough."],["Bulk fermentation","The first rise of dough after mixing."],["Proofing","The final rise of shaped dough before baking."],["Oven spring","The rapid rise of bread in the first minutes of baking."],["Sourdough starter","A culture of wild yeasts and bacteria used to leaven bread."],["Preferment","A portion of dough fermented in advance, such as poolish or biga."]],
  w:"Bread is the staple of many cultures, and making it teaches the essential patience and observation of the baker.",
  src:["Bread","Sourdough","Baguette","Flatbread","Yeast","No-knead bread"],
  q:[["About how old is the oldest known bread, found in Jordan?","About 14,400 years","About 2,000 years","About 500 years","About 50,000 years"],
     ["What does salt do in bread?","Strengthens gluten, controls fermentation, and adds flavor","Makes it rise","Makes it sweet","Nothing important"],
     ["What is oven spring?","The rapid rise of bread early in baking","A type of oven","The cooling period","A brand of yeast"],
     ["What makes sourdough sour?","Acids produced by lactic acid bacteria","Added vinegar","Lemon juice","Old flour"],
     ["When was the baguette added to UNESCO's intangible heritage list?","2022","1993","2000","2010"],
     ["What does the 'poke test' check?","Whether dough is properly proofed","Oven temperature","Salt level","Flour type"]]},

{ t:"Pastry and Desserts", s:"The precise art of sweets",
  sec:[
  ["The pastry kitchen",[
    "Pastry is a specialized field requiring precision, patience, and artistry. The pâtissier works with doughs, creams, chocolate, sugar, and fruit. Antonin Carême (1784–1833), often called the first celebrity chef, was famous for architectural sugar sculptures (pièces montées) and is credited with refining or popularizing many pastries.",
    "Pastry relies on exact measurements, temperatures, and techniques. Butter must often stay cold; sugar must reach precise temperatures; eggs must be whipped to specific stages. Small errors are hard to fix once something is in the oven."]],
  ["Pastry doughs",[
    "Shortcrust pastry (pâte brisée) is made by rubbing cold fat into flour and binding with a little water; pockets of fat create tenderness and flakiness. Sweet shortcrust (pâte sucrée) and pâte sablée are richer, used for tarts. American pie crust often uses butter, shortening, or lard.",
    "Laminated doughs are made by folding butter into dough repeatedly to create hundreds or thousands of thin layers. In the oven, water in the butter turns to steam and separates the layers. Puff pastry (pâte feuilletée) has no yeast; croissant and Danish doughs include yeast. Choux pastry (pâte à choux) is cooked on the stove with butter, water, flour, and eggs; in the oven it puffs into hollow shells for éclairs, profiteroles, and gougères. Phyllo (filo), paper-thin sheets used in baklava and spanakopita, comes from Ottoman and Greek traditions."]],
  ["Creams and custards",[
    "Pastry cream (crème pâtissière) is a thick custard of milk, eggs, sugar, and starch, used in éclairs and fruit tarts. Crème anglaise is a pouring custard without starch, cooked to about 82–85°C until it coats a spoon. Crème brûlée is baked custard with a caramelized sugar top; flan or crème caramel is custard baked over caramel.",
    "Other components include whipped cream (crème Chantilly), mousses (lightened with whipped cream or egg whites), Italian meringue (whites whipped with hot sugar syrup), buttercreams, ganache (chocolate emulsified with cream, used for truffles, glazes, and fillings), and fruit curds."]],
  ["Cakes",[
    "Cakes are classified by method. Butter cakes, like pound cake and many layer cakes, start by creaming butter and sugar to trap air. Sponge cakes, like génoise, rely on whipped eggs for lift. Chiffon cakes use oil and whipped whites; angel food cake uses only whipped whites, no yolks or fat.",
    "Classic cakes and desserts include the French opéra and fraisier, Austrian Sachertorte (chocolate cake with apricot jam, created by Franz Sacher in 1832), German Black Forest cake, Italian tiramisu (likely developed in the Veneto region in the 1960s–70s), and British Victoria sponge."]],
  ["Desserts of the world",[
    "Desserts reflect local ingredients and traditions. The Middle East and Turkey have baklava and kunefe; India has gulab jamun, jalebi, kheer, and barfi, many based on milk reduced into khoa; Japan has wagashi, delicate sweets often made from rice and sweet bean paste (anko), served with tea; China has mooncakes for the Mid-Autumn Festival.",
    "Latin America has dulce de leche, tres leches cake, and churros; Portugal has pastéis de nata (custard tarts, traditionally from the Jerónimos Monastery in Belém); France has macarons, tarte Tatin, and mille-feuille; and the US has apple pie, brownies, and cheesecake. Ice cream, developed over centuries from earlier frozen desserts, became widely popular in the 18th and 19th centuries."]],
  ["Plated desserts and pastry careers",[
    "Restaurant pastry chefs create plated desserts combining contrasting textures and temperatures: crisp tuiles, smooth creams, frozen elements, sauces, and fresh fruit. Modern pastry has embraced techniques like gels, foams, and precision tempering.",
    "Pastry careers include restaurant pastry chef, bakery owner, chocolatier, confectioner, and cake designer. Famous modern pastry chefs include Pierre Hermé, called 'the Picasso of pastry' and known for his macarons, and Dominique Ansel, creator of the Cronut in New York in 2013. Mastering pastry builds a precise, scientific approach valuable in all cooking."]]
  ],
  terms:[["Pâtissier","A pastry chef."],["Lamination","Folding butter into dough repeatedly to create layers."],["Choux pastry","A cooked dough that puffs into hollow shells."],["Crème pâtissière","Thick pastry cream thickened with starch and eggs."],["Ganache","Chocolate emulsified with cream."],["Génoise","A sponge cake leavened by whipped whole eggs."]],
  w:"Pastry teaches precision and patience, and desserts express the sweetness of cultures worldwide.",
  src:["Pastry","Puff pastry","Choux pastry","Custard","Cake","Marie-Antoine Carême"],
  q:[["What makes puff pastry rise?","Steam from layers of butter","Yeast","Baking powder","Whipped eggs"],
     ["Choux pastry is used for…","Éclairs and profiteroles","Croissants","Baklava","Pie crust"],
     ["What is ganache?","Chocolate emulsified with cream","Whipped egg whites","A pastry dough","Caramelized sugar"],
     ["Sachertorte comes from…","Austria","France","Italy","Germany"],
     ["Pastéis de nata are from…","Portugal","Spain","Brazil","Italy"],
     ["Who created the Cronut in 2013?","Dominique Ansel","Pierre Hermé","Antonin Carême","Christina Tosi"]]},

{ t:"Preserving and Fermentation", s:"Making food last, and making it better",
  sec:[
  ["Why preserve food",[
    "For most of history, preserving food was essential for survival through winters, droughts, journeys, and lean seasons. Preservation works by making food inhospitable to spoilage microbes: removing water (drying), adding salt or sugar (which bind water), adding acid (pickling), excluding air, using cold, applying heat (canning), or encouraging beneficial microbes (fermentation).",
    "Many preserved foods became prized delicacies in their own right: prosciutto, aged cheese, kimchi, sauerkraut, smoked salmon, wine, and soy sauce. Preservation creates new flavors that fresh ingredients lack."]],
  ["Drying, salting, and curing",[
    "Drying is the oldest method: sun-dried tomatoes, raisins, dried fish, jerky, and dried chilies and mushrooms. Salting draws out moisture and inhibits bacteria; salt cod and salted anchovies are examples. Curing uses salt, often with sugar, spices, and nitrites or nitrates, to preserve meat: bacon, ham, salami, and other charcuterie.",
    "Famous cured hams include Italy's prosciutto di Parma and San Daniele and Spain's jamón ibérico, from Iberian pigs often fattened on acorns (bellota), aged up to three years or more. Nitrites give cured meats their pink color and protect against botulism, though their health effects at high consumption levels are debated; the WHO classified processed meat as a Group 1 carcinogen in 2015 based on colorectal cancer evidence."]],
  ["Pickling",[
    "Pickling preserves food in acid. Quick pickles use vinegar; fermented pickles develop their acid naturally through lactic acid bacteria in salt brine. Cucumber pickles, Japanese tsukemono (including umeboshi pickled plums and pickled ginger), Indian achar (pickles preserved in oil, spices, and salt), and Middle Eastern pickled turnips are examples.",
    "Sugar preserves fruit in jams, jellies, marmalades, and candied fruits. Confit preserves meat in fat; rillettes are shredded, fat-preserved meat. In 1810, the French confectioner Nicolas Appert published his method of preserving food in sealed, heated containers, the foundation of canning, developed in response to a prize offered for feeding Napoleon's armies."]],
  ["Fermentation",[
    "Fermentation uses microorganisms, bacteria, yeasts, and molds, to transform food. Lactic acid fermentation produces sauerkraut, kimchi, yogurt, and sourdough. Alcoholic fermentation by yeasts produces beer, wine, and bread's rise. Acetic fermentation turns alcohol into vinegar. Molds create cheeses, soy sauce, miso, tempeh, and sake.",
    "Kimchi, Korea's essential side dish, has hundreds of varieties; the most common uses napa cabbage with chili flakes (gochugaru), garlic, ginger, and fish sauce or salted shrimp. Kimjang, the communal making and sharing of kimchi in late autumn, was inscribed by UNESCO in 2013. Sauerkraut, from Central Europe, is fermented with just cabbage and salt. Fermented foods have been linked by some research to gut health, though the evidence is still developing."]],
  ["Canning and modern preservation",[
    "Home canning uses heat to sterilize sealed jars. High-acid foods like fruits, jams, and pickles can be processed in a boiling water bath; low-acid foods like vegetables, meats, and beans require pressure canning to reach higher temperatures and destroy the spores of Clostridium botulinum, which cause botulism, a rare but deadly illness.",
    "Industrial food preservation includes refrigeration (widely available in homes in wealthy countries from the 1920s–1950s), freezing (Clarence Birdseye developed quick-freezing in the 1920s after observing Inuit fish freezing in Labrador), vacuum packing, freeze-drying, and modified atmosphere packaging. These transformed diets, allowing year-round access to many foods."]],
  ["The fermentation revival",[
    "Fermentation has seen a major revival among chefs and home cooks. Sandor Katz's 'The Art of Fermentation' (2012) and the work of restaurants like Noma in Copenhagen, which ran a dedicated fermentation lab and published 'The Noma Guide to Fermentation' (2018), inspired experiments with koji, garums, vinegars, and lacto-fermented fruits.",
    "Preservation techniques teach patience and reveal how time and microbes create flavor. Making a simple sauerkraut or pickle is an excellent introduction to this ancient craft."]]
  ],
  terms:[["Curing","Preserving meat or fish with salt, sugar, and often nitrites."],["Charcuterie","Prepared and cured meat products such as ham, sausage, and pâté."],["Lactic acid fermentation","Fermentation by bacteria producing lactic acid, as in sauerkraut and kimchi."],["Pickling","Preserving food in acid, either vinegar or fermented brine."],["Canning","Preserving food in sealed, heat-sterilized containers."],["Botulism","A dangerous illness from a toxin produced by Clostridium botulinum."]],
  w:"Preservation and fermentation turned survival techniques into some of the world's most treasured flavors.",
  src:["Food preservation","Fermentation in food processing","Kimchi","Curing (food preservation)","Nicolas Appert","Clarence Birdseye"],
  q:[["How does salting preserve food?","It draws out and binds water, inhibiting microbes","It adds bacteria","It heats food","It freezes food"],
     ["Who developed the method of canning in 1810?","Nicolas Appert","Louis Pasteur","Clarence Birdseye","Antoine Lavoisier"],
     ["Kimchi is made through…","Lactic acid fermentation","Smoking","Freezing","Canning"],
     ["Why do low-acid foods need pressure canning?","To destroy botulism spores at higher temperatures","To add flavor","To soften them","To keep them colorful"],
     ["Who developed quick-freezing after observing Inuit methods?","Clarence Birdseye","Nicolas Appert","Fergus Henderson","Sandor Katz"],
     ["In 2015, the WHO classified processed meat as…","A Group 1 carcinogen","Completely safe","A vegetable","A probiotic"]]}

);


/* ---- from cuisine-07.js ---- */
/* CUISINE FOUNDATIONS, part 7: Unit 4 A History of Food, chapters 1-4 */
COURSES.cuisine.units.push({ t:"A History of Food", ch:[

{ t:"From Foraging to Farming", s:"Prehistoric diets and the agricultural revolution",
  sec:[
  ["Hunter-gatherers",[
    "For most of human history, people lived by hunting, fishing, and gathering wild plants. Their diets varied enormously by environment, from the meat- and fat-heavy diets of Arctic peoples to the plant-rich diets of many tropical foragers. Archaeological evidence shows that early humans ate a wide range of foods, including wild grains, tubers, nuts, fruits, insects, shellfish, and game.",
    "Foragers developed sophisticated knowledge of plants and animals, including how to process toxic foods to make them edible, such as leaching bitter acorns or detoxifying cassava. Food preparation tools, like grinding stones, appear tens of thousands of years ago."]],
  ["The Neolithic Revolution",[
    "Beginning around 10,000 BCE, people in several regions independently began domesticating plants and animals. In the Fertile Crescent of the Middle East, early crops included wheat, barley, lentils, peas, chickpeas, and flax, and animals included sheep, goats, cattle, and pigs. In China, rice and millet were domesticated; in Mesoamerica, maize, beans, and squash; in the Andes, potatoes, quinoa, and llamas; in New Guinea, taro and bananas; and in Africa, sorghum, millet, African rice, and yams.",
    "Domestication changed plants: wild wheat scatters its seeds when ripe, but farmers selected plants whose seeds stayed on the stalk, making harvest easier. Maize ears grew from tiny teosinte cobs to large ears over thousands of years of selection."]],
  ["Consequences of farming",[
    "Agriculture allowed denser populations, permanent settlements, food surpluses, specialization of labor, cities, and states. But early farmers often had less varied diets than foragers, and skeletal evidence shows they were sometimes shorter and suffered more dental problems and nutritional deficiencies. The writer Jared Diamond provocatively called agriculture 'the worst mistake in the history of the human race' in a 1987 essay, a view many historians consider overstated.",
    "Farming also brought new cooking methods and foods: bread, porridge, beer, cheese, and yogurt. Pottery, which appeared in East Asia before farming, allowed boiling and stewing. Storage of grain led to granaries, and herding animals provided milk."]],
  ["The Three Sisters and other systems",[
    "Indigenous peoples of the Americas developed the 'Three Sisters' planting system: maize, beans, and squash grown together. The maize provides a stalk for beans to climb; beans fix nitrogen in the soil; and squash leaves shade the ground, retaining moisture and suppressing weeds. Together they also provide a balanced diet.",
    "Other ingenious agricultural systems include the chinampas of the Aztecs (raised fields in lakes), rice paddy terraces in Asia, and the Andean terraces where farmers grew hundreds of potato varieties at different altitudes and freeze-dried potatoes (chuño) using cold nights and sunny days."]],
  ["Early fermentation and drink",[
    "Fermented drinks appeared early. Chemical analysis of pottery from Jiahu in China, around 7000 BCE, shows evidence of a fermented drink made from rice, honey, and fruit. Evidence of grape wine in Georgia dates to around 6000 BCE, and beer was important in early Mesopotamia and Egypt, where workers were partly paid in beer and bread.",
    "Some researchers have speculated that the desire to brew beer may have contributed to the domestication of cereals, though this 'beer before bread' hypothesis remains debated. Cheese-making residues on pottery in Poland date to around 5500 BCE."]],
  ["Why this history matters",[
    "Today's diets still rest on crops and animals domesticated thousands of years ago. Just a handful of crops supply most of the world's calories, a reduction in diversity that worries some agricultural scientists concerned about resilience.",
    "Understanding the origins of food helps explain why cuisines developed as they did and reminds us of the long human ingenuity behind every meal."]]
  ],
  terms:[["Neolithic Revolution","The transition from foraging to farming, beginning about 12,000 years ago."],["Domestication","Selective breeding of plants or animals for human use."],["Fertile Crescent","The region in the Middle East where early agriculture developed."],["Three Sisters","Maize, beans, and squash grown together by Indigenous Americans."],["Chuño","Freeze-dried potatoes made in the Andes."]],
  w:"Our food today rests on the domestication of plants and animals thousands of years ago in many parts of the world.",
  src:["Neolithic Revolution","Fertile Crescent","Three Sisters (agriculture)","Domestication","Chuño","History of beer"],
  q:[["Which crops were domesticated in the Fertile Crescent?","Wheat, barley, and lentils","Maize and beans","Rice and millet","Potatoes and quinoa"],
     ["What did farmers select for in wild wheat?","Seeds that stayed on the stalk","Larger leaves","Bitter taste","Faster scattering"],
     ["In the Three Sisters system, what do beans contribute?","Nitrogen fixation","Shade","A stalk to climb","Weed control"],
     ["Where is evidence of an early fermented drink from about 7000 BCE?","Jiahu, China","Rome, Italy","Paris, France","Mexico City"],
     ["What is chuño?","Freeze-dried Andean potatoes","A Mexican sauce","A Chinese noodle","An Egyptian beer"],
     ["Who called agriculture 'the worst mistake in the history of the human race'?","Jared Diamond","Michael Pollan","Sidney Mintz","Richard Wrangham"]]},

{ t:"Ancient Food", s:"Mesopotamia, Egypt, Greece, Rome, China, and India",
  sec:[
  ["Mesopotamia and Egypt",[
    "The oldest known written recipes come from Mesopotamia: three cuneiform tablets in the Yale Babylonian Collection, dating to around 1730 BCE, record about 25 recipes, mostly for stews and broths using meat, onions, leeks, garlic, and herbs. Bread and beer were staples, and temple economies distributed rations.",
    "Ancient Egyptians ate bread, beer, onions, garlic, lentils, fish from the Nile, and, for the wealthy, meat, fowl, and wine. Tomb paintings show baking, brewing, and butchery in detail. Workers building pyramids received rations of bread and beer. Egyptians also raised geese and ducks and may have practiced early force-feeding, foreshadowing foie gras."]],
  ["Ancient Greece",[
    "The Greek diet was based on the 'Mediterranean triad' of grain (as bread and porridge), olive oil, and wine, with legumes, vegetables, cheese, fish, and occasional meat, usually from sacrifices. The symposium was an all-male drinking party with wine diluted with water, conversation, and entertainment.",
    "Greek writers on food included Archestratus, whose 4th-century BCE poem on gastronomy survives in fragments, and Athenaeus, whose 'Deipnosophists' (Dinner-Table Philosophers, about 200 CE) preserves many quotations about food. Greek physicians like Hippocrates related diet to health through the theory of the four humors, which influenced European food ideas for nearly 2,000 years."]],
  ["Ancient Rome",[
    "Ordinary Romans ate puls (grain porridge), bread, vegetables, legumes, and cheese; the urban poor relied on grain distributions and street food from thermopolia, counter-service shops, many found at Pompeii. The wealthy held lavish banquets, reclining on couches, eating dishes like dormice, peacocks, and exotic fish.",
    "Romans seasoned heavily with garum (fermented fish sauce), honey, vinegar, pepper, and herbs like lovage and silphium (a now-extinct plant). The cookbook attributed to Apicius, compiled around the 4th or 5th century CE, is the main surviving Roman recipe collection. Romans spread vines, olives, and many vegetables across their empire."]],
  ["Ancient China",[
    "Early Chinese cuisine centered on grains, millet in the north and rice in the south, with the concept of fan (grains) and cai (dishes accompanying them). Cooking techniques included steaming, boiling, and roasting; bronze vessels for cooking and ritual are among China's greatest artworks. Chopsticks were in use by the Shang dynasty or earlier.",
    "Confucius (551–479 BCE) was said to insist on properly cut and sauced food. Chinese thought linked food with medicine through balance of yin and yang and the 'hot' and 'cold' properties of foods. By the Han dynasty, soy products, noodles, and fermented sauces were developing, and trade along the Silk Roads brought grapes, sesame, and other foods from Central Asia."]],
  ["Ancient India",[
    "In ancient India, diets centered on wheat, barley, rice, lentils, dairy (milk, ghee, yogurt), and spices such as black pepper, turmeric, and ginger. Indus Valley sites show evidence of turmeric and ginger in cooking residues dating back over 4,000 years. Vedic texts describe ritual foods and the importance of ghee.",
    "Ideas of purity and non-violence (ahimsa) in Hinduism, Buddhism, and Jainism promoted vegetarianism. Ayurveda, the traditional Indian medical system, classified foods by their effects on the body's doshas (energies) and the six tastes: sweet, sour, salty, pungent, bitter, and astringent."]],
  ["Lessons from antiquity",[
    "Ancient cuisines show enduring patterns: grain as the core, legumes and vegetables for everyday meals, meat for festivals and the wealthy, fermented seasonings for umami, and links between food, religion, and health.",
    "They also show how trade spread ingredients long before globalization. Pepper from India reached Rome; Roman garum was traded across the Mediterranean; Chinese silk routes carried foods in both directions."]]
  ],
  terms:[["Cuneiform recipes","Mesopotamian recipes written on clay tablets around 1730 BCE."],["Garum","A Roman fermented fish sauce."],["Symposium","A Greek drinking party with conversation."],["Apicius","A Roman cookbook compiled around the 4th–5th century CE."],["Humoral theory","The ancient idea that health depends on balancing four bodily humors."],["Ayurveda","The traditional Indian medical system, including dietary principles."]],
  w:"Ancient food cultures established patterns of grain, ferment, spice, and ritual that still shape cuisines today.",
  src:["Ancient Egyptian cuisine","Ancient Greek cuisine","Ancient Roman cuisine","Apicius","Garum","Yale Babylonian Collection"],
  q:[["The oldest known written recipes come from…","Mesopotamia","Rome","China","Egypt"],
     ["The Greek 'Mediterranean triad' was…","Grain, olive oil, and wine","Rice, fish, and soy","Meat, milk, and honey","Corn, beans, and squash"],
     ["What was garum?","A Roman fermented fish sauce","A Greek wine","An Egyptian bread","A Chinese vessel"],
     ["The Roman cookbook is attributed to…","Apicius","Archestratus","Athenaeus","Hippocrates"],
     ["In Chinese food culture, 'fan' refers to…","Grains","Dishes accompanying grains","Soup","Tea"],
     ["Which belief encouraged vegetarianism in ancient India?","Ahimsa (non-violence)","Humoral theory","The symposium","Confucianism"]]},

{ t:"Medieval Food and the Islamic World", s:"Feasts, fasts, and the spread of flavors",
  sec:[
  ["The medieval European table",[
    "In medieval Europe, diet depended heavily on social class. Peasants ate bread (often rye or mixed grains), pottage (a thick soup of grains and vegetables), legumes, cheese, and some pork. The nobility enjoyed roast meats, game, fish, white bread, wine, and spiced dishes as displays of wealth.",
    "The Church calendar shaped eating. Christians fasted from meat on Fridays, during Lent, and on many other days, so fish, especially salted and dried fish, became very important. Monasteries developed brewing, cheesemaking, and gardening; some famous cheeses and beers originated in monastic houses."]],
  ["Medieval feasts and cookbooks",[
    "Medieval feasts were spectacles, with dishes served in multiple 'courses' each containing many dishes at once, and subtleties, elaborate sculptures in sugar or marzipan. Medieval cuisine for the wealthy used lots of spices, almond milk, and sweet-sour flavors with vinegar and verjuice (sour grape juice).",
    "Important cookbooks include 'Le Viandier', attributed to Guillaume Tirel (called Taillevent), cook to French kings in the 14th century, and 'The Forme of Cury', compiled by the cooks of England's Richard II around 1390. Contrary to a popular myth, spices were not mainly used to disguise rotten meat; they were expensive status symbols and were valued for flavor and supposed health effects."]],
  ["The Islamic culinary world",[
    "From the 8th century, the Islamic Caliphates, centered in Baghdad and later elsewhere, developed a sophisticated cuisine combining Persian, Arab, Byzantine, Indian, and Central Asian influences. The 10th-century 'Kitab al-Tabikh' by Ibn Sayyar al-Warraq is one of the oldest surviving Arabic cookbooks, with hundreds of recipes.",
    "Islamic cuisine featured rice, sugar, citrus, eggplants, spinach, almonds, rosewater, saffron, and spices, with techniques like sweet-sour meat stews, distillation (for rosewater and perfumes), and sophisticated sugar confectionery. Muslim rulers and traders spread crops like sugarcane, rice, citrus, and eggplant across the Mediterranean, including to Spain and Sicily, part of what historians call an 'Arab agricultural revolution'."]],
  ["Influence on Europe",[
    "Arab influence on European food is visible in words and dishes. 'Sugar', 'syrup', 'sherbet', 'orange', 'lemon', 'saffron', 'spinach', 'artichoke', 'apricot', and 'marzipan' have Arabic or Persian roots. Medieval European blancmange (chicken and rice in almond milk) and many sweet-sour dishes reflect Arab influences, as do Sicilian dishes like caponata and cassata.",
    "Spanish cuisine was transformed by centuries of Muslim rule in al-Andalus, which brought rice (leading eventually to paella), almonds, citrus, and spices. Crusaders and traders also brought new tastes back to Europe."]],
  ["Asia in the medieval period",[
    "China under the Song dynasty (960–1279) developed a vibrant urban food culture with restaurants, teahouses, and street vendors in cities like Kaifeng and Hangzhou, described in detail in contemporary writings. Some historians consider these among the world's first restaurants in a recognizably modern sense, with menus and specialized dishes.",
    "Japan developed Buddhist vegetarian cuisine (shōjin ryōri) in monasteries, and tea culture took root in the 12th and 13th centuries. India's cuisine was shaped by regional kingdoms and, from the 13th century, by the Delhi Sultanate, which introduced Persian and Central Asian influences."]],
  ["The spice route",[
    "Throughout the Middle Ages, spices traveled from India and Southeast Asia by sea and land to the Middle East and then to Europe, largely through Arab and Venetian merchants. Prices rose with each intermediary, making spices fabulously expensive in Europe.",
    "This expensive trade motivated Europeans to seek direct sea routes to Asia, launching the age of exploration that would transform global food forever."]]
  ],
  terms:[["Pottage","A thick medieval soup or stew of grains and vegetables."],["Verjuice","Sour juice of unripe grapes, used like vinegar."],["Subtlety","An elaborate medieval sculpture made of sugar or marzipan."],["Le Viandier","A 14th-century French cookbook attributed to Taillevent."],["Kitab al-Tabikh","A 10th-century Arabic cookbook by Ibn Sayyar al-Warraq."],["Shōjin ryōri","Japanese Buddhist vegetarian cuisine."]],
  w:"Medieval Europe, the Islamic world, and Song China developed sophisticated cuisines and spread ingredients that remain central today.",
  src:["Medieval cuisine","The Forme of Cury","Le Viandier","Arab cuisine","Arab Agricultural Revolution","Shōjin-ryōri"],
  q:[["Why was fish so important in medieval Europe?","The Church required fasting from meat on many days","Meat was illegal","Fish was cheaper than bread","Cows were rare"],
     ["Were spices mainly used to hide rotten meat?","No, that is a myth; they were status symbols valued for flavor","Yes, always","Only in England","Only for fish"],
     ["Who compiled 'The Forme of Cury'?","The cooks of Richard II of England","Taillevent","Apicius","Ibn Sayyar al-Warraq"],
     ["Which of these words comes from Arabic or Persian?","Sugar","Bread","Butter","Cheese"],
     ["Which crop did Muslim traders spread to Spain, leading eventually to paella?","Rice","Potatoes","Maize","Tomatoes"],
     ["Song dynasty cities are notable for…","Early restaurants and vibrant street food","The invention of pizza","Banning tea","Eating only raw food"]]},

{ t:"The Columbian Exchange", s:"How 1492 changed the world's food",
  sec:[
  ["A global transformation",[
    "Columbus's voyage in 1492 began the Columbian Exchange, a term coined by historian Alfred Crosby in 1972, the transfer of plants, animals, people, diseases, and ideas between the Americas and the rest of the world. It was arguably the most important event in the history of food.",
    "Before 1492, there were no tomatoes in Italy, no potatoes in Ireland, no chilies in India or Thailand, no chocolate in Switzerland, and no wheat, cattle, pigs, or sugar plantations in the Americas. Within a few centuries, cuisines everywhere were transformed."]],
  ["From the Americas",[
    "The Americas contributed maize, potatoes, sweet potatoes, cassava (manioc), tomatoes, chili peppers, beans (common, lima, and others), squash and pumpkins, peanuts, cacao, vanilla, avocados, pineapples, papayas, sunflowers, and turkeys, along with tobacco.",
    "These crops had huge effects. Potatoes, highly productive and nutritious, fueled population growth in Europe; some historians link them to European population growth and urbanization in the 18th and 19th centuries. Maize and cassava became staples in Africa; sweet potatoes and maize helped China's population expand during the Qing dynasty; and chilies spread rapidly through Asia via Portuguese trade."]],
  ["To the Americas",[
    "Europeans brought wheat, barley, rice, sugarcane, coffee (originally from Ethiopia), bananas, citrus, grapes, olives, onions, and many vegetables, along with cattle, horses, pigs, sheep, goats, and chickens. Cattle and horses transformed the Americas' landscapes and Indigenous cultures; for example, Plains nations adopted horses and reshaped their ways of life.",
    "African foods also crossed the Atlantic, carried with enslaved people: okra, black-eyed peas, yams, sesame (benne), watermelon, rice-growing skills, and cooking techniques like frying and one-pot dishes that shaped the cuisines of the American South, the Caribbean, and Brazil."]],
  ["The dark side",[
    "The Columbian Exchange brought catastrophe to Indigenous Americans. Diseases such as smallpox, measles, and influenza, to which they had no immunity, killed a very large proportion of the population, with estimates often ranging from 50 to 90 percent in many regions within a century or two of contact.",
    "Sugar, coffee, cotton, and tobacco plantations relied on the transatlantic slave trade, which forcibly transported about 12.5 million Africans across the Atlantic between the 16th and 19th centuries, according to the Trans-Atlantic Slave Trade Database. Many foods we enjoy today have histories inseparable from this violence."]],
  ["New fusion cuisines",[
    "Out of the exchange came new hybrid cuisines. Mexican cuisine combined Indigenous maize, beans, chilies, and chocolate with Spanish pork, beef, cheese, wheat, and spices; mole poblano is a celebrated example. Peruvian cuisine fused Andean, Spanish, African, and later Chinese and Japanese influences.",
    "In Europe, tomatoes, initially regarded with suspicion as relatives of poisonous nightshades, became central to Italian and Spanish cooking by the 18th and 19th centuries. In Asia, Sichuan, Hunan, Korean, Thai, and Indian cuisines became famous for chili heat, all within the last few hundred years."]],
  ["A continuing exchange",[
    "Globalization continues the Columbian Exchange: quinoa from the Andes, avocados from Mexico, and sriracha from Thailand are now global foods, and immigrant cuisines constantly create new fusions, such as Korean tacos or Japanese-Peruvian Nikkei cuisine.",
    "Understanding the Columbian Exchange reveals that 'traditional' cuisines are often dynamic products of global contact, conquest, and adaptation."]]
  ],
  terms:[["Columbian Exchange","The transfer of plants, animals, people, and diseases between the Americas and the rest of the world after 1492."],["Cassava (manioc)","A starchy root crop native to South America, now a staple in Africa and Asia."],["Nightshades","The plant family including tomatoes, potatoes, peppers, and eggplants."],["Plantation","A large estate producing cash crops, historically using enslaved labor."],["Fusion cuisine","Cuisine combining elements of different culinary traditions."]],
  w:"The Columbian Exchange reshaped every cuisine on Earth and reminds us that food history is global and often tragic.",
  src:["Columbian exchange","Alfred W. Crosby","Atlantic slave trade","Potato","Chili pepper","Tomato"],
  q:[["Who coined the term 'Columbian Exchange'?","Alfred Crosby","Christopher Columbus","Sidney Mintz","Jared Diamond"],
     ["Which crop came from the Americas?","Tomato","Wheat","Sugarcane","Coffee"],
     ["Which crop did Europeans bring to the Americas?","Sugarcane","Potato","Cacao","Vanilla"],
     ["Which African food crossed the Atlantic with enslaved people?","Okra","Maize","Potato","Cacao"],
     ["About how many Africans were forcibly transported across the Atlantic?","About 12.5 million","About 100,000","About 1 million","About 100 million"],
     ["Why were Europeans initially suspicious of tomatoes?","They are related to poisonous nightshades","They were too expensive","They were illegal","They tasted salty"]]}

]});


/* ---- from cuisine-08.js ---- */
/* CUISINE FOUNDATIONS, part 8: Unit 4 A History of Food, chapters 5-8 */
COURSES.cuisine.units[3].ch.push(

{ t:"The Rise of French Haute Cuisine", s:"La Varenne, Carême, Escoffier, and the restaurant",
  sec:[
  ["Breaking with the Middle Ages",[
    "In the 17th century, French cooking began moving away from heavily spiced medieval dishes toward flavors emphasizing the natural taste of ingredients, butter-based sauces, and herbs. François Pierre de La Varenne's 'Le Cuisinier françois' (1651) marked this shift, introducing roux, bouquet garni, stocks, and recipes like an early hollandaise-style sauce. It is often considered the founding text of modern French cuisine.",
    "The court of Louis XIV at Versailles made dining a ceremony of power. Service à la française, in which many dishes were placed on the table at once in symmetrical arrangements, dominated elite dining."]],
  ["The birth of the restaurant",[
    "The modern restaurant, where customers chose from a menu, sat at private tables, and paid set prices, emerged in Paris in the 1760s–1780s. The word originally referred to restorative broths ('restaurants') sold to people in delicate health. One early establishment was opened by a man named Boulanger around 1765, according to a popular story, though historian Rebecca Spang has shown the history is more complex.",
    "After the French Revolution of 1789, many cooks who had served aristocrats opened restaurants, and the number of Paris restaurants grew rapidly. Brillat-Savarin's 'The Physiology of Taste' (1825) and Grimod de La Reynière's guides to eating established gastronomy as a literary subject; Grimod is sometimes considered the first restaurant critic."]],
  ["Carême, the king of chefs",[
    "Marie-Antoine Carême (1784–1833), abandoned as a child in Paris, rose to become chef to Talleyrand, the Prince Regent of Britain, Tsar Alexander I, and the Rothschilds. He was celebrated for spectacular pièces montées, architectural centerpieces of sugar and pastry inspired by his study of architecture books.",
    "Carême wrote multi-volume works, including 'L'Art de la cuisine française au XIXe siècle', systematizing French cooking and classifying sauces into families. He is often called the first celebrity chef and the founder of grande cuisine, the elaborate cooking of 19th-century elites."]],
  ["Escoffier and modernization",[
    "Georges Auguste Escoffier (1846–1935) modernized and simplified French cuisine for the age of grand hotels. Working with hotelier César Ritz at the Savoy and Carlton in London and the Ritz in Paris, he organized the kitchen brigade, simplified elaborate garnishes, and created dishes like peach Melba (for the Australian opera singer Nellie Melba).",
    "His 'Le Guide culinaire' (1903), with about 5,000 recipes, became the bible of professional French cooking and remains in use. Escoffier also promoted service à la russe, in which dishes are served in sequence, course by course, now the standard for Western dining. He was the first chef awarded France's Legion of Honour, in 1919 (made an officer in 1928)."]],
  ["Guides and stars",[
    "The tire company Michelin published its first guide in 1900 to encourage motorists to travel (and wear out tires). It began awarding stars for restaurants in 1926, and the three-star system was established in the early 1930s: one star for 'a very good restaurant in its category', two for 'excellent cooking, worth a detour', and three for 'exceptional cuisine, worth a special journey'.",
    "Michelin inspectors remain anonymous. Over time, the guide expanded to many countries, and its stars became the most famous measure of restaurant excellence, sometimes criticized for favoring French-style fine dining and for placing immense pressure on chefs."]],
  ["Fernand Point and the 20th century",[
    "Fernand Point (1897–1955), chef of La Pyramide in Vienne, is considered the father of modern French cuisine, emphasizing fresh market ingredients and lighter, refined dishes. He trained many of the chefs who would lead nouvelle cuisine, including Paul Bocuse and the Troisgros brothers.",
    "French cuisine dominated Western fine dining for over two centuries, shaping culinary education, kitchen organization, vocabulary (sauté, purée, mise en place, chef), and ideas of gastronomy worldwide. In 2010, UNESCO inscribed 'the gastronomic meal of the French' as intangible cultural heritage."]]
  ],
  terms:[["Haute cuisine","The elaborate, refined cooking of French elites and fine restaurants."],["Service à la française","Serving many dishes on the table at once."],["Service à la russe","Serving dishes sequentially in courses."],["Pièce montée","An elaborate decorative centerpiece of pastry or sugar."],["Le Guide culinaire","Escoffier's 1903 reference book of French cuisine."],["Michelin star","A rating awarded by the Michelin Guide to restaurants."]],
  w:"French haute cuisine created the professional framework, vocabulary, and restaurant culture that shaped fine dining worldwide.",
  src:["French cuisine","François Pierre de la Varenne","Restaurant","Marie-Antoine Carême","Auguste Escoffier","Michelin Guide"],
  q:[["Which 1651 book is considered a founding text of modern French cuisine?","'Le Cuisinier françois' by La Varenne","'Le Guide culinaire'","'The Physiology of Taste'","'Le Viandier'"],
     ["The word 'restaurant' originally referred to…","Restorative broths","A type of table","A royal palace","A kitchen tool"],
     ["Who is often called the first celebrity chef?","Marie-Antoine Carême","Escoffier","Paul Bocuse","La Varenne"],
     ["Escoffier worked closely with which hotelier?","César Ritz","Conrad Hilton","Michelin","Rothschild"],
     ["What does service à la russe mean?","Serving dishes sequentially in courses","Serving all dishes at once","Russian food only","Self-service"],
     ["Michelin began awarding restaurant stars in…","1926","1800","1900","1975"]]},

{ t:"Industrial Food", s:"Canning, railways, refrigeration, and mass production",
  sec:[
  ["The industrialization of food",[
    "The Industrial Revolution transformed how food was produced, processed, distributed, and eaten. Mechanized agriculture, railways, steamships, canning, refrigeration, and factory processing made food cheaper and more plentiful for many people, while also changing its quality and separating consumers from producers.",
    "Urbanization meant that millions of people no longer grew their own food. Bread, milk, and meat came from factories, dairies, and slaughterhouses, often in unsanitary conditions. Adulteration was common: chalk in bread, water in milk, and toxic dyes in sweets."]],
  ["Canning and refrigeration",[
    "After Appert's 1810 invention, tin cans replaced glass jars, and by the mid-19th century canned food fed armies, sailors, and explorers. Can openers came later than cans; early cans were opened with hammers and chisels.",
    "Refrigerated railway cars from the 1870s allowed meat processed in Chicago's Union Stock Yards to be shipped across the US; Gustavus Swift was a pioneer. Refrigerated ships brought frozen meat from Argentina, Australia, and New Zealand to Britain; the ship Dunedin carried the first successful shipment of frozen New Zealand meat to London in 1882. Home refrigerators became common in American homes in the 1930s–1950s."]],
  ["Food safety reform",[
    "Public outrage over food adulteration and unsanitary conditions led to regulation. In Britain, the Sale of Food and Drugs Act of 1875 addressed adulteration. In the US, Upton Sinclair's novel 'The Jungle' (1906), exposing Chicago's meatpacking industry, helped spur the Pure Food and Drug Act and the Meat Inspection Act, both in 1906. Sinclair famously said he 'aimed at the public's heart, and by accident hit it in the stomach'.",
    "Harvey Wiley, a chemist at the US Department of Agriculture, ran the 'Poison Squad' experiments (from 1902), in which volunteers ate food with common preservatives to test their effects, building support for regulation. The US Food and Drug Administration grew from these efforts."]],
  ["Brands and processed foods",[
    "Industrial production created branded foods: Heinz ketchup (Heinz founded his company in 1869), Kellogg's corn flakes (developed around 1894–1906 by John Harvey Kellogg and his brother Will Keith Kellogg), Campbell's condensed soup (1897), Coca-Cola (1886), and Nabisco crackers. Advertising made them national and international household names.",
    "Margarine, invented by French chemist Hippolyte Mège-Mouriès in 1869 in response to a prize offered by Napoleon III for a cheap butter substitute, and hydrogenated shortening (Crisco, 1911) changed home cooking. Industrial bread became soft and sliced; the first commercial bread-slicing machine was used in Chillicothe, Missouri, in 1928."]],
  ["The Green Revolution",[
    "In the mid-20th century, the Green Revolution dramatically increased crop yields through high-yielding varieties of wheat and rice, synthetic fertilizers, pesticides, and irrigation. Norman Borlaug, who developed disease-resistant wheat varieties in Mexico, won the Nobel Peace Prize in 1970 and is credited with helping prevent famine for many millions of people in South Asia and elsewhere.",
    "Synthetic fertilizers depend on the Haber-Bosch process, developed in Germany around 1909–1913, which fixes nitrogen from the air to make ammonia; some estimates suggest that around half of the world's population today depends on food grown with such fertilizers. The Green Revolution also brought environmental concerns, including water pollution, soil degradation, and reduced crop diversity."]],
  ["Consequences",[
    "Industrial food made calories cheaper and more available than ever, reducing famine in many regions. Yet it also contributed to diets high in processed foods, sugar, and refined grains, linked to rising rates of obesity and related diseases in many countries.",
    "Industrial agriculture raised concerns about animal welfare, environmental damage, and the power of large food companies. These issues continue to drive debates about how we should produce and eat food."]]
  ],
  terms:[["Adulteration","Adding cheaper or harmful substances to food."],["Refrigerated transport","Shipping perishable food in cooled railcars or ships."],["The Jungle","Upton Sinclair's 1906 novel exposing the meatpacking industry."],["Green Revolution","Mid-20th-century increase in crop yields through new varieties and inputs."],["Haber-Bosch process","An industrial method of fixing nitrogen to make ammonia for fertilizer."]],
  w:"Industrialization made food cheap and abundant but transformed its quality and our relationship to it.",
  src:["Industrialization of food","The Jungle","Pure Food and Drug Act","Green Revolution","Norman Borlaug","Haber process"],
  q:[["Which novel helped spur US food safety laws in 1906?","The Jungle","The Grapes of Wrath","Fast Food Nation","Silent Spring"],
     ["What were Harvey Wiley's 'Poison Squad' experiments?","Volunteers ate preservatives to test their effects","Testing poisonous mushrooms","Military rations","Chemical weapons tests"],
     ["Margarine was invented in response to a prize offered by…","Napoleon III","Queen Victoria","Abraham Lincoln","Louis XIV"],
     ["Who won the 1970 Nobel Peace Prize for Green Revolution wheat?","Norman Borlaug","Fritz Haber","Gustavus Swift","Upton Sinclair"],
     ["The Haber-Bosch process produces…","Ammonia for fertilizer","Refined sugar","Canned food","Steel cans"],
     ["What did the ship Dunedin achieve in 1882?","The first successful frozen meat shipment from New Zealand to London","The first canned food shipment","The first steam-powered bakery","The first chocolate export"]]},

{ t:"Twentieth-Century Food Revolutions", s:"Nouvelle cuisine, fast food, and television cooks",
  sec:[
  ["Fast food",[
    "Fast food emerged in the US in the 20th century. White Castle (1921) is often cited as the first fast-food hamburger chain. In 1948, Richard and Maurice McDonald reorganized their San Bernardino, California, restaurant around a limited menu and an assembly-line 'Speedee Service System'. Ray Kroc, a milkshake-machine salesman, franchised the concept from 1955 and later bought the company.",
    "Fast food spread worldwide, symbolizing American culture and globalization. Critics like Eric Schlosser in 'Fast Food Nation' (2001) examined its effects on health, labor, agriculture, and culture. In response to the opening of a McDonald's near Rome's Spanish Steps in 1986, Carlo Petrini helped launch what became the Slow Food movement (formally founded in 1989), promoting local, traditional, and sustainable food."]],
  ["Supermarkets and convenience",[
    "Self-service grocery shopping began with Piggly Wiggly in Memphis in 1916, and supermarkets spread after World War II. Convenience foods, frozen dinners (Swanson's TV dinners, launched in 1953), cake mixes, instant coffee, and microwave meals changed home cooking, especially as more women entered the paid workforce.",
    "The microwave oven, developed after engineer Percy Spencer at Raytheon noticed a chocolate bar melting near radar equipment in 1945, became common in homes from the 1970s–80s."]],
  ["Television and cookbooks",[
    "Cookbooks and television brought cooking knowledge to mass audiences. Julia Child's 'Mastering the Art of French Cooking' (1961, with Simone Beck and Louisette Bertholle) and her television show 'The French Chef' (from 1963) taught Americans French cooking with warmth and humor. Elizabeth David in Britain introduced Mediterranean food to postwar readers.",
    "Later television cooks and food channels, including the Food Network (launched in 1993), made chefs into celebrities. Personalities such as Jamie Oliver, Gordon Ramsay, Nigella Lawson, Anthony Bourdain, and Martin Yan influenced how millions cook, travel, and think about food."]],
  ["Nouvelle cuisine",[
    "In the 1960s and 1970s, French chefs including Paul Bocuse, Michel Guérard, the Troisgros brothers, and Alain Chapel developed nouvelle cuisine ('new cuisine'). The critics Henri Gault and Christian Millau popularized the term and published 'ten commandments' in 1973, including shorter cooking times, fresh market ingredients, lighter sauces without heavy flour-based thickeners, simpler menus, and innovation.",
    "Nouvelle cuisine introduced plated service, with dishes arranged by the chef in the kitchen rather than served from platters, and drew inspiration from Japanese aesthetics. Its excesses, tiny portions on huge plates, were mocked, but it permanently changed fine dining."]],
  ["California cuisine and the farm-to-table movement",[
    "In 1971, Alice Waters opened Chez Panisse in Berkeley, California, focusing on fresh, local, seasonal, organic ingredients from small farms. 'California cuisine' blended French technique with Mediterranean and Asian influences and an emphasis on produce. Waters became a leading advocate for school gardens through the Edible Schoolyard project (1995).",
    "The farm-to-table movement spread widely, encouraging relationships between chefs and farmers, farmers' markets, and seasonal menus. Michael Pollan's 'The Omnivore's Dilemma' (2006) further popularized questions about where food comes from."]],
  ["Globalization of tastes",[
    "Immigration and travel made foreign cuisines mainstream: Italian, Chinese, Mexican, Indian, Thai, Japanese, and Vietnamese restaurants spread worldwide. Chicken tikka masala was declared 'a true British national dish' by Foreign Secretary Robin Cook in 2001. Sushi, once exotic in the West, became an everyday food.",
    "This globalization brought both creative fusion and debates about authenticity and cultural appropriation, as well as recognition of immigrant cooks' contributions to national cuisines."]]
  ],
  terms:[["Fast food","Quickly prepared, standardized food served at chain restaurants."],["Slow Food","A movement founded in Italy promoting local, traditional food."],["Nouvelle cuisine","A lighter, fresher French cuisine of the 1960s–70s."],["Plated service","Arranging food on individual plates in the kitchen."],["Farm-to-table","Sourcing food directly from local farms."],["California cuisine","A style emphasizing fresh local produce, pioneered at Chez Panisse."]],
  w:"Twentieth-century revolutions in fast food, media, and fine dining shaped how we eat today.",
  src:["Fast food","McDonald's","Slow Food","Nouvelle cuisine","Chez Panisse","Julia Child"],
  q:[["Who franchised McDonald's from 1955?","Ray Kroc","Richard McDonald","Colonel Sanders","Walt Disney"],
     ["The Slow Food movement began in response to…","A McDonald's opening near Rome's Spanish Steps","A French chef's death","A food safety scandal","The invention of the microwave"],
     ["Who wrote 'Mastering the Art of French Cooking' with collaborators?","Julia Child","Elizabeth David","Alice Waters","Nigella Lawson"],
     ["Who popularized the term 'nouvelle cuisine'?","Henri Gault and Christian Millau","Paul Bocuse alone","Escoffier","Michelin"],
     ["Alice Waters opened which restaurant in 1971?","Chez Panisse","The French Laundry","Noma","El Bulli"],
     ["How was the microwave oven discovered?","A chocolate bar melted near radar equipment","By heating water with magnets","In a bakery","By accident in a kitchen fire"]]},

{ t:"Modern Gastronomy", s:"El Bulli, Noma, and food in the 21st century",
  sec:[
  ["Modernist cuisine",[
    "In the 1990s and 2000s, a group of chefs applied scientific techniques and ideas to cooking, an approach variously called molecular gastronomy, modernist cuisine, or techno-emotional cuisine. Ferran Adrià of El Bulli, a restaurant on Spain's Costa Brava, became its most famous figure. El Bulli was named best restaurant in the world multiple times and closed as a restaurant in 2011.",
    "Adrià's team created 'deconstructed' dishes, foams (espumas) made with siphons, spherification (forming liquid-filled spheres using sodium alginate and calcium, so that 'olives' burst in the mouth), and dishes that surprised and played with expectations. Heston Blumenthal at The Fat Duck in England developed multisensory dishes, such as 'Sound of the Sea', served with headphones playing ocean sounds."]],
  ["Tools and techniques",[
    "Modernist kitchens use tools like immersion circulators for sous vide, rotary evaporators, liquid nitrogen for instant freezing, dehydrators, and hydrocolloids such as agar, xanthan gum, and gellan for gels and textures. Nathan Myhrvold's 'Modernist Cuisine' (2011), a 2,400-page, six-volume work, documented the science and techniques in detail.",
    "Many of these techniques have entered everyday professional kitchens. Sous vide, once exotic, is now common in restaurants and homes, valued for precise and consistent results."]],
  ["New Nordic cuisine",[
    "In 2003, René Redzepi and Claus Meyer opened Noma in Copenhagen. In 2004, a group of Nordic chefs signed the 'New Nordic Kitchen' manifesto, calling for purity, seasonality, local ingredients, and Nordic traditions. Noma foraged wild plants, used fermentation, and celebrated ingredients from the Nordic region, such as sea buckthorn, ants, and moss.",
    "Noma was ranked number one on the World's 50 Best Restaurants list several times, influencing chefs worldwide to explore their own local ecologies. Noma closed its regular Copenhagen restaurant service at the end of 2024, shifting toward a food laboratory and pop-up model."]],
  ["Rankings, media, and the chef as artist",[
    "The World's 50 Best Restaurants list, begun in 2002 by the British magazine Restaurant, became influential alongside the Michelin Guide, though both are criticized for subjectivity and a Eurocentric focus. Social media, especially Instagram, has made dishes photogenic and turned restaurants into global destinations.",
    "Netflix's 'Chef's Table' (from 2015) presented chefs as artists. Famous contemporary chefs include Massimo Bottura (Osteria Francescana, Modena), Grant Achatz (Alinea, Chicago), Virgilio Martínez (Central, Lima), Gaggan Anand (Bangkok), Dominique Crenn (San Francisco, the first woman chef in the US to earn three Michelin stars, in 2018), and Mitsuharu Tsumura (Maido, Lima, a leader of Nikkei cuisine)."]],
  ["Street food and democratization",[
    "At the same time, street food and casual dining gained prestige. In 2016, the Michelin Guide awarded a star to Hong Kong Soya Sauce Chicken Rice and Noodle, a hawker stall in Singapore run by Chan Hon Meng, then described as the cheapest Michelin-starred meal in the world. Singapore's hawker culture was inscribed by UNESCO in 2020.",
    "Chefs like David Chang (Momofuku, founded 2004) and Roy Choi (Kogi BBQ taco trucks, 2008) blended high and low, Asian and American, influencing a generation of casual restaurants. Food trucks, markets, and pop-ups made innovative food more accessible."]],
  ["Food today",[
    "Contemporary food culture is shaped by concerns about sustainability and climate change, plant-based diets, alternative proteins (plant-based meats and cultivated meat, the latter first approved for sale in Singapore in 2020), food waste reduction, and fair labor. Chefs increasingly act as advocates, from José Andrés's World Central Kitchen, founded in 2010, feeding people after disasters, to chefs fighting food waste.",
    "The history of food shows constant change: each era's innovations become the next era's traditions. Today's cooks inherit all of this history and continue to reinvent what and how we eat."]]
  ],
  terms:[["Molecular gastronomy","Applying scientific techniques and ideas to cooking."],["Spherification","Forming liquid-filled spheres using alginate and calcium."],["Espuma","A foam made with a siphon."],["Hydrocolloid","A substance like agar or xanthan gum used to gel or thicken."],["New Nordic cuisine","A movement emphasizing Nordic, local, seasonal ingredients."],["Cultivated meat","Meat grown from animal cells without raising and slaughtering animals."]],
  w:"Modern gastronomy blends science, art, sustainability, and street food, continuing cuisine's constant reinvention.",
  src:["Molecular gastronomy","El Bulli","Noma (restaurant)","Modernist Cuisine","The World's 50 Best Restaurants","World Central Kitchen"],
  q:[["Which chef led El Bulli?","Ferran Adrià","René Redzepi","Heston Blumenthal","Massimo Bottura"],
     ["What is spherification?","Forming liquid-filled spheres with alginate and calcium","Rolling meatballs","Freezing in liquid nitrogen","Baking round bread"],
     ["Noma is located in…","Copenhagen","Stockholm","Oslo","Helsinki"],
     ["Which hawker stall received a Michelin star in 2016?","Hong Kong Soya Sauce Chicken Rice and Noodle in Singapore","A taco truck in Los Angeles","A ramen shop in Tokyo","A pizza stall in Naples"],
     ["Which country first approved cultivated meat for sale in 2020?","Singapore","USA","Israel","Netherlands"],
     ["José Andrés founded which organization?","World Central Kitchen","Slow Food","Chez Panisse Foundation","Edible Schoolyard"]]}

);


/* ---- from cuisine-09.js ---- */
/* CUISINE FOUNDATIONS, part 9: Unit 5 Cuisines of Europe, chapters 1-4 */
COURSES.cuisine.units.push({ t:"Cuisines of Europe", ch:[

{ t:"France", s:"Regions, classics, and the art of the meal",
  sec:[
  ["A cuisine of regions",[
    "French cuisine is famous for its haute cuisine, but it is rooted in strongly distinct regional cooking (cuisine du terroir). Terroir, the idea that a product's character reflects its place of origin, soil, climate, and traditions, is central to French food culture, especially for wine and cheese.",
    "Broadly, northern France cooks with butter and cream, the south with olive oil, and the southwest with duck and goose fat. France has a strong system of protected designations (AOC/AOP) for wines, cheeses, butter, poultry (such as Bresse chicken), lentils (Le Puy), and more."]],
  ["Northern and eastern France",[
    "Normandy is famous for dairy, butter, cream, Camembert, apples, cider, Calvados (apple brandy), and seafood like mussels with cream (moules à la normande). Brittany is known for crêpes and buckwheat galettes, salted butter, oysters, and the butter cake kouign-amann.",
    "Alsace, near Germany, has choucroute garnie (sauerkraut with sausages and pork), tarte flambée (flammekueche), and Riesling and Gewürztraminer wines. Burgundy offers boeuf bourguignon, coq au vin, escargots in garlic butter, Dijon mustard, and great wines. Lyon, often called France's gastronomic capital, is famed for its bouchons (casual restaurants serving hearty dishes like quenelles, sausages, and tablier de sapeur, breaded tripe) and as the home of Paul Bocuse."]],
  ["Southern and southwestern France",[
    "Provence uses olive oil, garlic, tomatoes, herbs, and vegetables: bouillabaisse (the fish stew of Marseille, with rouille sauce), ratatouille, pissaladière (onion tart with anchovies), tapenade, and aioli. Nice has socca (chickpea pancake) and salade niçoise.",
    "Southwestern France (Gascony and Périgord) is the land of duck and goose: confit de canard, magret, foie gras, and cassoulet, the white-bean stew claimed by Castelnaudary, Carcassonne, and Toulouse. Périgord is also famous for black truffles. The Basque Country brings piment d'Espelette chilies and Bayonne ham."]],
  ["Paris and the bistro",[
    "Paris gathered the best of France's regions and developed its own institutions: the bistro (small, casual restaurants with classic dishes like steak frites, onion soup, and duck confit), the brasserie (larger, often Alsatian-influenced, open long hours, serving beer, choucroute, and seafood platters), the café, and the boulangerie and pâtisserie.",
    "Classic French dishes include blanquette de veau, pot-au-feu, gratin dauphinois, quiche lorraine, sole meunière, croque-monsieur, and desserts like crème brûlée, tarte Tatin, profiteroles, and soufflés. The macaron, popularized by the Parisian patisserie Ladurée, is now famous worldwide."]],
  ["The French meal",[
    "The traditional French meal has a structure: apéritif (a pre-dinner drink with small bites), entrée (starter, not main course as in American English), plat principal (main course), cheese course, and dessert, followed by coffee and sometimes a digestif. Meals are leisurely and social, with bread and wine on the table.",
    "UNESCO's 2010 recognition of 'the gastronomic meal of the French' emphasized these rituals: choosing good products, pairing food and wine, setting a beautiful table, and the art of conversation at table. Long lunches remain common, and children learn to eat varied foods in courses at school canteens."]],
  ["French influence",[
    "French cuisine's influence on the world is enormous: its techniques form the basis of culinary training globally, its vocabulary is used in kitchens everywhere, and its wines set standards for the industry. French colonial history also spread French bread and pastries to Vietnam (banh mi), North and West Africa, and the Caribbean.",
    "Today French cuisine continues to evolve, with bistronomie (high-quality cooking in casual settings, from the 1990s), immigrant influences from North Africa (couscous is among France's most popular dishes), and young chefs blending tradition and innovation."]]
  ],
  terms:[["Terroir","The character a product takes from its place of origin."],["AOC/AOP","French and EU protected designations of origin."],["Bistro","A small, casual French restaurant."],["Bouchon","A traditional Lyonnais restaurant."],["Brasserie","A large French restaurant, often serving beer and Alsatian dishes."],["Bistronomie","High-quality cooking in a casual bistro setting."]],
  w:"French cuisine's regional depth and professional techniques make it a cornerstone of culinary education and food culture.",
  src:["French cuisine","Terroir","Lyonnaise cuisine","Bouillabaisse","Cassoulet","Gastronomic meal of the French"],
  q:[["What does 'terroir' mean?","The character a product takes from its place","A type of earthenware","A French chef","A cooking technique"],
     ["Which region is famous for Camembert, cider, and Calvados?","Normandy","Provence","Alsace","Burgundy"],
     ["Bouillabaisse is the fish stew of…","Marseille","Paris","Lyon","Bordeaux"],
     ["Which city is often called France's gastronomic capital?","Lyon","Nice","Strasbourg","Toulouse"],
     ["In French, 'entrée' means…","The starter","The main course","Dessert","The cheese course"],
     ["Which French region is famous for duck confit and foie gras?","Southwestern France","Normandy","Brittany","Alsace"]]},

{ t:"Italy", s:"A cuisine of regions and ingredients",
  sec:[
  ["Unity and diversity",[
    "Italy was unified only in 1861, and its cuisine remains intensely regional; Italians often identify with the food of their town or region (campanilismo). The cookbook that helped create a national cuisine was Pellegrino Artusi's 'Science in the Kitchen and the Art of Eating Well' (1891), which collected recipes from across the new nation and remains a classic.",
    "Italian cooking emphasizes high-quality ingredients prepared simply. Common threads include olive oil (especially in the center and south), butter (in the north), pasta, bread, tomatoes, cheese, cured meats, vegetables, herbs, and wine. Italy has more protected (PDO/PGI) food products than any other EU country."]],
  ["Northern Italy",[
    "Northern Italy, richer in dairy and pastureland, cooks with butter and favors rice and polenta as well as pasta. Lombardy has risotto alla milanese (with saffron), osso buco, cotoletta, and cheeses like Gorgonzola and Taleggio. Piedmont is famed for white truffles from Alba, Barolo and Barbaresco wines, vitello tonnato, and agnolotti. Liguria has pesto, focaccia, and seafood.",
    "Emilia-Romagna, often called Italy's food heartland, produces Parmigiano-Reggiano, prosciutto di Parma, traditional balsamic vinegar of Modena, mortadella, and fresh egg pastas like tagliatelle al ragù (the true Bolognese), lasagne, and tortellini. Veneto offers risotto, polenta, radicchio, tiramisu, and Prosecco."]],
  ["Central Italy",[
    "Tuscany is known for simplicity: bistecca alla fiorentina (thick T-bone steaks), ribollita (bread and bean soup), pappa al pomodoro, unsalted bread, extra-virgin olive oil, Chianti wine, and pecorino cheese. Umbria has black truffles and lentils.",
    "Rome's classic pastas include carbonara (guanciale, eggs, pecorino, black pepper), cacio e pepe (pecorino and pepper), amatriciana (guanciale and tomato, from Amatrice), and gricia. Roman Jewish cuisine contributed carciofi alla giudia (fried artichokes). Rome's cucina povera also includes offal dishes like coda alla vaccinara (oxtail stew)."]],
  ["Southern Italy and the islands",[
    "Southern Italy uses more olive oil, tomatoes, dried pasta, vegetables, and seafood, with chili in Calabria. Naples, in Campania, is the home of pizza; the Neapolitan pizzaiuolo's art was inscribed by UNESCO in 2017. Pizza Margherita (tomato, mozzarella, basil) is traditionally said to have been named for Queen Margherita in 1889. Campania also produces mozzarella di bufala and San Marzano tomatoes.",
    "Puglia has orecchiette and burrata; Sicily blends Greek, Arab, Norman, and Spanish influences, with arancini, caponata, pasta alla Norma, couscous in Trapani, cannoli, cassata, and granita. Sardinia has pane carasau (thin crisp bread), culurgiones, and pecorino sardo."]],
  ["The Italian meal",[
    "A traditional Italian meal includes antipasto (starters), primo (first course: pasta, risotto, or soup), secondo (main course of meat or fish) with contorno (vegetable side), and dolce (dessert), followed by espresso and perhaps a digestivo like grappa or amaro. Everyday meals are simpler.",
    "Italians have strong food customs: cappuccino is typically drunk only in the morning, cheese is generally not added to seafood pasta, and pasta is sauced lightly. Food is tied to seasons, festivals, and family; Sunday lunch is a cherished ritual."]],
  ["Italian food abroad",[
    "Mass emigration, especially from southern Italy to the Americas between the 1880s and 1920s, spread Italian food worldwide. In the US, Italian-American cuisine developed its own dishes, such as spaghetti and meatballs, chicken parmesan, fettuccine Alfredo (based on a Roman dish created by Alfredo di Lelio), and New York and Chicago pizza styles.",
    "Italian food became one of the world's most popular cuisines. In 2025, Italian cuisine as a whole was inscribed on UNESCO's intangible heritage list, recognizing its social and cultural practices."]]
  ],
  terms:[["Campanilismo","Strong local pride, including in food, in Italy."],["Cucina povera","'Poor cooking': frugal traditional dishes."],["Primo and secondo","The first (pasta, rice) and second (meat, fish) courses of an Italian meal."],["Guanciale","Cured pork cheek, used in Roman pastas."],["Ragù","A slow-cooked meat sauce."],["Pizzaiuolo","A pizza maker, especially in Naples."]],
  w:"Italian cuisine shows how simple, excellent ingredients and regional traditions create one of the world's most loved food cultures.",
  src:["Italian cuisine","Pellegrino Artusi","Emilia-Romagna","Neapolitan pizza","Roman cuisine","Sicilian cuisine"],
  q:[["Which 1891 cookbook helped create a national Italian cuisine?","Artusi's 'Science in the Kitchen and the Art of Eating Well'","'The Silver Spoon'","'Le Guide culinaire'","'Apicius'"],
     ["Which region produces Parmigiano-Reggiano and prosciutto di Parma?","Emilia-Romagna","Tuscany","Sicily","Lombardy"],
     ["Carbonara traditionally includes…","Guanciale, eggs, pecorino, and pepper","Cream and ham","Tomato and basil","Clams and garlic"],
     ["Where was pizza born?","Naples","Rome","Milan","Florence"],
     ["What is the 'primo' in an Italian meal?","The first course of pasta, risotto, or soup","The appetizer","The meat course","Dessert"],
     ["Sicilian cuisine shows strong influence from…","Arab rule","Japan","Russia","Mexico"]]},

{ t:"Spain and Portugal", s:"Tapas, paella, bacalhau, and Iberian traditions",
  sec:[
  ["Iberian foundations",[
    "Spanish and Portuguese cuisines share Roman, Moorish, Jewish, and Christian influences, Mediterranean and Atlantic ingredients, and a central role in the Columbian Exchange. Olive oil, garlic, bread, pork, seafood, legumes, and wine are foundations.",
    "Nearly eight centuries of Muslim rule in parts of Iberia (711–1492) brought rice, saffron, almonds, citrus, sugar, eggplants, and spices. After 1492, Iberians introduced American foods like tomatoes, peppers, potatoes, and chocolate to Europe."]],
  ["Spanish regions",[
    "Spain's regions have distinct cuisines. Valencia is the home of paella, cooked in a wide, shallow pan; the original paella valenciana uses rabbit, chicken, green beans, and garrofó beans, while seafood paella is a later variation. Andalusia offers gazpacho, salmorejo, fried fish (pescaíto frito), and sherry from Jerez.",
    "The Basque Country is a culinary powerhouse with pintxos (small snacks often on bread), bacalao al pil pil, txakoli wine, and gastronomic societies (txokos). San Sebastián has one of the highest concentrations of Michelin stars per capita in the world. Galicia is famed for seafood, pulpo a la gallega (octopus with paprika and olive oil), and Albariño wine. Catalonia has pa amb tomàquet, escalivada, crema catalana, and the sauces romesco and picada."]],
  ["Tapas and Spanish eating",[
    "Tapas are small dishes served with drinks, eaten while moving from bar to bar (tapeo). Classics include patatas bravas, tortilla española (potato omelet), croquetas, gambas al ajillo, pimientos de Padrón, albóndigas, and jamón. Spaniards eat late: lunch often around 2–3 pm and dinner around 9–10 pm or later.",
    "Spain's cured hams are world-famous: jamón serrano and, especially, jamón ibérico, graded by the pigs' diet and breed, with jamón ibérico de bellota from free-range pigs fattened on acorns in the dehesa woodlands. Spanish cheeses include Manchego, Cabrales, and Idiazabal; chorizo is flavored with pimentón (smoked paprika)."]],
  ["Modern Spanish cuisine",[
    "From the 1990s, Spanish chefs led a culinary revolution. Ferran Adrià at El Bulli pioneered avant-garde techniques, while the Roca brothers' El Celler de Can Roca in Girona and Basque chefs like Juan Mari Arzak and Martín Berasategui earned international acclaim.",
    "Spain is also the world's largest producer of olive oil and has extensive wine regions, including Rioja, Ribera del Duero, Priorat, and cava sparkling wine from Catalonia."]],
  ["Portugal",[
    "Portuguese cuisine is hearty, based on seafood, pork, bread, olive oil, and garlic. Bacalhau (salted cod) is the national obsession, prepared in countless ways, such as bacalhau à Brás (with eggs and potatoes). Grilled sardines are central to Lisbon's June festivals. Other dishes include caldo verde (kale and potato soup), cozido à portuguesa (boiled meats and vegetables), and the Porto sandwich francesinha.",
    "Portuguese pastry is rich in egg yolks, possibly because convents used egg whites for starching clothes and clarifying wine and made sweets with the yolks. Pastéis de nata are the most famous. Portugal also produces port wine, from the Douro Valley, fortified with brandy, as well as Madeira and vinho verde."]],
  ["The Iberian world",[
    "Portuguese and Spanish explorers spread foods globally: the Portuguese brought chilies to India and Asia, influenced Japanese tempura (from Portuguese fried fish), and shaped Goan cuisine (vindaloo derives from Portuguese carne de vinha d'alhos, meat in wine and garlic). Spanish colonization shaped cuisines across Latin America and the Philippines.",
    "In return, Iberian cuisine embraced foods from its empires: potatoes in tortilla, peppers in pimentón, and chocolate in Spanish hot chocolate with churros."]]
  ],
  terms:[["Tapas","Small Spanish dishes served with drinks."],["Pintxos","Basque small snacks, often on bread."],["Jamón ibérico de bellota","Spanish ham from acorn-fed Iberian pigs."],["Pimentón","Spanish paprika, often smoked."],["Bacalhau","Portuguese salted, dried cod."],["Port","A fortified wine from Portugal's Douro Valley."]],
  w:"Iberian cuisines combine Mediterranean, Atlantic, Moorish, and American influences and spread foods around the world.",
  src:["Spanish cuisine","Portuguese cuisine","Paella","Tapas","Jamón ibérico","Pastel de nata"],
  q:[["The original paella valenciana contains…","Rabbit, chicken, and green beans","Only seafood","Chorizo and potatoes","Lamb and lentils"],
     ["What are pintxos?","Basque small snacks","Portuguese pastries","Spanish soups","Galician wines"],
     ["Jamón ibérico de bellota comes from pigs fed on…","Acorns","Corn","Fish","Apples"],
     ["What is the Portuguese national obsession?","Bacalhau (salted cod)","Paella","Sushi","Tortilla"],
     ["Which Portuguese dish influenced vindaloo?","Carne de vinha d'alhos","Caldo verde","Francesinha","Cozido"],
     ["Port wine comes from which valley?","Douro","Rioja","Loire","Napa"]]},

{ t:"The British Isles", s:"Roasts, pies, puddings, and a changing table",
  sec:[
  ["Reputation and reality",[
    "British food long had a poor reputation, partly due to wartime and postwar rationing (which in Britain lasted until 1954), industrial processing, and the loss of rural traditions during early industrialization. Yet Britain and Ireland have rich traditions of roasting, baking, dairy, game, seafood, and preserves, and British cooking has been revitalized since the 1990s.",
    "The British Isles have cool, wet climates suited to grasslands, producing excellent beef, lamb, dairy, and cheeses, and surrounded by seas rich in fish and shellfish."]],
  ["English traditions",[
    "The Sunday roast, with roast beef, Yorkshire pudding (a batter baked in hot fat), roast potatoes, vegetables, and gravy, is an English institution; the French nickname for the English, 'les rosbifs', reflects roast beef's long association with England. Pies are central: pork pies, steak and kidney pie, cottage and shepherd's pie (with minced beef or lamb under mashed potato), and Cornish pasties (with protected status).",
    "The full English breakfast includes eggs, bacon, sausages, black pudding, baked beans, tomatoes, mushrooms, and toast. Fish and chips became a working-class staple in the 19th century; the combination is often credited partly to Jewish immigrants who brought fried fish traditions from Portugal and Spain. Afternoon tea, with sandwiches, scones with clotted cream and jam, and cakes, is credited to Anna, Duchess of Bedford, in the 1840s."]],
  ["Puddings and baking",[
    "In Britain, 'pudding' can mean dessert in general or specific steamed or baked dishes: sticky toffee pudding, bread and butter pudding, Christmas pudding (rich with dried fruit and suet, often flamed with brandy), spotted dick, and trifle. Crumbles, Eton mess, and Bakewell tart are other favorites.",
    "British baking traditions include scones, crumpets, Victoria sponge, shortbread (Scottish), and Welsh cakes. Television's 'The Great British Bake Off' (from 2010) revived interest in home baking."]],
  ["Scotland, Wales, and Ireland",[
    "Scotland is known for salmon, beef (Aberdeen Angus), lamb, game, oats (porridge and oatcakes), haggis (sheep offal with oats and spices, cooked in a stomach or casing, celebrated on Burns Night), cullen skink (smoked haddock soup), and Scotch whisky. Wales has cawl (lamb and leek stew), Welsh rarebit (cheese on toast), laverbread (seaweed), and Welsh lamb.",
    "Ireland's cuisine features potatoes (colcannon and champ), soda bread (leavened with baking soda and buttermilk, which suited soft Irish wheat), Irish stew, bacon and cabbage, excellent butter and dairy, seafood, and stout. The Great Famine of 1845–1852, caused by potato blight combined with British policies, killed about a million people and drove a million more to emigrate, profoundly shaping Irish history and diaspora food culture."]],
  ["Empire and immigration",[
    "The British Empire brought tea, sugar, spices, and Indian influences to Britain: kedgeree (from Indian khichdi), mulligatawny soup, chutneys, and Worcestershire sauce (created in Worcester by Lea & Perrins in the 1830s, inspired by Indian flavors). Postwar immigration from South Asia, the Caribbean, China, and elsewhere transformed British eating; curry houses, mostly run by Bangladeshi Britons, became national institutions.",
    "Chicken tikka masala, often said to have been created in Britain (Glasgow is among claimed origins), became a symbol of multicultural Britain. Today London is one of the world's most diverse food cities."]],
  ["Modern British cooking",[
    "Since the 1990s, chefs like Fergus Henderson (St. John), Heston Blumenthal, Jamie Oliver, and others revitalized British food, emphasizing seasonal, local, and nose-to-tail cooking. Gastropubs, pubs serving high-quality food, emerged from 1991 with The Eagle in London. Farmers' markets and artisanal producers have revived traditional cheeses like Stilton, Cheddar, and Stinking Bishop.",
    "British cuisine today combines tradition, global influences, and a strong focus on quality ingredients."]]
  ],
  terms:[["Sunday roast","A traditional British meal of roast meat and accompaniments."],["Yorkshire pudding","A puffy batter baked in hot fat."],["Pudding","British term for dessert or certain steamed or baked dishes."],["Haggis","Scottish dish of sheep offal, oats, and spices."],["Soda bread","Irish bread leavened with baking soda and buttermilk."],["Gastropub","A pub serving high-quality food."]],
  w:"British and Irish cuisines, long underrated, have deep traditions and have been transformed by empire, immigration, and a modern revival.",
  src:["British cuisine","English cuisine","Scottish cuisine","Irish cuisine","Fish and chips","Great Famine (Ireland)"],
  q:[["When did British food rationing end?","1954","1945","1918","1970"],
     ["Who is credited with popularizing afternoon tea in the 1840s?","Anna, Duchess of Bedford","Queen Victoria","Elizabeth David","Mrs Beeton"],
     ["Haggis is traditionally celebrated on…","Burns Night","Christmas","St. Patrick's Day","Bonfire Night"],
     ["Irish soda bread is leavened with…","Baking soda and buttermilk","Yeast","Sourdough","Eggs"],
     ["Worcestershire sauce was created by…","Lea & Perrins","Heinz","Escoffier","Cadbury"],
     ["The first gastropub is often said to be…","The Eagle in London, 1991","The Savoy","The Fat Duck","St. John"]]}

]});


/* ---- from cuisine-10.js ---- */
/* CUISINE FOUNDATIONS, part 10: Unit 5 Cuisines of Europe, chapters 5-8 */
COURSES.cuisine.units[4].ch.push(

{ t:"Germany and Central Europe", s:"Bread, sausage, beer, and the coffeehouse",
  sec:[
  ["German foundations",[
    "German cuisine reflects a cool climate, strong regional identities, and traditions of preserving food. Staples include pork, potatoes, cabbage, bread, and dairy. Germany is famous for its bread culture; the German Bread Institute registers over 3,000 varieties, and 'German bread culture' was added to Germany's national inventory of intangible heritage in 2014.",
    "Sausages (Wurst) come in over 1,000 varieties: Bratwurst (Nuremberg and Thuringian versions have protected status), Weisswurst (Munich's white veal sausage, traditionally eaten before noon), Frankfurter, Bockwurst, and Currywurst (sausage with curry ketchup, invented in Berlin, often credited to Herta Heuwer in 1949)."]],
  ["Regional German dishes",[
    "Bavaria offers Schweinshaxe (roast pork knuckle), pretzels (Brezn), Weisswurst, dumplings (Knödel), and beer gardens. Swabia (in the southwest) has Spätzle (egg noodles) and Maultaschen (large stuffed pasta). The Rhineland has Sauerbraten (pot roast marinated in vinegar and spices), and the north has seafood like herring and Labskaus (a sailors' hash).",
    "Germans love cakes (Kuchen and Torten), such as Black Forest cake (Schwarzwälder Kirschtorte), Bienenstich, Stollen at Christmas, and Lebkuchen (gingerbread). The afternoon 'Kaffee und Kuchen' is a cherished ritual. Asparagus season (Spargelzeit) in spring is celebrated with white asparagus and hollandaise."]],
  ["Beer",[
    "Germany has a famous beer tradition. The Bavarian Reinheitsgebot ('purity law') of 1516 restricted beer ingredients to water, barley, and hops (yeast was added later once understood). Styles include lager types like Helles, Pils, Märzen, and Bock, wheat beers (Weissbier/Hefeweizen), Cologne's Kölsch, and Düsseldorf's Altbier.",
    "Munich's Oktoberfest, first held in 1810 to celebrate a royal wedding, is the world's largest beer festival, attracting about six million visitors each year."]],
  ["Austria and the coffeehouse",[
    "Austrian cuisine reflects the multiethnic Habsburg Empire, blending German, Hungarian, Czech, Italian, and Balkan influences. Wiener Schnitzel (breaded veal cutlet, protected by name in Austria for veal), Tafelspitz (boiled beef with horseradish and apple sauce), and goulash are classics.",
    "Vienna's coffeehouse culture, said to date to the late 17th century after the Ottoman siege of 1683, was inscribed by UNESCO on Austria's national list of intangible heritage in 2011. Coffeehouses serve coffee with water and newspapers, along with famous pastries: Sachertorte, Apfelstrudel (apple strudel), Kaiserschmarrn (shredded pancake), and Linzer Torte. Croissants may descend from the Austrian Kipferl."]],
  ["Switzerland, Czechia, and Hungary",[
    "Switzerland, multilingual and alpine, contributes cheese (Emmental, Gruyère, Appenzeller), fondue, raclette, rösti, Bircher muesli (created by doctor Maximilian Bircher-Benner around 1900), and world-famous chocolate. Czech cuisine includes svíčková (beef in creamy vegetable sauce), knedlíky (bread dumplings), roast pork with sauerkraut, and Pilsner beer, first brewed in Plzeň in 1842; Czechs drink more beer per person than any other nation.",
    "Hungary is famous for paprika, which became central to its cuisine in the 19th century: gulyás (goulash, originally a herdsmen's soup), paprikás csirke (chicken paprikash), halászlé (fisherman's soup), lángos (fried bread), and pastries like Dobos torte. Tokaji is Hungary's renowned sweet wine."]],
  ["Central European traditions",[
    "Central Europe shares dumplings, sour cream, cabbage, pickles, smoked meats, rye bread, and rich pastries, along with Christmas markets selling mulled wine (Glühwein), roasted nuts, and gingerbread. Jewish culinary traditions were also central here before the Holocaust, contributing dishes like gefilte fish, challah, and bagels, which traveled with emigrants to America.",
    "These cuisines are hearty, seasonal, and deeply tied to festivals, from Easter breads to Christmas cookies."]]
  ],
  terms:[["Wurst","German for sausage."],["Reinheitsgebot","The Bavarian beer purity law of 1516."],["Spätzle","Small Swabian egg noodles."],["Wiener Schnitzel","Breaded, fried veal cutlet from Vienna."],["Kaffee und Kuchen","The German afternoon coffee and cake ritual."],["Gulyás","Hungarian goulash, a paprika-rich soup or stew."]],
  w:"Central European cuisines are rich in bread, beer, sausage, and pastry traditions that spread worldwide.",
  src:["German cuisine","Reinheitsgebot","Austrian cuisine","Viennese coffee house","Hungarian cuisine","Czech cuisine"],
  q:[["What did the 1516 Reinheitsgebot regulate?","Beer ingredients","Bread prices","Sausage names","Cheese aging"],
     ["Weisswurst is traditionally eaten…","Before noon","At midnight","Only at Christmas","With ketchup"],
     ["When was Oktoberfest first held?","1810","1516","1900","1950"],
     ["Vienna's coffeehouse culture is said to date from after…","The Ottoman siege of 1683","World War I","The French Revolution","The Roman Empire"],
     ["Pilsner beer was first brewed in…","Plzeň","Munich","Vienna","Budapest"],
     ["Which spice is central to Hungarian cuisine?","Paprika","Saffron","Cumin","Cinnamon"]]},

{ t:"Eastern Europe and Russia", s:"Rye, beets, dumplings, and the zakuski table",
  sec:[
  ["A shared table",[
    "The cuisines of Eastern Europe, including Russia, Ukraine, Poland, Belarus, the Baltic states, and others, share foods suited to cold climates and short growing seasons: rye bread, buckwheat (kasha), potatoes, cabbage, beets, mushrooms (foraging is a beloved tradition), dairy (sour cream, kefir, tvorog), pickles, and preserved meats and fish.",
    "Orthodox and Catholic fasting calendars shaped diets, with many meatless days featuring fish, mushrooms, and vegetables. Soviet rule standardized much food culture in the 20th century, creating shared dishes like Olivier salad and 'herring under a fur coat' that remain New Year's favorites across the former Soviet Union."]],
  ["Russia",[
    "Classic Russian dishes include shchi (cabbage soup), borscht, pelmeni (small meat dumplings, originally from Siberia), blini (thin pancakes, especially during Maslenitsa, the butter week before Lent), pirozhki (filled buns), beef Stroganoff (named for the Stroganov family in the 19th century), and kasha. Caviar from sturgeon, especially from the Caspian Sea, was long a luxury; overfishing led to bans on wild beluga caviar trade.",
    "Russian aristocrats employed French chefs, and the meeting of French and Russian cooking produced service à la russe, which spread to France. The zakuski table, an array of appetizers like pickles, herring, mushrooms, and salads with vodka, is central to hospitality."]],
  ["Ukraine",[
    "Ukrainian cuisine, distinct though sharing much with neighbors, centers on wheat (Ukraine has long been a major grain exporter, once called 'the breadbasket of Europe'), pork, beets, and dairy. Borscht, a beet soup with many regional variations, is Ukraine's iconic dish; UNESCO inscribed 'the culture of Ukrainian borscht cooking' on its urgent safeguarding list in 2022 due to the war.",
    "Other dishes include varenyky (dumplings filled with potatoes, cheese, cabbage, or cherries), holubtsi (cabbage rolls), salo (cured pork fat), and paska (Easter bread). Chicken Kyiv, breaded chicken filled with herb butter, is famous internationally, though its exact origins are debated."]],
  ["Poland and the Baltics",[
    "Polish cuisine features pierogi (dumplings), bigos ('hunter's stew' of sauerkraut, meats, and mushrooms), żurek (sour rye soup), kielbasa sausages, gołąbki (cabbage rolls), and pączki (doughnuts eaten on Fat Thursday). The Christmas Eve supper (Wigilia) traditionally includes twelve meatless dishes, often with carp.",
    "Baltic cuisines (Lithuania, Latvia, Estonia) rely on rye bread, potatoes, smoked fish, dairy, and foraged berries and mushrooms. Lithuania's cepelinai are large potato dumplings shaped like zeppelins; Latvia and Estonia share herring and dark rye traditions."]],
  ["The Caucasus",[
    "Georgia, between Europe and Asia, has a celebrated cuisine and one of the world's oldest wine traditions, with wine fermented in large clay vessels called qvevri buried underground, a method inscribed by UNESCO in 2013. Dishes include khachapuri (cheese-filled bread, the Adjarian version topped with egg and butter), khinkali (soup dumplings), and walnut-based sauces.",
    "The Georgian feast (supra) is led by a toastmaster (tamada) who gives elaborate toasts. Armenian and Azerbaijani cuisines share kebabs, rice pilafs (plov), dolma, lavash (Armenian lavash bread was inscribed by UNESCO in 2014), and herb-rich dishes."]],
  ["Hospitality and preserving",[
    "Eastern European food culture prizes hospitality; the traditional welcome of bread and salt (khleb-sol) is offered to guests. Families preserve summer produce through pickling, fermenting, and making jams, and many maintain dachas (country cottages with gardens) for growing food.",
    "These cuisines show resourcefulness in harsh climates and deep links between food, family, and religious festivals."]]
  ],
  terms:[["Kasha","Porridge, especially of buckwheat."],["Pelmeni","Small Russian meat dumplings."],["Blini","Thin Russian pancakes."],["Zakuski","Russian appetizers served with drinks."],["Pierogi","Polish filled dumplings."],["Qvevri","Large Georgian clay vessels for fermenting wine underground."],["Supra","A Georgian feast led by a toastmaster."]],
  w:"Eastern European cuisines show how cold climates, faith, and hospitality shape hearty, resourceful food traditions.",
  src:["Russian cuisine","Ukrainian cuisine","Polish cuisine","Georgian cuisine","Qvevri","Borscht"],
  q:[["Which grain is used for traditional kasha?","Buckwheat","Rice","Maize","Quinoa"],
     ["Blini are especially eaten during…","Maslenitsa","Ramadan","Diwali","Thanksgiving"],
     ["What is Ukraine's iconic dish?","Borscht","Pierogi","Goulash","Khachapuri"],
     ["The Polish Christmas Eve supper traditionally includes…","Twelve meatless dishes","A roast goose","Turkey","Only bread"],
     ["Georgian qvevri are used to…","Ferment wine underground","Bake bread","Store cheese","Cook dumplings"],
     ["What is the traditional Eastern European welcome for guests?","Bread and salt","Wine and cheese","Tea and cake","Fruit and nuts"]]},

{ t:"The Nordic Countries and the Low Countries", s:"Herring, rye, smørrebrød, frites, and waffles",
  sec:[
  ["The Nordic table",[
    "Nordic cuisines (Denmark, Norway, Sweden, Finland, Iceland) developed in a harsh climate with short summers and long winters, relying on fish, dairy, rye, barley, potatoes, root vegetables, berries, mushrooms, and game. Preservation was vital: dried, salted, smoked, pickled, and fermented foods.",
    "Herring was the 'silver of the sea', pickled in countless ways. Norway's stockfish (air-dried cod from the Lofoten Islands) was exported across Europe for centuries. Gravlax (salmon cured with salt, sugar, and dill) originally meant 'buried salmon', from the practice of fermenting fish in the ground."]],
  ["Denmark and Sweden",[
    "Denmark is famous for smørrebrød (open-faced sandwiches on dense rye bread, rugbrød, topped with herring, liver pâté, roast beef, or shrimp), frikadeller (meatballs), and pastries known abroad as 'Danish' (in Denmark, wienerbrød, 'Viennese bread', since Austrian bakers introduced laminated dough in the 19th century).",
    "Sweden's smörgåsbord is a buffet of many dishes, traditionally starting with herring, then cold fish and meats, then hot dishes like köttbullar (meatballs with lingonberry jam), and Janssons frestelse (potato and anchovy gratin). Fika, the Swedish coffee break with pastries like cinnamon buns (kanelbullar), is a cherished ritual. Surströmming, fermented Baltic herring, is famously pungent."]],
  ["Norway, Finland, and Iceland",[
    "Norway offers salmon (Norway is the world's largest producer of farmed Atlantic salmon), lutefisk (dried fish soaked in lye, also eaten in Sweden and by Scandinavian Americans), fårikål (mutton and cabbage stew), and brunost (sweet brown cheese made from caramelized whey). Finland has karjalanpiirakka (Karelian rye pies), salmon soup, reindeer, rye bread, and saunas with sausage.",
    "Iceland's food, shaped by isolation, includes skyr, lamb, fish, and preserved specialties like hákarl (fermented shark, toxic when fresh) eaten at the midwinter Þorrablót festival. The New Nordic movement, led by Noma, reinvigorated interest in Nordic ingredients and traditions."]],
  ["The Netherlands",[
    "Dutch cuisine is hearty and practical: stamppot (mashed potatoes with vegetables like kale, served with smoked sausage), erwtensoep (thick split pea soup), raw herring (haring, eaten with onions), bitterballen (fried ragout balls), and cheeses like Gouda and Edam. Dutch traders and the Dutch East India Company shaped global spice trade and introduced Indonesian influences.",
    "The rijsttafel ('rice table'), a Dutch colonial elaboration of Indonesian dishes served together, remains popular in the Netherlands. The Dutch also contributed to cocoa processing (Van Houten's cocoa powder) and to the cultivation of orange carrots, though the popular story that they were bred to honor the House of Orange is unproven."]],
  ["Belgium",[
    "Belgium is renowned for chocolate (pralines were invented by Jean Neuhaus II in Brussels in 1912), waffles (Brussels and Liège styles), frites (fries, which Belgians claim to have invented, fried twice in beef fat and served with mayonnaise), moules-frites (mussels with fries), and carbonnade flamande (beef braised in beer).",
    "Belgian beer culture was inscribed by UNESCO in 2016. Belgium has a remarkable variety of beer styles, including Trappist beers brewed in monasteries (like Westmalle, Chimay, and Westvleteren), lambics fermented with wild yeasts (including fruity kriek and gueuze), saisons, and strong golden ales."]],
  ["Lessons from the north",[
    "Northern European cuisines teach the value of preservation, seasonality, and simple, high-quality ingredients. Their dark rye breads, fermented and cured fish, and foraged foods are now admired worldwide.",
    "They also show how trade shaped even modest cuisines: Dutch and Danish ports brought spices, coffee, and sugar that became central to local baking and drinking traditions."]]
  ],
  terms:[["Smørrebrød","Danish open-faced sandwiches on rye bread."],["Smörgåsbord","A Swedish buffet of many dishes."],["Fika","The Swedish coffee break ritual."],["Gravlax","Nordic salmon cured with salt, sugar, and dill."],["Stamppot","Dutch mashed potatoes with vegetables."],["Trappist beer","Beer brewed in or under the control of Trappist monasteries."]],
  w:"Nordic and Low Country cuisines show the art of preservation and the influence of trade on everyday food.",
  src:["Nordic cuisine","Danish cuisine","Swedish cuisine","Dutch cuisine","Belgian cuisine","Beer in Belgium"],
  q:[["What is smørrebrød?","Danish open-faced sandwiches on rye bread","Swedish meatballs","Norwegian cheese","Dutch stew"],
     ["What is fika?","A Swedish coffee break with pastries","A fermented fish","A Danish pastry","A Finnish sauna"],
     ["Which country is the world's largest producer of farmed Atlantic salmon?","Norway","Sweden","Iceland","Denmark"],
     ["What is a rijsttafel?","A Dutch colonial array of Indonesian dishes","A Belgian waffle","A Danish sandwich","A Swedish buffet"],
     ["Who invented the praline in Brussels in 1912?","Jean Neuhaus II","Coenraad van Houten","Rodolphe Lindt","Henri Nestlé"],
     ["Belgian beer culture was inscribed by UNESCO in…","2016","1990","2005","2022"]]},

{ t:"Greece, Turkey, and the Balkans", s:"The eastern Mediterranean table",
  sec:[
  ["Shared heritage",[
    "The cuisines of Greece, Turkey, the Balkans, and Cyprus share a long history shaped by Byzantine and especially Ottoman rule, which lasted centuries across the region. As a result, many dishes appear under related names: dolma (stuffed vegetables and vine leaves), moussaka, börek/burek (filled pastries), baklava, kofte/keftedes (meatballs), and yogurt-based dishes.",
    "Who invented which dish is often hotly debated, as with baklava, Turkish versus Greek coffee, or the origins of moussaka. In reality, these cuisines developed together through centuries of exchange."]],
  ["Greece",[
    "Greek cuisine is based on olive oil, vegetables, legumes, bread, cheese (especially feta, made from sheep's or a sheep-goat milk mix, with EU protected status), yogurt, fish, lamb, herbs like oregano and dill, lemon, and wine. Many traditional meals are vegetable-based ladera ('oily' dishes cooked in olive oil), reflecting frequent Orthodox fasting days.",
    "Famous dishes include moussaka (layers of eggplant, spiced meat, and béchamel, in its modern form popularized by chef Nikolaos Tselementes in the 1920s), spanakopita, souvlaki and gyros, horiatiki (village salad), tzatziki, avgolemono (egg-lemon soup and sauce), and grilled octopus. Meze, small shared plates with ouzo, are central to Greek socializing."]],
  ["Turkey",[
    "Turkish cuisine, heir to the Ottoman palace kitchens of Istanbul's Topkapı Palace, which employed many hundreds of cooks, is one of the world's great cuisines. It ranges from Anatolian village cooking to refined Istanbul dishes. Kebabs come in many forms: döner (meat roasted on a vertical spit, the ancestor of gyros and shawarma), şiş, Adana (spicy minced meat), and İskender.",
    "Other classics include meze, pide and lahmacun (flatbreads), mantı (tiny dumplings with yogurt and chili butter), köfte, imam bayıldı ('the imam fainted', eggplant stuffed with onions and tomatoes), pilafs, and sweets like baklava, künefe, lokum (Turkish delight), and sütlaç (rice pudding). Turkish coffee and its culture were inscribed by UNESCO in 2013; tea (çay) is the everyday drink."]],
  ["The Balkans",[
    "Balkan cuisines, from Serbia, Croatia, Bosnia, Bulgaria, Romania, Albania, North Macedonia, and neighbors, blend Ottoman, Central European, and Mediterranean influences. Grilled meats are central: ćevapi (small grilled sausages served with bread and onions, iconic in Bosnia), pljeskavica (spiced patty), and sarma (cabbage rolls).",
    "Ajvar (roasted red pepper relish), shopska salad (Bulgaria's tomato, cucumber, and white cheese salad), burek, kajmak (clotted cream), and rakija (fruit brandy) are shared favorites. Bulgaria is famed for its yogurt; the bacterium Lactobacillus bulgaricus was named after Bulgaria. Romania has mămăligă (polenta) and sarmale; Croatia's Dalmatian coast features seafood and olive oil."]],
  ["Cyprus and the Levant connection",[
    "Cyprus combines Greek and Turkish traditions with halloumi cheese (a semi-hard cheese that holds its shape when grilled, now with EU protected status), souvla (large meat chunks roasted on spits), and meze spreads of dozens of dishes.",
    "The eastern Mediterranean also connects to Levantine and Middle Eastern cuisines, sharing hummus, tahini, pita, and rice dishes, showing how food crosses political borders."]],
  ["The Mediterranean diet",[
    "The Mediterranean diet, based on the traditional diets of Crete and southern Italy observed in the 1950s–60s, notably by researcher Ancel Keys in the Seven Countries Study, emphasizes vegetables, fruits, legumes, whole grains, olive oil, fish, moderate dairy and wine, and little red meat. UNESCO recognized it in 2010 (extended 2013) for Spain, Greece, Italy, Morocco, Cyprus, Croatia, and Portugal.",
    "These cuisines show how simple, seasonal ingredients, olive oil, and shared meals create food that is both delicious and associated with good health."]]
  ],
  terms:[["Meze","Small shared dishes served with drinks in the eastern Mediterranean."],["Dolma","Stuffed vegetables or vine leaves."],["Ladera","Greek vegetable dishes cooked in olive oil."],["Döner","Meat roasted on a vertical spit."],["Ajvar","A Balkan roasted red pepper relish."],["Halloumi","A Cypriot cheese that holds its shape when grilled."]],
  w:"The eastern Mediterranean's shared Ottoman and Byzantine heritage created a rich family of cuisines.",
  src:["Greek cuisine","Turkish cuisine","Ottoman cuisine","Balkan cuisine","Meze","Mediterranean diet"],
  q:[["Which empire shaped many shared dishes across Greece, Turkey, and the Balkans?","The Ottoman Empire","The Roman Empire","The British Empire","The Mughal Empire"],
     ["Feta cheese is traditionally made from…","Sheep's milk or a sheep-goat mix","Cow's milk only","Buffalo milk","Camel milk"],
     ["What does 'imam bayıldı' mean?","The imam fainted","The sultan's feast","Royal kebab","Sweet delight"],
     ["Döner kebab is the ancestor of…","Gyros and shawarma","Pizza","Burgers","Sushi"],
     ["Ćevapi are especially iconic in…","Bosnia","Greece","Turkey","Romania"],
     ["Who studied Mediterranean diets in the Seven Countries Study?","Ancel Keys","Norman Borlaug","Michael Pollan","Harvey Wiley"]]}

);


/* ---- from cuisine-11.js ---- */
/* CUISINE FOUNDATIONS, part 11: Unit 6 Cuisines of Asia, chapters 1-5 */
COURSES.cuisine.units.push({ t:"Cuisines of Asia", ch:[

{ t:"China I: Foundations", s:"Philosophy, technique, and the Chinese table",
  sec:[
  ["An ancient, continuous tradition",[
    "Chinese cuisine is one of the world's oldest and most influential, with written culinary records spanning over two thousand years. Food holds a central place in Chinese culture; a traditional greeting translates roughly as 'Have you eaten?' The Chinese table is built on the balance of fan (grains: rice in the south, wheat products like noodles and buns in the north) and cai (accompanying dishes of vegetables, meat, and fish).",
    "Chinese food philosophy emphasizes balance and harmony: of flavors, textures, colors, and the yin (cooling) and yang (heating) qualities of foods, linked to traditional Chinese medicine. A good meal balances many dishes rather than centering on one main course."]],
  ["Techniques",[
    "Chinese cooking employs many techniques. Stir-frying (chao) in a wok at high heat; steaming (zheng), used for fish, dumplings, buns, and eggs; braising, including red-braising (hong shao) with soy sauce, sugar, and Shaoxing wine; deep-frying; double-boiling (slow-cooking soups in a covered vessel set in water); smoking; and roasting, as in Cantonese char siu and roast duck.",
    "Knife work is fundamental: ingredients are cut into uniform pieces for quick, even cooking, and chopsticks make knives unnecessary at the table. The cleaver is the main all-purpose knife. 'Velveting', coating meat in egg white and cornstarch before briefly cooking it in oil or water, gives a silky texture to stir-fries."]],
  ["Flavors and seasonings",[
    "Key seasonings include soy sauce (light and dark), Shaoxing rice wine, rice vinegars (including Zhenjiang black vinegar), sesame oil, oyster sauce, fermented bean pastes, garlic, ginger, and scallions. Regional cuisines add chilies, Sichuan peppercorns, star anise, cinnamon, and fermented tofu.",
    "Chinese cooks value texture (kou gan) as highly as flavor, prizing crunchy, springy, slippery, and gelatinous textures. This explains the appreciation for foods like jellyfish, wood ear mushrooms, sea cucumber, and tendon, which are valued more for texture than taste."]],
  ["Dining customs",[
    "Chinese meals are typically served family-style, with shared dishes placed in the center of a round table, often on a lazy Susan. Diners take food with chopsticks to their own bowls of rice. Hosts honor guests by serving them the best morsels, and banquets feature many courses, with a whole fish often served last for its symbolism of abundance (the word for fish, yu, sounds like 'surplus').",
    "Etiquette includes not sticking chopsticks upright in rice (which resembles incense at funerals), pouring tea for others first, and tapping fingers to thank someone pouring tea. Round tables symbolize unity."]],
  ["Festivals and food",[
    "Festivals are tied to specific foods. At Lunar New Year (Spring Festival), northern families make jiaozi dumplings, whose shape resembles ancient silver ingots; southerners eat niangao (rice cakes, symbolizing growth), fish, and long noodles for longevity. The Mid-Autumn Festival brings mooncakes; the Dragon Boat Festival brings zongzi (sticky rice wrapped in bamboo leaves).",
    "Tea is integral to Chinese culture, and dim sum, small dishes eaten with tea (yum cha) in Cantonese teahouses, is a beloved social ritual. Traditional Chinese tea processing techniques and associated customs were inscribed by UNESCO in 2022."]],
  ["The Chinese diaspora",[
    "Chinese emigrants spread their cuisine worldwide, adapting it to local tastes. American Chinese food developed dishes like chop suey, General Tso's chicken (adapted from a dish created in Taiwan by chef Peng Chang-kuei), and fortune cookies (actually of Japanese-American origin). Peru's chifa, India's Indo-Chinese cuisine (chili chicken, Manchurian dishes), and Southeast Asian Chinese cooking show the diaspora's influence.",
    "Today, regional Chinese cuisines, especially Sichuan, Hunan, Cantonese, and northwestern styles, are increasingly available worldwide, revealing the true diversity of Chinese food."]]
  ],
  terms:[["Fan and cai","Grains and accompanying dishes, the two halves of a Chinese meal."],["Wok","A round-bottomed Chinese pan for stir-frying and more."],["Velveting","Coating meat in egg white and cornstarch for a silky texture."],["Kou gan","Mouthfeel or texture, highly valued in Chinese cuisine."],["Yum cha","'Drinking tea': the Cantonese ritual of tea with dim sum."],["Zongzi","Sticky rice dumplings wrapped in bamboo leaves."]],
  w:"Chinese cuisine's philosophy of balance and its vast techniques make it one of the world's great culinary traditions.",
  src:["Chinese cuisine","Wok","Dim sum","Chinese New Year","General Tso's chicken","Velveting"],
  q:[["What is the 'fan' in a Chinese meal?","The grain staple","The main meat","The soup","The dessert"],
     ["What is velveting?","Coating meat in egg white and cornstarch","Deep-frying vegetables","Steaming fish","Smoking meat"],
     ["Why is a whole fish served at Chinese banquets?","Its name sounds like 'surplus', symbolizing abundance","Fish is the cheapest food","It is a religious rule","For dessert"],
     ["Which food is eaten at the Dragon Boat Festival?","Zongzi","Mooncakes","Jiaozi","Peking duck"],
     ["Fortune cookies are actually of…","Japanese-American origin","Cantonese origin","Sichuan origin","Korean origin"],
     ["What does 'yum cha' mean?","Drinking tea","Eating noodles","Happy new year","Cooking rice"]]},

{ t:"China II: Regional Cuisines", s:"Sichuan, Cantonese, and the eight great traditions",
  sec:[
  ["The Eight Great Cuisines",[
    "China's vast territory and diverse climates produced many regional cuisines. They are traditionally grouped as the 'Eight Great Cuisines': Sichuan (Chuan), Cantonese (Yue), Shandong (Lu), Jiangsu (Su, including Huaiyang), Zhejiang (Zhe), Fujian (Min), Hunan (Xiang), and Anhui (Hui). Other important traditions include Beijing, Shanghai, Yunnan, Xinjiang, Dongbei (northeast), and Hakka cooking.",
    "A common saying characterizes flavors by direction: 'south sweet, north salty, east sour, west spicy' (nan tian, bei xian, dong suan, xi la)."]],
  ["Sichuan and Hunan",[
    "Sichuan cuisine, from southwestern China, is famous for bold, complex flavors, especially mala, 'numbing and spicy', from Sichuan peppercorns and chilies. It is said to have many flavor profiles, including fish-fragrant (yuxiang, garlic, ginger, pickled chilies, sugar, and vinegar, with no fish), strange-flavor (guaiwei), and red oil. Famous dishes include mapo tofu, kung pao chicken, twice-cooked pork, dan dan noodles, fish in chili oil, and hot pot (especially Chongqing hot pot). Chengdu was named a UNESCO City of Gastronomy in 2010.",
    "Hunan cuisine is hot and often sour, using fresh chilies, smoked and cured meats, and pickles. Chairman Mao's red-braised pork and steamed fish head with chopped chilies are well known. Fuchsia Dunlop, an English cook trained at the Sichuan Institute of Higher Cuisine, has written influential books on these cuisines."]],
  ["Cantonese",[
    "Cantonese cuisine, from Guangdong, Hong Kong, and Macau, emphasizes freshness, natural flavors, and delicate seasoning, with steaming and quick stir-frying. Live seafood tanks are common in restaurants. It includes dim sum (har gow, siu mai, char siu bao, cheung fun), roast meats (char siu, roast goose, crispy pork belly), steamed whole fish with ginger and scallions, wonton noodles, congee, and slow-cooked soups (lou fo tong).",
    "Because most early Chinese emigrants came from Guangdong, Cantonese food was for a long time the main Chinese cuisine known abroad. Hong Kong developed a cosmopolitan food culture, including cha chaan teng cafés serving Hong Kong-style milk tea and Western-influenced dishes."]],
  ["Eastern China",[
    "Jiangsu and Zhejiang cuisines of the fertile Yangtze delta are refined and slightly sweet, with emphasis on knife work, fresh river fish, and seasonal vegetables. Huaiyang cuisine, served at state banquets, includes lion's head meatballs. Shanghai offers xiaolongbao, red-braised dishes, and drunken chicken; Hangzhou has West Lake vinegar fish and Dongpo pork (named after the poet Su Dongpo). Shaoxing is famous for rice wine.",
    "Fujian cuisine emphasizes seafood and soups; its famous banquet dish 'Buddha Jumps Over the Wall' combines dozens of luxurious ingredients like abalone, sea cucumber, and shark fin (now often substituted for conservation reasons). Anhui cuisine uses wild mountain herbs and braising."]],
  ["Northern and western China",[
    "Shandong cuisine, one of the oldest, influenced imperial cooking in Beijing; it features seafood, soups, and braises. Beijing is famous for Peking duck, roasted until its skin is crisp and lacquered, served with thin pancakes, scallions, and sweet bean sauce; Quanjude, founded in 1864, is one of its famous restaurants. Northern cuisine relies on wheat: noodles, dumplings, steamed buns, and flatbreads.",
    "Northwestern and Xinjiang cuisines, influenced by Muslim Hui and Uyghur peoples, feature lamb, cumin, hand-pulled noodles, kebabs, and naan; Lanzhou beef noodle soup and Xi'an's roujiamo ('Chinese hamburger') and biangbiang noodles are famous. Yunnan, bordering Southeast Asia, has rich biodiversity, wild mushrooms, rice noodles (crossing-the-bridge noodles), and cured ham."]],
  ["Imperial and modern China",[
    "Imperial cuisine reached its height in the Qing dynasty court; the legendary 'Manchu Han Imperial Feast' supposedly had over a hundred dishes. Chinese chefs were trained in apprenticeships, and culinary schools later formalized training.",
    "Today, rapid economic growth, urbanization, delivery apps, and regional migration have spread regional cuisines across China and the world. Michelin guides now cover several Chinese cities, and chefs are reviving and modernizing regional traditions."]]
  ],
  terms:[["Mala","Numbing and spicy flavor from Sichuan peppercorns and chilies."],["Yuxiang","Sichuan 'fish-fragrant' flavor without fish."],["Dim sum","Small Cantonese dishes eaten with tea."],["Char siu","Cantonese barbecued pork."],["Peking duck","Roast duck with crisp skin served with pancakes."],["Hot pot","A communal pot of simmering broth for cooking ingredients at the table."]],
  w:"China's regional cuisines are as diverse as Europe's and reveal the depth of Chinese culinary culture.",
  src:["Eight Great Traditions","Sichuan cuisine","Cantonese cuisine","Hunan cuisine","Peking duck","Huaiyang cuisine"],
  q:[["What does 'mala' mean?","Numbing and spicy","Sweet and sour","Salty and savory","Smoky"],
     ["What is notable about Sichuan 'fish-fragrant' dishes?","They contain no fish","They are all fish","They are sweet desserts","They are raw"],
     ["Which cuisine emphasizes freshness, steaming, and dim sum?","Cantonese","Hunan","Sichuan","Xinjiang"],
     ["Why was Cantonese food long the main Chinese food known abroad?","Most early emigrants came from Guangdong","It is the oldest","The emperor preferred it","It uses no chilies"],
     ["'Buddha Jumps Over the Wall' comes from which cuisine?","Fujian","Sichuan","Beijing","Shandong"],
     ["Which city was named a UNESCO City of Gastronomy in 2010?","Chengdu","Shanghai","Beijing","Hong Kong"]]},

{ t:"Japan", s:"Washoku, seasonality, and precision",
  sec:[
  ["Washoku",[
    "Japanese cuisine (washoku) was inscribed by UNESCO in 2013, recognized for its respect for nature, seasonality, nutritional balance, and connection to festivals like New Year. Its foundation is rice, miso soup, pickles (tsukemono), and side dishes; the basic meal pattern is ichiju sansai, 'one soup, three dishes', with rice.",
    "Umami is central, provided by dashi, soy sauce, miso, and other fermented products. Presentation is highly valued, with careful attention to color, arrangement, and tableware that changes with the seasons. Seasonality (shun) is fundamental: ingredients are eaten at their peak, and many dishes evoke particular seasons."]],
  ["History",[
    "Rice cultivation arrived in Japan around the first millennium BCE. Buddhism discouraged eating meat, and imperial edicts restricted it from the 7th century, so for over a thousand years many Japanese ate mainly rice, vegetables, soy, and seafood. Buddhist temple cuisine (shōjin ryōri) developed sophisticated vegetarian cooking.",
    "Contact with the Portuguese in the 16th century introduced frying (leading to tempura) and sweets like castella sponge cake. After the Meiji Restoration (1868), Japan opened to the West, meat-eating was officially encouraged, and Western-influenced yōshoku dishes developed, like tonkatsu, curry rice (from British naval curry), omurice, and korokke (croquettes)."]],
  ["Sushi and seafood",[
    "Sushi originated from narezushi, fish preserved in fermented rice, a technique from Southeast Asia. In Edo (Tokyo) in the early 19th century, nigiri sushi, fresh fish on vinegared rice, became a fast food sold at stalls; Hanaya Yohei is often credited with popularizing it. Sushi types include nigiri, maki (rolls), temaki (hand rolls), chirashi (scattered), and sashimi (sliced raw fish without rice).",
    "Sushi chefs (itamae) traditionally train for years; the documentary 'Jiro Dreams of Sushi' (2011) portrayed the dedication of Jiro Ono. Japan's fish markets, like Tokyo's former Tsukiji market (moved to Toyosu in 2018), are famous. California rolls and other inside-out rolls developed in North America."]],
  ["Noodles, comfort foods, and street food",[
    "Noodles include soba (buckwheat), udon (thick wheat), somen (thin wheat), and ramen, adapted from Chinese noodles in the late 19th and early 20th centuries and now with countless regional styles (shoyu, miso, shio, tonkotsu). Comfort foods include donburi (rice bowls like oyakodon and katsudon), curry rice, and nabe (hot pots like sukiyaki and shabu-shabu).",
    "Street and casual foods include yakitori, takoyaki (octopus balls, from Osaka), okonomiyaki (savory pancakes), and onigiri (rice balls). Izakaya are casual pubs serving small dishes with drinks. Bento boxes are carefully arranged packed meals; ekiben are sold at train stations."]],
  ["Kaiseki and the art of the meal",[
    "Kaiseki is Japan's multi-course haute cuisine, originating in the simple meals served with the tea ceremony (cha-kaiseki) and developed into an elaborate seasonal progression of small dishes: appetizers (sakizuke), soup (suimono), sashimi, grilled dish (yakimono), simmered dish (nimono), rice, pickles, and dessert. Each course reflects the season through ingredients, garnishes, and tableware.",
    "Kyoto is the center of kaiseki. Japanese cooking emphasizes subtraction, letting ingredients' natural flavors stand out. Tokyo has long held more Michelin-starred restaurants than any other city in the world."]],
  ["Japanese ingredients and influence",[
    "Key ingredients include rice, soy sauce, miso, mirin, sake, rice vinegar, dashi (kombu and katsuobushi), nori and other seaweeds, tofu, wasabi (true wasabi is rare and expensive; most is horseradish-based), shiso, yuzu, matcha, and wagyu beef. Japanese knives and techniques are prized by chefs worldwide.",
    "Japanese cuisine influences global fine dining through its emphasis on seasonality, presentation, umami, and precision. Nikkei cuisine in Peru blends Japanese and Peruvian traditions, and Japanese ingredients like miso and yuzu appear on menus worldwide."]]
  ],
  terms:[["Washoku","Traditional Japanese cuisine."],["Ichiju sansai","'One soup, three dishes' with rice, the basic Japanese meal."],["Shun","The peak season of an ingredient."],["Nigiri","Hand-pressed sushi of fish on vinegared rice."],["Kaiseki","Japanese seasonal multi-course haute cuisine."],["Izakaya","A Japanese casual pub serving small dishes."],["Yōshoku","Japanese adaptations of Western dishes."]],
  w:"Japanese cuisine's respect for seasonality, precision, and umami has made it one of the world's most influential cuisines.",
  src:["Japanese cuisine","Washoku","Sushi","Kaiseki","Ramen","Yōshoku"],
  q:[["When was washoku inscribed by UNESCO?","2013","2000","1990","2020"],
     ["What does 'ichiju sansai' mean?","One soup, three dishes","Three soups, one dish","Rice and fish","Seasonal tea"],
     ["Tempura developed from contact with…","The Portuguese","The Dutch","The Chinese","The Americans"],
     ["Nigiri sushi became a fast food in which city?","Edo (Tokyo)","Kyoto","Osaka","Nagasaki"],
     ["Kaiseki originated from meals served with…","The tea ceremony","Sumo tournaments","Buddhist festivals","Samurai battles"],
     ["Japanese curry rice was derived from…","British naval curry","Indian royal cuisine","Thai green curry","Chinese stir-fry"]]},

{ t:"Korea", s:"Kimchi, banchan, and fermented flavors",
  sec:[
  ["Foundations",[
    "Korean cuisine centers on rice (bap), soups and stews, and banchan, a variety of small side dishes served with every meal. Fermentation is fundamental: kimchi, jang (fermented soybean pastes and sauces), and jeotgal (salted, fermented seafood). The three essential jang are doenjang (soybean paste), ganjang (soy sauce), and gochujang (fermented chili paste with glutinous rice and soybeans).",
    "Korean cooking balances five colors (green, red, yellow, white, black) and five flavors, ideas linked to East Asian cosmology. Garlic, sesame oil, scallions, ginger, and gochugaru (chili flakes) are essential. Chili arrived in Korea only around the late 16th or 17th century, but it transformed the cuisine, including kimchi."]],
  ["Kimchi",[
    "Kimchi is Korea's national dish, eaten at almost every meal. There are hundreds of varieties, made from napa cabbage (baechu kimchi), radish (kkakdugi), cucumbers, and other vegetables, fermented with salt, chili, garlic, ginger, and often fish sauce or salted shrimp. White kimchi (baek kimchi) contains no chili.",
    "Kimjang, the communal autumn making of kimchi for the winter, was inscribed by UNESCO in 2013 for South Korea, and North Korea's kimchi-making tradition was inscribed in 2015. Special kimchi refrigerators, designed to control fermentation, are common in Korean homes. Kimchi is also cooked into kimchi jjigae (stew), kimchi fried rice, and kimchi pancakes."]],
  ["Classic dishes",[
    "Bibimbap ('mixed rice') is rice topped with seasoned vegetables, meat, egg, and gochujang, mixed before eating; Jeonju's version is famous, and dolsot bibimbap is served in a hot stone bowl that crisps the rice. Bulgogi ('fire meat') is thinly sliced marinated beef, grilled or stir-fried. Galbi is marinated short ribs. Japchae is stir-fried sweet-potato glass noodles with vegetables.",
    "Soups and stews (guk, tang, jjigae, jjim) include doenjang jjigae, sundubu jjigae (soft tofu stew), samgyetang (whole young chicken stuffed with ginseng and rice, eaten on hot summer days), and seolleongtang (milky beef bone soup). Naengmyeon, cold buckwheat noodles in icy broth, originated in the north."]],
  ["Korean barbecue and eating culture",[
    "Korean barbecue (gogi-gui) is cooked at the table: pork belly (samgyeopsal), marinated beef, and galbi, eaten wrapped in lettuce or perilla leaves with garlic, ssamjang (a dipping paste), and kimchi (ssam). Drinking culture pairs food with soju, a clear distilled spirit, and makgeolli, a cloudy rice wine; anju are foods eaten with drinks.",
    "Korean meals are communal, with banchan shared and refilled freely in restaurants. Etiquette includes waiting for elders to begin eating and turning away from elders when drinking. Royal court cuisine of the Joseon dynasty, with many refined dishes, is preserved by specialists."]],
  ["Street food and modern Korea",[
    "Korean street food includes tteokbokki (chewy rice cakes in spicy sauce), gimbap (seaweed rice rolls), hotteok (sweet filled pancakes), odeng (fish cakes), and Korean fried chicken, double-fried for crispness and often glazed with sweet-spicy sauce. Budae jjigae ('army stew'), with Spam, sausages, and instant noodles, developed from US military surplus after the Korean War.",
    "The 'Korean Wave' (Hallyu) of music, film, and television has spread Korean food globally. Korean temple cuisine has also gained fame, notably through Buddhist nun Jeong Kwan, featured on 'Chef's Table'."]],
  ["Lessons",[
    "Korean cuisine shows the power of fermentation to create depth, the pleasure of communal, interactive dining, and the importance of balance in a meal of many small dishes.",
    "Learning to make kimchi and basic jang-based dishes opens the door to Korean cooking, which is increasingly central to global food culture."]]
  ],
  terms:[["Banchan","Small side dishes served with Korean meals."],["Jang","Korean fermented soybean pastes and sauces."],["Gochujang","Fermented chili paste with glutinous rice and soybeans."],["Kimjang","The communal making of kimchi for winter."],["Ssam","Food wrapped in lettuce or leaves."],["Soju","A clear Korean distilled spirit."]],
  w:"Korean cuisine's fermentation, balance, and communal dining have made it one of the world's most exciting food cultures.",
  src:["Korean cuisine","Kimchi","Banchan","Gochujang","Korean barbecue","Bibimbap"],
  q:[["What are banchan?","Small side dishes served with meals","Fermented sauces","Rice cakes","Noodle soups"],
     ["What are the three essential Korean jang?","Doenjang, ganjang, and gochujang","Kimchi, soju, and bap","Bulgogi, galbi, and japchae","Miso, soy, and mirin"],
     ["When did chili arrive in Korea?","Around the late 16th or 17th century","Before 1000 BCE","In the 20th century","It is native to Korea"],
     ["Samgyetang is…","Chicken soup with ginseng, eaten in summer","Spicy rice cakes","Cold noodles","Fried chicken"],
     ["Budae jjigae developed from…","US military surplus after the Korean War","Royal court cuisine","Buddhist temples","Japanese ramen"],
     ["What is kimjang?","The communal autumn making of kimchi","A Korean drink","A barbecue grill","A rice dish"]]},

{ t:"India I: Foundations", s:"Spices, dals, breads, and the thali",
  sec:[
  ["A cuisine of many cuisines",[
    "India's cuisine is better understood as many cuisines, shaped by enormous geographic diversity, religions (Hinduism, Islam, Sikhism, Jainism, Buddhism, Christianity, and others), caste and community traditions, and history, including Mughal and colonial influences. With over 1.4 billion people, India has more vegetarians than any other country; estimates vary, but a substantial share of Indians are vegetarian.",
    "Shared features include complex use of spices, the importance of legumes (dal) and dairy, rice and wheat breads as staples, and the use of many dishes in a single meal. Ayurvedic ideas of balance, along with religious rules about purity, have shaped diets."]],
  ["Spices and techniques",[
    "Indian cooks use spices in layers. Whole spices are often bloomed in hot oil or ghee at the start or end (tadka or tarka), releasing their aromas; ground spices form masalas (spice blends), which vary by dish, region, and family. Common spices include cumin, coriander, turmeric, chili, mustard seeds, cardamom, cloves, cinnamon, fenugreek, asafoetida (hing), and black pepper.",
    "Techniques include bhuna (sautéing spices and aromatics until oil separates), dum (slow cooking in a sealed pot, as in dum biryani), tandoor cooking (in clay ovens), and frying. Onion, garlic, ginger, tomato, and chilies form common bases, though some communities, such as many Jains and some Hindus, avoid onions and garlic."]],
  ["Staples",[
    "Rice dominates in the south, east, and northeast; wheat in the north and west, eaten as flatbreads: roti or chapati (unleavened whole-wheat), paratha (layered, often stuffed), puri (deep-fried, puffed), and naan (leavened, cooked in a tandoor, more common in restaurants than homes). Millets like bajra and jowar are traditional in drier regions.",
    "Dal, lentils and split pulses cooked into soups or stews, is eaten daily across India, in countless varieties: dal tadka, dal makhani (slow-cooked black lentils with butter and cream), sambar (a South Indian lentil-vegetable stew with tamarind), and more. Dairy is central: milk, yogurt (dahi), paneer (fresh cheese), ghee, and sweets made from reduced milk."]],
  ["The meal",[
    "A traditional meal may be served as a thali, a platter with small bowls (katoris) containing rice, bread, dal, vegetables, yogurt, pickles, chutney, and a sweet, offering a balance of flavors and textures. In South India, meals are often served on banana leaves. Eating with the right hand is traditional; diners mix rice and curries with their fingers.",
    "Accompaniments include chutneys (fresh or cooked condiments of herbs, fruits, or coconut), achar (pickles), raita (yogurt with vegetables or spices), and papad (crisp lentil wafers)."]],
  ["'Curry' and its meanings",[
    "'Curry' is not a single Indian dish; the word was used by Europeans, probably from the Tamil kari (sauce or relish), to describe many spiced, sauced dishes. Indians typically name dishes specifically, such as korma (braised in yogurt or cream), vindaloo, rogan josh, or saag. 'Curry powder' was largely a British invention for convenience.",
    "Many dishes famous abroad were shaped by restaurants and diasporas: chicken tikka masala and balti (popularized in Birmingham, England), and butter chicken (murgh makhani), developed at Moti Mahal in Delhi after 1947 by cooks associated with Kundan Lal Gujral and Kundan Lal Jaggi, a subject of a recent legal dispute between their descendants."]],
  ["Sweets and street food",[
    "Indian sweets (mithai) are central to festivals like Diwali and include gulab jamun (fried milk-solid balls in syrup), jalebi (fried spirals in syrup), rasgulla (spongy cheese balls in syrup, the subject of a friendly dispute between West Bengal and Odisha over its origin), laddoo, barfi, kheer (rice pudding), and kulfi (dense frozen dessert).",
    "Street food (chaat) is beloved: pani puri (crisp shells filled with spiced water), bhel puri, samosas, pav bhaji (from Mumbai), vada pav, dosa, kathi rolls (Kolkata), and chole bhature. Masala chai, spiced milk tea, popularized in the 20th century, is India's everyday drink, alongside South Indian filter coffee."]]
  ],
  terms:[["Masala","A spice blend."],["Tadka","Blooming spices in hot fat to flavor a dish."],["Dal","Lentils and split pulses, and dishes made from them."],["Thali","A platter of many small dishes forming a complete meal."],["Chutney","A fresh or cooked condiment."],["Mithai","Indian sweets."],["Chaat","Savory Indian street snacks."]],
  w:"India's many cuisines show the most sophisticated use of spices in the world and a rich vegetarian tradition.",
  src:["Indian cuisine","Masala (spice mix)","Dal","Thali","Curry","Chaat"],
  q:[["What is tadka?","Blooming spices in hot fat","A type of bread","A dessert","A clay oven"],
     ["Which flatbread is cooked in a tandoor and more common in restaurants?","Naan","Chapati","Puri","Dosa"],
     ["What is a thali?","A platter of many small dishes","A spice","A cooking pot","A drink"],
     ["The word 'curry' probably comes from…","The Tamil 'kari'","The English 'curried'","A Portuguese word for sauce","The Hindi 'karahi' only"],
     ["Butter chicken was developed at which Delhi restaurant?","Moti Mahal","Bukhara","Karim's","Indian Accent"],
     ["What is chaat?","Savory Indian street snacks","Indian rice pudding","A spiced tea","A type of dal"]]}

]});


/* ---- from cuisine-12.js ---- */
/* CUISINE FOUNDATIONS, part 12: Unit 6 Cuisines of Asia, chapters 6-10 */
COURSES.cuisine.units[5].ch.push(

{ t:"India II: Regional Cuisines", s:"From Punjab to Kerala, Bengal to Goa",
  sec:[
  ["The North",[
    "Punjabi cuisine, hearty and rich in dairy, is the source of much 'Indian restaurant' food abroad: tandoori chicken, butter chicken, dal makhani, sarson ka saag with makki ki roti (mustard greens with maize bread), chole (chickpeas), and lassi. The Sikh tradition of langar serves free communal meals to all, most famously at the Golden Temple in Amritsar.",
    "Mughal cuisine (Mughlai), developed at the courts of the Mughal emperors from the 16th century, blends Persian and Central Asian influences with Indian ingredients: rich kormas with cream, nuts, and saffron; biryanis; kebabs; and breads. Lucknow's Awadhi cuisine is famous for dum cooking and delicate kebabs like galouti. Kashmiri cuisine includes the wazwan, a ceremonial multi-course feast, with dishes like rogan josh and gushtaba."]],
  ["The West",[
    "Gujarati cuisine is largely vegetarian, with a characteristic sweetness balancing salt and spice; dishes include dhokla (steamed fermented gram flour cakes), thepla, undhiyu (mixed winter vegetables), and elaborate thalis. Rajasthan's desert cuisine uses preserved ingredients, legumes, and dairy, with dal baati churma and laal maas (fiery red mutton).",
    "Maharashtra offers vada pav, pav bhaji, misal pav, and Kolhapuri spicy dishes; Mumbai's street food is legendary. Goa, a Portuguese colony until 1961, has a distinctive Catholic-influenced cuisine with pork vindaloo, sorpotel, xacuti, seafood curries with coconut and kokum, bebinca (layered dessert), and feni (cashew or coconut spirit)."]],
  ["The South",[
    "South Indian cuisines rely on rice, coconut, tamarind, curry leaves, mustard seeds, and lentils. Fermented rice-and-lentil batters make idli (steamed cakes) and dosa (thin crisp crepes, like masala dosa with spiced potato), served with sambar and coconut chutney. Tamil Nadu's Chettinad cuisine is famous for complex spice blends; Hyderabad, in Telangana, is famous for its dum biryani, blending Mughal and southern influences.",
    "Kerala's cuisine, shaped by the spice trade and Hindu, Muslim, Christian, and Jewish communities, features coconut, seafood, appam (lacy rice pancakes) with stew, fish curries with kudampuli (Malabar tamarind), and the sadya, a vegetarian feast served on banana leaves during the Onam festival. Karnataka's Udupi cuisine, associated with temple cooking, influenced South Indian restaurants across India."]],
  ["The East and Northeast",[
    "Bengali cuisine, from West Bengal and Bangladesh, centers on rice and fish, especially hilsa (ilish), cooked with mustard oil and mustard paste. It uses panch phoron (a five-spice blend of fenugreek, nigella, cumin, black mustard, and fennel seeds) and is famous for sweets like rasgulla, sandesh, and mishti doi (sweet yogurt). Bengali meals follow a sequence of courses, starting with something bitter (shukto).",
    "Odisha shares many traditions, including temple food from the Jagannath Temple in Puri. Northeastern states, culturally connected to Southeast Asia and Tibet, have distinct cuisines with fermented bamboo shoots, smoked meats, fermented soybeans (axone in Nagaland), and some of the world's hottest chilies, like the bhut jolokia (ghost pepper)."]],
  ["Indian food and religion",[
    "Religion shapes Indian cuisine in many ways. Many Hindus avoid beef, as the cow is sacred; many are vegetarian, and some avoid eggs, onions, and garlic. Jains follow strict vegetarianism that excludes root vegetables to avoid harming small organisms. Muslims avoid pork and eat halal meat. Festivals have special foods: modak for Ganesh Chaturthi, sweets and snacks for Diwali, and biryani and sewaiyan (vermicelli pudding) for Eid.",
    "Temple kitchens prepare offerings (prasad) and feed huge numbers of pilgrims; communal and charity kitchens, like langar, express religious values of service and equality."]],
  ["Indian food in the world",[
    "The Indian diaspora, in Britain, East Africa, the Caribbean, Fiji, Malaysia, Singapore, South Africa (where bunny chow, curry in a hollowed-out loaf, developed in Durban), and North America, spread Indian food widely. In Trinidad, roti and doubles show Indian influence; in Malaysia, roti canai and mamak stalls.",
    "Indian chefs like Gaggan Anand and Vineet Bhatia have reinterpreted Indian cuisine in fine dining, while regional Indian cuisines are increasingly celebrated, revealing that 'Indian food' is a vast family of traditions."]]
  ],
  terms:[["Mughlai","Rich cuisine from the Mughal courts with Persian influences."],["Dum","Slow cooking in a sealed pot."],["Dosa","A thin, crisp South Indian crepe of fermented rice and lentil batter."],["Sadya","A Kerala vegetarian feast on banana leaves."],["Panch phoron","A Bengali five-spice blend of whole seeds."],["Prasad","Food offered to deities and shared with devotees."]],
  w:"India's regional cuisines are as different from each other as those of different European countries.",
  src:["Punjabi cuisine","Mughlai cuisine","Goan cuisine","South Indian cuisine","Bengali cuisine","Hyderabadi biryani"],
  q:[["Which regional cuisine is the source of much Indian restaurant food abroad?","Punjabi","Bengali","Keralan","Goan"],
     ["Goa's cuisine was shaped by colonization by…","Portugal","Britain","France","the Netherlands"],
     ["Idli and dosa are made from…","Fermented rice and lentil batter","Wheat flour","Corn","Chickpea flour only"],
     ["Which fish is central to Bengali cuisine?","Hilsa","Salmon","Tuna","Cod"],
     ["Why do Jains avoid root vegetables?","To avoid harming small organisms","They are too expensive","They are bitter","They are hard to cook"],
     ["Bunny chow, curry in a hollowed-out loaf, developed in…","Durban, South Africa","London","Mumbai","Singapore"]]},

{ t:"Thailand and Mainland Southeast Asia", s:"Balance of sweet, sour, salty, and spicy",
  sec:[
  ["Thai principles",[
    "Thai cuisine is celebrated for balancing sweet, sour, salty, spicy, and sometimes bitter in a single dish or meal. Key ingredients include fish sauce (nam pla), palm sugar, lime, tamarind, chilies, garlic, shallots, lemongrass, galangal, makrut lime leaves, cilantro (including roots), Thai basil, and shrimp paste (kapi). Rice is the center of the meal; the phrase 'kin khao', 'eat rice', means 'to eat'.",
    "A Thai meal typically includes rice with several shared dishes: a curry, a soup, a stir-fry, a salad (yam), and a dip (nam prik, chili relish) with vegetables, balanced among one another. Thai food was shaped by Indian, Chinese, Khmer, Persian, and Portuguese influences; chilies arrived via the Portuguese in the 16th century."]],
  ["Thai dishes",[
    "Curries (gaeng) are based on pounded pastes: green curry (made with fresh green chilies), red curry, yellow curry, massaman (with Persian and Muslim influences, peanuts, and potatoes), panang, and jungle curry (without coconut milk). Soups include tom yum (hot and sour, often with shrimp) and tom kha gai (chicken in coconut milk with galangal).",
    "Pad thai, stir-fried rice noodles with tamarind, fish sauce, egg, and peanuts, was promoted as a national dish by the government of Plaek Phibunsongkhram in the late 1930s and 1940s as part of a nation-building campaign. Other favorites include som tam (green papaya salad, from the northeast), larb (minced meat salad), pad kra pao (holy basil stir-fry), khao man gai (chicken rice), and mango sticky rice."]],
  ["Regions of Thailand",[
    "Central Thai cuisine, including Bangkok's, is refined and includes royal court cuisine with elaborate carving of fruits and vegetables. Northern (Lanna) cuisine is milder, with sticky rice, khao soi (curry noodle soup, showing Burmese and Chinese Muslim influences), and sai ua (herbal sausage). Northeastern (Isan) cuisine, related to Lao food, features sticky rice, som tam, larb, and grilled chicken (gai yang), with bold, spicy, sour flavors and fermented fish (pla ra).",
    "Southern Thai cuisine is spicy and rich in seafood, coconut, and turmeric, with Malay and Muslim influences, as in gaeng som (sour curry) and khao mok gai (chicken biryani). Bangkok's street food is world-famous; chef Jay Fai, known for her crab omelet, received a Michelin star in 2018."]],
  ["Laos, Cambodia, and Myanmar",[
    "Lao cuisine centers on sticky rice, eaten by hand, with larb (often considered Laos's national dish), jaew (chili dips), tam mak hoong (papaya salad), and padaek (fermented fish sauce). Luang Prabang is noted for its herbs and river fish.",
    "Cambodian (Khmer) cuisine is less spicy than Thai, relying on prahok (fermented fish paste), kroeung (herb pastes with lemongrass and galangal), fish amok (fish steamed in coconut curry in banana leaves), and kampot pepper (with EU protected status). Myanmar's cuisine includes mohinga (fish noodle soup, the national breakfast), lahpet thoke (fermented tea leaf salad), and curries influenced by India and China."]],
  ["Shared traditions",[
    "Mainland Southeast Asian cuisines share fermented fish products, abundant fresh herbs eaten raw, rice (sticky or jasmine), river fish, and contrasting textures. Meals are shared, with balance achieved across dishes. Mortar-and-pestle pounding of pastes and salads is central.",
    "Street food culture is vibrant, with markets and stalls serving most daily meals in cities. Cooking classes in Bangkok, Chiang Mai, and Luang Prabang have made these cuisines popular with travelers."]],
  ["Thai food worldwide",[
    "Thai food spread globally from the 1970s and 1980s with emigration and tourism, and the Thai government's 'Global Thai' program, launched in 2002, promoted Thai restaurants abroad as a form of culinary diplomacy. Thai restaurants are now found in many countries.",
    "Chefs like David Thompson (whose Nahm in London received a Michelin star), Bo.lan, and others have championed traditional recipes drawn from old Thai cookbooks, while many Thai cooks abroad adapt dishes to local tastes."]]
  ],
  terms:[["Nam pla","Thai fish sauce."],["Galangal","A rhizome related to ginger, used in Thai cooking."],["Nam prik","Thai chili relish or dip."],["Som tam","Green papaya salad."],["Larb","A minced meat salad from Laos and northeast Thailand."],["Prahok","Cambodian fermented fish paste."]],
  w:"Thai and mainland Southeast Asian cuisines teach the art of balancing contrasting flavors and fresh herbs.",
  src:["Thai cuisine","Pad thai","Isan","Lao cuisine","Cambodian cuisine","Burmese cuisine"],
  q:[["What does 'kin khao' mean in Thai?","Eat rice, meaning to eat","Good morning","Spicy food","Thank you"],
     ["Who promoted pad thai as a national dish in the late 1930s–40s?","The government of Plaek Phibunsongkhram","King Rama V","David Thompson","Jay Fai"],
     ["Which region of Thailand is famous for som tam and sticky rice?","Isan (northeast)","Bangkok","The south","The islands"],
     ["Khao soi is associated with…","Northern Thailand","Southern Thailand","Cambodia","Vietnam"],
     ["Fish amok is from…","Cambodia","Laos","Myanmar","Thailand"],
     ["Mohinga is the national breakfast of…","Myanmar","Laos","Vietnam","Cambodia"]]},

{ t:"Vietnam", s:"Fresh herbs, fish sauce, and the bowl of pho",
  sec:[
  ["Foundations",[
    "Vietnamese cuisine emphasizes freshness, herbs, balance, and lightness. Nearly every meal includes fresh herbs and greens (mint, cilantro, Thai basil, perilla, Vietnamese coriander, and lettuce), fish sauce (nuoc mam), rice, and contrasting textures. Dishes balance the five tastes and are often assembled at the table, with diners adding herbs, lime, chilies, and sauces to suit themselves.",
    "Nuoc cham, a dipping sauce of fish sauce, lime, sugar, garlic, chili, and water, accompanies many dishes. Phu Quoc island is famous for its fish sauce, made from fermented anchovies and salt. Vietnamese cuisine reflects a thousand years of Chinese rule, Southeast Asian neighbors, and French colonization (1858–1954)."]],
  ["Pho and noodle soups",[
    "Pho, Vietnam's most famous dish, is a noodle soup of rice noodles in a clear, aromatic broth simmered from beef bones with charred onion and ginger, star anise, cinnamon, and cloves, topped with sliced beef (pho bo) or chicken (pho ga). It emerged in northern Vietnam around the early 20th century, possibly influenced by both Chinese and French (pot-au-feu) cooking. Hanoi-style pho is simpler; southern Saigon-style pho is served with plates of herbs, bean sprouts, and sauces.",
    "Other noodle soups include bun bo Hue (spicy beef noodle soup from Hue, with lemongrass), hu tieu (southern pork noodle soup), mi Quang from Quang Nam, and bun rieu (crab noodle soup)."]],
  ["Rice dishes and rolls",[
    "Rice paper wrappers make goi cuon (fresh spring rolls with shrimp, pork, herbs, and rice noodles) and cha gio or nem ran (fried spring rolls). Bun cha, grilled pork with rice vermicelli and herbs in a dipping sauce, is a Hanoi specialty, famously shared by US President Barack Obama and Anthony Bourdain in 2016. Com tam (broken rice) with grilled pork is a Saigon favorite.",
    "Banh xeo are crispy, turmeric-colored crepes filled with shrimp, pork, and bean sprouts, eaten wrapped in lettuce and herbs. Banh cuon are steamed rice rolls with minced pork and mushrooms."]],
  ["French influence and banh mi",[
    "French colonization introduced baguettes, coffee, pâté, butter, and other ingredients. Banh mi, a baguette (made lighter, often with rice flour in the dough) filled with pâté, cold cuts or grilled meat, pickled carrots and daikon, cilantro, chilies, and mayonnaise, is a perfect fusion, popularized in Saigon in the 1950s.",
    "Vietnamese coffee, introduced by the French in the 19th century, is often brewed through a small metal filter (phin) and served with sweetened condensed milk (ca phe sua da when iced). Hanoi's egg coffee (ca phe trung), topped with whipped egg yolk and sugar, was reportedly created in 1946 by Nguyen Van Giang when milk was scarce. Vietnam is now the world's second-largest coffee producer, mostly robusta."]],
  ["Regional cuisines",[
    "Vietnam's long, narrow shape produces three main regional cuisines. Northern cuisine (Hanoi) is subtle, less spicy and sweet, with clear broths. Central cuisine (Hue, the former imperial capital) is spicy and complex, with imperial court dishes and many small, refined dishes.",
    "Southern cuisine (Ho Chi Minh City and the Mekong Delta) is sweeter, uses more herbs, coconut, and tropical produce, and reflects Khmer and Chinese influences. The Mekong Delta's floating markets supply abundant fruits, vegetables, and fish."]],
  ["Vietnamese food abroad",[
    "After the Vietnam War ended in 1975, waves of Vietnamese refugees settled in the United States, France, Australia, Canada, and elsewhere, bringing pho and banh mi to the world. Vietnamese-American communities, like Little Saigon in Orange County, California, became culinary centers.",
    "Vietnamese food's freshness and balance have made it one of the most popular Asian cuisines worldwide, and its herbs and noodle soups have influenced chefs everywhere."]]
  ],
  terms:[["Nuoc mam","Vietnamese fish sauce."],["Nuoc cham","A Vietnamese dipping sauce of fish sauce, lime, sugar, and chili."],["Pho","A Vietnamese noodle soup with aromatic broth."],["Banh mi","A Vietnamese baguette sandwich."],["Phin","A small Vietnamese metal coffee filter."],["Goi cuon","Fresh spring rolls in rice paper."]],
  w:"Vietnamese cuisine combines freshness, herbs, and balance with layered historical influences.",
  src:["Vietnamese cuisine","Pho","Bánh mì","Fish sauce","Vietnamese iced coffee","Bún chả"],
  q:[["Which sauce is fundamental to Vietnamese cooking?","Fish sauce (nuoc mam)","Soy sauce","Oyster sauce","Tomato sauce"],
     ["Pho originated in…","Northern Vietnam","Southern Vietnam","France","China"],
     ["Which dish did Obama and Bourdain share in Hanoi in 2016?","Bun cha","Pho","Banh mi","Banh xeo"],
     ["Banh mi shows the influence of…","French colonization","Japanese occupation","Indian traders","American soldiers"],
     ["What is a phin?","A small metal coffee filter","A rice paper wrapper","A noodle","A fish sauce"],
     ["Which country is the world's second-largest coffee producer?","Vietnam","Thailand","India","Indonesia"]]},

{ t:"Maritime Southeast Asia", s:"Indonesia, Malaysia, Singapore, and the Philippines",
  sec:[
  ["Islands of spice",[
    "Maritime Southeast Asia, including Indonesia, Malaysia, Singapore, Brunei, and the Philippines, sits at the crossroads of the spice trade. Its cuisines reflect Indigenous traditions combined with Indian, Chinese, Arab, Portuguese, Dutch, Spanish, British, and American influences. Rice, coconut, chilies, shrimp paste, lemongrass, galangal, turmeric, tamarind, and sweet soy sauce (kecap manis) are common.",
    "Pounded spice pastes (bumbu in Indonesia, rempah in Malaysia) are the base of many dishes. Sambal, chili-based relishes and sauces, exist in hundreds of varieties and accompany most meals."]],
  ["Indonesia",[
    "Indonesia, with over 17,000 islands and hundreds of ethnic groups, has enormously diverse cuisine. National favorites include nasi goreng (fried rice), satay (skewered grilled meat with peanut sauce), gado-gado (vegetables with peanut sauce), soto (soups), and rendang, slow-cooked beef in coconut milk and spices from the Minangkabau people of West Sumatra, which has topped international polls of the world's most delicious foods.",
    "Padang restaurants serve Minangkabau food in many small dishes. Tempeh, fermented soybean cake from Java, is a protein staple. Balinese cuisine, largely Hindu, includes babi guling (roast suckling pig) and bebek betutu (spiced duck). Java's cuisine tends toward sweetness; Sumatra's toward spice."]],
  ["Malaysia and Singapore",[
    "Malaysian cuisine combines Malay, Chinese, and Indian traditions, along with Indigenous and Peranakan influences. Nasi lemak, rice cooked in coconut milk served with sambal, anchovies, peanuts, egg, and cucumber, is often called the national dish. Others include laksa (spicy noodle soups, with many regional variants such as curry laksa and sour Penang assam laksa), char kway teow, roti canai, and satay.",
    "Peranakan (Nyonya) cuisine, from the descendants of Chinese settlers who married locally, blends Chinese ingredients with Malay spices, as in ayam buah keluak and kueh (colorful cakes). Singapore's hawker centers, open-air food courts serving affordable dishes, are central to life; Singapore's hawker culture was inscribed by UNESCO in 2020. Hainanese chicken rice, chili crab, and kaya toast (coconut jam toast) are Singaporean icons."]],
  ["The Philippines",[
    "Filipino cuisine combines Austronesian roots with Chinese, Spanish (over three centuries of colonization from 1565), and American influences. Adobo, meat or vegetables braised in vinegar, soy sauce, garlic, bay leaves, and pepper, is often called the national dish. Sinigang is a sour soup flavored with tamarind; kare-kare is oxtail stew in peanut sauce; and lechon (whole roast pig) is the centerpiece of fiestas.",
    "Filipino flavors favor sour, salty, and sweet, with vinegar central and condiments like bagoong (fermented shrimp paste) and patis (fish sauce). Chinese influence appears in pancit (noodles) and lumpia (spring rolls); Spanish in dishes like leche flan, menudo, and paella-like arroz valenciana; and American in Spam and spaghetti with sweet banana ketchup. Halo-halo is a beloved shaved-ice dessert."]],
  ["Eating customs",[
    "In much of the region, meals are eaten with the right hand or with spoon and fork (spoon in the right hand, fork in the left to push food onto it), reflecting colonial and local customs. Rice is eaten at nearly every meal, and many dishes are shared.",
    "Street food and night markets, from Jakarta's warungs to Penang's hawker stalls and Manila's carinderias, are central to daily life. Festive foods mark religious holidays such as Eid (Hari Raya), Chinese New Year, Deepavali, and Christmas."]],
  ["Global influence",[
    "Dutch colonial ties brought Indonesian food to the Netherlands (rijsttafel), and Malaysian, Singaporean, and Filipino diasporas have spread their cuisines widely. Ingredients like sambal, kecap manis, and calamansi are increasingly found worldwide.",
    "These cuisines show how trade and migration can create layered, vibrant food cultures where many traditions coexist on the same street."]]
  ],
  terms:[["Sambal","A chili-based relish or sauce."],["Kecap manis","Sweet Indonesian soy sauce."],["Rendang","Slow-cooked beef in coconut milk and spices from West Sumatra."],["Nasi lemak","Malaysian coconut rice with accompaniments."],["Peranakan","Descendants of Chinese settlers in the Malay world, and their cuisine."],["Adobo","Filipino meat braised in vinegar, soy sauce, and garlic."],["Hawker center","An open-air food court of affordable stalls."]],
  w:"Maritime Southeast Asia's cuisines show how spice-trade crossroads create rich, layered food cultures.",
  src:["Indonesian cuisine","Malaysian cuisine","Singaporean cuisine","Filipino cuisine","Rendang","Peranakan cuisine"],
  q:[["What is sambal?","A chili-based relish","A rice dish","A coconut drink","A noodle soup"],
     ["Rendang comes from which people?","The Minangkabau of West Sumatra","The Javanese","The Balinese","The Malay of Penang"],
     ["What is nasi lemak?","Rice cooked in coconut milk with accompaniments","Fried rice","Noodle soup","Grilled skewers"],
     ["Peranakan cuisine blends…","Chinese ingredients with Malay spices","French and Vietnamese food","Japanese and Korean food","Indian and Thai food"],
     ["What is often called the Philippine national dish?","Adobo","Lechon","Sinigang","Pancit"],
     ["Singapore's hawker culture was inscribed by UNESCO in…","2020","2010","2000","2023"]]},

{ t:"Central Asia and the Silk Road", s:"Plov, nomads, and the crossroads of Asia",
  sec:[
  ["A crossroads cuisine",[
    "Central Asia, including Kazakhstan, Uzbekistan, Kyrgyzstan, Tajikistan, Turkmenistan, and neighboring regions like Afghanistan, Mongolia, and Xinjiang, lies on the historic Silk Roads linking China, Persia, India, and Europe. Its cuisines blend nomadic pastoral traditions with the cooking of settled oasis cities like Samarkand and Bukhara, and Persian, Turkic, Chinese, and Russian influences.",
    "Nomadic peoples relied on their herds: mutton, horse meat, beef, camel, and abundant dairy, including fermented mare's milk (kumis) and dried yogurt balls (kurut). Oasis cities grew wheat, rice, fruits (melons, apricots, pomegranates, grapes), nuts, and vegetables."]],
  ["Plov and rice",[
    "Plov (pilaf), rice cooked with meat (usually lamb), carrots, onions, and spices like cumin, often with chickpeas, raisins, or quince, is the king of Central Asian dishes. It is cooked in a large cast-iron kazan, often by men for weddings and celebrations; Uzbek plov is said to have dozens of regional variations. 'Palov culture and tradition' in Uzbekistan and Tajikistan's 'Oshi palav' were both inscribed by UNESCO in 2016.",
    "The pilaf family spans a vast region: Persian polo, Indian pulao and biryani, Turkish pilav, and Spanish paella share the technique of cooking rice in fat with aromatics before adding liquid."]],
  ["Breads, dumplings, and noodles",[
    "Bread (non or nan) is sacred in Central Asia, never thrown away or placed upside down. It is baked in tandyr ovens (clay ovens like the Indian tandoor), often stamped with decorative patterns. Samsa, triangular pastries filled with meat and onion, are also baked in tandyrs.",
    "Dumplings and noodles show Chinese links: manti (large steamed dumplings), chuchvara (small boiled dumplings), and lagman, hand-pulled noodles in a meat and vegetable sauce, associated with Uyghur and Dungan (Chinese Muslim) cooks. Beshbarmak ('five fingers', because it is eaten by hand), boiled meat over flat noodles, is a national dish of Kazakhstan and Kyrgyzstan."]],
  ["Mongolia and the steppe",[
    "Mongolian cuisine, shaped by nomadic herding in a harsh climate, relies on meat (especially mutton) and dairy, with few vegetables. Dishes include buuz (steamed dumplings, eaten especially at Lunar New Year, Tsagaan Sar), khuushuur (fried meat pastries), and boodog and khorkhog, meats cooked with hot stones. Airag (fermented mare's milk) is the summer drink.",
    "The so-called 'Mongolian barbecue' served in restaurants abroad is actually a stir-fry concept developed in Taiwan in the 20th century, not a traditional Mongolian dish."]],
  ["Hospitality and tea",[
    "Hospitality is a sacred duty across Central Asia. Guests are seated in the place of honor and served the dastarkhan, a tablecloth spread with bread, fruits, nuts, sweets, salads, and tea, before the main dishes. Tea, green in Uzbekistan and black with milk in Kazakhstan, is served in bowls (piala), poured back and forth to mix it.",
    "Teahouses (chaikhana) are social centers for men to eat, drink tea, and talk. Afghanistan's cuisine, with Kabuli pulao (rice with lamb, carrots, and raisins), mantu, and ashak dumplings, shares these traditions."]],
  ["Lessons of the Silk Road",[
    "The Silk Roads carried ingredients and techniques in every direction: noodles and dumplings, rice pilafs, tandoor ovens, spices, fruits, and tea. Many dishes found from China to Turkey to Italy have related forms along these routes.",
    "Central Asian cuisines show how food travels with traders, migrants, and empires, and how nomadic and settled traditions combine."]]
  ],
  terms:[["Plov","Central Asian rice pilaf cooked with meat and carrots in a kazan."],["Kazan","A large cast-iron cooking pot."],["Tandyr","A clay oven used for bread and samsa."],["Lagman","Hand-pulled noodles in a meat and vegetable sauce."],["Beshbarmak","Boiled meat over flat noodles, eaten by hand."],["Dastarkhan","A spread of food laid out for guests."],["Kumis/Airag","Fermented mare's milk."]],
  w:"Central Asian cuisines reveal the Silk Road's role in spreading noodles, pilafs, breads, and dumplings across Eurasia.",
  src:["Central Asian cuisine","Uzbek cuisine","Pilaf","Lagman","Mongolian cuisine","Silk Road"],
  q:[["What is plov?","A rice pilaf with meat and carrots","A dumpling","A bread","A tea"],
     ["Plov is traditionally cooked in a…","Kazan","Wok","Tagine","Tandoor"],
     ["What does 'beshbarmak' mean?","Five fingers","Sacred bread","Hot stone","Horse milk"],
     ["What is kumis or airag?","Fermented mare's milk","A meat stew","A noodle","A spice"],
     ["'Mongolian barbecue' restaurants abroad are based on a concept developed in…","Taiwan","Mongolia","Kazakhstan","Japan"],
     ["Why is bread treated with respect in Central Asia?","It is considered sacred","It is very expensive","It is only for guests","It is imported"]]}

);


/* ---- from cuisine-13.js ---- */
/* CUISINE FOUNDATIONS, part 13: Unit 7 The Middle East and Africa, chapters 1-3 */
COURSES.cuisine.units.push({ t:"The Middle East and Africa", ch:[

{ t:"The Levant and the Arab World", s:"Mezze, bread, and hospitality",
  sec:[
  ["A shared table",[
    "The Levant, Lebanon, Syria, Jordan, Israel and Palestine, along with Iraq and the Arabian Peninsula, shares a culinary heritage built on wheat, olive oil, legumes, yogurt, lamb, vegetables, herbs, and spices. The region is one of the birthplaces of agriculture, and its food traditions draw on ancient Mesopotamian, Persian, Arab, and Ottoman influences.",
    "Hospitality is a deep cultural value; guests are welcomed with coffee, dates, and abundant food. Meals are communal and generous, often eaten from shared platters. Islamic dietary laws (halal) prohibit pork and alcohol and require animals to be slaughtered in a specific way."]],
  ["Mezze",[
    "Mezze, an array of small dishes served together, is central to Levantine dining. Classic mezze include hummus (chickpeas pureed with tahini, lemon, and garlic), baba ghanoush and mutabbal (smoky eggplant dips), tabbouleh (a parsley salad with bulgur, tomato, and lemon, in its Lebanese form mostly herbs), fattoush (a salad with toasted pita), labneh (strained yogurt), falafel, kibbeh (bulgur and meat croquettes, Lebanon's national dish in many forms, including raw kibbeh nayyeh), and stuffed grape leaves (warak enab).",
    "Who 'owns' dishes like hummus and falafel is a subject of passionate regional debate. Lebanon set Guinness records for the largest plate of hummus in 2009–2010 in a friendly competition with Israel."]],
  ["Breads, grills, and rice",[
    "Bread, especially pita (khubz) and thin markook baked on a dome, is eaten with almost every meal and used as a utensil. Manakish, flatbreads topped with za'atar and olive oil or cheese, are a Levantine breakfast favorite. Grilled meats include shawarma (meat roasted on a vertical spit, related to Turkish döner), shish tawook (marinated chicken skewers), and kofta.",
    "Rice dishes are central for feasts: maqluba ('upside-down', rice, vegetables, and meat cooked in a pot and flipped onto a platter), mansaf (Jordan's national dish of lamb cooked in fermented dried yogurt, jameed, served over rice and bread; inscribed by UNESCO in 2022), and the kabsa and mandi of the Arabian Peninsula (spiced rice with meat; mandi is cooked in an underground pit)."]],
  ["Spices and condiments",[
    "Levantine cooking uses spices moderately: allspice, cinnamon, cumin, coriander, sumac (sour red berries), Aleppo pepper, seven-spice blends (baharat), and za'atar. Tahini (sesame paste), pomegranate molasses, lemon, garlic, and fresh herbs like parsley and mint are essential. Toum is a Lebanese garlic emulsion served with grilled chicken.",
    "Iraqi cuisine, heir to Baghdad's medieval culinary golden age, features masgouf (grilled carp), dolma, and kubba. Gulf cuisines use dried limes (loomi), saffron, cardamom, and rosewater, reflecting trade with Persia and India."]],
  ["Sweets and coffee",[
    "Middle Eastern sweets are often rich with nuts, syrup, and floral waters: baklava, knafeh (cheese pastry soaked in syrup, famously from Nablus), ma'amoul (date- or nut-filled cookies for festivals), halva, and muhallabia (milk pudding). Dates have been cultivated in the region for thousands of years and are traditionally used to break the Ramadan fast.",
    "Coffee culture began in the Arab world: coffee was first drunk in Sufi monasteries in Yemen in the 15th century, and coffeehouses spread through Mecca, Cairo, and Istanbul. Arabic coffee (qahwa), lightly roasted and spiced with cardamom, served in small cups, was inscribed by UNESCO in 2015 as a symbol of generosity."]],
  ["Ramadan and festivals",[
    "During Ramadan, Muslims fast from dawn to sunset, breaking the fast (iftar) with dates and water, followed by soups like lentil soup or harira, and festive meals. A pre-dawn meal (suhoor) sustains the fast. Eid al-Fitr, ending Ramadan, is celebrated with sweets and family feasts; Eid al-Adha involves the sacrifice of an animal, with meat shared with family, neighbors, and the poor.",
    "These traditions show how food in the Arab world is bound to faith, family, and generosity."]]
  ],
  terms:[["Mezze","An array of small shared dishes."],["Tahini","Sesame seed paste."],["Kibbeh","Croquettes or dishes of bulgur and minced meat."],["Shawarma","Meat roasted on a vertical spit and shaved."],["Mansaf","Jordan's lamb dish cooked in fermented dried yogurt."],["Qahwa","Arabic coffee spiced with cardamom."],["Iftar","The meal breaking the daily Ramadan fast."]],
  w:"Levantine and Arab cuisines show how generosity, shared plates, and ancient ingredients create one of the world's most loved food cultures.",
  src:["Levantine cuisine","Arab cuisine","Mezze","Hummus","Mansaf","Arabic coffee"],
  q:[["What is mezze?","An array of small shared dishes","A grilled meat","A sweet pastry","A coffee"],
     ["Tabbouleh in its Lebanese form is mostly…","Parsley and herbs","Bulgur","Tomatoes","Chickpeas"],
     ["Mansaf is the national dish of…","Jordan","Lebanon","Iraq","Saudi Arabia"],
     ["Where was coffee first drunk, in Sufi monasteries?","Yemen","Turkey","Ethiopia","Egypt"],
     ["What is traditionally eaten to break the Ramadan fast?","Dates and water","Bread and cheese","Rice and meat","Coffee and sweets"],
     ["Knafeh is famously associated with which city?","Nablus","Beirut","Baghdad","Riyadh"]]},

{ t:"Persia and Jewish Cuisines", s:"Saffron rice, fragrant stews, and a diaspora table",
  sec:[
  ["Persian cuisine",[
    "Iranian (Persian) cuisine is among the world's most refined and influential. Persian courts shaped Arab, Ottoman, Central Asian, and Mughal cooking. It balances sweet and sour flavors, uses fresh herbs abundantly, and features rice, saffron, dried limes, pomegranate, barberries, nuts, rosewater, and yogurt.",
    "Persian thought traditionally classified foods as 'hot' (garm) or 'cold' (sard), rooted in ancient humoral medicine, and balanced them in meals; for example, walnuts and pomegranates (hot and cold) combine in fesenjan."]],
  ["Rice and polo",[
    "Persian rice is an art. Chelow is plain steamed rice, parboiled and then steamed slowly so each grain is separate and fluffy, with a golden, crisp crust at the bottom of the pot, tahdig, the most prized part, sometimes made with potatoes, bread, or yogurt-saffron rice. Polo is rice cooked with other ingredients, such as sabzi polo (herb rice, eaten for Nowruz, the Persian New Year, with fish) and zereshk polo (with barberries).",
    "Saffron, of which Iran is the world's largest producer by far, is used to color and perfume rice, often bloomed in hot water and drizzled over the top."]],
  ["Stews and kebabs",[
    "Khoresh (stews) are served over rice: ghormeh sabzi (herb stew with kidney beans, dried limes, and lamb, often considered the national dish), fesenjan (chicken or duck in pomegranate and ground walnut sauce), and gheymeh (split peas and lamb with fried potatoes). Ash are thick soups with herbs, legumes, and noodles, like ash reshteh.",
    "Kebabs include kebab koobideh (minced meat), joojeh (saffron chicken), and barg (thin lamb or beef fillet), served with rice, grilled tomatoes, and sumac. Meals are accompanied by sabzi khordan, a plate of fresh herbs, radishes, and cheese eaten with bread, and doogh, a salty yogurt drink."]],
  ["Jewish cuisines",[
    "Jewish food is not one cuisine but many, shaped by the diaspora across Europe, the Middle East, North Africa, Central Asia, India, and beyond, and unified by the laws of kashrut (keeping kosher). Kashrut forbids pork, shellfish, and certain other animals; requires ritual slaughter (shechita); and forbids mixing meat and dairy, which leads to separate dishes and utensils.",
    "The Sabbath, when cooking is traditionally prohibited from Friday sunset to Saturday nightfall, inspired slow-cooked stews prepared before it begins: cholent among Ashkenazi Jews, hamin and dafina among Sephardi and Mizrahi Jews, often cooked overnight. Challah, the braided bread, is blessed at Sabbath meals."]],
  ["Ashkenazi and Sephardi traditions",[
    "Ashkenazi Jews of Central and Eastern Europe developed dishes like gefilte fish, matzo ball soup, latkes (potato pancakes for Hanukkah), kugel, brisket, knishes, blintzes, and rye bread, as well as bagels, which traveled with immigrants to New York. Jewish delis in America popularized pastrami, corned beef, and lox and bagels.",
    "Sephardi Jews (descended from Iberia, expelled from Spain in 1492) and Mizrahi Jews (from the Middle East and North Africa) have cuisines related to their host regions: Moroccan Jewish tagines and fish with peppers, Iraqi Jewish amba (pickled mango sauce) and kubba, Persian Jewish dishes, and Turkish Jewish borekas. Passover is marked by matzo (unleavened bread) and a symbolic Seder plate."]],
  ["Israeli cuisine",[
    "Modern Israeli cuisine developed as Jewish immigrants from many countries met Palestinian and Arab foods, producing a fusion of traditions: hummus, falafel, shakshuka (eggs poached in spiced tomato sauce, from North Africa), sabich (an Iraqi Jewish pita with fried eggplant and egg), and the large Israeli breakfast.",
    "Questions of cultural appropriation and shared heritage between Israeli and Palestinian cuisines are sensitive. Chefs like Yotam Ottolenghi (born in Jerusalem) and Sami Tamimi (a Palestinian from Jerusalem), co-authors of 'Jerusalem' (2012), popularized the region's vegetables, herbs, and spices worldwide while emphasizing shared roots."]]
  ],
  terms:[["Tahdig","The crisp golden crust at the bottom of Persian rice."],["Khoresh","Persian stews served over rice."],["Nowruz","The Persian New Year."],["Kashrut","Jewish dietary laws."],["Cholent","A slow-cooked Ashkenazi Sabbath stew."],["Ashkenazi and Sephardi","Jewish diaspora communities from Central/Eastern Europe and Iberia, respectively."]],
  w:"Persian and Jewish cuisines show how refined court traditions and religious law shaped food across continents.",
  src:["Iranian cuisine","Tahdig","Ghormeh sabzi","Jewish cuisine","Kashrut","Israeli cuisine"],
  q:[["What is tahdig?","The crisp crust at the bottom of Persian rice","A Persian stew","A yogurt drink","A herb plate"],
     ["Which country is by far the largest producer of saffron?","Iran","Spain","India","Morocco"],
     ["Fesenjan is made with…","Pomegranate and ground walnuts","Kidney beans and dried limes","Barberries and rice","Herbs and noodles"],
     ["Kashrut forbids…","Mixing meat and dairy","Eating vegetables","Drinking water on the Sabbath","Eating bread"],
     ["Cholent is a…","Slow-cooked Sabbath stew","Braided bread","Potato pancake","Fish dish"],
     ["Who co-wrote 'Jerusalem' (2012)?","Yotam Ottolenghi and Sami Tamimi","Claudia Roden and Joan Nathan","Anthony Bourdain and David Chang","Jamie Oliver and Nigella Lawson"]]},

{ t:"North Africa", s:"Couscous, tagines, and Maghrebi spice",
  sec:[
  ["The Maghreb",[
    "North Africa's cuisines, Morocco, Algeria, Tunisia, Libya, and Egypt, combine Indigenous Amazigh (Berber) traditions with Arab, Andalusian, Ottoman, Jewish, and French influences. Couscous, made from semolina rolled into tiny granules and steamed, often in a couscoussier over a stew, is the region's emblematic food. In 2020, UNESCO inscribed 'knowledge, know-how and practices pertaining to the production and consumption of couscous' jointly for Algeria, Mauritania, Morocco, and Tunisia.",
    "Spices include cumin, coriander, cinnamon, ginger, turmeric, paprika, saffron, and blends like ras el hanout (Moroccan, 'head of the shop', with dozens of spices). Preserved lemons, olives, harissa (Tunisian chili paste), argan oil, and smen (aged fermented butter) give distinctive flavors."]],
  ["Morocco",[
    "Moroccan cuisine is famous for tagines, slow-cooked stews named after the conical earthenware pot: chicken with preserved lemons and olives, lamb with prunes and almonds, and kefta (meatballs) with eggs. Royal kitchens in cities like Fez and Marrakesh developed refined dishes, often combining sweet and savory.",
    "Pastilla (bastilla) is a pastry of thin warqa sheets filled with pigeon or chicken, almonds, and spices, dusted with cinnamon and sugar. Harira, a tomato, lentil, and chickpea soup, is eaten to break the Ramadan fast. Mint tea, green tea with fresh mint and sugar poured from height to create foam, is the symbol of hospitality. Marrakesh's Jemaa el-Fnaa square, a UNESCO-recognized cultural space, comes alive at night with food stalls."]],
  ["Algeria, Tunisia, and Libya",[
    "Algerian cuisine features couscous in many forms, chorba (soup), chakhchoukha (torn flatbread in sauce), and mhajeb (stuffed semolina flatbreads). Tunisian cuisine is famously spicy with harissa, which UNESCO inscribed in 2022; dishes include brik (thin pastry filled with egg and tuna, fried), lablabi (chickpea soup), and couscous with fish.",
    "Shakshuka, eggs poached in a spiced tomato and pepper sauce, is common across the Maghreb and spread to Israel and worldwide. Libyan cuisine shows Italian influence from colonization, with dishes like macaroni bil bosla."]],
  ["Egypt",[
    "Egyptian cuisine, with ancient roots, relies on bread (aish baladi, whose name means 'life'), legumes, and vegetables. Ful medames (stewed fava beans with oil, cumin, and lemon) is an everyday breakfast; ta'ameya is Egyptian falafel, made with fava beans rather than chickpeas.",
    "Koshari, a street food of rice, lentils, pasta, and chickpeas topped with spicy tomato sauce and fried onions, is often called Egypt's national dish; it was inscribed by UNESCO in 2025. Molokhia (a soup of jute mallow leaves), mahshi (stuffed vegetables), and feteer (layered pastry) are also beloved."]],
  ["Bread and street life",[
    "Bread is central throughout North Africa, from Moroccan khobz baked in communal ovens to Tunisian tabouna. Communal neighborhood ovens (ferran) still bake families' bread in many Moroccan medinas.",
    "Markets (souks) display spices, olives, dates, and preserved lemons, while street vendors sell grilled meats, snail soup, msemen (layered flatbreads), and sweets like chebakia (sesame cookies in honey, for Ramadan)."]],
  ["North Africa abroad",[
    "North African food has deeply influenced France, where couscous is among the most popular dishes, due to colonial history and immigration. Merguez sausages, harissa, and mint tea are common in France and beyond.",
    "Writers like Paula Wolfert and Claudia Roden brought North African and Middle Eastern cooking to English-speaking audiences in the late 20th century."]]
  ],
  terms:[["Couscous","Steamed granules of rolled semolina."],["Tagine","A Moroccan conical clay pot and the stews cooked in it."],["Ras el hanout","A complex Moroccan spice blend."],["Harissa","A Tunisian chili paste."],["Preserved lemons","Lemons cured in salt, used in Maghrebi cooking."],["Koshari","An Egyptian dish of rice, lentils, pasta, and tomato sauce."]],
  w:"North African cuisines combine Amazigh, Arab, Andalusian, and Ottoman traditions into fragrant, spiced dishes.",
  src:["Maghrebi cuisine","Moroccan cuisine","Couscous","Tunisian cuisine","Egyptian cuisine","Harissa"],
  q:[["What is couscous made from?","Rolled, steamed semolina granules","Rice","Maize","Lentils"],
     ["What does 'ras el hanout' mean?","Head of the shop","Red pepper","Lemon salt","King's spice"],
     ["Harissa is especially associated with…","Tunisia","Egypt","Morocco","Libya"],
     ["Ta'ameya, Egyptian falafel, is made with…","Fava beans","Chickpeas","Lentils","Rice"],
     ["Which Egyptian dish combines rice, lentils, pasta, and tomato sauce?","Koshari","Ful medames","Molokhia","Feteer"],
     ["Moroccan mint tea is poured from height to…","Create foam","Cool it quickly","Show off only","Remove leaves"]]}

]});


/* ---- from cuisine-14.js ---- */
/* CUISINE FOUNDATIONS, part 14: Unit 7 The Middle East and Africa, chapters 4-5 */
COURSES.cuisine.units[6].ch.push(

{ t:"West and Central Africa", s:"Jollof, fufu, soups, and the roots of Atlantic cooking",
  sec:[
  ["Foundations",[
    "West and Central African cuisines are built on starchy staples, flavorful soups and stews, and bold seasoning. Staples include yams, cassava, plantains, cocoyams (taro), rice, millet, sorghum, maize, and fonio (an ancient, fast-growing grain). Red palm oil, groundnuts (peanuts), okra, leafy greens, smoked and dried fish, chilies, and fermented seasonings are central.",
    "Many meals pair a 'swallow', a smooth, stretchy dough of pounded or stirred starch, such as fufu (pounded cassava, plantain, or yam), pounded yam, eba (from cassava granules, garri), banku, or ugali-like porridges, with a soup or stew. Diners tear off a piece with their right hand, shape it, and use it to scoop the soup."]],
  ["Soups and stews",[
    "West African 'soups' are often thick stews. Nigerian egusi soup is made with ground melon seeds and leafy greens; ogbono soup uses ground wild mango seeds, giving a slippery texture; okra soup is similar. Groundnut (peanut) stew, known as maafe in Senegal and Mali and nkatenkwan in Ghana, is widespread. Palm nut soup and light soup are Ghanaian favorites; pepper soup, spicy and aromatic, is popular in Nigeria.",
    "Fermented seasonings like iru or dawadawa (fermented locust beans) and ogiri (fermented seeds) provide umami, as do smoked fish, dried shrimp, crayfish, and, since the 20th century, bouillon cubes such as Maggi, which became ubiquitous."]],
  ["Rice dishes",[
    "Jollof rice, rice cooked in a sauce of tomatoes, peppers, onions, and spices, is beloved across West Africa and the subject of a famous friendly rivalry ('jollof wars') between Nigeria and Ghana, with Senegal, Sierra Leone, and Liberia also claiming excellence. Its likely ancestor is thieboudienne (ceebu jën) from Senegal's Wolof people, rice cooked with fish and vegetables, which UNESCO inscribed in 2021. Party jollof, cooked over firewood, is prized for its smoky flavor.",
    "Waakye (Ghanaian rice and beans), Nigerian fried rice, and coconut rice are other favorites. West Africa also has an ancient tradition of rice cultivation using African rice (Oryza glaberrima)."]],
  ["Grills and street food",[
    "Suya, from northern Nigeria, is spiced, thinly sliced beef or chicken grilled on skewers and coated with yaji, a spice mix of ground peanuts, chili, ginger, and other spices. Senegal's chicken yassa (marinated in lemon and onions) and Ivory Coast's attiéké (fermented cassava couscous) with grilled fish are classics.",
    "Street food includes kelewele (spiced fried plantains, Ghana), akara (black-eyed pea fritters, ancestors of Brazilian acarajé), puff-puff (fried dough balls), moi moi (steamed bean pudding), kenkey (fermented corn dough), and meat pies. Central African cuisines, from Cameroon and the Congo basin, feature cassava leaves (saka saka or pondu), ndolé (bitterleaf and peanut stew, Cameroon's national dish), and plantains."]],
  ["Africa and the Atlantic world",[
    "The transatlantic slave trade carried West and Central African people, foods, and cooking techniques to the Americas. Okra (gumbo comes from a Bantu word for okra), black-eyed peas, rice-growing knowledge, yams, watermelon, sesame, and techniques like deep-frying, one-pot rice dishes, and seasoning with smoked meats and hot peppers shaped Southern US, Caribbean, and Brazilian cuisines.",
    "Dishes like Louisiana gumbo and jambalaya, Carolina Lowcountry rice dishes (like Hoppin' John), Brazilian acarajé and vatapá, and Caribbean callaloo show these deep roots. Historians like Jessica B. Harris, in 'High on the Hog' (2011), and Michael Twitty, in 'The Cooking Gene' (2017), have documented this heritage."]],
  ["Contemporary West African food",[
    "West African cuisines are increasingly celebrated internationally, with chefs like Pierre Thiam (Senegal), who promotes fonio, and Tunde Wey and others bringing attention to the region's food. Nigerian and Ghanaian diasporas in London, Houston, and elsewhere have opened restaurants, and afrobeats culture has helped spread interest.",
    "These cuisines show the importance of stews, starches, fermentation, and communal eating, and their profound influence on the cooking of the Americas."]]
  ],
  terms:[["Swallow","A smooth starchy dough, like fufu, eaten with soup."],["Fufu","Pounded or stirred dough of cassava, plantain, or yam."],["Egusi","Ground melon seeds used to thicken soups."],["Jollof rice","West African rice cooked in a tomato and pepper sauce."],["Thieboudienne","Senegalese rice cooked with fish and vegetables."],["Suya","Nigerian spiced grilled skewers."],["Dawadawa/iru","Fermented locust bean seasoning."]],
  w:"West and Central African cuisines are rich traditions in their own right and foundational to the cooking of the Americas.",
  src:["West African cuisine","Fufu","Jollof rice","Thieboudienne","Egusi","Suya"],
  q:[["What is a 'swallow' in West African cuisine?","A smooth starchy dough eaten with soup","A type of bird","A drink","A spice blend"],
     ["Egusi soup is thickened with…","Ground melon seeds","Peanuts","Okra","Flour"],
     ["Jollof rice's likely ancestor is…","Senegalese thieboudienne","Spanish paella","Indian biryani","Persian polo"],
     ["What spice mix coats suya?","Yaji","Berbere","Ras el hanout","Garam masala"],
     ["The word 'gumbo' comes from a Bantu word for…","Okra","Rice","Soup","Pepper"],
     ["Who wrote 'The Cooking Gene'?","Michael Twitty","Jessica B. Harris","Pierre Thiam","Marcus Samuelsson"]]},

{ t:"East and Southern Africa", s:"Injera, ugali, braai, and spice coast flavors",
  sec:[
  ["Ethiopia and Eritrea",[
    "Ethiopian and Eritrean cuisines are among Africa's most distinctive. Meals center on injera, a large, spongy, sour flatbread made from fermented teff batter, on which stews (wat or tsebhi) are served; diners tear pieces of injera to scoop up food, eating from a shared platter. Feeding someone a mouthful by hand (gursha) is a gesture of affection.",
    "Key seasonings include berbere (a fiery blend of chilies, fenugreek, ginger, and many spices), mitmita (chili powder), and niter kibbeh (spiced clarified butter). Dishes include doro wat (spicy chicken stew with eggs, eaten at festivals), kitfo (minced raw beef with mitmita and butter), tibs (sautéed meat), and many vegetarian stews of lentils (misir wat) and split peas (shiro), because the Ethiopian Orthodox Church prescribes many fasting days without animal products. Ethiopia is also the birthplace of coffee, with an elaborate coffee ceremony."]],
  ["East Africa",[
    "In Kenya, Tanzania, and Uganda, staples include ugali (a stiff maize porridge, also called nsima or sadza elsewhere), matoke (steamed green bananas, central in Uganda), rice, and beans. Nyama choma (grilled meat, often goat) is a social favorite. Sukuma wiki (collard greens), chapati, and mandazi (fried dough) reflect everyday cooking.",
    "The Swahili coast, shaped by over a thousand years of Indian Ocean trade with Arabia, Persia, and India, has spiced dishes: pilau and biryani, coconut fish curries, samosas, and urojo (Zanzibar mix soup). Zanzibar, the 'Spice Island', grows cloves, nutmeg, cinnamon, and pepper. Indian communities in East Africa contributed many dishes."]],
  ["Southern Africa",[
    "Southern African cuisine combines Indigenous traditions with Dutch, British, Malay, Indian, and Portuguese influences. Staples include maize porridge (pap or mealie meal, sadza in Zimbabwe, nshima in Zambia and Malawi). The braai (barbecue) is a central social ritual in South Africa, with boerewors (spiced sausage), lamb chops, and sosaties (skewers).",
    "Cape Malay cuisine, from people brought from Southeast Asia (many enslaved) by the Dutch, contributed bobotie (spiced minced meat with an egg custard topping, often called South Africa's national dish), bredies (stews), and curries. Biltong (air-dried cured meat), chakalaka (spicy relish), bunny chow (from Durban's Indian community), and malva pudding are beloved."]],
  ["Madagascar and the islands",[
    "Madagascar's cuisine is based on rice, eaten at nearly every meal, with laoka (accompaniments) such as romazava (a meat and greens stew) and ravitoto (pounded cassava leaves with pork). Madagascar is the world's largest producer of vanilla, grown in the northeast.",
    "Mauritius and Réunion blend African, Indian, Chinese, and French cuisines, with dishes like dholl puri, rougaille, and curries, illustrating the creolization of island food cultures."]],
  ["Portuguese Africa",[
    "Mozambique and Angola, former Portuguese colonies, have cuisines influenced by Portugal and Brazil. Mozambique is known for piri-piri (African bird's-eye chili) chicken and prawns, which spread internationally through Portuguese and South African restaurant chains like Nando's (founded in 1987). Angola has muamba de galinha (chicken in palm oil sauce) and funge (cassava porridge).",
    "Peri-peri sauce, based on chili, lemon, garlic, and oil, is a clear example of Columbian Exchange fusion: an American chili adopted in Africa via Portuguese trade and returned to Europe."]],
  ["African food today",[
    "Across Africa, rapid urbanization, global trade, and growing middle classes are transforming diets, while chefs and food writers are documenting and celebrating traditional dishes. Chefs like Marcus Samuelsson (born in Ethiopia, raised in Sweden), Selassie Atadika (Ghana), and Pierre Thiam (Senegal) are among those promoting African cuisines internationally.",
    "African cuisines remain underrepresented internationally relative to their diversity and influence, but interest is growing rapidly in their grains (teff, fonio, sorghum), spices, and techniques."]]
  ],
  terms:[["Injera","A spongy, sour flatbread of fermented teff."],["Berbere","An Ethiopian spice blend of chilies and spices."],["Niter kibbeh","Ethiopian spiced clarified butter."],["Ugali","A stiff maize porridge eaten in East Africa."],["Braai","South African barbecue."],["Bobotie","A Cape Malay dish of spiced meat with egg custard."],["Piri-piri","African bird's-eye chili and the sauce made from it."]],
  w:"East and Southern African cuisines show remarkable diversity, from Ethiopian injera to Cape Malay curries and the braai.",
  src:["Ethiopian cuisine","Injera","Swahili cuisine","South African cuisine","Bobotie","Piri piri"],
  q:[["What is injera made from?","Fermented teff batter","Maize","Wheat","Rice"],
     ["Why are there many vegetarian Ethiopian dishes?","The Orthodox Church prescribes many fasting days","Meat is illegal","Cattle are rare","It is too hot for meat"],
     ["What is ugali?","A stiff maize porridge","A spiced stew","A flatbread","A fermented drink"],
     ["Bobotie comes from which tradition?","Cape Malay","Ethiopian","Swahili","Zulu"],
     ["Which country is the world's largest producer of vanilla?","Madagascar","Mexico","India","Indonesia"],
     ["Piri-piri chicken is especially associated with…","Mozambique","Kenya","Ethiopia","Nigeria"]]}

);


/* ---- from cuisine-15.js ---- */
/* CUISINE FOUNDATIONS, part 15: Unit 8 The Americas, chapters 1-4 */
COURSES.cuisine.units.push({ t:"Cuisines of the Americas", ch:[

{ t:"Mexico", s:"Maize, chilies, and a living ancient cuisine",
  sec:[
  ["Mesoamerican roots",[
    "Mexican cuisine rests on foundations laid by Mesoamerican peoples over thousands of years: maize, beans, squash, chilies, tomatoes and tomatillos, avocados, cacao, vanilla, and turkey. In 2010, UNESCO inscribed 'Traditional Mexican cuisine: ancestral, ongoing community culture, the Michoacán paradigm', the first national cuisine to be recognized.",
    "Nixtamalization, cooking dried maize with an alkaline solution (traditionally lime, calcium hydroxide) and then grinding it, is the essential technique. It loosens the hulls, improves flavor and aroma, makes niacin available (preventing pellagra), and allows the dough (masa) to hold together for tortillas and tamales. The comal, a flat griddle, and the metate, a grinding stone, are ancient tools still used."]],
  ["Chilies",[
    "Mexico has an extraordinary variety of chilies, used fresh and dried, each with distinct flavor, not just heat. Fresh chilies include jalapeño, serrano, poblano, and habanero; dried chilies include ancho (dried poblano), chipotle (smoked, dried jalapeño), guajillo, pasilla, mulato, chile de árbol, and cascabel.",
    "Dried chilies are typically toasted, soaked, and ground into sauces. Salsas range from raw pico de gallo to cooked salsa roja and tangy salsa verde made with tomatillos. Moles are complex sauces combining several dried chilies with seeds, nuts, spices, and sometimes chocolate; mole poblano from Puebla and Oaxaca's black mole (mole negro) are famous."]],
  ["Tortillas and antojitos",[
    "Tortillas, corn in most of Mexico and flour in the north (where wheat was introduced by the Spanish), accompany most meals. Antojitos ('little cravings'), masa-based street foods, include tacos, quesadillas, sopes, gorditas, tlayudas (large Oaxacan tortillas), tostadas, and tamales (masa steamed in corn husks or banana leaves).",
    "Tacos come in countless forms: tacos al pastor (pork marinated with chilies and pineapple, cooked on a vertical spit, an adaptation of Lebanese shawarma brought by immigrants in the early 20th century), carnitas (pork slowly cooked in lard, from Michoacán), barbacoa (slow-cooked meat, traditionally in an underground pit), and fish tacos from Baja California."]],
  ["Regional cuisines",[
    "Oaxaca is known for its moles, tlayudas, quesillo cheese, chapulines (toasted grasshoppers), and mezcal. The Yucatán, with Maya traditions, offers cochinita pibil (pork marinated in achiote and sour orange, cooked in banana leaves in a pit), sopa de lima, and habanero salsas. Puebla is the home of mole poblano and chiles en nogada (stuffed poblanos in walnut sauce with pomegranate, in the colors of the Mexican flag).",
    "Jalisco gave the world tequila and birria (spiced stewed goat or beef, now popular as quesabirria tacos). Northern Mexico favors beef, flour tortillas, and grilled meats (carne asada); Veracruz has seafood with tomatoes, olives, and capers (huachinango a la veracruzana), showing Spanish influence. Mexico City's street food culture is legendary."]],
  ["Spanish encounter and fusion",[
    "After the Spanish conquest in 1521, Mexican cuisine absorbed European ingredients: pork, beef, chicken, cheese, wheat, rice, onions, garlic, cinnamon, and sugar. Convents in colonial Mexico developed elaborate dishes and sweets, and traditional stories credit nuns in Puebla with creating mole poblano.",
    "Mexican cuisine's richness comes from this fusion with deep Indigenous roots. Pre-Hispanic foods like huitlacoche (corn smut, a fungus prized as a delicacy), nopales (cactus pads), escamoles (ant larvae), and quelites (wild greens) remain part of the cuisine."]],
  ["Mexican food in the world",[
    "Mexican food is enormously popular worldwide, especially in the United States, where Tex-Mex developed in Texas with dishes like chili con carne, fajitas, nachos (invented by Ignacio 'Nacho' Anaya in Piedras Negras around 1943), and hard-shell tacos. Tex-Mex is a cuisine in its own right, though distinct from regional Mexican cooking.",
    "Chefs like Enrique Olvera (Pujol, Mexico City) and writers like Diana Kennedy and Rick Bayless have championed the depth of regional Mexican cuisine. Drinks include tequila and mezcal (from agave), pulque (fermented agave sap, pre-Hispanic), horchata, and Mexican hot chocolate."]]
  ],
  terms:[["Nixtamalization","Cooking maize with alkali to make masa."],["Masa","Dough made from nixtamalized maize."],["Comal","A flat griddle for cooking tortillas."],["Mole","A complex sauce of chilies, seeds, nuts, and spices."],["Antojitos","Masa-based Mexican snacks and street foods."],["Al pastor","Pork cooked on a vertical spit, inspired by Lebanese shawarma."],["Tex-Mex","Mexican-American cuisine developed in Texas."]],
  w:"Mexican cuisine is a living ancient tradition, built on maize and chilies, and one of the world's most influential cuisines.",
  src:["Mexican cuisine","Nixtamalization","Mole (sauce)","Taco","Al pastor","Tex-Mex cuisine"],
  q:[["Which national cuisine was inscribed by UNESCO in 2010 as the first of its kind?","Traditional Mexican cuisine","Italian cuisine","Japanese washoku","Korean cuisine"],
     ["What is a chipotle?","A smoked, dried jalapeño","A fresh poblano","A dried poblano","A habanero"],
     ["Tacos al pastor were inspired by…","Lebanese shawarma","Spanish tapas","Chinese stir-fry","Maya cooking"],
     ["Cochinita pibil comes from…","The Yucatán","Oaxaca","Jalisco","Puebla"],
     ["Chiles en nogada display the colors of…","The Mexican flag","The Spanish flag","Christmas","Autumn leaves"],
     ["Who invented nachos around 1943?","Ignacio 'Nacho' Anaya","Diana Kennedy","Rick Bayless","Enrique Olvera"]]},

{ t:"The Caribbean and Central America", s:"Creole kitchens of many origins",
  sec:[
  ["Creolization",[
    "Caribbean cuisines are among the world's most creolized, blending Indigenous Taíno, Kalinago, and Arawak foods (cassava, corn, peppers, and the barbacoa method of grilling on wooden frames, which gave English the word 'barbecue'), African traditions brought by enslaved people, European colonial influences (Spanish, British, French, Dutch), and later Indian, Chinese, and Middle Eastern immigrants, many arriving as indentured laborers after slavery's abolition.",
    "Common ingredients include rice, beans, plantains, cassava, yams, breadfruit (brought from Tahiti by the British in 1793 as cheap food for enslaved people, after the famous mutiny on the Bounty interrupted an earlier attempt), salt fish, coconut, allspice, Scotch bonnet chilies, thyme, scallions, and citrus."]],
  ["Jamaica and the English-speaking Caribbean",[
    "Jamaican cuisine is known for jerk, meat (especially chicken and pork) marinated in a paste of Scotch bonnets, allspice (pimento), thyme, and scallions, then slow-cooked over pimento wood. Jerk traditions are linked to the Maroons, communities of escaped enslaved people. Ackee and saltfish is the national dish; ackee, a West African fruit, must be eaten only when ripe, as unripe fruit is toxic.",
    "Other favorites include curry goat, oxtail stew, rice and peas (with kidney beans and coconut milk), festival (fried dumplings), patties, and bammy (cassava flatbread). Trinidad and Tobago, with a large Indian-descended population, has doubles (curried chickpeas in fried bread), roti, pelau, and callaloo. Barbados has cou-cou and flying fish."]],
  ["The Spanish and French Caribbean",[
    "Cuba's cuisine includes ropa vieja (shredded beef in tomato sauce), moros y cristianos (black beans and rice), lechón asado (roast pork with mojo, a garlic-citrus sauce), and the Cuban sandwich, developed among Cuban workers in Florida. Puerto Rico has mofongo (mashed fried plantains with garlic and pork cracklings), arroz con gandules, and pasteles. The Dominican Republic's la bandera (rice, beans, and meat) and sancocho (a hearty stew) are daily staples.",
    "Haiti's cuisine includes griot (fried marinated pork), pikliz (spicy pickled cabbage), diri ak djon djon (rice with black mushrooms), and soup joumou, a pumpkin soup traditionally eaten on January 1 to celebrate independence in 1804, inscribed by UNESCO in 2021. Martinique and Guadeloupe have accras (salt cod fritters), colombo (curry), and rhum agricole."]],
  ["Central America",[
    "Central American cuisines, from Guatemala to Panama, share Maya and other Indigenous roots, Spanish influences, and Afro-Caribbean traditions on the Caribbean coast. Corn tortillas, beans, rice, plantains, and tamales are staples. Guatemala's pepián, a rich stew with roasted seeds and chilies, has pre-Hispanic roots.",
    "El Salvador's pupusas (thick corn tortillas stuffed with cheese, beans, or pork, served with curtido, a fermented cabbage slaw) are the national dish. Honduras has baleadas (flour tortillas with beans, cheese, and cream); Costa Rica and Nicaragua have gallo pinto (rice and beans) for breakfast. Garifuna communities on the Caribbean coast, of African and Indigenous descent, have dishes like hudut (fish in coconut broth with mashed plantains)."]],
  ["Rum, sugar, and history",[
    "The Caribbean was the center of the colonial sugar economy, which depended on the enslavement of Africans. Rum, distilled from molasses or cane juice, emerged in the Caribbean in the 17th century, notably in Barbados, and became central to colonial trade and the British Royal Navy's daily ration (until 1970).",
    "Caribbean cuisines thus embody both a painful history and remarkable resilience, creativity, and celebration, seen in carnival foods, Sunday family meals, and roadside grills."]],
  ["Caribbean food abroad",[
    "Migration to the United Kingdom (the Windrush generation from 1948), the United States, Canada, and France spread Caribbean food. Jerk chicken, roti, patties, and rice and peas are popular in cities like London, New York, Toronto, and Miami, where carnival celebrations feature food stalls.",
    "Caribbean flavors like Scotch bonnet heat, allspice, and lime have influenced chefs worldwide."]]
  ],
  terms:[["Creolization","The blending of different cultures into new forms, including cuisines."],["Jerk","Jamaican spiced marinade and slow-grilling method."],["Ackee","A West African fruit used in Jamaica's national dish."],["Mofongo","Puerto Rican mashed fried plantains."],["Pupusa","A stuffed corn tortilla from El Salvador."],["Soup joumou","Haitian pumpkin soup celebrating independence."]],
  w:"Caribbean and Central American cuisines show how African, Indigenous, European, and Asian traditions merged into vibrant creole cooking.",
  src:["Caribbean cuisine","Jamaican cuisine","Jerk (cooking)","Cuban cuisine","Pupusa","Soup joumou"],
  q:[["The word 'barbecue' comes from…","A Taíno word for a wooden grilling frame","A French term","An English verb","A Spanish town"],
     ["What is Jamaica's national dish?","Ackee and saltfish","Jerk chicken","Curry goat","Rice and peas"],
     ["Jerk traditions are linked to…","The Maroons","Spanish monks","Chinese immigrants","British sailors"],
     ["Mofongo is from…","Puerto Rico","Cuba","Haiti","Jamaica"],
     ["Haitians eat soup joumou on January 1 to celebrate…","Independence in 1804","Christmas","Harvest","Carnival"],
     ["What is El Salvador's national dish?","Pupusas","Baleadas","Gallo pinto","Pepián"]]},

{ t:"The United States I: Roots", s:"Indigenous foodways, the South, and soul food",
  sec:[
  ["Indigenous foodways",[
    "Before European colonization, Indigenous peoples across North America had diverse food systems: the Three Sisters agriculture of maize, beans, and squash in the East and Southwest; wild rice harvesting by the Ojibwe and others in the Great Lakes; salmon fishing in the Pacific Northwest; bison hunting on the Plains; and the gathering of acorns, berries, nuts, and maple sap.",
    "Colonization, forced removal, and reservation policies devastated these food systems; government commodity foods like white flour and lard led to dishes such as frybread, now both a symbol of survival and a reminder of loss. Indigenous chefs like Sean Sherman (the Sioux Chef, whose Minneapolis restaurant Owamni won the 2022 James Beard Award for Best New Restaurant) are reviving pre-colonial ingredients and promoting food sovereignty."]],
  ["Colonial foundations",[
    "English colonists in New England adopted corn, beans, pumpkins, turkey, cranberries, and clams, learning from Indigenous peoples; the 1621 harvest feast at Plymouth, shared with the Wampanoag, became the basis of the Thanksgiving myth. New England cooking developed baked beans, chowders, brown bread, and clambakes.",
    "Other European settlers brought their foodways: the Dutch in New York (cookies, coleslaw), the Germans in Pennsylvania (scrapple, pretzels, apple butter), the Spanish in Florida and the Southwest, and the French in Louisiana."]],
  ["The South",[
    "Southern cuisine combines African, European, and Indigenous influences, shaped heavily by enslaved African cooks who prepared food in plantation kitchens and their own homes. Staples include corn (cornbread, grits, hominy), pork, rice in the Lowcountry, greens (collards cooked slowly with pork), black-eyed peas, sweet potatoes, okra, and fried chicken.",
    "Iconic dishes include biscuits and gravy, shrimp and grits, Hoppin' John (rice and black-eyed peas, eaten on New Year's Day for luck), fried green tomatoes, pecan pie, and barbecue. Southern hospitality and Sunday dinners are cultural institutions. Edna Lewis's 'The Taste of Country Cooking' (1976) is a classic celebration of Southern farm cooking."]],
  ["Louisiana: Creole and Cajun",[
    "Louisiana has two distinct but related cuisines. Creole cuisine developed in New Orleans, blending French, Spanish, African, Caribbean, and later Italian influences; it is more urban and refined, often using tomatoes and butter, with dishes like shrimp Creole, gumbo, jambalaya, red beans and rice (traditionally a Monday dish), and beignets.",
    "Cajun cuisine comes from Acadians, French settlers expelled from Canada by the British from 1755, who settled in rural southwest Louisiana. It is rustic, using the 'holy trinity' of onion, celery, and bell pepper, dark roux, crawfish, andouille sausage, boudin, and dishes like étouffée and crawfish boils. Both share gumbo, though styles vary."]],
  ["Soul food",[
    "Soul food, a term popularized in the 1960s during the Black Power movement, refers to the cooking of African Americans, especially as carried from the rural South to Northern cities during the Great Migration (about 1910–1970). It includes fried chicken, catfish, collard greens, macaroni and cheese, candied yams, black-eyed peas, chitterlings, cornbread, and peach cobbler.",
    "Soul food carries memories of resilience: making nourishing, delicious meals from limited ingredients under oppression. Historians emphasize that African American culinary contributions extend far beyond soul food, including skilled professional cooks and caterers, like James Hemings, enslaved by Thomas Jefferson and trained as a chef in Paris, who helped introduce French dishes like macaroni and cheese to American elite tables."]],
  ["Regional America",[
    "America's other regions developed their own traditions: Midwestern hotdish and casseroles, Chicago deep-dish pizza and hot dogs, Wisconsin cheese, Kansas City and Texas barbecue, Southwestern and New Mexican food with Hatch green chiles, Pacific Northwest salmon and Dungeness crab, Hawaiian cuisine blending Polynesian, Asian, and American influences (poke, plate lunch, Spam musubi), and Alaskan Native foods.",
    "This regional diversity, often overshadowed by national chains, is a rich heritage that chefs and food writers have increasingly documented and celebrated."]]
  ],
  terms:[["Food sovereignty","The right of communities to control their own food systems."],["Frybread","Fried dough developed from government commodity rations, a symbol in Native communities."],["Lowcountry","Coastal South Carolina and Georgia, with rice-based cuisine."],["Creole (Louisiana)","Urban New Orleans cuisine blending many influences."],["Cajun","Rural cuisine of Louisiana's Acadian descendants."],["Soul food","African American cuisine rooted in the South."]],
  w:"American cuisine's roots lie in Indigenous foodways and in the profound contributions of African Americans, whose cooking shaped the nation's food.",
  src:["Native American cuisine","Cuisine of the Southern United States","Louisiana Creole cuisine","Cajun cuisine","Soul food","James Hemings"],
  q:[["Which chef leads the revival of pre-colonial Indigenous ingredients through the restaurant Owamni?","Sean Sherman","Edna Lewis","Paul Prudhomme","Emeril Lagasse"],
     ["Hoppin' John is traditionally eaten on…","New Year's Day","Thanksgiving","Easter","the Fourth of July"],
     ["Cajuns descend from…","Acadians expelled from Canada","Spanish settlers","Haitian refugees","German immigrants"],
     ["Red beans and rice is traditionally a dish for…","Monday","Friday","Sunday","Christmas"],
     ["Soul food was carried north during…","The Great Migration","The Gold Rush","The Civil War","Prohibition"],
     ["Who was James Hemings?","An enslaved chef trained in Paris who cooked for Thomas Jefferson","A barbecue pitmaster","A New Orleans restaurateur","A Thanksgiving chef"]]},

{ t:"The United States II: A Nation of Immigrants", s:"Burgers, delis, pizza, and fusion",
  sec:[
  ["An immigrant cuisine",[
    "American food has been continuously reshaped by immigration. German immigrants in the 19th century brought lager beer, sausages, hamburgers (named after Hamburg), and frankfurters; Irish immigrants brought corned beef traditions (actually adopted in America from Jewish butchers); Italian immigrants brought pizza, pasta, and sandwiches; Jewish immigrants brought bagels, delis, and cheesecake; and Chinese immigrants created Chinese-American restaurants across the country.",
    "After the 1965 Immigration and Nationality Act ended national-origin quotas, immigration from Asia, Latin America, Africa, and the Middle East grew dramatically, transforming American food with Vietnamese, Korean, Indian, Thai, Salvadoran, Ethiopian, and countless other cuisines."]],
  ["Iconic American foods",[
    "Hamburgers became national icons through roadside stands and chains, and many places claim to have invented them. Hot dogs became stadium and street food. Fried chicken, apple pie ('as American as apple pie', though apple pies came from Europe), barbecue, and macaroni and cheese are national comfort foods.",
    "American innovations include the chocolate chip cookie (invented by Ruth Wakefield at the Toll House Inn in Massachusetts in the late 1930s), peanut butter, the club sandwich, Buffalo wings (credited to the Anchor Bar in Buffalo, New York, in 1964), brownies, s'mores, and potato chips (a legend credits George Crum in Saratoga Springs, 1853)."]],
  ["Pizza and the deli",[
    "Pizza arrived with Neapolitan immigrants; Lombardi's in New York, licensed in 1905, is often called America's first pizzeria. After World War II, returning soldiers who had been in Italy helped popularize pizza, and regional styles developed: New York's thin, foldable slices; Chicago's deep-dish (claimed by Pizzeria Uno, 1943); New Haven's charred 'apizza'; and Detroit's square pan pizza.",
    "Jewish delicatessens, like Katz's in New York (founded 1888), popularized pastrami, corned beef, matzo ball soup, and bagels with lox and cream cheese. Italian-American red-sauce restaurants created chicken parmigiana, spaghetti and meatballs, and the Italian sub; the Philadelphia cheesesteak and New Orleans muffuletta are other immigrant-inspired sandwiches."]],
  ["Asian and Latin American influences",[
    "Chinese-American cuisine developed dishes like chop suey, egg foo young, General Tso's chicken, and crab rangoon; Japanese-American cooks popularized teriyaki and helped spread sushi, including the California roll. Korean barbecue, Vietnamese pho and banh mi, Thai curries, Indian buffets, and Filipino food are now part of American dining.",
    "Mexican and Tex-Mex food is among the most popular in the US; salsa has competed with ketchup as a top-selling condiment since the early 1990s. Fusion foods like Korean tacos (popularized by Roy Choi's Kogi truck in Los Angeles, 2008) and poke bowls show continuing creativity."]],
  ["Industrial and fast food",[
    "The United States pioneered industrial food production, supermarkets, fast food chains, frozen foods, and processed snacks, which spread globally. McDonald's, KFC, Subway, Starbucks, and others became international symbols of American culture.",
    "At the same time, counter-movements emerged: the farm-to-table movement, farmers' markets (their numbers grew greatly from the 1990s), craft beer (the US has thousands of breweries), artisanal cheese, and third-wave coffee. American food culture contains both mass production and intense craft."]],
  ["Modern American cuisine",[
    "Contemporary American cooking draws on all these traditions. Chefs like Thomas Keller (The French Laundry, Per Se), David Chang (Momofuku), Dan Barber (Blue Hill at Stone Barns), Edward Lee, Nina Compton, and Mashama Bailey reflect diverse influences. The James Beard Foundation, named after the cookbook author and teacher James Beard, gives awards often called the 'Oscars of food'.",
    "Debates continue about authenticity, cultural appropriation, and credit for immigrant cooks. American cuisine is best understood not as a single tradition but as a constantly evolving conversation among many."]]
  ],
  terms:[["Deli","A Jewish-American delicatessen serving cured meats and sandwiches."],["Red-sauce restaurant","An Italian-American restaurant serving tomato-based classics."],["Chinese-American cuisine","Chinese cooking adapted to American tastes."],["Fusion","Combining elements of different cuisines."],["James Beard Awards","Prestigious American food industry awards."]],
  w:"American cuisine is a constantly evolving conversation among immigrant traditions, industry, and craft.",
  src:["American cuisine","Hamburger","Pizza in the United States","Delicatessen","Chinese-American cuisine","James Beard Foundation"],
  q:[["Which 1965 law transformed American immigration and food?","The Immigration and Nationality Act","The Pure Food and Drug Act","The Homestead Act","The Civil Rights Act"],
     ["Who invented the chocolate chip cookie?","Ruth Wakefield","Betty Crocker","Julia Child","Fannie Farmer"],
     ["Buffalo wings are credited to…","The Anchor Bar in Buffalo, 1964","Colonel Sanders","A Chicago diner","Katz's Deli"],
     ["Lombardi's in New York is often called…","America's first pizzeria","The first deli","The first burger stand","The first diner"],
     ["Who popularized Korean tacos with the Kogi truck?","Roy Choi","David Chang","Thomas Keller","Dan Barber"],
     ["The James Beard Awards are often called…","The Oscars of food","The Michelin of America","The Nobel of cooking","The Golden Spoon"]]}

]});


/* ---- from cuisine-16.js ---- */
/* CUISINE FOUNDATIONS, part 16: Unit 8 The Americas, chapters 5-7 */
COURSES.cuisine.units[7].ch.push(

{ t:"Peru and the Andes", s:"Potatoes, ceviche, and a fusion powerhouse",
  sec:[
  ["Andean foundations",[
    "The Andes are one of the world's great centers of crop domestication. Andean peoples domesticated potatoes (Peru has thousands of native varieties, and the International Potato Center in Lima maintains a large collection), quinoa, kiwicha (amaranth), oca, ulluco, maize of many colors, ají chilies, lima beans, and squash, along with llamas, alpacas, and guinea pigs (cuy).",
    "Ingenious techniques allowed survival at high altitudes: chuño (freeze-dried potatoes), charqui (dried meat, the origin of the word 'jerky'), terrace farming, and the pachamanca, meat and vegetables cooked under hot stones in the earth. The Inca Empire stored food in thousands of storehouses (qollqas) along its road network."]],
  ["Ceviche and coastal cuisine",[
    "Peru's long Pacific coast, fed by the cold, nutrient-rich Humboldt Current, provides abundant seafood. Ceviche, Peru's national dish, is raw fish 'cooked' in lime juice with onion, ají chilies, and salt, served with sweet potato and corn. The marinade left over, leche de tigre ('tiger's milk'), is drunk as a restorative. Ceviche was declared part of Peru's national cultural heritage in 2004, and 'practices and meanings associated with the preparation and consumption of ceviche' were inscribed by UNESCO in 2023.",
    "Other coastal dishes include tiradito (sliced raw fish in sauce, influenced by sashimi), causa (layered chilled potato with fillings), and arroz con mariscos."]],
  ["Fusion: Criollo, Chifa, and Nikkei",[
    "Peruvian cuisine is a fusion of Indigenous, Spanish, African, Chinese, Japanese, and Italian influences. Criollo cooking blends Spanish and African traditions: lomo saltado (stir-fried beef with tomatoes, onions, and fries, showing Chinese influence), ají de gallina (chicken in creamy ají amarillo sauce), and anticuchos (grilled beef heart skewers, rooted in Afro-Peruvian cooking).",
    "Chinese immigrants, arriving from 1849 as indentured laborers, created chifa, Chinese-Peruvian cuisine, now found everywhere in Peru (arroz chaufa is fried rice). Japanese immigrants, arriving from 1899, created Nikkei cuisine, blending Japanese technique with Peruvian ingredients, as in tiradito and Nikkei ceviche. Peru has one of the largest ethnic Japanese populations in Latin America."]],
  ["Ají and Peruvian flavors",[
    "Ají peppers are central: ají amarillo (yellow, fruity), ají panca (red, smoky), and rocoto (very hot, often stuffed in Arequipa as rocoto relleno). Huacatay (black mint) and other herbs, along with purple corn (used in chicha morada, a sweet drink, and mazamorra morada, a pudding), are distinctive.",
    "Pisco, a grape brandy, is Peru's national spirit (and also Chile's, a long-running dispute); the pisco sour is its signature cocktail. Inca Kola, a sweet yellow soda, is a national icon."]],
  ["The gastronomic boom",[
    "Since the early 2000s, Peru has experienced a 'gastronomic boom'. Chef Gastón Acurio, with his restaurant Astrid y Gastón and many ventures, promoted Peruvian cuisine as a source of national pride and economic development. Peruvian restaurants have ranked high on international lists: Central, led by Virgilio Martínez and Pía León, which explores Peru's ecosystems by altitude, was named the World's Best Restaurant in 2023, and Maido (Mitsuharu Tsumura) is a leader of Nikkei cuisine.",
    "Lima's Mistura food festival, culinary schools, and tourism have made Peru one of the world's leading food destinations."]],
  ["Bolivia, Ecuador, and Colombia",[
    "Bolivia shares Andean traditions: salteñas (juicy baked empanadas), chuño dishes, and quinoa. Ecuador has locro de papa (potato soup with cheese and avocado), encebollado (fish and cassava soup), and cuy. Colombia is famous for arepas (shared with Venezuela), ajiaco (Bogotá's chicken and potato soup with guascas herb), bandeja paisa (a huge platter from Antioquia), and coffee.",
    "Venezuela's arepas, pabellón criollo (shredded beef, black beans, rice, and plantains), and hallacas (Christmas tamales) are beloved; Venezuelan migration has spread arepas worldwide."]]
  ],
  terms:[["Ceviche","Raw fish marinated in lime juice with chilies and onion."],["Leche de tigre","The citrus marinade of ceviche."],["Chifa","Chinese-Peruvian cuisine."],["Nikkei cuisine","Japanese-Peruvian fusion cuisine."],["Ají amarillo","A fruity yellow Peruvian chili."],["Pachamanca","Andean cooking with hot stones in the earth."],["Pisco","A grape brandy from Peru and Chile."]],
  w:"Peru's cuisine shows how ancient Andean agriculture and successive waves of migration created one of the world's most exciting food cultures.",
  src:["Peruvian cuisine","Ceviche","Chifa","Nikkei cuisine","Central (restaurant)","Gastón Acurio"],
  q:[["Which crop did Andean peoples domesticate in thousands of varieties?","Potato","Wheat","Rice","Soybean"],
     ["What is leche de tigre?","The citrus marinade of ceviche","A milk drink","A chili sauce","A pisco cocktail"],
     ["What is chifa?","Chinese-Peruvian cuisine","Japanese-Peruvian cuisine","Afro-Peruvian cuisine","Inca cuisine"],
     ["Lomo saltado shows the influence of…","Chinese stir-frying","Japanese sushi","French sauces","Italian pasta"],
     ["Which Lima restaurant was named World's Best Restaurant in 2023?","Central","Maido","Astrid y Gastón","Noma"],
     ["The word 'jerky' derives from the Andean…","Charqui","Chuño","Cuy","Chicha"]]},

{ t:"Brazil", s:"Feijoada, churrasco, and a continent of flavors",
  sec:[
  ["Three roots and many branches",[
    "Brazilian cuisine, from a country of continental size, blends Indigenous, Portuguese, and African traditions, with later Italian, German, Japanese, Lebanese, and other immigrant influences. Indigenous peoples contributed cassava (manioc), the region's most important staple, as well as açaí, guaraná, peanuts, and techniques for processing bitter cassava, which contains toxic cyanogenic compounds removed by grating, pressing, and cooking.",
    "Cassava becomes farinha (toasted cassava flour, sprinkled on many dishes), farofa (farinha toasted in butter with additions), tapioca crepes, and pão de queijo (cheese bread made with cassava starch, from Minas Gerais). Brazil has five major regions, each with distinct cuisines."]],
  ["Feijoada and everyday food",[
    "Feijoada, a stew of black beans with various pork cuts and sausages, served with rice, collard greens (couve), farofa, and orange slices, is often called Brazil's national dish; it is traditionally eaten on Wednesdays and Saturdays in Rio de Janeiro. Its popular origin story as a dish created by enslaved people from discarded cuts is debated by historians, who point to European bean-and-meat stew traditions.",
    "The everyday Brazilian plate is rice and beans (arroz e feijão), with meat, salad, and farofa. Snacks (salgados) include coxinhas (teardrop-shaped chicken croquettes), pastéis (fried pastries), and empadas. Brigadeiros, chocolate fudge balls, are essential at birthday parties."]],
  ["Bahia and the Afro-Brazilian kitchen",[
    "Brazil received more enslaved Africans than any other country in the Americas, around 4.9 million according to estimates, and Bahia, in the northeast, has the strongest Afro-Brazilian culinary traditions. Bahian cuisine uses dendê (red palm oil), coconut milk, dried shrimp, peanuts, and malagueta chilies.",
    "Dishes include moqueca baiana (fish or shrimp stew with coconut milk and dendê), vatapá (a creamy paste of bread, shrimp, peanuts, and coconut), and acarajé (black-eyed pea fritters fried in dendê and split and filled with vatapá and shrimp), sold by baianas in white dresses; the craft of the baianas de acarajé is recognized as Brazilian national heritage. Acarajé has roots in West African akara and is linked to Candomblé religious offerings."]],
  ["Churrasco and the south",[
    "In southern Brazil, gaúchos (cowboys) developed churrasco, beef and other meats roasted on skewers over fire, seasoned simply with coarse salt. Churrascarias serve rodízio style, with waiters bringing skewers to the table and carving meat until diners signal to stop; picanha (top sirloin cap) is the favorite cut. Chimarrão, a bitter mate tea drunk from a gourd, is the gaúcho drink.",
    "The south also has strong German and Italian immigrant influences, seen in beer, sausages, polenta, and pasta. São Paulo, with large Italian, Japanese, Lebanese, and other communities, is one of the world's great food cities, famous for pizza and for the largest Japanese community outside Japan."]],
  ["The Amazon and Minas Gerais",[
    "Amazonian cuisine uses river fish like pirarucu and tambaqui, tucupi (a yellow broth from fermented cassava juice), jambu (a herb that numbs the mouth), and fruits like açaí, cupuaçu, and bacuri. Pato no tucupi (duck in tucupi) and tacacá are specialties of Belém. Açaí, a staple in the Amazon, became a global 'superfood' bowl.",
    "Minas Gerais, a mining region, has hearty comfort food: pão de queijo, feijão tropeiro (beans with farinha, pork, and eggs), tutu de feijão, and doce de leite, cooked on wood-burning stoves. Chef Alex Atala, of D.O.M. in São Paulo, brought Amazonian ingredients to international fine dining."]],
  ["Drinks and culture",[
    "Cachaça, a spirit distilled from fresh sugarcane juice, is Brazil's national spirit, the base of the caipirinha, made with lime, sugar, and ice. Brazil has been the world's largest coffee producer since the 19th century. Guaraná soda, from an Amazonian fruit high in caffeine, is a national favorite.",
    "Food is central to Brazilian social life, from beach snacks and street markets (feiras) to long Sunday churrascos and festivals like the June Festas Juninas, with corn dishes like pamonha and canjica."]]
  ],
  terms:[["Farinha","Toasted cassava flour."],["Farofa","Cassava flour toasted with butter and additions."],["Feijoada","Black bean and pork stew."],["Dendê","Red palm oil used in Bahian cuisine."],["Acarajé","Black-eyed pea fritters fried in dendê."],["Churrasco","Brazilian grilled meats on skewers."],["Cachaça","A spirit distilled from sugarcane juice."]],
  w:"Brazil's cuisine combines Indigenous, African, Portuguese, and immigrant traditions across a vast and diverse country.",
  src:["Brazilian cuisine","Feijoada","Acarajé","Churrasco","Cachaça","Cassava"],
  q:[["Why must bitter cassava be processed carefully?","It contains toxic cyanogenic compounds","It is too sweet","It spoils instantly","It is very expensive"],
     ["What is pão de queijo made with?","Cassava starch and cheese","Wheat flour","Corn","Rice flour"],
     ["Which region has the strongest Afro-Brazilian culinary traditions?","Bahia","Rio Grande do Sul","Minas Gerais","Amazonas"],
     ["Acarajé has roots in which West African food?","Akara","Fufu","Jollof","Suya"],
     ["What is the base spirit of the caipirinha?","Cachaça","Rum","Pisco","Tequila"],
     ["Which São Paulo chef brought Amazonian ingredients to fine dining?","Alex Atala","Gastón Acurio","Virgilio Martínez","Francis Mallmann"]]},

{ t:"Argentina, Chile, and Canada", s:"Asado, empanadas, and the northern table",
  sec:[
  ["Argentina and the asado",[
    "Argentina, with vast grasslands (the Pampas), developed one of the world's great beef cultures. The asado, a social gathering centered on meats grilled over wood or charcoal embers on a parrilla (grill), led by an asador, is a national ritual, usually on weekends. Cuts include tira de asado (short ribs), vacío (flank), bife de chorizo (sirloin), and entraña (skirt), along with chorizo, morcilla (blood sausage), and mollejas (sweetbreads).",
    "Chimichurri, a sauce of parsley, garlic, oregano, chili, vinegar, and oil, accompanies grilled meat. Chef Francis Mallmann popularized Patagonian open-fire cooking techniques internationally."]],
  ["Argentine and Uruguayan food",[
    "Mass Italian and Spanish immigration in the late 19th and early 20th centuries shaped Argentine food: pizza (often with thick crust and lots of cheese), fugazza (onion pizza), pasta, milanesas (breaded cutlets), and gelato. Empanadas, filled pastries, vary by province.",
    "Dulce de leche, milk caramel, fills alfajores (sandwich cookies) and many desserts. Yerba mate, a caffeinated infusion drunk from a gourd through a metal straw (bombilla) and shared in a circle, is central to social life in Argentina, Uruguay, Paraguay, and southern Brazil. Uruguay, with one of the world's highest beef consumption rates per person, shares the asado culture and has the chivito sandwich. Argentine Malbec, especially from Mendoza, became internationally famous."]],
  ["Chile",[
    "Chile's long, narrow territory, from desert to glaciers, and its Pacific coast provide excellent seafood: sea urchins, conger eel (caldillo de congrio, celebrated in a poem by Pablo Neruda), abalone-like locos, and machas (razor clams). Curanto, from the island of Chiloé, cooks seafood, meat, and potatoes in a pit with hot stones covered with leaves.",
    "Other Chilean dishes include pastel de choclo (a corn pie), empanadas de pino (beef, onion, olive, and egg), sopaipillas, and completos (loaded hot dogs). Chile is a major wine producer, known for Carménère, a grape once thought extinct in Bordeaux but rediscovered in Chilean vineyards in 1994. Pisco and the pisco sour are also central to Chilean drinking culture."]],
  ["Canada",[
    "Canadian cuisine reflects Indigenous foodways (including bannock, pemmican, wild rice, salmon, and game), French colonial traditions, British influences, and successive waves of immigration. Quebec has a distinctive French-Canadian cuisine: tourtière (meat pie), pea soup, tarte au sucre, and poutine, fries topped with cheese curds and gravy, which emerged in rural Quebec in the 1950s and became a national icon.",
    "Canada is the world's largest producer of maple syrup, most of it from Quebec; sugar shacks (cabanes à sucre) celebrate the spring sap harvest. Other Canadian foods include Montreal-style bagels (smaller, denser, boiled in honey water, and baked in wood-fired ovens) and smoked meat, butter tarts, Nanaimo bars, Atlantic lobster and cod, and Pacific salmon."]],
  ["Multicultural cities",[
    "Toronto and Vancouver are among the most multicultural cities in the world, with a high proportion of foreign-born residents, and their food scenes reflect large Chinese, South Asian, Caribbean, Portuguese, Italian, Korean, Filipino, and other communities. Vancouver is known for excellent Cantonese food and sushi; Toronto for Caribbean, South Asian, and Portuguese food.",
    "Indigenous chefs across Canada are reclaiming traditional ingredients and techniques, part of a broader movement across the Americas."]],
  ["The Americas as a whole",[
    "Across the Americas, cuisines share a pattern: Indigenous foundations (maize, potatoes, beans, chilies, cassava), European colonization, African traditions brought through slavery, and successive immigrant waves. The result is some of the world's most diverse and dynamic food cultures.",
    "Understanding these cuisines requires recognizing both the creativity of their cooks and the histories of conquest, slavery, and migration that shaped them."]]
  ],
  terms:[["Asado","An Argentine social gathering centered on grilled meats."],["Parrilla","A grill used for asado."],["Chimichurri","An Argentine herb and garlic sauce."],["Yerba mate","A caffeinated infusion drunk from a gourd."],["Dulce de leche","Milk caramel."],["Poutine","Fries with cheese curds and gravy from Quebec."],["Curanto","A Chilean pit-cooked seafood and meat feast."]],
  w:"The Southern Cone and Canada show how land, immigration, and Indigenous heritage shape national foods across the Americas.",
  src:["Argentine cuisine","Asado","Chilean cuisine","Canadian cuisine","Poutine","Yerba mate"],
  q:[["What is a parrilla?","A grill used for asado","An Argentine sauce","A type of beef","A mate gourd"],
     ["Chimichurri contains…","Parsley, garlic, oregano, vinegar, and oil","Tomatoes and chilies","Cream and cheese","Peanuts and coconut"],
     ["How is yerba mate traditionally drunk?","From a gourd through a metal straw, shared in a circle","From a teacup with milk","Iced from a bottle","Mixed with wine"],
     ["Which grape was rediscovered in Chile in 1994?","Carménère","Malbec","Merlot","Pinot Noir"],
     ["Poutine originated in…","Rural Quebec in the 1950s","Toronto","Vancouver","Nova Scotia"],
     ["Which country is the world's largest producer of maple syrup?","Canada","USA","Norway","Japan"]]}

);


/* ---- from cuisine-17.js ---- */
/* CUISINE FOUNDATIONS, part 17: Unit 9 Drinks, chapters 1-6 */
COURSES.cuisine.units.push({ t:"Drinks", ch:[

{ t:"Coffee", s:"From Ethiopian forests to the third wave",
  sec:[
  ["Origins",[
    "Coffee comes from the seeds (beans) of the Coffea plant, native to the forests of Ethiopia, where a legend tells of a goat herder named Kaldi noticing his goats' energy after eating coffee cherries. Reliable records show coffee being drunk in Sufi monasteries in Yemen by the 15th century, where it helped worshippers stay awake for nighttime devotions.",
    "Coffeehouses spread through Mecca, Cairo, and Istanbul in the 16th century, becoming centers of conversation, politics, and entertainment, and sometimes banned by nervous authorities. Coffee reached Europe in the 17th century; England's first coffeehouse opened in Oxford in 1650 (some say 1651), and London's coffeehouses became places of business; Lloyd's of London insurance began in Edward Lloyd's coffeehouse."]],
  ["Species and growing",[
    "The two main species are Coffea arabica (arabica), which accounts for a majority of world production and is prized for complex, aromatic flavors, grown at higher altitudes; and Coffea canephora (robusta), more bitter, higher in caffeine, hardier, and grown at lower altitudes, used in espresso blends and instant coffee. Vietnam is the largest robusta producer.",
    "Coffee grows in the 'bean belt' between the tropics. Brazil is the world's largest producer, followed by Vietnam, Colombia, Indonesia, and Ethiopia. Like wine, coffee flavor reflects variety, terroir, altitude, and processing: washed (fruit removed before drying, giving clean, bright flavors), natural (dried in the whole cherry, giving fruity flavors), and honey processes. Climate change threatens many coffee-growing regions."]],
  ["Roasting and brewing",[
    "Green coffee beans are roasted to develop flavor through Maillard reactions and caramelization. Light roasts preserve acidity and origin flavors; dark roasts emphasize bitterness and roast flavors. Freshly ground coffee loses aroma quickly, so grinding just before brewing is ideal.",
    "Brewing methods include drip and pour-over (like the Hario V60 and Chemex), French press (immersion), espresso (hot water forced through finely ground coffee at around 9 bars of pressure, producing a concentrated shot topped with crema), moka pot, cold brew, and Turkish coffee (very finely ground coffee simmered in a cezve). The key variables are grind size, water temperature (about 90–96°C), ratio of coffee to water, and time."]],
  ["Espresso and coffee culture",[
    "The espresso machine developed in Italy; Achille Gaggia's lever machine of 1948 produced the crema that defines modern espresso. Italian coffee culture includes espresso, cappuccino (espresso with steamed and foamed milk, typically a morning drink), macchiato, and caffè latte. Coffee is usually drunk standing at a bar.",
    "Other cultures have distinctive traditions: the Ethiopian coffee ceremony, roasting and brewing coffee in a clay jebena; Turkish coffee, inscribed by UNESCO in 2013; Vietnamese coffee with condensed milk; Viennese coffeehouses; and Scandinavian countries, which have among the highest coffee consumption per person in the world."]],
  ["Waves of coffee",[
    "Coffee professionals describe 'waves': the first wave was mass-market coffee in the 20th century (cans of pre-ground coffee and instant coffee, with Nescafé launched in 1938); the second wave brought espresso drinks and café culture, led by chains like Starbucks (founded in Seattle in 1971, expanded by Howard Schultz); and the third wave treats coffee as an artisanal product, emphasizing single origins, light roasts, direct trade with farmers, and precise brewing.",
    "Baristas compete in championships, and specialty coffee is graded by the Specialty Coffee Association's cupping protocols, with scores of 80 or above qualifying as specialty."]],
  ["Coffee and ethics",[
    "Coffee is grown mostly by smallholder farmers in developing countries, many of whom earn very little. Price volatility and low prices have caused hardship. Certifications like Fairtrade (launched with Max Havelaar coffee in the Netherlands in 1988), Rainforest Alliance, and organic aim to improve conditions, though their effectiveness is debated.",
    "Caffeine is the world's most widely consumed psychoactive substance. Moderate coffee consumption is generally considered safe for most adults, with many health authorities suggesting up to around 400 mg of caffeine per day (roughly three to four cups of brewed coffee) for healthy adults."]]
  ],
  terms:[["Arabica","The main coffee species, prized for aromatic flavor."],["Robusta","A hardier, more bitter coffee species higher in caffeine."],["Espresso","Concentrated coffee brewed by forcing hot water through fine grounds under pressure."],["Crema","The golden foam on top of espresso."],["Third wave coffee","Coffee treated as an artisanal product emphasizing origin and craft."],["Cupping","The professional method of tasting and grading coffee."]],
  w:"Coffee is one of the world's most traded commodities and a daily ritual with a rich history and craft.",
  src:["Coffee","History of coffee","Coffea arabica","Espresso","Third-wave coffee","Fairtrade"],
  q:[["Where is coffee native?","Ethiopia","Brazil","Italy","Vietnam"],
     ["Which coffee species is more bitter and higher in caffeine?","Robusta","Arabica","Liberica","Excelsa"],
     ["Which country is the world's largest coffee producer?","Brazil","Vietnam","Colombia","Ethiopia"],
     ["Espresso is brewed at about what pressure?","9 bars","1 bar","50 bars","100 bars"],
     ["Who developed the lever espresso machine that produced crema in 1948?","Achille Gaggia","Howard Schultz","Luigi Bezzera","Alfred Peet"],
     ["Which insurance market began in a coffeehouse?","Lloyd's of London","AXA","Allianz","Prudential"]]},

{ t:"Tea", s:"Camellia sinensis and the world's most popular brewed drink",
  sec:[
  ["One plant, many teas",[
    "True tea comes from one plant, Camellia sinensis, native to the region where southwestern China, northeastern India, and Myanmar meet. After water, tea is often described as the world's most consumed drink. Herbal 'teas' like chamomile or rooibos are technically infusions (tisanes), not tea.",
    "Two main varieties exist: Camellia sinensis var. sinensis (Chinese, small-leaved, suited to green and white teas) and var. assamica (Assam, large-leaved, suited to strong black teas). Differences among tea types come mainly from processing, especially oxidation, the enzymatic browning of leaves after they are bruised."]],
  ["Types of tea",[
    "White tea is minimally processed (withered and dried), delicate and sweet. Green tea is heated soon after picking to stop oxidation, by pan-firing in China (like Longjing, Dragon Well) or steaming in Japan (like sencha and gyokuro), keeping fresh, grassy flavors. Matcha is shade-grown Japanese green tea ground into a fine powder and whisked.",
    "Oolong teas are partially oxidized, ranging from light and floral (like Taiwanese high-mountain oolongs) to dark and roasted (like Wuyi rock teas such as Da Hong Pao). Black tea (called 'red tea', hong cha, in China) is fully oxidized, robust and malty, like Assam, Darjeeling, Ceylon, and Keemun. Dark teas like pu-erh from Yunnan are fermented and aged, sometimes for decades. Yellow tea is a rare, lightly 'sweltered' variant."]],
  ["Tea in China and Japan",[
    "Chinese legend credits Emperor Shennong with discovering tea around 2737 BCE when leaves blew into his boiling water. Tea became widespread during the Tang dynasty, when Lu Yu wrote 'The Classic of Tea' (Cha Jing, around 760–780 CE), the first book devoted to tea. Methods changed from boiling compressed tea cakes, to whisking powdered tea in the Song dynasty, to steeping loose leaves from the Ming dynasty onward.",
    "Japanese monks, notably Eisai in the late 12th century, brought tea and Zen practices from China. The Japanese tea ceremony (chanoyu or sadō), refined by Sen no Rikyū in the 16th century, is a ritual of preparing and serving matcha, embodying harmony, respect, purity, and tranquility. Chinese gongfu cha uses small pots and many short infusions to appreciate high-quality oolongs and pu-erhs."]],
  ["Tea and empire",[
    "Tea reached Europe in the 17th century through Dutch and Portuguese traders. Catherine of Braganza, the Portuguese wife of England's Charles II, popularized tea drinking at the English court after 1662. Tea became Britain's national drink, and its trade shaped history: the Boston Tea Party (1773) protested British taxes, and Britain's trade deficit with China led to the opium trade and the Opium Wars (1839–1842 and 1856–1860).",
    "To break China's monopoly, the British East India Company employed the botanist Robert Fortune, who smuggled tea plants and knowledge from China to India in the 1840s–50s. The British established vast plantations in Assam, Darjeeling, and Ceylon (Sri Lanka), using indentured labor. India, Kenya, and Sri Lanka became major producers; China remains the largest."]],
  ["Tea cultures around the world",[
    "Tea cultures are diverse: British afternoon tea with milk; Indian masala chai with milk, sugar, and spices; Russian tea from a samovar; Moroccan mint tea; Turkish çay in tulip-shaped glasses (Turkey has among the highest per capita consumption in the world); Tibetan butter tea (po cha) with yak butter and salt; and Hong Kong milk tea, strained through cloth ('silk stocking tea').",
    "Taiwan invented bubble tea (boba), milk tea with tapioca pearls, in the 1980s; it became a global phenomenon. Iced tea and sweet tea are American favorites; the tea bag, popularized in the early 20th century in the US, made tea convenient."]],
  ["Brewing well",[
    "Brewing depends on tea type. Delicate green and white teas are brewed with cooler water (around 70–85°C) for short times to avoid bitterness; oolongs at around 85–95°C; black and dark teas at near-boiling temperatures. The ratio of leaves to water, the steeping time, and water quality matter.",
    "High-quality loose-leaf teas can be infused several times, with each infusion revealing different flavors. Tea contains caffeine and L-theanine, an amino acid associated with calm alertness, as well as polyphenols such as catechins."]]
  ],
  terms:[["Camellia sinensis","The plant from which all true tea comes."],["Oxidation","Enzymatic browning of tea leaves that determines tea type."],["Matcha","Powdered Japanese green tea."],["Oolong","Partially oxidized tea."],["Pu-erh","Fermented, aged dark tea from Yunnan."],["Chanoyu","The Japanese tea ceremony."],["Tisane","An herbal infusion not made from the tea plant."]],
  w:"Tea is one of humanity's most important drinks, shaping cultures, rituals, trade, and even wars.",
  src:["Tea","Camellia sinensis","The Classic of Tea","Japanese tea ceremony","History of tea","Bubble tea"],
  q:[["All true tea comes from which plant?","Camellia sinensis","Coffea arabica","Ilex paraguariensis","Aspalathus linearis"],
     ["What mainly distinguishes tea types?","Processing, especially oxidation","The plant species","The country only","Added flavors"],
     ["Who wrote 'The Classic of Tea'?","Lu Yu","Sen no Rikyū","Eisai","Shennong"],
     ["Who popularized tea at the English court after 1662?","Catherine of Braganza","Queen Victoria","Anna, Duchess of Bedford","Elizabeth I"],
     ["Who smuggled tea plants from China to India?","Robert Fortune","Joseph Banks","Charles Darwin","Thomas Lipton"],
     ["Bubble tea was invented in…","Taiwan","Japan","Hong Kong","Thailand"]]},

{ t:"Wine", s:"Grapes, terroir, and the art of tasting",
  sec:[
  ["An ancient drink",[
    "Wine is fermented grape juice. Yeasts convert the grapes' sugars into alcohol and carbon dioxide. The earliest chemical evidence of grape wine comes from Georgia, around 6000 BCE. Wine spread through the ancient Near East, Egypt, Greece, and Rome, where it became central to daily life, religion, and trade; the Romans planted vineyards across Europe, including in France, Spain, and Germany.",
    "Medieval monasteries preserved and developed viticulture; Cistercian monks in Burgundy mapped vineyards whose distinct qualities they observed, laying foundations for the concept of terroir. Most of the world's wine comes from the European grape species Vitis vinifera."]],
  ["Grapes and styles",[
    "Important red grapes include Cabernet Sauvignon (structured, blackcurrant, the backbone of Bordeaux's Left Bank), Merlot, Pinot Noir (delicate, the grape of red Burgundy), Syrah/Shiraz, Grenache, Tempranillo (Rioja), Sangiovese (Chianti), Nebbiolo (Barolo), and Malbec. Important white grapes include Chardonnay (white Burgundy and much else), Sauvignon Blanc, Riesling, Chenin Blanc, and Pinot Grigio/Gris.",
    "Red wine gets its color and tannins from fermenting with the grape skins; white wine is usually fermented without skins; rosé has brief skin contact; 'orange' wines are white grapes fermented with skins. Sparkling wines trap carbon dioxide: Champagne uses the traditional method (a second fermentation in the bottle); Prosecco usually uses the tank method. Fortified wines like port, sherry, and Madeira have added spirit."]],
  ["Terroir and the Old World",[
    "In the 'Old World' (Europe), wines are usually named by place (Bordeaux, Chablis, Rioja), and regulations, like France's Appellation d'Origine Contrôlée (AOC) system established in 1935, control grape varieties, yields, and methods. Burgundy's vineyards are classified down to individual plots (climats), with Grand Cru and Premier Cru levels; the Climats of Burgundy became a UNESCO World Heritage Site in 2015.",
    "Bordeaux's famous 1855 Classification ranked its top châteaux, with only one change since (Château Mouton Rothschild was promoted to first growth in 1973). Champagne, Burgundy, Bordeaux, the Rhône, the Loire, Piedmont, Tuscany, Rioja, the Douro, the Mosel, and Tokaj are among Europe's great regions."]],
  ["The New World",[
    "'New World' wines, from the Americas, Australia, New Zealand, South Africa, and elsewhere, are often labeled by grape variety. The 1976 'Judgment of Paris', a blind tasting organized by Steven Spurrier, in which California wines beat top French wines, boosted the reputation of New World wine.",
    "Major New World regions include California's Napa and Sonoma, Oregon (Pinot Noir), Washington, Argentina's Mendoza (Malbec), Chile, Australia's Barossa Valley (Shiraz), New Zealand's Marlborough (Sauvignon Blanc), and South Africa's Stellenbosch. In the late 19th century, the phylloxera aphid, accidentally imported from America, devastated European vineyards; the solution was grafting European vines onto resistant American rootstocks, still standard practice."]],
  ["Tasting wine",[
    "Wine tasting follows steps: look (color and clarity), swirl (to release aromas), smell, taste, and consider the finish (how long flavors last). Tasters describe sweetness, acidity, tannin (the drying sensation from skins and oak in reds), alcohol, body, and flavors, such as fruit, floral, herbal, earthy, and oak notes (vanilla, toast from oak barrels).",
    "Sommeliers are wine professionals who select, store, and serve wine in restaurants. The Court of Master Sommeliers' Master Sommelier diploma and the Institute of Masters of Wine's MW qualification are among the most difficult professional exams in the world, with only a few hundred holders each."]],
  ["Food and wine pairing",[
    "Pairing principles include matching weight (rich food with full-bodied wine), balancing acidity (acidic wines cut through fatty food and match acidic dishes), pairing sweet wines with desserts at least as sweet, using tannic reds with protein and fat (steak), and avoiding high-alcohol wines with spicy food, which amplifies heat. 'What grows together goes together': regional wines often suit regional foods.",
    "Wine is also an ingredient in cooking: deglazing, braising (coq au vin, boeuf bourguignon), and sauces. Cooking with wine one would not drink is generally discouraged, though it need not be expensive."]]
  ],
  terms:[["Vitis vinifera","The European grape species used for most wine."],["Tannin","Compounds from skins, seeds, and oak that create a drying sensation."],["Terroir","How place shapes a wine's character."],["Traditional method","Making sparkling wine with a second fermentation in the bottle."],["Phylloxera","An aphid that devastated European vineyards in the 19th century."],["Sommelier","A wine professional in a restaurant."]],
  w:"Wine connects agriculture, place, history, and pleasure, and understanding it enriches both cooking and dining.",
  src:["Wine","Terroir","Champagne (wine)","Judgment of Paris (wine)","Phylloxera","Sommelier"],
  q:[["Where is the earliest chemical evidence of grape wine?","Georgia, around 6000 BCE","France, around 500 BCE","Italy, around 1000 BCE","Egypt, around 100 CE"],
     ["Where does red wine's color come from?","Fermenting with grape skins","Added dye","Oak barrels","Red grape juice"],
     ["Which grape is the grape of red Burgundy?","Pinot Noir","Cabernet Sauvignon","Merlot","Syrah"],
     ["What happened at the 1976 Judgment of Paris?","California wines beat top French wines in a blind tasting","France banned American wine","Champagne was invented","Phylloxera was discovered"],
     ["How was the phylloxera crisis solved?","Grafting vines onto American rootstocks","Spraying pesticides","Moving vineyards to Asia","Using only white grapes"],
     ["Which château was promoted to first growth in 1973?","Mouton Rothschild","Lafite Rothschild","Margaux","Latour"]]},

{ t:"Beer", s:"Malt, hops, yeast, and water",
  sec:[
  ["An ancient beverage",[
    "Beer is among the oldest fermented drinks, brewed in Mesopotamia and Egypt thousands of years ago; Sumerian texts include a 'Hymn to Ninkasi', goddess of brewing, which contains a beer recipe. Egyptian workers received beer rations. Medieval European monasteries refined brewing, and beer was a safer daily drink than untreated water in many places.",
    "Hops, the flowers of the hop plant, became widely used in Europe from around the 13th–15th centuries, adding bitterness, aroma, and preservative qualities. Before hops, brewers used gruit, a mix of herbs."]],
  ["Ingredients and process",[
    "Beer has four main ingredients: water, malted grain (usually barley), hops, and yeast. Malting involves soaking and sprouting grain, then drying it with heat, which activates enzymes that convert starches to sugars. The degree of kilning affects color and flavor, from pale malts to dark roasted malts used in stouts.",
    "Brewing involves mashing (soaking crushed malt in hot water so enzymes convert starch to sugar), producing a sweet liquid called wort; boiling the wort with hops; cooling; fermenting with yeast; conditioning; and packaging. Water chemistry matters: Burton-upon-Trent's hard water suited pale ales, while Pilsen's soft water suited pale lagers."]],
  ["Ales and lagers",[
    "Beers are broadly divided into ales and lagers based on yeast. Ales use top-fermenting yeast (Saccharomyces cerevisiae) at warmer temperatures, producing fruity, complex flavors; styles include pale ales, India pale ales (IPAs), stouts, porters, wheat beers, Belgian ales, and saisons. Lagers use bottom-fermenting yeast (Saccharomyces pastorianus) at cooler temperatures and are conditioned cold for weeks (lager means 'storage' in German), producing clean, crisp beers like pilsners, helles, bocks, and most mass-market beers.",
    "Pilsner, first brewed in Plzeň (now in Czechia) in 1842 by Bavarian brewer Josef Groll, was the first golden lager and became the most imitated beer style in the world. Spontaneously fermented beers, such as Belgian lambics, use wild yeasts and bacteria from the air."]],
  ["Styles and history",[
    "Porter became popular among London's working people in the 18th century, and stouts were stronger porters; Guinness, founded in Dublin in 1759 by Arthur Guinness (who signed a 9,000-year lease), became famous for its dry stout. India pale ale was brewed in England for export to British India, with extra hops, though historians debate how special it originally was.",
    "Industrialization, refrigeration (Carl von Linde's refrigeration machines in the 1870s were developed partly for breweries), and Louis Pasteur's studies of fermentation transformed brewing. In 1883, Emil Christian Hansen at the Carlsberg laboratory isolated a pure yeast culture, revolutionizing lager consistency."]],
  ["The craft beer revolution",[
    "In the 20th century, consolidation and Prohibition (1920–1933) in the United States left a few large breweries making light lagers. From the late 1970s, after the US legalized home brewing in 1978, a craft beer movement emerged, with pioneers like Anchor Brewing (revived by Fritz Maytag), Sierra Nevada (1980), and others. The US went from under a hundred breweries in the late 1970s to more than nine thousand by the 2020s.",
    "Craft brewing spread worldwide, reviving historic styles and inventing new ones like hazy New England IPAs and pastry stouts. In Britain, the Campaign for Real Ale (CAMRA), founded in 1971, championed traditional cask ale."]],
  ["Beer and food",[
    "Beer pairs well with many foods: its carbonation cleanses the palate, bitterness cuts fat, and malt sweetness can balance spice. Classic pairings include stouts with oysters, IPAs with spicy foods, Belgian beers with mussels, and wheat beers with salads and seafood.",
    "Beer is also used in cooking: beer-battered fish, Belgian carbonnade, beer bread, and braises. Serving beer at the right temperature and in appropriate glassware enhances its aroma and flavor."]]
  ],
  terms:[["Malt","Grain that has been sprouted and dried to develop enzymes and flavor."],["Wort","The sweet liquid produced by mashing malt, before fermentation."],["Hops","Flowers that add bitterness, aroma, and preservation to beer."],["Ale","Beer made with top-fermenting yeast at warmer temperatures."],["Lager","Beer made with bottom-fermenting yeast and cold conditioning."],["Craft beer","Beer from small, independent breweries emphasizing flavor and variety."]],
  w:"Beer is one of humanity's oldest drinks and a rich field of craft, history, and food pairing.",
  src:["Beer","Brewing","Hops","Lager","Pilsner","Craft beer"],
  q:[["Who was Ninkasi?","The Sumerian goddess of brewing","An Egyptian queen","A Belgian monk","A German brewer"],
     ["What is wort?","The sweet liquid from mashing malt","Fermented beer","A type of hop","Brewing yeast"],
     ["What does 'lager' mean in German?","Storage","Light","Gold","Cold"],
     ["The first golden lager was brewed in Plzeň in…","1842","1516","1759","1978"],
     ["When did the US legalize home brewing?","1978","1933","1920","2000"],
     ["Who isolated a pure brewing yeast culture at Carlsberg in 1883?","Emil Christian Hansen","Louis Pasteur","Carl von Linde","Josef Groll"]]},

{ t:"Spirits and Cocktails", s:"Distillation and the art of mixing",
  sec:[
  ["Distillation",[
    "Spirits are made by distilling a fermented liquid: heating it so that alcohol, which boils at about 78°C (lower than water), vaporizes, and then condensing the vapor to concentrate the alcohol. Distillation was used in antiquity for perfumes and medicines; Islamic-era scholars refined the alembic still, and the word 'alcohol' derives from Arabic (al-kuḥl). By the medieval period, European monks and physicians were distilling 'aqua vitae' (water of life).",
    "Two main types of still exist: pot stills, used in batches, producing fuller-flavored spirits (like single malt whisky and cognac); and column (continuous) stills, patented by Aeneas Coffey in 1830, producing lighter, purer spirits efficiently. Many spirits are aged in wooden barrels, which add color, flavor (vanilla, spice, toast), and smoothness."]],
  ["Grain and grape spirits",[
    "Whisky (whiskey in Ireland and the US) is distilled from fermented grain mash. Scotch whisky must be aged at least three years in oak in Scotland; single malt is made from malted barley at a single distillery, often in pot stills, with regional styles like smoky Islay whiskies (from peat-dried malt). Irish whiskey is typically triple distilled. American bourbon must be made from at least 51% corn and aged in new charred oak containers; Tennessee whiskey is filtered through maple charcoal. Japanese whisky has won international acclaim since the early 2000s.",
    "Brandy is distilled from wine or fruit. Cognac and Armagnac are French grape brandies with protected status; calvados is apple brandy from Normandy. Pisco (Peru and Chile), grappa (from grape pomace in Italy), and eaux-de-vie (clear fruit brandies like kirsch) are other examples."]],
  ["Clear and cane spirits",[
    "Vodka, from Russia and Poland (both claim it), is distilled to high purity and often filtered, making it neutral in flavor. Gin is a neutral spirit flavored with botanicals, primarily juniper; it evolved from Dutch genever, and London dry gin is a style. The 18th-century 'Gin Craze' in London caused social problems, depicted in William Hogarth's print 'Gin Lane' (1751).",
    "Rum is distilled from sugarcane products, mainly molasses, or fresh cane juice (rhum agricole in the French Caribbean); cachaça is Brazil's cane spirit. Tequila is distilled from blue agave in designated regions of Mexico (mainly Jalisco); mezcal can be made from many agave species, often roasting the agave hearts in earthen pits for a smoky flavor. East Asian spirits include Chinese baijiu (the world's most consumed spirit by volume, made from sorghum and other grains), Japanese shōchū, and Korean soju."]],
  ["Liqueurs and aperitifs",[
    "Liqueurs are sweetened spirits flavored with fruits, herbs, spices, nuts, or cream: Grand Marnier, Cointreau, Chartreuse (made by Carthusian monks since the 18th century from a secret recipe of 130 herbs), Bénédictine, amaretto, limoncello, and coffee liqueurs. Bitters are concentrated herbal infusions used in small amounts, such as Angostura bitters (created in Venezuela in 1824).",
    "Aperitifs and digestifs, like vermouth (fortified, aromatized wine), Campari, Aperol, and Italian amari, stimulate appetite before meals or aid digestion afterward. The Italian aperitivo culture, with drinks like the Aperol spritz and Negroni accompanied by snacks, has spread worldwide."]],
  ["Cocktails",[
    "A cocktail combines spirits with other ingredients. The term appeared in print in 1806 in a New York newspaper, defining it as spirits, sugar, water, and bitters, essentially the Old Fashioned. Jerry Thomas published the first bartender's guide in 1862. Classic cocktails include the martini (gin and vermouth), Manhattan (whiskey and sweet vermouth), daiquiri (rum, lime, sugar), margarita (tequila, lime, orange liqueur), Negroni (gin, Campari, sweet vermouth), and mojito.",
    "Prohibition in the US (1920–1933) sent bartenders abroad and spurred cocktails that masked poor-quality spirits. The 21st-century 'cocktail renaissance' revived classic techniques, fresh juices, and house-made syrups. Key techniques include shaking (for drinks with juice, cream, or egg), stirring (for spirit-forward drinks, for clarity and texture), building in the glass, and muddling."]],
  ["Responsible enjoyment",[
    "Alcohol has deep cultural roots in celebration and hospitality, but excessive drinking causes serious harm. Health authorities, including the WHO, warn of risks such as liver disease, several cancers, and accidents, and recent guidance in several countries has lowered recommended drinking limits. Non-alcoholic cocktails ('mocktails' or zero-proof drinks) and low-alcohol options have become increasingly sophisticated and popular.",
    "In the professional world, bartenders and sommeliers are trained to serve responsibly, and knowledge of spirits and cocktails is part of hospitality careers."]]
  ],
  terms:[["Distillation","Heating and condensing a fermented liquid to concentrate alcohol."],["Pot still","A batch still producing fuller-flavored spirits."],["Column still","A continuous still producing lighter spirits efficiently."],["Bourbon","American whiskey of at least 51% corn, aged in new charred oak."],["Botanicals","Herbs and spices flavoring gin, especially juniper."],["Bitters","Concentrated herbal infusions used in small amounts."]],
  w:"Spirits and cocktails are a craft with deep history, important for anyone working in hospitality.",
  src:["Distilled beverage","Distillation","Whisky","Gin","Tequila","Cocktail"],
  q:[["Why does distillation concentrate alcohol?","Alcohol boils at a lower temperature than water","Water freezes first","Alcohol is heavier","Yeast is removed"],
     ["Who patented the column still in 1830?","Aeneas Coffey","Louis Pasteur","Jerry Thomas","Arthur Guinness"],
     ["Bourbon must be made from at least what percentage of corn?","51%","10%","90%","100%"],
     ["Gin is flavored primarily with…","Juniper","Agave","Anise","Vanilla"],
     ["Which is the world's most consumed spirit by volume?","Baijiu","Vodka","Whisky","Rum"],
     ["The first bartender's guide was published in 1862 by…","Jerry Thomas","Harry Craddock","Dale DeGroff","Ernest Hemingway"]]},

{ t:"Chocolate, Soft Drinks, and Other Beverages", s:"Drinks beyond coffee, tea, and alcohol",
  sec:[
  ["Water and its importance",[
    "Water is the most essential drink and a key ingredient in cooking. Its mineral content (hardness) affects the taste of coffee, tea, and beer, the texture of cooked beans, and bread dough. Mineral waters from springs, such as those from Evian, San Pellegrino, and Vichy, have been prized for centuries, and spa towns grew around them.",
    "Access to clean drinking water remains a global challenge; according to WHO and UNICEF, around two billion people still lacked safely managed drinking water services in the early 2020s."]],
  ["Hot chocolate",[
    "Cacao was drunk in Mesoamerica for thousands of years; the Maya and Aztecs prepared frothy drinks of ground cacao with water, chili, vanilla, and maize, poured from a height to create foam. The Aztec ruler Moctezuma was reputed to drink large quantities. Spanish colonizers adopted chocolate, adding sugar and cinnamon, and it became a fashionable drink at European courts in the 17th century.",
    "Today, hot chocolate traditions include thick Spanish chocolate with churros, Mexican chocolate whipped with a wooden molinillo, Italian cioccolata calda, and Swiss and Belgian hot chocolates. Champurrado is a Mexican chocolate drink thickened with masa."]],
  ["Soft drinks",[
    "Carbonated water was created artificially by Joseph Priestley in 1767, and Johann Jacob Schweppe founded his company in Geneva in 1783. Pharmacists in the 19th century sold flavored soda waters as tonics. Coca-Cola was created by pharmacist John Stith Pemberton in Atlanta in 1886, originally containing extracts of coca leaf and kola nut; Pepsi followed in 1893. Ginger ale, root beer, and tonic water (with quinine, originally an antimalarial) became popular.",
    "Soft drinks became global brands, but high sugar consumption has raised health concerns. Many countries, including Mexico (2014) and the United Kingdom (2018), have introduced taxes on sugary drinks, which studies suggest have reduced purchases."]],
  ["Fermented and traditional drinks",[
    "Many cultures have traditional non-alcoholic or low-alcohol fermented drinks: kombucha (fermented sweetened tea with a culture of bacteria and yeast, SCOBY), kefir and lassi (from milk), kvass (fermented rye bread drink, Eastern Europe), tepache (fermented pineapple, Mexico), ginger beer, and switchel.",
    "Plant-based traditional drinks include horchata (Spanish horchata de chufa from tiger nuts; Mexican horchata from rice and cinnamon), agua fresca, Indian nimbu pani and jaljeera, sugarcane juice, coconut water, and hibiscus drinks (agua de jamaica, bissap in West Africa, sorrel in the Caribbean)."]],
  ["Other infusions",[
    "Yerba mate, from a South American holly, is the national drink of Argentina, Uruguay, and Paraguay. Rooibos (red bush) from South Africa is caffeine-free. Guayusa, guaraná, and cacao husk infusions have also gained popularity. Herbal teas like chamomile, mint, and hibiscus are enjoyed worldwide.",
    "Milk and plant milks are also important drinks; plant-based milks from soy, oats, almonds, and rice have grown greatly, with oat milk rising rapidly in popularity in coffee shops since the late 2010s."]],
  ["Drinks in the kitchen",[
    "Understanding drinks helps cooks plan menus, pairings, and hospitality. Non-alcoholic pairings, using teas, juices, shrubs (drinking vinegars), and fermented drinks, are increasingly offered in fine restaurants alongside wine.",
    "Drinks also feature in cooking: tea-smoked duck, coffee rubs for meat, chocolate in mole, and soda in braises and cakes. A well-rounded cook knows the world of beverages as well as food."]]
  ],
  terms:[["Water hardness","The mineral content of water, affecting flavor and cooking."],["Molinillo","A wooden whisk for frothing Mexican chocolate."],["Kombucha","Fermented sweetened tea."],["SCOBY","Symbiotic culture of bacteria and yeast used to make kombucha."],["Horchata","A drink made from tiger nuts or rice."],["Shrub","A drinking vinegar used in beverages."]],
  w:"Drinks beyond coffee, tea, and alcohol have rich histories and are increasingly important in modern menus.",
  src:["Hot chocolate","Soft drink","Coca-Cola","Kombucha","Horchata","Sugary drink tax"],
  q:[["Who created artificial carbonated water in 1767?","Joseph Priestley","John Pemberton","Johann Schweppe","Louis Pasteur"],
     ["Coca-Cola was created in which city in 1886?","Atlanta","New York","Chicago","New Orleans"],
     ["What is a molinillo used for?","Frothing Mexican chocolate","Grinding coffee","Brewing tea","Making tortillas"],
     ["Kombucha is…","Fermented sweetened tea","Fermented milk","Fermented rye bread","Fermented pineapple"],
     ["Spanish horchata de chufa is made from…","Tiger nuts","Rice","Almonds","Oats"],
     ["Tonic water originally contained quinine as…","An antimalarial","A sweetener","A preservative","A colorant"]]}

]});


/* ---- from cuisine-18.js ---- */
/* CUISINE FOUNDATIONS, part 18: Unit 10 The World of Food, chapters 1-5 */
COURSES.cuisine.units.push({ t:"The World of Food", ch:[

{ t:"The Restaurant Business", s:"How restaurants work",
  sec:[
  ["Types of restaurants",[
    "Restaurants range from street stalls and food trucks to quick-service (fast food), fast-casual (like counter-service chains with higher-quality ingredients), casual dining, fine dining, and specialized concepts like tasting-menu restaurants, ghost kitchens (delivery-only kitchens), and pop-ups. Each model has different costs, staffing, service styles, and margins.",
    "Restaurants are part of the broader hospitality industry, along with hotels, catering, bars, and institutional food service (schools, hospitals, corporate cafeterias, airlines), which employs many cooks."]],
  ["The economics",[
    "Restaurants are notoriously difficult businesses with thin profit margins, often in the low single digits as a percentage of revenue for full-service restaurants. Major costs are often summarized as 'prime cost': food and beverage costs plus labor costs, together commonly targeted at around 60–65% of sales. Rent, utilities, equipment, insurance, marketing, and repairs take much of the rest.",
    "Food cost percentage is calculated by dividing the cost of ingredients by the menu price; beverage programs, especially alcohol, typically have higher margins and are crucial to profitability. Many new restaurants close within their first few years, though the oft-quoted claim that 90% fail in the first year is an exaggeration according to research."]],
  ["Front and back of house",[
    "Restaurants are divided into the back of house (BOH), the kitchen staff led by the chef, including sous-chefs, line cooks, prep cooks, and dishwashers (often called the backbone of the kitchen), and the front of house (FOH), the service staff led by a general manager or maître d', including hosts, servers, bartenders, sommeliers, runners, and bussers.",
    "Communication between them happens through point-of-sale (POS) systems that send tickets to the kitchen, and through the pass, where the expediter checks dishes. Good restaurants depend on teamwork between the two sides."]],
  ["Operations",[
    "Running a restaurant involves purchasing (relationships with suppliers, farmers, and distributors), receiving and storing deliveries, inventory control, prep lists, menu costing, scheduling staff, maintaining equipment, and complying with health, safety, labor, and licensing regulations.",
    "Reservations systems, online reviews, delivery platforms, and social media have transformed how restaurants attract and serve customers. Delivery apps expanded dramatically during the COVID-19 pandemic, which also forced many restaurants to close and others to reinvent themselves with takeout and outdoor dining."]],
  ["Labor and culture",[
    "Restaurant work is demanding, with long hours, physical strain, heat, and pressure, and often modest pay. In the US, tipped workers can be paid a lower minimum wage, an arrangement debated widely; some restaurants have adopted 'hospitality included' pricing or service charges instead of tipping. In many other countries, service is included in prices.",
    "The industry has faced reckonings over abusive kitchen cultures, harassment, substance abuse, and mental health. Many chefs now emphasize healthier workplaces, reasonable hours, and better pay. Immigrant workers form a large share of the restaurant workforce in many countries."]],
  ["Starting a restaurant",[
    "Opening a restaurant requires a concept, a business plan, financing, a location, design, permits, equipment, staff hiring and training, menu development, and marketing. Location, concept clarity, consistent quality, cost control, and hospitality are commonly cited as keys to success.",
    "Many chefs begin with lower-risk ventures, such as pop-ups, market stalls, food trucks, or catering, to test concepts and build a following before opening a full restaurant."]]
  ],
  terms:[["Prime cost","Food, beverage, and labor costs combined."],["Food cost percentage","Ingredient cost divided by menu price."],["Back of house","The kitchen and its staff."],["Front of house","The dining room and service staff."],["Ghost kitchen","A delivery-only commercial kitchen."],["POS system","Point-of-sale system for orders and payments."]],
  w:"Understanding restaurant economics and operations is essential for anyone hoping to work in or open a restaurant.",
  src:["Restaurant","Restaurant management","Food cost","Ghost kitchen","Front of house","Hospitality industry"],
  q:[["What is 'prime cost' in a restaurant?","Food, beverage, and labor costs combined","The rent","The price of the best dish","The owner's salary"],
     ["How is food cost percentage calculated?","Ingredient cost divided by menu price","Menu price divided by rent","Labor divided by sales","Profit divided by costs"],
     ["Who works in the back of house?","Kitchen staff","Servers and hosts","Bartenders only","Customers"],
     ["What is a ghost kitchen?","A delivery-only kitchen","A haunted restaurant","A closed restaurant","A pop-up"],
     ["Is it true that 90% of restaurants fail in the first year?","No, research shows this is an exaggeration","Yes, exactly","Yes, in all countries","Only fine dining fails"],
     ["Why are beverage programs important to restaurants?","They typically have higher profit margins","They are required by law","They are free","They attract inspectors"]]},

{ t:"Hospitality and Service", s:"Making guests feel cared for",
  sec:[
  ["What hospitality means",[
    "Hospitality is the art of making people feel welcome and cared for. Restaurateur Danny Meyer, founder of Union Square Hospitality Group, distinguishes service, the technical delivery of a product, from hospitality, how the delivery makes the recipient feel. In his book 'Setting the Table' (2006), he argued that hospitality is the key to business success.",
    "Will Guidara, former co-owner of Eleven Madison Park, which topped the World's 50 Best Restaurants list in 2017, describes 'unreasonable hospitality': going far beyond expectations to create memorable experiences, like surprising guests with personalized gestures."]],
  ["Service styles",[
    "Restaurants use different service styles. American service has plates assembled in the kitchen and carried to tables. French service (in the classical sense) involves food finished or served from a cart (guéridon) beside the table, as in carving or flambéing. Russian service involves servers presenting platters and serving portions to each guest. Family-style service places shared dishes on the table; buffet service lets guests serve themselves.",
    "Classic fine-dining service rules include serving food from the left and clearing from the right (conventions vary), serving women and older guests first in traditional settings, clearing plates only when all guests at a table have finished, and never reaching across a guest."]],
  ["The dining room",[
    "Front-of-house staff manage reservations, greet guests, seat them thoughtfully, explain menus, take orders, time courses, handle wine service, address complaints, and present the bill. Servers must know the menu deeply, including ingredients and allergens, and communicate accurately with the kitchen.",
    "Ambience, the lighting, music, noise level, table spacing, temperature, and décor, strongly influences the guest's experience. Many restaurants have grown louder due to hard surfaces in modern design, prompting complaints; acoustic treatment can improve comfort."]],
  ["Handling problems",[
    "Problems inevitably occur: a dish arrives wrong, a reservation is lost, a guest has an allergic reaction or is unhappy. Good hospitality responds quickly, listens, apologizes sincerely, and fixes the problem, often going further to restore goodwill. Many hospitality professionals believe that a well-handled problem can create a more loyal guest than an experience with no problems.",
    "Allergies and dietary needs require careful systems: recording them at booking, flagging them on tickets, preventing cross-contact in the kitchen, and confirming dishes before serving."]],
  ["Hospitality at home",[
    "Hospitality applies equally at home. Hosting well means planning a menu suited to guests and to your skill, preparing as much as possible in advance, setting a welcoming table, considering dietary needs, and spending time with guests rather than in the kitchen. The French concept of convivialité and the Italian tradition of long Sunday lunches show that the social experience matters as much as the food.",
    "Across cultures, sharing food is a fundamental act of welcome, from the Arab tradition of coffee and dates to Central Asian dastarkhan, the Georgian supra, and the Sikh langar."]],
  ["Careers in hospitality",[
    "Front-of-house careers include server, captain, maître d', sommelier, bartender, general manager, and restaurant director. Hotels offer roles in food and beverage management, banqueting, and room service. Hospitality management programs, such as those at École hôtelière de Lausanne (founded in 1893) and Cornell's Nolan School of Hotel Administration (founded 1922), train future leaders.",
    "Skills include communication, empathy, attention to detail, calm under pressure, product knowledge, and teamwork. Hospitality is a craft as demanding and rewarding as cooking."]]
  ],
  terms:[["Hospitality","How service makes guests feel welcome and cared for."],["Guéridon","A service cart used for tableside preparation."],["Family-style service","Shared dishes placed on the table for guests to serve themselves."],["Maître d'","The head of the dining room."],["Ambience","The atmosphere of a dining space."],["Convivialité","The French ideal of warm, lively social dining."]],
  w:"Hospitality, how food is served and how guests feel, is as important to a great meal as the cooking itself.",
  src:["Hospitality","Danny Meyer","Table service","Maître d'hôtel","Eleven Madison Park","École hôtelière de Lausanne"],
  q:[["How does Danny Meyer distinguish hospitality from service?","Service is delivery; hospitality is how it makes guests feel","They are the same","Hospitality is only for hotels","Service is free; hospitality costs extra"],
     ["Who wrote about 'unreasonable hospitality'?","Will Guidara","Thomas Keller","Gordon Ramsay","Escoffier"],
     ["In family-style service…","Shared dishes are placed on the table","Waiters carve at the table","Guests serve themselves from a buffet line","Plates come pre-assembled"],
     ["What is a guéridon?","A service cart for tableside preparation","A type of wine glass","A dining room manager","A sauce"],
     ["A well-handled problem can…","Create a more loyal guest","Never be fixed","Always cause a complaint","Close a restaurant"],
     ["Which famous hospitality school was founded in 1893?","École hôtelière de Lausanne","Le Cordon Bleu","Culinary Institute of America","Cornell"]]},

{ t:"Menus, Plating, and the Meal", s:"Designing what people eat",
  sec:[
  ["Building a menu",[
    "A menu expresses a restaurant's identity and must balance creativity, cost, kitchen capacity, seasonality, and guests' expectations. Good menus offer variety in ingredients, cooking methods, textures, and price points, while ensuring each station in the kitchen can execute its dishes efficiently during service.",
    "Menu engineering analyzes each dish's popularity and profitability. Dishes are sometimes classified as 'stars' (popular and profitable), 'plowhorses' (popular, less profitable), 'puzzles' (profitable but unpopular), and 'dogs' (neither). Menu design, such as placement, descriptions, and the absence of currency symbols, can influence choices."]],
  ["Types of menus",[
    "À la carte menus let guests choose individual dishes priced separately. Prix fixe (fixed-price) menus offer a set number of courses for one price, often with choices. Tasting menus (dégustation) present many small courses chosen by the chef, sometimes with wine pairings. Table d'hôte is a traditional fixed menu. Cyclical menus, common in institutions, rotate over a set period.",
    "Seasonal menus change with available produce, and many restaurants change daily based on markets. The Japanese omakase ('I leave it to you') lets the chef decide."]],
  ["Composing a dish",[
    "A well-composed dish has balance and contrast: a main element, complementary components, a sauce, and garnishes that add color, texture, and flavor. Chefs consider the 'flavor bridge', ingredients that connect different elements, and the progression of tastes on the palate.",
    "Flavor pairing can draw on tradition (tomato and basil, lamb and rosemary, pork and apple) or on analysis; the 'food pairing' hypothesis suggests ingredients sharing aroma compounds may combine well, though research shows the theory fits Western cuisines better than many East Asian ones, which often contrast flavors."]],
  ["Plating",[
    "Plating, the arrangement of food on the plate, affects how food is perceived. Principles include balance, using the plate's negative space, varying height and texture, using odd numbers of elements, and making colors contrast. Classic plating placed the protein at the front (six o'clock) with starch and vegetables behind; modern plating is freer, sometimes asymmetric or scattered.",
    "Plates matter too: white plates highlight color; size and shape frame the food. Research by psychologists like Charles Spence has shown that plate color, weight of cutlery, and even background music affect perceived flavor. Food should be served at the right temperature, with hot plates for hot food."]],
  ["The structure of meals",[
    "Meal structures vary across cultures. Western formal meals progress through courses: appetizer, soup, fish, meat, salad, cheese, dessert. Chinese banquets serve many dishes in waves, sharing across the table. Japanese kaiseki follows a seasonal sequence of small courses. Indian thalis present everything at once. Ethiopian meals share a single platter of injera.",
    "Understanding these structures helps chefs design menus and helps diners appreciate different cultures' ideas of a complete, balanced meal."]],
  ["Menu writing and ethics",[
    "Menu descriptions should be accurate and appealing. Truth-in-menu laws in some places prohibit misrepresenting ingredients, origins, or preparation methods, and seafood fraud, mislabeling cheaper fish as more expensive species, has been documented in studies in many countries.",
    "Allergen information, calorie labeling (required for chains in some countries, such as the US since 2018 and England since 2022), and clear pricing are increasingly expected. Menus also communicate a restaurant's values, such as naming farms and producers."]]
  ],
  terms:[["Menu engineering","Analyzing dishes' popularity and profitability to optimize a menu."],["À la carte","Dishes ordered and priced individually."],["Prix fixe","A set menu at a fixed price."],["Tasting menu","A sequence of many small courses chosen by the chef."],["Omakase","'I leave it to you': chef's choice in Japanese dining."],["Plating","Arranging food on the plate."]],
  w:"Designing menus and plates turns cooking into a coherent experience for the diner.",
  src:["Menu","Menu engineering","Tasting menu","Omakase","Food presentation","Charles Spence"],
  q:[["In menu engineering, what is a 'star'?","A popular and profitable dish","An unpopular dish","A cheap dish","A dessert"],
     ["What is a prix fixe menu?","A set menu at a fixed price","Dishes priced individually","A wine list","A children's menu"],
     ["What does 'omakase' mean?","I leave it to you","Thank you","Delicious","Raw fish"],
     ["The food pairing hypothesis fits which cuisines better?","Western cuisines","East Asian cuisines","All equally","None"],
     ["Who has researched how plates and music affect perceived flavor?","Charles Spence","Harold McGee","Hervé This","Ferran Adrià"],
     ["What is seafood fraud?","Mislabeling cheaper fish as more expensive species","Overcooking fish","Fishing without a license","Serving raw fish"]]},

{ t:"Becoming a Cook", s:"Training, careers, and the path to mastery",
  sec:[
  ["Paths into cooking",[
    "Professional cooks enter the field through culinary schools, apprenticeships, or working their way up in kitchens. Famous culinary schools include Le Cordon Bleu (founded in Paris in 1895), the Culinary Institute of America (founded in 1946 in New Haven, later moved to Hyde Park, New York), Institut Paul Bocuse in Lyon, and the Basque Culinary Center in San Sebastián, which offers university degrees in gastronomy.",
    "Many great chefs trained mainly through apprenticeship and work experience, starting as dishwashers or prep cooks. In Europe, formal apprenticeship systems combine school and paid work. 'Staging' (from the French stagiaire, 'intern'), working briefly in a restaurant kitchen, often unpaid, to learn or try out, is a common practice, though unpaid stages have been criticized."]],
  ["The kitchen hierarchy as a career",[
    "A typical kitchen career progresses from commis or prep cook to line cook (chef de partie), then sous-chef, chef de cuisine (head chef), and executive chef, who may oversee multiple kitchens and business operations. Pastry has its own track. Advancement depends on skill, speed, reliability, leadership, and creativity.",
    "Chefs increasingly need business skills: costing, staffing, management, marketing, and finance. Many also become restaurant owners, consultants, product developers, private chefs, caterers, or teachers."]],
  ["Skills to master",[
    "Essential skills include knife work, stocks and sauces, cooking proteins and vegetables precisely, baking basics, seasoning, mise en place, sanitation, and speed with consistency. Tasting constantly and developing a refined palate are key. Professionals also learn to read and scale recipes, manage time, and work as part of a team under pressure.",
    "Mastery takes years. The idea of '10,000 hours' to mastery, popularized by Malcolm Gladwell, is an oversimplification of research, but cooking clearly rewards deliberate practice, repetition, and learning from mistakes."]],
  ["Other food careers",[
    "The food world offers many careers beyond restaurant kitchens: food science and product development, research chef (combining culinary arts and food science), nutrition and dietetics, food writing and photography, food styling for media, recipe development and testing, culinary tourism, agriculture and farming, butchery, cheesemaking, baking, brewing and winemaking, and food policy.",
    "Institutional food service, such as hospital, school, and corporate dining, employs many chefs with more regular hours. Private chefs cook for households, and personal chefs prepare meals for clients."]],
  ["Certification and competitions",[
    "Certifications exist in many countries, such as the American Culinary Federation's certifications or national vocational qualifications in Europe. France's 'Meilleur Ouvrier de France' (MOF) title, awarded after grueling competitions, is among the most prestigious, entitling winners to wear a tricolor collar.",
    "Culinary competitions include the Bocuse d'Or (founded by Paul Bocuse in 1987, held in Lyon), considered the most prestigious international cooking competition, and pastry competitions like the Coupe du Monde de la Pâtisserie. Television competitions have popularized cooking as entertainment."]],
  ["Learning as a home cook",[
    "Home cooks can follow a similar path: master basic techniques, cook regularly, learn from good cookbooks and teachers, taste widely, and explore cuisines. Classic teaching books include Julia Child's 'Mastering the Art of French Cooking', Marcella Hazan's 'Essentials of Classic Italian Cooking', Madhur Jaffrey's books on Indian cooking, J. Kenji López-Alt's 'The Food Lab', and Samin Nosrat's 'Salt, Fat, Acid, Heat'.",
    "Cooking classes, travel, and cooking with family members who hold traditional knowledge are invaluable. The most important habit is to cook often, taste carefully, and stay curious."]]
  ],
  terms:[["Stage","A short, often unpaid internship in a restaurant kitchen."],["Commis","A junior cook in a kitchen."],["Executive chef","A chef overseeing kitchens and business operations."],["MOF","Meilleur Ouvrier de France, a prestigious French craft title."],["Bocuse d'Or","A prestigious international cooking competition held in Lyon."],["Research chef","A professional combining culinary arts and food science."]],
  w:"Knowing the paths, skills, and standards of the profession helps anyone serious about cooking plan their growth.",
  src:["Chef","Culinary art","Le Cordon Bleu","Culinary Institute of America","Bocuse d'Or","Meilleur Ouvrier de France"],
  q:[["When and where was Le Cordon Bleu founded?","Paris, 1895","New York, 1946","Lyon, 1987","London, 1900"],
     ["What is 'staging' in a kitchen?","A short, often unpaid internship","Plating food","Cooking on a stage","Preparing sauces"],
     ["Who oversees multiple kitchens and business operations?","The executive chef","The commis","The dishwasher","The sommelier"],
     ["What do MOF winners wear?","A tricolor collar","A gold medal","A red hat","A blue apron"],
     ["Where is the Bocuse d'Or held?","Lyon","Paris","New York","Tokyo"],
     ["Who wrote 'The Food Lab'?","J. Kenji López-Alt","Marcella Hazan","Madhur Jaffrey","Julia Child"]]},

{ t:"Food Writing, Media, and Criticism", s:"How we talk about food",
  sec:[
  ["A long tradition",[
    "Writing about food is ancient, from Archestratus's gastronomic poem and Apicius's recipes to medieval cookbooks. Brillat-Savarin's 'The Physiology of Taste' (1825) established the food essay; Grimod de La Reynière's 'Almanach des gourmands' (from 1803) pioneered restaurant criticism.",
    "Cookbooks have shaped national cuisines and home cooking: Hannah Glasse's 'The Art of Cookery Made Plain and Easy' (1747), Isabella Beeton's 'Book of Household Management' (1861), Fannie Farmer's 'Boston Cooking-School Cook Book' (1896), which popularized standardized measurements, and 'Joy of Cooking' (1931) by Irma Rombauer."]],
  ["Great food writers",[
    "M.F.K. Fisher, in books like 'The Gastronomical Me' (1943), wrote about food as a way of writing about hunger, love, and life. Elizabeth David's 'A Book of Mediterranean Food' (1950) brought sunshine to rationed Britain. Claudia Roden documented Middle Eastern and Jewish food; Madhur Jaffrey introduced Indian food to Western home cooks; Diana Kennedy documented regional Mexican cooking over decades.",
    "Other influential writers include A.J. Liebling, Calvin Trillin, Ruth Reichl (editor of Gourmet), Anthony Bourdain ('Kitchen Confidential'), Michael Pollan, and Jonathan Gold, the first food critic to win a Pulitzer Prize for Criticism, in 2007, celebrated for championing Los Angeles's immigrant restaurants."]],
  ["Restaurant criticism",[
    "Restaurant critics visit anonymously, often multiple times, pay their own bills, and evaluate food, service, ambience, and value. Influential critics, such as those at The New York Times, have long been able to make or break restaurants. Star rating systems vary by publication.",
    "The rise of online review platforms like Yelp (founded 2004) and TripAdvisor, and later social media, democratized criticism but raised concerns about fake reviews, unfair ratings, and the decline of professional criticism. Guides like Michelin and the World's 50 Best are both celebrated and criticized for their influence."]],
  ["Television, video, and social media",[
    "Food television evolved from instructional shows (James Beard's 'I Love to Eat' in 1946, Julia Child's 'The French Chef') to entertainment, competition shows ('Iron Chef', 'MasterChef', 'Top Chef'), travel documentaries (Bourdain's 'No Reservations' and 'Parts Unknown'), and documentaries like 'Chef's Table'.",
    "YouTube, Instagram, and TikTok have made food creators into major influences on what people cook and eat, with viral recipes like feta pasta in 2021. Food photography and styling are professions in themselves, using natural light, careful composition, and props."]],
  ["Recipe writing",[
    "Good recipes are clear and reliable: a descriptive headnote, a complete ingredient list in order of use with precise quantities (ideally including weights), numbered steps with times and sensory cues ('until golden and fragrant'), yield, and notes on substitutions or storage. Recipe testing in different kitchens ensures they work.",
    "Recipes themselves cannot generally be copyrighted as lists of ingredients in many legal systems, but the descriptive text and creative expression can be. Ethical food writers credit sources and the cultures and cooks behind dishes."]],
  ["Writing about food responsibly",[
    "Contemporary food writing pays increasing attention to whose stories are told, cultural context, labor, sustainability, and appropriation. Writers from many backgrounds now document their own food traditions, correcting older accounts that exoticized or misrepresented cuisines.",
    "Good food writing combines sensory description, history, culture, and personal experience. It helps readers understand not just what food tastes like but what it means."]]
  ],
  terms:[["Food writing","Writing about food, cooking, and eating, from recipes to essays."],["Headnote","The introduction to a recipe."],["Restaurant critic","A writer who evaluates restaurants, usually anonymously."],["Food styling","Preparing food to look appealing for photography or film."],["Recipe testing","Trying recipes repeatedly to ensure they work reliably."]],
  w:"Food writing, criticism, and media shape how we cook, where we eat, and how we understand food's meaning.",
  src:["Food writing","M. F. K. Fisher","Elizabeth David","Jonathan Gold","Restaurant rating","Food photography"],
  q:[["Who pioneered restaurant criticism with the 'Almanach des gourmands'?","Grimod de La Reynière","Brillat-Savarin","Escoffier","Carême"],
     ["Which cookbook popularized standardized measurements in 1896?","Fannie Farmer's 'Boston Cooking-School Cook Book'","'Joy of Cooking'","Mrs Beeton's book","Hannah Glasse's book"],
     ["Who was the first food critic to win a Pulitzer Prize?","Jonathan Gold","Ruth Reichl","Anthony Bourdain","M.F.K. Fisher"],
     ["Who wrote 'A Book of Mediterranean Food' (1950)?","Elizabeth David","Claudia Roden","Julia Child","Marcella Hazan"],
     ["What makes a good recipe?","Clear quantities, ordered ingredients, steps with sensory cues","Only a photo","Vague instructions","No quantities"],
     ["Are ingredient lists generally copyrightable?","Generally not in many legal systems","Always","Only in France","Only for desserts"]]}

]});


/* ---- from cuisine-19.js ---- */
/* CUISINE FOUNDATIONS, part 19: Unit 10 The World of Food, chapters 6-10 */
COURSES.cuisine.units[9].ch.push(

{ t:"Food Systems and Sustainability", s:"From farm to fork and the planet",
  sec:[
  ["What a food system is",[
    "A food system includes everything involved in feeding people: farming, fishing, processing, transport, retail, cooking, eating, and waste, along with the people, policies, and environments involved. Modern food systems produce enormous quantities of food but face major challenges in sustainability, health, and equity.",
    "Food systems are estimated to account for roughly a quarter to a third of global greenhouse gas emissions when land use, agriculture, processing, transport, and waste are included. Agriculture is also the largest user of fresh water and a major driver of biodiversity loss and deforestation."]],
  ["The impact of different foods",[
    "Different foods have very different environmental footprints. A widely cited 2018 study by Joseph Poore and Thomas Nemecek, analyzing data from about 38,000 farms, found that beef from beef herds has by far the highest greenhouse gas emissions per kilogram of protein, followed by lamb and cheese, while legumes, grains, and many vegetables have much lower footprints. Ruminants like cattle produce methane, a potent greenhouse gas, during digestion.",
    "The EAT-Lancet Commission's 2019 'planetary health diet' recommended a diet rich in plants, with modest amounts of animal foods, to feed a growing population within environmental limits. Such recommendations remain debated, especially regarding cultural, economic, and nutritional contexts."]],
  ["Food waste",[
    "According to the UN Environment Programme's Food Waste Index Report 2024, over a billion tonnes of food were wasted in 2022 across households, food service, and retail, around a fifth of food available to consumers, with households responsible for the largest share. Additional food is lost earlier, during harvest, storage, and transport. Wasted food also wastes the water, land, energy, and labor used to produce it.",
    "Chefs fight waste through whole-ingredient cooking (using stems, peels, and trimmings), nose-to-tail butchery, preserving, careful purchasing, and repurposing leftovers. Movements like Massimo Bottura's Food for Soul refettorios turn surplus food into meals for people in need. Home cooks can reduce waste by planning meals, storing food properly, understanding date labels ('best before' indicates quality, while 'use by' indicates safety), and using leftovers."]],
  ["Farming approaches",[
    "Approaches to farming include conventional industrial agriculture, organic farming (avoiding synthetic pesticides and fertilizers, certified under various national standards), regenerative agriculture (aiming to rebuild soil health through practices like cover cropping, reduced tillage, and rotational grazing), agroecology, and permaculture. Each has supporters and critics regarding yields, costs, and environmental effects.",
    "Technology also plays a role: precision agriculture, improved crop varieties (including genetically modified and gene-edited crops), vertical farming, and alternative proteins such as plant-based meats, fermentation-derived proteins, and cultivated meat."]],
  ["Seafood and biodiversity",[
    "Overfishing, bycatch, and habitat destruction threaten ocean ecosystems. Choosing sustainably managed seafood, eating smaller fish lower on the food chain (like sardines and anchovies), and supporting well-run aquaculture, such as farming of mussels and oysters, which can even filter water, help.",
    "Agricultural biodiversity has declined as farmers concentrate on a few high-yielding varieties. Organizations like Slow Food's Ark of Taste catalog endangered traditional foods, and seed banks, like the Svalbard Global Seed Vault (opened in 2008 in Norway), preserve crop diversity for the future."]],
  ["The cook's role",[
    "Cooks and chefs influence food systems through what they buy, cook, and serve. Seasonal and local sourcing, featuring plant-forward dishes, choosing sustainable seafood and responsibly raised meat, minimizing waste, and educating diners all make a difference.",
    "Sustainability involves trade-offs; local food is not always lower-carbon than imported food, since transport often accounts for a small share of emissions compared with production. Understanding the evidence helps cooks make better choices."]]
  ],
  terms:[["Food system","All the activities and actors involved in producing and consuming food."],["Carbon footprint","Greenhouse gas emissions associated with a product or activity."],["Food waste","Edible food discarded at retail, food service, or household level."],["Regenerative agriculture","Farming aimed at rebuilding soil health and ecosystems."],["Alternative proteins","Plant-based, fermentation-derived, or cultivated substitutes for animal proteins."],["Ark of Taste","Slow Food's catalog of endangered traditional foods."]],
  w:"What we cook and eat has profound effects on the planet, and cooks can help build more sustainable food systems.",
  src:["Food system","Environmental impact of agriculture","Food waste","Regenerative agriculture","EAT-Lancet Commission","Svalbard Global Seed Vault"],
  q:[["Roughly what share of global greenhouse gas emissions come from food systems?","About a quarter to a third","Under 1%","Over 90%","About half exactly"],
     ["Which food has the highest emissions per kilogram of protein, according to Poore and Nemecek?","Beef from beef herds","Lentils","Chicken","Tofu"],
     ["According to UNEP, who wastes the largest share of food?","Households","Farms only","Restaurants only","Supermarkets only"],
     ["What does a 'best before' date indicate?","Quality","Safety","The production date","The price"],
     ["What does the Svalbard Global Seed Vault do?","Preserves crop diversity","Grows food in the Arctic","Stores frozen meat","Tests GMOs"],
     ["Is local food always lower-carbon than imported food?","No; production often matters more than transport","Yes, always","Only for meat","Only in winter"]]},

{ t:"Food, Ethics, and Justice", s:"Hunger, labor, animals, and culture",
  sec:[
  ["Hunger and food security",[
    "Despite producing enough calories to feed everyone, the world still faces hunger. The UN's State of Food Security and Nutrition in the World reports estimate that around 700 million people faced hunger in recent years, with crises driven by conflict, climate shocks, economic downturns, and inequality. Food security means reliable access to sufficient, safe, nutritious food.",
    "Even in wealthy countries, many households experience food insecurity. 'Food deserts', low-income areas with limited access to affordable, healthy food, and the related concept of 'food apartheid', used by activists to emphasize structural racism, describe inequities in access. Food banks, school meal programs, and public assistance address some needs."]],
  ["Labor",[
    "Food depends on the labor of farmworkers, fishers, meatpacking workers, cooks, and servers, many of whom are low-paid, migrant, or undocumented, and face hazardous conditions. Movements like the United Farm Workers, led by César Chávez and Dolores Huerta from the 1960s, organized for better wages and conditions, including the famous grape boycotts.",
    "Forced labor has been documented in some supply chains, such as fishing fleets in Southeast Asia and cocoa farming in West Africa, where child labor remains a serious problem. Fair trade certifications, labor laws, and consumer pressure seek to improve conditions."]],
  ["Animal welfare",[
    "Most meat, eggs, and dairy in industrialized countries come from intensive systems that raise very large numbers of animals in confined conditions, raising ethical concerns. Ruth Harrison's 'Animal Machines' (1964) prompted the UK's Brambell Report (1965), which proposed the 'Five Freedoms' for farm animals, including freedom from hunger, discomfort, pain, fear, and freedom to express normal behavior.",
    "Responses include welfare regulations (such as the EU's ban on conventional battery cages for laying hens from 2012), labels like free-range and pasture-raised, and vegetarian and vegan diets. Philosophers like Peter Singer, in 'Animal Liberation' (1975), argued for considering animals' interests, while others defend humane animal farming. Thoughtful cooks often choose higher-welfare products and use the whole animal."]],
  ["Cultural appropriation and credit",[
    "As cuisines circulate globally, debates arise about cultural appropriation, when people outside a culture profit from its food without credit, understanding, or respect, while cooks from that culture face barriers. Examples include restaurants that 'reinvent' immigrant dishes for wealthy customers while immigrant cooks receive less recognition.",
    "Many argue that cultural exchange is natural and good, but that it should involve respect, accurate representation, credit to sources, and fair opportunities for cooks from those cultures. Learning the history and meaning of dishes is part of cooking them well."]],
  ["Food and health equity",[
    "Diet-related diseases such as type 2 diabetes and heart disease are influenced by food environments, income, education, marketing, and time. Policies such as sugary drink taxes, front-of-package warning labels (as in Chile's 2016 law, with black octagon warnings for products high in sugar, salt, saturated fat, or calories), school food standards, and limits on marketing to children aim to improve health.",
    "Cooking skills are linked to healthier diets, and many programs teach cooking in schools and communities. Chefs like Jamie Oliver have campaigned for better school food."]],
  ["The ethical cook",[
    "Every cook makes ethical choices: what to buy, from whom, how much to waste, how to treat co-workers, and how to honor the traditions behind recipes. Perfection is impossible, but awareness allows better decisions.",
    "Food is one of the most powerful ways people connect with one another. Recognizing food's ethical dimensions makes cooking and eating more meaningful, linking each meal to land, labor, animals, and culture."]]
  ],
  terms:[["Food security","Reliable access to sufficient, safe, nutritious food."],["Food desert","An area with limited access to affordable, healthy food."],["Five Freedoms","A framework for farm animal welfare from the 1965 Brambell Report."],["Fair trade","Certification aiming to improve conditions for producers."],["Cultural appropriation","Adopting elements of a culture without respect, credit, or understanding."],["Front-of-package labeling","Warning labels on food packaging about nutrients of concern."]],
  w:"Food raises ethical questions about hunger, labor, animals, culture, and health that every cook and eater faces.",
  src:["Food security","Food desert","United Farm Workers","Five freedoms (animal welfare)","Cultural appropriation","Food labeling in Chile"],
  q:[["Roughly how many people faced hunger in recent UN estimates?","Around 700 million","About 7 million","About 7 billion","Nobody"],
     ["Who co-led the United Farm Workers?","César Chávez and Dolores Huerta","Michael Pollan and Alice Waters","Upton Sinclair and Harvey Wiley","Peter Singer and Ruth Harrison"],
     ["The 'Five Freedoms' came from which report?","The Brambell Report (1965)","The EAT-Lancet Commission","The Jungle","The Athens Charter"],
     ["When did the EU ban conventional battery cages for laying hens?","2012","1965","1990","2025"],
     ["Chile's 2016 law introduced…","Black octagon warning labels on unhealthy foods","A ban on all sugar","Free school meals","A tax on wine"],
     ["Who wrote 'Animal Liberation'?","Peter Singer","Ruth Harrison","Temple Grandin","Michael Pollan"]]},

{ t:"Developing Your Palate", s:"How to taste like a chef",
  sec:[
  ["Tasting is a skill",[
    "Professional cooks, sommeliers, and tasters train their palates through practice and attention. Tasting well is less about having special senses and more about focused attention, memory, and vocabulary. Anyone can improve by tasting deliberately and comparing.",
    "Start by noticing the basic tastes, sweet, sour, salty, bitter, and umami, then aromas, texture, temperature, and aftertaste. Asking 'what do I taste, and what does it need?' every time you cook is the core habit."]],
  ["Comparative tasting",[
    "Comparing similar items side by side reveals differences more clearly than tasting alone. Try tasting several olive oils, salts, vinegars, apples, cheeses, chocolates, or coffees together; or taste the same dish with and without salt, or with different acids. Blind tasting removes bias from labels and price.",
    "Professional tasters use tools like the wine aroma wheel (developed by Ann C. Noble at UC Davis in the 1980s), the coffee taster's flavor wheel from the Specialty Coffee Association, and cheese and beer flavor wheels to develop vocabulary."]],
  ["Building flavor memory",[
    "Smell training builds a mental library of aromas. Smelling spices, herbs, fruits, and other ingredients, and naming them, helps. Sommeliers practice with aroma kits. Keeping a tasting notebook, recording what you tasted and your impressions, strengthens memory.",
    "Exposure matters: trying new cuisines, ingredients, and dishes expands the range of flavors you know and can draw on when cooking. Children's preferences, for example, often change after repeated exposure to a new food; adults' palates can grow too."]],
  ["Seasoning to taste",[
    "Recipes say 'season to taste' because ingredients vary in saltiness, sweetness, and acidity. Taste at each stage of cooking: raw ingredients (when safe), after building the base, during cooking, and before serving. Adjust a little at a time; it is easier to add than to remove.",
    "Remember that perception changes with temperature: cold food tastes less sweet and salty, so chilled dishes need more seasoning, while very hot food can hide flavors. Taste food at serving temperature when possible."]],
  ["Balancing a plate and a meal",[
    "Think in terms of contrast and harmony. Rich dishes need acid or bitterness; spicy dishes benefit from sweetness, fat, or cooling dairy; soft dishes need crunch; heavy meals need something fresh. Across a meal, vary flavors, textures, colors, and cooking methods.",
    "Classic combinations persist because they balance one another, like tomato, mozzarella, and basil; lamb, garlic, and rosemary; chili, lime, and fish sauce; or ginger, scallion, and soy. Understanding why they work lets cooks invent new combinations."]],
  ["Learning from great food",[
    "Eating at excellent restaurants, markets, street stalls, and in people's homes is part of a cook's education. Pay attention to what makes a dish memorable: balance, texture, temperature, seasoning, and the quality of ingredients.",
    "Equally, learn from mistakes: a dish that is too salty, bland, or heavy teaches what to adjust next time. A refined palate develops over years of attentive cooking and eating."]]
  ],
  terms:[["Palate","A person's ability to taste and discern flavors."],["Blind tasting","Tasting without knowing the identity of what is tasted."],["Flavor wheel","A visual tool listing flavor and aroma descriptors."],["Season to taste","Adjusting seasoning based on tasting."],["Aftertaste (finish)","The flavors that linger after swallowing."]],
  w:"A trained palate is a cook's most important tool, and anyone can develop one through deliberate tasting.",
  src:["Taste","Wine tasting","Flavor","Blind taste test","Aroma wheel","Seasoning"],
  q:[["What is the core habit of a cook developing their palate?","Asking what a dish tastes like and what it needs","Following recipes exactly without tasting","Using only salt","Eating quickly"],
     ["Why compare similar items side by side?","Differences become clearer","It is faster","It saves money","It hides flaws"],
     ["Who developed the wine aroma wheel?","Ann C. Noble","Robert Parker","Jancis Robinson","Steven Spurrier"],
     ["Why do cold dishes often need more seasoning?","Cold reduces perception of sweetness and saltiness","Cold food absorbs salt","Cold food is denser","They do not"],
     ["What balances a very rich dish?","Acid or bitterness","More fat","More sugar","More cream"],
     ["What is blind tasting?","Tasting without knowing what is tasted","Tasting with eyes closed only","Tasting at night","Tasting spoiled food"]]},

{ t:"Cooking for Others", s:"Planning, hosting, and feasting",
  sec:[
  ["Planning a meal",[
    "Planning a meal for others begins with the guests: their number, dietary needs and allergies, preferences, and the occasion. Choose a menu that fits your skills, equipment, budget, and time, and that balances flavors, textures, colors, and richness across courses. Include dishes that can be made in advance.",
    "A timeline working backward from serving time, listing shopping, prep, cooking, and plating tasks, helps avoid last-minute stress. Professional cooks call this a prep list and production schedule."]],
  ["Cooking in quantity",[
    "Cooking for many people requires scaling recipes carefully, using larger equipment, and adjusting cooking times. Braises, stews, roasts, baked pastas, grain salads, and casseroles scale well; delicate, last-minute dishes like risotto or seared fish for many people are harder.",
    "Food safety becomes more important with larger quantities: cool food quickly in shallow containers, keep hot food above 60°C and cold food below 5°C, and avoid leaving buffets out too long. Caterers use chafing dishes, ice beds, and timing to keep food safe."]],
  ["Feasts and celebrations",[
    "Every culture has feasts that bring people together around food: Thanksgiving in the US and Canada, Christmas dinners, Lunar New Year banquets, Eid feasts, Diwali sweets, Passover Seders, Nowruz tables, weddings, and harvest festivals. Feast foods often carry symbolic meanings, such as long noodles for longevity, round foods for completeness, or bitter herbs for remembrance.",
    "Many feasts involve communal cooking, such as Korean kimjang, Italian Sunday sauce-making, and Southern US fish fries, strengthening family and community bonds."]],
  ["Budget and everyday cooking",[
    "Cooking well on a budget relies on staples (rice, beans, lentils, pasta, oats, eggs, seasonal vegetables), buying whole ingredients and using all parts, cooking in batches, and building flavor with inexpensive seasonings like onions, garlic, spices, vinegar, and stock made from scraps. Many of the world's great dishes were born from frugality.",
    "Weekly meal planning, shopping lists, and cooking components that can be combined in different ways (a pot of beans, roasted vegetables, a sauce) make everyday cooking easier and reduce waste."]],
  ["Cooking for special diets",[
    "Cooking for guests with dietary restrictions requires care and creativity. For vegetarian and vegan guests, build satisfying dishes around legumes, grains, vegetables, nuts, mushrooms, tofu, and umami-rich ingredients like miso, soy sauce, and tomatoes. For gluten-free guests, use naturally gluten-free foods like rice, corn, potatoes, and buckwheat, and avoid cross-contact.",
    "For allergies, read labels, clean surfaces and tools, and when unsure, ask. Many cuisines, such as South Indian, Ethiopian, and Middle Eastern, offer naturally vegetarian or vegan dishes that suit everyone at the table."]],
  ["The joy of sharing food",[
    "Research in many countries has found that eating together is associated with wellbeing and social connection. The word 'companion' literally means 'one who shares bread'. Cooking for others is an act of care and generosity that has bound families and communities together throughout history.",
    "Relax and enjoy it: a simple, well-made meal shared warmly is better than an elaborate one served with stress. As Julia Child often encouraged her viewers, a cook should be fearless and keep a sense of humor."]]
  ],
  terms:[["Prep list","A list of preparation tasks for a meal or service."],["Production schedule","A timeline of cooking tasks leading to service."],["Batch cooking","Cooking large quantities to use over several meals."],["Chafing dish","A dish kept warm over a heat source for buffets."],["Feast","A celebratory meal often with symbolic foods."]],
  w:"Cooking for others combines planning, skill, and generosity, and is one of the most rewarding uses of culinary knowledge.",
  src:["Meal","Feast","Catering","Meal preparation","Vegetarian cuisine","Gluten-free diet"],
  q:[["What is the first step in planning a meal for guests?","Considering the guests' needs and the occasion","Buying expensive ingredients","Choosing plates","Setting the oven"],
     ["Which dish scales well for large groups?","Braises and stews","Individually seared fish","Soufflés","Risotto for fifty"],
     ["What do long noodles symbolize at Lunar New Year?","Longevity","Wealth","Love","Luck in exams"],
     ["Which is a good budget staple?","Lentils","Saffron","Caviar","Wagyu beef"],
     ["What does 'companion' literally mean?","One who shares bread","A friend at war","A dinner guest","A cook"],
     ["For gluten-free guests, which grain is naturally safe?","Rice","Wheat","Barley","Rye"]]},

{ t:"Thinking Like a Cook", s:"Bringing it all together",
  sec:[
  ["From recipes to understanding",[
    "This foundation course has covered how cooking works, the science of heat and flavor, the major ingredients and techniques, the history of food, the world's great cuisines, drinks, and the professional world. Together they form the knowledge of a serious cook.",
    "The goal is to move from following recipes to understanding them: knowing why a technique works, how to adjust for different ingredients, and how to create new dishes from principles. A cook who understands salt, acid, fat, heat, texture, and timing can cook from almost any tradition."]],
  ["Principles to remember",[
    "Key principles include: start with good ingredients and respect them; prepare before you cook (mise en place); control heat thoughtfully, browning for flavor and cooking gently for tenderness; season throughout and taste constantly; balance flavors and textures; and finish dishes with care, with fresh herbs, acid, or good oil.",
    "Also: match techniques to ingredients (tough cuts low and slow, tender cuts quick and hot); respect food safety; reduce waste; and learn from each dish you make."]],
  ["Respecting tradition",[
    "Every cuisine studied here represents centuries of accumulated knowledge from countless cooks, often unrecorded and often women working in home kitchens. Learning a cuisine means learning its ingredients, techniques, and meanings, ideally from people who grew up with it.",
    "Respecting tradition does not mean never changing it; all cuisines evolve through trade, migration, and creativity. But understanding a tradition well is the best foundation for creative cooking."]],
  ["A lifetime of learning",[
    "Cooking can be learned for a lifetime. Next steps might include mastering a particular cuisine, baking or pastry, butchery, fermentation, or wine; reading great cookbooks and food histories; traveling and eating; taking classes; or working in a professional kitchen.",
    "Cook regularly, taste attentively, ask questions, keep notes, and cook for others. Each meal is a chance to improve."]],
  ["Food as connection",[
    "Food connects us to the land and the seasons, to history and culture, to the people who grow and cook it, and to those we share it with. Understanding cuisine deepens every meal: a bowl of pho carries French colonial history and Vietnamese ingenuity; a tomato sauce carries the Columbian Exchange; a loaf of bread carries ten thousand years of agriculture.",
    "Whatever path you take, from home cooking to professional kitchens or food writing, this knowledge will make your cooking better and your eating richer."]],
  ["A final word",[
    "The great chef Fernand Point is often quoted as saying that success in cooking is the sum of many small things done correctly. Cooking well is less about secret recipes than about care, attention, and practice.",
    "So keep cooking, keep tasting, and keep sharing. The kitchen is one of the most rewarding places to keep learning."]]
  ],
  terms:[["Principle-based cooking","Cooking by understanding techniques and balance rather than only following recipes."],["Tradition","Accumulated knowledge and practices passed through generations."],["Mastery","High skill developed through long, deliberate practice."]],
  w:"Thinking like a cook means using principles, curiosity, and respect to cook well in any tradition.",
  src:["Cooking","Cuisine","Fernand Point","Gastronomy","Culinary arts","Food history"],
  q:[["What is the goal of moving beyond recipes?","Understanding why techniques work","Never using recipes again","Cooking faster","Using fewer ingredients"],
     ["Which principle applies to tough cuts of meat?","Cook low and slow","Cook fast and hot","Serve raw","Boil hard"],
     ["Whose knowledge does much traditional cuisine represent?","Countless unrecorded home cooks, often women","Only famous chefs","Only scientists","Only kings"],
     ["A bowl of pho carries the history of…","French colonialism and Vietnamese ingenuity","The Columbian Exchange only","Japanese cuisine","Italian immigration"],
     ["Fernand Point is quoted on success in cooking as…","The sum of many small things done correctly","A secret recipe","Expensive ingredients","Luck"],
     ["What is the best way to keep improving as a cook?","Cook regularly, taste attentively, and keep learning","Only watch television","Buy more gadgets","Never change recipes"]]}

);
