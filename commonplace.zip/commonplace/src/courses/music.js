/* ---- from music-01.js ---- */
/* MUSIC FOUNDATIONS, part 1: Unit 1 How Music Works, chapters 1-5 */
COURSES.music = { units: [] };
COURSES.music.units.push({ t:"How Music Works", ch:[

{ t:"What Is Music?", s:"Organized sound and how to listen",
  sec:[
  ["A human universal",[
    "Every known human culture makes music. The oldest known musical instruments are flutes carved from bird bones and mammoth ivory found in caves in southern Germany, such as at Hohle Fels and Geißenklösterle, dated to about 40,000 years ago. Music accompanies rituals, work, celebration, mourning, courtship, worship, and storytelling.",
    "The composer Edgard Varèse defined music as “organized sound.” Most music combines a few basic elements: rhythm (the organization of time), pitch and melody (high and low notes in sequence), harmony (notes sounding together), timbre (tone color), dynamics (loudness), texture (how layers combine), and form (overall structure)."]],
  ["Why music moves us",[
    "Music can trigger powerful emotions, chills, tears, and the urge to move. Brain imaging shows that pleasurable music activates reward circuits and releases dopamine, especially at moments of anticipation and resolution. Music also synchronizes groups of people, which may explain its role in rituals, armies, and dance.",
    "Scholars debate why music evolved: possible explanations include social bonding, courtship, communication between parents and infants, and coordinating groups. Charles Darwin speculated that musical ability preceded language."]],
  ["Ways of studying music",[
    "Music theory studies how music is constructed: scales, chords, rhythms, and forms. Musicology studies music's history. Ethnomusicology studies music in its cultural context, especially traditions beyond Western classical music. Music psychology and cognition study how we perceive and remember music.",
    "Musicians may learn by ear, through oral tradition, or by reading notation; many of the world's great traditions, from West African drumming to Indian classical music and the blues, have been passed down largely by ear."]],
  ["Active listening",[
    "Listening attentively, rather than in the background, reveals more. Questions to ask include: What instruments or voices do I hear? What is the tempo and meter, and can I tap the beat? Is the melody stepwise or leaping? Is the music loud or soft, and does that change? How many layers are there? Does a section repeat or return?",
    "Comparing different performances of the same piece, or the same song in different arrangements, shows how much interpretation matters. Repeated listening reveals details; much great music is designed to reward it."]],
  ["Categories of music",[
    "Music is often divided into broad categories: art or classical music, composed and notated in traditions such as Western classical, Indian classical, and Chinese court music; folk or traditional music, passed down within communities; popular music, commercially produced for mass audiences, from Tin Pan Alley to hip-hop; and religious music.",
    "These categories overlap and change: jazz began as popular dance music and became an art form; folk melodies have inspired symphonies; and classical pieces appear in films and advertisements. Genres such as rock, country, and electronic music each contain many subgenres."]],
  ["Music and meaning",[
    "Some music tells stories or depicts things, program music, such as Vivaldi's The Four Seasons or Beethoven's Pastoral Symphony; other music is “absolute,” meaningful purely as patterns of sound, such as a Bach fugue. Songs combine music with words, and opera, musicals, ballet, and film unite music with drama and movement.",
    "This course introduces how music works, the instruments and voices that make it, and the major traditions of the world, from medieval chant to hip-hop, so that you can listen with deeper understanding and enjoyment."]]
  ],
  terms:[["Organized sound","Varèse's definition of music."],["Rhythm","The organization of music in time."],["Melody","A sequence of pitches heard as a line."],["Harmony","Notes sounding together."],["Timbre","The tone color of a sound."],["Ethnomusicology","The study of music in cultural context."],["Program music","Music that depicts a story or scene."]],
  w:"Understanding music's elements and listening actively transforms music from background sound into a rich experience.",
  src:["Music","Prehistoric music","Edgard Varèse","Music and emotion","Ethnomusicology","Program music","Absolute music"],
  q:[["How old are the oldest known musical instruments?","About 40,000 years","About 4,000 years","About 400,000 years","About 10,000 years"],
     ["Who defined music as organized sound?","Edgard Varèse","Igor Stravinsky","John Cage","Leonard Bernstein"],
     ["What is the tone color of a sound called?","Timbre","Pitch","Dynamics","Tempo"],
     ["What field studies music in its cultural context?","Ethnomusicology","Music theory","Acoustics","Musicology only"],
     ["Which is an example of program music?","Vivaldi's The Four Seasons","A Bach fugue","A scale exercise","A string quartet without title"],
     ["What do the oldest flutes come from?","Bird bones and mammoth ivory","Bamboo","Clay","Metal"]]},

{ t:"The Science of Sound", s:"Vibrations, pitch, and overtones",
  sec:[
  ["Sound waves",[
    "Sound is a vibration traveling through a medium, usually air, as waves of pressure. A plucked string, struck drumhead, or vibrating vocal cords push air molecules back and forth, creating compressions and rarefactions that reach our ears. Sound travels about 343 meters per second in air.",
    "Acoustics is the science of sound. A sound's frequency, the number of vibrations per second measured in hertz (Hz), determines its pitch; its amplitude determines its loudness, measured in decibels."]],
  ["Pitch and frequency",[
    "Higher frequencies sound higher in pitch. Humans hear roughly 20 to 20,000 Hz. The lowest note on a standard piano is about 27.5 Hz and the highest about 4,186 Hz. The A above middle C is the standard tuning reference at 440 Hz, adopted internationally in 1939 and reaffirmed in 1955; orchestras sometimes tune slightly higher.",
    "Doubling a frequency produces a note an octave higher, which sounds like the same note at a higher level: A at 440 Hz and A at 880 Hz. This octave equivalence is recognized in virtually every musical culture."]],
  ["Overtones and timbre",[
    "When a string vibrates, it vibrates not only as a whole, producing the fundamental frequency, but also in halves, thirds, quarters, and so on, producing higher frequencies called overtones or harmonics, multiples of the fundamental. This series of harmonics is called the harmonic series.",
    "The mix and strength of overtones give each instrument its characteristic timbre: a flute's tone is relatively pure, with few overtones, while an oboe's is rich in them. That is why a violin and a trumpet playing the same note sound different. Pythagoras, according to tradition, discovered that simple ratios of string lengths, 2:1 for an octave and 3:2 for a fifth, produce harmonious intervals."]],
  ["How instruments make sound",[
    "Instruments produce sound in different ways, classified in the Hornbostel-Sachs system (1914): chordophones use vibrating strings (violin, guitar, piano); aerophones use vibrating air (flute, trumpet, organ); membranophones use stretched membranes (drums); idiophones vibrate their own bodies (xylophone, cymbals, bells); and electrophones produce sound electronically (synthesizers).",
    "Most instruments have a resonator, a body or tube that amplifies and shapes the sound, such as a violin's wooden body or a trumpet's bell."]],
  ["Rooms and resonance",[
    "The space where music is performed shapes its sound. Reverberation, the persistence of sound as it reflects off surfaces, can make music sound full and rich or muddy. Gothic cathedrals, with very long reverberation, suited slow-moving chant; smaller rooms suited the intricate detail of chamber music.",
    "Concert halls are designed by acoustic engineers; Boston's Symphony Hall (1900), designed with the physicist Wallace Sabine, who founded architectural acoustics, and Vienna's Musikverein (1870) are renowned for their sound."]],
  ["Recording sound",[
    "In 1877 Thomas Edison invented the phonograph, recording sound as grooves on a tin-foil cylinder; Emile Berliner's flat disc gramophone (1887) led to records. Recording transformed music, allowing it to be heard anywhere, anytime, and preserving performances.",
    "Microphones convert sound waves into electrical signals; speakers convert them back. Digital audio, as on CDs (introduced in 1982), samples sound waves thousands of times per second, typically 44,100 times, and stores them as numbers."]]
  ],
  terms:[["Frequency","Vibrations per second, measured in hertz."],["Pitch","How high or low a sound is."],["Octave","The interval between a note and one with double its frequency."],["Overtones","Higher frequencies that sound with a fundamental."],["Harmonic series","The sequence of overtones at multiples of the fundamental."],["Hornbostel-Sachs","A system classifying instruments by how they make sound."],["Reverberation","Persistence of sound in a space."]],
  w:"The physics of sound explains pitch, timbre, and harmony, and why instruments and rooms sound as they do.",
  src:["Sound","Pitch (music)","A440 (pitch standard)","Overtone","Harmonic series (music)","Hornbostel–Sachs","Phonograph"],
  q:[["What is the standard tuning pitch for A above middle C?","440 Hz","256 Hz","880 Hz","100 Hz"],
     ["What does doubling a frequency produce?","An octave higher","A fifth higher","The same note","A lower note"],
     ["What gives instruments their distinctive timbre?","The mix of overtones","Their volume","Their size only","Their pitch"],
     ["What ratio of string lengths produces a perfect fifth?","3:2","2:1","4:3","5:4"],
     ["What type of instrument is a drum in the Hornbostel-Sachs system?","Membranophone","Chordophone","Aerophone","Idiophone"],
     ["Who invented the phonograph in 1877?","Thomas Edison","Emile Berliner","Alexander Graham Bell","Guglielmo Marconi"]]},

{ t:"Rhythm, Beat, and Meter", s:"Music in time",
  sec:[
  ["The beat",[
    "Rhythm is the organization of sound in time. Most music has a beat, or pulse, a steady recurring pattern that listeners tap their feet to. Tempo is the speed of the beat, measured in beats per minute (BPM): a slow ballad may be around 60–70 BPM, a pop song often 100–130, and fast dance music 120–140 or more.",
    "Classical music uses Italian tempo terms: largo (very slow), adagio (slow), andante (walking pace), moderato (moderate), allegro (fast), and presto (very fast). Accelerando means speeding up; ritardando, slowing down. Johann Maelzel patented the metronome in 1815, and Beethoven was among the first composers to give metronome markings."]],
  ["Meter",[
    "Meter groups beats into regular patterns of strong and weak beats, organized into measures (bars). In duple meter, beats are grouped in twos (STRONG-weak), as in marches; in triple meter, in threes (STRONG-weak-weak), as in waltzes; in quadruple meter, in fours (STRONG-weak-medium-weak), the most common meter in popular music.",
    "A time signature indicates the meter: 4/4 (four quarter-note beats per measure, so common it is called “common time”), 3/4 for waltzes, and 2/4 for marches. In compound meters such as 6/8, each beat divides into three, giving a lilting feel, as in many jigs and lullabies."]],
  ["Note values",[
    "In Western notation, note durations are shown by different symbols: a whole note lasts four beats in 4/4 time, a half note two beats, a quarter note one beat, an eighth note half a beat, and a sixteenth note a quarter of a beat. Rests indicate silences of corresponding lengths.",
    "A dot after a note adds half its value; a tie joins notes into one longer sound. Triplets divide a beat into three equal parts."]],
  ["Syncopation and swing",[
    "Syncopation places accents on normally weak beats or between beats, creating surprise and forward momentum; it is essential to ragtime, jazz, funk, Latin music, and much popular music. A backbeat, emphasis on beats two and four of a 4/4 measure, typically played on the snare drum, defines rock and roll and much popular music.",
    "Swing rhythm, central to jazz, plays pairs of eighth notes unevenly, long-short, giving a relaxed, bouncing feel. Groove describes the irresistible rhythmic feel that makes people want to dance, arising from the interaction of instruments."]],
  ["Complex rhythms",[
    "Many traditions use rhythms more complex than Western 4/4. Polyrhythm layers different rhythms simultaneously, such as three against two, central to West African drumming. Indian classical music uses tala, rhythmic cycles of various lengths, some with 7, 10, or 16 beats. Balkan folk music uses asymmetric meters such as 7/8 and 11/8.",
    "Odd meters appear in Western music too: Dave Brubeck's “Take Five” (1959) is in 5/4, and Stravinsky's The Rite of Spring (1913) shifts meters constantly. The clave, a two-measure pattern, organizes much Afro-Cuban music."]],
  ["Rhythm and the body",[
    "Rhythm is deeply physical; humans readily synchronize movements to a beat, an ability called entrainment, rare among animals, though some parrots, such as Snowball the cockatoo, famously dance to music.",
    "Dance and rhythm are inseparable in most cultures, and drumming traditions around the world use rhythm for communication, ritual, and trance."]]
  ],
  terms:[["Tempo","The speed of the beat."],["Meter","The grouping of beats into patterns."],["Time signature","The notation indicating meter."],["Measure (bar)","A unit containing a fixed number of beats."],["Syncopation","Accents on weak beats or between beats."],["Backbeat","Emphasis on beats two and four."],["Polyrhythm","Layered contrasting rhythms."]],
  w:"Rhythm is the heartbeat of music, and understanding beat, meter, and syncopation explains why music makes us move.",
  src:["Rhythm","Tempo","Metre (music)","Time signature","Syncopation","Swing (jazz performance style)","Polyrhythm"],
  q:[["What does BPM measure?","Beats per minute","Bars per measure","Bass per melody","Breaths per minute"],
     ["What does allegro mean?","Fast","Slow","Walking pace","Very slow"],
     ["Which meter is typical of a waltz?","Triple meter, 3/4","Duple meter, 2/4","Quadruple meter, 4/4","Compound meter, 12/8"],
     ["What is emphasis on beats two and four called?","The backbeat","Syncopation","Swing","Polyrhythm"],
     ["In what meter is Take Five?","5/4","4/4","7/8","3/4"],
     ["What are rhythmic cycles in Indian classical music called?","Tala","Raga","Clave","Gamaka"]]},

{ t:"Pitch, Notes, and Notation", s:"Reading and naming the sounds of music",
  sec:[
  ["Naming notes",[
    "In Western music, the seven natural notes are named with letters A, B, C, D, E, F, and G, repeating in each octave. On a piano, these are the white keys; the black keys are sharps (♯, raising a note by a half step) and flats (♭, lowering it). C♯ and D♭ are the same key, called enharmonic equivalents.",
    "The smallest interval in standard Western music is the half step, or semitone, the distance between adjacent piano keys. Two half steps make a whole step. An octave contains 12 half steps, giving the 12 notes of the chromatic scale."]],
  ["Solfège",[
    "Another naming system, solfège, uses syllables: do, re, mi, fa, sol, la, ti (or si). It derives from the 11th-century Italian monk Guido of Arezzo, who used the first syllables of the lines of a Latin hymn to Saint John to help singers learn melodies. The song “Do-Re-Mi” from The Sound of Music teaches it.",
    "In many countries, such as France, Italy, and Spain, these syllables are used as fixed names for notes (do = C); in “movable do,” do is the first note of whatever key is being sung."]],
  ["The staff and clefs",[
    "Western notation writes music on a staff of five horizontal lines, developed from Guido of Arezzo's innovations around 1025. Notes are placed on lines and spaces; higher position means higher pitch. A clef at the beginning fixes which line represents which note.",
    "The treble clef (G clef) is used for higher instruments and voices; mnemonics for its lines are E-G-B-D-F (“Every Good Boy Does Fine”) and for its spaces F-A-C-E. The bass clef (F clef) is used for lower instruments. Piano music uses both on a grand staff; middle C lies between them. The alto clef is used for the viola."]],
  ["Other symbols",[
    "Notation also shows rhythm, tempo, dynamics (p for piano, soft; f for forte, loud), articulation (staccato dots for short, detached notes; legato slurs for smooth, connected notes), repeat signs, and expression marks.",
    "A key signature at the start of each line shows which notes are consistently sharp or flat. A conductor or player reads a score, which for an orchestra shows all the parts stacked together."]],
  ["Other notation systems",[
    "Western staff notation is not the only system. Guitarists often use tablature (tab), which shows which fret to press on each string; jazz and pop musicians often use lead sheets with a melody and chord symbols. Ancient Greeks used letter notation, and medieval chant used neumes, marks indicating melodic shape.",
    "Chinese guqin music uses a tablature describing finger positions; Indian musicians use sargam syllables (sa, re, ga, ma, pa, dha, ni). Many traditions rely mainly on oral transmission."]],
  ["Learning to read music",[
    "Reading music is a skill like reading a language: recognizing notes and rhythms becomes automatic with practice. Sight-reading means playing or singing music at first sight. Ear training develops the ability to identify pitches, intervals, and chords by sound.",
    "Some people have absolute (perfect) pitch, the rare ability to name a note without a reference, estimated in about 1 in 10,000 people in Western populations, more common among speakers of tonal languages and those with early musical training; most musicians develop relative pitch, recognizing intervals between notes."]]
  ],
  terms:[["Half step","The smallest interval in Western music."],["Sharp and flat","Raising or lowering a note by a half step."],["Chromatic scale","All 12 notes in an octave."],["Solfège","Do, re, mi, fa, sol, la, ti."],["Staff","Five lines on which music is written."],["Clef","A symbol fixing the pitch of staff lines."],["Tablature","Notation showing finger positions."],["Absolute pitch","The ability to name notes without a reference."]],
  w:"Notation and note names are the written language of music, allowing it to be preserved, shared, and studied.",
  src:["Musical note","Semitone","Solfège","Guido of Arezzo","Staff (music)","Clef","Absolute pitch"],
  q:[["How many half steps are in an octave?","12","7","8","10"],
     ["Who devised the solfège syllables?","Guido of Arezzo","Pythagoras","Hildegard of Bingen","J. S. Bach"],
     ["How many lines does a musical staff have?","Five","Four","Six","Three"],
     ["What are the spaces of the treble clef?","F-A-C-E","E-G-B-D-F","A-C-E-G","G-B-D-F"],
     ["What does f mean in dynamics?","Forte, loud","Fine, end","Fast","Flat"],
     ["What notation shows which fret to press on guitar?","Tablature","Neumes","Solfège","Sargam"]]},

{ t:"Scales, Keys, and Intervals", s:"The building blocks of melody",
  sec:[
  ["Intervals",[
    "An interval is the distance between two pitches. Intervals are named by counting letter names: C to D is a second, C to E a third, C to F a fourth, C to G a fifth, C to A a sixth, C to B a seventh, and C to C an octave. They are further described as major, minor, perfect, augmented, or diminished.",
    "Different intervals have characteristic sounds: the perfect fifth sounds open and stable (the opening of “Twinkle, Twinkle, Little Star”); the major third sounds bright; the minor third sounds darker. The tritone, six half steps, was once called “the devil in music” for its tense, unstable sound."]],
  ["Consonance and dissonance",[
    "Consonant intervals, such as octaves, fifths, and thirds, sound stable and pleasant; dissonant intervals, such as seconds, sevenths, and the tritone, sound tense and seem to need resolution to consonance. Much of the expressive power of music comes from creating tension through dissonance and releasing it.",
    "What counts as dissonant has changed over history and differs between cultures; thirds were treated as dissonant in early medieval music, and 20th-century composers embraced dissonance freely."]],
  ["The major scale",[
    "A scale is a set of notes arranged in order of pitch. The major scale, the basis of much Western music, has seven notes following the pattern of whole (W) and half (H) steps: W-W-H-W-W-W-H. Starting on C, it uses only the white keys: C-D-E-F-G-A-B-C, the familiar do-re-mi-fa-sol-la-ti-do.",
    "Major keys often sound bright or happy, though such associations are partly cultural."]],
  ["Minor scales and modes",[
    "The natural minor scale follows the pattern W-H-W-W-H-W-W; A minor uses the white keys from A to A. Minor keys often sound darker or sadder. The harmonic minor raises the seventh note, giving an exotic-sounding step, and the melodic minor raises the sixth and seventh when ascending.",
    "Modes are scales starting on different notes of the major scale: Dorian (D to D on white keys), common in folk and jazz; Phrygian; Lydian; Mixolydian, common in rock and folk; and Aeolian (natural minor) and Ionian (major). The pentatonic scale, with five notes, is found in folk music worldwide, from China to Scotland to West Africa; the black keys of a piano form one. The blues scale adds a “blue note,” a flattened fifth, to a minor pentatonic."]],
  ["Keys",[
    "A key is the tonal center of a piece, the note and scale that feel like “home.” A piece in C major centers on C, and melodies and chords tend to return to it for a sense of resolution. The first note of the scale is the tonic; the fifth, the dominant, has a strong pull back to the tonic.",
    "Key signatures show which sharps or flats a key uses. The circle of fifths arranges the 12 keys so that each is a fifth from the next, showing how many sharps or flats each has and which keys are closely related. Moving from one key to another within a piece is called modulation, a powerful expressive device, as in the key change that lifts many pop songs' final choruses."]],
  ["Melody",[
    "A melody, or tune, is a sequence of notes perceived as a single line. Melodies move by steps (conjunct motion), which sound smooth and singable, or by leaps (disjunct motion), which sound dramatic. A melody's range is the distance from its lowest to highest note, and its contour is its overall shape, rising and falling.",
    "Melodies are often built from phrases, like sentences, and motifs, short recognizable fragments, such as the four-note opening of Beethoven's Fifth Symphony, which composers develop and transform. A memorable melodic phrase in popular music is often called a hook."]]
  ],
  terms:[["Interval","The distance between two pitches."],["Consonance and dissonance","Stable vs. tense combinations of notes."],["Major scale","The W-W-H-W-W-W-H scale."],["Minor scale","A scale often heard as darker."],["Mode","A scale beginning on a different note of the major scale."],["Pentatonic scale","A five-note scale found worldwide."],["Key","The tonal center of a piece."],["Circle of fifths","An arrangement of keys a fifth apart."]],
  w:"Scales, keys, and intervals are the vocabulary of melody and harmony, explaining why music sounds bright, dark, tense, or resolved.",
  src:["Interval (music)","Consonance and dissonance","Major scale","Minor scale","Mode (music)","Pentatonic scale","Circle of fifths"],
  q:[["What interval is C to G?","A fifth","A third","A fourth","A sixth"],
     ["Which interval was called the devil in music?","The tritone","The octave","The fifth","The third"],
     ["What is the pattern of the major scale?","W-W-H-W-W-W-H","W-H-W-W-H-W-W","H-W-W-W-H-W-W","W-W-W-H-W-W-H"],
     ["Which scale has five notes and is found worldwide?","The pentatonic scale","The chromatic scale","The major scale","The harmonic minor"],
     ["What is moving from one key to another called?","Modulation","Syncopation","Transposition only","Resolution"],
     ["What is the first note of a scale called?","The tonic","The dominant","The leading tone","The subdominant"]]}

]});


/* ---- from music-02.js ---- */
/* MUSIC FOUNDATIONS, part 2: Unit 1 chapters 6-10 */
COURSES.music.units[0].ch.push(

{ t:"Chords and Harmony", s:"Notes sounding together",
  sec:[
  ["Triads",[
    "A chord is three or more notes sounded together. The most basic is the triad, built by stacking two thirds: a root, a third, and a fifth. A major triad (such as C-E-G) has a major third on the bottom and sounds bright; a minor triad (A-C-E) has a minor third on the bottom and sounds darker. Diminished triads (two minor thirds) sound tense, and augmented triads (two major thirds) sound unsettled.",
    "Adding another third creates seventh chords, such as the dominant seventh (G-B-D-F), which strongly pulls toward resolution, and the major seventh, with its dreamy sound in jazz and pop."]],
  ["Roman numerals",[
    "Chords built on each note of a scale are numbered with Roman numerals. In C major, the chords are I (C major), ii (D minor), iii (E minor), IV (F major), V (G major), vi (A minor), and vii° (B diminished). Uppercase indicates major and lowercase minor.",
    "The three primary chords, I (tonic), IV (subdominant), and V (dominant), can harmonize countless songs. The tonic feels like home; the dominant creates tension that wants to resolve to the tonic."]],
  ["Chord progressions",[
    "A chord progression is a sequence of chords. The I–IV–V progression underlies the 12-bar blues and much early rock and roll. The I–V–vi–IV progression (in C: C–G–Am–F) appears in an enormous number of pop songs, such as “Let It Be” and “Don't Stop Believin',” famously demonstrated in the comedy group Axis of Awesome's “Four Chords” medley.",
    "The ii–V–I progression is the backbone of jazz harmony. The circle-of-fifths progression moves chords by descending fifths, driving many Baroque pieces and standards."]],
  ["Cadences",[
    "A cadence is a harmonic ending point, like punctuation. The authentic cadence (V–I) sounds final, like a period; the plagal cadence (IV–I) is the “Amen” cadence heard at the end of hymns. A half cadence ends on V, sounding unfinished, like a comma; a deceptive cadence goes from V to an unexpected chord such as vi, creating surprise.",
    "Composers use cadences to shape phrases and build expectation; delaying resolution creates suspense."]],
  ["Functional harmony and beyond",[
    "Western classical music from about 1600 to 1900 used tonal harmony, in which chords have functions organized around a home key, a system codified by Jean-Philippe Rameau in his Treatise on Harmony (1722). Romantic composers such as Wagner stretched it with chromatic harmony, using notes outside the key for intense emotion.",
    "Jazz harmony uses extended chords (ninths, elevenths, thirteenths), substitutions, and altered chords. Some 20th-century composers abandoned tonality altogether. Many musical traditions, such as Indian classical music, emphasize melody over a drone rather than chord progressions."]],
  ["Hearing harmony",[
    "Learning to hear harmony begins with the bass line, which usually outlines the chord roots, and with recognizing major versus minor chords. Guitarists and pianists often learn songs as chord charts.",
    "Arpeggios play the notes of a chord one after another rather than together, as in the opening of many guitar ballads. Inversions place a note other than the root in the bass, creating smoother bass lines. Voice leading, moving each note smoothly to the next chord, is a central skill in composition."]]
  ],
  terms:[["Chord","Three or more notes sounding together."],["Triad","A three-note chord of root, third, and fifth."],["Tonic, subdominant, dominant","Chords I, IV, and V."],["Chord progression","A sequence of chords."],["Cadence","A harmonic point of rest or ending."],["Functional harmony","Chords organized around a home key."],["Arpeggio","Chord notes played one after another."]],
  w:"Harmony gives music depth, color, and direction, and recognizing chord progressions unlocks how songs are built.",
  src:["Chord (music)","Triad (music)","Roman numeral analysis","Chord progression","Cadence","I–V–vi–IV progression","Jean-Philippe Rameau"],
  q:[["What notes make a C major triad?","C-E-G","C-D-E","C-F-A","C-E♭-G"],
     ["Which chord is the dominant in C major?","G major","F major","D minor","A minor"],
     ["Which progression is very common in pop songs?","I–V–vi–IV","ii–V–I","I–ii–iii","vi–ii–iii"],
     ["What is the IV–I cadence called?","The plagal or Amen cadence","The authentic cadence","The deceptive cadence","The half cadence"],
     ["Who wrote the Treatise on Harmony in 1722?","Jean-Philippe Rameau","J. S. Bach","Johann Fux","Arnold Schoenberg"],
     ["What is playing chord notes one after another called?","An arpeggio","A cadence","An inversion","A drone"]]},

{ t:"Texture and Form", s:"How music is layered and structured",
  sec:[
  ["Texture",[
    "Texture describes how musical lines combine. Monophony is a single melodic line without accompaniment, such as Gregorian chant or someone singing alone. Homophony is a melody with chordal accompaniment, the most common texture in popular music and hymns. Polyphony combines two or more independent melodies at once, as in a Bach fugue or a round.",
    "Heterophony, common in many world traditions, has several performers playing slightly different versions of the same melody simultaneously. Texture can change within a piece to create contrast."]],
  ["Counterpoint",[
    "Counterpoint is the art of combining independent melodic lines that sound good together, central to Renaissance and Baroque music. A canon or round has voices imitating the same melody at different times, as in “Row, Row, Row Your Boat” or Pachelbel's Canon.",
    "A fugue, perfected by J. S. Bach, introduces a theme (the subject) in one voice, then imitates it in other voices in turn, weaving them into an intricate whole. Johann Joseph Fux's treatise Gradus ad Parnassum (1725) taught counterpoint to generations, including Haydn, Mozart, and Beethoven."]],
  ["Repetition and contrast",[
    "Musical form is the overall structure of a piece, built from repetition, contrast, and variation. Letters label sections: AB (binary form) has two contrasting sections; ABA (ternary form) presents a section, a contrasting middle, and a return, as in many minuets and arias.",
    "Strophic form repeats the same music for each verse of a song, as in many folk songs and hymns; through-composed songs have new music throughout. Theme and variations presents a melody and then transforms it in a series of variations, such as Mozart's variations on “Twinkle, Twinkle, Little Star.”"]],
  ["Classical forms",[
    "The rondo alternates a recurring main theme with contrasting episodes (ABACA). Sonata form, the most important form of the Classical era, has three main parts: an exposition, presenting two contrasting themes in different keys; a development, which fragments and transforms the themes through different keys, building tension; and a recapitulation, returning the themes in the home key, often followed by a coda.",
    "Larger works combine movements: a symphony usually has four movements (often fast, slow, minuet or scherzo, fast); a concerto features a soloist with orchestra, typically in three movements; a sonata is for one or two instruments; a string quartet is for two violins, viola, and cello."]],
  ["Vocal and dramatic forms",[
    "Vocal genres include the art song (German Lied), the madrigal, the motet, the mass, which sets the fixed texts of the Catholic liturgy (Kyrie, Gloria, Credo, Sanctus, Agnus Dei), the oratorio (a large sacred work for chorus, soloists, and orchestra, such as Handel's Messiah), and the cantata.",
    "Opera combines singing, acting, orchestra, and staging; its main elements are arias (expressive solo songs), recitatives (speech-like singing that advances the plot), ensembles, and choruses."]],
  ["Why form matters",[
    "Form helps listeners follow and remember music, creating expectations that composers fulfill or cleverly defeat. Recognizing when a theme returns in a recapitulation or a chorus is one of the pleasures of listening.",
    "Many traditions have their own forms: the Indian raga performance progresses from a slow, free-rhythm alap to faster, rhythmic sections; the 12-bar blues repeats a fixed chord pattern; and jazz performances typically state a tune's “head,” then improvise over its chord structure before returning to the head."]]
  ],
  terms:[["Monophony","A single unaccompanied melody."],["Homophony","Melody with chordal accompaniment."],["Polyphony","Several independent melodies at once."],["Counterpoint","The art of combining independent lines."],["Fugue","A polyphonic form built on imitation of a subject."],["Sonata form","Exposition, development, recapitulation."],["Theme and variations","A melody followed by transformations."]],
  w:"Texture and form organize music's layers and structure, helping listeners follow and appreciate everything from fugues to pop songs.",
  src:["Texture (music)","Counterpoint","Fugue","Musical form","Ternary form","Sonata form","Symphony"],
  q:[["What is a single unaccompanied melody called?","Monophony","Homophony","Polyphony","Heterophony"],
     ["Which texture is most common in popular music?","Homophony","Monophony","Polyphony","Heterophony"],
     ["Who perfected the fugue?","J. S. Bach","Mozart","Beethoven","Chopin"],
     ["What is the middle part of sonata form called?","The development","The exposition","The recapitulation","The coda"],
     ["How many movements does a symphony usually have?","Four","Three","Two","Five"],
     ["What are the speech-like sung parts of opera called?","Recitatives","Arias","Choruses","Overtures"]]},

{ t:"Expression: Dynamics, Timbre, and Articulation", s:"How music is shaped in performance",
  sec:[
  ["Dynamics",[
    "Dynamics are the levels of loudness in music, marked with Italian terms: pianissimo (pp, very soft), piano (p, soft), mezzo-piano (mp), mezzo-forte (mf), forte (f, loud), and fortissimo (ff, very loud). Crescendo means gradually getting louder; diminuendo or decrescendo means getting softer. Sforzando (sfz) is a sudden strong accent.",
    "The piano's full name, pianoforte (“soft-loud”), reflects its ability, new in the early 18th century, to play both softly and loudly depending on touch, unlike the harpsichord."]],
  ["Timbre and orchestration",[
    "Timbre, or tone color, distinguishes instruments and voices. Words such as bright, dark, warm, nasal, breathy, and brassy describe it. Players change timbre through technique: string players use mutes or play near the bridge for a glassy sound; trumpeters use mutes; singers vary vowel shapes.",
    "Orchestration is the art of combining instrumental colors. Composers such as Rimsky-Korsakov, who wrote a textbook on orchestration, and Ravel, whose orchestration of Mussorgsky's Pictures at an Exhibition is famous, were masters. Ravel's Boléro (1928) repeats the same melody many times, changing only the orchestration and building a long crescendo."]],
  ["Articulation",[
    "Articulation describes how notes are attacked and connected. Legato notes are smooth and connected; staccato notes are short and detached; accents emphasize particular notes; tenuto means holding a note for its full value. Pizzicato means plucking a string instrument instead of bowing.",
    "Phrasing, shaping groups of notes into musical sentences, is like breathing in speech. Rubato (“stolen time”) means flexibly speeding up and slowing down for expression, especially in Romantic piano music such as Chopin's."]],
  ["Ornamentation",[
    "Ornaments are decorations added to melodies: trills (rapid alternation of two notes), mordents, turns, and grace notes. Baroque musicians were expected to add ornaments, especially on repeats. In many traditions, ornamentation is central to style: the slides and bends of the blues, the melismas of gospel and R&B singing (many notes on one syllable), and the gamakas of Indian classical music.",
    "Vibrato, a slight regular fluctuation in pitch, adds warmth to singing and string playing; its use has varied by era and style."]],
  ["Interpretation",[
    "Notation never captures everything. Performers interpret music, choosing tempo, dynamics, phrasing, and emphasis, so two performances of the same piece can sound very different. Glenn Gould's two recordings of Bach's Goldberg Variations, in 1955 and 1981, are famous examples, the first brisk and the second slow and meditative.",
    "The historically informed performance movement, which grew from the 1960s, seeks to perform older music as it might have sounded originally, with period instruments, gut strings, and historical techniques."]],
  ["Improvisation",[
    "Improvisation is creating music spontaneously during performance. It is central to jazz, Indian classical music, the blues, flamenco, organ playing, and many folk traditions, and was common in Western classical music: Bach, Mozart, and Beethoven were celebrated improvisers, and concerto cadenzas were originally improvised.",
    "Improvisers draw on deep knowledge of scales, harmony, rhythm, and a stylistic vocabulary, combining preparation with in-the-moment creativity."]]
  ],
  terms:[["Dynamics","Levels of loudness."],["Crescendo","Gradually getting louder."],["Orchestration","Combining instrumental colors."],["Legato and staccato","Smooth vs. short, detached notes."],["Rubato","Flexible tempo for expression."],["Ornament","A melodic decoration such as a trill."],["Improvisation","Creating music spontaneously."]],
  w:"Expression, dynamics, timbre, phrasing, and improvisation are what turn notes on a page into living music.",
  src:["Dynamics (music)","Timbre","Orchestration","Articulation (music)","Tempo rubato","Ornament (music)","Musical improvisation"],
  q:[["What does pianissimo mean?","Very soft","Very loud","Moderately loud","Gradually louder"],
     ["What does pianoforte mean?","Soft-loud","Little piano","Strong keys","Played instrument"],
     ["Which Ravel work repeats a melody while building orchestration?","Boléro","Daphnis et Chloé","La Valse","Pavane"],
     ["What does pizzicato mean?","Plucking a string","Bowing smoothly","Playing loudly","Sliding between notes"],
     ["What is flexible tempo for expression called?","Rubato","Vibrato","Staccato","Legato"],
     ["Whose two recordings of the Goldberg Variations are famous?","Glenn Gould's","Vladimir Horowitz's","Arthur Rubinstein's","Martha Argerich's"]]},

{ t:"How Songs Are Built", s:"Verse, chorus, hooks, and lyrics",
  sec:[
  ["Song forms",[
    "Popular songs typically use a few standard structures. The verse-chorus form alternates verses, which tell the story with changing lyrics, and a chorus, which repeats the same words and melody and contains the song's main hook and often its title. Many songs add an intro, a pre-chorus building to the chorus, a bridge offering contrast, and an outro.",
    "The 32-bar AABA form, standard in Tin Pan Alley and Broadway songs of the 1920s–1950s, such as “Over the Rainbow,” has two A sections, a contrasting B section (the bridge or “middle eight”), and a return to A."]],
  ["The 12-bar blues",[
    "The 12-bar blues is one of the most influential forms in popular music. It uses three four-bar phrases over a fixed chord pattern: four bars on I, two on IV and two on I, then one on V, one on IV, and two on I (with variations). Lyrics often follow an AAB pattern: a line is sung, repeated, and answered by a rhyming line.",
    "The 12-bar blues underlies countless blues, jazz, rock and roll, and R&B songs, from “Hound Dog” to “Johnny B. Goode.”"]],
  ["Hooks",[
    "A hook is a catchy musical or lyrical phrase that grabs attention and sticks in memory, often in the chorus. Hooks can be melodic, rhythmic, a guitar riff (as in the Rolling Stones' “(I Can't Get No) Satisfaction”), or a distinctive sound.",
    "Songs that get stuck in the head are called earworms; research suggests they often have simple, repetitive melodies with some unusual intervals. Songwriters craft hooks carefully, and modern pop often places a hook within the first seconds to capture listeners on streaming platforms."]],
  ["Lyrics",[
    "Lyrics combine poetry with music. Effective lyrics fit the rhythm and melody, use rhyme, imagery, and memorable phrases, and tell stories or express emotions. Rhyme schemes, internal rhymes, and wordplay are central to genres such as hip-hop, where rapping emphasizes rhythmic delivery (flow).",
    "Great lyricists include Cole Porter, Bob Dylan, the first songwriter to win the Nobel Prize in Literature (2016), Joni Mitchell, and Kendrick Lamar, who won the Pulitzer Prize for Music in 2018, the first non-classical, non-jazz artist to do so."]],
  ["Arrangement and production",[
    "An arrangement determines which instruments play what and when, building intensity across a song, for example adding drums in the second verse and harmonies in the final chorus. Many songs build to a climax with a key change or a final, fuller chorus.",
    "In recording studios, producers shape a song's sound through instrumentation, effects, editing, and mixing. Producers such as George Martin (the Beatles), Phil Spector (the “Wall of Sound”), Quincy Jones (Michael Jackson's Thriller), and Max Martin (many pop hits since the 1990s) have been as influential as performers."]],
  ["Writing a song",[
    "Songwriters work in many ways: starting with a melody, a chord progression, a lyric idea, a title, or a beat. Professional songwriting often involves collaboration; famous partnerships include Lennon and McCartney, Rodgers and Hammerstein, Holland–Dozier–Holland at Motown, and Elton John and Bernie Taupin.",
    "Understanding song structure helps listeners appreciate craft and anticipate what comes next, and is the first step for anyone who wants to write songs."]]
  ],
  terms:[["Verse and chorus","Changing story sections and a repeated main section."],["Bridge","A contrasting section in a song."],["AABA form","The 32-bar form of classic popular songs."],["12-bar blues","A three-phrase chord pattern central to American music."],["Hook","A catchy, memorable musical phrase."],["Earworm","A song stuck in the head."],["Arrangement","How instruments and parts are organized in a song."]],
  w:"Understanding how songs are built, from the 12-bar blues to the verse-chorus form, reveals the craft behind the music we hear every day.",
  src:["Song structure","Verse–chorus form","Thirty-two-bar form","Twelve-bar blues","Hook (music)","Earworm","Record producer"],
  q:[["What section usually contains the song's title and main hook?","The chorus","The verse","The bridge","The intro"],
     ["What form is used in Over the Rainbow?","32-bar AABA","12-bar blues","Verse-chorus","Through-composed"],
     ["How many bars long is the classic blues form?","12","8","16","32"],
     ["Who was the first songwriter to win the Nobel Prize in Literature?","Bob Dylan","Leonard Cohen","Joni Mitchell","Paul McCartney"],
     ["Who won the 2018 Pulitzer Prize for Music?","Kendrick Lamar","Jay-Z","Beyoncé","Taylor Swift"],
     ["Who produced Michael Jackson's Thriller?","Quincy Jones","Phil Spector","George Martin","Max Martin"]]},

{ t:"Tuning and the World's Scales", s:"Temperament, microtones, and musical systems",
  sec:[
  ["The tuning problem",[
    "Tuning instruments involves a mathematical puzzle. Intervals based on pure ratios, such as 3:2 for fifths and 5:4 for major thirds, sound beautifully in tune, but they do not fit together perfectly: stacking twelve pure fifths overshoots seven octaves by a small amount, called the Pythagorean comma. Tuning systems, called temperaments, compromise in different ways.",
    "Just intonation uses pure ratios but works well only in one key. Meantone temperament, common in the Renaissance and Baroque, favored pure thirds but made some keys unusable."]],
  ["Equal temperament",[
    "Equal temperament divides the octave into 12 exactly equal half steps, so every key sounds equally (slightly) out of tune but all keys are usable, allowing free modulation. It became standard for pianos in the 19th century.",
    "Bach's The Well-Tempered Clavier (Book 1, 1722; Book 2, 1742), with preludes and fugues in all 24 major and minor keys, demonstrated the possibilities of well-tempered tuning, systems in which all keys were playable though each had its own character, a precursor to equal temperament."]],
  ["Microtones",[
    "Many musical traditions use intervals smaller than the Western half step, called microtones. Arabic maqam music uses intervals around three-quarters of a whole tone, giving its characteristic sound; Persian dastgah and Turkish makam systems also use such intervals.",
    "Some Western composers, such as Harry Partch, who built his own instruments for a 43-tone scale, and Ivan Wyschnegradsky, explored microtonal music, and microtonal bands such as King Gizzard and the Lizard Wizard have brought it to rock."]],
  ["Indian classical music",[
    "Indian classical music is built on raga, a melodic framework with a particular set of notes, characteristic phrases, ornaments, and mood, sometimes associated with a time of day or season, and tala, the rhythmic cycle. The octave is theoretically divided into 22 shrutis, microtonal intervals, from which the notes of each raga are drawn.",
    "Performances are largely improvised within the rules of the raga, over a drone usually provided by the tanpura. There are two main traditions: Hindustani in the north and Carnatic in the south."]],
  ["East Asian and other scales",[
    "Traditional Chinese music commonly uses pentatonic scales. Japanese music uses several pentatonic scales, some including half steps, such as the in scale, giving a distinctive sound. Indonesian gamelan orchestras use two tuning systems, slendro (five roughly equal notes) and pelog (seven unequal notes); each gamelan set is tuned uniquely, so instruments cannot be swapped between ensembles.",
    "African music uses many scale systems, and the blues' “blue notes,” pitches between major and minor, may reflect African roots."]],
  ["Different ears",[
    "Musical systems are cultural: what sounds in tune, consonant, or expressive in one tradition may sound strange in another. Research with people unfamiliar with Western music, such as a 2016 study of the Tsimané in the Bolivian Amazon, found they did not prefer consonant over dissonant chords, suggesting such preferences are partly learned.",
    "Exploring the world's tuning systems broadens musical understanding and reveals how much the familiar sound of Western music rests on particular historical choices."]]
  ],
  terms:[["Temperament","A system of tuning intervals."],["Pythagorean comma","The small discrepancy between pure fifths and octaves."],["Equal temperament","Dividing the octave into 12 equal half steps."],["Microtone","An interval smaller than a half step."],["Maqam","A melodic mode system in Arabic music."],["Raga","A melodic framework in Indian classical music."],["Slendro and pelog","The two tuning systems of gamelan."]],
  w:"Tuning systems reveal that the sounds we take for granted are cultural choices, and that the world's music offers many other beautiful possibilities.",
  src:["Musical temperament","Pythagorean comma","Equal temperament","The Well-Tempered Clavier","Microtonal music","Raga","Gamelan"],
  q:[["What is the discrepancy from stacking twelve pure fifths called?","The Pythagorean comma","The tritone","The octave","The semitone"],
     ["Which tuning divides the octave into 12 equal steps?","Equal temperament","Just intonation","Meantone","Pythagorean tuning"],
     ["Which Bach work has preludes and fugues in all 24 keys?","The Well-Tempered Clavier","The Goldberg Variations","The Art of Fugue","The Brandenburg Concertos"],
     ["Which music uses maqam?","Arabic music","Indian music","Chinese music","Japanese music"],
     ["What provides the drone in Indian classical music?","The tanpura","The tabla","The sitar","The sarod"],
     ["What are the two tuning systems of gamelan?","Slendro and pelog","Raga and tala","Maqam and iqa","Yin and yang"]]}

);


/* ---- from music-03.js ---- */
/* MUSIC FOUNDATIONS, part 3: Unit 2 Instruments and Voice, chapters 1-5 */
COURSES.music.units.push({ t:"Instruments and Voice", ch:[

{ t:"The Human Voice", s:"The first instrument",
  sec:[
  ["How singing works",[
    "The voice is the oldest instrument. Air from the lungs passes through the larynx, where two folds of tissue, the vocal folds (often called vocal cords), vibrate. The pitch depends on how fast they vibrate: tighter, thinner folds vibrate faster and give higher notes. The raw buzz is then shaped by the throat, mouth, and nasal cavities, which act as resonators and give each voice its color.",
    "Singers train breath support, using the diaphragm and the muscles of the torso to control air pressure, so that tone stays steady and phrases can be long. Good posture, relaxed jaw and throat, and clear vowels are basics in nearly every vocal tradition."]],
  ["Voice types",[
    "Classical music divides voices by range and color. The four main types used in choirs are soprano (highest female voice), alto (lower female voice), tenor (higher male voice), and bass (lowest male voice), abbreviated SATB. Opera adds in-between types: mezzo-soprano between soprano and alto, baritone between tenor and bass, and contralto as the deepest female voice.",
    "The countertenor is a male voice singing in the alto or soprano range, usually using a light head voice. Countertenors revived the roles once written for castrati, male singers castrated before puberty to keep a high voice, a practice that flourished in Baroque Italian opera and ended in the 19th century."]],
  ["Registers and techniques",[
    "A voice has registers, regions that feel and sound different. Chest voice is the full, speech-like lower register; head voice is lighter and higher; falsetto is a breathy, thin upper register used especially by men, as in much soul and disco. Mixing these smoothly is a central skill.",
    "Vibrato is a regular, slight wavering of pitch that adds warmth. Bel canto (Italian for 'beautiful singing') is the 18th- and 19th-century Italian ideal of smooth, agile, evenly produced tone. Belting, common in musical theater and pop, carries a strong chest-dominant sound high into the range."]],
  ["Voices around the world",[
    "Traditions shape the voice differently. Tuvan and Mongolian throat singers (khoomei) produce two or more pitches at once by amplifying overtones. Yodeling, from the Alps and elsewhere, flips rapidly between chest and head voice. Bulgarian women's choirs use a bright, open, chest-heavy sound with close dissonances.",
    "In Indian classical music, singers ornament notes with slides and oscillations; in Arabic music, singers use microtonal inflections and long melismas. Gospel, blues, and soul singers use bending, growls, and runs, styles that shaped virtually all modern popular singing."]],
  ["Choirs and a cappella",[
    "A choir or chorus is a group of singers, usually arranged in sections. A cappella means singing without instruments (literally 'in the chapel style'). Barbershop quartets, doo-wop groups, and modern college a cappella groups continue the tradition.",
    "Singing together is found in every known human culture, from work songs to lullabies, and choral singing remains one of the most widely practiced forms of amateur music-making."]]
  ],
  terms:[["Vocal folds","Tissue in the larynx whose vibration makes vocal sound."],["SATB","Soprano, alto, tenor, bass: the four standard choir parts."],["Falsetto","A light, high register above the normal voice."],["A cappella","Singing without instrumental accompaniment."],["Bel canto","Italian ideal of smooth, agile, beautiful singing."]],
  w:"Every melody you hum uses this instrument; understanding voice types helps you hear opera, choirs, and pop singers more clearly.",
  src:["Human voice","Voice type","Vocal register","A cappella","Throat singing"],
  q:[
  ["Which part of the body contains the vocal folds?","The larynx","The trachea","The diaphragm","The pharynx only"],
  ["What does SATB stand for?","Soprano, alto, tenor, bass","Solo, accompaniment, tempo, beat","Soprano, alto, treble, baritone","Strings, alto, trumpets, bass"],
  ["Which is the lowest standard male voice?","Bass","Tenor","Baritone","Countertenor"],
  ["What does 'a cappella' mean?","Singing without instruments","Singing in falsetto","Singing in a large hall","Singing in Italian"],
  ["Which tradition is known for producing multiple pitches at once through overtones?","Tuvan throat singing","Bel canto","Barbershop","Gregorian chant"],
  ["What is a countertenor?","A male voice singing in the alto or soprano range","The lowest female voice","A tenor who sings bass parts","A choir conductor"]]},

{ t:"String Instruments", s:"Bowed and plucked",
  sec:[
  ["How strings make sound",[
    "String instruments (chordophones) produce sound from vibrating strings. Pitch depends on the string's length, tension, and thickness: shorter, tighter, thinner strings sound higher. Players change pitch by pressing (stopping) strings against a fingerboard to shorten the vibrating length.",
    "A string alone is quiet; the body of the instrument acts as a resonator, amplifying the vibration. Strings can be set in motion by bowing, plucking, or striking."]],
  ["The violin family",[
    "The orchestra's string section uses the violin family: violin, viola, cello (violoncello), and double bass. The violin is the highest and smallest; the viola is slightly larger with a darker tone; the cello, held between the knees, has a rich, singing middle-low range; the double bass provides the foundation.",
    "These instruments were perfected in northern Italy in the 16th–18th centuries. The workshops of Cremona, especially Antonio Stradivari and Giuseppe Guarneri 'del Gesù,' produced violins still considered the finest ever made, worth millions of dollars today."]],
  ["Bowing and other techniques",[
    "The bow is a stick strung with horsehair coated in rosin, which makes the hair grip the string. Arco means play with the bow; pizzicato means pluck with the fingers. Other techniques include tremolo (rapid repeated bowing), vibrato (rocking the finger to vary pitch slightly), double stops (two strings at once), harmonics (light touches producing high, flute-like tones), and col legno (striking with the wood of the bow).",
    "Mutes, clipped onto the bridge, give a veiled, softer sound, marked con sordino."]],
  ["Plucked strings",[
    "Plucked strings include the harp, one of the oldest instruments, found in ancient Mesopotamia and Egypt. The modern concert harp has 47 strings and seven pedals that shift each note name up or down a semitone, allowing it to play in any key.",
    "The lute family was central to Renaissance music, and its Arabic ancestor, the oud, is still at the heart of Middle Eastern music. Other plucked instruments include the mandolin, banjo (developed from West African instruments by enslaved Africans in the Americas), ukulele (Hawaiian, adapted from a Portuguese instrument), sitar (India), koto (Japan), and guzheng (China). The guitar gets its own chapter."]],
  ["Struck and other strings",[
    "Some string instruments are struck, such as the hammered dulcimer and the cimbalom of Hungary, played with small hammers. The piano is technically both a string and a percussion instrument, since hammers strike its strings.",
    "Bowed strings exist across the world too: the Chinese erhu has two strings and a snakeskin-covered resonator; the Indian sarangi is bowed with many sympathetic strings that ring along; and the Norwegian Hardanger fiddle also has sympathetic strings beneath the playing strings."]]
  ],
  terms:[["Chordophone","Instrument whose sound comes from vibrating strings."],["Pizzicato","Plucking the strings instead of bowing."],["Arco","Playing with the bow."],["Rosin","Resin applied to bow hair so it grips the string."],["Sympathetic strings","Unplayed strings that vibrate in response to others."]],
  w:"Strings form the core of the orchestra and many folk traditions; knowing their techniques lets you hear what composers ask for.",
  src:["String instrument","Violin","Antonio Stradivari","Harp","Pizzicato"],
  q:[
  ["Which instrument is the lowest member of the orchestral violin family?","Double bass","Cello","Viola","Bass guitar"],
  ["What does 'pizzicato' mean?","Pluck the strings","Use the bow","Play very softly","Play with a mute"],
  ["Which Italian city was home to Stradivari's workshop?","Cremona","Venice","Florence","Naples"],
  ["What do the seven pedals on a concert harp do?","Shift note names up or down a semitone","Sustain the sound","Change the volume","Mute the strings"],
  ["The banjo developed from instruments from which region?","West Africa","Hawaii","Spain","Ireland"],
  ["What is rosin used for?","Helping bow hair grip the string","Tuning the strings","Polishing the body","Muting the sound"]]},

{ t:"Woodwinds", s:"Air, reeds, and keys",
  sec:[
  ["What makes a woodwind",[
    "Woodwinds are wind instruments in which the player's breath sets a column of air vibrating, using either an edge or a reed. Despite the name, not all are made of wood: modern flutes are metal, and saxophones are brass. What unites them is how the sound starts, not the material.",
    "Players change pitch by opening and closing holes along the tube, usually with keys, which changes the effective length of the air column. Overblowing, increasing air pressure, makes the instrument jump to higher harmonics."]],
  ["Flutes",[
    "Flutes produce sound when air is blown across an edge, splitting the airstream. The modern concert flute is held sideways (transverse); its smaller cousin the piccolo sounds an octave higher and is the highest-pitched instrument in the orchestra. The recorder, blown from the end, was widely used in the Renaissance and Baroque and is a common school instrument today.",
    "Flutes are among the oldest known instruments: bone flutes from caves in Germany are around 40,000 years old. Panpipes, the Japanese shakuhachi, and the Indian bansuri are other edge-blown flutes."]],
  ["Single reeds: clarinet and saxophone",[
    "The clarinet uses a single reed, a thin piece of cane clamped to the mouthpiece, which vibrates against it. Its tone is warm and has a famously wide range, from a dark, hollow low register to brilliant highs. It entered the orchestra in the 18th century; Mozart loved it and wrote a Clarinet Concerto and Clarinet Quintet.",
    "The saxophone was invented by Belgian instrument maker Adolphe Sax around 1840. It also uses a single reed but has a conical metal body. Though rarely used in the orchestra, it became central to military bands, jazz, and rock. Common types are soprano, alto, tenor, and baritone."]],
  ["Double reeds: oboe and bassoon",[
    "The oboe uses a double reed, two blades of cane that vibrate against each other. Its tone is penetrating and nasal-sweet, and because its pitch is stable, the orchestra traditionally tunes to the oboe's A. The English horn (cor anglais) is a larger, lower oboe with a melancholy sound.",
    "The bassoon is the bass of the woodwinds, its long tube folded back on itself. The contrabassoon sounds an octave lower still. Double reeds appear worldwide too, from the Middle Eastern zurna to the Indian shehnai and the Chinese suona."]],
  ["Woodwinds in the orchestra",[
    "A standard symphony orchestra includes pairs or threes of flutes, oboes, clarinets, and bassoons, with occasional piccolo, English horn, bass clarinet, and contrabassoon. Each has a distinct color, and composers assign them solos to stand out against the strings.",
    "A woodwind quintet traditionally includes flute, oboe, clarinet, bassoon, and French horn, even though the horn is a brass instrument, because it blends so well."]]
  ],
  terms:[["Reed","Thin vibrating blade of cane that starts the sound in many woodwinds."],["Single reed","One reed vibrating against a mouthpiece (clarinet, sax)."],["Double reed","Two reeds vibrating together (oboe, bassoon)."],["Piccolo","Small flute, the orchestra's highest instrument."],["Overblowing","Increasing breath pressure to reach higher harmonics."]],
  w:"Woodwinds give the orchestra its distinct solo colors and gave jazz its signature saxophone sound.",
  src:["Woodwind instrument","Flute","Clarinet","Saxophone","Oboe"],
  q:[
  ["Who invented the saxophone?","Adolphe Sax","Antonio Stradivari","Theobald Boehm","Johann Denner"],
  ["Which instrument does the orchestra traditionally tune to?","Oboe","Flute","Clarinet","Violin"],
  ["The clarinet uses what kind of reed?","Single reed","Double reed","No reed","Metal reed"],
  ["Which is the highest-pitched instrument in the orchestra?","Piccolo","Flute","Oboe","Violin"],
  ["Why is the saxophone classified as a woodwind despite being metal?","It uses a reed to start the sound","It is played sideways","It has finger holes","It was first made of wood"],
  ["Which is the bass of the woodwind section?","Bassoon","English horn","Tuba","Bass clarinet only"]]},

{ t:"Brass Instruments", s:"Lips and tubes",
  sec:[
  ["How brass works",[
    "In brass instruments the player's lips buzz into a cup-shaped mouthpiece, and the buzz sets the air in a long tube vibrating. The material is less important than the method: the defining feature is lip vibration.",
    "A tube of fixed length produces a series of notes called the harmonic series. By changing lip tension and air speed, players move between these harmonics. Early trumpets and horns had no valves and could only play these 'natural' notes, which is why bugle calls use just a few pitches."]],
  ["Valves and slides",[
    "Valves, invented in the early 19th century, let players instantly add extra lengths of tubing, filling in the gaps between harmonics so brass instruments could play every chromatic note. This transformed brass from signaling and fanfare instruments into full melodic voices.",
    "The trombone uses a slide instead of valves, changing tube length continuously. This allows smooth glissandos, the sliding sound heard in jazz and comedy."]],
  ["The main brass instruments",[
    "The trumpet is the highest brass instrument, bright and powerful, used for fanfares, solos, and jazz. The French horn (or simply horn) has a long coiled tube and a mellow, noble tone; players put a hand in the bell to adjust tone and pitch. The trombone is a tenor-to-bass voice, and the tuba is the bass of the brass section.",
    "Other brass include the cornet, flugelhorn, euphonium, and baritone horn, common in brass and military bands, and the sousaphone, a tuba wrapped around the body for marching."]],
  ["Mutes and colors",[
    "Brass players can insert mutes into the bell to change the sound. A straight mute makes it thin and nasal; a cup mute softens it; the Harmon (wah-wah) mute gives the buzzy, intimate sound associated with Miles Davis; and a plunger, literally a sink plunger, creates 'wah' effects used in early jazz.",
    "Horn players can also produce a stopped sound, pushing the hand deep into the bell for a brassy, distant effect."]],
  ["Brass traditions",[
    "Brass instruments have deep roots in ceremony and the military: ancient trumpets were found in Tutankhamun's tomb, and horns were used for hunting and signaling. British brass bands, often formed by mining and factory communities in the 19th century, remain a lively amateur tradition.",
    "In New Orleans, brass bands play at parades and jazz funerals; in Mexico, banda music features brass; and Balkan brass bands are famous for fast, virtuosic dance music."]]
  ],
  terms:[["Mouthpiece","Cup-shaped piece into which brass players buzz their lips."],["Valve","Mechanism that adds tubing to change pitch."],["Harmonic series","The natural set of pitches a tube produces."],["Glissando","A slide between pitches."],["Mute","Device placed in the bell to change tone."]],
  w:"Brass gives music its power and brilliance, from fanfares and symphonies to jazz and marching bands.",
  src:["Brass instrument","Trumpet","French horn","Trombone","Brass band"],
  q:[
  ["What starts the sound in a brass instrument?","The player's buzzing lips","A reed","Air across an edge","A vibrating string"],
  ["Which brass instrument uses a slide instead of valves?","Trombone","Tuba","French horn","Trumpet"],
  ["What did valves allow brass instruments to do?","Play all chromatic notes","Play louder","Play in tune with strings only","Sound an octave higher"],
  ["Which is the bass of the brass section?","Tuba","Trombone","Euphonium","Flugelhorn"],
  ["Which mute is associated with Miles Davis's sound?","Harmon (wah-wah) mute","Straight mute","Cup mute","Practice mute"],
  ["Why can a bugle play only a few notes?","It has no valves, so it plays only natural harmonics","It is too short","It has a single reed","It is made of wood"]]},

{ t:"Percussion", s:"Struck, shaken, scraped",
  sec:[
  ["Pitched and unpitched",[
    "Percussion instruments make sound when struck, shaken, or scraped. They are the most widespread instruments on Earth. They divide into pitched (tuned) instruments, which play definite notes, and unpitched instruments, which give a sound without a clear pitch.",
    "In instrument classification, membranophones produce sound with a stretched skin (drums), and idiophones vibrate their whole body (cymbals, bells, xylophones, rattles). The Hornbostel–Sachs system, devised in 1914, organizes all instruments into idiophones, membranophones, chordophones, and aerophones, with electrophones added later."]],
  ["Orchestral percussion",[
    "The timpani (kettledrums) are large copper bowls with skins that can be tuned to specific pitches, often using pedals. They supply drama and rhythmic weight, and have been part of the orchestra since the Baroque.",
    "Other orchestral percussion includes the bass drum, snare drum (with metal wires that buzz against the lower head), cymbals, triangle, tambourine, gong and tam-tam, and pitched mallet instruments: glockenspiel (metal bars, bright), xylophone (wooden bars, dry), marimba (wooden bars with resonators, warm), vibraphone (metal bars with motor-driven vibrato), and tubular bells (chimes)."]],
  ["The drum kit",[
    "The drum kit, developed in the early 20th century in the United States, lets one player handle several instruments. It usually includes a bass drum played with a foot pedal, a snare drum, tom-toms, a hi-hat (two cymbals closed by a foot pedal), a ride cymbal, and crash cymbals.",
    "It was shaped by New Orleans jazz drummers and became the engine of jazz, rock, funk, and pop. Basic patterns such as the backbeat, the snare on beats 2 and 4, define much popular music."]],
  ["World percussion",[
    "Africa has extraordinarily rich drumming traditions: the djembe of West Africa, the talking drum, whose pitch is changed by squeezing its cords to imitate speech tones, and ensembles layering interlocking rhythms. Latin American music uses congas, bongos, timbales, claves, maracas, guiros, and the cajón, a box drum from Peru.",
    "India's tabla (a pair of hand drums) and mridangam carry complex rhythmic systems. Japan's taiko drumming is powerful and theatrical, Indonesia's gamelan uses tuned gongs and metallophones, and Trinidad invented the steelpan, tuned from oil drums, in the 20th century."]],
  ["Rhythm as language",[
    "Percussionists often learn patterns through spoken syllables: Indian tabla players use bols such as 'dha' and 'tin,' and many drumming traditions teach rhythms vocally before on the instrument.",
    "Percussion can carry melody and harmony as well as rhythm, and modern composers have written whole works for percussion ensembles, such as Edgard Varèse's Ionisation (1931)."]]
  ],
  terms:[["Idiophone","Instrument whose body itself vibrates (bells, cymbals)."],["Membranophone","Instrument with a stretched vibrating skin (drums)."],["Timpani","Tunable orchestral kettledrums."],["Hi-hat","Two cymbals on a stand closed by a foot pedal."],["Backbeat","Accents on beats 2 and 4."]],
  w:"Rhythm is the heartbeat of almost all music; percussion connects orchestras, rock bands, and drumming traditions worldwide.",
  src:["Percussion instrument","Hornbostel–Sachs","Timpani","Drum kit","Steelpan"],
  q:[
  ["Which orchestral drums can be tuned to specific pitches?","Timpani","Snare drum","Bass drum","Tom-toms"],
  ["What is an idiophone?","An instrument whose whole body vibrates","A drum with a skin","A string instrument","A wind instrument"],
  ["Which country invented the steelpan?","Trinidad and Tobago","Jamaica","Cuba","Brazil"],
  ["Which mallet instrument has metal bars and motor-driven vibrato?","Vibraphone","Marimba","Xylophone","Glockenspiel"],
  ["What makes the African talking drum's pitch change?","Squeezing its cords","Changing sticks","Pouring water inside","Turning tuning pegs"],
  ["Who devised the instrument classification system of 1914 (with Sachs)?","Erich von Hornbostel","Carl Orff","Edgard Varèse","Béla Bartók"]]}

]});


/* ---- from music-04.js ---- */
/* MUSIC FOUNDATIONS, part 4: Unit 2 chapters 6-9 */
COURSES.music.units[1].ch.push(

{ t:"Keyboards and the Piano", s:"Eighty-eight keys",
  sec:[
  ["Early keyboards",[
    "Keyboard instruments let one player sound many notes at once by pressing keys. The pipe organ is the oldest: its ancestor, the hydraulis, was invented in Hellenistic Alexandria in the 3rd century BCE. By the Middle Ages organs were central to church music, and large organs today have thousands of pipes controlled from several keyboards (manuals) and a pedalboard.",
    "The harpsichord, important from the Renaissance through the Baroque, plucks its strings with small quills or plectra. It cannot vary volume by touch. The clavichord, a quiet domestic instrument, strikes strings with metal tangents and allows subtle expression."]],
  ["The invention of the piano",[
    "Around 1700, Bartolomeo Cristofori, working in Florence for the Medici, invented the piano. He called it the gravicembalo col piano e forte, a harpsichord that could play soft and loud, because its hammers struck strings with force depending on how hard the key was pressed. The name was shortened to pianoforte and then piano.",
    "Over the 18th and 19th centuries the piano grew larger and louder, with iron frames, more keys, and heavier strings. The modern piano has 88 keys (52 white and 36 black), covering more than seven octaves."]],
  ["How the piano works",[
    "When a key is pressed, a felt-covered hammer strikes the strings and falls back, while a damper lifts to let the strings ring; releasing the key lets the damper fall and stop the sound. Most notes have two or three strings tuned in unison for volume.",
    "Pianos usually have pedals: the right (sustain or damper) pedal lifts all dampers so notes ring on; the left (una corda or soft) pedal softens the sound; and on many grand pianos the middle (sostenuto) pedal sustains only notes already held. Grand pianos have horizontal strings; uprights have vertical strings to save space."]],
  ["The piano's central role",[
    "From the late 18th century the piano became the most important instrument in Western music. Composers such as Mozart, Beethoven, Chopin, Liszt, and Debussy wrote masterpieces for it, and middle-class homes acquired pianos as a sign of culture. It was the main tool for composing, teaching harmony, accompanying singers, and bringing orchestral music into homes through arrangements.",
    "In jazz, ragtime, blues, gospel, and pop the piano remained central, from Scott Joplin and Duke Ellington to Ray Charles, Elton John, and Alicia Keys."]],
  ["Electric keyboards",[
    "The 20th century added electric and electronic keyboards: the Hammond organ (1935), with its rotating Leslie speaker, central to gospel, jazz, and rock; the Fender Rhodes electric piano; and synthesizers. Digital pianos and keyboards now use sampled sounds.",
    "Keyboard skills remain a foundation for musicians of all kinds, because the layout makes harmony visible and easy to understand."]]
  ],
  terms:[["Harpsichord","Keyboard instrument that plucks its strings."],["Pianoforte","Original name of the piano, meaning soft-loud."],["Sustain pedal","Lifts dampers so notes keep ringing."],["Manual","A keyboard on an organ played with the hands."],["Hammond organ","Electric organ introduced in 1935."]],
  w:"The piano shaped how Western music was composed, taught, and shared; its keyboard is the best map of harmony.",
  src:["Piano","Bartolomeo Cristofori","Harpsichord","Pipe organ","Hammond organ"],
  q:[
  ["Who invented the piano around 1700?","Bartolomeo Cristofori","Antonio Stradivari","Johann Sebastian Bach","Ignaz Pleyel"],
  ["How many keys does a modern piano have?","88","76","92","64"],
  ["How does a harpsichord produce sound?","It plucks the strings","It strikes the strings with hammers","It bows the strings","It blows air through pipes"],
  ["What does the piano's right pedal do?","Lifts all dampers so notes sustain","Softens the sound","Transposes the keys","Mutes the strings"],
  ["Why was the piano originally called 'piano e forte'?","It could play soft and loud depending on touch","It was invented in two cities","It had two keyboards","It played both strings and pipes"],
  ["The hydraulis, ancestor of the organ, was invented where?","Hellenistic Alexandria","Medieval Paris","Renaissance Florence","Ancient Babylon"]]},

{ t:"The Guitar", s:"From Spain to the world",
  sec:[
  ["Origins",[
    "The guitar descends from plucked string instruments of medieval Europe and the Islamic world. The Spanish vihuela and the Baroque guitar, with five courses (pairs) of strings, were popular in the 16th–17th centuries. The six-string guitar emerged in the late 18th century, and in the 19th century the Spanish maker Antonio de Torres Jurado developed the modern classical guitar's larger body and fan bracing.",
    "The standard guitar has six strings tuned E–A–D–G–B–E from lowest to highest, and metal frets across the neck that mark semitones, making it easy to play chords."]],
  ["Classical and flamenco",[
    "The classical guitar uses nylon strings (originally gut) and is played with the fingers. Francisco Tárrega and later Andrés Segovia raised it to a concert instrument, and composers such as Joaquín Rodrigo wrote for it; his Concierto de Aranjuez (1939) is one of the most popular concertos of the 20th century.",
    "Flamenco guitar, from Andalusia, uses brighter tone, percussive strumming (rasgueado), and tapping on the body, accompanying singing and dance."]],
  ["The steel-string acoustic",[
    "In the United States, makers such as C. F. Martin developed steel-string acoustic guitars, louder and brighter than nylon. These became central to folk, blues, country, and singer-songwriter music.",
    "Players strum chords with a pick or fingerpick patterns. Slide guitar, using a glass or metal tube on the strings, was developed in the blues tradition; the Hawaiian steel guitar, played flat on the lap, influenced country music's pedal steel."]],
  ["The electric guitar",[
    "Electric guitars use magnetic pickups to convert string vibrations into an electrical signal, sent through an amplifier. Early electric guitars appeared in the 1930s; solid-body designs, such as the Fender Telecaster (1950s) and Stratocaster (1954) and the Gibson Les Paul (1952), became icons. Les Paul himself pioneered multitrack recording.",
    "Amplification allowed new sounds: distortion, feedback, and effects pedals such as wah-wah and delay. Players like Charlie Christian (jazz), Chuck Berry, Jimi Hendrix, Eric Clapton, and Eddie Van Halen made the electric guitar the symbol of rock."]],
  ["The bass and guitar roles",[
    "The electric bass guitar, popularized by Fender's Precision Bass (1951), usually has four strings tuned an octave below the guitar's lowest four, and replaced the double bass in most popular music.",
    "In a band, rhythm guitar provides chords and groove while lead guitar plays melodies and solos. Guitarists read chord charts and tablature (tab), a notation showing which string and fret to play."]]
  ],
  terms:[["Fret","Metal strip on the neck marking semitone positions."],["Standard tuning","E–A–D–G–B–E from low to high."],["Pickup","Magnetic device converting string vibration to a signal."],["Tablature","Notation showing strings and frets."],["Rasgueado","Flamenco strumming technique."]],
  w:"The guitar is the world's most popular instrument for amateurs and the defining sound of 20th-century popular music.",
  src:["Guitar","Classical guitar","Electric guitar","Antonio de Torres Jurado","Bass guitar"],
  q:[
  ["What is standard guitar tuning from low to high?","E–A–D–G–B–E","E–A–D–G–C–F","D–A–D–G–A–D","C–G–D–A–E–B"],
  ["Who developed the modern classical guitar design in the 19th century?","Antonio de Torres Jurado","Andrés Segovia","Leo Fender","C. F. Martin"],
  ["How does an electric guitar capture sound?","Magnetic pickups","A microphone inside the body","A soundhole","Piezo bridges only"],
  ["Which composer wrote the Concierto de Aranjuez?","Joaquín Rodrigo","Manuel de Falla","Isaac Albéniz","Francisco Tárrega"],
  ["What is tablature?","Notation showing which string and fret to play","A type of guitar body","A strumming technique","A guitar effect"],
  ["Which instrument largely replaced the double bass in popular music?","Electric bass guitar","Tuba","Cello","Baritone guitar"]]},

{ t:"The Orchestra and the Conductor", s:"A hundred musicians as one",
  sec:[
  ["How the orchestra grew",[
    "The orchestra developed in the 17th century, centered on strings with harpsichord continuo. In the Classical era (Haydn, Mozart) it standardized around strings plus pairs of flutes, oboes, bassoons, horns, trumpets, and timpani, with clarinets added. In the 19th century Romantic composers such as Berlioz, Wagner, and Mahler expanded it greatly, adding more brass, tubas, harps, and percussion.",
    "A modern symphony orchestra typically has 70 to 100 or more players. A smaller chamber orchestra has perhaps 15 to 40."]],
  ["Sections and seating",[
    "The orchestra has four families: strings, woodwinds, brass, and percussion, often plus harp and keyboard. Strings sit in front, divided into first violins, second violins, violas, cellos, and double basses; woodwinds sit behind them, then brass and percussion at the back.",
    "The concertmaster (or leader in Britain), the principal first violinist, sits to the conductor's left, plays violin solos, leads tuning, and acts as a bridge between conductor and players. Each section has a principal who plays solos and leads the section."]],
  ["The conductor's job",[
    "Early ensembles were led from the keyboard or by the first violinist. The modern conductor with a baton emerged in the 19th century, as orchestras grew and music became more complex; Felix Mendelssohn and Hector Berlioz were early influential conductors.",
    "The conductor beats time, but the real work is interpretation: choosing tempos, balancing sections, shaping phrases and dynamics, and unifying a hundred people's playing during rehearsal. Basic beat patterns show the meter: down-up for 2, down-out-up for 3, down-in-out-up for 4."]],
  ["Great conductors and orchestras",[
    "Famous conductors include Arturo Toscanini, Herbert von Karajan, Leonard Bernstein, Georg Solti, Claudio Abbado, Simon Rattle, and Gustavo Dudamel. Marin Alsop became a pioneering woman conductor in the 21st century.",
    "Leading orchestras include the Berlin Philharmonic, the Vienna Philharmonic (which plays the famous New Year's Concert), the Royal Concertgebouw Orchestra of Amsterdam, the London Symphony Orchestra, the Chicago Symphony Orchestra, and the New York Philharmonic."]],
  ["Orchestral genres",[
    "Orchestras play symphonies, concertos (soloist with orchestra), overtures, tone poems, ballet scores, and opera, as well as film and video game music. Orchestration is the art of assigning musical material to instruments; Rimsky-Korsakov, Ravel, and others are celebrated as master orchestrators.",
    "Benjamin Britten's The Young Person's Guide to the Orchestra (1945) and Prokofiev's Peter and the Wolf (1936) were written partly to introduce listeners to the instruments."]]
  ],
  terms:[["Concertmaster","Principal first violinist who leads the orchestra's players."],["Baton","Stick used by a conductor."],["Orchestration","Assigning music to specific instruments."],["Chamber orchestra","Smaller orchestra of about 15 to 40 players."],["Principal","Leader and soloist of a section."]],
  w:"Understanding the orchestra's layout and the conductor's role makes concerts and film scores far more rewarding.",
  src:["Orchestra","Conducting","Concertmaster","Orchestration","The Young Person's Guide to the Orchestra"],
  q:[
  ["Who sits to the conductor's left and leads the violins?","The concertmaster","The principal cellist","The timpanist","The assistant conductor"],
  ["Which section usually sits at the front of the orchestra?","Strings","Brass","Percussion","Woodwinds"],
  ["Which Britten work introduces orchestral instruments?","The Young Person's Guide to the Orchestra","Peter and the Wolf","Bolero","The Planets"],
  ["When did the modern baton conductor become established?","19th century","15th century","17th century","20th century"],
  ["What is orchestration?","Assigning musical material to instruments","Tuning the orchestra","Seating the players","Writing lyrics for opera"],
  ["Which orchestra performs a famous New Year's Concert?","Vienna Philharmonic","Berlin Philharmonic","London Symphony Orchestra","Chicago Symphony"]]},

{ t:"Electronic Instruments", s:"From theremin to laptop",
  sec:[
  ["Early electronic instruments",[
    "The theremin, invented by Russian physicist Léon Theremin around 1920, is played without being touched: the player moves hands near two antennas to control pitch and volume, producing an eerie, gliding tone heard in many science-fiction film scores. The ondes Martenot (1928), used by Olivier Messiaen, was another early electronic instrument.",
    "The Hammond organ (1935) and electric guitar spread electric sound into popular music."]],
  ["Tape and studio",[
    "After World War II, composers began working directly with recorded sound. In Paris, Pierre Schaeffer created musique concrète (1948) by editing and transforming recorded noises on disc and tape. In Cologne, Karlheinz Stockhausen and others made elektronische Musik from electronic oscillators.",
    "The BBC Radiophonic Workshop, founded in 1958, produced pioneering sounds including Delia Derbyshire's realization of the Doctor Who theme (1963)."]],
  ["Synthesizers",[
    "A synthesizer generates sound electronically. Robert Moog's modular synthesizers of the 1960s used voltage-controlled oscillators, filters, and envelopes; Wendy Carlos's album Switched-On Bach (1968) made them famous. The portable Minimoog (1970) brought synthesis to rock and funk.",
    "Basic synthesis terms: an oscillator produces a waveform (sine, square, sawtooth); a filter removes frequencies to shape tone; an envelope (ADSR: attack, decay, sustain, release) shapes how a sound starts and fades; an LFO (low-frequency oscillator) adds wobble or vibrato."]],
  ["Drum machines, sampling, and MIDI",[
    "Drum machines such as the Roland TR-808 (1980) and TR-909 created sounds central to hip-hop, house, and techno. Samplers record and replay short sounds, allowing producers to build music from fragments of other recordings.",
    "MIDI (Musical Instrument Digital Interface), introduced in 1983, is a standard language that lets electronic instruments and computers communicate. It sends performance data, which note, how hard, how long, rather than audio itself."]],
  ["The computer as instrument",[
    "Today most recorded music is made with digital audio workstations (DAWs) such as Pro Tools, Logic, Ableton Live, and FL Studio, which combine recording, editing, virtual instruments, and effects on a computer. Software synthesizers and sample libraries can imitate orchestras.",
    "Auto-Tune, introduced in 1997 to correct pitch, became a deliberate stylistic effect after Cher's 'Believe' (1998) and later in hip-hop. Electronic tools have made music production available to anyone with a laptop."]]
  ],
  terms:[["Theremin","Early electronic instrument played without touch."],["Synthesizer","Instrument generating sound electronically."],["ADSR","Attack, decay, sustain, release: the envelope of a sound."],["MIDI","1983 standard for electronic instruments to communicate."],["DAW","Digital audio workstation software for making music."]],
  w:"Nearly all music you hear today passes through electronic tools; these basics explain how modern sound is made.",
  src:["Theremin","Synthesizer","Moog synthesizer","MIDI","Roland TR-808"],
  q:[
  ["Which instrument is played without being touched?","Theremin","Ondes Martenot","Hammond organ","Minimoog"],
  ["Who created musique concrète?","Pierre Schaeffer","Karlheinz Stockhausen","Robert Moog","Edgard Varèse"],
  ["What does MIDI transmit?","Performance data such as notes and velocity","Recorded audio","Video signals","Lyrics"],
  ["Which album made the Moog synthesizer famous in 1968?","Switched-On Bach","Pet Sounds","Oxygène","Kind of Blue"],
  ["What does the 'A' in ADSR stand for?","Attack","Amplitude","Audio","Accent"],
  ["Which drum machine became central to hip-hop and electronic music?","Roland TR-808","Hammond B-3","Fender Rhodes","Mellotron"]]}

);


/* ---- from music-05.js ---- */
/* MUSIC FOUNDATIONS, part 5: Unit 3 Early Music and the Baroque, chapters 1-4 */
COURSES.music.units.push({ t:"Early Music and the Baroque", ch:[

{ t:"Music in the Ancient World", s:"The first songs",
  sec:[
  ["Prehistoric music",[
    "Music is older than writing, older than farming, and probably older than our species' spread across the globe. The oldest known instruments are flutes made from bird bone and mammoth ivory, found in caves in southwestern Germany such as Hohle Fels and Geissenklösterle, dated to roughly 40,000 years ago. Singing, clapping, and drumming on found objects almost certainly came earlier but left no trace.",
    "Anthropologists find music in every known human culture, used for ritual, healing, work, courtship, storytelling, mourning, and play. Researchers debate why music evolved: theories include social bonding, signaling group strength, parent–infant communication, and courtship."]],
  ["Mesopotamia and Egypt",[
    "In Sumer, beautifully decorated lyres were buried in the Royal Cemetery of Ur around 2500 BCE. Cuneiform tablets record music theory, and the Hurrian songs from Ugarit (about 1400 BCE) include the oldest substantially surviving notated melody, the 'Hymn to Nikkal.'",
    "Egyptian art shows harps, lutes, flutes, double-reed pipes, sistrums (rattles), and trumpets; two trumpets were found in Tutankhamun's tomb. Music accompanied temple ritual, feasts, and work, and professional musicians, including women, held recognized roles."]],
  ["Ancient Greece",[
    "The Greeks gave Western music much of its vocabulary: music (from the Muses), harmony, melody, rhythm, chorus, orchestra, and diatonic all have Greek roots. Their main instruments were the lyre and kithara (plucked strings associated with Apollo) and the aulos, a double-reed pipe associated with Dionysus.",
    "Pythagoras is credited with discovering that pleasing intervals correspond to simple ratios of string length: the octave 2:1, the fifth 3:2, the fourth 4:3. Greek theory organized scales into modes, and Plato and Aristotle argued that different modes shaped character, so music had a role in education and ethics. The Seikilos epitaph (about 1st century CE), carved on a tombstone, is the oldest surviving complete musical composition with notation."]],
  ["Rome and beyond",[
    "Romans adopted Greek music and added military brass such as the tuba and cornu. Music accompanied theater, gladiatorial games, and banquets, and Emperor Nero famously fancied himself a singer and lyre player.",
    "Elsewhere, great ancient traditions flourished independently. In China, sets of tuned bronze bells, such as those from the tomb of Marquis Yi of Zeng (433 BCE), show sophisticated tuning; Confucius considered music essential to moral order. In India, the Vedic chants are among the oldest continuously practiced musical traditions, and the Natya Shastra, a treatise on performing arts, laid out early music theory."]],
  ["What we can and cannot know",[
    "Most ancient music is lost because it was passed down orally. Surviving fragments of notation are rare and hard to interpret, so modern performances of ancient music are partly reconstructions.",
    "Still, ancient ideas lasted: the Greek link between number and harmony shaped medieval education, where music was one of the four mathematical arts of the quadrivium alongside arithmetic, geometry, and astronomy."]]
  ],
  terms:[["Aulos","Ancient Greek double-reed pipe."],["Kithara","Ancient Greek concert lyre."],["Seikilos epitaph","Oldest surviving complete notated composition."],["Quadrivium","Medieval math arts: arithmetic, geometry, music, astronomy."],["Mode","A scale pattern with its own character."]],
  w:"Music is a human universal; the ancient world gave us instruments, the math of intervals, and the very word 'music.'",
  src:["Prehistoric music","Music of ancient Greece","Seikilos epitaph","Hurrian songs","Divje Babe flute"],
  q:[
  ["Roughly how old are the oldest known flutes from German caves?","About 40,000 years","About 4,000 years","About 10,000 years","About 200,000 years"],
  ["Which ratio did Pythagoras associate with the octave?","2:1","3:2","4:3","5:4"],
  ["What is the Seikilos epitaph?","The oldest surviving complete notated composition","A Roman military song","An Egyptian harp","A Chinese bell set"],
  ["Which ancient Greek instrument was a double-reed pipe?","Aulos","Kithara","Lyre","Sistrum"],
  ["Music was part of which group of medieval subjects?","The quadrivium","The trivium","The liberal crafts","The humanities"],
  ["The 'Hymn to Nikkal' comes from which ancient culture?","The Hurrians of Ugarit","Ancient Egypt","Classical Athens","The Roman Empire"]]},

{ t:"Medieval Music", s:"Chant, troubadours, and polyphony",
  sec:[
  ["Gregorian chant",[
    "Western art music grew from the chant of the Christian church. Plainchant (plainsong) is a single unaccompanied melodic line sung to Latin texts, in free rhythm that follows the words. The main Western repertory is called Gregorian chant, named after Pope Gregory I (died 604), though it was largely compiled under the Carolingian rulers in the 8th–9th centuries.",
    "Chant was organized by the church calendar and sung in the Mass and the Office (daily prayer services in monasteries). Chant melodies use the church modes, such as Dorian, Phrygian, Lydian, and Mixolydian. Texts may be set syllabically (one note per syllable) or melismatically (many notes on one syllable)."]],
  ["The invention of notation",[
    "At first chant was learned by ear. In the 9th century, neumes, small marks above the text, began recording the shape of melodies. In the early 11th century, Guido of Arezzo, an Italian monk, refined the staff of lines to show exact pitch and devised the solmization syllables ut–re–mi–fa–sol–la, taken from a hymn, the ancestor of do–re–mi.",
    "Notation changed music history: it allowed complex music to be preserved, composed in writing, and taught widely. Later notation added ways to show rhythm."]],
  ["Hildegard and sacred song",[
    "Hildegard of Bingen (1098–1179), a German abbess, mystic, writer, and scientist, composed a large body of chant with soaring, wide-ranging melodies, as well as Ordo Virtutum, a musical morality play. She is one of the earliest composers whose name and many works are known.",
    "Monasteries and convents were the main centers of learning and music-making for centuries."]],
  ["Polyphony and the Notre Dame school",[
    "Polyphony, music with two or more independent lines, developed gradually. Early organum added a second voice parallel to the chant; over time the added voice became freer. In Paris around 1200, composers at Notre Dame Cathedral, Léonin and Pérotin, wrote elaborate organum in two, three, and four voices, with chant notes stretched out under lively upper parts organized by rhythmic modes.",
    "The motet developed in the 13th century by adding new texts to upper voices, sometimes in different languages at once."]],
  ["Ars nova and secular music",[
    "Secular song flourished too. The troubadours of southern France and trouvères of the north (12th–13th centuries) sang poetry of courtly love, and German Minnesingers followed. Their songs were monophonic and often accompanied by instruments such as the vielle, a medieval fiddle.",
    "In the 14th century, the Ars nova ('new art') introduced more flexible rhythmic notation. Its leading figure, the French poet-composer Guillaume de Machaut, wrote the Messe de Nostre Dame, one of the earliest complete polyphonic settings of the Mass Ordinary by a single composer. In Italy, Francesco Landini excelled at secular songs."]],
  ["Medieval instruments",[
    "Medieval instruments included the vielle, rebec, psaltery, lute, harp, portative organ, recorder, shawm (a loud double reed), sackbut (early trombone), bagpipe, and drums. Dances such as the estampie survive in a few manuscripts.",
    "Performers likely improvised much of what they played, so modern early-music ensembles reconstruct instrumentation from art, descriptions, and surviving instruments."]]
  ],
  terms:[["Plainchant","Unaccompanied single-line liturgical song."],["Neumes","Early marks showing melodic shape."],["Organum","Early polyphony adding voices to chant."],["Melisma","Many notes sung on one syllable."],["Ars nova","14th-century style with new rhythmic notation."]],
  w:"Medieval musicians invented notation and polyphony, the two foundations of Western composition.",
  src:["Gregorian chant","Guido of Arezzo","Hildegard of Bingen","Notre-Dame school","Guillaume de Machaut"],
  q:[
  ["Who devised the ancestor of do–re–mi syllables?","Guido of Arezzo","Pope Gregory I","Pérotin","Machaut"],
  ["Which abbess composed chant and the play Ordo Virtutum?","Hildegard of Bingen","Héloïse","Christine de Pizan","Clare of Assisi"],
  ["Léonin and Pérotin worked at which cathedral?","Notre Dame in Paris","Chartres","Canterbury","St. Mark's in Venice"],
  ["What is polyphony?","Music with multiple independent lines","A single melody","Music without rhythm","Instrumental dance music"],
  ["Who composed the Messe de Nostre Dame?","Guillaume de Machaut","Francesco Landini","Josquin des Prez","Hildegard of Bingen"],
  ["Troubadours were poet-musicians from which region?","Southern France","Northern Germany","Italy","England"]]},

{ t:"The Renaissance", s:"Harmony, print, and humanism",
  sec:[
  ["A new sound",[
    "The Renaissance in music runs roughly from 1400 to 1600. Composers favored a full, smooth sound with more consonant harmony, especially thirds and sixths, which English music had made popular; John Dunstaple's influence on continental composers was called the contenance angloise ('English manner').",
    "The typical texture was imitative polyphony: four to six independent voices of equal importance, each entering with the same motif in turn. Composers sought to make words clear and expressive, reflecting humanist interest in classical rhetoric."]],
  ["The Franco-Flemish masters",[
    "Composers from northern France and the Low Countries dominated Europe and worked in courts and churches across it. Guillaume Du Fay wrote masses, motets, and chansons in the 15th century. Johannes Ockeghem was famous for long, flowing lines.",
    "Josquin des Prez (about 1450–1521) was the most celebrated composer of his era; Martin Luther said Josquin was master of the notes, where others were mastered by them. His motet Ave Maria... virgo serena shows clear imitation and expressive text-setting. Composers often based masses on existing melodies, including popular songs such as 'L'homme armé' ('The Armed Man')."]],
  ["Music printing and the madrigal",[
    "In 1501 Ottaviano Petrucci in Venice published the Odhecaton, the first substantial collection of polyphonic music printed with movable type. Printing spread music across Europe and helped amateurs sing and play at home.",
    "The madrigal, a secular song for several voices, flourished in 16th-century Italy and then England. Madrigalists used word painting, illustrating words musically: rising lines for 'ascending,' quick notes for 'running,' harsh dissonance for 'pain.' Major figures include Luca Marenzio, Claudio Monteverdi, and the startlingly chromatic Carlo Gesualdo; English madrigalists include Thomas Morley, Thomas Weelkes, and John Wilbye."]],
  ["Reformation and Counter-Reformation",[
    "The Protestant Reformation transformed church music. Martin Luther, a capable musician, promoted congregational hymns (chorales) in German, such as 'A Mighty Fortress Is Our God.' Calvinists favored simple psalm singing, and the English church developed the anthem.",
    "The Catholic Council of Trent (1545–63) discussed whether complex polyphony obscured sacred words. Giovanni Pierluigi da Palestrina became the model of clear, balanced, serene polyphony; his Pope Marcellus Mass was later celebrated in legend as having 'saved' polyphony. Tomás Luis de Victoria in Spain and William Byrd and Thomas Tallis in England were also great sacred composers; Tallis's Spem in alium is written for forty independent voices."]],
  ["Instruments and dance",[
    "Instrumental music grew in importance. The lute was the most popular domestic instrument; John Dowland's melancholy lute songs were bestsellers. Consorts of viols (bowed instruments held downward) and recorders played together, and keyboard music for virginal and organ developed.",
    "Dance pairs such as the slow pavane and lively galliard were popular, and dances later gathered into suites."]]
  ],
  terms:[["Imitative polyphony","Voices entering one by one with the same motif."],["Madrigal","Secular part-song, often with word painting."],["Word painting","Musically illustrating the meaning of words."],["Chorale","Lutheran congregational hymn."],["Mass Ordinary","Fixed texts of the Mass: Kyrie, Gloria, Credo, Sanctus, Agnus Dei."]],
  w:"Renaissance polyphony set the standards of harmony and voice-leading that musicians still study today.",
  src:["Renaissance music","Josquin des Prez","Giovanni Pierluigi da Palestrina","Madrigal","Ottaviano Petrucci"],
  q:[
  ["Which composer became the model of clear Counter-Reformation polyphony?","Palestrina","Gesualdo","Josquin","Dowland"],
  ["What is word painting?","Illustrating the meaning of words in music","Writing lyrics in color","Decorating manuscripts","Singing without words"],
  ["Who printed the Odhecaton in 1501?","Ottaviano Petrucci","Johannes Gutenberg","Aldus Manutius","Pierre Attaingnant"],
  ["Thomas Tallis's Spem in alium is written for how many voices?","Forty","Eight","Twelve","Sixteen"],
  ["Which reformer promoted German congregational chorales?","Martin Luther","John Calvin","Ulrich Zwingli","Henry VIII"],
  ["Who was the most celebrated composer around 1500?","Josquin des Prez","Monteverdi","Machaut","Bach"]]},

{ t:"The Birth of Opera", s:"Drama through music",
  sec:[
  ["Reviving Greek drama",[
    "Around 1600, a group of Florentine scholars, poets, and musicians known as the Florentine Camerata sought to revive what they believed was the expressive power of ancient Greek drama, which they thought had been sung throughout. They criticized dense polyphony for burying the words.",
    "Their solution was monody: a single expressive vocal line over simple chordal accompaniment, letting words come through clearly and with emotion. This new style helped create opera, drama set to continuous music."]],
  ["The first operas",[
    "Jacopo Peri's Dafne (1598, mostly lost) is considered the first opera, and his Euridice (1600) is the earliest surviving one. Both were based on Greek myths about the power of music.",
    "Claudio Monteverdi's L'Orfeo (1607), written for the court of Mantua, is the first operatic masterpiece still regularly performed. It tells the story of Orpheus, who descends to the underworld to rescue his wife Eurydice with his singing. Monteverdi used a rich orchestra, choruses, dances, and expressive recitative."]],
  ["Recitative, aria, and basso continuo",[
    "Opera developed two main types of singing. Recitative imitates the rhythms of speech and moves the plot forward. The aria is a lyrical song in which a character expresses emotion, often with more elaborate melody and repetition.",
    "Underneath was the basso continuo, a bass line played by a cello or bassoon with a chord instrument such as harpsichord, lute, or organ improvising harmonies from shorthand figures (figured bass). The continuo became the backbone of Baroque music."]],
  ["Opera goes public",[
    "The first public opera house, the Teatro San Cassiano, opened in Venice in 1637. Opera moved from court spectacle to commercial entertainment with paying audiences. Monteverdi's late operas, including L'incoronazione di Poppea (1643), were written for Venice.",
    "Opera soon spread across Italy and Europe, with elaborate stage machinery, star singers including castrati, and audiences who chatted, ate, and gambled during performances."]],
  ["Monteverdi and the 'second practice'",[
    "Monteverdi (1567–1643) bridged the Renaissance and Baroque. He described a seconda pratica ('second practice') in which words ruled the music, justifying bold dissonances for expression, versus the prima pratica of strict Renaissance counterpoint. His madrigals and his Vespers of 1610 are landmarks.",
    "The shift to expressive solo singing, a strong bass line, and dramatic contrast marks the beginning of the Baroque era."]]
  ],
  terms:[["Monody","Solo voice with simple chordal accompaniment."],["Recitative","Speech-like singing that advances the plot."],["Aria","Lyrical solo song expressing emotion."],["Basso continuo","Bass line plus improvised chords."],["Libretto","The text of an opera."]],
  w:"Opera fused poetry, music, and theater, and its forms shaped vocal music, film scoring, and musicals ever since.",
  src:["Florentine Camerata","L'Orfeo","Claudio Monteverdi","Recitative","Basso continuo"],
  q:[
  ["Which is the first operatic masterpiece still regularly performed?","Monteverdi's L'Orfeo (1607)","Peri's Dafne","Purcell's Dido and Aeneas","Handel's Rinaldo"],
  ["What were the Florentine Camerata trying to revive?","Ancient Greek drama","Gregorian chant","Troubadour song","Roman military music"],
  ["What is recitative?","Speech-like singing that moves the plot","A lyrical solo song","A chorus number","An instrumental overture"],
  ["Where did the first public opera house open in 1637?","Venice","Florence","Rome","Paris"],
  ["What is the basso continuo?","A bass line with improvised chords","A low-voiced singer","An opening overture","A type of aria"],
  ["What was Monteverdi's 'second practice'?","Words rule the music, allowing expressive dissonance","Strict Renaissance counterpoint","Instrumental music without voices","A new tuning system"]]}

]});


/* ---- from music-06.js ---- */
/* MUSIC FOUNDATIONS, part 6: Unit 3 chapters 5-8 */
COURSES.music.units[2].ch.push(

{ t:"The Baroque Style", s:"1600 to 1750",
  sec:[
  ["What 'Baroque' means",[
    "The Baroque era in music runs roughly from 1600 (the first operas) to 1750 (the death of J. S. Bach). The word, possibly from a Portuguese term for an irregular pearl, was first used as an insult for art that seemed overly ornate. Baroque art, architecture, and music share grandeur, movement, contrast, and drama.",
    "Music of the period expresses a single emotion or 'affect' per piece or movement, according to the Doctrine of the Affections: a lament stays mournful, a celebration stays joyful."]],
  ["Musical features",[
    "Baroque music typically has a strong bass line with basso continuo, a steady driving rhythm, and long, spun-out melodies built from short motifs. Dynamics often change in sudden blocks (terraced dynamics) rather than gradual swells, partly because harpsichords and organs could not easily crescendo.",
    "Major–minor tonality became established in this era, replacing the old modes. Performers were expected to add ornaments such as trills and to improvise over the continuo."]],
  ["Forms and genres",[
    "Instrumental genres flourished. The concerto contrasts a soloist or small group (the concertino in a concerto grosso) with the full ensemble (ripieno or tutti); ritornello form alternates a recurring orchestral refrain with solo episodes. The sonata, for one or two melody instruments and continuo, came in church (sonata da chiesa) and chamber (sonata da camera) types.",
    "The suite is a collection of dances, typically allemande, courante, sarabande, and gigue, often with optional minuets or gavottes. The fugue is a contrapuntal form in which a subject (theme) enters in each voice in turn and is then developed. Vocal genres included opera, the oratorio (a sacred, unstaged drama), and the cantata."]],
  ["Tuning and instruments",[
    "Baroque instruments differed from modern ones: gut strings, lighter bows, valveless natural trumpets and horns, wooden flutes, and the harpsichord. Pitch was often lower than today's standard. Since the late 20th century, historically informed performance has revived period instruments and practices.",
    "Tuning systems such as well temperament allowed composers to write in all keys; Bach's Well-Tempered Clavier showcases this with preludes and fugues in all 24 major and minor keys."]],
  ["Music and patronage",[
    "Composers worked mostly for the church, royal or aristocratic courts, or city governments, and were treated as skilled servants. Music was written for specific occasions and was often new rather than repeated: the idea of a fixed canon of old masterpieces had not yet developed.",
    "Major centers included Italy (opera and violin music), France (court music of Louis XIV at Versailles), Germany (Lutheran church music), and England (Purcell and later Handel in London)."]]
  ],
  terms:[["Terraced dynamics","Sudden shifts between loud and soft levels."],["Concerto grosso","Small soloist group contrasted with full ensemble."],["Fugue","Contrapuntal form built on a subject entering in each voice."],["Oratorio","Unstaged sacred drama for voices and orchestra."],["Suite","Collection of stylized dances."]],
  w:"Baroque forms like the concerto and fugue, and its major–minor harmony, still underpin music you hear today.",
  src:["Baroque music","Concerto grosso","Fugue","Suite (music)","Historically informed performance"],
  q:[
  ["Which years roughly define the Baroque era in music?","1600–1750","1450–1600","1750–1820","1820–1900"],
  ["What are terraced dynamics?","Sudden shifts between loud and soft","Gradual crescendos","Echo effects only","Silence between movements"],
  ["In a concerto grosso, what is the concertino?","The small group of soloists","The full orchestra","The final movement","The bass line"],
  ["Which is a standard dance in a Baroque suite?","Sarabande","Waltz","Polka","Tango"],
  ["What is an oratorio?","An unstaged sacred drama","A comic opera","A keyboard dance","A solo song"],
  ["Bach's Well-Tempered Clavier contains pieces in how many keys?","All 24 major and minor keys","12 major keys","8 church modes","48 keys"]]},

{ t:"Johann Sebastian Bach", s:"The summit of counterpoint",
  sec:[
  ["Life",[
    "Johann Sebastian Bach (1685–1750) was born in Eisenach, Germany, into a large family of musicians. Orphaned at ten, he was raised by his older brother and became a brilliant organist. He worked at Arnstadt, Mühlhausen, the court of Weimar, the court of Cöthen, and finally, from 1723 until his death, as Thomaskantor in Leipzig, responsible for music at the city's main churches and the St. Thomas School.",
    "He had twenty children with two wives, Maria Barbara and Anna Magdalena; several sons became important composers, including C. P. E. Bach and J. C. Bach."]],
  ["Sacred music",[
    "In Leipzig Bach wrote cantatas for Lutheran services nearly every week in his early years there; around 200 sacred cantatas survive. His St. Matthew Passion (1727) and St. John Passion set the Gospel accounts of Christ's death for soloists, choirs, and orchestra and are among the greatest works of sacred music.",
    "The Mass in B minor, assembled late in his life, and the Christmas Oratorio are other monumental works. Bach often wrote 'Soli Deo Gloria' (to God alone the glory) on his scores."]],
  ["Instrumental music",[
    "For keyboard, Bach wrote The Well-Tempered Clavier (two books of 24 preludes and fugues), the Goldberg Variations, the Inventions, the French and English Suites, and partitas. For organ, he composed chorale preludes and toccatas and fugues; the Toccata and Fugue in D minor is famous though its authorship is sometimes questioned.",
    "For instruments, he wrote six Suites for solo cello, sonatas and partitas for solo violin (including the great Chaconne), and the six Brandenburg Concertos (1721), each for a different combination of instruments. The Art of Fugue explores a single theme through many contrapuntal techniques."]],
  ["His style",[
    "Bach is considered the supreme master of counterpoint, combining independent melodic lines into rich harmony. His music unites German, Italian, and French styles, intellectual rigor, and deep emotion. He used chorale melodies as building blocks, and his four-part chorale harmonizations are still studied by every music student.",
    "In his lifetime he was known mainly as an organ virtuoso, and his style was considered old-fashioned by the end of his life."]],
  ["Revival and legacy",[
    "After his death Bach's music was studied by Mozart and Beethoven but rarely performed publicly. In 1829, 20-year-old Felix Mendelssohn conducted the St. Matthew Passion in Berlin, sparking the Bach revival. Today Bach is often regarded as the greatest composer in the Western tradition.",
    "His music has been arranged for jazz, synthesizers, and pop, and a recording of the Brandenburg Concerto No. 2 travels on the Voyager Golden Record into interstellar space."]]
  ],
  terms:[["Thomaskantor","Bach's post as music director in Leipzig."],["Cantata","Multi-movement vocal work for church or occasion."],["Passion","Musical setting of the Gospel story of Christ's death."],["Counterpoint","Combining independent melodic lines."],["Chorale prelude","Organ piece based on a hymn tune."]],
  w:"Bach's music is the foundation of Western harmony and counterpoint, studied by nearly every composer since.",
  src:["Johann Sebastian Bach","St Matthew Passion","Brandenburg Concertos","Goldberg Variations","Bach revival"],
  q:[
  ["In which city did Bach work as Thomaskantor?","Leipzig","Berlin","Dresden","Hamburg"],
  ["Who conducted the St. Matthew Passion in 1829, sparking the Bach revival?","Felix Mendelssohn","Robert Schumann","Johannes Brahms","Richard Wagner"],
  ["How many Brandenburg Concertos are there?","Six","Four","Twelve","Twenty-four"],
  ["Which Bach work consists of an aria and thirty variations?","Goldberg Variations","Art of Fugue","Mass in B minor","Inventions"],
  ["Bach is considered the supreme master of what?","Counterpoint","Opera","Symphony","Program music"],
  ["Which son of Bach became an important composer?","C. P. E. Bach","Johann Pachelbel","Georg Philipp Telemann","Dietrich Buxtehude"]]},

{ t:"Handel and the English Baroque", s:"Opera, oratorio, and Messiah",
  sec:[
  ["Purcell",[
    "England's greatest native Baroque composer was Henry Purcell (1659–1695), organist at Westminster Abbey and composer to the royal court. His opera Dido and Aeneas (about 1689) is a short masterpiece; Dido's lament 'When I am laid in earth' is built over a repeating descending bass line (a ground bass) and remains one of the most moving arias ever written.",
    "Purcell also wrote anthems, odes, theater music, and keyboard pieces, and died young at 35."]],
  ["Handel's life",[
    "George Frideric Handel (1685–1759) was born in Halle, Germany, in the same year as Bach, but their careers were very different. After studying in Germany and working in Hamburg's opera, he spent several years in Italy absorbing opera and the Italian style.",
    "He moved to London in 1712, became a British subject in 1727, and spent most of his career there as a composer and entrepreneur, running opera companies and producing concerts for paying audiences."]],
  ["Italian opera in London",[
    "Handel wrote more than forty Italian operas, including Rinaldo (1711), Giulio Cesare (1724), and Alcina (1735). They featured star singers, including castrati such as Senesino, and elaborate da capo arias (A–B–A form, with the singer ornamenting the return of A).",
    "By the 1730s, Italian opera was losing popularity in London, partly mocked by The Beggar's Opera (1728), a ballad opera in English using popular tunes."]],
  ["The English oratorio",[
    "Handel turned to oratorio in English, mostly on Old Testament subjects, such as Saul, Israel in Egypt, Samson, Judas Maccabaeus, and Jephtha. These used dramatic choruses and were performed in theaters without staging.",
    "Messiah (1741), composed in about three and a half weeks, premiered in Dublin in 1742. Its 'Hallelujah' chorus became one of the most famous pieces of music in the world, and the tradition of standing for it is said, perhaps legendarily, to date to King George II. Messiah has been performed continuously ever since."]],
  ["Orchestral works and legacy",[
    "Handel's Water Music (1717) was played on a barge on the Thames for King George I, and Music for the Royal Fireworks (1749) celebrated a peace treaty. He also wrote organ concertos and concerti grossi.",
    "Unlike Bach, Handel never fell out of fashion in Britain; he was buried in Westminster Abbey. Beethoven called him the greatest composer who ever lived."]]
  ],
  terms:[["Ground bass","Repeating bass line under changing upper parts."],["Da capo aria","A–B–A aria with ornamented repeat."],["Ballad opera","English stage work using popular tunes."],["Castrato","Male singer with a preserved high voice."],["Oratorio","Unstaged dramatic work, often sacred."]],
  w:"Handel turned the oratorio into public entertainment; Messiah remains one of the most performed works in history.",
  src:["George Frideric Handel","Messiah (Handel)","Henry Purcell","Dido and Aeneas","Water Music"],
  q:[
  ["Where did Handel's Messiah premiere in 1742?","Dublin","London","Hamburg","Halle"],
  ["Which Purcell opera contains the lament 'When I am laid in earth'?","Dido and Aeneas","The Fairy-Queen","King Arthur","The Indian Queen"],
  ["What is a da capo aria's form?","A–B–A","A–B","Theme and variations","Rondo"],
  ["Handel's Water Music was played on which river?","The Thames","The Rhine","The Danube","The Liffey"],
  ["Which 1728 work mocked Italian opera in London?","The Beggar's Opera","Rinaldo","Messiah","The Magic Flute"],
  ["In what year were both Bach and Handel born?","1685","1659","1700","1678"]]},

{ t:"Vivaldi, Italy, and France", s:"Violins, concertos, and Versailles",
  sec:[
  ["The Italian violin school",[
    "Italy led Baroque instrumental music, helped by the great violin makers of Cremona. Arcangelo Corelli (1653–1713), in Rome, set models for the trio sonata and concerto grosso, admired for elegance and balance; his Christmas Concerto is still beloved.",
    "Italian composers developed the solo concerto, typically in three movements (fast–slow–fast), which became the standard concerto structure for centuries."]],
  ["Antonio Vivaldi",[
    "Antonio Vivaldi (1678–1741), known as the Red Priest for his red hair, was a priest and virtuoso violinist in Venice. For decades he taught and composed for the Ospedale della Pietà, an orphanage whose girls' orchestra and choir were famous across Europe.",
    "He wrote about 500 concertos, many for violin but also for bassoon, cello, flute, mandolin, and other instruments, as well as operas and sacred works such as the Gloria. His best-known work is The Four Seasons (published 1725), four violin concertos accompanied by sonnets, depicting birdsong, storms, a sleeping goatherd, and slipping on ice: an early masterpiece of program music."]],
  ["Other Italians",[
    "Alessandro Scarlatti was a leading opera composer in Naples, and his son Domenico Scarlatti (1685–1757) wrote 555 harpsichord sonatas full of daring technique and Spanish color, composed largely while working at the Spanish and Portuguese courts.",
    "Tomaso Albinoni wrote concertos and oboe works; the famous 'Albinoni Adagio' was largely composed in the 20th century by Remo Giazotto. Giovanni Battista Pergolesi's Stabat Mater and comic opera La serva padrona (1733) were hugely influential."]],
  ["France and Versailles",[
    "French Baroque music developed differently, shaped by the court of Louis XIV and his love of dance. Jean-Baptiste Lully (1632–1687), Italian-born, dominated French music, creating French opera (tragédie en musique) with a strong role for ballet and the French overture (slow dotted rhythms followed by a fast section). He led the 24 Violons du Roi, an early disciplined string orchestra.",
    "Lully died of gangrene after striking his foot with the staff he used to beat time."]],
  ["Couperin and Rameau",[
    "François Couperin (1668–1733) wrote exquisite harpsichord pieces with fanciful titles and a treatise on keyboard playing. Jean-Philippe Rameau (1683–1764) wrote an influential Treatise on Harmony (1722) explaining chords in terms of roots and inversions, and later operas of great richness, such as Hippolyte et Aricie.",
    "In Germany, Georg Philipp Telemann was in his own time even more famous than Bach, and enormously prolific; Dietrich Buxtehude was a great organist whom young Bach walked over 400 kilometers to hear. Johann Pachelbel is remembered for his Canon in D."]]
  ],
  terms:[["Solo concerto","Work for soloist and orchestra, usually fast–slow–fast."],["Trio sonata","Two melody instruments plus continuo."],["Program music","Instrumental music depicting a story or scene."],["French overture","Slow dotted opening followed by a fast section."],["Ospedale della Pietà","Venetian orphanage where Vivaldi taught."]],
  w:"The Italian concerto and French dance styles spread across Europe and shaped everything from Bach to modern film scores.",
  src:["Antonio Vivaldi","The Four Seasons (Vivaldi)","Arcangelo Corelli","Jean-Baptiste Lully","Jean-Philippe Rameau"],
  q:[
  ["Which composer was known as the Red Priest?","Antonio Vivaldi","Arcangelo Corelli","Domenico Scarlatti","Tomaso Albinoni"],
  ["The Four Seasons is accompanied by what kind of texts?","Sonnets","Bible verses","Opera librettos","Folk songs"],
  ["Who dominated French music at the court of Louis XIV?","Jean-Baptiste Lully","Jean-Philippe Rameau","François Couperin","Marc-Antoine Charpentier"],
  ["Domenico Scarlatti is famous for what?","555 keyboard sonatas","The first opera","The Canon in D","The Treatise on Harmony"],
  ["Who wrote the Treatise on Harmony (1722)?","Jean-Philippe Rameau","J. S. Bach","Johann Fux","Lully"],
  ["What is the usual movement pattern of a Baroque solo concerto?","Fast–slow–fast","Slow–fast–slow","Four movements","One movement"]]}

);


/* ---- from music-07.js ---- */
/* MUSIC FOUNDATIONS, part 7: Unit 4 Classical and Romantic, chapters 1-4 */
COURSES.music.units.push({ t:"The Classical and Romantic Eras", ch:[

{ t:"The Classical Style", s:"Clarity, balance, and the sonata",
  sec:[
  ["A new taste",[
    "The Classical era in music runs roughly from 1750 to 1820. (Confusingly, 'classical music' in everyday speech means the whole Western art-music tradition; 'Classical' with a capital C refers to this specific period.) It coincided with the Enlightenment, which prized reason, clarity, naturalness, and universal appeal.",
    "Composers reacted against the dense counterpoint of the late Baroque. A transitional galant style, light and tuneful, and the expressive empfindsamer Stil ('sensitive style') of C. P. E. Bach led toward a new ideal: clear melodies over simple accompaniment, balanced phrases, and dramatic contrasts within a single movement."]],
  ["Musical features",[
    "Classical melodies are built from short, symmetrical phrases, often four plus four bars, like a question and answer. Accompaniments are simpler, such as the Alberti bass, a broken-chord pattern in the left hand. Harmony changes more slowly than in Baroque music, and the basso continuo gradually disappeared.",
    "Unlike the Baroque's single affect, a Classical movement can shift moods quickly, from playful to stormy to tender. Dynamics change gradually too: the Mannheim orchestra in Germany became famous for its thrilling crescendos and the 'Mannheim rocket,' a rapidly rising arpeggio."]],
  ["Sonata form",[
    "The most important structure of the era is sonata form (also called sonata-allegro form), typically used for first movements. It has three main parts. The exposition presents the first theme in the home key and a second, contrasting theme in a different key (usually the dominant, or the relative major in minor-key works), linked by a transition. It is usually repeated.",
    "The development takes fragments of the themes and moves them through many keys, building tension. The recapitulation brings back both themes, now both in the home key, resolving the conflict. A coda may round things off. Sonata form is less a rigid mold than a dramatic plan based on key contrast and return."]],
  ["Multi-movement works",[
    "The symphony, string quartet, sonata, and concerto typically follow a four- or three-movement plan. A typical symphony: a fast first movement in sonata form; a slow, lyrical second movement; a minuet and trio (a dance in triple meter, later replaced by the lively scherzo); and a fast finale, often a rondo (A–B–A–C–A) or sonata form.",
    "The Classical concerto, in three movements, includes a cadenza near the end of the first movement, where the soloist plays alone, originally improvised, to display virtuosity."]],
  ["New genres and audiences",[
    "The symphony developed from the Italian opera overture into the central orchestral genre. The string quartet (two violins, viola, cello) became the prestigious chamber genre, a 'conversation among four reasonable people,' as Goethe put it. The piano sonata grew alongside the rising piano.",
    "Public concerts expanded, music publishing boomed, and middle-class amateurs bought sheet music. Still, most composers depended on aristocratic or church patrons, a system that was beginning to change."]],
  ["Vienna",[
    "Vienna, capital of the Habsburg Empire, became the musical center of Europe. The three towering figures of the Classical style, Haydn, Mozart, and Beethoven, all worked there, and are often called the First Viennese School.",
    "Opera also changed. Christoph Willibald Gluck's 'reform operas,' such as Orfeo ed Euridice (1762), stripped away excessive ornament to serve the drama, while comic opera (opera buffa) gained prestige."]]
  ],
  terms:[["Sonata form","Exposition, development, recapitulation structure."],["Alberti bass","Broken-chord accompaniment pattern."],["Cadenza","Solo passage for the soloist in a concerto."],["Minuet and trio","Triple-meter dance movement."],["Rondo","Form with a recurring main theme (A–B–A–C–A)."]],
  w:"Sonata form and the four-movement plan structured symphonies, quartets, and sonatas for over a century.",
  src:["Classical period (music)","Sonata form","Alberti bass","Mannheim school","Christoph Willibald Gluck"],
  q:[
  ["What are the three main sections of sonata form?","Exposition, development, recapitulation","Introduction, aria, finale","Prelude, fugue, coda","Verse, chorus, bridge"],
  ["What is an Alberti bass?","A broken-chord accompaniment pattern","A large string instrument","A bass singer","A slow movement"],
  ["Which orchestra became famous for dramatic crescendos?","Mannheim","Vienna","Leipzig","Paris"],
  ["What is a cadenza?","A solo display passage in a concerto","A final chord","The slow movement","A dance in triple meter"],
  ["Which instruments form a string quartet?","Two violins, viola, cello","Violin, viola, cello, bass","Four violins","Violin, cello, piano, viola"],
  ["What happens in the recapitulation?","Themes return, now in the home key","New themes are introduced","The soloist improvises","Themes move through distant keys"]]},

{ t:"Haydn", s:"Father of the symphony and quartet",
  sec:[
  ["Early life",[
    "Franz Joseph Haydn (1732–1809) was born in the Austrian village of Rohrau, the son of a wheelwright. His fine voice won him a place as a choirboy at St. Stephen's Cathedral in Vienna. When his voice broke he was dismissed and struggled as a freelance musician, teaching himself composition from treatises and C. P. E. Bach's sonatas.",
    "His big break came in 1761 when he entered the service of the Esterházy family, the wealthiest Hungarian noble family, eventually becoming Kapellmeister (music director)."]],
  ["Life at Esterháza",[
    "For nearly thirty years Haydn worked for Prince Nikolaus Esterházy, largely at the magnificent palace of Esterháza, writing symphonies, operas, chamber music, and church music, and leading an orchestra. He wore livery like other servants.",
    "Isolation was, he said, a gift: 'I was cut off from the world... and so I had to become original.' He could experiment with his orchestra and hear results immediately. His 'Farewell' Symphony (No. 45, 1772) ends with musicians leaving one by one, a hint to the prince that the musicians wanted to go home to their families; the prince took the hint."]],
  ["The symphony and quartet",[
    "Haydn wrote 104 numbered symphonies and around 68 string quartets, and did more than anyone to establish both genres. His quartets turned the second violin, viola, and cello from mere accompaniment into true partners, developing themes through motivic work.",
    "His music is famous for wit and surprise. The 'Surprise' Symphony (No. 94) has a sudden loud chord in its quiet slow movement. The 'Emperor' Quartet (Op. 76 No. 3) contains a hymn he wrote for the Austrian emperor; the melody later became the tune of Germany's national anthem."]],
  ["London triumph",[
    "After Prince Nikolaus died in 1790, Haydn, now internationally famous, accepted an invitation from the impresario Johann Peter Salomon to visit London. His two visits (1791–92 and 1794–95) were enormous successes; he composed the twelve 'London' Symphonies (Nos. 93–104) for public concerts and received an honorary doctorate from Oxford.",
    "This was a sign of changing times: a composer could earn fame and money from a paying public, not just a patron."]],
  ["Late oratorios and legacy",[
    "Inspired by hearing Handel's oratorios in London, Haydn wrote The Creation (1798), opening with a famous depiction of chaos and a blazing C-major chord on the words 'and there was light,' and The Seasons (1801). He also wrote masses, and the Trumpet Concerto (1796) for a new keyed trumpet.",
    "Haydn was a friend and admirer of Mozart and briefly taught the young Beethoven. Known affectionately as 'Papa Haydn,' he is called the father of the symphony and of the string quartet."]]
  ],
  terms:[["Kapellmeister","Music director of a court or church."],["Esterházy","Hungarian noble family who employed Haydn."],["Motivic development","Building music from short themes."],["London Symphonies","Haydn's last twelve symphonies, Nos. 93–104."],["The Creation","Haydn's oratorio of 1798."]],
  w:"Haydn defined the symphony and string quartet, the two genres at the heart of the Classical tradition.",
  src:["Joseph Haydn","Symphony No. 45 (Haydn)","Symphony No. 94 (Haydn)","The Creation (Haydn)","Esterházy"],
  q:[
  ["Which noble family employed Haydn for decades?","The Esterházy family","The Habsburgs","The Medici","The Lobkowitz family"],
  ["What happens at the end of Haydn's 'Farewell' Symphony?","Musicians leave one by one","A sudden loud chord","A choir enters","A cannon fires"],
  ["Haydn is often called the father of which two genres?","Symphony and string quartet","Opera and oratorio","Concerto and sonata","Mass and motet"],
  ["What does the 'Surprise' Symphony contain?","A sudden loud chord in a quiet slow movement","A choir in the finale","A drum solo","A tune played backward"],
  ["Haydn's melody from the 'Emperor' Quartet became which anthem?","Germany's national anthem","Austria's current anthem","Britain's national anthem","The European anthem"],
  ["Which oratorio did Haydn write after hearing Handel in London?","The Creation","Messiah","Elijah","St. Paul"]]},

{ t:"Mozart", s:"The prodigy",
  sec:[
  ["A child genius",[
    "Wolfgang Amadeus Mozart (1756–1791) was born in Salzburg, then an independent archbishopric. His father Leopold, a violinist and author of a famous violin method, recognized his son's extraordinary gifts. Wolfgang played keyboard at three, composed at five, and from age six toured Europe with his talented sister Maria Anna ('Nannerl'), performing for royalty in Munich, Vienna, Paris, and London.",
    "In Rome at fourteen, he reportedly wrote out Allegri's closely guarded Miserere from memory after hearing it. These journeys exposed him to every major style of the day."]],
  ["Salzburg and freedom",[
    "As a young man Mozart served the Archbishop of Salzburg, Hieronymus Colloredo, but chafed at being treated as a servant. In 1781, after a bitter quarrel, he was dismissed, literally with a kick from the archbishop's steward, and settled in Vienna as a freelance musician, one of the first major composers to try.",
    "In Vienna he married Constanze Weber, taught, performed his own piano concertos at subscription concerts, and composed operas. Income was unpredictable, and his finances rose and fell."]],
  ["The operas",[
    "Mozart is among the greatest opera composers. The Abduction from the Seraglio (1782) is a German Singspiel. With the librettist Lorenzo Da Ponte he wrote three Italian masterpieces: The Marriage of Figaro (1786), a comedy about servants outwitting a count, based on a controversial play by Beaumarchais; Don Giovanni (1787), about a seducer dragged to hell; and Così fan tutte (1790).",
    "The Magic Flute (1791), a Singspiel with spoken dialogue, mixes fairy tale, comedy, and Masonic symbolism; the Queen of the Night's aria reaches a high F. Mozart's operas create vivid, complex characters and use ensembles in which several characters sing different feelings simultaneously."]],
  ["Instrumental mastery",[
    "Mozart wrote about 41 symphonies; the last three, Nos. 39, 40 (G minor), and 41 ('Jupiter'), were composed in about six weeks in 1788. His 27 piano concertos, many written for himself to play, raised the genre to a summit. He wrote concertos for violin, horn, flute, and clarinet, and great chamber music, including six quartets dedicated to Haydn.",
    "Popular works include Eine kleine Nachtmusik (1787), the Piano Sonata in A major with its 'Rondo alla turca,' and the Clarinet Concerto. His works are catalogued by K. numbers (Köchel catalogue), compiled by Ludwig von Köchel in 1862."]],
  ["Death and myth",[
    "Mozart died in Vienna in December 1791, aged 35, probably of an illness such as rheumatic fever, while writing his Requiem, which was completed by his student Franz Xaver Süssmayr. Legends that his rival Antonio Salieri poisoned him, popularized by Peter Shaffer's play and film Amadeus, are unfounded.",
    "Haydn told Leopold that Wolfgang was the greatest composer he knew. Mozart's music combines elegance and ease with deep emotion, and remains among the most performed in the world."]]
  ],
  terms:[["Singspiel","German opera with spoken dialogue."],["Köchel catalogue","Numbering system (K.) for Mozart's works."],["Da Ponte","Librettist of three Mozart operas."],["Piano concerto","Work for piano soloist and orchestra."],["Requiem","Mass for the dead; Mozart's last work."]],
  w:"Mozart perfected every genre of his time, and his operas remain cornerstones of the repertoire.",
  src:["Wolfgang Amadeus Mozart","The Marriage of Figaro","Don Giovanni","The Magic Flute","Requiem (Mozart)"],
  q:[
  ["In which city was Mozart born?","Salzburg","Vienna","Prague","Munich"],
  ["Who wrote the librettos for Figaro, Don Giovanni, and Così fan tutte?","Lorenzo Da Ponte","Emanuel Schikaneder","Pietro Metastasio","Beaumarchais"],
  ["What do K. numbers refer to?","The Köchel catalogue of Mozart's works","Key signatures","Concert halls","Opera acts"],
  ["Who completed Mozart's Requiem?","Franz Xaver Süssmayr","Antonio Salieri","Joseph Haydn","Leopold Mozart"],
  ["Which Mozart opera is a Singspiel with a Queen of the Night?","The Magic Flute","Don Giovanni","Così fan tutte","Idomeneo"],
  ["What is the nickname of Mozart's Symphony No. 41?","Jupiter","Prague","Linz","Haffner"]]},

{ t:"Beethoven", s:"The bridge to Romanticism",
  sec:[
  ["Bonn and Vienna",[
    "Ludwig van Beethoven (1770–1827) was born in Bonn, where his father, a court singer, drilled him harshly in the hope of creating another Mozart. In 1792 he moved to Vienna, studied briefly with Haydn, and quickly won fame as a fiery piano virtuoso and improviser.",
    "Unlike Haydn, he was never a household servant; aristocratic patrons such as Prince Lichnowsky, Prince Lobkowitz, and Archduke Rudolph supported him, sometimes with annual stipends, while he sold works to publishers."]],
  ["Deafness",[
    "In his late twenties Beethoven began losing his hearing. In 1802, in a letter to his brothers called the Heiligenstadt Testament, he described his despair and his resolve to live for his art. Eventually he became almost completely deaf, communicating through conversation books, yet he continued to compose.",
    "At the premiere of the Ninth Symphony in 1824, he had to be turned around to see the audience applauding."]],
  ["Three periods",[
    "Scholars traditionally divide his work into three periods. The early period (to about 1802) builds on Haydn and Mozart, with works like the first two symphonies, the 'Pathétique' Sonata, and the Op. 18 quartets.",
    "The middle or 'heroic' period expands the scale and drama: the Third Symphony 'Eroica' (1804), originally dedicated to Napoleon until Beethoven tore up the title page when Napoleon crowned himself emperor; the Fifth Symphony, with its famous four-note opening motif; the Sixth 'Pastoral'; the 'Emperor' Piano Concerto; the Violin Concerto; the 'Appassionata' and 'Waldstein' sonatas; and his only opera, Fidelio, about freedom from tyranny. The late period (from about 1815) is introspective and visionary: the last piano sonatas including the 'Hammerklavier,' the Missa solemnis, the late string quartets including the Große Fuge, and the Ninth Symphony."]],
  ["The Ninth Symphony",[
    "The Ninth Symphony (1824) broke the boundaries of the genre by adding vocal soloists and a chorus in its finale, setting Friedrich Schiller's poem 'Ode to Joy' with its message of universal brotherhood. Its melody is now the anthem of the European Union.",
    "Its scale and ambition haunted later composers; many feared writing a ninth symphony."]],
  ["His innovations",[
    "Beethoven expanded every form: longer developments and codas, a scherzo in place of the minuet, linking movements without pause, and building whole works from tiny motifs. He treated music as personal expression and moral struggle, often moving from darkness to triumph, as in the Fifth Symphony's progress from C minor to a blazing C-major finale.",
    "His 32 piano sonatas are called the 'New Testament' of the piano (with Bach's Well-Tempered Clavier the 'Old Testament'). Popular pieces include the 'Moonlight' Sonata and 'Für Elise.'"]],
  ["Legacy",[
    "When Beethoven died in 1827, an estimated 10,000 or more people attended his funeral. He created the model of the composer as an independent, heroic artist, a genius serving his own vision rather than a patron.",
    "He stands at the boundary between the Classical and Romantic eras, and almost every 19th-century composer measured themselves against him."]]
  ],
  terms:[["Heiligenstadt Testament","Beethoven's 1802 letter about his deafness."],["Eroica","Symphony No. 3, once dedicated to Napoleon."],["Scherzo","Fast, playful movement replacing the minuet."],["Ode to Joy","Schiller poem set in the Ninth Symphony finale."],["Fidelio","Beethoven's only opera."]],
  w:"Beethoven turned music into personal drama and created the image of the composer as independent artist.",
  src:["Ludwig van Beethoven","Symphony No. 9 (Beethoven)","Symphony No. 5 (Beethoven)","Heiligenstadt Testament","Symphony No. 3 (Beethoven)"],
  q:[
  ["Which symphony was originally dedicated to Napoleon?","Symphony No. 3 'Eroica'","Symphony No. 5","Symphony No. 6 'Pastoral'","Symphony No. 9"],
  ["Which poem is set in the finale of the Ninth Symphony?","Schiller's 'Ode to Joy'","Goethe's 'Erlkönig'","Heine's 'Lorelei'","Homer's Odyssey"],
  ["What is the Heiligenstadt Testament?","A letter about his deafness and despair","His last will about money","A symphony","A theory book"],
  ["What was Beethoven's only opera?","Fidelio","Don Giovanni","Der Freischütz","Egmont"],
  ["Where was Beethoven born?","Bonn","Vienna","Salzburg","Leipzig"],
  ["The Ninth Symphony's melody is the anthem of what?","The European Union","Germany","Austria","The United Nations"]]}

]});


/* ---- from music-08.js ---- */
/* MUSIC FOUNDATIONS, part 8: Unit 4 chapters 5-8 */
COURSES.music.units[3].ch.push(

{ t:"Romanticism and Schubert", s:"Feeling, nature, and song",
  sec:[
  ["What Romanticism meant",[
    "Romanticism, roughly 1820 to 1900 in music, valued emotion, imagination, individuality, nature, the supernatural, the past, and national identity over Enlightenment balance and reason. Writers such as Goethe, E. T. A. Hoffmann, and Byron inspired composers, and Hoffmann called instrumental music 'the most Romantic of all the arts' because it expressed the infinite beyond words.",
    "Romantic music features expressive, song-like melodies; richer, more chromatic harmony; a wider range of dynamics and tone colors; expanded orchestras; and both very short intimate pieces and enormous works."]],
  ["Musical life changes",[
    "The middle class became music's main audience. Public concert halls, conservatories, music journalism, and piano-owning households grew. The virtuoso performer became a celebrity, and composers increasingly worked as independent artists, teachers, critics, and conductors.",
    "A canon of 'great works' by dead composers, especially Bach, Mozart, and Beethoven, became the core of concert programs for the first time."]],
  ["Program music and absolute music",[
    "Many Romantics wrote program music, instrumental music linked to a story, poem, painting, or idea, signaled by a title or written program. Others championed absolute music, valued for its pure musical form without external meaning; the critic Eduard Hanslick defended this view. Debates between the camps shaped the century.",
    "Character pieces, short piano works capturing a mood, such as nocturnes, impromptus, and songs without words, were especially Romantic."]],
  ["Franz Schubert",[
    "Franz Schubert (1797–1828) lived his whole short life in Vienna. Never a celebrated public figure, he was supported by a circle of friends who held musical evenings called 'Schubertiades.' He died at 31, yet left over 600 songs, nine symphonies, piano sonatas, chamber music, and masses.",
    "His Symphony No. 8 is called the 'Unfinished' because he wrote only two movements; the 'Great' C major Symphony (No. 9) was discovered after his death by Robert Schumann. Chamber works include the 'Trout' Quintet and the String Quintet in C, and his piano Impromptus remain favorites."]],
  ["The Lied",[
    "Schubert was the first great master of the Lied (plural Lieder), German art song for voice and piano setting Romantic poetry. In his Lieder the piano is an equal partner that paints the scene: in 'Erlkönig' (written at about 18, setting Goethe's ballad), pounding piano triplets depict a galloping horse as a father rides with his dying son, and the singer voices four characters.",
    "He wrote song cycles, sets of songs telling a story: Die schöne Müllerin and the bleak Winterreise ('Winter Journey'), 24 songs of a rejected wanderer. Later Lieder masters include Schumann, Brahms, Hugo Wolf, and Richard Strauss."]],
  ["Schubert's legacy",[
    "Schubert's gift for melody is legendary, but he also explored daring harmony, often shifting suddenly to distant keys and between major and minor for poignant effects.",
    "Recognition came mostly after his death, as Schumann, Mendelssohn, and Brahms championed his works. He was buried near Beethoven, whom he revered."]]
  ],
  terms:[["Romanticism","19th-century movement valuing emotion and imagination."],["Lied","German art song for voice and piano."],["Song cycle","Linked set of songs telling a story."],["Program music","Instrumental music tied to an external story or idea."],["Absolute music","Music valued purely for its form."]],
  w:"Romanticism made music a language of personal feeling; Schubert made the art song a major form.",
  src:["Romantic music","Franz Schubert","Lied","Erlkönig (Schubert)","Winterreise"],
  q:[
  ["Which Schubert song depicts a father riding with his dying son?","Erlkönig","Ave Maria","Gretchen am Spinnrade","Der Lindenbaum"],
  ["What is a Lied?","A German art song for voice and piano","A French opera","An Italian dance","A choral mass"],
  ["Why is Schubert's Symphony No. 8 called 'Unfinished'?","He completed only two movements","He died while conducting it","It has no ending chord","It was lost"],
  ["What is Winterreise?","A song cycle of 24 songs","A symphony","An opera","A piano sonata"],
  ["What is program music?","Instrumental music linked to a story or idea","Music printed in concert programs","Music for radio","Music without melody"],
  ["What were Schubertiades?","Musical gatherings of Schubert's friends","Schubert's symphonies","Vienna's concert halls","Schubert's piano pieces"]]},

{ t:"The Romantic Piano", s:"Chopin, Liszt, Schumann",
  sec:[
  ["The age of the piano",[
    "By the 1830s the piano had become stronger and more powerful, with iron frames and a faster action that allowed rapid repeated notes. It became the instrument of the Romantic era: in salons, concert halls, and middle-class homes.",
    "Virtuoso pianists toured Europe, and composers wrote both dazzling showpieces and intimate miniatures."]],
  ["Frédéric Chopin",[
    "Frédéric Chopin (1810–1849), born near Warsaw to a French father and Polish mother, settled in Paris in 1831 after the failed Polish uprising against Russia. He wrote almost exclusively for solo piano and preferred intimate salons to large concert halls.",
    "His works include nocturnes, mazurkas and polonaises (Polish dances expressing his national feeling), ballades, scherzos, études that make technical exercises into poetry, waltzes, preludes, and sonatas. His style is known for singing melodies, rich harmony, and rubato, flexible 'stolen' time. He had a famous relationship with the novelist George Sand and died of tuberculosis at 39."]],
  ["Franz Liszt",[
    "Franz Liszt (1811–1886), born in Hungary, was the greatest piano virtuoso of the century and arguably the first modern superstar. His concerts produced fan frenzy that the poet Heinrich Heine called 'Lisztomania.' He invented the solo recital and turned the piano sideways on stage so audiences could see his profile.",
    "He wrote Hungarian Rhapsodies, the Transcendental Études, a Sonata in B minor, and transcriptions of symphonies and operas that spread music widely. As a conductor at Weimar he championed new music, including Wagner's, and invented the symphonic poem. In later life he took minor orders in the Catholic Church and wrote experimental late works that anticipated 20th-century harmony. He was also a generous teacher."]],
  ["Robert and Clara Schumann",[
    "Robert Schumann (1810–1856) wanted to be a concert pianist until a hand injury ended that path. He founded an influential music journal, the Neue Zeitschrift für Musik, where he championed Chopin ('Hats off, gentlemen, a genius!') and later the young Brahms. His piano cycles, such as Carnaval and Kinderszenen ('Scenes from Childhood'), are full of literary imagination; he also wrote symphonies, a piano concerto, and song cycles. He suffered from mental illness and died in an asylum.",
    "Clara Wieck Schumann (1819–1896), his wife, was one of the greatest pianists of the century, performing for more than sixty years and helping establish the modern recital repertoire, while raising eight children. She was also a composer, of a Piano Trio and a Piano Concerto among other works."]],
  ["Felix and Fanny Mendelssohn",[
    "Felix Mendelssohn (1809–1847) was a prodigy whose Octet for strings (written at 16) and overture to A Midsummer Night's Dream (at 17) are masterpieces. His Songs Without Words popularized lyrical piano pieces.",
    "His sister Fanny Mendelssohn Hensel was equally gifted; social expectations for women limited her public career, though she composed hundreds of works and published some under her own name shortly before her death."]]
  ],
  terms:[["Rubato","Flexible tempo, 'stolen time,' for expression."],["Étude","Study piece focused on a technique."],["Nocturne","Lyrical 'night piece' for piano."],["Mazurka","Polish folk dance in triple meter."],["Recital","Solo concert, a format popularized by Liszt."]],
  w:"Romantic piano music is the core of the pianist's repertoire and shaped the idea of the celebrity performer.",
  src:["Frédéric Chopin","Franz Liszt","Robert Schumann","Clara Schumann","Lisztomania"],
  q:[
  ["Which composer wrote almost exclusively for solo piano and settled in Paris?","Frédéric Chopin","Franz Liszt","Robert Schumann","Felix Mendelssohn"],
  ["Who inspired the term 'Lisztomania'?","Franz Liszt","Niccolò Paganini","Chopin","Clara Schumann"],
  ["What is rubato?","Flexible, expressive tempo","A fast dance","A loud ending","A piano pedal"],
  ["Who founded the Neue Zeitschrift für Musik?","Robert Schumann","Johannes Brahms","Franz Liszt","Richard Wagner"],
  ["Mazurkas and polonaises expressed Chopin's ties to which nation?","Poland","Hungary","France","Russia"],
  ["Which of these was one of the century's greatest concert pianists?","Clara Schumann","Fanny Mendelssohn","George Sand","Cosima Wagner"]]},

{ t:"The Romantic Orchestra", s:"Berlioz, Brahms, and the symphony",
  sec:[
  ["Berlioz and the Symphonie fantastique",[
    "Hector Berlioz (1803–1869), a French composer and brilliant critic, wrote the Symphonie fantastique (1830), a landmark of program music. It portrays an artist's obsessive love through five movements, including a ball, a march to the scaffold, and a witches' sabbath that quotes the medieval chant Dies irae. A recurring theme, the idée fixe, represents the beloved and changes with each episode.",
    "Berlioz expanded the orchestra's colors dramatically and wrote a famous Treatise on Instrumentation. Other works include Harold in Italy, the dramatic legend The Damnation of Faust, the huge Requiem, and the opera Les Troyens."]],
  ["Mendelssohn and the concert hall",[
    "Felix Mendelssohn wrote five symphonies, including the 'Scottish' and 'Italian,' the Hebrides Overture (Fingal's Cave), a famous Violin Concerto in E minor, and the oratorio Elijah. As conductor of the Leipzig Gewandhaus Orchestra he shaped concert life and founded the Leipzig Conservatory (1843).",
    "His Wedding March from A Midsummer Night's Dream is still played at weddings worldwide."]],
  ["Johannes Brahms",[
    "Johannes Brahms (1833–1897), born in Hamburg, was hailed by Schumann in 1853 as the coming genius. Close to Clara Schumann for the rest of his life, he settled in Vienna. Brahms wrote in Classical forms with Romantic warmth, absorbing Bach's counterpoint and Beethoven's structure.",
    "Fearing comparison with Beethoven, he took around two decades to finish his First Symphony (1876), nicknamed 'Beethoven's Tenth' by the conductor Hans von Bülow. He wrote four symphonies, two piano concertos, a Violin Concerto, A German Requiem (setting biblical texts of comfort rather than the Latin Mass), Hungarian Dances, chamber music, and Lieder, including the famous Lullaby. Von Bülow grouped him with Bach and Beethoven as 'the three B's.'"]],
  ["The War of the Romantics",[
    "Mid-century musical life split into factions. The 'New German School' of Liszt and Wagner believed music should develop through program music, music drama, and new harmony. Conservatives, with Brahms as figurehead and the critic Hanslick as spokesman, defended absolute music and traditional forms.",
    "The rivalry was mostly between partisans; Brahms himself admired parts of Wagner's music. Both paths deeply influenced the future."]],
  ["The symphonic poem and the concerto",[
    "Liszt created the symphonic poem (or tone poem), a one-movement orchestral work telling a story or depicting a subject, such as Les préludes. It became popular with Smetana, Tchaikovsky, Dvořák, Sibelius, and Richard Strauss.",
    "The Romantic concerto became a showcase of virtuosity and drama. Paganini, the demonic violin virtuoso, inspired a generation; famous works include the violin concertos of Mendelssohn, Bruch, Brahms, and Tchaikovsky, and piano concertos by Schumann, Grieg, Liszt, Brahms, and Tchaikovsky. Anton Bruckner, an Austrian organist, wrote vast, cathedral-like symphonies."]]
  ],
  terms:[["Idée fixe","Berlioz's recurring theme representing an obsession."],["Symphonic poem","One-movement orchestral work on a story or subject."],["Three B's","Bach, Beethoven, Brahms."],["New German School","Liszt and Wagner's progressive faction."],["Dies irae","Medieval chant on the Day of Judgment."]],
  w:"The Romantic orchestra grew larger and more colorful, and its symphonies and concertos form the core of concert programs.",
  src:["Symphonie fantastique","Hector Berlioz","Johannes Brahms","Symphonic poem","War of the Romantics"],
  q:[
  ["What is the idée fixe in the Symphonie fantastique?","A recurring theme representing the beloved","A fixed tempo","A chord progression","A dance rhythm"],
  ["Which composer's First Symphony was called 'Beethoven's Tenth'?","Brahms","Bruckner","Mendelssohn","Schumann"],
  ["Who invented the symphonic poem?","Franz Liszt","Hector Berlioz","Richard Strauss","Bedřich Smetana"],
  ["Who are the 'three B's'?","Bach, Beethoven, Brahms","Bach, Berlioz, Bruckner","Beethoven, Bizet, Brahms","Bartók, Berg, Britten"],
  ["Which medieval chant appears in the Symphonie fantastique?","Dies irae","Ave Maria","Salve Regina","Te Deum"],
  ["Brahms's A German Requiem sets what texts?","Biblical texts of comfort in German","The Latin Requiem Mass","Goethe's poems","Folk songs"]]},

{ t:"Italian Opera", s:"Rossini, Verdi, Puccini",
  sec:[
  ["Bel canto opera",[
    "In early 19th-century Italy, opera was the dominant art form, attended by all classes. The bel canto composers emphasized beautiful, agile singing. Gioachino Rossini (1792–1868) wrote sparkling comic operas such as The Barber of Seville (1816) and La Cenerentola, and the grand William Tell (1829), whose overture is world-famous. He then retired from opera at 37 and lived nearly forty more years.",
    "Gaetano Donizetti wrote about 70 operas, including Lucia di Lammermoor, with its famous mad scene, and the comedy L'elisir d'amore. Vincenzo Bellini's long, floating melodies in Norma and La sonnambula influenced Chopin."]],
  ["Giuseppe Verdi",[
    "Giuseppe Verdi (1813–1901) dominated Italian opera for half a century. His early opera Nabucco (1842) contains the chorus 'Va, pensiero,' sung by Hebrew exiles, which later became associated with Italian national feeling. During the Risorgimento, the movement to unify Italy, 'Viva VERDI' was read as an acronym for Vittorio Emanuele Re d'Italia (Victor Emmanuel, King of Italy).",
    "Verdi's middle-period trio Rigoletto (1851), Il trovatore (1853), and La traviata (1853) remain staples. Later works such as Aida (1871), written for Cairo, the Requiem (1874), and two Shakespeare operas from his seventies and eighties, Otello (1887) and the comedy Falstaff (1893), show constant growth. Verdi focused on human drama, strong melody, and dramatic pacing."]],
  ["Verismo and Puccini",[
    "Late in the century, verismo ('realism') opera depicted everyday people and violent passions, as in Mascagni's Cavalleria rusticana (1890) and Leoncavallo's Pagliacci (1892), with its aria 'Vesti la giubba.'",
    "Giacomo Puccini (1858–1924) combined lush orchestration, unforgettable melody, and theatrical skill. La bohème (1896), about poor artists in Paris, Tosca (1900), and Madama Butterfly (1904) are among the most performed operas in the world. His unfinished Turandot (1926) contains 'Nessun dorma,' made famous worldwide by Luciano Pavarotti."]],
  ["French and other opera",[
    "Paris was another opera capital. Grand opéra, such as Meyerbeer's Les Huguenots, featured historical spectacle, ballets, and huge casts. Georges Bizet's Carmen (1875), about a free-spirited Spanish woman and a soldier, shocked audiences with its realism but became one of the most popular operas ever, with the 'Habanera' and 'Toreador Song.' Gounod's Faust and Massenet's Manon were also successes.",
    "Operetta, light opera with spoken dialogue, flourished with Jacques Offenbach in Paris (the 'can-can' from Orpheus in the Underworld), Johann Strauss II in Vienna (Die Fledermaus), and Gilbert and Sullivan in London (The Pirates of Penzance, The Mikado)."]],
  ["How to listen to opera",[
    "Opera combines singing, orchestra, drama, design, and sometimes dance. Key terms: the libretto is the text; the overture or prelude opens the work; arias are solos; duets, trios, and ensembles combine voices; and choruses represent crowds.",
    "Opera houses such as La Scala (Milan), the Metropolitan Opera (New York), the Royal Opera House (London), the Vienna State Opera, and the Paris Opera are cultural landmarks. Surtitles projected above the stage now let audiences follow the words."]]
  ],
  terms:[["Bel canto","Opera style emphasizing beautiful, agile singing."],["Verismo","Realistic Italian opera of everyday passions."],["Risorgimento","19th-century movement for Italian unification."],["Operetta","Light opera with spoken dialogue."],["Surtitles","Translations projected above the stage."]],
  w:"Italian opera produced many of the most famous melodies in the world and remains central to opera houses everywhere.",
  src:["Giuseppe Verdi","Giacomo Puccini","Gioachino Rossini","Carmen","Verismo (music)"],
  q:[
  ["Which composer wrote La traviata, Rigoletto, and Aida?","Giuseppe Verdi","Giacomo Puccini","Gioachino Rossini","Gaetano Donizetti"],
  ["Which opera contains 'Nessun dorma'?","Turandot","Tosca","La bohème","Madama Butterfly"],
  ["Who wrote The Barber of Seville (1816)?","Gioachino Rossini","Mozart","Verdi","Bellini"],
  ["What does 'verismo' mean?","Realism","Beautiful singing","Grand spectacle","Comedy"],
  ["Which opera by Bizet features the 'Habanera'?","Carmen","Faust","Manon","Les Huguenots"],
  ["Which famous Milan opera house premiered many Italian operas?","La Scala","La Fenice","Teatro San Carlo","Covent Garden"]]}

);


/* ---- from music-09.js ---- */
/* MUSIC FOUNDATIONS, part 9: Unit 4 chapters 9-12 */
COURSES.music.units[3].ch.push(

{ t:"Wagner and Music Drama", s:"The total work of art",
  sec:[
  ["A revolutionary",[
    "Richard Wagner (1813–1883), born in Leipzig, was among the most influential and controversial figures in music history. Early operas such as The Flying Dutchman (1843), Tannhäuser, and Lohengrin (with its 'Bridal Chorus,' still played at weddings) brought success. After taking part in the 1849 Dresden uprising he fled into exile in Switzerland, where he wrote essays on the future of art.",
    "He argued for the Gesamtkunstwerk, 'total work of art,' uniting music, poetry, drama, and staging into one whole, and called his mature works music dramas rather than operas. He wrote his own librettos, mostly drawn from Germanic and Norse myth and medieval legend."]],
  ["Leitmotifs and endless melody",[
    "Wagner abandoned the old division into separate arias and recitatives in favor of continuous music ('endless melody'), where the orchestra carries a symphonic web of themes. Leitmotifs are short musical ideas associated with characters, objects, places, or emotions, which recur and transform as the drama unfolds: in the Ring there are motifs for the gold, the ring, the sword, Valhalla, and fate.",
    "This technique directly influenced film music: composers such as John Williams use leitmotifs for characters like Darth Vader."]],
  ["The Ring",[
    "Der Ring des Nibelungen (The Ring of the Nibelung) is a cycle of four music dramas, Das Rheingold, Die Walküre, Siegfried, and Götterdämmerung (Twilight of the Gods), lasting about fifteen hours. Composed over roughly 26 years, it tells of a magic ring forged from stolen Rhine gold and the downfall of the gods. 'The Ride of the Valkyries' is its most famous excerpt.",
    "With the support of King Ludwig II of Bavaria, Wagner built his own theater at Bayreuth, designed with a hidden orchestra pit, where the complete Ring premiered in 1876. The Bayreuth Festival still performs only his works."]],
  ["Tristan and harmony",[
    "Tristan und Isolde (1865) tells of doomed love. Its opening 'Tristan chord' and harmony that constantly delays resolution created a sense of endless longing and pushed tonality toward its limits, a decisive step toward 20th-century music.",
    "Wagner also wrote the comedy Die Meistersinger von Nürnberg and his last work, Parsifal (1882), based on the Grail legend."]],
  ["A troubling legacy",[
    "Wagner's genius is matched by serious moral problems. He wrote the antisemitic essay 'Jewishness in Music' (1850), and his family later had close ties to Adolf Hitler, who idolized his music. Wagner's works are still rarely performed in Israel.",
    "Debate continues on how to separate the art from the man. Musically, Wagner's harmonies, orchestration, and ideas transformed opera and influenced composers from Bruckner and Mahler to Debussy and Schoenberg."]]
  ],
  terms:[["Gesamtkunstwerk","Wagner's 'total work of art' uniting all arts."],["Leitmotif","Recurring theme tied to a character or idea."],["Music drama","Wagner's term for his continuous operas."],["Bayreuth","Wagner's festival theater in Bavaria."],["Tristan chord","Ambiguous opening chord of Tristan und Isolde."]],
  w:"Wagner's leitmotifs and harmony transformed opera and gave film music its central technique.",
  src:["Richard Wagner","Der Ring des Nibelungen","Leitmotif","Tristan chord","Bayreuth Festival"],
  q:[
  ["What is a leitmotif?","A recurring theme linked to a character or idea","A type of aria","A conductor's gesture","A German dance"],
  ["How many music dramas make up Wagner's Ring cycle?","Four","Three","Five","Seven"],
  ["Where did Wagner build his own festival theater?","Bayreuth","Munich","Dresden","Leipzig"],
  ["What does 'Gesamtkunstwerk' mean?","Total work of art","Endless melody","Music drama","Grand opera"],
  ["Which Wagner work is famous for a harmonically ambiguous opening chord?","Tristan und Isolde","Lohengrin","Parsifal","Tannhäuser"],
  ["Which king supported Wagner and helped fund Bayreuth?","Ludwig II of Bavaria","Wilhelm I of Prussia","Franz Joseph of Austria","Victor Emmanuel II"]]},

{ t:"Musical Nationalism", s:"Folk roots and national voices",
  sec:[
  ["Why nationalism",[
    "In the 19th century, as nations sought independence or unity, many composers used folk songs, dances, legends, and landscapes to create a national voice. This was partly a reaction against the dominance of German, Italian, and French music.",
    "Nationalist music used folk melodies and rhythms, modal scales, national history and myths, and programmatic depictions of homeland scenes."]],
  ["Russia and 'The Mighty Handful'",[
    "Mikhail Glinka's opera A Life for the Tsar (1836) is considered the start of Russian national music. In St. Petersburg, a group of mostly self-taught composers, Mily Balakirev, César Cui, Modest Mussorgsky, Alexander Borodin (a chemist by profession), and Nikolai Rimsky-Korsakov, known as 'The Five' or 'The Mighty Handful,' sought a distinctly Russian sound.",
    "Mussorgsky wrote the opera Boris Godunov and the piano suite Pictures at an Exhibition, later orchestrated by Ravel. Borodin wrote the opera Prince Igor, with its 'Polovtsian Dances.' Rimsky-Korsakov, a master orchestrator, wrote Scheherazade (1888) and 'Flight of the Bumblebee' and taught Stravinsky."]],
  ["Bohemia",[
    "Bedřich Smetana (1824–1884) wrote the opera The Bartered Bride and the cycle of symphonic poems Má vlast ('My Homeland'), including 'Vltava' ('The Moldau'), tracing the river through the Czech countryside. He became deaf late in life, like Beethoven.",
    "Antonín Dvořák (1841–1904) wrote Slavonic Dances, nine symphonies, a famous Cello Concerto, and the opera Rusalka. Invited to direct the National Conservatory in New York (1892–95), he wrote Symphony No. 9 'From the New World' and urged Americans to build their own national music on African American spirituals and Native American music."]],
  ["Scandinavia and elsewhere",[
    "Norway's Edvard Grieg (1843–1907) wrote the Piano Concerto in A minor and incidental music to Ibsen's play Peer Gynt, including 'In the Hall of the Mountain King' and 'Morning Mood.' Finland's Jean Sibelius (1865–1957) wrote seven symphonies, a Violin Concerto, and Finlandia (1899), which became a symbol of resistance to Russian rule.",
    "Spain's Isaac Albéniz, Enrique Granados, and Manuel de Falla drew on Spanish and flamenco styles. In England, Edward Elgar (Enigma Variations, Pomp and Circumstance marches) and Ralph Vaughan Williams, who collected English folk songs, led a national revival. Hungary's Bartók and Kodály later took folk research to scientific levels."]],
  ["Folk and art music",[
    "Nationalist composers often used real folk melodies, but frequently created new tunes in folk style. Their work raised questions that still matter: who defines a nation's music, and how should composers borrow from traditions?",
    "Nationalism spread classical music into new regions and enriched it with fresh rhythms, scales, and colors."]]
  ],
  terms:[["Musical nationalism","Using national folk elements and themes in composition."],["The Mighty Handful","Five Russian nationalist composers."],["Má vlast","Smetana's cycle 'My Homeland.'"],["Finlandia","Sibelius's patriotic tone poem."],["New World Symphony","Dvořák's Symphony No. 9, written in America."]],
  w:"Nationalism broadened classical music beyond Germany, Italy, and France and gave many nations a musical identity.",
  src:["Nationalism in music","The Five (composers)","Antonín Dvořák","Edvard Grieg","Jean Sibelius"],
  q:[
  ["Which work traces a river through the Czech countryside?","Smetana's 'Vltava' (The Moldau)","Dvořák's New World Symphony","Grieg's Peer Gynt","Sibelius's Finlandia"],
  ["Which Russian composer of The Five was also a chemist?","Alexander Borodin","Modest Mussorgsky","César Cui","Mily Balakirev"],
  ["Dvořák's Symphony No. 9 is subtitled what?","From the New World","Pathétique","Resurrection","Titan"],
  ["Who wrote 'In the Hall of the Mountain King'?","Edvard Grieg","Jean Sibelius","Carl Nielsen","Rimsky-Korsakov"],
  ["Which piece became a symbol of Finnish resistance to Russian rule?","Finlandia","Karelia Suite","Valse triste","The Swan of Tuonela"],
  ["Who orchestrated Mussorgsky's Pictures at an Exhibition in its famous version?","Maurice Ravel","Rimsky-Korsakov","Stravinsky","Debussy"]]},

{ t:"Tchaikovsky and Ballet", s:"Melody, emotion, and dance",
  sec:[
  ["Tchaikovsky's life",[
    "Pyotr Ilyich Tchaikovsky (1840–1893) worked as a civil servant before studying at the new St. Petersburg Conservatory and teaching at the Moscow Conservatory. Less nationalist than The Five, he combined Russian character with Western European forms and training.",
    "He was a sensitive, often troubled man. A wealthy widow, Nadezhda von Meck, supported him with a stipend for thirteen years on the condition that they never meet. He died in St. Petersburg nine days after conducting the premiere of his Sixth Symphony; cholera is the official cause, though theories have circulated."]],
  ["Symphonies and concertos",[
    "Tchaikovsky wrote six numbered symphonies; the Fourth, Fifth, and especially the Sixth, 'Pathétique,' which ends in a slow, despairing finale, are passionate and dramatic. His Piano Concerto No. 1 (1875), with its grand opening chords, and his Violin Concerto (1878) are among the most popular concertos ever written.",
    "He also wrote the fantasy-overture Romeo and Juliet, whose love theme has become a shorthand for romance, the 1812 Overture (with cannon fire), and operas such as Eugene Onegin and The Queen of Spades."]],
  ["The great ballets",[
    "Ballet had developed at the French court and was formalized in France in the 17th century; by the 19th century Russia's Imperial Ballet in St. Petersburg was a leading center. Before Tchaikovsky, ballet music was often considered secondary, functional accompaniment.",
    "Tchaikovsky gave ballet symphonic richness. Swan Lake (1877), The Sleeping Beauty (1890), and The Nutcracker (1892), the latter two created with choreographer Marius Petipa, are the most famous ballets in the world. The Nutcracker, with the 'Dance of the Sugar Plum Fairy' featuring the celesta, a new instrument he introduced to Russia, is a Christmas tradition everywhere."]],
  ["How ballet music works",[
    "Classical ballet is built from set numbers: the pas de deux (dance for two) with its adagio, variations for each dancer, and coda; character dances drawn from national styles; and divertissements, displays of dancing. Music must suit the dancers' movement and tempo while telling a story without words.",
    "Earlier ballets such as Adolphe Adam's Giselle (1841) and Léo Delibes's Coppélia (1870) were important; Tchaikovsky raised the art form's musical ambitions."]],
  ["Ballet after Tchaikovsky",[
    "In 1909, impresario Sergei Diaghilev founded the Ballets Russes in Paris, commissioning revolutionary works from Stravinsky (The Firebird, Petrushka, The Rite of Spring), Ravel (Daphnis et Chloé), Debussy, and Prokofiev, with designs by artists such as Picasso. This made ballet a center of modernism.",
    "Later ballet scores include Prokofiev's Romeo and Juliet and Cinderella and Aaron Copland's Appalachian Spring."]]
  ],
  terms:[["Pas de deux","Dance for two in ballet."],["Celesta","Keyboard instrument with bell-like tone."],["Ballets Russes","Diaghilev's revolutionary ballet company."],["Pathétique","Tchaikovsky's Sixth Symphony."],["Divertissement","Display dances within a ballet."]],
  w:"Tchaikovsky's melodies are some of the most loved in classical music, and his ballets remain the heart of dance.",
  src:["Pyotr Ilyich Tchaikovsky","The Nutcracker","Swan Lake","Ballets Russes","Marius Petipa"],
  q:[
  ["Which of these is a Tchaikovsky ballet?","The Nutcracker","Giselle","Coppélia","The Firebird"],
  ["What instrument did Tchaikovsky use for the Sugar Plum Fairy?","Celesta","Glockenspiel","Harp","Harpsichord"],
  ["Who supported Tchaikovsky on condition they never meet?","Nadezhda von Meck","Clara Schumann","Catherine the Great","George Sand"],
  ["What is the nickname of Tchaikovsky's Sixth Symphony?","Pathétique","Eroica","Titan","Tragic"],
  ["Who founded the Ballets Russes?","Sergei Diaghilev","Marius Petipa","Vaslav Nijinsky","Igor Stravinsky"],
  ["What is a pas de deux?","A dance for two","A solo variation","A group finale","A national dance"]]},

{ t:"The Late Romantics", s:"Mahler, Strauss, and the end of an era",
  sec:[
  ["Gustav Mahler",[
    "Gustav Mahler (1860–1911), born in Bohemia, was the most famous conductor of his day, directing the Vienna Court Opera from 1897 to 1907 and later the Metropolitan Opera and New York Philharmonic. He composed mainly in summers, in small huts in the Austrian countryside.",
    "His nine completed symphonies (and an unfinished Tenth) are vast, often over an hour long, mixing grandeur, folk tunes, marches, birdsong, and irony. He said, 'A symphony must be like the world; it must embrace everything.' Several include voices, such as the Second 'Resurrection' and the Eighth, called the 'Symphony of a Thousand' for its huge forces. His song cycles include Das Lied von der Erde ('The Song of the Earth') and Kindertotenlieder."]],
  ["Richard Strauss",[
    "Richard Strauss (1864–1949) wrote brilliant tone poems: Don Juan, Till Eulenspiegel, Death and Transfiguration, Don Quixote, and Also sprach Zarathustra (1896), whose opening sunrise fanfare became famous through Stanley Kubrick's film 2001: A Space Odyssey.",
    "He then turned to opera: the shocking Salome (1905), with its 'Dance of the Seven Veils,' and Elektra, which pushed dissonance to extremes, then the lush, nostalgic comedy Der Rosenkavalier (1911). In old age he wrote the Four Last Songs (1948). His role as head of the Nazi state music bureau (1933–35) remains a controversial part of his legacy."]],
  ["Other late Romantics",[
    "Anton Bruckner (1824–1896) wrote monumental symphonies inspired by his Catholic faith and organ playing. Hugo Wolf perfected the Lied. Sergei Rachmaninoff (1873–1943), one of the greatest pianists ever, wrote lush Romantic piano concertos (especially No. 2 and No. 3), the Rhapsody on a Theme of Paganini, and preludes well into the 20th century.",
    "In France, César Franck, Camille Saint-Saëns (The Carnival of the Animals, the 'Organ' Symphony), and Gabriel Fauré (Requiem) developed a refined French style. In England, Elgar's Cello Concerto and symphonies are late-Romantic landmarks."]],
  ["Stretching tonality",[
    "By 1900 composers had pushed chromatic harmony so far that the sense of a home key was weakening. Wagner's Tristan, Mahler's late works, and Strauss's Salome and Elektra stretched tonality to its breaking point.",
    "At the same time, orchestras reached enormous sizes, and works grew longer and more extreme. Many felt that Romanticism had reached its end and that something radically new must come."]],
  ["Fin de siècle",[
    "Vienna around 1900 was a ferment of ideas: Freud's psychoanalysis, Klimt's painting, and new architecture. Mahler, Strauss, and Alexander Zemlinsky mentored younger composers such as Arnold Schoenberg, who would soon abandon tonality altogether.",
    "The late Romantic era thus led directly into the revolutions of 20th-century music."]]
  ],
  terms:[["Late Romanticism","Era around 1880–1915 of huge forms and extreme chromaticism."],["Tone poem","Another name for the symphonic poem."],["Resurrection Symphony","Mahler's Second Symphony."],["Also sprach Zarathustra","Strauss tone poem used in 2001: A Space Odyssey."],["Chromaticism","Use of notes outside the key."]],
  w:"The late Romantics produced some of the most emotionally overwhelming music ever and set the stage for modernism.",
  src:["Gustav Mahler","Richard Strauss","Sergei Rachmaninoff","Also sprach Zarathustra (Strauss)","Late Romantic music"],
  q:[
  ["Which composer said 'A symphony must be like the world'?","Gustav Mahler","Richard Strauss","Anton Bruckner","Johannes Brahms"],
  ["Which Strauss tone poem opens 2001: A Space Odyssey?","Also sprach Zarathustra","Don Juan","Till Eulenspiegel","Ein Heldenleben"],
  ["Mahler's Eighth Symphony is nicknamed what?","Symphony of a Thousand","Resurrection","Titan","Tragic"],
  ["Who wrote the famous Piano Concerto No. 2 in C minor and Rhapsody on a Theme of Paganini?","Sergei Rachmaninoff","Tchaikovsky","Scriabin","Prokofiev"],
  ["Which Strauss opera features the 'Dance of the Seven Veils'?","Salome","Elektra","Der Rosenkavalier","Ariadne auf Naxos"],
  ["Who wrote The Carnival of the Animals?","Camille Saint-Saëns","Gabriel Fauré","César Franck","Claude Debussy"]]}

);


/* ---- from music-10.js ---- */
/* MUSIC FOUNDATIONS, part 10: Unit 5 Modern Classical, chapters 1-4 */
COURSES.music.units.push({ t:"Modern and Contemporary Classical", ch:[

{ t:"Debussy, Ravel, and Impressionism", s:"Color and atmosphere",
  sec:[
  ["A French alternative",[
    "Around 1890, French composers sought an alternative to the heavy German style of Wagner. Claude Debussy (1862–1918) developed a music of color, atmosphere, and suggestion rather than drama and development. Critics labeled it Impressionism, after the painters Monet and Renoir; Debussy himself disliked the term and felt closer to Symbolist poets such as Mallarmé and Verlaine.",
    "Important influences included the Javanese gamelan, which Debussy heard at the 1889 Paris World's Fair, Russian music, and medieval modes."]],
  ["Debussy's language",[
    "Debussy treated chords as sounds valued for their color, not for where they 'must' resolve. He used parallel chords sliding in blocks, the whole-tone scale (made only of whole steps, with no clear home note), pentatonic scales, church modes, and unresolved seventh and ninth chords. Rhythms are often fluid and the meter blurred.",
    "His Prelude to the Afternoon of a Faun (1894), opening with a languid solo flute, is often considered the beginning of modern music. Other works include La mer (The Sea, 1905), Nocturnes, the opera Pelléas et Mélisande (1902), and piano works such as 'Clair de lune,' 'Reflets dans l'eau,' and two books of Préludes with poetic titles like 'The Sunken Cathedral.'"]],
  ["Maurice Ravel",[
    "Maurice Ravel (1875–1937) is often paired with Debussy but had a more Classical, precise sensibility; Stravinsky called him 'the most perfect of Swiss watchmakers.' He was a supreme orchestrator, as his version of Mussorgsky's Pictures at an Exhibition shows.",
    "His Boléro (1928), a single melody repeated over a snare-drum rhythm with ever-growing orchestration, became one of the most famous pieces of the century. Other works include the ballet Daphnis et Chloé, the String Quartet, the Piano Concerto in G (influenced by jazz), the Piano Concerto for the Left Hand (for a pianist who lost his right arm in World War I), Pavane for a Dead Princess, and La valse."]],
  ["Satie and Les Six",[
    "Erik Satie (1866–1925), an eccentric Parisian, wrote deliberately simple, strange pieces such as the Gymnopédies (1888) and Gnossiennes, with whimsical directions to the performer. He rejected grandeur and influenced Debussy, Ravel, and later minimalists and ambient music.",
    "In the 1920s a group called Les Six, including Francis Poulenc, Darius Milhaud, and Arthur Honegger, embraced Satie's spirit of simplicity, wit, and popular influences such as music hall and jazz."]],
  ["Lasting influence",[
    "Impressionist harmony, especially extended chords, parallel motion, and modal color, deeply shaped jazz pianists such as Bill Evans, as well as film music and ambient music.",
    "Debussy showed that music could be built around sound itself and freed composers from the 'rules' of tonal progression, opening paths for the whole 20th century."]]
  ],
  terms:[["Impressionism","Atmospheric, color-focused French style around 1900."],["Whole-tone scale","Scale built only of whole steps."],["Parallel chords","Chords moving in blocks in the same direction."],["Gamelan","Indonesian gong ensemble that influenced Debussy."],["Les Six","Group of six French composers of the 1920s."]],
  w:"Debussy's sound-centered approach launched modern music and still echoes in jazz and film scores.",
  src:["Claude Debussy","Prélude à l'après-midi d'un faune","Maurice Ravel","Boléro","Erik Satie"],
  q:[
  ["Which work is often considered the beginning of modern music?","Debussy's Prelude to the Afternoon of a Faun","Ravel's Boléro","Satie's Gymnopédies","Mahler's Ninth"],
  ["Which scale contains only whole steps?","Whole-tone scale","Pentatonic scale","Chromatic scale","Dorian mode"],
  ["Which Ravel work repeats one melody over a snare-drum rhythm?","Boléro","La valse","Daphnis et Chloé","Pavane for a Dead Princess"],
  ["Debussy was strongly influenced by hearing what at the 1889 Paris World's Fair?","Javanese gamelan","Japanese koto","Indian sitar","African drumming"],
  ["Who wrote the Gymnopédies?","Erik Satie","Francis Poulenc","Claude Debussy","Gabriel Fauré"],
  ["Ravel's Piano Concerto for the Left Hand was written for whom?","A pianist who lost his right arm in World War I","Ravel himself","A child prodigy","Debussy"]]},

{ t:"Stravinsky and the Rite of Spring", s:"Rhythm unleashed",
  sec:[
  ["Russian beginnings",[
    "Igor Stravinsky (1882–1971), a student of Rimsky-Korsakov, became perhaps the most influential composer of the 20th century. Diaghilev's Ballets Russes commissioned his three great early ballets: The Firebird (1910), based on Russian fairy tales, with brilliant orchestration; Petrushka (1911), about a puppet who comes to life, featuring the 'Petrushka chord' combining two keys at once; and The Rite of Spring.",
    "These made him world-famous almost overnight."]],
  ["The Rite of Spring",[
    "The Rite of Spring (Le sacre du printemps), subtitled 'Pictures from Pagan Russia,' depicts a prehistoric ritual in which a young girl dances herself to death to bring the spring. Its premiere in Paris on 29 May 1913, with choreography by Vaslav Nijinsky, provoked a famous uproar, with laughter, shouting, and disturbances in the audience.",
    "The music was revolutionary: driving, irregular rhythms with constantly shifting meters and unpredictable accents; pounding, repeated dissonant chords; layered ostinatos; and folk-like melodic fragments. It opens with a high, strained bassoon solo. Within a year it was hailed in concert performance, and it is now considered one of the most important works of the century."]],
  ["Neoclassicism",[
    "After World War I Stravinsky turned to neoclassicism, adapting forms and gestures of the 18th century with modern harmony and rhythm, clear textures, and ironic detachment. Pulcinella (1920) reworked music attributed to Pergolesi. Other neoclassical works include the Octet, the opera-oratorio Oedipus Rex, the Symphony of Psalms (1930), and the opera The Rake's Progress (1951).",
    "Neoclassicism became a major trend, followed by Prokofiev, Hindemith, Poulenc, and others."]],
  ["Later life",[
    "Stravinsky became a French citizen in 1934 and moved to the United States in 1939, settling in Los Angeles; he became an American citizen in 1945. In the 1950s, in his seventies, he surprised the world by adopting serialism, the technique associated with Schoenberg, in works such as Agon.",
    "He also wrote The Soldier's Tale (1918) for a small ensemble with a narrator, and the Ebony Concerto for jazz clarinetist Woody Herman's band."]],
  ["Influence",[
    "Stravinsky's rhythmic innovations influenced everything from modern classical to jazz, film scores, and progressive rock; the 'Rite' rhythms echo in film scores such as John Williams's Jaws. His changing styles showed that a composer could reinvent himself repeatedly.",
    "He said music is 'by its very nature essentially powerless to express anything at all,' emphasizing structure, though few listeners hear his music as unexpressive."]]
  ],
  terms:[["Ostinato","Short pattern repeated persistently."],["Polytonality","Two or more keys at the same time."],["Neoclassicism","Modern music using 18th-century forms and clarity."],["Shifting meter","Frequent changes of time signature."],["Ballets Russes","Diaghilev's company that commissioned Stravinsky."]],
  w:"The Rite of Spring made rhythm a central force of modern music and remains its most famous turning point.",
  src:["Igor Stravinsky","The Rite of Spring","Petrushka (ballet)","The Firebird","Neoclassicism (music)"],
  q:[
  ["In what year did The Rite of Spring premiere?","1913","1899","1924","1905"],
  ["Who choreographed the premiere of The Rite of Spring?","Vaslav Nijinsky","Marius Petipa","George Balanchine","Sergei Diaghilev"],
  ["What instrument plays the opening solo of the Rite?","Bassoon","Oboe","Flute","Clarinet"],
  ["Which Stravinsky ballet is about a puppet that comes to life?","Petrushka","The Firebird","Pulcinella","Apollo"],
  ["What is neoclassicism?","Modern music using 18th-century forms and clarity","Revival of Greek music","Romantic-style symphonies","Twelve-tone music"],
  ["Where did Stravinsky settle in America?","Los Angeles","New York","Chicago","Boston"]]},

{ t:"Schoenberg and Atonality", s:"Beyond the key",
  sec:[
  ["Emancipation of dissonance",[
    "Arnold Schoenberg (1874–1951), a largely self-taught Viennese composer, began in a late-Romantic style; his Transfigured Night (Verklärte Nacht, 1899) is lush and Wagnerian. Around 1908 he took a radical step: writing music without a home key, which came to be called atonality (a term he disliked, preferring 'pantonality').",
    "He spoke of the 'emancipation of dissonance': dissonant chords no longer needed to resolve to consonance. His Pierrot lunaire (1912), a cycle of 21 poems for a reciter and small ensemble, uses Sprechstimme, a half-spoken, half-sung style. The music was linked to Expressionism, an art movement expressing inner anxiety and extreme emotion."]],
  ["The twelve-tone method",[
    "Atonality without rules made large forms hard to organize. In the early 1920s Schoenberg devised the twelve-tone method (dodecaphony). The composer arranges all twelve chromatic notes in a specific order, the tone row, without repeating any until all have sounded. The row can be used in its original form, backward (retrograde), upside-down (inversion), and backward upside-down (retrograde inversion), and transposed to any starting note, giving 48 forms.",
    "This ensured no note dominated, preventing a sense of key, while giving unity. Later this approach was extended into serialism, applying ordered series to rhythm, dynamics, and timbre too, as by Pierre Boulez and Karlheinz Stockhausen after World War II."]],
  ["The Second Viennese School",[
    "Schoenberg's two most famous students, Alban Berg (1885–1935) and Anton Webern (1883–1945), formed with him the Second Viennese School. Berg combined twelve-tone methods with Romantic expression in his opera Wozzeck (1925), the opera Lulu, and his Violin Concerto 'To the Memory of an Angel,' which quotes a Bach chorale.",
    "Webern wrote extremely concentrated, brief works, some lasting under a minute, with isolated notes and silences, using Klangfarbenmelodie ('tone-color melody'), passing a melody between instruments. His style hugely influenced the postwar avant-garde."]],
  ["Exile and teaching",[
    "Schoenberg, of Jewish heritage, was dismissed from his Berlin teaching post when the Nazis came to power in 1933; the regime condemned modernist music as 'degenerate.' He emigrated to the United States, taught at UCLA, and wrote A Survivor from Warsaw (1947) about the Holocaust.",
    "He was also a painter and an influential teacher; John Cage studied with him."]],
  ["Reception",[
    "Atonal and twelve-tone music has always divided listeners. Many find it difficult; others find it powerfully expressive. Its approaches dominated much academic composition from the 1950s through the 1970s.",
    "Today its techniques appear in film and television scores, where atonal sounds convey suspense, horror, and psychological tension."]]
  ],
  terms:[["Atonality","Music without a home key."],["Tone row","Ordering of all twelve chromatic notes."],["Sprechstimme","Half-spoken, half-sung vocal style."],["Serialism","Ordering musical elements in series."],["Second Viennese School","Schoenberg, Berg, and Webern."]],
  w:"Schoenberg's break with tonality was the century's most radical musical idea and still shapes modern and film music.",
  src:["Arnold Schoenberg","Twelve-tone technique","Atonality","Second Viennese School","Pierrot lunaire"],
  q:[
  ["Who devised the twelve-tone method?","Arnold Schoenberg","Igor Stravinsky","Alban Berg","Claude Debussy"],
  ["What is Sprechstimme?","Half-spoken, half-sung vocal style","A twelve-tone row","A German dance","A choral technique"],
  ["How many forms of a tone row are possible with all transpositions?","48","12","24","4"],
  ["Which Berg opera premiered in 1925?","Wozzeck","Lulu","Moses und Aron","Elektra"],
  ["Who formed the Second Viennese School with Schoenberg?","Alban Berg and Anton Webern","Mahler and Strauss","Bartók and Kodály","Stravinsky and Ravel"],
  ["Where did Schoenberg teach after emigrating to the US?","UCLA","Juilliard","Harvard","Yale"]]},

{ t:"Modernism in Eastern Europe", s:"Bartók, Prokofiev, Shostakovich",
  sec:[
  ["Béla Bartók",[
    "Béla Bartók (1881–1945), Hungarian composer and pianist, was also a pioneering ethnomusicologist. With Zoltán Kodály he traveled through Hungarian, Romanian, Slovak, and other villages from 1906 onward, recording thousands of folk songs on wax cylinders and transcribing them precisely.",
    "He absorbed folk modes, asymmetric rhythms, and drones into a fiercely original modern style. Major works include six string quartets (considered the most important since Beethoven's), Music for Strings, Percussion and Celesta (1936), the Concerto for Orchestra (1943), Mikrokosmos (graded piano pieces), and the opera Bluebeard's Castle. Opposed to fascism, he emigrated to the United States in 1940 and died in New York in 1945."]],
  ["Kodály and music education",[
    "Zoltán Kodály (1882–1967) composed works such as the Háry János suite, but is best known for the Kodály method of music education, based on singing, folk songs, hand signs, and solfège. It is used in schools worldwide.",
    "Carl Orff, a German composer known for the cantata Carmina Burana (1937), whose opening 'O Fortuna' is famous from films and adverts, also created an influential children's music method using percussion instruments."]],
  ["Sergei Prokofiev",[
    "Sergei Prokofiev (1891–1953) was a brilliant pianist with a style combining motoric rhythms, biting dissonance, sarcasm, and lyrical melody. His Classical Symphony (1917) was an early neoclassical work in Haydn's style. He left Russia after the 1917 Revolution and worked in the West, but returned to the Soviet Union in 1936.",
    "Works include Peter and the Wolf (1936), a children's tale where each character is an instrument; the ballets Romeo and Juliet and Cinderella; the film scores for Eisenstein's Alexander Nevsky and Ivan the Terrible; five piano concertos; nine piano sonatas; and seven symphonies. He died on the same day as Stalin, 5 March 1953."]],
  ["Dmitri Shostakovich",[
    "Dmitri Shostakovich (1906–1975) spent his entire career in the Soviet Union, under the pressure of Stalin's regime. His First Symphony made him famous at 19. In 1936, after Stalin attended his opera Lady Macbeth of the Mtsensk District, the newspaper Pravda denounced it in an editorial titled 'Muddle Instead of Music.' Fearing arrest, he withdrew his Fourth Symphony and wrote the Fifth (1937), described in the press as 'a Soviet artist's creative response to just criticism,' which was a triumph.",
    "His Seventh Symphony, 'Leningrad,' was a symbol of resistance during the German siege; its 1942 performance in the starving city was broadcast by loudspeaker. He wrote fifteen symphonies and fifteen string quartets, often with double meanings: public celebration on the surface, irony, grief, or protest beneath. He was denounced again in 1948, together with Prokofiev and others."]],
  ["Art under pressure",[
    "Soviet 'socialist realism' required music to be accessible, optimistic, and patriotic; 'formalism,' meaning modernist experiment, was condemned. Composers faced censorship, loss of work, and fear for their lives.",
    "The debate over Shostakovich's true views, sharpened by the disputed memoir Testimony (1979), continues. His music remains a powerful witness to 20th-century history."]]
  ],
  terms:[["Ethnomusicology","Study of music in its cultural context."],["Kodály method","Singing-based music education approach."],["Socialist realism","Soviet doctrine requiring optimistic, accessible art."],["Formalism","Soviet term condemning modernist experiment."],["Motoric rhythm","Driving, machine-like repeated rhythm."]],
  w:"These composers fused folk roots and modernism and showed how music could survive, and resist, political pressure.",
  src:["Béla Bartók","Zoltán Kodály","Sergei Prokofiev","Dmitri Shostakovich","Muddle Instead of Music"],
  q:[
  ["Which composer recorded thousands of folk songs with Kodály?","Béla Bartók","Sergei Prokofiev","Carl Orff","Leoš Janáček"],
  ["Which Prokofiev work uses instruments to represent characters?","Peter and the Wolf","Romeo and Juliet","Classical Symphony","Cinderella"],
  ["What was the Pravda editorial attacking Shostakovich in 1936 called?","Muddle Instead of Music","Formalism Condemned","The Enemy of the People","Decadent Sounds"],
  ["Shostakovich's Seventh Symphony is named after which city?","Leningrad","Moscow","Stalingrad","Kiev"],
  ["Who composed Carmina Burana?","Carl Orff","Paul Hindemith","Kurt Weill","Zoltán Kodály"],
  ["Prokofiev died on the same day as whom?","Joseph Stalin","Sergei Rachmaninoff","Igor Stravinsky","Vladimir Lenin"]]}

]});


/* ---- from music-11.js ---- */
/* MUSIC FOUNDATIONS, part 11: Unit 5 chapters 5-8 */
COURSES.music.units[4].ch.push(

{ t:"American Classical Voices", s:"Ives, Gershwin, Copland, Bernstein",
  sec:[
  ["Charles Ives",[
    "Charles Ives (1874–1954) was a successful insurance executive who composed in his spare time. Raised in Danbury, Connecticut, by a bandmaster father who experimented with playing tunes in two keys at once, Ives wrote music of astonishing originality: layered hymns, marching bands, patriotic songs, and ragtime colliding in polytonality and complex rhythms.",
    "Works such as The Unanswered Question (1906), Three Places in New England, the 'Concord' Sonata, and his Fourth Symphony anticipated European modernism. Largely ignored at first, he won the Pulitzer Prize in 1947 for his Third Symphony, written decades earlier."]],
  ["George Gershwin",[
    "George Gershwin (1898–1937), from Brooklyn, began as a Tin Pan Alley song plugger and became one of the great songwriters, often with his brother Ira as lyricist ('I Got Rhythm,' 'Summertime,' 'Someone to Watch Over Me'). He bridged popular and concert music.",
    "Rhapsody in Blue (1924), commissioned by bandleader Paul Whiteman and opening with a famous clarinet glissando, combined jazz and classical styles. He also wrote An American in Paris and the Piano Concerto in F. His opera Porgy and Bess (1935), set in an African American community in South Carolina, includes 'Summertime.' He died of a brain tumor at 38."]],
  ["Aaron Copland",[
    "Aaron Copland (1900–1990), son of Jewish immigrants from Brooklyn, studied in Paris with the legendary teacher Nadia Boulanger, who trained many American composers. After an early modernist phase, in the 1930s and 1940s he developed an open, spacious 'American' sound using wide intervals, folk tunes, and clear textures.",
    "His ballets Billy the Kid, Rodeo (with its 'Hoe-Down'), and Appalachian Spring (1944, Pulitzer Prize), which uses the Shaker hymn 'Simple Gifts,' and Fanfare for the Common Man (1942) defined the musical image of the American landscape. He also wrote film scores."]],
  ["Leonard Bernstein",[
    "Leonard Bernstein (1918–1990) was a conductor, composer, pianist, and educator. He became famous overnight in 1943 when he substituted at short notice for an ill conductor with the New York Philharmonic, live on national radio; he later became its music director (1958–69), the first American-born conductor in that post.",
    "His musicals On the Town and West Side Story (1957), a retelling of Romeo and Juliet among New York gangs with lyrics by Stephen Sondheim, and his operetta Candide, joined classical and Broadway styles. His televised Young People's Concerts introduced millions to classical music."]],
  ["Other American voices",[
    "Samuel Barber's Adagio for Strings (1936) is perhaps the best-known American orchestral piece, often played at times of national mourning. William Grant Still's Afro-American Symphony (composed 1930, premiered 1931) was the first symphony by a Black American composer performed by a leading American orchestra. Florence Price became the first African American woman to have a symphony performed by a major American orchestra, the Chicago Symphony in 1933.",
    "Other important figures include Henry Cowell, who experimented with tone clusters and playing piano strings directly, and Duke Ellington, who also wrote extended concert works."]]
  ],
  terms:[["Polytonality","Several keys sounding at once."],["Nadia Boulanger","French teacher of many American composers."],["Rhapsody in Blue","Gershwin's 1924 jazz-classical fusion."],["Tone cluster","Chord of adjacent notes."],["Americana","Music evoking American landscape and folk life."]],
  w:"American composers blended jazz, folk, and classical traditions and shaped the sound of America on stage and screen.",
  src:["Charles Ives","George Gershwin","Aaron Copland","Leonard Bernstein","Florence Price"],
  q:[
  ["Which Gershwin work opens with a famous clarinet glissando?","Rhapsody in Blue","An American in Paris","Porgy and Bess","Concerto in F"],
  ["Which Copland ballet uses the Shaker hymn 'Simple Gifts'?","Appalachian Spring","Rodeo","Billy the Kid","Fancy Free"],
  ["Who was an insurance executive and pioneering modernist composer?","Charles Ives","Samuel Barber","Henry Cowell","Walter Piston"],
  ["Which musical by Bernstein retells Romeo and Juliet?","West Side Story","On the Town","Candide","Wonderful Town"],
  ["Who taught Copland and many other American composers in Paris?","Nadia Boulanger","Maurice Ravel","Darius Milhaud","Igor Stravinsky"],
  ["Whose symphony did the Chicago Symphony perform in 1933, a first for an African American woman?","Florence Price","Margaret Bonds","Mary Lou Williams","Undine Smith Moore"]]},

{ t:"The Avant-Garde and Minimalism", s:"Chance, silence, and repetition",
  sec:[
  ["Postwar experiment",[
    "After World War II, many composers felt the need to start again. At summer courses in Darmstadt, Germany, figures such as Pierre Boulez, Karlheinz Stockhausen, and Luigi Nono developed 'total serialism,' controlling pitch, rhythm, dynamics, and timbre with ordered series. Olivier Messiaen (1908–1992), their teacher, wrote richly colored music inspired by Catholic faith, birdsong, and Indian rhythms; his Quartet for the End of Time (1941) was composed and premiered in a German prisoner-of-war camp.",
    "Electronic and tape music expanded the palette of sounds. Edgard Varèse called music 'organized sound,' and his Poème électronique was played through hundreds of loudspeakers at the 1958 Brussels World's Fair."]],
  ["John Cage and chance",[
    "The American John Cage (1912–1992) questioned what music is. He invented the prepared piano, inserting screws, bolts, and rubber between strings to make percussive sounds. Influenced by Zen Buddhism and the I Ching, he used chance operations to compose, removing his own preferences.",
    "His most famous piece, 4′33″ (1952), consists of a performer sitting silently for four minutes and thirty-three seconds; the 'music' is whatever ambient sounds occur. It invites listeners to hear all sounds as potentially musical. Cage's ideas influenced art, dance (with his partner, choreographer Merce Cunningham), and experimental music."]],
  ["Texture and sound mass",[
    "Some composers built music from dense textures rather than melody. Krzysztof Penderecki's Threnody to the Victims of Hiroshima (1960) for 52 strings uses clusters, glissandos, and extended techniques. György Ligeti's shimmering micropolyphony in Atmosphères (1961) and Lux aeterna became famous through Stanley Kubrick's 2001: A Space Odyssey.",
    "Iannis Xenakis, an architect who worked with Le Corbusier, used mathematics and probability to compose."]],
  ["Minimalism",[
    "In the 1960s, American composers reacted against complexity with minimalism: steady pulse, consonant harmony, and repeated short patterns that change gradually. La Monte Young and Terry Riley were pioneers; Riley's In C (1964) consists of 53 short phrases that performers repeat at their own pace.",
    "Steve Reich explored phasing, in which two identical patterns played at slightly different speeds drift in and out of alignment, in It's Gonna Rain and Piano Phase; his Music for 18 Musicians (1976) and Different Trains are landmarks. Philip Glass wrote operas such as Einstein on the Beach (1976) and Akhnaten and many film scores. John Adams developed post-minimalism in Short Ride in a Fast Machine and the operas Nixon in China (1987) and Doctor Atomic."]],
  ["Holy minimalism and today",[
    "Arvo Pärt of Estonia developed tintinnabuli, a bell-like style combining a melodic voice with a voice outlining a triad, in serene works such as Spiegel im Spiegel and Fratres. Henryk Górecki's Symphony No. 3 (1976), 'Symphony of Sorrowful Songs,' became a surprise bestseller in a 1992 recording.",
    "Contemporary classical music today is pluralistic: composers such as Kaija Saariaho, Thomas Adès, Caroline Shaw, Unsuk Chin, Max Richter, and Jóhann Jóhannsson blend styles freely, drawing on electronics, pop, and world traditions."]]
  ],
  terms:[["Prepared piano","Piano altered with objects between strings."],["Chance music","Music composed or performed with random procedures."],["Minimalism","Music of repetition and gradual change."],["Phasing","Identical patterns drifting out of sync."],["Tintinnabuli","Pärt's bell-like compositional style."]],
  w:"Postwar experiment questioned what music is; minimalism then created one of the most popular modern styles.",
  src:["John Cage","4′33″","Minimal music","Steve Reich","Arvo Pärt"],
  q:[
  ["What is John Cage's 4′33″?","A performer sitting silently while ambient sounds form the music","A piece for prepared piano","A tape composition","A minimalist opera"],
  ["Which Messiaen work premiered in a prisoner-of-war camp?","Quartet for the End of Time","Turangalîla-Symphonie","Catalogue d'oiseaux","Visions de l'Amen"],
  ["What technique did Steve Reich use in Piano Phase?","Phasing","Twelve-tone rows","Chance operations","Sound mass"],
  ["Which Philip Glass opera premiered in 1976?","Einstein on the Beach","Nixon in China","Akhnaten","Doctor Atomic"],
  ["Who developed the tintinnabuli style?","Arvo Pärt","Henryk Górecki","John Tavener","György Ligeti"],
  ["Whose music was used in 2001: A Space Odyssey besides Strauss?","György Ligeti","John Cage","Philip Glass","Pierre Boulez"]]},

{ t:"Film, Television, and Game Music", s:"Scoring the moving image",
  sec:[
  ["Silent film",[
    "Films were never truly silent. From the 1890s, pianists, organists, and in large cinemas full orchestras accompanied films, using compiled classical excerpts and mood music, or improvising. Some original scores were written, such as Camille Saint-Saëns's for The Assassination of the Duke of Guise (1908).",
    "Sound film arrived with The Jazz Singer (1927), and soon films had recorded scores."]],
  ["The Golden Age",[
    "In the 1930s and 1940s, Hollywood composers, many émigrés trained in late-Romantic European traditions, created the classic film score: lush orchestral music using leitmotifs. Max Steiner's King Kong (1933) and Gone with the Wind (1939) and Erich Wolfgang Korngold's The Adventures of Robin Hood (1938) set the model.",
    "Bernard Herrmann brought psychological intensity to Citizen Kane, Vertigo, and Psycho (1960), whose screeching shower-scene strings are among the most famous film cues ever. Composers also scored for studios such as Disney, where songs and animation joined in Snow White (1937) and Fantasia (1940)."]],
  ["New sounds",[
    "From the 1950s, scores incorporated jazz (Elmer Bernstein's The Man with the Golden Arm), pop songs, and modernist techniques. Henry Mancini's Pink Panther and Moon River, and Ennio Morricone's distinctive Westerns for Sergio Leone, with whistling, electric guitar, and coyote-like cries in The Good, the Bad and the Ugly (1966), expanded the palette.",
    "Electronic scores emerged too: Vangelis's Chariots of Fire and Blade Runner, Wendy Carlos's Tron, and later Hans Zimmer's blend of orchestra and synthesizers."]],
  ["John Williams and the modern blockbuster",[
    "John Williams (born 1932) revived the full symphonic score with Jaws (1975), whose two-note shark motif is iconic, and Star Wars (1977), inspired by Wagner, Korngold, and Holst. He went on to score Close Encounters, Superman, the Indiana Jones films, E.T., Jurassic Park, Schindler's List, and the first Harry Potter films. He has received more than fifty Academy Award nominations.",
    "Other leading film composers include Howard Shore (The Lord of the Rings), Hans Zimmer (The Lion King, Inception, Interstellar, Dune), James Horner (Titanic), Danny Elfman, Alexandre Desplat, Joe Hisaishi (Studio Ghibli films), Hildur Guðnadóttir (Joker), and Ludwig Göransson (Black Panther, Oppenheimer)."]],
  ["How film music works",[
    "Film scoring terms include diegetic music, which characters can hear (a band in a scene), and non-diegetic underscore, heard only by the audience. A cue is a single piece of music in a film; spotting is deciding where music goes; temp tracks are placeholder music used during editing.",
    "Music tells audiences how to feel, signals danger, links characters through themes, and smooths editing. Mickey-mousing is closely matching music to on-screen action, as in cartoons."]],
  ["Games and television",[
    "Video game music developed from simple chip-tune melodies on limited sound chips, such as Koji Kondo's Super Mario Bros. (1985) and The Legend of Zelda themes, to full orchestral scores. Adaptive (dynamic) music changes in real time with gameplay. Nobuo Uematsu's Final Fantasy music and scores for Halo, The Elder Scrolls, and Journey are performed in concert halls.",
    "Television themes, from the Doctor Who theme to Ramin Djawadi's Game of Thrones, are part of popular culture. Film and game music is now a major route by which young listeners encounter orchestral sound."]]
  ],
  terms:[["Diegetic music","Music heard by the characters in a scene."],["Underscore","Background music heard only by the audience."],["Cue","A single piece of music in a film."],["Adaptive music","Game music that changes with gameplay."],["Mickey-mousing","Music precisely matching on-screen action."]],
  w:"Film and game scores are the most widely heard orchestral music today; knowing how they work deepens every viewing.",
  src:["Film score","John Williams","Bernard Herrmann","Ennio Morricone","Video game music"],
  q:[
  ["Who composed the scores for Jaws and Star Wars?","John Williams","Hans Zimmer","Jerry Goldsmith","Howard Shore"],
  ["What is diegetic music?","Music the characters can hear in the scene","Background underscore","Music over the credits","A temp track"],
  ["Which composer scored Psycho and Vertigo?","Bernard Herrmann","Max Steiner","Ennio Morricone","Henry Mancini"],
  ["Ennio Morricone is famous for scoring whose Westerns?","Sergio Leone","John Ford","Clint Eastwood","Sam Peckinpah"],
  ["Who composed the music for Super Mario Bros. (1985)?","Koji Kondo","Nobuo Uematsu","Joe Hisaishi","Yoko Shimomura"],
  ["Which 1927 film is known as the first major sound feature film with synchronized singing?","The Jazz Singer","King Kong","Metropolis","Sunrise"]]},

{ t:"How to Listen to Classical Music", s:"Concert-going and active listening",
  sec:[
  ["Genres at a glance",[
    "Classical music has many forms. Orchestral genres include the symphony (usually four movements), concerto (soloist and orchestra), overture, symphonic poem, and suite. Chamber music is written for small groups with one player per part: string quartet, piano trio (piano, violin, cello), wind quintet, or sonata (often one instrument with piano).",
    "Vocal genres include opera, oratorio, mass, requiem, cantata, art song, and choral music. Solo keyboard genres include the sonata, variations, étude, prelude, and character piece."]],
  ["Reading a program",[
    "A concert program might list 'Symphony No. 5 in C minor, Op. 67.' The number places it in the composer's series, the key tells the home key, and 'Op.' (opus, 'work') is the publication number. Some composers have catalogue numbers instead: K. for Mozart, BWV for Bach, D. for Schubert, Hob. for Haydn, RV for Vivaldi.",
    "Movements are often labeled with Italian tempo terms such as Allegro con brio or Andante. Nicknames like 'Moonlight' or 'Eroica' were sometimes given by the composer and often by publishers or later listeners."]],
  ["Concert etiquette",[
    "In modern classical concerts, audiences usually hold applause until the end of a multi-movement work, not between movements, though in Mozart's day audiences clapped whenever they liked. In opera, applause after famous arias is customary.",
    "The concertmaster enters, the orchestra tunes to the oboe's A, then the conductor and soloist enter. Silence during the music lets the quietest sounds be heard; dynamics in a live hall reach extremes no recording captures."]],
  ["Active listening",[
    "To listen more deeply, try following one instrument through a piece; noticing when a theme returns or changes; identifying the form; sensing when tension builds and resolves; and comparing recordings by different performers, since each interpretation differs in tempo, color, and phrasing.",
    "Reading about a piece beforehand, listening several times, and following a score, even without fluent reading, all reveal more. Familiarity breeds love: most people enjoy music more on repeated hearing."]],
  ["Where to start",[
    "A starter list might include Vivaldi's Four Seasons, Bach's Brandenburg Concertos and Cello Suites, Mozart's Eine kleine Nachtmusik and Requiem, Beethoven's Fifth and Ninth Symphonies, Schubert's 'Trout' Quintet, Chopin's Nocturnes, Tchaikovsky's Nutcracker, Dvořák's New World Symphony, Debussy's 'Clair de lune,' Holst's The Planets, Stravinsky's Rite of Spring, Gershwin's Rhapsody in Blue, Barber's Adagio for Strings, and Pärt's Spiegel im Spiegel.",
    "Live performance, whether in a concert hall, church, or school, remains the best way to experience classical music, and many orchestras offer affordable tickets and free outdoor concerts."]]
  ],
  terms:[["Opus","Publication number of a composer's work."],["BWV","Catalogue numbering for Bach's works."],["Chamber music","Music for small groups, one player per part."],["Movement","Self-contained section of a larger work."],["Interpretation","A performer's personal shaping of a work."]],
  w:"Knowing how classical works are named, structured, and performed turns passive hearing into rich listening.",
  src:["Opus number","Chamber music","Bach-Werke-Verzeichnis","Concert etiquette","Movement (music)"],
  q:[
  ["What does 'Op.' stand for in a work's title?","Opus, meaning work","Opera","Orchestral part","Original performance"],
  ["What catalogue numbering is used for Bach's works?","BWV","K.","D.","Hob."],
  ["What instruments form a piano trio?","Piano, violin, cello","Three pianos","Piano, flute, clarinet","Piano, viola, bass"],
  ["In modern concerts, when do audiences usually applaud a symphony?","At the end of the whole work","After each movement","At the start","During the music"],
  ["The orchestra tunes to which note from the oboe?","A","C","G","E"],
  ["What is chamber music?","Music for small groups with one player per part","Music played in bedrooms","Choral church music","Music for full orchestra"]]}

);


/* ---- from music-12.js ---- */
/* MUSIC FOUNDATIONS, part 12: Unit 6 American Roots, chapters 1-4 */
COURSES.music.units.push({ t:"American Roots: Blues, Jazz, Gospel, Country", ch:[

{ t:"African Roots and Spirituals", s:"The foundations of American music",
  sec:[
  ["Africa to America",[
    "Between the 16th and 19th centuries, roughly 12.5 million Africans were forced onto ships in the transatlantic slave trade (about 10.7 million survived the crossing), most to the Caribbean and Brazil, with several hundred thousand to North America. They brought musical traditions that would become the deepest root of American popular music.",
    "Common features of West and Central African music include call and response (a leader sings and a group answers), polyrhythm (several rhythms layered at once), syncopation, improvisation, the use of the voice in many timbres including slides, growls, and falsetto, and music as a communal, participatory activity tied to dance and daily life."]],
  ["Music under slavery",[
    "Enslaved people in the United States were often forbidden drums, which owners feared could be used to signal revolts, so rhythm was carried by voices, clapping, stomping, and patting juba (slapping the body). Work songs and field hollers coordinated labor and expressed hardship.",
    "In New Orleans, Congo Square was a rare place where enslaved and free Black people gathered on Sundays to dance and drum in African styles into the 19th century, a key link in the chain toward jazz."]],
  ["Spirituals",[
    "Spirituals were religious folk songs created by enslaved African Americans, blending African musical practice with Christian hymns and biblical stories. Songs such as 'Swing Low, Sweet Chariot,' 'Go Down, Moses,' 'Deep River,' and 'Nobody Knows the Trouble I've Seen' often had double meanings: the river Jordan and the promised land could signify freedom in the North, and some songs may have carried messages about escape.",
    "After emancipation, the Fisk Jubilee Singers from Fisk University in Nashville toured the United States and Europe from 1871, presenting arranged spirituals to concert audiences and raising money for their school. Their success brought spirituals worldwide recognition."]],
  ["Minstrelsy: a painful history",[
    "In the 19th century, blackface minstrel shows, in which mostly white performers darkened their faces and caricatured Black people, became the most popular American entertainment. They spread racist stereotypes while also, ironically, circulating versions of African American musical styles; Stephen Foster wrote songs such as 'Oh! Susanna' and 'Camptown Races' for minstrel performance.",
    "Black performers later worked in minstrelsy too, and some, such as the songwriter James Bland, gained fame. Understanding this history helps explain the complicated racial dynamics of American popular music."]],
  ["The banjo and other legacies",[
    "The banjo descends from West African gourd lutes such as the akonting and was played by enslaved people before becoming central to minstrel shows and later bluegrass and country.",
    "African American musical practices, especially blue notes, call and response, syncopation, and improvisation, shaped ragtime, blues, jazz, gospel, R&B, rock and roll, soul, funk, and hip-hop. Much of the world's popular music today rests on these foundations."]]
  ],
  terms:[["Call and response","Leader's phrase answered by a group."],["Polyrhythm","Several rhythms layered simultaneously."],["Spiritual","Religious folk song of enslaved African Americans."],["Field holler","Solo work song from the fields."],["Fisk Jubilee Singers","Choir that brought spirituals to world audiences."]],
  w:"African musical traditions, carried through slavery, are the root of blues, jazz, rock, soul, and hip-hop.",
  src:["Spiritual (music)","Fisk Jubilee Singers","Call and response (music)","Congo Square","Blackface minstrel show"],
  q:[
  ["What is call and response?","A leader's phrase answered by a group","Two choirs singing at once","A telephone song","A solo improvisation"],
  ["Which group toured from 1871 bringing spirituals to world audiences?","Fisk Jubilee Singers","Golden Gate Quartet","Hampton Singers","Mormon Tabernacle Choir"],
  ["Where in New Orleans did enslaved people gather to dance and drum on Sundays?","Congo Square","Bourbon Street","Jackson Square","Storyville"],
  ["The banjo descends from instruments of which region?","West Africa","Ireland","Spain","India"],
  ["Which songwriter wrote 'Oh! Susanna' for minstrel shows?","Stephen Foster","Scott Joplin","W. C. Handy","George M. Cohan"],
  ["Which is a well-known spiritual?","Swing Low, Sweet Chariot","Maple Leaf Rag","St. Louis Blues","Take the A Train"]]},

{ t:"The Blues", s:"Twelve bars of truth",
  sec:[
  ["Origins",[
    "The blues emerged among African Americans in the Deep South, especially the Mississippi Delta, around the 1890s–1900s, drawing on work songs, field hollers, spirituals, and ballads. It expressed hard lives under segregation and sharecropping, but also humor, desire, and resilience.",
    "W. C. Handy, known as the 'Father of the Blues,' heard a guitarist playing slide with a knife at a railway station in Tutwiler, Mississippi, around 1903 and later published blues songs such as 'Memphis Blues' and 'St. Louis Blues' (1914), spreading the style nationally."]],
  ["Blues form and sound",[
    "The most common form is the 12-bar blues, based on three chords: I, IV, and V. A standard pattern is four bars of I, two of IV, two of I, one of V, one of IV, and two of I. Lyrics often follow an AAB pattern: a line is sung, repeated, then answered by a rhyming line.",
    "Blue notes, notes sung or played slightly flat, especially the third, fifth, and seventh degrees, give the blues its characteristic sound. The blues scale adds the flatted fifth to the minor pentatonic. Singers and players bend notes, and instruments answer the voice in call-and-response fills."]],
  ["Delta and country blues",[
    "Early rural blues was often a solo singer with acoustic guitar. Charley Patton, Son House, Skip James, and Robert Johnson (1911–1938) are legends of the Delta blues; Johnson's recordings such as 'Cross Road Blues' and 'Sweet Home Chicago' and the myth that he sold his soul at a crossroads made him iconic. Blind Lemon Jefferson in Texas and Lead Belly were also influential.",
    "The first blues recording by a Black singer to become a hit was Mamie Smith's 'Crazy Blues' (1920), which revealed a market for 'race records.'"]],
  ["Classic blues queens",[
    "In the 1920s, women singers with jazz bands dominated recorded blues. Ma Rainey, the 'Mother of the Blues,' toured tent shows across the South. Bessie Smith (1894–1937), the 'Empress of the Blues,' was the best-selling Black artist of her time, with a powerful voice heard in 'Downhearted Blues' and 'St. Louis Blues' with Louis Armstrong.",
    "These singers addressed independence, sexuality, and hardship with frankness unusual for the era."]],
  ["Chicago and electric blues",[
    "During the Great Migration (about 1910–1970), millions of African Americans moved north to cities such as Chicago, Detroit, and New York. In Chicago, blues became electric and band-based. Muddy Waters ('Hoochie Coochie Man,' 'Mannish Boy'), Howlin' Wolf, Willie Dixon, Little Walter on amplified harmonica, and Chess Records defined the sound.",
    "B. B. King, with his guitar 'Lucille' and singing vibrato on single notes, became the blues' great ambassador; Albert King, T-Bone Walker, John Lee Hooker, and Buddy Guy were also central."]],
  ["The blues' children",[
    "The blues is the foundation of rock and roll, R&B, soul, and much jazz. In the 1960s, British bands such as the Rolling Stones (named after a Muddy Waters song), the Yardbirds, Cream, and Led Zeppelin built careers on reworked blues, introducing many white audiences to the originals.",
    "Later artists from Stevie Ray Vaughan to Gary Clark Jr. and Christone 'Kingfish' Ingram have continued the tradition."]]
  ],
  terms:[["12-bar blues","Blues form of twelve bars using I, IV, V chords."],["Blue note","Note bent slightly flat for expression."],["AAB lyric","Line, repeated line, answering line."],["Great Migration","Movement of African Americans from the rural South to northern cities."],["Race records","1920s term for records marketed to Black audiences."]],
  w:"The blues gave popular music its basic chords, scale, and emotional honesty; nearly all rock and soul grows from it.",
  src:["Blues","Twelve-bar blues","Robert Johnson","Bessie Smith","Chicago blues"],
  q:[
  ["Which three chords form the basis of the 12-bar blues?","I, IV, and V","I, ii, and V","I, vi, and IV","I, iii, and vi"],
  ["Who is known as the 'Empress of the Blues'?","Bessie Smith","Ma Rainey","Billie Holiday","Mamie Smith"],
  ["Which musician is connected to the crossroads legend?","Robert Johnson","Muddy Waters","B. B. King","Son House"],
  ["What is the usual lyric pattern of a blues verse?","AAB","ABAB","AABB","ABCB"],
  ["Which Chicago label recorded Muddy Waters and Howlin' Wolf?","Chess Records","Sun Records","Motown","Stax"],
  ["B. B. King named his guitar what?","Lucille","Trigger","Blackie","Lucy"]]},

{ t:"Ragtime and Early Jazz", s:"New Orleans and the birth of jazz",
  sec:[
  ["Ragtime",[
    "Ragtime, popular from the mid-1890s to about 1918, was a piano style with a steady, march-like 'oom-pah' left hand and a syncopated ('ragged') right-hand melody. It was written down and sold as sheet music, played in saloons, parlors, and on player pianos.",
    "Scott Joplin (about 1868–1917), the 'King of Ragtime,' wrote 'Maple Leaf Rag' (1899), a huge sheet-music success, and 'The Entertainer,' later revived in the 1973 film The Sting. He also wrote an opera, Treemonisha. Ragtime launched a nationwide craze for syncopated music and dance."]],
  ["New Orleans",[
    "Jazz emerged in New Orleans around the 1900s–1910s. The city was uniquely mixed: French, Spanish, Caribbean, African American, and Creole cultures; brass bands for parades and funerals; blues; ragtime; opera; and Caribbean rhythms such as the 'Spanish tinge' that Jelly Roll Morton described.",
    "Cornetist Buddy Bolden, active around 1900, is often named the first jazz musician, though he was never recorded. Jelly Roll Morton, pianist and composer, claimed to have invented jazz and was among its first great composers."]],
  ["The New Orleans style",[
    "Early jazz ensembles featured collective improvisation: the cornet or trumpet played the melody, the clarinet wove decorations above it, and the trombone added slides and counter-lines below, over a rhythm section of banjo or guitar, tuba or bass, piano, and drums.",
    "The first jazz recording, 'Livery Stable Blues' (1917), was made by the Original Dixieland Jass Band, a white group. Joe 'King' Oliver's Creole Jazz Band in Chicago, with young Louis Armstrong on second cornet, recorded in 1923."]],
  ["Louis Armstrong",[
    "Louis Armstrong (1901–1971), born in poverty in New Orleans, became the most influential figure in early jazz. His Hot Five and Hot Seven recordings (1925–28), such as 'West End Blues' with its dazzling opening cadenza, shifted jazz from collective improvisation to the virtuoso soloist.",
    "He also transformed popular singing with relaxed phrasing, swing, and scat singing (improvising with nonsense syllables), as on 'Heebie Jeebies.' Later hits included 'Hello, Dolly!' and 'What a Wonderful World.' Armstrong's sense of swing defined jazz rhythm."]],
  ["The Jazz Age",[
    "The Great Migration carried jazz north to Chicago and New York. The 1920s became known as the Jazz Age, a term popularized by F. Scott Fitzgerald. Jazz spread through records, radio, dance halls, and speakeasies during Prohibition.",
    "In New York's Harlem, the Harlem Renaissance flourished in literature and music; stride pianists such as James P. Johnson and Fats Waller extended ragtime into a powerful, swinging style. Bix Beiderbecke, a white cornetist with a lyrical tone, became a legend, and Sidney Bechet was an early soprano saxophone virtuoso."]]
  ],
  terms:[["Ragtime","Syncopated piano style of about 1895–1918."],["Collective improvisation","Several players improvising together at once."],["Scat singing","Improvising with nonsense syllables."],["Stride piano","Harlem piano style with leaping left hand."],["Swing (feel)","Lilting rhythmic feel of jazz."]],
  w:"Jazz, born in New Orleans, became America's great contribution to world music and introduced the improvising soloist.",
  src:["Ragtime","Scott Joplin","Jazz","Louis Armstrong","Jelly Roll Morton"],
  q:[
  ["Who is known as the 'King of Ragtime'?","Scott Joplin","Jelly Roll Morton","James P. Johnson","Eubie Blake"],
  ["In which city did jazz emerge?","New Orleans","Chicago","New York","Memphis"],
  ["Which group made the first jazz recording in 1917?","Original Dixieland Jass Band","King Oliver's Creole Jazz Band","Hot Five","Red Hot Peppers"],
  ["What is scat singing?","Improvising with nonsense syllables","Singing very fast lyrics","Singing in falsetto","Whispered singing"],
  ["Which Armstrong recording opens with a famous cadenza?","West End Blues","Hello, Dolly!","What a Wonderful World","Potato Head Blues"],
  ["Who is often named the first jazz musician, though never recorded?","Buddy Bolden","Sidney Bechet","King Oliver","Kid Ory"]]},

{ t:"The Swing Era", s:"Big bands and the dance floor",
  sec:[
  ["Big bands",[
    "From about 1935 to 1946, swing music performed by big bands was the most popular music in America. A big band typically had 12 to 20 players in sections: trumpets, trombones, saxophones, and a rhythm section of piano, guitar, bass, and drums. Written arrangements had sections playing in harmony and riffs (short repeated phrases) trading back and forth, framing improvised solos.",
    "Fletcher Henderson's band in the 1920s, with arranger Don Redman, created the model. The swing feel, with its smooth four-beat pulse and lilting eighth notes, made it ideal for dances such as the Lindy Hop, which flourished in Harlem's Savoy Ballroom."]],
  ["Duke Ellington",[
    "Edward Kennedy 'Duke' Ellington (1899–1974) was jazz's greatest composer. His orchestra, which began its fame at the Cotton Club in Harlem in 1927, developed a unique sound by writing for the distinctive voices of individual players such as saxophonist Johnny Hodges and trumpeter Bubber Miley.",
    "Among some 1,000 compositions are 'Mood Indigo,' 'Sophisticated Lady,' 'It Don't Mean a Thing (If It Ain't Got That Swing),' 'In a Sentimental Mood,' and extended suites such as Black, Brown and Beige. His collaborator Billy Strayhorn wrote 'Take the \"A\" Train,' the band's theme."]],
  ["Count Basie and Kansas City",[
    "Kansas City developed a looser, blues-based swing built on riffs and long jam sessions. William 'Count' Basie's band (from 1935) was famous for its relaxed 'All-American Rhythm Section' and soloists such as tenor saxophonist Lester Young, whose cool, floating style influenced generations.",
    "Basie's 'One O'Clock Jump' and 'Jumpin' at the Woodside' epitomize the swinging Kansas City style."]],
  ["The King of Swing and others",[
    "Clarinetist Benny Goodman, called the 'King of Swing,' sparked the craze with a 1935 broadcast and a triumphant Los Angeles concert, and in 1938 led the first jazz concert at Carnegie Hall. He was also among the first bandleaders to integrate his groups, hiring pianist Teddy Wilson and vibraphonist Lionel Hampton.",
    "Other popular bands were led by Glenn Miller ('In the Mood,' 'Moonlight Serenade'), Artie Shaw, Tommy Dorsey, Jimmie Lunceford, Cab Calloway, and Chick Webb, whose band featured the young Ella Fitzgerald. Coleman Hawkins's 'Body and Soul' (1939) became a landmark tenor saxophone solo."]],
  ["Singers of the era",[
    "Vocalists became stars: Billie Holiday (1915–1959), with her intimate phrasing and emotional depth, recorded 'Strange Fruit' (1939), a haunting protest against lynching. Ella Fitzgerald, the 'First Lady of Song,' had flawless intonation and brilliant scat. Frank Sinatra rose as a singer with Tommy Dorsey's band before becoming a solo idol.",
    "The swing era declined after World War II due to wartime travel restrictions, a musicians' recording strike, a cabaret tax, rising costs, and changing tastes, as singers and smaller groups took over."]]
  ],
  terms:[["Big band","Large jazz ensemble with sections."],["Riff","Short repeated melodic phrase."],["Arrangement","Written version of a piece for an ensemble."],["Lindy Hop","Swing dance born in Harlem."],["Rhythm section","Piano, guitar, bass, and drums."]],
  w:"Swing made jazz the popular music of a generation and produced the great American songbook singers.",
  src:["Swing music","Duke Ellington","Count Basie","Benny Goodman","Billie Holiday"],
  q:[
  ["Which bandleader was called the 'King of Swing'?","Benny Goodman","Duke Ellington","Count Basie","Glenn Miller"],
  ["Where did Duke Ellington's orchestra gain fame starting in 1927?","The Cotton Club","The Savoy Ballroom","Carnegie Hall","Minton's Playhouse"],
  ["Who wrote 'Take the \"A\" Train'?","Billy Strayhorn","Duke Ellington","Count Basie","Cab Calloway"],
  ["Which Billie Holiday song protested lynching?","Strange Fruit","God Bless the Child","Lover Man","Gloomy Sunday"],
  ["Which city was known for a riff-based, blues-heavy swing style?","Kansas City","Detroit","Philadelphia","San Francisco"],
  ["Which singer was called the 'First Lady of Song'?","Ella Fitzgerald","Sarah Vaughan","Billie Holiday","Dinah Washington"]]}

]});


/* ---- from music-13.js ---- */
/* MUSIC FOUNDATIONS, part 13: Unit 6 chapters 5-9 */
COURSES.music.units[5].ch.push(

{ t:"Bebop and Modern Jazz", s:"Jazz becomes art music",
  sec:[
  ["The bebop revolution",[
    "In the early 1940s, young musicians jamming after hours at Harlem clubs such as Minton's Playhouse and Monroe's Uptown House developed bebop, a fast, complex style meant for listening rather than dancing. Alto saxophonist Charlie Parker ('Bird'), trumpeter Dizzy Gillespie, pianist Thelonious Monk, pianist Bud Powell, and drummer Kenny Clarke led the way.",
    "Bebop featured very fast tempos, intricate melodies (often new 'heads' written over the chord changes of existing songs, such as 'I Got Rhythm'), extended chords with ninths, elevenths, and thirteenths, the flatted fifth, and rapid harmonic movement. Drummers moved the steady beat to the ride cymbal and used the bass drum for accents ('dropping bombs')."]],
  ["The players",[
    "Charlie Parker (1920–1955) was a towering improviser whose fluid lines on 'Ko-Ko,' 'Now's the Time,' and 'Ornithology' became a language every jazz musician studies. Dizzy Gillespie, with his bent trumpet and puffed cheeks, was both virtuoso and educator, and helped introduce Afro-Cuban rhythms to jazz with percussionist Chano Pozo in 'Manteca.'",
    "Thelonious Monk's quirky, angular compositions, such as ''Round Midnight,' 'Straight, No Chaser,' and 'Blue Monk,' with surprising dissonances and silences, are among the most-played jazz standards."]],
  ["Cool and hard bop",[
    "In the late 1940s and 1950s, cool jazz offered a calmer, lighter alternative. Miles Davis's Birth of the Cool sessions (1949–50), arranged with Gil Evans and Gerry Mulligan, and West Coast players like Chet Baker and Dave Brubeck exemplified it. Brubeck's 'Take Five' (1959), written by saxophonist Paul Desmond in 5/4 time, became a surprise hit.",
    "Hard bop, by contrast, brought back blues and gospel intensity: Art Blakey's Jazz Messengers, Horace Silver, Clifford Brown, Sonny Rollins (Saxophone Colossus), and Cannonball Adderley. Blue Note Records became the label of hard bop."]],
  ["Miles Davis and modal jazz",[
    "Miles Davis (1926–1991) reinvented jazz repeatedly. His album Kind of Blue (1959), with John Coltrane, Cannonball Adderley, and pianist Bill Evans, used modal jazz: improvising over scales (modes) held for long stretches rather than fast-changing chords, as in 'So What.' It is the best-selling jazz album of all time.",
    "Davis later led a 'second great quintet' with Wayne Shorter and Herbie Hancock, and pioneered jazz-rock fusion with Bitches Brew (1970)."]],
  ["Coltrane and free jazz",[
    "John Coltrane (1926–1967) developed 'sheets of sound,' rapid cascades of notes, on Giant Steps (1960), whose title track's fast-moving chords became a test for musicians. His spiritual masterpiece A Love Supreme (1965) is one of jazz's most revered albums.",
    "Free jazz abandoned fixed chord changes and meter. Ornette Coleman's The Shape of Jazz to Come (1959) and Free Jazz (1961), Cecil Taylor, Albert Ayler, and Sun Ra pushed into collective improvisation and new sounds. Charles Mingus, bassist and composer, combined gospel, blues, and complex structure in Mingus Ah Um."]]
  ],
  terms:[["Bebop","Fast, complex jazz style of the 1940s."],["Head","The composed melody of a jazz tune."],["Modal jazz","Improvising over modes rather than fast chord changes."],["Hard bop","Bebop infused with blues and gospel."],["Free jazz","Jazz without fixed chords or meter."]],
  w:"Bebop turned jazz into a sophisticated art music, and its language still defines jazz improvisation.",
  src:["Bebop","Charlie Parker","Kind of Blue","John Coltrane","Thelonious Monk"],
  q:[
  ["Which alto saxophonist was nicknamed 'Bird'?","Charlie Parker","Cannonball Adderley","Johnny Hodges","Paul Desmond"],
  ["What is the best-selling jazz album of all time?","Kind of Blue","A Love Supreme","Time Out","Bitches Brew"],
  ["'Take Five' is in which meter?","5/4","3/4","7/8","4/4"],
  ["Which Coltrane album is a spiritual suite from 1965?","A Love Supreme","Giant Steps","Blue Train","My Favorite Things"],
  ["Who composed ''Round Midnight'?","Thelonious Monk","Dizzy Gillespie","Bud Powell","Charles Mingus"],
  ["What characterizes modal jazz?","Improvising over long-held scales","Rapid chord changes","No rhythm section","Only blues forms"]]},

{ t:"Jazz Since 1970", s:"Fusion, tradition, and global jazz",
  sec:[
  ["Fusion",[
    "Around 1970, jazz musicians embraced electric instruments and rock and funk rhythms. Miles Davis's In a Silent Way and Bitches Brew launched jazz-rock fusion. His sidemen founded key fusion bands: Weather Report (Joe Zawinul and Wayne Shorter, with bassist Jaco Pastorius), Herbie Hancock's Headhunters (whose 'Chameleon' is a funk classic), Chick Corea's Return to Forever, and John McLaughlin's Mahavishnu Orchestra.",
    "Fusion brought jazz new audiences but critics argued over its commercialism. Smooth jazz, a radio-friendly style, followed in the 1980s."]],
  ["The neoclassical movement",[
    "In the 1980s, trumpeter Wynton Marsalis led a movement to restore acoustic jazz traditions, swing, and the blues, and became artistic director of Jazz at Lincoln Center, founded in 1987. Ken Burns's documentary Jazz (2001) reflected this view of jazz history.",
    "Marsalis won Grammys in both jazz and classical categories, and in 1997 his oratorio Blood on the Fields became the first jazz composition to win the Pulitzer Prize for Music."]],
  ["Jazz around the world",[
    "Jazz became global. Europe developed its own scenes: the ECM label's spacious sound with Keith Jarrett (whose 1975 Köln Concert is the best-selling solo piano album), Jan Garbarek, and others; Django Reinhardt's 'gypsy jazz' in 1930s France had already shown European originality.",
    "Brazilian bossa nova merged samba and cool jazz; Latin jazz grew from Afro-Cuban roots with Machito, Tito Puente, and Chucho Valdés; South Africa produced Hugh Masekela and Abdullah Ibrahim; and Ethiopia's Mulatu Astatke created Ethio-jazz."]],
  ["Jazz vocal and the Great American Songbook",[
    "Jazz singers such as Sarah Vaughan, Nina Simone, Carmen McRae, Betty Carter, Cassandra Wilson, Diana Krall, and Cécile McLorin Salvant have interpreted the Great American Songbook, the canon of popular songs from about the 1920s to 1950s by writers such as Gershwin, Cole Porter, Irving Berlin, Jerome Kern, Richard Rodgers, and Harold Arlen.",
    "These songs, called 'standards,' remain the shared repertoire of jazz musicians, who learn them from 'fake books' with melody and chord symbols."]],
  ["Jazz today",[
    "Twenty-first-century jazz blends hip-hop, R&B, electronic music, and global influences. Robert Glasper, Kamasi Washington (whose album The Epic was a 2015 landmark), Esperanza Spalding, Snarky Puppy, Shabaka Hutchings and the London scene, and Jacob Collier have reached new young audiences.",
    "Jazz education has grown enormously, with university programs worldwide. Improvisation remains the heart of the music: spontaneous creation within shared structures."]],
  ["How a jazz performance works",[
    "A typical small-group jazz performance follows a pattern: the band plays the head (melody), then players take turns improvising solos over the repeating chord cycle (each pass is a chorus), sometimes 'trading fours' with the drummer (alternating four-bar phrases), and finally the head returns.",
    "Listeners traditionally applaud after each solo. Understanding this structure makes jazz far easier to follow."]]
  ],
  terms:[["Fusion","Jazz combined with rock and funk."],["Standard","Well-known song in the jazz repertoire."],["Chorus (jazz)","One pass through the tune's form."],["Trading fours","Alternating four-bar solos."],["Fake book","Book of lead sheets with melody and chords."]],
  w:"Jazz keeps renewing itself, and knowing how a performance is structured unlocks any jazz gig.",
  src:["Jazz fusion","Wynton Marsalis","Great American Songbook","Jazz standard","Keith Jarrett"],
  q:[
  ["Which Miles Davis album helped launch jazz-rock fusion?","Bitches Brew","Kind of Blue","Birth of the Cool","Milestones"],
  ["Which band featured Joe Zawinul and Wayne Shorter?","Weather Report","Return to Forever","Headhunters","Mahavishnu Orchestra"],
  ["What is 'trading fours'?","Alternating four-bar solos","Playing in 4/4 time","Four soloists at once","Changing four keys"],
  ["Whose oratorio was the first jazz work to win the Pulitzer Prize?","Wynton Marsalis","Duke Ellington","Ornette Coleman","Herbie Hancock"],
  ["Which solo piano album is the best-selling of its kind?","Keith Jarrett's The Köln Concert","Bill Evans's Sunday at the Village Vanguard","Thelonious Monk's Solo Monk","Art Tatum's Solo Masterpieces"],
  ["What is the 'head' in jazz?","The composed melody","The bandleader","The first soloist","The drum intro"]]},

{ t:"Gospel Music", s:"Good news in song",
  sec:[
  ["From hymns to gospel",[
    "Gospel music grew in African American churches in the early 20th century from spirituals, hymns, and the lively worship of Pentecostal and Holiness churches, where congregations sang with shouts, clapping, and instruments such as tambourines and pianos.",
    "Thomas A. Dorsey (1899–1993), a former blues pianist known as 'Georgia Tom,' is called the 'Father of Gospel Music.' He blended blues and jazz feeling with sacred texts, founded the first gospel publishing house, and wrote 'Take My Hand, Precious Lord' (1932) after the deaths of his wife and child."]],
  ["Great gospel singers",[
    "Mahalia Jackson (1911–1972), the 'Queen of Gospel,' brought gospel to international audiences with her majestic voice. She sang at the 1963 March on Washington, where she reportedly urged Martin Luther King Jr. to 'tell them about the dream.'",
    "Sister Rosetta Tharpe (1915–1973) played electric guitar with a driving, bluesy style that influenced early rock and roll; she is sometimes called the 'Godmother of Rock and Roll.' Quartets such as the Soul Stirrers (with young Sam Cooke), the Dixie Hummingbirds, and the Golden Gate Quartet were also hugely popular."]],
  ["Sound and style",[
    "Gospel singing uses call and response between leader and choir, melisma (runs of notes on a single syllable), vocal improvisation, dramatic dynamic builds, and emotional intensity. The Hammond organ, piano, bass, and drums drive the music, and choirs sing in rich harmony.",
    "Gospel choirs grew in the 1960s and 70s with James Cleveland and Edwin Hawkins, whose 'Oh Happy Day' (1969) became an international pop hit."]],
  ["Contemporary gospel",[
    "Contemporary gospel incorporates R&B, funk, and hip-hop. Andraé Crouch, the Winans, Kirk Franklin (who blended gospel and hip-hop in the 1990s), Yolanda Adams, and CeCe Winans became major stars.",
    "Southern gospel, a separate largely white tradition with male quartets, and contemporary Christian music (CCM) also have large audiences."]],
  ["Gospel's influence",[
    "Gospel shaped soul music profoundly: Ray Charles turned gospel songs into secular hits, and Aretha Franklin, Sam Cooke, Whitney Houston, and many others learned to sing in church. The melismatic vocal runs of modern R&B and pop singers descend from gospel.",
    "Gospel also gave voice to the civil rights movement, through songs such as 'We Shall Overcome,' derived from a gospel hymn, and the freedom songs sung during marches."]]
  ],
  terms:[["Gospel","African American sacred music blending hymns, blues, and jazz."],["Melisma","Many notes sung on one syllable."],["Quartet (gospel)","Small vocal group, often four or five men."],["Freedom songs","Songs of the civil rights movement."],["CCM","Contemporary Christian music."]],
  w:"Gospel is the training ground of soul and R&B singing and the soundtrack of the civil rights movement.",
  src:["Gospel music","Thomas A. Dorsey","Mahalia Jackson","Sister Rosetta Tharpe","We Shall Overcome"],
  q:[
  ["Who is called the 'Father of Gospel Music'?","Thomas A. Dorsey","James Cleveland","Andraé Crouch","Sam Cooke"],
  ["Who is known as the 'Queen of Gospel'?","Mahalia Jackson","Aretha Franklin","Sister Rosetta Tharpe","Yolanda Adams"],
  ["Which gospel artist's electric guitar influenced early rock and roll?","Sister Rosetta Tharpe","Mahalia Jackson","Thomas Dorsey","Kirk Franklin"],
  ["Which 1969 gospel recording became an international pop hit?","Oh Happy Day","Precious Lord","Amazing Grace","Stomp"],
  ["Which famous soul singer started in the Soul Stirrers?","Sam Cooke","Ray Charles","Otis Redding","Marvin Gaye"],
  ["Which civil rights anthem derives from a gospel hymn?","We Shall Overcome","Blowin' in the Wind","A Change Is Gonna Come","Strange Fruit"]]},

{ t:"Country and Bluegrass", s:"Three chords and the truth",
  sec:[
  ["Roots",[
    "Country music grew from the folk music of the rural American South, especially the Appalachian region, where ballads and fiddle tunes from England, Scotland, and Ireland mixed with African American blues and the banjo. Hymns, cowboy songs, and vaudeville also fed in.",
    "Early recordings were called 'hillbilly music.' The 1927 Bristol Sessions in Bristol, Tennessee, recorded by Ralph Peer, introduced both the Carter Family, with their harmony singing and Maybelle Carter's guitar style, and Jimmie Rodgers, the 'Singing Brakeman,' whose yodeling blues made him the first country star. These sessions are often called the 'big bang' of country music."]],
  ["The Grand Ole Opry and Nashville",[
    "The Grand Ole Opry, a radio show broadcast from Nashville since 1925, spread country music nationwide and made Nashville its capital. In the 1930s–40s, Western swing (Bob Wills) and singing cowboys in films (Gene Autry, Roy Rogers) were popular.",
    "Hank Williams (1923–1953), with songs like 'Your Cheatin' Heart' and 'I'm So Lonesome I Could Cry,' became the model of the country singer-songwriter before his death at 29."]],
  ["Bluegrass",[
    "Bluegrass was developed in the 1940s by Bill Monroe and his Blue Grass Boys (named for Kentucky, the 'Bluegrass State'). It features acoustic instruments, fiddle, mandolin, five-string banjo, guitar, and upright bass, with fast tempos, virtuosic solos passed around the band, and high, lonesome harmony singing.",
    "Earl Scruggs's three-finger banjo picking and Lester Flatt's guitar defined the sound; their 'Foggy Mountain Breakdown' is a classic. Later stars include Ralph Stanley, Alison Krauss, and Billy Strings."]],
  ["Nashville sound and outlaws",[
    "In the late 1950s and 60s, Nashville producers such as Chet Atkins created the polished 'Nashville sound' with strings and backing choirs, as heard in Patsy Cline's 'Crazy' (written by Willie Nelson). Meanwhile, the Bakersfield sound of Buck Owens and Merle Haggard kept a raw, twangy edge.",
    "In the 1970s, 'outlaw country' artists, Willie Nelson, Waylon Jennings, and Johnny Cash, rebelled against Nashville control. Cash, the 'Man in Black,' recorded famous concerts at Folsom and San Quentin prisons. Loretta Lynn, Dolly Parton ('Jolene,' 'I Will Always Love You'), and Tammy Wynette sang about working-class women's lives."]],
  ["Modern country",[
    "From the late 1980s, Garth Brooks, Shania Twain, and others brought arena-scale pop country, making country one of America's best-selling genres. Taylor Swift began as a country artist before moving to pop.",
    "Recent decades have seen country-rap crossovers, such as Lil Nas X's 'Old Town Road' (2019), and renewed debates about who belongs in country; Beyoncé's Cowboy Carter (2024) highlighted Black roots of the genre. Alternative country and Americana artists such as Chris Stapleton, Kacey Musgraves, and Jason Isbell maintain its storytelling tradition. Harlan Howard's description of country as 'three chords and the truth' is often quoted."]]
  ],
  terms:[["Bristol Sessions","1927 recordings that launched country music."],["Grand Ole Opry","Nashville country radio show since 1925."],["Bluegrass","Fast acoustic string-band style created by Bill Monroe."],["Nashville sound","Polished country style with strings and choirs."],["Outlaw country","1970s rebellion against Nashville polish."]],
  w:"Country and bluegrass preserve old folk traditions and remain among the most popular music in America.",
  src:["Country music","Bristol sessions","Bluegrass music","Grand Ole Opry","Hank Williams"],
  q:[
  ["Who is called the 'Father of Bluegrass'?","Bill Monroe","Earl Scruggs","Hank Williams","Ralph Stanley"],
  ["Which 1927 recording sessions launched the Carter Family and Jimmie Rodgers?","The Bristol Sessions","The Sun Sessions","The Opry Sessions","The Atlanta Sessions"],
  ["Which radio show made Nashville the capital of country music?","The Grand Ole Opry","Louisiana Hayride","American Bandstand","The Ed Sullivan Show"],
  ["Which country star was known as the 'Man in Black'?","Johnny Cash","Waylon Jennings","Merle Haggard","George Jones"],
  ["Who wrote Patsy Cline's hit 'Crazy'?","Willie Nelson","Hank Williams","Dolly Parton","Kris Kristofferson"],
  ["Which instrument is NOT standard in a bluegrass band?","Drum kit","Banjo","Mandolin","Fiddle"]]},

{ t:"Folk, Broadway, and the Popular Song", s:"Tin Pan Alley to the folk revival",
  sec:[
  ["Tin Pan Alley",[
    "From the 1880s to the 1950s, America's popular song industry was centered in New York's Tin Pan Alley, a stretch of West 28th Street where music publishers employed songwriters and 'song pluggers' to promote sheet music. The name supposedly came from the clatter of many pianos sounding like tin pans.",
    "Songwriters such as Irving Berlin ('White Christmas,' 'God Bless America'), George and Ira Gershwin, Cole Porter ('Night and Day'), Jerome Kern ('Ol' Man River'), Richard Rodgers with Lorenz Hart and later Oscar Hammerstein II, and Harold Arlen ('Over the Rainbow') created the Great American Songbook. The typical form was the 32-bar AABA song."]],
  ["The Broadway musical",[
    "The American musical grew from operetta, vaudeville, and revues. Show Boat (1927), by Jerome Kern and Oscar Hammerstein II, integrated songs with a serious story about race and marriage. Rodgers and Hammerstein's Oklahoma! (1943) fully integrated songs, dance, and plot, and they followed with Carousel, South Pacific, The King and I, and The Sound of Music.",
    "Golden-age hits included Lerner and Loewe's My Fair Lady, Bernstein's West Side Story, and Fiddler on the Roof. Later innovators include Stephen Sondheim (Company, Sweeney Todd, Into the Woods), Andrew Lloyd Webber's mega-musicals (The Phantom of the Opera, Cats), Les Misérables, Jonathan Larson's Rent, and Lin-Manuel Miranda's hip-hop musical Hamilton (2015)."]],
  ["Folk music in America",[
    "Folklorists such as John and Alan Lomax traveled the South for the Library of Congress from the 1930s, recording blues, work songs, ballads, and prison songs; they recorded Lead Belly and Muddy Waters. Woody Guthrie (1912–1967), who wrote 'This Land Is Your Land,' sang about Dust Bowl migrants and workers, with 'This machine kills fascists' written on his guitar.",
    "Pete Seeger, with the Weavers, popularized folk songs in the 1950s despite being blacklisted during the McCarthy era for his politics."]],
  ["The folk revival",[
    "In the late 1950s and early 1960s, a folk revival centered in places like New York's Greenwich Village brought acoustic folk songs to young audiences. The Kingston Trio, Joan Baez, Odetta, and Peter, Paul and Mary had hits, and folk became the voice of the civil rights and antiwar movements.",
    "Bob Dylan (born 1941) wrote protest songs such as 'Blowin' in the Wind' and 'The Times They Are a-Changin'.' His decision to play with an electric band at the 1965 Newport Folk Festival caused uproar and helped create folk rock. Dylan received the Nobel Prize in Literature in 2016, the first songwriter to do so."]],
  ["Singer-songwriters",[
    "The folk revival led to the singer-songwriter movement of the late 1960s and 70s: Joni Mitchell (Blue, 1971), James Taylor, Carole King (Tapestry, 1971), Leonard Cohen, Paul Simon, Neil Young, Cat Stevens, and Nick Drake wrote personal, introspective songs, often on acoustic guitar or piano.",
    "This tradition of personal songwriting continues in artists from Tracy Chapman and Ani DiFranco to Phoebe Bridgers and Taylor Swift."]]
  ],
  terms:[["Tin Pan Alley","New York's popular song publishing industry."],["32-bar form","AABA song form of four eight-bar sections."],["Book musical","Musical where songs advance the story."],["Folk revival","1950s–60s renewal of folk song."],["Singer-songwriter","Artist who writes and performs personal songs."]],
  w:"Tin Pan Alley and Broadway created the classic popular song, and the folk revival made songwriting a voice of conscience.",
  src:["Tin Pan Alley","Musical theatre","Oklahoma!","Bob Dylan","American folk music revival"],
  q:[
  ["Which musical by Rodgers and Hammerstein (1943) fully integrated song, dance, and plot?","Oklahoma!","Show Boat","Carousel","Guys and Dolls"],
  ["Who wrote 'This Land Is Your Land'?","Woody Guthrie","Pete Seeger","Bob Dylan","Lead Belly"],
  ["Where did Bob Dylan controversially 'go electric' in 1965?","Newport Folk Festival","Woodstock","Monterey Pop","Carnegie Hall"],
  ["What is the typical form of a Tin Pan Alley song?","32-bar AABA","12-bar blues","Verse-chorus only","Through-composed"],
  ["Which Joni Mitchell album (1971) is a singer-songwriter landmark?","Blue","Tapestry","Harvest","Sweet Baby James"],
  ["Which songwriter won the Nobel Prize in Literature in 2016?","Bob Dylan","Leonard Cohen","Paul Simon","Joni Mitchell"]]}

);


/* ---- from music-14.js ---- */
/* MUSIC FOUNDATIONS, part 14: Unit 7 Popular Music, chapters 1-4 */
COURSES.music.units.push({ t:"Popular Music: From Records to Streaming", ch:[

{ t:"Recording, Radio, and the Music Industry", s:"How technology made pop",
  sec:[
  ["Capturing sound",[
    "In 1877 Thomas Edison invented the phonograph, recording sound as grooves on a tinfoil cylinder. (Édouard-Léon Scott de Martinville's phonautograph of 1857 had traced sound waves on paper, but could not play them back.) Emile Berliner's gramophone (1887) used flat discs, which were easier to mass-produce and won out.",
    "Early recording was acoustic: performers crowded around a horn. Electrical recording with microphones arrived in 1925, capturing a wider range of sound and enabling intimate 'crooning' singers such as Bing Crosby, who sang softly close to the microphone."]],
  ["Records and formats",[
    "The 78 rpm shellac disc held about three minutes per side, which shaped the length of popular songs, a standard that largely persists. After World War II, Columbia introduced the 33⅓ rpm long-playing (LP) vinyl record (1948), holding over 20 minutes per side, and RCA the 45 rpm single (1949).",
    "Later formats included the compact cassette (1963), the compact disc (CD, 1982), MP3 digital files (1990s), and streaming. Each change reshaped how music was made and consumed: the LP made the 'album' an artistic statement, the cassette made music portable and copyable (the Sony Walkman, 1979), and the MP3 made it shareable over the internet."]],
  ["Radio and charts",[
    "Commercial radio broadcasting began in 1920, and by the 1930s radio was the main way most people heard music. Radio created national hits and stars. In the 1950s, Top 40 radio played the most popular singles on rotation, and disc jockeys (DJs) such as Alan Freed promoted rock and roll.",
    "Billboard magazine began charting record sales, and its Hot 100 chart started in 1958. 'Payola,' paying DJs to play records, became a scandal in 1959–60."]],
  ["Multitrack recording and the studio",[
    "Magnetic tape recording, developed in Germany in the 1930s and spread after the war, allowed editing. Guitarist Les Paul pioneered multitrack recording and overdubbing in the late 1940s–50s, recording multiple parts separately and layering them.",
    "By the 1960s the recording studio became an instrument in itself: Phil Spector's 'Wall of Sound,' the Beatles' experiments with George Martin at Abbey Road, and the Beach Boys' Pet Sounds used multitracking, tape effects, and orchestration impossible to perform live."]],
  ["The business",[
    "The music industry has several revenue streams: recorded music sales and streams; publishing, which collects royalties for songwriters when songs are performed, broadcast, or recorded; live concerts; and licensing for films, ads, and games. A record label signs artists and finances, markets, and distributes recordings; the 'major labels' today are Universal, Sony, and Warner.",
    "Performing rights organizations such as ASCAP and BMI in the US, and PRS in the UK, collect royalties for public performance of songs."]],
  ["The streaming era",[
    "File-sharing service Napster (1999) disrupted the industry by letting users share MP3s freely, and recorded music revenue fell sharply in the 2000s. Apple's iTunes Store (2003) sold legal downloads.",
    "Streaming services such as Spotify (launched 2008) and Apple Music now provide most recorded-music revenue, paying fractions of a cent per stream. Playlists and algorithms shape discovery, and social media platforms such as TikTok can turn songs into global hits overnight."]]
  ],
  terms:[["Phonograph","Edison's 1877 sound-recording machine."],["LP","Long-playing 33⅓ rpm record introduced 1948."],["Multitrack recording","Recording parts separately and layering them."],["Publishing","Business of songwriters' rights and royalties."],["Payola","Illegal payment for radio airplay."]],
  w:"Every popular style was shaped by technology and business; knowing them explains why songs sound and last as they do.",
  src:["Phonograph","Gramophone record","Multitrack recording","Music industry","Music streaming service"],
  q:[
  ["Who invented the phonograph in 1877?","Thomas Edison","Emile Berliner","Alexander Graham Bell","Guglielmo Marconi"],
  ["Which format did Columbia introduce in 1948?","The 33⅓ rpm LP","The 45 rpm single","The cassette","The 78 rpm disc"],
  ["Who pioneered multitrack recording and overdubbing?","Les Paul","Phil Spector","George Martin","Leo Fender"],
  ["What is payola?","Paying DJs to play records","A royalty for songwriters","A type of record contract","A recording technique"],
  ["Which file-sharing service disrupted the industry in 1999?","Napster","Spotify","iTunes","LimeWire"],
  ["Why did early pop songs last about three minutes?","78 rpm discs held about three minutes per side","Radio rules required it","Listeners' attention spans","Union regulations"]]},

{ t:"Rhythm and Blues and the Birth of Rock and Roll", s:"1940s–1950s",
  sec:[
  ["Rhythm and blues",[
    "In 1949 Billboard renamed its 'race records' chart 'Rhythm & Blues,' a term coined by journalist Jerry Wexler, who later became a producer at Atlantic Records. R&B combined blues, jazz, and gospel with a strong backbeat for dancing.",
    "Louis Jordan's jump blues ('Caldonia,' 'Choo Choo Ch'Boogie') with small bands and humorous lyrics was hugely popular in the 1940s. Vocal groups sang doo-wop harmony on street corners and records. Ruth Brown, LaVern Baker, and Big Mama Thornton (the original 'Hound Dog,' 1953) were R&B stars."]],
  ["What was the first rock and roll record?",[
    "There is no single answer. Candidates include Wynonie Harris's 'Good Rocking Tonight' (1948), Fats Domino's 'The Fat Man' (1949), and especially 'Rocket 88' (1951), credited to Jackie Brenston and his Delta Cats but actually Ike Turner's band, recorded by Sam Phillips in Memphis, with a distorted guitar from a damaged amplifier.",
    "DJ Alan Freed popularized the term 'rock and roll' on his Cleveland radio show from 1951, bringing Black R&B to white teenagers. Bill Haley and His Comets' 'Rock Around the Clock' (1954) became a global hit after appearing in the film Blackboard Jungle (1955)."]],
  ["The pioneers",[
    "Chuck Berry (1926–2017) wrote witty songs about teenage life, cars, and school, and created the guitar language of rock: 'Maybellene,' 'Roll Over Beethoven,' and 'Johnny B. Goode,' with its famous opening riff. Little Richard (1932–2020), with his pounding piano, wild screams, and flamboyance on 'Tutti Frutti' and 'Long Tall Sally,' brought gospel intensity.",
    "Fats Domino, with gentle New Orleans boogie piano ('Blueberry Hill'), sold more records than almost anyone in the 1950s. Bo Diddley's shuffling 'Bo Diddley beat' influenced generations. Buddy Holly, with his Crickets' two guitars, bass, and drums lineup and self-written songs ('That'll Be the Day,' 'Peggy Sue'), became a model for rock bands before dying in a 1959 plane crash, 'the day the music died.' Jerry Lee Lewis pounded the piano on 'Great Balls of Fire.'"]],
  ["Race and rock and roll",[
    "Rock and roll emerged in a segregated America. Many early hits by Black artists were 'covered' by white performers in watered-down versions that received more airplay and sales, such as Pat Boone's versions of Little Richard and Fats Domino songs.",
    "Yet rock and roll also brought Black and white audiences together at concerts, sometimes defying segregation laws, and was attacked by critics as immoral and dangerous. Its rise was intertwined with the civil rights movement and the new spending power of teenagers."]],
  ["Musical features",[
    "Early rock and roll typically uses the 12-bar blues and simple verse-chorus forms, a strong backbeat on beats 2 and 4, boogie-woogie bass patterns, shuffle or straight eighth rhythms, electric guitar riffs and solos, saxophone breaks, and energetic vocals.",
    "Rockabilly, mixing country and R&B, was a white Southern variant associated with Sun Records in Memphis: Carl Perkins ('Blue Suede Shoes'), Johnny Cash, Jerry Lee Lewis, and above all Elvis Presley."]]
  ],
  terms:[["Rhythm and blues","Black popular music combining blues, jazz, and gospel with a backbeat."],["Doo-wop","Vocal group harmony style of the 1950s."],["Rockabilly","Mix of country and R&B from the Southern US."],["Cover version","New recording of a previously recorded song."],["Jump blues","Up-tempo, horn-driven 1940s blues."]],
  w:"Rock and roll, rooted in Black R&B, created youth culture and the template for all later popular music.",
  src:["Rhythm and blues","Rock and roll","Chuck Berry","Little Richard","Rocket 88"],
  q:[
  ["Which 1951 record, recorded by Sam Phillips, is a candidate for the first rock and roll record?","Rocket 88","Rock Around the Clock","Hound Dog","Tutti Frutti"],
  ["Which DJ popularized the term 'rock and roll'?","Alan Freed","Dick Clark","Wolfman Jack","Sam Phillips"],
  ["Who wrote 'Johnny B. Goode'?","Chuck Berry","Little Richard","Bo Diddley","Buddy Holly"],
  ["Who recorded the original 'Hound Dog' in 1953?","Big Mama Thornton","Ruth Brown","Etta James","LaVern Baker"],
  ["What is rockabilly?","A mix of country and R&B","A type of doo-wop","Rock played on banjo","British rock"],
  ["Which film made 'Rock Around the Clock' a global hit?","Blackboard Jungle","Rebel Without a Cause","Jailhouse Rock","The Girl Can't Help It"]]},

{ t:"Elvis Presley and the Rock Explosion", s:"The King",
  sec:[
  ["Sun Records",[
    "Elvis Presley (1935–1977) was born in Tupelo, Mississippi, and grew up in Memphis, absorbing gospel, blues, country, and pop. In 1954 at Sam Phillips's Sun Records, during a break in a session, he began playing Arthur Crudup's blues 'That's All Right' in an energetic style with guitarist Scotty Moore and bassist Bill Black. Phillips had reportedly been seeking a white singer with the Black sound and feel.",
    "His Sun recordings fused country and R&B into rockabilly."]],
  ["National stardom",[
    "In 1955 RCA bought his contract, and manager 'Colonel' Tom Parker guided his career. 'Heartbreak Hotel' (1956) became his first national number one, followed by 'Hound Dog,' 'Don't Be Cruel,' 'Love Me Tender,' and 'Jailhouse Rock.'",
    "His television appearances, especially on The Ed Sullivan Show in 1956–57, caused a sensation; his hip-swiveling performances shocked adults and thrilled teenagers, and on his third Sullivan appearance he was famously shown only from the waist up."]],
  ["The army and Hollywood",[
    "Drafted into the US Army in 1958, Elvis served in Germany until 1960. Afterward, Parker steered him into a string of formulaic films, such as Blue Hawaii and Viva Las Vegas, with soundtrack songs, while British bands took over rock's cutting edge.",
    "His 1968 television special, known as the '68 Comeback Special, in black leather, revived his career, followed by acclaimed recordings such as 'Suspicious Minds' (1969) and years of Las Vegas residencies in jumpsuits."]],
  ["Decline and legacy",[
    "Elvis's health declined amid prescription drug dependence, and he died at his Memphis home, Graceland, in 1977, aged 42. Graceland is now one of the most visited homes in the United States.",
    "Called 'the King of Rock and Roll,' he is one of the best-selling solo artists in history. His success opened the mainstream to rock and roll, though debates continue about how much of his fame rested on Black musical traditions that Black artists had been denied the same rewards for."]],
  ["Other 1950s figures",[
    "The Everly Brothers' close harmonies ('Bye Bye Love,' 'All I Have to Do Is Dream') influenced the Beatles and Simon & Garfunkel. Ritchie Valens, a Mexican-American pioneer, adapted the folk song 'La Bamba.' Ray Charles, combining gospel and R&B in 'I Got a Woman' (1954) and 'What'd I Say' (1959), is often credited with creating soul music.",
    "By the late 1950s, scandals, deaths, and Elvis's army service created a lull filled by teen idols, girl groups, and the Brill Building songwriters."]]
  ],
  terms:[["Sun Records","Memphis label where Elvis began."],["Graceland","Elvis's Memphis home, now a museum."],["'68 Comeback Special","1968 TV show that revived Elvis's career."],["Teen idol","Young star marketed to teenagers."],["Soul (origins)","Gospel-influenced R&B pioneered by Ray Charles."]],
  w:"Elvis made rock and roll a national phenomenon and became the first great rock icon.",
  src:["Elvis Presley","Sun Records","Sam Phillips","Ray Charles","The Everly Brothers"],
  q:[
  ["At which label did Elvis Presley first record?","Sun Records","RCA","Chess Records","Atlantic"],
  ["Which song was Elvis's first national number one?","Heartbreak Hotel","Hound Dog","That's All Right","Jailhouse Rock"],
  ["Who managed Elvis's career?","Colonel Tom Parker","Sam Phillips","Ahmet Ertegun","Berry Gordy"],
  ["What is Graceland?","Elvis's Memphis home","Elvis's first album","A recording studio","A Las Vegas hotel"],
  ["Which TV show caused a sensation with Elvis in 1956–57?","The Ed Sullivan Show","American Bandstand","The Tonight Show","Shindig!"],
  ["Who is often credited with creating soul music?","Ray Charles","Elvis Presley","Buddy Holly","Jerry Lee Lewis"]]},

{ t:"Motown, Soul, and the Brill Building", s:"The early sixties",
  sec:[
  ["Brill Building pop",[
    "In New York's Brill Building and nearby 1650 Broadway, teams of professional songwriters wrote hits for others: Carole King and Gerry Goffin ('Will You Love Me Tomorrow'), Barry Mann and Cynthia Weil ('You've Lost That Lovin' Feelin''), Burt Bacharach and Hal David, Jerry Leiber and Mike Stoller ('Hound Dog,' 'Stand by Me' with Ben E. King), and Neil Sedaka.",
    "Girl groups such as the Shirelles, the Ronettes ('Be My Baby'), the Crystals, and the Shangri-Las sang these songs. Producer Phil Spector's 'Wall of Sound' layered many instruments in echo chambers for a massive effect."]],
  ["Motown",[
    "Berry Gordy, a former autoworker and songwriter, founded Motown Records in Detroit in 1959 with an $800 family loan. Modeling it on an automobile assembly line, Motown had in-house songwriters (notably Holland–Dozier–Holland and Smokey Robinson), the studio band the Funk Brothers, and an artist development department teaching choreography and etiquette.",
    "The 'Sound of Young America' produced hits by the Supremes (with Diana Ross), the Temptations ('My Girl'), Smokey Robinson and the Miracles, Marvin Gaye, Stevie Wonder (signed as an 11-year-old), Martha and the Vandellas ('Dancing in the Street'), the Four Tops, and the Jackson 5. Motown became one of the most successful Black-owned businesses in America and crossed over to white audiences."]],
  ["Southern soul",[
    "Soul music, drawing on gospel fervor, was rawer in the South. Stax Records in Memphis, with house band Booker T. & the M.G.'s (an integrated group), recorded Otis Redding ('(Sittin' On) The Dock of the Bay'), Sam & Dave ('Soul Man'), and Isaac Hayes. In Muscle Shoals, Alabama, studios with local session players recorded Aretha Franklin, Wilson Pickett, and later the Rolling Stones.",
    "Aretha Franklin (1942–2018), the 'Queen of Soul,' recorded 'Respect' (1967), turning Otis Redding's song into an anthem of civil rights and women's empowerment, and 'Chain of Fools' and '(You Make Me Feel Like) A Natural Woman.'"]],
  ["Soul and civil rights",[
    "Sam Cooke's 'A Change Is Gonna Come' (1964), inspired partly by Dylan's 'Blowin' in the Wind' and by Cooke's experience of discrimination, became a civil rights anthem. James Brown's 'Say It Loud – I'm Black and I'm Proud' (1968) and Curtis Mayfield's 'People Get Ready' expressed pride and hope.",
    "In 1971 Marvin Gaye's What's Going On, about war, poverty, and the environment, and Stevie Wonder's albums such as Innervisions and Songs in the Key of Life showed that soul artists could create ambitious, socially conscious albums with artistic control."]],
  ["James Brown and the birth of funk",[
    "James Brown (1933–2006), the 'Godfather of Soul' and 'Hardest-Working Man in Show Business,' was an electrifying performer. In songs like 'Papa's Got a Brand New Bag' (1965) and 'Cold Sweat' (1967), he shifted emphasis to rhythm: every instrument became percussive, with chopping guitar chords, tight horn stabs, and a heavy accent on the first beat ('the one').",
    "This new style, funk, influenced disco, hip-hop (his drummers' breaks, such as Clyde Stubblefield's on 'Funky Drummer,' are among the most sampled recordings ever), and Afrobeat."]]
  ],
  terms:[["Brill Building","New York center of professional pop songwriting."],["Wall of Sound","Phil Spector's dense production style."],["Motown","Detroit label: 'The Sound of Young America.'"],["Stax","Memphis soul label."],["Funk","Rhythm-driven style emphasizing 'the one.'"]],
  w:"Motown and soul gave pop its greatest singers and songs, and soul carried the spirit of the civil rights movement.",
  src:["Motown","Berry Gordy","Aretha Franklin","Stax Records","James Brown"],
  q:[
  ["Who founded Motown Records?","Berry Gordy","Smokey Robinson","Ahmet Ertegun","Jerry Wexler"],
  ["Which singer is called the 'Queen of Soul'?","Aretha Franklin","Diana Ross","Gladys Knight","Tina Turner"],
  ["Which Memphis label had Booker T. & the M.G.'s as its house band?","Stax","Sun","Motown","Atlantic"],
  ["Which Marvin Gaye album (1971) addressed war and poverty?","What's Going On","Let's Get It On","Here, My Dear","I Want You"],
  ["Which artist is called the 'Godfather of Soul'?","James Brown","Otis Redding","Sam Cooke","Wilson Pickett"],
  ["What was Phil Spector's production style called?","Wall of Sound","Motown Sound","Nashville Sound","Philly Sound"]]}

]});


/* ---- from music-15.js ---- */
/* MUSIC FOUNDATIONS, part 15: Unit 7 chapters 5-9 */
COURSES.music.units[6].ch.push(

{ t:"The Beatles and the British Invasion", s:"Four lads from Liverpool",
  sec:[
  ["Liverpool and Hamburg",[
    "The Beatles, John Lennon, Paul McCartney, George Harrison, and Ringo Starr, formed in Liverpool in the late 1950s out of the skiffle craze, a British do-it-yourself style using guitars, washboards, and tea-chest basses. They honed their skills in grueling all-night club sets in Hamburg, Germany, and at Liverpool's Cavern Club.",
    "Manager Brian Epstein polished their image, and producer George Martin signed them to EMI's Parlophone label. Their first hit, 'Love Me Do,' came in 1962, and 'Please Please Me' and 'She Loves You' launched 'Beatlemania' in Britain."]],
  ["America and Beatlemania",[
    "'I Want to Hold Your Hand' reached number one in the US in early 1964, and their appearance on The Ed Sullivan Show on 9 February 1964 drew an estimated 73 million viewers. In April 1964 they held the top five positions on the Billboard Hot 100 at once.",
    "Their success opened the door for the British Invasion: the Rolling Stones, the Kinks, the Who, the Animals, Herman's Hermits, the Dave Clark Five, and others, who had learned from American blues and rock and roll and sold it back to America."]],
  ["Songwriting and growth",[
    "Lennon and McCartney's songwriting partnership produced an extraordinary catalogue; unlike most earlier pop acts, the Beatles wrote their own songs, setting a new standard. Their music evolved rapidly: from cheerful pop ('A Hard Day's Night') to folk-influenced introspection ('Yesterday,' 'In My Life' on Rubber Soul, 1965) to studio experiment.",
    "Harrison introduced the Indian sitar, which he studied with Ravi Shankar, on 'Norwegian Wood' and 'Within You Without You.' Revolver (1966) used tape loops, reversed sounds, and Indian music on 'Tomorrow Never Knows.'"]],
  ["The studio years",[
    "In 1966 the Beatles stopped touring, partly because screaming fans drowned out their playing, and focused on recording. Sgt. Pepper's Lonely Hearts Club Band (1967), recorded at Abbey Road with George Martin and engineer Geoff Emerick, was hailed as a landmark concept album, using orchestras, sound effects, and multitrack techniques; 'A Day in the Life' ends with a famous orchestral crescendo and long piano chord.",
    "Later albums included the 'White Album' (1968) and Abbey Road (1969), with its medley and the famous zebra-crossing cover. 'Hey Jude' (1968) became one of their biggest singles. Tensions over business (their company Apple Corps) and direction led to their breakup in 1970."]],
  ["Legacy",[
    "The Beatles are the best-selling music act in history. They transformed popular music by writing their own material, treating the album as an art form, expanding studio techniques, absorbing diverse influences, and shaping youth culture, fashion, and film (A Hard Day's Night, Help!).",
    "After the breakup, each member had solo success: Lennon's 'Imagine' (1971), McCartney with Wings, Harrison's All Things Must Pass, and Starr. Lennon was murdered in New York in 1980, and Harrison died in 2001. A final 'new' Beatles song, 'Now and Then,' completed with the help of audio-separation technology, was released in 2023."]],
  ["The Rolling Stones and others",[
    "The Rolling Stones, led by Mick Jagger and Keith Richards, cultivated a rougher, rebellious, blues-based image: '(I Can't Get No) Satisfaction' (1965), 'Paint It Black,' 'Gimme Shelter,' and albums like Beggars Banquet and Exile on Main St. They are still performing in the 2020s.",
    "The Who (with Pete Townshend's guitar-smashing and the rock opera Tommy), the Kinks ('You Really Got Me,' 'Waterloo Sunset'), and the Animals ('The House of the Rising Sun') also left lasting marks."]]
  ],
  terms:[["Skiffle","British DIY folk-blues craze of the 1950s."],["British Invasion","Mid-1960s wave of British bands in the US."],["Concept album","Album unified by a theme or idea."],["Abbey Road","EMI studio where the Beatles recorded."],["Lennon–McCartney","The Beatles' songwriting partnership."]],
  w:"The Beatles redefined what a pop group could be and turned the album into an art form.",
  src:["The Beatles","British Invasion","Sgt. Pepper's Lonely Hearts Club Band","The Rolling Stones","George Martin"],
  q:[
  ["Who produced most of the Beatles' recordings?","George Martin","Brian Epstein","Phil Spector","Geoff Emerick"],
  ["Which TV show introduced the Beatles to a huge US audience in 1964?","The Ed Sullivan Show","American Bandstand","Shindig!","The Tonight Show"],
  ["Which 1967 Beatles album is famous as a concept album?","Sgt. Pepper's Lonely Hearts Club Band","Rubber Soul","Help!","Let It Be"],
  ["Who taught George Harrison the sitar?","Ravi Shankar","Ali Akbar Khan","Zakir Hussain","Anoushka Shankar"],
  ["What British style did the Beatles grow out of?","Skiffle","Punk","Mod jazz","Music hall"],
  ["Which band recorded '(I Can't Get No) Satisfaction'?","The Rolling Stones","The Who","The Kinks","The Animals"]]},

{ t:"The Sixties Rock Revolution", s:"Psychedelia, protest, and festivals",
  sec:[
  ["Folk rock and the Beach Boys",[
    "After Dylan went electric, the Byrds' jangling 12-string version of his 'Mr. Tambourine Man' (1965) defined folk rock. Simon & Garfunkel ('The Sound of Silence'), the Mamas & the Papas, and Buffalo Springfield followed.",
    "In California, the Beach Boys, led by composer and producer Brian Wilson, moved from surf songs to the sophisticated Pet Sounds (1966) and the single 'Good Vibrations,' with complex harmonies, unusual instruments, and studio innovation that inspired the Beatles' Sgt. Pepper."]],
  ["Psychedelic rock",[
    "Psychedelic rock, linked to the counterculture and hallucinogenic drugs, used long improvisations, distorted guitars, studio effects, Indian influences, and surreal lyrics. San Francisco's Haight-Ashbury scene produced Jefferson Airplane ('White Rabbit'), the Grateful Dead, famous for improvised live shows and devoted 'Deadhead' fans, and Janis Joplin with Big Brother and the Holding Company.",
    "The Doors, led by Jim Morrison, brought darker poetry from Los Angeles. In London, Pink Floyd, with Syd Barrett, and Cream, with Eric Clapton, explored psychedelia and extended blues jams."]],
  ["Jimi Hendrix",[
    "Jimi Hendrix (1942–1970), an American guitarist who found fame in London, revolutionized the electric guitar. He used feedback, distortion, the wah-wah pedal, and the whammy bar as expressive tools, played left-handed on a flipped right-handed Stratocaster, and fused blues, rock, and psychedelia in 'Purple Haze,' 'Voodoo Child (Slight Return),' and 'Little Wing.'",
    "His searing, distorted version of 'The Star-Spangled Banner' at Woodstock in 1969, evoking bombs and sirens, became an emblem of the Vietnam era. He died at 27."]],
  ["Festivals and protest",[
    "The Monterey Pop Festival (1967) introduced Hendrix, Janis Joplin, Otis Redding, and Ravi Shankar to American audiences. Woodstock (August 1969), in upstate New York, drew about 400,000 people for three days of music and became the symbol of a generation; months later, the violent Altamont Free Concert seemed to mark the end of the decade's idealism.",
    "Rock and folk were bound up with protest against the Vietnam War and support for civil rights: songs such as Country Joe McDonald's 'I-Feel-Like-I'm-Fixin'-to-Die Rag,' Creedence Clearwater Revival's 'Fortunate Son,' and Buffalo Springfield's 'For What It's Worth.'"]],
  ["The rise of the album and rock criticism",[
    "Rock became 'serious' art in the late 1960s. Rolling Stone magazine, founded in 1967, and other publications created rock criticism. FM radio stations played whole album sides, and artists gained more creative control.",
    "Musically, rock expanded to include hard rock, blues rock, country rock, and early progressive rock, setting the stage for the many genres of the 1970s."]]
  ],
  terms:[["Folk rock","Folk songs played with electric rock instruments."],["Psychedelic rock","Experimental rock linked to the 1960s counterculture."],["Feedback","Sound looping from amplifier to guitar pickup."],["Woodstock","1969 festival symbolizing the counterculture."],["Counterculture","1960s youth movement rejecting mainstream values."]],
  w:"The late 1960s made rock a vehicle for art, protest, and experiment, and created the festival culture still alive today.",
  src:["Psychedelic rock","Jimi Hendrix","Woodstock","Pet Sounds","Folk rock"],
  q:[
  ["Which Beach Boys album (1966) inspired Sgt. Pepper?","Pet Sounds","Surfin' Safari","Smile","Holland"],
  ["Which guitarist played 'The Star-Spangled Banner' at Woodstock?","Jimi Hendrix","Eric Clapton","Carlos Santana","Jerry Garcia"],
  ["Which band's 'Mr. Tambourine Man' defined folk rock?","The Byrds","The Mamas & the Papas","Simon & Garfunkel","Buffalo Springfield"],
  ["About how many people attended Woodstock?","About 400,000","About 40,000","About 4 million","About 100,000"],
  ["Which San Francisco band was famous for long improvised concerts and devoted fans?","The Grateful Dead","The Doors","Cream","The Byrds"],
  ["Which 1967 festival introduced Hendrix and Joplin to US audiences?","Monterey Pop","Woodstock","Altamont","Isle of Wight"]]},

{ t:"Seventies Rock", s:"Hard rock, prog, and the singer-songwriter",
  sec:[
  ["Hard rock and heavy metal",[
    "Hard rock emphasized loud distorted guitars, powerful riffs, and strong vocals. Led Zeppelin (Jimmy Page, Robert Plant, John Paul Jones, John Bonham) combined blues, folk, and Middle Eastern influences with immense power on 'Whole Lotta Love,' 'Kashmir,' and 'Stairway to Heaven' (1971). Deep Purple ('Smoke on the Water') and the Who were also giants.",
    "Black Sabbath from Birmingham, England, with Tony Iommi's dark, heavy riffs and Ozzy Osbourne's vocals, created heavy metal on their 1970 debut. Later metal styles included the New Wave of British Heavy Metal (Iron Maiden, Judas Priest), thrash (Metallica, Slayer), and many more."]],
  ["Progressive rock",[
    "Progressive rock ('prog') borrowed from classical music and jazz: long, multi-section compositions, complex time signatures, virtuosity, and synthesizers. Pink Floyd's The Dark Side of the Moon (1973), which spent over 900 weeks on the Billboard 200 album chart, explored madness, time, and money; Wish You Were Here and The Wall followed.",
    "Yes, Genesis (with Peter Gabriel), King Crimson, Emerson, Lake & Palmer, and Rush were other leading prog bands. Queen, with Freddie Mercury's operatic range, merged hard rock, prog, and opera in 'Bohemian Rhapsody' (1975)."]],
  ["Glam and arena rock",[
    "Glam rock featured theatrical costumes, makeup, and androgyny. David Bowie (1947–2016) created the alien rock star Ziggy Stardust (1972) and kept reinventing himself through soul, electronic Berlin albums, and pop. T. Rex, Roxy Music, and Elton John were also glam stars.",
    "Arena rock bands filled stadiums: the Eagles (Hotel California, and the best-selling album in US history, Their Greatest Hits 1971–1975), Fleetwood Mac (Rumours, 1977), Aerosmith, Kiss, Bruce Springsteen ('Born to Run'), and Boston."]],
  ["Southern rock and reggae influence",[
    "The Allman Brothers Band and Lynyrd Skynyrd ('Sweet Home Alabama,' 'Free Bird') developed Southern rock, mixing blues, country, and long guitar jams.",
    "Meanwhile, Jamaican reggae spread internationally through Bob Marley and Eric Clapton's 1974 cover of Marley's 'I Shot the Sheriff,' influencing punk and new wave bands later in the decade."]],
  ["Punk rock",[
    "By the mid-1970s, punk rebelled against the excess and virtuosity of prog and arena rock with short, fast, loud songs, simple chords, and do-it-yourself ethics. In New York, the Ramones (debut 1976), along with Patti Smith, Television, Blondie, and Talking Heads, played at the club CBGB.",
    "In London, the Sex Pistols, managed by Malcolm McLaren, provoked scandal with 'Anarchy in the U.K.' and 'God Save the Queen' (1977). The Clash combined punk with reggae and politics on London Calling (1979). Punk's attitude, 'anyone can form a band,' inspired independent labels and fanzines."]],
  ["Post-punk and new wave",[
    "After punk, post-punk bands experimented with darker atmospheres, dance rhythms, and art: Joy Division, the Cure, Siouxsie and the Banshees, Gang of Four, and Talking Heads. New wave, a more commercial offshoot, used synthesizers and catchy hooks: Blondie, the Police, Elvis Costello, the Cars, and Devo.",
    "These genres led into the alternative rock and synth-pop of the 1980s."]]
  ],
  terms:[["Heavy metal","Loud, distorted, riff-based style born around 1970."],["Progressive rock","Rock with complex, classical-influenced structures."],["Glam rock","Theatrical, androgynous 1970s rock."],["Punk","Fast, raw, DIY rock rebellion of the mid-1970s."],["Post-punk","Experimental, darker music after punk."]],
  w:"The 1970s split rock into enduring branches, metal, prog, punk, and arena rock, that shape music today.",
  src:["Led Zeppelin","Black Sabbath","Progressive rock","The Dark Side of the Moon","Punk rock"],
  q:[
  ["Which band is credited with creating heavy metal on its 1970 debut?","Black Sabbath","Led Zeppelin","Deep Purple","Judas Priest"],
  ["Which Pink Floyd album spent over 900 weeks on the Billboard 200?","The Dark Side of the Moon","The Wall","Wish You Were Here","Animals"],
  ["Which band played 'Bohemian Rhapsody'?","Queen","Genesis","Yes","Electric Light Orchestra"],
  ["David Bowie's 1972 alien rock star persona was called what?","Ziggy Stardust","Major Tom","Aladdin Sane","The Thin White Duke"],
  ["Which New York club was the center of early punk?","CBGB","The Fillmore","Studio 54","The Cavern Club"],
  ["Which band released 'God Save the Queen' in 1977?","Sex Pistols","The Clash","The Damned","The Ramones"]]},

{ t:"Disco, Funk, and Reggae", s:"Dance floors and island rhythms",
  sec:[
  ["Funk",[
    "Funk, rooted in James Brown, emphasized interlocking rhythm, syncopated bass lines, and the downbeat ('the one'). Sly and the Family Stone, an integrated, mixed-gender band, blended funk, soul, and psychedelia in 'Everyday People' and 'Thank You (Falettinme Be Mice Elf Agin),' where Larry Graham popularized slap bass.",
    "George Clinton's Parliament-Funkadelic ('P-Funk') built a science-fiction mythology with the Mothership and a cosmic, deep groove. Earth, Wind & Fire, Kool & the Gang, the Ohio Players, and Chaka Khan with Rufus also defined the era. Prince later fused funk, rock, and pop."]],
  ["Disco",[
    "Disco emerged in the early 1970s in New York nightclubs frequented by Black, Latino, and gay communities, where DJs played continuous dance music. It featured a steady four-on-the-floor bass drum (every beat), offbeat hi-hats, orchestral strings, and soaring vocals at around 120 beats per minute.",
    "Hits included Gloria Gaynor's 'I Will Survive,' Donna Summer's 'I Feel Love' (1977), produced by Giorgio Moroder with an all-synthesizer backing that foreshadowed electronic dance music, Chic's 'Le Freak,' and the Bee Gees' songs for the film Saturday Night Fever (1977), whose soundtrack became one of the best-selling albums ever. Studio 54 became a celebrity disco palace."]],
  ["The backlash",[
    "Disco's commercial dominance triggered a backlash. At 'Disco Demolition Night' at Chicago's Comiskey Park in July 1979, disco records were blown up, causing a riot. Critics have noted that the hostility had overtones of racism and homophobia.",
    "Disco declined commercially, but its sounds continued in dance-pop, house music (born in Chicago), and the 12-inch remix, whose extended versions were invented for club DJs."]],
  ["Jamaican music",[
    "Jamaica, with under three million people, has had an outsized influence on world music. In the late 1950s and early 1960s, ska, with an upbeat, offbeat guitar 'skank' and horns, mixed mento (Jamaican folk), R&B, and jazz. In the mid-1960s it slowed into rocksteady, then reggae around 1968, with a heavy bass, a 'one drop' drum beat accenting the third beat, and offbeat chords.",
    "Sound systems, mobile DJ setups with huge speakers, were central to Jamaican culture. Producers such as King Tubby and Lee 'Scratch' Perry created dub, remixing tracks with echo, reverb, and dropped-out instruments, and DJs 'toasted' (chanted) over records, a direct ancestor of rapping."]],
  ["Bob Marley",[
    "Bob Marley (1945–1981) with the Wailers (including Peter Tosh and Bunny Wailer) became the first global superstar from the developing world. Albums such as Catch a Fire (1973), Exodus (1977), and songs like 'No Woman, No Cry,' 'Get Up, Stand Up,' 'One Love,' and 'Redemption Song' spread reggae and messages of Rastafari, Pan-African unity, and resistance to oppression.",
    "In 1978 at the One Love Peace Concert he brought together rival Jamaican political leaders on stage. He died of cancer at 36. Later Jamaican styles include dancehall (Shabba Ranks, Sean Paul) with digital rhythms called riddims."]]
  ],
  terms:[["Four-on-the-floor","Bass drum on every beat."],["Slap bass","Percussive bass technique popularized by Larry Graham."],["Ska","Jamaican offbeat style of the early 1960s."],["Dub","Remix style using echo, reverb, and dropouts."],["Sound system","Jamaican mobile DJ setup."]],
  w:"Funk, disco, and Jamaican sound systems laid the groundwork for hip-hop, house, and modern dance music.",
  src:["Funk","Disco","Reggae","Bob Marley","Dub music"],
  q:[
  ["What is 'four-on-the-floor'?","Bass drum on every beat","Four guitars playing at once","A dance step","A 4/4 time signature with no drums"],
  ["Who produced Donna Summer's synth-driven 'I Feel Love'?","Giorgio Moroder","Nile Rodgers","Quincy Jones","Barry Gibb"],
  ["What is dub?","Remixed reggae with heavy echo and reverb","A fast ska style","Jamaican folk music","A type of guitar strum"],
  ["Which bassist popularized slap bass with Sly and the Family Stone?","Larry Graham","Bootsy Collins","Jaco Pastorius","James Jamerson"],
  ["Which 1977 film soundtrack featured the Bee Gees?","Saturday Night Fever","Grease","Thank God It's Friday","Fame"],
  ["Which Jamaican style came first?","Ska","Reggae","Dancehall","Rocksteady"]]},

{ t:"Hip-Hop: Origins", s:"The Bronx, breaks, and the MC",
  sec:[
  ["The Bronx in the 1970s",[
    "Hip-hop was born in the South Bronx, New York, in the 1970s, a neighborhood devastated by poverty, arson, and urban neglect. Young Black and Latino residents created a culture with four traditional elements: DJing, MCing (rapping), breaking (breakdancing), and graffiti art; a fifth, 'knowledge,' is often added.",
    "On 11 August 1973, DJ Kool Herc (Clive Campbell), a Jamaican-born DJ, played a back-to-school party at 1520 Sedgwick Avenue, an event often cited as hip-hop's birthday. He brought the Jamaican sound-system tradition to the Bronx."]],
  ["The break",[
    "Kool Herc noticed dancers went wild during the 'break,' the instrumental percussion section of funk and soul records. Using two turntables with two copies of the same record, he extended the break by switching between them, a technique called the 'merry-go-round.' Dancers who performed during these breaks became 'b-boys' and 'b-girls.'",
    "Grandmaster Flash refined the technique of seamless mixing and invented key DJ practices; Grand Wizzard Theodore is credited with inventing scratching, moving a record back and forth under the needle. Afrika Bambaataa founded the Universal Zulu Nation, promoting peace and unity among former gang members, and released 'Planet Rock' (1982), which used Kraftwerk's electronic sounds and the TR-808."]],
  ["Rapping",[
    "The MC (master of ceremonies) began as a party host hyping the crowd over the DJ's beats, drawing on Jamaican toasting, African American traditions of the dozens, signifying, preaching, jazz poetry, and the spoken-word politics of the Last Poets and Gil Scott-Heron.",
    "The Sugarhill Gang's 'Rapper's Delight' (1979) was the first rap single to become a mainstream hit. Grandmaster Flash and the Furious Five's 'The Message' (1982), describing ghetto life ('Don't push me 'cause I'm close to the edge'), showed rap could be serious social commentary."]],
  ["Rap's foundations",[
    "Rap is built on flow (the rhythm and delivery of words over the beat), rhyme schemes including internal and multisyllabic rhymes, wordplay, storytelling, and persona. Beats were initially made from looped breaks; later, drum machines and samplers became the producer's tools.",
    "Run-DMC from Queens brought a harder, minimal sound and street style in the mid-1980s; their 1986 collaboration with Aerosmith on 'Walk This Way' crossed rap over to rock audiences. Def Jam Records, founded by Russell Simmons and Rick Rubin, launched LL Cool J and the Beastie Boys."]],
  ["The golden age",[
    "The late 1980s and early 1990s are often called hip-hop's 'golden age,' marked by innovation and variety. Public Enemy (It Takes a Nation of Millions to Hold Us Back, 1988) combined political militancy with dense sonic collage by the production team the Bomb Squad. Eric B. & Rakim set new standards of lyrical complexity.",
    "De La Soul's 3 Feet High and Rising and A Tribe Called Quest's jazz-infused albums offered playful, Afrocentric alternatives. Women MCs such as MC Lyte, Salt-N-Pepa, and Queen Latifah gained prominence. Sampling lawsuits, especially the 1991 Grand Upright v. Warner case, changed how producers used samples."]]
  ],
  terms:[["Break","Instrumental percussion section of a record."],["MC","Rapper; originally master of ceremonies."],["Scratching","Moving a record back and forth for rhythmic sound."],["Flow","Rhythm and delivery of rap lyrics."],["Sampling","Reusing pieces of existing recordings."]],
  w:"Hip-hop grew from a Bronx block party into the world's most popular musical culture.",
  src:["Hip-hop","DJ Kool Herc","Grandmaster Flash","Rapper's Delight","Golden age hip-hop"],
  q:[
  ["In which borough did hip-hop originate?","The Bronx","Brooklyn","Queens","Manhattan"],
  ["Which DJ's 1973 party is often called hip-hop's birthday?","DJ Kool Herc","Grandmaster Flash","Afrika Bambaataa","Grand Wizzard Theodore"],
  ["What was the first rap single to become a mainstream hit?","Rapper's Delight","The Message","Planet Rock","Walk This Way"],
  ["Who is credited with inventing scratching?","Grand Wizzard Theodore","DJ Kool Herc","Run-DMC","Rick Rubin"],
  ["Which group released It Takes a Nation of Millions to Hold Us Back?","Public Enemy","N.W.A","Run-DMC","De La Soul"],
  ["What are the four traditional elements of hip-hop?","DJing, MCing, breaking, graffiti","Rapping, singing, dancing, acting","Beats, rhymes, samples, scratches","Fashion, slang, rap, dance"]]}

);


/* ---- from music-16.js ---- */
/* MUSIC FOUNDATIONS, part 16: Unit 7 chapters 10-14 */
COURSES.music.units[6].ch.push(

{ t:"Hip-Hop Becomes Global", s:"From West Coast to world culture",
  sec:[
  ["Gangsta rap and the West Coast",[
    "In Los Angeles, N.W.A (Ice Cube, Dr. Dre, Eazy-E, MC Ren, DJ Yella) released Straight Outta Compton (1988), depicting street life, police brutality, and violence with blunt force, provoking controversy and FBI criticism of the song 'Fuck tha Police.' Ice-T had pioneered the style.",
    "Dr. Dre's The Chronic (1992) created G-funk, with slow, melodic synthesizer lines and P-Funk samples, and introduced Snoop Dogg. Tupac Shakur, a charismatic and conflicted artist, became one of the best-selling rappers ever."]],
  ["East Coast and the rivalry",[
    "In New York, Nas's Illmatic (1994), the Wu-Tang Clan's Enter the Wu-Tang (36 Chambers) (1993), and the Notorious B.I.G.'s Ready to Die (1994), on Sean 'Puffy' Combs's Bad Boy label, defined East Coast hip-hop. A media-fueled rivalry between Bad Boy and Death Row Records (Tupac's label) ended tragically with the unsolved murders of Tupac (1996) and Biggie (1997).",
    "These deaths prompted calls for peace within hip-hop."]],
  ["Mainstream dominance",[
    "From the late 1990s, hip-hop became a dominant force in American popular music. Jay-Z built a business empire; Lauryn Hill's The Miseducation of Lauryn Hill (1998) won the Grammy for Album of the Year, the first hip-hop album to do so; Missy Elliott and producer Timbaland created futuristic sounds; OutKast brought Atlanta's Southern hip-hop to the fore.",
    "Eminem, a white rapper from Detroit mentored by Dr. Dre, became one of the best-selling artists of the 2000s. Kanye West's productions and albums, from The College Dropout (2004) to My Beautiful Dark Twisted Fantasy (2010), pushed hip-hop's artistic boundaries."]],
  ["The 2010s and beyond",[
    "In 2017, hip-hop/R&B became the most consumed genre in the United States, according to Nielsen. Atlanta trap music, with booming 808 bass, rapid hi-hat rolls, and dark synths (T.I., Gucci Mane, Future, Migos), became the dominant sound. Drake blended rap and singing into massive streaming success.",
    "Kendrick Lamar's To Pimp a Butterfly (2015) fused jazz and funk with commentary on race; his album DAMN. won the 2018 Pulitzer Prize for Music, the first non-classical, non-jazz work to win. Cardi B, Nicki Minaj, Megan Thee Stallion, and Doechii are prominent women MCs."]],
  ["Hip-hop worldwide",[
    "Hip-hop is now global. France has one of the largest rap markets in the world (IAM, MC Solaar, PNL); the UK developed grime (Dizzee Rascal, Skepta, Stormzy) and UK drill; Brazil's funk carioca, Nigeria's and Ghana's rap scenes, Korea's hip-hop and K-pop rap lines, India's 'gully rap,' and Arabic rap during the Arab Spring all adapted hip-hop to local languages and issues.",
    "In 2023 hip-hop celebrated its 50th anniversary, and breaking appeared as an Olympic sport at the 2024 Paris Games."]]
  ],
  terms:[["Gangsta rap","Rap depicting street life and violence."],["G-funk","Melodic West Coast style built on P-Funk samples."],["Trap","Southern rap style with 808 bass and fast hi-hats."],["Grime","UK electronic rap style from London."],["Producer","Person who creates beats and shapes a recording."]],
  w:"Hip-hop became the dominant popular music of the 21st century and a global voice for local stories.",
  src:["Gangsta rap","East Coast–West Coast hip-hop rivalry","Kendrick Lamar","Trap music","The Miseducation of Lauryn Hill"],
  q:[
  ["Which album won the Grammy for Album of the Year as the first hip-hop album to do so?","The Miseducation of Lauryn Hill","Illmatic","The Chronic","Speakerboxxx/The Love Below"],
  ["Which rapper's album DAMN. won the Pulitzer Prize for Music?","Kendrick Lamar","Jay-Z","Kanye West","Drake"],
  ["Which producer created G-funk on The Chronic?","Dr. Dre","Timbaland","Kanye West","DJ Premier"],
  ["Which Southern style features 808 bass and rapid hi-hat rolls?","Trap","G-funk","Boom bap","Crunk only"],
  ["Grime developed in which city?","London","Paris","Lagos","Toronto"],
  ["At which Olympics did breaking debut?","Paris 2024","Tokyo 2020","Los Angeles 2028","Rio 2016"]]},

{ t:"The MTV Era", s:"Pop stars of the 1980s",
  sec:[
  ["Video killed the radio star",[
    "MTV (Music Television) launched on 1 August 1981, appropriately opening with the Buggles' 'Video Killed the Radio Star.' Music videos became essential to promotion, and image, choreography, and fashion became as important as sound. Early on MTV rarely played Black artists, a policy challenged until Michael Jackson's videos broke through.",
    "British synth-pop and new romantic acts with stylish videos, such as Duran Duran, Culture Club, Eurythmics, Depeche Mode, and the Human League, thrived in this 'Second British Invasion.'"]],
  ["Michael Jackson",[
    "Michael Jackson (1958–2009), former child star of the Jackson 5, became the 'King of Pop.' Off the Wall (1979) and especially Thriller (1982), both produced by Quincy Jones, combined R&B, funk, rock, and pop. Thriller is widely reported as the best-selling album of all time, with seven top-ten singles including 'Billie Jean' and 'Beat It' (with a guitar solo by Eddie Van Halen).",
    "The 14-minute 'Thriller' video, directed by John Landis, and his moonwalk on the Motown 25 television special (1983) made him a global icon. His later life was overshadowed by controversy and allegations, and he died in 2009."]],
  ["Madonna and Prince",[
    "Madonna (born 1958) became the 'Queen of Pop' with dance-pop hits such as 'Like a Virgin,' 'Material Girl,' and 'Like a Prayer' (1989), constantly reinventing her image and provoking debates about sexuality, religion, and female autonomy. She is the best-selling female recording artist of all time according to Guinness World Records.",
    "Prince (1958–2016), a Minneapolis multi-instrumentalist, producer, and songwriter, blended funk, rock, R&B, and pop in Purple Rain (1984) and Sign o' the Times (1987), playing most instruments on many records and famously fighting his record label for artistic control."]],
  ["Other 1980s sounds",[
    "Whitney Houston's powerful voice ('I Wanna Dance with Somebody,' and later 'I Will Always Love You') set a standard for pop singing. Bruce Springsteen's Born in the U.S.A. (1984), U2's The Joshua Tree (1987), Bon Jovi, and Def Leppard's 'hair metal' filled arenas. Cyndi Lauper, Tina Turner's comeback, Janet Jackson's Rhythm Nation, and George Michael also defined the decade.",
    "Benefit concerts and songs, Band Aid's 'Do They Know It's Christmas?' (1984), USA for Africa's 'We Are the World' (1985), and Live Aid (1985), organized by Bob Geldof and Midge Ure for Ethiopian famine relief and watched by an estimated 1.5 billion people, showed pop's global reach."]],
  ["Technology of 1980s pop",[
    "Digital synthesizers such as the Yamaha DX7 (1983), drum machines like the LinnDrum and TR-808, gated reverb on drums (as on Phil Collins's 'In the Air Tonight'), and samplers like the Fairlight CMI gave 1980s pop its distinctive sound.",
    "The compact disc, introduced in 1982, became the dominant format by the end of the decade, boosting industry revenues as fans replaced their vinyl collections."]],
  ["Underground and alternative",[
    "Beneath the mainstream, college radio and independent labels nurtured alternative rock: R.E.M., the Smiths, the Cure, Sonic Youth, the Pixies, and Hüsker Dü. Hardcore punk (Black Flag, Minor Threat) built a DIY network of venues and labels.",
    "These scenes set the stage for the 1990s alternative explosion."]]
  ],
  terms:[["MTV","Music video channel launched in 1981."],["Synth-pop","Pop built on synthesizers."],["Gated reverb","Drum effect with reverb cut off abruptly."],["Live Aid","1985 global benefit concert."],["Alternative rock","Independent, non-mainstream rock."]],
  w:"In the 1980s pop became a visual medium, and its biggest stars set standards still followed today.",
  src:["MTV","Michael Jackson","Thriller (album)","Madonna","Live Aid"],
  q:[
  ["Which video was the first played on MTV in 1981?","Video Killed the Radio Star","Thriller","Billie Jean","Money for Nothing"],
  ["Who produced Michael Jackson's Thriller?","Quincy Jones","Nile Rodgers","Babyface","Prince"],
  ["Which Prince album (1984) was also a film?","Purple Rain","1999","Sign o' the Times","Parade"],
  ["Who organized Live Aid?","Bob Geldof and Midge Ure","Bono and Sting","Quincy Jones","Michael Jackson"],
  ["Which digital synthesizer of 1983 defined many 1980s sounds?","Yamaha DX7","Minimoog","Roland TR-909","Mellotron"],
  ["Who is called the 'Queen of Pop'?","Madonna","Whitney Houston","Janet Jackson","Cyndi Lauper"]]},

{ t:"The Nineties", s:"Grunge, Britpop, and R&B",
  sec:[
  ["Grunge",[
    "In Seattle, independent label Sub Pop nurtured grunge, combining punk's rawness with heavy metal's weight and dark, introspective lyrics. Nirvana's 'Smells Like Teen Spirit' from Nevermind (1991) unexpectedly knocked Michael Jackson's Dangerous off the top of the Billboard album chart in January 1992, signaling a generational shift.",
    "Pearl Jam, Soundgarden, and Alice in Chains followed. Nirvana's singer Kurt Cobain, uneasy with fame, died in 1994. Grunge's success brought alternative rock into the mainstream."]],
  ["Alternative nation",[
    "The 1990s alternative boom included Radiohead (OK Computer, 1997, a landmark album about technology and alienation), Red Hot Chili Peppers, Smashing Pumpkins, Beck, Green Day's pop-punk Dookie (1994), Rage Against the Machine's rap-metal, Alanis Morissette's Jagged Little Pill, and Lollapalooza, the touring alternative festival founded in 1991.",
    "Women artists such as PJ Harvey, Björk, Tori Amos, Sheryl Crow, and the Lilith Fair tour (1997–99) brought new voices to the forefront."]],
  ["Britpop",[
    "In the UK, Britpop celebrated British guitar pop heritage of the Beatles, the Kinks, and the Smiths. A media-hyped 'Battle of Britpop' in 1995 pitted Oasis (Definitely Maybe; (What's the Story) Morning Glory? with 'Wonderwall') against Blur, whose 'Country House' outsold Oasis's 'Roll with It' in the singles chart. Pulp and Suede were also leaders.",
    "Britpop was linked to the 'Cool Britannia' cultural moment of the mid-1990s."]],
  ["R&B and pop",[
    "Contemporary R&B dominated the charts: Mariah Carey, with her five-octave range and record-setting number-one singles, Whitney Houston, Boyz II Men, TLC, Destiny's Child (launching Beyoncé), Usher, and Janet Jackson. New jack swing, pioneered by producer Teddy Riley, fused R&B and hip-hop. Neo-soul artists such as D'Angelo, Erykah Badu, and Lauryn Hill revived classic soul.",
    "Late in the decade, teen pop surged: the Backstreet Boys, *NSYNC, Britney Spears ('...Baby One More Time,' 1998), and Christina Aguilera, many produced by Swedish hitmakers such as Max Martin. The Spice Girls led 'Girl Power' and became the best-selling girl group of all time."]],
  ["Latin pop and global hits",[
    "The late 1990s 'Latin explosion' brought Ricky Martin ('Livin' la Vida Loca,' 1999), Jennifer Lopez, Enrique Iglesias, Marc Anthony, and Shakira to global audiences. Tejano star Selena, murdered in 1995, became a lasting icon.",
    "Céline Dion's 'My Heart Will Go On' (1997), from Titanic, became one of the best-selling singles ever."]]
  ],
  terms:[["Grunge","Seattle style mixing punk and metal."],["Britpop","Mid-1990s British guitar pop."],["New jack swing","Fusion of R&B and hip-hop."],["Neo-soul","Revival of classic soul in the 1990s."],["Teen pop","Pop marketed to young teenagers."]],
  w:"The 1990s fractured pop into alternative, R&B, hip-hop, and teen pop, the genre map that still shapes playlists.",
  src:["Grunge","Nirvana (band)","Britpop","OK Computer","Contemporary R&B"],
  q:[
  ["Which Nirvana album contains 'Smells Like Teen Spirit'?","Nevermind","In Utero","Bleach","Ten"],
  ["Which city was the center of grunge?","Seattle","Portland","Los Angeles","Minneapolis"],
  ["Which two bands were pitted in the 'Battle of Britpop'?","Oasis and Blur","Pulp and Suede","Radiohead and Coldplay","The Verve and Oasis"],
  ["Which Radiohead album (1997) is a landmark of the decade?","OK Computer","The Bends","Kid A","Pablo Honey"],
  ["Which Swedish producer shaped teen pop hits for Britney Spears?","Max Martin","Denniz Pop","Teddy Riley","Timbaland"],
  ["Which group launched Beyoncé's career?","Destiny's Child","TLC","En Vogue","SWV"]]},

{ t:"Electronic Dance Music", s:"House, techno, and the rave",
  sec:[
  ["Electronic pioneers",[
    "Germany's Kraftwerk, formed in Düsseldorf in 1970, created entirely electronic pop with robotic themes in Autobahn (1974), Trans-Europe Express, and The Man-Machine. Their influence on hip-hop, synth-pop, and techno is enormous. Japan's Yellow Magic Orchestra and Giorgio Moroder's disco productions were also key.",
    "Jean-Michel Jarre's Oxygène (1976) and ambient music, a term coined by Brian Eno with Ambient 1: Music for Airports (1978), explored electronic atmosphere."]],
  ["House",[
    "House music emerged in Chicago in the early 1980s, named after the Warehouse club where DJ Frankie Knuckles played. DJs and producers combined disco's four-on-the-floor rhythm with drum machines (TR-808, TR-909), synthesizers, and soulful vocals. Early tracks include Jesse Saunders's 'On and On' (1984) and Marshall Jefferson's 'Move Your Body.'",
    "Acid house, from the squelching sound of the Roland TB-303 bass synthesizer, emerged around 1987 with Phuture's 'Acid Tracks.' Chicago's Black and gay club scenes were at its heart."]],
  ["Techno",[
    "Techno developed in Detroit in the mid-1980s, created by the 'Belleville Three': Juan Atkins, Derrick May, and Kevin Saunderson, high school friends who combined Kraftwerk's machine sound with funk and futurism in post-industrial Detroit. Derrick May described it as being 'like George Clinton and Kraftwerk stuck in an elevator.'",
    "Berlin embraced techno after the fall of the Berlin Wall in 1989, with clubs such as Tresor and later Berghain, and the Love Parade."]],
  ["Rave culture and genres",[
    "In Britain, the 'Second Summer of Love' (1988–89) saw huge illegal raves in fields and warehouses, inspired by Ibiza's club scene. The UK produced many new genres: jungle and drum and bass (fast breakbeats with deep bass, Goldie, Roni Size), UK garage, trip-hop (Massive Attack, Portishead), and big beat (The Prodigy, The Chemical Brothers, Fatboy Slim). Dubstep emerged in south London in the early 2000s.",
    "France's Daft Punk ('One More Time,' 2000) and its 'French touch' filter house, and electronic artists such as Aphex Twin, Björk, and Moby, crossed into the mainstream."]],
  ["EDM goes mainstream",[
    "In the 2000s and 2010s, 'EDM' became a commercial phenomenon in America, with DJs such as David Guetta, Tiësto, Swedish House Mafia, Avicii ('Levels,' 2011), Calvin Harris, Skrillex (brostep), and Deadmau5 headlining festivals like Tomorrowland in Belgium, Ultra in Miami, and Electric Daisy Carnival in Las Vegas.",
    "Today superstar DJs are among the highest-paid musicians, and electronic production techniques underpin almost all pop music."]],
  ["How DJs work",[
    "DJs mix records by beatmatching: adjusting tempo so two tracks' beats align, then blending them with a mixer using volume faders and equalizers. Tracks are measured in beats per minute (BPM): house around 120–128, techno 125–140, drum and bass around 170.",
    "Dance tracks follow structures of build-ups, drops (the moment the full beat returns after tension), and breakdowns, designed for the dance floor. Modern DJs use turntables, CDJs, or controllers with software."]]
  ],
  terms:[["House","Chicago dance music with four-on-the-floor beat."],["Techno","Detroit electronic dance music of the mid-1980s."],["Beatmatching","Aligning tempos of two tracks."],["BPM","Beats per minute, the measure of tempo."],["Drop","Moment the full beat returns after a build-up."]],
  w:"Electronic dance music reshaped pop production and created a global club and festival culture.",
  src:["Electronic dance music","House music","Techno","Kraftwerk","Rave"],
  q:[
  ["House music is named after which Chicago club?","The Warehouse","The Music Box","Paradise Garage","The Loft"],
  ["Which city is the birthplace of techno?","Detroit","Chicago","Berlin","Manchester"],
  ["Which German group pioneered fully electronic pop in the 1970s?","Kraftwerk","Tangerine Dream","Can","Neu!"],
  ["Who coined the term 'ambient music'?","Brian Eno","Jean-Michel Jarre","Aphex Twin","Moby"],
  ["What tempo is typical of drum and bass?","Around 170 BPM","Around 90 BPM","Around 120 BPM","Around 60 BPM"],
  ["Which Roland bass synthesizer created the 'acid' sound?","TB-303","TR-808","Juno-60","SH-101"]]},

{ t:"Pop in the Streaming Age", s:"The 2000s to now",
  sec:[
  ["The 2000s",[
    "The early 2000s saw pop stars such as Britney Spears, Justin Timberlake, Christina Aguilera, and Beyoncé, whose solo career began with 'Crazy in Love' (2003). Reality TV competitions, especially Pop Idol (UK, 2001) and American Idol (2002), launched Kelly Clarkson and Carrie Underwood. Amy Winehouse's Back to Black (2006) revived retro soul, and Adele's 21 (2011) became one of the best-selling albums of the century.",
    "Indie rock and garage-rock revival bands such as the Strokes, the White Stripes, Arcade Fire, and Arctic Monkeys (the latter boosted by early internet buzz) thrived."]],
  ["Pop goes digital",[
    "Digital production, Auto-Tune, and collaborations across genres blurred boundaries between pop, hip-hop, R&B, and EDM. Lady Gaga's theatrical The Fame (2008), Rihanna, Katy Perry, Bruno Mars, and Justin Bieber, discovered on YouTube, became stars.",
    "Taylor Swift moved from country to pop with 1989 (2014), and her re-recordings of earlier albums (from 2021), done to own her masters, changed industry conversations about artists' rights. Her Eras Tour (2023–24) became the highest-grossing concert tour of all time."]],
  ["Streaming and the shape of songs",[
    "Since streaming pays per play (counted after 30 seconds on Spotify), songs have tended to get shorter, introductions have shrunk, and hooks arrive sooner. Albums are sometimes loaded with many tracks to boost stream counts. Playlists curated by algorithms and editors are major discovery channels.",
    "TikTok has become a hit machine since around 2019: short, catchy clips go viral, reviving old songs (Fleetwood Mac's 'Dreams,' Kate Bush's 'Running Up That Hill,' helped by Stranger Things) and launching new artists. Lil Nas X's 'Old Town Road' spent a record 19 weeks at number one in 2019."]],
  ["Global pop",[
    "Streaming made pop more global. Luis Fonsi and Daddy Yankee's 'Despacito' (2017) became one of the most-streamed songs ever; Bad Bunny became Spotify's most-streamed artist worldwide in 2020, 2021, and 2022, singing almost entirely in Spanish. Reggaeton, with its dembow rhythm from Puerto Rico and Panama, became a global sound.",
    "K-pop groups such as BTS and BLACKPINK, and Afrobeats artists such as Burna Boy, Wizkid, and Tems, achieved worldwide success."]],
  ["Today's landscape",[
    "Artists such as Billie Eilish (whose bedroom-produced debut with her brother Finneas won major Grammys), Olivia Rodrigo, Dua Lipa, Harry Styles, The Weeknd ('Blinding Lights' became one of Billboard's biggest Hot 100 hits ever), SZA, Sabrina Carpenter, and Chappell Roan illustrate a genre-fluid era.",
    "Vinyl records have made a comeback, outselling CDs in the US in recent years. Artificial intelligence is now a pressing issue, as AI tools can generate music and imitate voices, raising questions about copyright, consent, and creativity."]],
  ["How hits are made",[
    "Modern pop songs are often co-written by teams in writing camps, with 'topliners' writing melodies and lyrics over producers' tracks. Swedish producers such as Max Martin, who has written or co-written more Billboard number ones than anyone except Paul McCartney and John Lennon, shaped a 'melodic math' approach of tight structure and repeated hooks.",
    "Common pop structures: intro, verse, pre-chorus, chorus, verse, pre-chorus, chorus, bridge, final chorus. The pre-chorus builds tension; the 'drop' or post-chorus adds an instrumental or chant hook."]]
  ],
  terms:[["Streaming","Listening to music on demand over the internet."],["Topliner","Writer of melody and lyrics over a producer's track."],["Reggaeton","Latin genre built on the dembow rhythm."],["Masters","Original recordings, owned by labels or artists."],["Viral hit","Song spreading quickly through social media."]],
  w:"Streaming and social media have changed how songs are written, discovered, and shared around the world.",
  src:["Pop music","Taylor Swift","Despacito","Max Martin","TikTok"],
  q:[
  ["Which song spent a record 19 weeks at number one in 2019?","Old Town Road","Despacito","Blinding Lights","Uptown Funk"],
  ["Why did Taylor Swift re-record her earlier albums?","To own her master recordings","To change the lyrics","Because the originals were lost","To switch genres"],
  ["Which artist was Spotify's most-streamed globally in 2020–2022?","Bad Bunny","Drake","Taylor Swift","The Weeknd"],
  ["Which rhythm underlies reggaeton?","Dembow","Clave","Bossa nova","One drop"],
  ["Which producer has written more US number ones than anyone but Lennon and McCartney?","Max Martin","Dr. Luke","Timbaland","Pharrell Williams"],
  ["What is a topliner?","A writer of melody and lyrics over a producer's track","A headline act","A chart-topping single","A backing singer"]]}

);


/* ---- from music-17.js ---- */
/* MUSIC FOUNDATIONS, part 17: Unit 8 Music of the World, chapters 1-4 */
COURSES.music.units.push({ t:"Music of the World", ch:[

{ t:"Thinking About World Music", s:"Many musics, not one",
  sec:[
  ["A problematic label",[
    "'World music' became a record-store and marketing category in the late 1980s, coined in 1987 by a group of British record labels to sell music from outside the Anglo-American mainstream. The label is criticized for lumping together thousands of very different traditions, from Mongolian throat singing to Congolese rumba, and for treating Western music as the default.",
    "A better approach is to recognize that every culture has its own music, with its own history, theory, instruments, and values. Ethnomusicology, the study of music in its cultural context, developed in the 20th century to understand these traditions on their own terms."]],
  ["Universal and particular",[
    "Studies of recordings from many societies, such as a 2019 study published in Science that analyzed music from 315 societies, suggest some near-universals: music everywhere is used for dancing, healing, love, and soothing infants, and lullabies and dance songs share recognizable features across cultures. Most cultures use scales with a small number of discrete pitches, often five to seven, and organize rhythm around a regular beat.",
    "Yet much differs: tuning systems (including microtones), the role of improvisation, the relation between music and words, whether music is meant for performance or participation, and the meaning of sound itself."]],
  ["Classical, folk, and popular",[
    "Many societies have classical traditions with formal theory, training, and patronage, such as Indian, Persian, Arabic, Chinese, Japanese, Javanese, and European art music. Folk traditions are passed orally within communities, often tied to daily life, festivals, and identity. Popular music is commercially produced and spread through media.",
    "These categories blur: much of today's popular music worldwide fuses local folk styles with global pop, hip-hop, and electronic sounds."]],
  ["Oral tradition and transmission",[
    "Most of the world's music has been transmitted orally, learned by listening and imitating a teacher, often over many years. In India, the guru–shishya (teacher–student) relationship is central; in West Africa, griots learn epic songs within hereditary families.",
    "Notation, where used, is often a memory aid rather than a complete score, and improvisation within established frameworks is common."]],
  ["Globalization and fusion",[
    "Since the age of recording, musics have mixed constantly. Recordings, radio, migration, colonialism, and the internet carried styles across the globe: Cuban son influenced Congolese rumba, American soul shaped Afrobeat, Indian film songs reached Nigeria and Indonesia.",
    "Projects such as Paul Simon's Graceland (1986), with South African musicians, and the Buena Vista Social Club (1997), featuring veteran Cuban musicians, brought global attention to these traditions but also raised questions about credit, exploitation, and appropriation."]],
  ["Listening across cultures",[
    "When listening to unfamiliar music, it helps to set aside expectations: the 'out of tune' notes may be precise microtones, a 'repetitive' rhythm may be an intricate cycle, and a 'long' performance may be designed for trance or ritual.",
    "Learning a bit about the context, instruments, and structure of a tradition, and listening repeatedly, opens doors to some of the richest music humans have created."]]
  ],
  terms:[["World music","Marketing label coined in 1987 for non-Western music."],["Ethnomusicology","Study of music in its cultural context."],["Oral tradition","Passing music on by ear and imitation."],["Microtone","Interval smaller than a semitone."],["Fusion","Blending of musical styles."]],
  w:"Understanding that every culture has its own musical logic is the first step to appreciating music worldwide.",
  src:["World music","Ethnomusicology","Graceland (album)","Buena Vista Social Club","Universality of music"],
  q:[
  ["When was the marketing term 'world music' coined?","1987","1955","1967","2001"],
  ["What is ethnomusicology?","The study of music in its cultural context","The study of music theory","Music therapy","The history of opera"],
  ["Which 1986 album featured South African musicians with Paul Simon?","Graceland","Rhythm of the Saints","Bridge over Troubled Water","Hearts and Bones"],
  ["Which 1997 project brought veteran Cuban musicians to global attention?","Buena Vista Social Club","Gipsy Kings","Afro-Cuban All Stars","Irakere"],
  ["Which are near-universal functions of music across cultures?","Dancing, healing, love, and soothing infants","Only religious ritual","Only entertainment","Only warfare"],
  ["What is the guru–shishya relationship?","Indian teacher–student tradition","A Japanese tuning system","An African drum pattern","A Persian poetic form"]]},

{ t:"Music of Africa", s:"Rhythm, voice, and community",
  sec:[
  ["Diversity and shared features",[
    "Africa has 54 countries and thousands of ethnic groups, with immense musical diversity. North African music is closely linked to Arab and Berber traditions; sub-Saharan Africa has its own wide range. Common features south of the Sahara include polyrhythm, call and response, the close link between music and dance, the use of ostinato, interlocking parts, and participation by everyone present.",
    "Many African languages are tonal, where pitch changes meaning, so melodies often follow speech tones, and 'talking drums' can imitate speech."]],
  ["Instruments",[
    "Drums include the djembe (Mali, Guinea), talking drum (dundun in Yoruba), and many ensembles. Melodic percussion includes the balafon (a West African xylophone with gourd resonators) and the mbira, a 'thumb piano' of metal keys on a board, central to Shona spiritual music in Zimbabwe.",
    "The kora, a 21-string harp-lute of the Mande peoples of West Africa, is played by griots; Toumani Diabaté of Mali was a famous virtuoso. Other instruments include the ngoni (lute), the masenqo (one-string fiddle) of Ethiopia, and the Ugandan amadinda xylophone."]],
  ["Griots",[
    "In West Africa, griots (jeli in the Mande languages) are hereditary musician-historians who preserve genealogies, recite epics such as the Epic of Sundiata about the founder of the 13th-century Mali Empire, praise patrons, and mediate disputes. Their art passes through families over generations.",
    "Griot families such as the Kouyatés and Diabatés produced international stars, while Salif Keita, born into a noble family descended from Sundiata, broke caste tradition by becoming a singer."]],
  ["Polyrhythm and timelines",[
    "In many West and Central African ensembles, a 'timeline,' a repeating bell pattern, often a 12-pulse pattern, organizes the music, while drums play different interlocking patterns that combine into a complex whole. No single part is 'the rhythm'; the music exists in the interaction of all the parts.",
    "Cross-rhythms, such as three against two, create a rich sense of motion. Dancers often respond to different layers with different parts of the body."]],
  ["Southern and Central Africa",[
    "Pygmy peoples of the Central African rainforest, such as the BaAka, sing complex polyphony with yodeling and hocketing (each singer contributes a few notes to a shared melody). In South Africa, choral music is powerful: isicathamiya, made famous by Ladysmith Black Mambazo, is a soft, close-harmony male choral style, and freedom songs and toyi-toyi chants were central to the anti-apartheid struggle.",
    "'Mbube' by Solomon Linda (1939) became 'The Lion Sleeps Tonight' after passing through Pete Seeger and the Tokens; Linda's family later won a settlement for royalties, an example of the issues of credit in global music."]],
  ["Ethiopia and the Horn",[
    "Ethiopia has an ancient Christian liturgical chant tradition attributed to the 6th-century Saint Yared, with its own notation, and distinctive pentatonic modes called qenet. Ethiopian popular music of the 1960s–70s 'golden age,' collected in the Éthiopiques series, mixed these modes with jazz and soul.",
    "Throughout Africa, music marks life stages, from birth and initiation to marriage and death, and plays roles in healing, spirituality, work, and politics."]]
  ],
  terms:[["Kora","21-string harp-lute of West Africa."],["Mbira","Thumb piano of metal keys, central to Shona music."],["Griot","Hereditary West African musician-historian."],["Timeline","Repeating bell pattern organizing African ensembles."],["Hocketing","Sharing a melody note-by-note among performers."]],
  w:"African music's rhythm and communal spirit are a source of much of the world's music.",
  src:["Music of Africa","Kora","Mbira","Griot","Ladysmith Black Mambazo"],
  q:[
  ["What is the kora?","A 21-string West African harp-lute","A drum","A xylophone","A flute"],
  ["What is a griot?","A hereditary West African musician-historian","A drum pattern","A type of dance","A South African choir"],
  ["Which instrument is central to Shona spiritual music in Zimbabwe?","Mbira","Kora","Djembe","Balafon"],
  ["Which group made isicathamiya famous?","Ladysmith Black Mambazo","Soweto Gospel Choir","Osibisa","Tinariwen"],
  ["Which song originated as Solomon Linda's 'Mbube'?","The Lion Sleeps Tonight","Pata Pata","Shosholoza","Wimoweh Blues"],
  ["What organizes many West African drum ensembles?","A repeating bell timeline","A conductor","A written score","A drone"]]},

{ t:"African Popular Music", s:"Highlife, Afrobeat, and Afrobeats",
  sec:[
  ["Highlife and palm-wine",[
    "In early 20th-century Ghana and Nigeria, highlife blended local rhythms and melodies with Western brass band music, church hymns, sea shanties, and later jazz and calypso. E. T. Mensah became the 'King of Highlife' in the 1950s, and highlife became the sound of independence: in 1957 Ghana became one of the first sub-Saharan African colonies to win independence.",
    "Palm-wine guitar music, played in bars, influenced guitar styles across West Africa."]],
  ["Congolese rumba and soukous",[
    "In the 1940s and 50s, records of Cuban son, themselves rooted in Central African rhythms, became popular in the Belgian Congo. Musicians adapted them into Congolese rumba, with sweet vocals and intricate, interlocking guitars. Franco Luambo and his band TPOK Jazz, Tabu Ley Rochereau, and Papa Wemba were stars; Congolese rumba was added to UNESCO's intangible heritage list in 2021.",
    "Faster dance versions, soukous and ndombolo, spread across Africa."]],
  ["Fela Kuti and Afrobeat",[
    "Fela Anikulapo Kuti (1938–1997), a Nigerian bandleader, created Afrobeat in the late 1960s and 70s by combining highlife, Yoruba music, jazz, and James Brown's funk. Afrobeat features long songs, often over ten minutes, with interlocking guitars, a large horn section, and drummer Tony Allen's revolutionary polyrhythmic grooves.",
    "Fela's lyrics, in pidgin English, attacked corruption and military rule ('Zombie,' 1976). He declared his compound the independent Kalakuta Republic; in 1977 soldiers raided and burned it, and his mother died from injuries suffered there. He was jailed several times."]],
  ["Mali, Senegal, and the desert",[
    "Mali's Ali Farka Touré blended traditional Songhai music with guitar styles that sounded remarkably like American blues, highlighting the African roots of the blues; his collaboration with Ry Cooder, Talking Timbuktu, won a Grammy in 1995. Salif Keita, Oumou Sangaré, and the blind couple Amadou & Mariam also became international stars.",
    "In Senegal, Youssou N'Dour developed mbalax, mixing Wolof sabar drumming with pop. Tuareg 'desert blues' bands such as Tinariwen, formed by exiled rebels, play electric guitar music of the Sahara."]],
  ["South Africa",[
    "South African popular music includes marabi and kwela (with pennywhistles), mbaqanga, and the jazz of Hugh Masekela and Abdullah Ibrahim. Miriam Makeba, 'Mama Africa,' became an international star and anti-apartheid voice; her 'Pata Pata' was a 1967 hit. Johnny Clegg's racially mixed bands defied apartheid laws.",
    "Recent styles include kwaito (1990s house-influenced township music), gqom, and amapiano (from about 2012), with its log-drum bass and piano, which has spread worldwide."]],
  ["Afrobeats",[
    "Afrobeats (with an 's'), distinct from Fela's Afrobeat, is a 21st-century pop style from Nigeria and Ghana that blends West African rhythms with hip-hop, dancehall, R&B, and electronic production. Stars such as Wizkid, Davido, Burna Boy (whose Twice as Tall won a Grammy in 2021), Tems, and Rema ('Calm Down,' a global hit) have made it one of the world's fastest-growing genres.",
    "The Grammys introduced a Best African Music Performance category in 2024, recognizing Africa's growing influence on global pop."]]
  ],
  terms:[["Highlife","Ghanaian-Nigerian fusion of local and Western styles."],["Congolese rumba","Guitar-based dance music inspired by Cuban son."],["Afrobeat","Fela Kuti's fusion of highlife, jazz, and funk."],["Afrobeats","21st-century West African pop style."],["Amapiano","South African house style with log-drum bass."]],
  w:"African popular music has shaped global pop for decades and is now one of its leading forces.",
  src:["Fela Kuti","Afrobeat","Afrobeats","Highlife","Congolese rumba"],
  q:[
  ["Who created Afrobeat?","Fela Kuti","King Sunny Adé","Youssou N'Dour","Burna Boy"],
  ["Which drummer was central to Afrobeat's sound?","Tony Allen","Ginger Baker","Babatunde Olatunji","Max Roach"],
  ["Congolese rumba was inspired by records from which country?","Cuba","Brazil","USA","Jamaica"],
  ["Which Malian guitarist recorded Talking Timbuktu with Ry Cooder?","Ali Farka Touré","Salif Keita","Toumani Diabaté","Boubacar Traoré"],
  ["Which singer was known as 'Mama Africa'?","Miriam Makeba","Angélique Kidjo","Oumou Sangaré","Brenda Fassie"],
  ["Amapiano comes from which country?","South Africa","Nigeria","Ghana","Kenya"]]},

{ t:"Latin America: Cuba and the Caribbean", s:"Son, salsa, and the clave",
  sec:[
  ["Three roots",[
    "Latin American and Caribbean music grew from three main sources: Indigenous American music, Spanish and Portuguese music (guitars, harmony, poetic forms), and African music brought by enslaved people (drums, polyrhythm, call and response). The mix varies greatly from place to place.",
    "Cuba, with deep Yoruba, Kongo, and Spanish roots, became one of the most influential musical centers in the world."]],
  ["The clave and Cuban genres",[
    "Much Cuban music is organized around the clave, a two-bar rhythmic pattern of five strokes played on two wooden sticks (also called claves), either 3-2 or 2-3. All parts must fit the clave. Son cubano, from eastern Cuba, combined Spanish guitar (and the tres, a guitar with three double strings) with African percussion (bongos, maracas) and became the basis of salsa.",
    "Other Cuban genres include the danzón, an elegant ballroom dance; the habanera, a rhythm that spread worldwide (as in Bizet's Carmen); rumba (Afro-Cuban drum and dance); the mambo (Pérez Prado and Tito Puente popularized it in the 1950s); and the cha-cha-chá. Afro-Cuban religious music of Santería uses batá drums."]],
  ["Salsa",[
    "Salsa developed in New York in the 1960s and 70s among Puerto Rican and Cuban musicians, building on son and mambo with brass, piano montunos (repeated patterns), and a hot rhythm section with congas, timbales, and bongos. Fania Records, with stars such as Celia Cruz (the 'Queen of Salsa'), Willie Colón, Héctor Lavoe, Rubén Blades, and Johnny Pacheco, made salsa a symbol of Latino identity.",
    "Salsa spread to Colombia, Venezuela, Puerto Rico, and beyond; Cali in Colombia calls itself the world salsa capital."]],
  ["Dominican Republic and Puerto Rico",[
    "The Dominican Republic gave the world merengue, a fast dance with accordion, tambora drum, and güira scraper, and bachata, originally a guitar music of rural poverty, later polished into a global romantic style by artists such as Juan Luis Guerra and Romeo Santos.",
    "Puerto Rico's traditions include bomba (Afro-Puerto Rican drumming and dance) and plena (a sung newspaper of everyday events). It later became a center of reggaeton, with Daddy Yankee's 'Gasolina' (2004) and today Bad Bunny."]],
  ["The English- and French-speaking Caribbean",[
    "Trinidad and Tobago created calypso, witty topical songs with roots in African traditions and carnival, made famous by Lord Kitchener and the Mighty Sparrow, and soca ('soul of calypso'), its faster dance offshoot. The steelpan was invented there in the 20th century from oil drums.",
    "Haiti's kompa, and the zouk of Guadeloupe and Martinique (popularized by Kassav'), are major French Caribbean dance styles. Jamaica's ska, reggae, and dancehall were covered earlier."]],
  ["Cuba's global influence",[
    "Cuban music influenced jazz (Dizzy Gillespie and Chano Pozo's Cubop), Congolese rumba, and pop worldwide. Jazz pianist Jelly Roll Morton described the 'Spanish tinge' as essential to jazz.",
    "The Buena Vista Social Club recording (1997), with Compay Segundo, Ibrahim Ferrer, and Omara Portuondo, brought classic son to a global audience. Contemporary Cuban artists mix son with timba, jazz, and hip-hop."]]
  ],
  terms:[["Clave","Two-bar rhythmic key pattern of Cuban music."],["Son cubano","Cuban genre combining Spanish guitar and African percussion."],["Montuno","Repeated piano or vocal pattern in salsa."],["Calypso","Trinidadian topical song style."],["Merengue","Fast Dominican dance music."]],
  w:"Caribbean music, especially Cuban, gave the world salsa, mambo, and rhythms found in jazz and pop everywhere.",
  src:["Clave (rhythm)","Son cubano","Salsa music","Calypso music","Merengue music"],
  q:[
  ["What is the clave?","A two-bar rhythmic pattern organizing Cuban music","A Cuban guitar","A dance","A drum"],
  ["Which genre developed in 1960s–70s New York from Cuban son?","Salsa","Bachata","Calypso","Cumbia"],
  ["Who is called the 'Queen of Salsa'?","Celia Cruz","Gloria Estefan","La Lupe","Omara Portuondo"],
  ["Which country is the home of merengue and bachata?","Dominican Republic","Cuba","Puerto Rico","Colombia"],
  ["Calypso comes from which country?","Trinidad and Tobago","Jamaica","Barbados","Haiti"],
  ["Which label made salsa famous in the 1970s?","Fania Records","Motown","Columbia","Chess"]]}

]});


/* ---- from music-18.js ---- */
/* MUSIC FOUNDATIONS, part 18: Unit 8 chapters 5-8 */
COURSES.music.units[7].ch.push(

{ t:"Latin America: Brazil, Argentina, and Beyond", s:"Samba, tango, and cumbia",
  sec:[
  ["Brazil: samba",[
    "Brazil, the largest country in South America and Portuguese-speaking, received more enslaved Africans than any other country, and its music reflects deep African roots. Samba emerged in Rio de Janeiro in the early 20th century among Afro-Brazilian communities; 'Pelo Telefone' (1917) is often called the first recorded samba.",
    "Samba schools (escolas de samba), community organizations, compete in Rio's Carnival parade with thousands of dancers and huge percussion sections (baterias) of surdo bass drums, tamborims, cuícas (friction drums with a squeaking sound), and agogô bells."]],
  ["Bossa nova and MPB",[
    "In the late 1950s, bossa nova ('new trend') slowed samba's rhythm and combined it with cool jazz harmony and soft, intimate singing. João Gilberto's guitar style and Antônio Carlos Jobim's songs, such as 'The Girl from Ipanema' (with lyricist Vinicius de Moraes) and 'Desafinado,' became global hits; Getz/Gilberto (1964) won the Grammy for Album of the Year.",
    "In the late 1960s, Tropicália, led by Caetano Veloso and Gilberto Gil, mixed Brazilian styles with psychedelic rock and avant-garde ideas; both were imprisoned and exiled by the military dictatorship. MPB (Música Popular Brasileira) describes the broad tradition of Brazilian songwriters, including Chico Buarque, Milton Nascimento, and Elis Regina."]],
  ["More Brazilian styles",[
    "Choro, an instrumental style of 19th-century Rio, is sometimes called Brazil's jazz, with virtuosic flute, guitar, cavaquinho, and pandeiro; Pixinguinha was its master. Heitor Villa-Lobos, Brazil's greatest classical composer, fused Bach and Brazilian folk in his Bachianas Brasileiras.",
    "Northeastern Brazil produced forró (accordion-driven dance music made famous by Luiz Gonzaga), frevo, and maracatu. The Afro-Brazilian martial art capoeira is accompanied by the berimbau, a musical bow with a gourd resonator. Contemporary styles include funk carioca, sertanejo (Brazilian country, the best-selling genre in Brazil), and Brazilian pop by Anitta."]],
  ["Argentina: tango",[
    "Tango was born in the late 19th century in the port neighborhoods of Buenos Aires and Montevideo (Uruguay), among immigrants, Afro-Argentines, and working-class people. It mixed habanera, milonga, Italian and Spanish songs, and African rhythms, with a sensual, intimate dance.",
    "Its signature instrument is the bandoneón, a type of concertina from Germany. Carlos Gardel (1890–1935) became tango's great singer ('Por una Cabeza'). Astor Piazzolla (1921–1992), who studied with Nadia Boulanger, created nuevo tango, adding jazz and classical elements ('Libertango,' 'Adiós Nonino'). Tango was added to UNESCO's intangible heritage list in 2009."]],
  ["The Andes and Mexico",[
    "Andean music of Peru, Bolivia, and Ecuador uses panpipes (siku, zampoña), the quena flute, and the charango, a small lute once made with an armadillo shell. 'El Cóndor Pasa' (1913), by Peruvian composer Daniel Alomía Robles, became famous through Simon & Garfunkel.",
    "Mexico's mariachi, from Jalisco, features violins, trumpets, guitars, the vihuela, and the guitarrón (bass guitar), playing sones, rancheras, and boleros; mariachi was added to UNESCO's list in 2011. Northern Mexican norteño uses the accordion, brought by German and Czech immigrants, and the bajo sexto; banda uses large brass ensembles. Corridos are narrative ballads; recently 'corridos tumbados' by Peso Pluma and others have gone global."]],
  ["Colombia and nueva canción",[
    "Colombia's cumbia, from the Caribbean coast, mixes Indigenous flutes (gaitas), African drums, and Spanish melody. It spread throughout Latin America, generating local variants in Mexico, Peru (chicha), and Argentina. Vallenato, with accordion, caja drum, and guacharaca scraper, is another Colombian favorite; Shakira and Carlos Vives drew on these traditions.",
    "In the 1960s–70s, the nueva canción ('new song') movement, with Violeta Parra and Víctor Jara in Chile and Mercedes Sosa in Argentina, used folk music for social protest; Jara was killed after the 1973 Chilean coup."]]
  ],
  terms:[["Samba","Afro-Brazilian music and dance from Rio."],["Bossa nova","Brazilian blend of samba and cool jazz."],["Tango","Dance music from Buenos Aires and Montevideo."],["Bandoneón","Concertina central to tango."],["Cumbia","Colombian dance rhythm popular across Latin America."]],
  w:"Brazil, Argentina, Mexico, and the Andes gave the world samba, bossa nova, tango, and mariachi.",
  src:["Samba","Bossa nova","Tango music","Astor Piazzolla","Mariachi"],
  q:[
  ["Who wrote 'The Girl from Ipanema'?","Antônio Carlos Jobim","João Gilberto","Caetano Veloso","Gilberto Gil"],
  ["What is the bandoneón?","A concertina central to tango","A Brazilian drum","An Andean flute","A Mexican guitar"],
  ["Who created nuevo tango?","Astor Piazzolla","Carlos Gardel","Aníbal Troilo","Osvaldo Pugliese"],
  ["Which musical bow accompanies capoeira?","Berimbau","Charango","Cuíca","Cavaquinho"],
  ["Which country is the home of cumbia?","Colombia","Mexico","Peru","Argentina"],
  ["Which Chilean singer of nueva canción was killed after the 1973 coup?","Víctor Jara","Violeta Parra","Pablo Neruda","Inti-Illimani"]]},

{ t:"Music of the Middle East and North Africa", s:"Maqam and the oud",
  sec:[
  ["The maqam system",[
    "Arabic, Turkish, and Persian classical music are organized by modal systems: maqam (Arabic; makam in Turkish) and dastgah (Persian). A maqam is more than a scale; it includes characteristic melodic phrases, a central note, typical ways of moving, and an emotional character. Common Arabic maqamat include Rast, Bayati, Hijaz, Saba, Nahawand, and Sikah.",
    "These systems use intervals that fall between Western semitones, including 'neutral' seconds roughly three-quarters of a tone wide, which give the music its distinctive color. Arabic music theory is often explained with quarter tones, though actual intonation varies by region and maqam."]],
  ["Instruments",[
    "The oud, a short-necked fretless lute with a pear-shaped body, is the 'king' of Arabic instruments and the ancestor of the European lute (from Arabic al-'ud). Other instruments include the qanun (a plucked zither with levers to adjust pitches), the nay (an end-blown reed flute, central to Sufi music), the violin, and percussion such as the darbuka (goblet drum), riq (tambourine), and daf (frame drum).",
    "Persian music features the tar and setar (lutes), santur (hammered dulcimer), kamancheh (spike fiddle), and tombak drum. Turkish music uses the saz (bağlama), ney, and kanun."]],
  ["Form and performance",[
    "Classical performances often begin with a taqsim, an unmetered improvisation exploring the maqam, followed by composed pieces and songs. Rhythmic cycles called iqa'at (usul in Turkish) organize metered music, sometimes in long and complex patterns.",
    "Tarab is the Arabic concept of musical ecstasy or enchantment shared between performer and audience; listeners respond audibly to beautiful phrases, and a great singer extends and repeats lines in response to the audience's emotion."]],
  ["Great artists",[
    "Umm Kulthum (about 1904–1975) of Egypt was the most celebrated Arab singer of the 20th century, whose monthly concerts, broadcast on radio, emptied streets across the Arab world; single songs could last over an hour. Mohammed Abdel Wahab, Farid al-Atrash, and Abdel Halim Hafez were also legends, and Lebanon's Fairuz, with the Rahbani brothers, became a beloved voice from the 1950s onward.",
    "In Iran, singers such as Mohammad-Reza Shajarian preserved the Persian classical tradition, and in Turkey, Ottoman court music and Sufi music of the Mevlevi order (the 'whirling dervishes') flourished."]],
  ["Sacred sounds",[
    "The Islamic call to prayer (adhan), chanted five times daily from mosques, and the art of Quran recitation (tajwid) are highly developed vocal arts, though in Islamic tradition these are not considered 'music.' Views on music within Islam vary widely, from embrace to strict limitation.",
    "Sufi traditions use music for spiritual ecstasy: Turkish Mevlevi ceremonies, Moroccan Gnawa trance music (with the sintir bass lute and iron castanets, rooted in sub-Saharan Africa), and South Asian qawwali."]],
  ["Popular music",[
    "Algerian raï, a rebellious popular style with roots in Oran, was popularized by Cheb Khaled ('Didi,' 'Aïcha'). Arabic pop, centered in Cairo and Beirut, mixes traditional instruments with Western production; Amr Diab and Nancy Ajram are major stars. Egyptian mahraganat, an electronic street style, emerged in the 2010s.",
    "Israeli music blends Mizrahi (Middle Eastern Jewish), Ashkenazi, and global styles. The Moroccan Andalusian tradition preserves music associated with medieval Muslim Spain."]]
  ],
  terms:[["Maqam","Arabic modal system with characteristic phrases."],["Oud","Fretless lute, ancestor of the European lute."],["Taqsim","Unmetered improvisation exploring a maqam."],["Tarab","Musical ecstasy shared by performer and listener."],["Qanun","Plucked zither with pitch-adjusting levers."]],
  w:"The maqam tradition is one of the great musical systems of the world and shaped music from Spain to Central Asia.",
  src:["Arabic maqam","Oud","Umm Kulthum","Persian traditional music","Raï"],
  q:[
  ["What is a maqam?","An Arabic modal system with characteristic melodic phrases","A drum rhythm","A type of song lyric","An instrument"],
  ["Which instrument is the ancestor of the European lute?","Oud","Qanun","Nay","Saz"],
  ["Which Egyptian singer's monthly concerts emptied streets across the Arab world?","Umm Kulthum","Fairuz","Warda","Asmahan"],
  ["What is a taqsim?","An unmetered improvisation exploring a maqam","A dance rhythm","A choral song","A religious chant"],
  ["Which genre did Cheb Khaled popularize?","Raï","Gnawa","Mahraganat","Chaabi"],
  ["What does 'tarab' mean?","Musical ecstasy or enchantment","A rhythmic cycle","A string instrument","A type of mosque chant"]]},

{ t:"Music of India", s:"Raga and tala",
  sec:[
  ["Two classical traditions",[
    "India has two main classical traditions: Hindustani music in the north, shaped by centuries of Persian and Mughal court influence, and Carnatic music in the south, more closely tied to Hindu devotional song. Both rest on two concepts: raga (melodic framework) and tala (rhythmic cycle).",
    "Indian music theory goes back to the Natya Shastra (about 2nd century BCE to 2nd century CE). Music was historically supported by temples and royal courts, and today by concerts, festivals, and media."]],
  ["Raga",[
    "A raga is a melodic framework: a set of notes with specific ascending and descending patterns, characteristic phrases, important notes, ornaments, and an emotional flavor (rasa). Ragas are traditionally associated with times of day or seasons; for example, Raga Bhairav is a morning raga and Raga Yaman an evening one.",
    "The seven note names are sa, re, ga, ma, pa, dha, ni (sargam). Notes are bent and ornamented with slides (meend), oscillations (gamak), and grace notes, so how a note is approached matters as much as the note itself. A drone, played by the tanpura, sounds the tonic (sa) and fifth (pa) continuously."]],
  ["Tala",[
    "A tala is a cyclic rhythmic pattern of a fixed number of beats grouped in sections. Teentaal (16 beats, 4+4+4+4) is the most common Hindustani tala; others include rupak (7) and jhaptal (10). The first beat, sam, is the point of arrival; performers create excitement by improvising complex patterns that land precisely on sam.",
    "Tabla players learn rhythms using spoken syllables (bols), and in Carnatic music the mridangam and konnakol (vocal percussion) play this role."]],
  ["A Hindustani performance",[
    "A typical Hindustani instrumental performance begins with the alap, a slow, unmetered exploration of the raga without drums; then jor and jhala add pulse and speed; then the gat, a composition with tabla, followed by improvisations that grow faster and more intricate. Vocal genres include the serious dhrupad and the more ornate khyal.",
    "Leading instruments include the sitar (a long-necked lute with sympathetic strings), sarod, bansuri (bamboo flute), santoor, sarangi, shehnai, and tabla. Famous musicians include Ravi Shankar (sitar), Ali Akbar Khan (sarod), Zakir Hussain (tabla), Hariprasad Chaurasia (bansuri), Bismillah Khan (shehnai), and vocalists such as Bhimsen Joshi and Kishori Amonkar."]],
  ["Carnatic music",[
    "Carnatic music is primarily vocal, with compositions, especially kritis, at its center. The 'Trinity' of Carnatic composers, Tyagaraja, Muthuswami Dikshitar, and Syama Sastri, lived in the 18th–19th centuries. Instruments include the veena, violin (adopted in the 19th century), mridangam, ghatam (clay pot), and flute.",
    "M. S. Subbulakshmi was the first musician to receive India's highest civilian honor, the Bharat Ratna (1998). The annual Madras Music Season in Chennai is one of the world's largest music festivals."]],
  ["Film music and global reach",[
    "Film music (filmi) is India's dominant popular music. Bollywood (Hindi films from Mumbai) and regional film industries use songs as integral parts of storytelling, sung by 'playback singers' while actors lip-sync. Lata Mangeshkar, who recorded thousands of songs, and Asha Bhosle are legends; composer A. R. Rahman won two Academy Awards for Slumdog Millionaire (2008).",
    "Indian music has influenced the Beatles, John Coltrane, minimalists such as Philip Glass (who worked with Ravi Shankar), and much fusion. Bhangra, Punjabi folk dance music, became a global club sound through the South Asian diaspora in Britain."]]
  ],
  terms:[["Raga","Melodic framework with characteristic phrases and mood."],["Tala","Cyclic rhythmic pattern."],["Sam","First beat of a tala cycle."],["Alap","Slow, unmetered opening exploration of a raga."],["Tanpura","Drone instrument sounding the tonic."]],
  w:"Indian classical music is one of the world's most sophisticated improvised traditions and deeply influenced Western music.",
  src:["Raga","Tala (music)","Hindustani classical music","Carnatic music","Filmi"],
  q:[
  ["What is a raga?","A melodic framework with characteristic phrases and mood","A rhythmic cycle","A drum","A dance"],
  ["How many beats are in teentaal?","16","12","8","7"],
  ["What is the first beat of a tala cycle called?","Sam","Alap","Bol","Gat"],
  ["Which instrument provides the drone in Indian music?","Tanpura","Tabla","Sarod","Bansuri"],
  ["Which South Indian classical tradition is centered on vocal compositions?","Carnatic","Hindustani","Qawwali","Dhrupad"],
  ["Which composer won two Oscars for Slumdog Millionaire?","A. R. Rahman","R. D. Burman","Ravi Shankar","Ilaiyaraaja"]]},

{ t:"Music of East Asia", s:"China, Japan, and Korea",
  sec:[
  ["Chinese music",[
    "Chinese music has a documented history of over 3,000 years. Confucian thought regarded music as essential to harmony in society and the state. Traditional Chinese instruments were classified by material into eight categories (bayin): silk, bamboo, wood, stone, metal, clay, gourd, and skin.",
    "Key instruments include the guqin (a seven-string zither associated with scholars, among the oldest instruments still played), the guzheng (a larger plucked zither), the pipa (a pear-shaped lute), the erhu (a two-string bowed fiddle), and the dizi (bamboo flute). Much Chinese music uses pentatonic scales, and it often depicts nature or poetic images, such as the guqin piece 'Flowing Water,' sent into space on the Voyager Golden Record."]],
  ["Chinese opera and modern music",[
    "Chinese opera includes hundreds of regional forms; Peking (Beijing) opera, developed in the late 18th and 19th centuries, combines singing, speech, acrobatics, martial arts, symbolic gestures, painted face makeup indicating character, and a percussion ensemble. Kunqu, older and more refined, was named by UNESCO a Masterpiece of the Oral and Intangible Heritage of Humanity in 2001.",
    "In the 20th century, Western classical music took root in China, and conservatories trained world-class performers such as pianist Lang Lang. Chinese pop includes Mandopop and Cantopop, with stars from Teresa Teng to Jay Chou. Composer Tan Dun won an Oscar for Crouching Tiger, Hidden Dragon."]],
  ["Japanese traditions",[
    "Gagaku, imperial court music imported from China and Korea around the 7th–8th centuries, is among the oldest orchestral traditions still performed. Noh theater (14th century) combines slow, stylized movement, chant, flute, and drums; kabuki (17th century) is more popular and flamboyant, accompanied by the shamisen, a three-string lute.",
    "Other instruments include the koto (a 13-string zither), the shakuhachi (bamboo flute associated with Zen monks), and taiko drums, whose ensemble style became internationally famous from the mid-20th century. Japanese aesthetics value ma, meaningful space or silence, and subtle timbral change."]],
  ["Japanese popular music",[
    "Japan has the second-largest recorded music market in the world, notable for continued strong physical CD sales. Enka (sentimental ballads), city pop of the 1970s–80s (rediscovered online in the 2010s, such as Mariya Takeuchi's 'Plastic Love'), J-pop, J-rock, and idol groups such as AKB48 are major genres. Anime and video game music, from Joe Hisaishi's Studio Ghibli scores to Koji Kondo's Nintendo themes, reach global audiences.",
    "Japan was also important to electronic music through Yellow Magic Orchestra and Ryuichi Sakamoto and to instrument making through companies such as Yamaha, Roland, Korg, and Casio."]],
  ["Korea and K-pop",[
    "Korean traditional music (gugak) includes court music, the gayageum (zither), and pansori, an epic storytelling genre for one singer and a drummer, designated by UNESCO in 2003. Samul nori is a dynamic percussion quartet style based on farmers' music.",
    "K-pop emerged in the 1990s, often dated to Seo Taiji and Boys (1992). Entertainment companies such as SM, YG, JYP, and HYBE train young performers for years in singing, dance, and languages, then debut them in groups with polished choreography and videos. PSY's 'Gangnam Style' (2012) became the first YouTube video to reach a billion views; BTS became one of the world's best-selling acts and topped the Billboard Hot 100; BLACKPINK headlined Coachella in 2023. The 'Korean Wave' (Hallyu) is also a deliberate cultural export strategy."]],
  ["Southeast Asia: gamelan",[
    "In Indonesia, especially Java and Bali, the gamelan is an ensemble of bronze gongs, metallophones, drums, and sometimes voices, flute, and fiddle. Music is built in layers: a core melody, elaborating parts at faster speeds, and large gongs marking the end of cycles (colotomic structure). Two tuning systems, slendro (five tones) and pelog (seven tones), are used, and each gamelan is tuned uniquely as a set.",
    "Balinese gamelan is fast and brilliant, with interlocking parts called kotekan; Javanese gamelan is often slower and meditative. Gamelan accompanies wayang kulit (shadow puppet theater) and dance. Thailand's piphat ensembles and Vietnam's dan bau (monochord) are other Southeast Asian traditions."]]
  ],
  terms:[["Guqin","Ancient Chinese seven-string zither."],["Peking opera","Chinese theatrical form of song, acrobatics, and gesture."],["Shamisen","Japanese three-string lute."],["Pansori","Korean epic storytelling song."],["Gamelan","Indonesian bronze percussion ensemble."]],
  w:"East and Southeast Asian music offers ancient traditions and today's most dynamic pop industries.",
  src:["Music of China","Guqin","Music of Japan","K-pop","Gamelan"],
  q:[
  ["Which Chinese zither is associated with scholars and is very ancient?","Guqin","Pipa","Erhu","Dizi"],
  ["Which Japanese theatrical form is accompanied by the shamisen and is flamboyant?","Kabuki","Noh","Gagaku","Bunraku only"],
  ["What is pansori?","Korean epic storytelling song","A Japanese flute","Chinese opera","A Thai ensemble"],
  ["Which was the first YouTube video to reach a billion views?","Gangnam Style","Despacito","Baby","Dynamite"],
  ["What are the two tuning systems of gamelan?","Slendro and pelog","Raga and tala","Maqam and iqa","Yo and in"],
  ["Which K-pop group topped the Billboard Hot 100 and became a global best-seller?","BTS","EXO","Big Bang","TWICE"]]}

);


/* ---- from music-19.js ---- */
/* MUSIC FOUNDATIONS, part 19: Unit 8 chapters 9-11 */
COURSES.music.units[7].ch.push(

{ t:"European Folk Traditions", s:"Celtic, Nordic, Balkan, and Slavic",
  sec:[
  ["Folk music in Europe",[
    "Before industrialization, most Europeans made music themselves: ballads, work songs, dance tunes, lullabies, and seasonal songs passed down orally. In the 19th century, collectors such as the Brothers Grimm (for tales), Francis James Child (who published 305 English and Scottish ballads, the 'Child Ballads'), and later Cecil Sharp and Bartók began recording this heritage, partly from nationalist motives and partly from fear it would vanish.",
    "Folk music often uses modes, drones, ornamented singing, and dance forms tied to particular regions."]],
  ["Ireland and Scotland",[
    "Irish traditional music is built on dance tunes, jigs (in 6/8), reels (in 4/4), hornpipes, slides, and polkas, played on fiddle, tin whistle, wooden flute, uilleann pipes (bellows-blown bagpipes), button accordion, concertina, banjo, and the bodhrán (frame drum). Sessions in pubs bring musicians together informally. Sean-nós ('old style') singing is unaccompanied and highly ornamented, often in Irish.",
    "The Chieftains, Planxty, and the Dubliners led a revival from the 1960s, and Riverdance (1994) made Irish dance a global spectacle. Scotland's Great Highland bagpipe, with its chanter and drones, is famous for military pipe bands and pibroch (ceòl mòr), long classical variations. Scottish fiddling, Gaelic song, and the Strathspey dance rhythm are also distinctive."]],
  ["England and Scandinavia",[
    "English folk includes ballads, morris dance tunes, sea shanties (work songs for sailors, which had a viral revival on TikTok in 2021 with 'Wellerman,' actually a New Zealand whaling song), and carols. The 1960s–70s British folk revival produced Fairport Convention, Pentangle, Sandy Denny, and Shirley Collins.",
    "Scandinavian traditions include the Swedish nyckelharpa (keyed fiddle), the Norwegian Hardanger fiddle with sympathetic strings, Sámi joik (a personal chant evoking a person, animal, or place, considered among Europe's oldest vocal traditions), and Finnish kantele (zither) and the Kalevala epic songs."]],
  ["Eastern Europe and the Balkans",[
    "Balkan music features irregular, 'additive' meters such as 7/8 (3+2+2), 9/8 (2+2+2+3), and 11/8, used in dances like the Bulgarian rachenitsa and kopanitsa. The Bulgarian women's choir sound, with open-throated singing and close dissonant harmonies, became famous through the album Le Mystère des Voix Bulgares (1975 onward).",
    "Georgian polyphonic singing, with three-part harmony and unusual intervals, was among the first items declared by UNESCO a masterpiece of intangible heritage (2001). Ukrainian, Polish, and Russian traditions include choral singing, the bandura (Ukrainian harp-lute), the balalaika, and village polyphony."]],
  ["Roma and klezmer",[
    "The Romani people, who migrated from northern India to Europe around a thousand years ago, became renowned professional musicians across Europe, especially in Hungary, Romania, the Balkans, and Spain. Their virtuosic violin and cimbalom playing influenced Liszt's Hungarian Rhapsodies and Brahms's Hungarian Dances. Django Reinhardt, a Belgian-born Romani guitarist, created gypsy jazz (jazz manouche) in 1930s Paris with violinist Stéphane Grappelli, despite having two fingers of his left hand damaged by fire.",
    "Klezmer is the instrumental celebration music of Ashkenazi Jews of Eastern Europe, played at weddings, with clarinet, violin, accordion, and bass, and a 'crying' ornamental style. Nearly destroyed by the Holocaust, it was revived in the 1970s in America by bands such as the Klezmatics."]],
  ["Folk and modern Europe",[
    "Folk traditions continue in festivals, dance halls, and fusion. Breton fest-noz dances, Basque txalaparta, Corsican polyphony, Portuguese and Spanish regional styles, and the Alpine yodel remain alive.",
    "Many contemporary artists, from Björk to Wardruna (Nordic folk) to the Ukrainian 'ethno-chaos' band DakhaBrakha, blend folk roots with modern sounds."]]
  ],
  terms:[["Jig","Irish dance tune in 6/8."],["Uilleann pipes","Irish bellows-blown bagpipes."],["Joik","Sámi personal chant."],["Additive meter","Meter of uneven beat groupings, like 7/8 = 3+2+2."],["Klezmer","Eastern European Jewish celebration music."]],
  w:"European folk traditions underlie much classical, rock, and pop music and remain vibrant living cultures.",
  src:["Irish traditional music","Child Ballads","Music of Bulgaria","Klezmer","Django Reinhardt"],
  q:[
  ["In what meter is an Irish jig typically written?","6/8","4/4","3/4","7/8"],
  ["What are uilleann pipes?","Irish bellows-blown bagpipes","Scottish military pipes","A Welsh harp","A Breton flute"],
  ["What is joik?","A Sámi personal chant","A Swedish fiddle","A Finnish epic","A Norwegian dance"],
  ["Which meter is typical of Balkan dance?","7/8","4/4","2/2","6/8 only"],
  ["Who created gypsy jazz in 1930s Paris?","Django Reinhardt","Stéphane Grappelli","Sidney Bechet","Joe Pass"],
  ["Klezmer is the celebration music of which people?","Ashkenazi Jews","Romani people","Irish travelers","Basques"]]},

{ t:"Flamenco and Fado", s:"Iberian song of passion and longing",
  sec:[
  ["Flamenco's origins",[
    "Flamenco developed in Andalusia, southern Spain, especially among the Gitano (Romani) communities, absorbing influences from Andalusian folk, Moorish (Arab-Andalusian) music, Sephardic Jewish music, and possibly Byzantine chant. Its recognizable form took shape in the 18th and 19th centuries, and it flourished in 19th-century cafés cantantes (singing cafés).",
    "Flamenco was inscribed on UNESCO's list of the Intangible Cultural Heritage of Humanity in 2010."]],
  ["The elements",[
    "Flamenco has three central elements: cante (song), toque (guitar), and baile (dance), plus jaleo (shouts of encouragement such as '¡Olé!'), palmas (rhythmic handclapping), and zapateado (rhythmic footwork). Singers use a raw, intense, melismatic style; the deepest songs, cante jondo ('deep song'), express grief and passion.",
    "The poet Federico García Lorca and composer Manuel de Falla organized a famous cante jondo competition in Granada in 1922 to preserve the tradition."]],
  ["Palos and compás",[
    "Flamenco is organized into palos, song forms with specific rhythms, moods, and harmonies. Many use a 12-beat compás (rhythmic cycle) with accents on beats 3, 6, 8, 10, and 12, as in the soleá and alegrías; the bulería is a fast, playful 12-beat form; the seguiriya is a solemn, deep form; tangos and rumbas are in 4/4; the fandango and sevillanas are lighter forms.",
    "The 'Andalusian cadence,' a descending chord progression such as A minor–G–F–E, is characteristic, and the Phrygian mode gives flamenco its distinctive sound."]],
  ["Masters",[
    "Guitarist Paco de Lucía (1947–2014) revolutionized flamenco guitar, adding jazz harmonies and the Peruvian cajón box drum, and partnering with the legendary singer Camarón de la Isla (1950–1992), whose album La leyenda del tiempo (1979) blended flamenco with rock. Dancers such as Carmen Amaya, Antonio Gades, and Joaquín Cortés gained world fame.",
    "Modern artists such as Rosalía, whose album El mal querer (2018) fused flamenco with pop and R&B, have brought flamenco to new generations, though with debate about tradition and appropriation."]],
  ["Fado",[
    "Fado ('fate') is Portugal's soulful urban song, which emerged in Lisbon's working-class neighborhoods such as Alfama and Mouraria in the early 19th century. A singer (fadista) is accompanied by the Portuguese guitar (guitarra portuguesa, a 12-string, pear-shaped instrument descended from the English cittern) and a classical guitar (viola).",
    "Fado expresses saudade, a uniquely Portuguese word for a deep, melancholic longing for something absent or lost. Amália Rodrigues (1920–1999), the 'Queen of Fado,' made it internationally known; Coimbra has its own student fado tradition. Fado joined UNESCO's list in 2011. Contemporary fadistas include Mariza, Ana Moura, and Carminho."]],
  ["Lusophone music",[
    "Portuguese colonial history spread music across the Lusophone world. Cape Verde's morna, a slow, melancholic song form related to fado, became famous through Cesária Évora, the 'barefoot diva.' Angola's semba influenced Brazilian samba and gave rise to kizomba, a popular partner dance.",
    "These connections show how songs travel across oceans and centuries, carrying both sorrow and celebration."]]
  ],
  terms:[["Cante jondo","'Deep song,' flamenco's most intense form."],["Compás","Flamenco rhythmic cycle."],["Palo","A flamenco song form."],["Saudade","Portuguese longing for something absent."],["Portuguese guitar","12-string instrument accompanying fado."]],
  w:"Flamenco and fado show how song can carry a people's deepest emotions, and both remain living arts.",
  src:["Flamenco","Fado","Paco de Lucía","Amália Rodrigues","Saudade"],
  q:[
  ["In which region of Spain did flamenco develop?","Andalusia","Catalonia","Galicia","Basque Country"],
  ["What are the three central elements of flamenco?","Cante, toque, baile","Palmas, jaleo, compás","Guitar, drums, voice","Soleá, bulería, tango"],
  ["Which guitarist revolutionized flamenco and introduced the cajón?","Paco de Lucía","Vicente Amigo","Tomatito","Sabicas"],
  ["What does 'saudade' mean?","Deep melancholic longing","Joyful celebration","Religious devotion","Rhythmic intensity"],
  ["Who was called the 'Queen of Fado'?","Amália Rodrigues","Mariza","Cesária Évora","Ana Moura"],
  ["Which Cape Verdean singer made morna famous?","Cesária Évora","Amália Rodrigues","Lura","Sara Tavares"]]},

{ t:"Indigenous and Oceanic Musics", s:"Songlines, powwows, and island voices",
  sec:[
  ["Indigenous music of North America",[
    "Native American music is diverse, reflecting hundreds of nations, but often centers on the voice, frequently with vocables (meaningful syllables without dictionary meaning), accompanied by drums and rattles. Songs may belong to particular people, clans, or ceremonies and carry spiritual power.",
    "The powwow, an intertribal gathering of dance, song, and community that grew in the 20th century, features 'drums,' groups of singers seated around a large drum, singing in high, intense styles (Northern) or lower styles (Southern). The Native American flute, played by R. Carlos Nakai and others, became widely known. Artists such as Buffy Sainte-Marie, Robbie Robertson, and the electronic group The Halluci Nation (formerly A Tribe Called Red) brought Indigenous perspectives to popular music; Inuit throat singing (katajjaq) is a vocal game between two women."]],
  ["Australia's First Nations",[
    "Aboriginal Australians have the world's oldest continuous cultures, with song traditions tens of thousands of years deep. Songlines, also called dreaming tracks, are routes across the land recorded in sequences of songs; singing them encodes navigation, law, kinship, ecology, and sacred story.",
    "The didgeridoo (yidaki in Yolŋu language), a long wooden trumpet hollowed by termites, comes from northern Australia and is played with circular breathing for continuous sound. Clapsticks accompany song. Contemporary artists include Yothu Yindi ('Treaty,' 1991), Archie Roach, Gurrumul (Geoffrey Gurrumul Yunupingu), and Baker Boy, who raps in Yolŋu Matha."]],
  ["Polynesia and Hawaii",[
    "In Hawaii, mele (chant and song) and hula (dance) were central to religious and historical life. Christian missionaries in the 19th century suppressed hula and introduced hymns (himeni), which influenced Hawaiian harmony. The ukulele developed from Portuguese instruments brought by Madeiran immigrants in the 1870s, and Hawaiian steel guitar, invented by Joseph Kekuku, influenced country music.",
    "Slack-key guitar (kī hō'alu), with open tunings, became a cherished Hawaiian style. Israel Kamakawiwo'ole's ukulele medley 'Somewhere Over the Rainbow/What a Wonderful World' (1993) became a worldwide favorite. The late 20th-century Hawaiian Renaissance revived language, hula, and chant."]],
  ["Māori and the Pacific",[
    "In New Zealand (Aotearoa), Māori music includes waiata (songs) and the haka, a posture dance with chanted words, performed at ceremonies and famously by the All Blacks rugby team before matches ('Ka Mate'). Taonga pūoro are traditional Māori instruments of wood, bone, and stone, revived from the 1980s.",
    "Across the Pacific, Samoan, Tongan, and Fijian choral singing is renowned, with powerful harmonies developed from both indigenous traditions and church music. Papua New Guinea, with over 800 languages, has an enormous variety of music, including garamut slit-drums and kundu hand drums."]],
  ["Survival and revival",[
    "Colonization often suppressed Indigenous music through bans on ceremonies, residential and mission schools, and loss of land and language. In Canada and the US, for example, some ceremonies such as the Potlatch and Sun Dance were legally restricted for decades.",
    "Today, Indigenous musicians are reclaiming and revitalizing traditions while creating contemporary music. Issues of cultural ownership, respect, and consent are central: some songs are sacred or private and not meant to be recorded or performed by outsiders."]]
  ],
  terms:[["Vocables","Song syllables without dictionary meaning."],["Powwow","Intertribal Native American gathering of song and dance."],["Songline","Aboriginal route across land recorded in song."],["Didgeridoo","Aboriginal wooden trumpet played with circular breathing."],["Haka","Māori posture dance with chant."]],
  w:"Indigenous musics carry some of the oldest knowledge on Earth and are being reclaimed as living traditions.",
  src:["Native American music","Songline","Didgeridoo","Music of Hawaii","Haka"],
  q:[
  ["What is a songline?","An Aboriginal route across land recorded in songs","A powwow drum circle","A Māori dance","A Hawaiian chant"],
  ["What breathing technique is used for the didgeridoo?","Circular breathing","Throat singing","Overblowing","Diaphragm pulsing"],
  ["The ukulele developed from instruments brought by immigrants from where?","Madeira (Portugal)","Spain","Mexico","Japan"],
  ["What is the haka?","A Māori posture dance with chant","A Hawaiian dance","An Aboriginal song","A Samoan drum"],
  ["Which Hawaiian singer's ukulele medley of 'Somewhere Over the Rainbow' became world famous?","Israel Kamakawiwo'ole","Gabby Pahinui","Don Ho","Keali'i Reichel"],
  ["What is katajjaq?","Inuit throat singing game","A Lakota drum","A Navajo chant","A Cree flute"]]}

);


/* ---- from music-20.js ---- */
/* MUSIC FOUNDATIONS, part 20: Unit 9 Musicianship in Depth, chapters 1-5 */
COURSES.music.units.push({ t:"Musicianship in Depth", ch:[

{ t:"Reading Rhythm Fluently", s:"Counting, subdividing, and sight-reading",
  sec:[
  ["Counting systems",[
    "Musicians count rhythm aloud to place notes precisely. In 4/4, quarter notes are counted '1, 2, 3, 4'; eighth notes '1 and 2 and' (written 1 + 2 +); sixteenths '1 e and a 2 e and a.' Triplet eighths are often counted '1 trip-let 2 trip-let' or '1 la li.' Some teachers use syllable systems such as Kodály's 'ta' and 'ti-ti' for children, or the Takadimi system used in many universities.",
    "The key skill is subdivision: feeling the smaller pulses inside each beat, so that long notes are held for their full value and syncopations land exactly."]],
  ["Dots, ties, and rests",[
    "A dot adds half the note's value: a dotted half note equals three quarter notes; a dotted quarter equals a quarter plus an eighth. A double dot adds half plus a quarter. A tie joins two notes of the same pitch into one longer sound, often across a bar line, where a dot cannot be used.",
    "Every note value has a matching rest. A whole rest hangs from the fourth staff line; a half rest sits on the third line ('a hat'). A whole rest is also used for an entire silent bar in any meter."]],
  ["Simple and compound meter",[
    "In simple meters (2/4, 3/4, 4/4), each beat divides into two. In compound meters (6/8, 9/8, 12/8), each beat is a dotted quarter divided into three; 6/8 is felt in two big beats, each with three eighths ('1 la li 2 la li'). Recognizing the difference between 3/4 (three beats, each split in two) and 6/8 (two beats, each split in three) is a classic skill; Leonard Bernstein's 'America' from West Side Story alternates between them.",
    "Cut time (2/2, shown as a C with a vertical line) counts the half note as the beat, common in marches and fast music."]],
  ["Tuplets and irregular groupings",[
    "Tuplets fit a number of notes into the time normally taken by a different number: triplets (three in the time of two), duplets in compound time, quintuplets, and septuplets. A 'three against two' polyrhythm, with one hand playing triplets and the other duplets, is a basic coordination skill for pianists and drummers.",
    "Irregular meters such as 5/4 or 7/8 are grouped into combinations of twos and threes: 7/8 may be 2+2+3 or 3+2+2. Beaming in the notation shows the grouping."]],
  ["Sight-reading",[
    "Sight-reading is playing or singing music at first sight. Good practices: first scan the piece for the key signature, time signature, tempo, repeats, and difficult passages; keep a steady tempo even if you miss notes, because rhythm matters more than individual pitches; and read ahead, looking at the next beat or bar while playing the current one.",
    "Daily sight-reading of easy material builds fluency faster than occasional attempts at hard pieces. Musicians recognize common patterns, scales, arpeggios, and rhythms as units, just as fluent readers recognize words rather than letters."]],
  ["The metronome",[
    "A metronome produces a steady click at a set number of beats per minute. Johann Maelzel patented the mechanical metronome in 1815, and Beethoven was among the first composers to give metronome markings (marked M.M. for Maelzel's Metronome).",
    "Practicing with a metronome, starting slowly and gradually increasing speed, builds steady time. Many musicians also practice with the click on only beats 2 and 4, or only once per bar, to strengthen their internal sense of pulse."]]
  ],
  terms:[["Subdivision","Feeling smaller pulses within a beat."],["Tie","Curved line joining notes of the same pitch."],["Compound meter","Meter whose beats divide into three."],["Tuplet","Group of notes fitted into an unusual span of time."],["Sight-reading","Performing music at first sight."]],
  w:"Rhythmic reading is the foundation of ensemble playing; without it, even the right notes sound wrong.",
  src:["Counting (music)","Dotted note","Compound meter","Tuplet","Metronome"],
  q:[
  ["How long is a dotted half note in quarter notes?","Three","Two","Four","Two and a half"],
  ["How is 6/8 usually felt?","Two beats, each divided into three","Six equal strong beats","Three beats divided in two","Eight beats"],
  ["What does a tie do?","Joins two notes of the same pitch into one sound","Shortens a note","Connects different pitches smoothly","Repeats a note"],
  ["Who patented the mechanical metronome in 1815?","Johann Maelzel","Beethoven","Bartolomeo Cristofori","Theobald Boehm"],
  ["How are sixteenth notes commonly counted in a beat?","1 e and a","1 and 2 and","1 la li","Ta ti ti"],
  ["When sight-reading, what is most important to keep?","A steady rhythm","Every single correct pitch","A slow tempo at all costs","Maximum volume"]]},

{ t:"Ear Training", s:"Hearing what you see, writing what you hear",
  sec:[
  ["Why train the ear",[
    "Ear training (aural skills) develops the ability to recognize pitches, intervals, chords, rhythms, and structures by hearing alone. It helps musicians play in tune, learn music by ear, improvise, transcribe, and understand what they hear.",
    "Most people have relative pitch, the ability to judge pitches in relation to each other, which can be greatly improved by practice. A small minority have absolute (perfect) pitch, the ability to name or sing a note without reference; it is more common among people who began musical training very early and among speakers of tonal languages such as Mandarin."]],
  ["Recognizing intervals",[
    "A common technique is associating intervals with familiar songs. Ascending examples often used in English-speaking countries: minor second, the 'Jaws' theme; major second, 'Happy Birthday' (first two different notes); minor third, 'Greensleeves'; major third, 'When the Saints Go Marching In'; perfect fourth, 'Here Comes the Bride'; tritone, 'Maria' from West Side Story; perfect fifth, 'Twinkle, Twinkle, Little Star' (first leap) or the Star Wars main theme; major sixth, 'My Bonnie Lies Over the Ocean'; minor seventh, 'Somewhere' from West Side Story; octave, 'Somewhere Over the Rainbow.'",
    "Eventually musicians learn to hear the intervals' qualities directly: the bright stability of a major third, the hollow openness of a fifth, the tension of a tritone."]],
  ["Chords and progressions",[
    "Training to recognize chord quality starts with triads: major (bright), minor (dark), diminished (tense, small), and augmented (unsettled, expanding). Then seventh chords: dominant seventh (bluesy, wanting to resolve), major seventh (soft, dreamy), minor seventh (mellow), half-diminished, and diminished seventh (dramatic, used for suspense in silent films).",
    "Hearing the bass line is the key to identifying progressions: listen for the root movement, such as the strong fall from V to I, or the move to IV that often begins a chorus."]],
  ["Solfège and scale degrees",[
    "Singing with solfège (do–re–mi) builds a sense of each scale degree's function. In movable do, do is always the tonic of the current key, so each syllable has a stable 'feeling': ti leads strongly up to do, fa tends to fall to mi, and so on. Fixed do, used in France, Italy, and Spain, assigns do permanently to C.",
    "Singing melodies from notation (sight-singing) and singing back phrases heard (call and response practice) build the connection between ear, voice, and eye."]],
  ["Dictation and transcription",[
    "Melodic dictation is writing down a melody after hearing it; harmonic dictation is writing the chords. Students start with short phrases, first identifying the meter and rhythm, then the starting note, contour, and intervals.",
    "Transcribing recordings by ear, writing down a solo or a song, is a classic method for jazz and popular musicians. Many great improvisers learned by transcribing solos of players they admired, absorbing their vocabulary note by note."]],
  ["Practice tools",[
    "Apps and websites offer interval, chord, and rhythm drills. Singing scales and arpeggios daily, playing melodies by ear on an instrument, and humming bass lines along with songs are simple, effective methods.",
    "Like a language, the ear develops with consistent short practice: ten minutes a day is more effective than an hour once a week."]]
  ],
  terms:[["Relative pitch","Judging pitches in relation to each other."],["Absolute pitch","Naming a note without any reference."],["Movable do","Solfège system where do is the tonic of the key."],["Dictation","Writing down music after hearing it."],["Transcription","Notating a recorded performance by ear."]],
  w:"A trained ear lets you understand, learn, and create music far faster than notation alone.",
  src:["Ear training","Absolute pitch","Relative pitch","Solfège","Transcription (music)"],
  q:[
  ["Which song is commonly used to learn the ascending perfect fourth?","Here Comes the Bride","Jaws","Somewhere Over the Rainbow","My Bonnie Lies Over the Ocean"],
  ["What is absolute pitch?","Naming a note without any reference","Judging pitches relative to others","Singing perfectly in tune","Hearing very high frequencies"],
  ["In movable do, what is 'do'?","The tonic of the current key","Always C","Always A","The highest note"],
  ["Which chord is often described as dramatic and suspenseful, used in silent films?","Diminished seventh","Major seventh","Major triad","Minor seventh"],
  ["Which interval is associated with 'Maria' from West Side Story?","Tritone","Perfect fifth","Octave","Minor third"],
  ["What is melodic dictation?","Writing down a melody after hearing it","Singing a written melody","Composing a melody","Memorizing lyrics"]]},

{ t:"Counterpoint and Voice Leading", s:"How lines move together",
  sec:[
  ["The art of combining lines",[
    "Counterpoint (from Latin punctus contra punctum, 'note against note') is the art of writing independent melodic lines that sound good together. Voice leading is the practice of moving each voice (part) smoothly from one chord to the next.",
    "Even in simple songs, good voice leading makes chords connect gracefully; in Bach, counterpoint becomes the substance of the music."]],
  ["Species counterpoint",[
    "In 1725 the Austrian theorist Johann Joseph Fux published Gradus ad Parnassum ('Steps to Parnassus'), a textbook in dialogue form that taught counterpoint in five 'species' modeled on Palestrina's style. Mozart, Haydn, and Beethoven studied it, and it is still used today.",
    "First species: note against note. Second species: two notes against one. Third species: four against one. Fourth species: syncopations and suspensions. Fifth species: florid counterpoint combining all. Each species adds new possibilities and rules."]],
  ["Types of motion",[
    "Between two voices, there are four types of motion: parallel (both move in the same direction by the same interval), similar (same direction, different intervals), contrary (opposite directions), and oblique (one voice stays while the other moves). Contrary motion gives the greatest independence.",
    "Traditional rules forbid parallel perfect fifths and octaves between voices, because they make two lines sound like one, reducing independence. Hidden (direct) fifths and octaves in outer voices are also restricted. Popular music and impressionist composers often break these rules deliberately for effect."]],
  ["Dissonance treatment",[
    "In strict style, dissonances must be handled carefully. A passing tone fills in a gap stepwise between two consonant notes; a neighbor tone steps away and returns; a suspension holds a note over from the previous chord into a new one where it becomes dissonant, then resolves down by step, creating expressive tension and release (as in the common 4–3 suspension).",
    "An appoggiatura is a dissonance on a strong beat, approached by leap and resolved by step, often heard as a 'sigh.'"]],
  ["Voice leading in harmony",[
    "In four-part harmony (soprano, alto, tenor, bass), good voice leading means: keep common tones between chords in the same voice; move other voices by the smallest possible interval; resolve tendency tones (the leading tone rises to the tonic, the seventh of a chord falls by step); avoid voice crossing; and keep voices within their ranges with no more than an octave between adjacent upper voices.",
    "Bach's chorales are the classic model for studying four-part voice leading, and students still learn by writing and analyzing them."]],
  ["Imitation and canon",[
    "Imitation occurs when one voice repeats a melody introduced by another. A canon is strict imitation throughout; a round, such as 'Row, Row, Row Your Boat' or 'Frère Jacques,' is a canon that can repeat indefinitely. Pachelbel's Canon in D is a canon for three violins over a repeating bass.",
    "The fugue, the most elaborate imitative form, introduces a subject in each voice in turn, with an answer at the fifth, a countersubject, episodes, and often stretto, where entries overlap closely to build intensity."]]
  ],
  terms:[["Voice leading","Smooth movement of individual parts between chords."],["Species counterpoint","Fux's graded method of learning counterpoint."],["Contrary motion","Voices moving in opposite directions."],["Suspension","Held note creating dissonance that resolves down."],["Canon","Strict imitation of one voice by another."]],
  w:"Counterpoint and voice leading are what make harmony sound smooth and inevitable; every arranger uses them.",
  src:["Counterpoint","Voice leading","Gradus ad Parnassum","Nonchord tone","Canon (music)"],
  q:[
  ["Who wrote Gradus ad Parnassum (1725)?","Johann Joseph Fux","J. S. Bach","Jean-Philippe Rameau","Guido of Arezzo"],
  ["Which motion gives voices the greatest independence?","Contrary motion","Parallel motion","Similar motion","No motion"],
  ["Why are parallel fifths traditionally avoided?","They make two lines sound like one","They are too dissonant","They are too high","They are hard to sing"],
  ["What is a suspension?","A held note creating dissonance that resolves down","A long rest","A held chord at the end","A sudden key change"],
  ["Which of these is a round?","Frère Jacques","Greensleeves","Ode to Joy","Amazing Grace"],
  ["What does the leading tone usually do?","Rise to the tonic","Fall to the dominant","Stay still","Jump an octave"]]},

{ t:"Chromatic Harmony and Modulation", s:"Color beyond the key",
  sec:[
  ["Secondary dominants",[
    "A secondary dominant is a dominant chord that 'tonicizes' a chord other than the tonic, briefly treating it as a temporary home. In C major, D major (or D7) is the 'V of V,' written V/V, leading strongly to G. E7 is V/vi, leading to A minor; C7 is V/IV, leading to F.",
    "Secondary dominants add color and forward motion, and are extremely common in classical music, jazz, gospel, and pop, for example in the 'Ragtime progression' (E7–A7–D7–G7–C)."]],
  ["Borrowed chords and modal mixture",[
    "Modal mixture means borrowing chords from the parallel minor (or major) key. In C major, borrowed chords include F minor (iv), A-flat major (♭VI), B-flat major (♭VII), and E-flat major (♭III). The minor iv chord gives a bittersweet, nostalgic feeling.",
    "The ♭VI–♭VII–I progression, heard in many rock anthems and video game victory themes, and the 'backdoor' ♭VII–I cadence are popular examples. The Picardy third, ending a minor-key piece on a major chord, is a Baroque form of mixture."]],
  ["Special chromatic chords",[
    "The Neapolitan sixth is a major chord built on the lowered second degree (in C minor, D-flat major), usually in first inversion, leading to V; it has a dark, poignant color. Augmented sixth chords (Italian, French, and German types) contain an augmented sixth interval whose notes expand outward by step to an octave on the dominant.",
    "The diminished seventh chord is symmetrical, built entirely of minor thirds, so it can resolve to many different keys, making it a powerful tool for surprising modulations."]],
  ["Modulation",[
    "Modulation is changing from one key to another. The most common modulations are to closely related keys, which differ by at most one sharp or flat: the dominant, subdominant, relative minor or major, and their relatives.",
    "Techniques include the pivot chord (a chord that belongs to both keys, reinterpreted), direct or 'phrase' modulation (simply starting a new phrase in the new key), chromatic modulation (moving through a chromatic voice-leading step), and enharmonic modulation (respelling a chord, such as a diminished seventh or German sixth, to land in a distant key)."]],
  ["The 'truck driver's' key change",[
    "In pop music, a sudden key change up a half or whole step for the final chorus adds excitement; critics nicknamed it the 'truck driver's gear change.' Examples include Whitney Houston's 'I Will Always Love You,' Bon Jovi's 'Livin' on a Prayer,' and Michael Jackson's 'Man in the Mirror.'",
    "Classical composers modulate far more widely: Schubert's sudden shifts to keys a third away (chromatic mediants) create magical, dreamlike effects, a technique later central to film music."]],
  ["Chromatic mediants and beyond",[
    "Chromatic mediants are chords whose roots are a third apart but not in the same key, such as C major to E major or C major to A-flat major. They share one common tone and sound striking, heroic, or otherworldly; film composers such as John Williams and Hans Zimmer use them constantly.",
    "Late Romantic composers stretched chromatic harmony toward the dissolution of tonality, and jazz developed its own sophisticated chromatic language, the subject of the next chapter."]]
  ],
  terms:[["Secondary dominant","Dominant chord of a chord other than the tonic."],["Modal mixture","Borrowing chords from the parallel key."],["Neapolitan sixth","Major chord on the lowered second degree."],["Pivot chord","Chord shared by two keys, used to modulate."],["Chromatic mediant","Chord a third away outside the key."]],
  w:"Chromatic harmony and modulation create much of music's color and emotional surprise, from Schubert to film scores.",
  src:["Secondary dominant","Borrowed chord","Neapolitan chord","Modulation (music)","Chromatic mediant"],
  q:[
  ["In C major, what is V/V?","D major","G major","A minor","F major"],
  ["What is modal mixture?","Borrowing chords from the parallel key","Using two modes at once","Changing meter","Mixing instruments"],
  ["On which degree is the Neapolitan chord built?","Lowered second degree","Raised fourth degree","Fifth degree","Seventh degree"],
  ["What is a pivot chord?","A chord belonging to both old and new keys","A chord that never resolves","A chord played by the bass","A chord with a missing third"],
  ["What is the Picardy third?","Ending a minor piece on a major chord","A French cadence","A third chord in a progression","A diminished third"],
  ["What nickname describes a sudden pop key change up for the last chorus?","Truck driver's gear change","Backdoor cadence","Deceptive cadence","Picardy shift"]]},

{ t:"Jazz Harmony and Improvisation", s:"Changes, scales, and vocabulary",
  sec:[
  ["Chord symbols and extensions",[
    "Jazz and popular musicians read chords as symbols: Cmaj7 (C–E–G–B), C7 (dominant: C–E–G–B♭), Cm7 (C–E♭–G–B♭), Cm7♭5 or Cø (half-diminished), and Cdim7 or C°7. Extensions add the 9th, 11th, and 13th: C9, Cm11, C13. Alterations such as ♭9, ♯9, ♯11, and ♭13 add tension, mostly on dominant chords; the 'Hendrix chord' is a 7♯9.",
    "A lead sheet gives only the melody and chord symbols, and musicians create their own voicings and accompaniment."]],
  ["The ii–V–I",[
    "The ii–V–I progression (in C: Dm7–G7–Cmaj7) is the basic building block of jazz harmony; tunes are often chains of ii–Vs moving through different keys. In minor keys, the progression is iiø7–V7(♭9)–i.",
    "Tritone substitution replaces a dominant chord with the dominant a tritone away (D♭7 instead of G7), because both share the same tritone (B and F); this creates a chromatic bass line descending to the tonic."]],
  ["Voicings and guide tones",[
    "The third and seventh of a chord, called guide tones, define its quality. Pianists and guitarists often voice chords using guide tones plus extensions, leaving the root to the bass. 'Rootless' voicings, popularized by Bill Evans, and 'shell' voicings (root, third, seventh) are fundamental.",
    "Smooth guide-tone lines, where the seventh of one chord moves down a half step to the third of the next, make ii–V–I progressions flow."]],
  ["Chord-scale theory",[
    "A practical approach to improvisation pairs chords with scales: Dorian mode over minor seventh chords, Mixolydian over dominant sevenths, Ionian or Lydian over major sevenths, Locrian over half-diminished. Altered dominants use the altered scale (the seventh mode of melodic minor); diminished chords use the symmetrical diminished scale. The blues scale and pentatonic scales work over many contexts.",
    "This approach, codified in the 1950s–70s (George Russell's Lydian Chromatic Concept, Jamey Aebersold's play-along records), is a useful map, but great improvisers also think melodically, rhythmically, and in phrases, not just scales."]],
  ["Building vocabulary",[
    "Jazz is often compared to a language: improvisers learn 'licks' and phrases from recordings, practice them in all twelve keys, and combine them creatively. Techniques include targeting chord tones on strong beats, approach notes (chromatic notes leading to targets), enclosures (surrounding a target note from above and below), and motivic development, as Sonny Rollins famously did.",
    "Rhythm is as important as notes: swing feel, phrasing across bar lines, rests, and dynamics distinguish great soloists."]],
  ["Form and the repertoire",[
    "Most jazz standards use forms such as the 32-bar AABA ('I Got Rhythm,' whose changes, called 'rhythm changes,' underlie countless tunes), 32-bar ABAC, and the 12-bar blues. Musicians memorize hundreds of tunes and 'comp' (accompany) one another, listening and responding in real time.",
    "Jam sessions, where musicians gather to play standards together, are a traditional way to learn and build community."]]
  ],
  terms:[["Lead sheet","Melody with chord symbols."],["ii–V–I","Jazz's core progression."],["Tritone substitution","Replacing a dominant with one a tritone away."],["Guide tones","Third and seventh defining a chord."],["Comping","Accompanying a soloist with chords."]],
  w:"Jazz harmony is the language of modern pop, gospel, R&B, and film music; improvisation trains real-time creativity.",
  src:["Jazz harmony","ii–V–I progression","Tritone substitution","Chord-scale system","Jazz improvisation"],
  q:[
  ["What are the notes of a C7 chord?","C–E–G–B♭","C–E–G–B","C–E♭–G–B♭","C–E♭–G♭–A"],
  ["What is the basic jazz progression in C major?","Dm7–G7–Cmaj7","C–F–G","Am–F–C–G","C–Am–F–G"],
  ["What is a tritone substitution for G7?","D♭7","D7","C7","F7"],
  ["Which mode is typically used over a minor seventh chord in chord-scale theory?","Dorian","Lydian","Locrian","Phrygian"],
  ["What are guide tones?","The third and seventh of a chord","The root and fifth","The highest notes","Passing tones"],
  ["What are 'rhythm changes'?","The chord progression of 'I Got Rhythm'","Changes of meter","A drum technique","A swing rhythm"]]}

]});


/* ---- from music-21.js ---- */
/* MUSIC FOUNDATIONS, part 21: Unit 9 chapters 6-10 */
COURSES.music.units[8].ch.push(

{ t:"Melody and Composition", s:"Crafting musical ideas",
  sec:[
  ["What makes a good melody",[
    "Memorable melodies usually balance repetition and variety, steps and leaps, tension and release. Most melodies move mainly by step, with occasional leaps that are often followed by a step in the opposite direction ('gap-fill'). A clear high point, the climax, usually occurs once, often about two-thirds of the way through.",
    "Melodies have a contour, an overall shape: arch, rising, falling, or wave. Rhythm is as important as pitch: a distinctive rhythm makes a melody recognizable even when tapped."]],
  ["Motifs and development",[
    "A motif is the smallest meaningful musical idea, such as the four-note opening of Beethoven's Fifth Symphony. Composers develop motifs through repetition, sequence (repeating at a different pitch level), inversion (turning upside down), retrograde (backward), augmentation (longer note values), diminution (shorter values), fragmentation (using only part), and changes of harmony or orchestration.",
    "Developing a few ideas thoroughly gives unity; many great works grow from tiny seeds."]],
  ["Phrases and periods",[
    "Melodies are organized into phrases, musical sentences usually four or eight bars long, ending in cadences. A period pairs an antecedent phrase (ending inconclusively, often on a half cadence) with a consequent phrase (ending conclusively on an authentic cadence), like question and answer.",
    "The 'sentence' structure, identified by Schoenberg and his students, presents a basic idea, repeats it, then continues with fragmentation and acceleration toward a cadence; it is common in Classical themes and in pop melodies."]],
  ["Harmonizing a melody",[
    "To harmonize a melody, a composer chooses chords containing the important (usually strong-beat) melody notes, considering where cadences fall. Most simple melodies can be harmonized with I, IV, and V; richer harmonizations use ii, vi, secondary dominants, and inversions for a smoother bass.",
    "Reharmonization, changing the chords under an existing melody, is a powerful creative tool used by jazz arrangers and film composers to give familiar tunes new emotional colors."]],
  ["Ways to start composing",[
    "Composers begin in many ways: from a melody, a chord progression, a rhythm or groove, a text, a sound, a structural plan, or an image or story. Constraints help creativity, for example writing a piece for only three instruments, using only one scale, or setting a short poem.",
    "Practical habits include recording or writing down every idea, working regularly, studying and imitating admired pieces (as composers have done for centuries), and finishing pieces even if imperfect."]],
  ["Tools of the trade",[
    "Composers use pencil and manuscript paper, notation software (such as Sibelius, Finale, Dorico, or the free MuseScore), and digital audio workstations with virtual instruments that let them hear ideas immediately.",
    "Knowing instrument ranges, idiomatic writing, and how to prepare clear parts for performers remains essential. Many composers also learn by orchestrating piano pieces and arranging songs for different ensembles."]]
  ],
  terms:[["Motif","Smallest meaningful musical idea."],["Sequence","Repeating a pattern at a different pitch level."],["Period","Antecedent and consequent phrases forming a unit."],["Contour","The overall shape of a melody."],["Reharmonization","Changing the chords beneath a melody."]],
  w:"Understanding how melodies and motifs work lets you write your own music and hear the craft in others'.",
  src:["Melody","Motif (music)","Phrase (music)","Musical composition","Sequence (music)"],
  q:[
  ["What is a motif?","The smallest meaningful musical idea","A full song","A chord progression","A tempo marking"],
  ["What is a sequence in music?","Repeating a pattern at a different pitch level","Playing notes in order","A list of songs","A rhythmic cycle"],
  ["What is augmentation?","Lengthening the note values of a motif","Adding more instruments","Raising the pitch","Adding a chord"],
  ["In a period, what is the antecedent phrase?","The 'question' phrase ending inconclusively","The concluding phrase","The introduction","The bridge"],
  ["What is reharmonization?","Changing the chords beneath a melody","Transposing a melody","Rewriting lyrics","Adding a countermelody"],
  ["Which free notation software is popular with composers?","MuseScore","Pro Tools","Ableton Live","Garage Band"]]},

{ t:"Arranging and Orchestration", s:"Dressing the music",
  sec:[
  ["Arranging versus composing",[
    "Arranging is adapting existing music for a particular ensemble or style: a pop song for string quartet, a folk tune for choir, a standard for big band. Orchestration is assigning the parts of a composition to the instruments of an orchestra (or other ensemble). Both require knowing what each instrument can do and how it sounds in each register.",
    "Famous arrangers include Nelson Riddle (for Frank Sinatra), Gil Evans (for Miles Davis), Quincy Jones, and George Martin; famous orchestrators include Ravel and Rimsky-Korsakov."]],
  ["Ranges and registers",[
    "Every instrument has a playable range and registers with different colors: the flute is weak and breathy low, bright high; the clarinet's low chalumeau register is dark and rich; the cello sings beautifully in its tenor register; the trumpet becomes brilliant and strained very high. Writing in an instrument's comfortable middle register is safest; extremes are for special effects.",
    "Singers' ranges vary; arrangers choose keys to fit them, and often a song must be transposed for a different singer."]],
  ["Transposing instruments",[
    "Some instruments are written at a different pitch than they sound. A B♭ clarinet or trumpet sounds a whole step lower than written: written C sounds B♭. The French horn in F sounds a perfect fifth lower than written; the alto saxophone (in E♭) sounds a major sixth lower. Piccolo, glockenspiel, and guitar are written an octave away from sounding pitch for convenience of reading.",
    "A conductor's score may be written 'in C' (concert pitch) or transposed; arrangers must prepare correctly transposed parts."]],
  ["Voicing and balance",[
    "Voicing is how the notes of a chord are distributed among instruments. Close voicing keeps notes within an octave; open voicing spreads them out. Wider spacing usually sounds better low down, since close low chords sound muddy, so arrangers follow the natural 'harmonic series' spacing: wide intervals in the bass, closer near the top.",
    "Balance means ensuring the melody is heard: brass can overpower strings; one trumpet equals several violins in volume. Doubling a line at the unison or octave in different instruments creates new blended colors, such as the classic flute-and-violin or clarinet-and-viola combinations."]],
  ["Texture and roles",[
    "In most arrangements, instruments take on roles: melody, countermelody, harmony pads (sustained chords), rhythmic accompaniment, and bass. Clarity comes from not having too many things competing in the same register at once.",
    "Contrast keeps listeners engaged: thinning the texture for a verse, adding instruments for the chorus, saving the full ensemble for the climax, and changing the instrument carrying the melody when it repeats. Ravel's Boléro is essentially a lesson in orchestration, repeating one melody with ever-changing colors."]],
  ["Writing for voices",[
    "Choral arranging uses SATB or other groupings. Arrangers consider text clarity, breath points, comfortable ranges, and the blend of voices. Close harmony for vocal groups, from barbershop to a cappella pop, places voices near one another for a ringing sound.",
    "Backing vocal arrangements in pop, such as the Beach Boys' or Queen's stacked harmonies, use overdubbing to create walls of voices."]]
  ],
  terms:[["Arranging","Adapting music for a particular ensemble or style."],["Transposing instrument","Instrument whose written pitch differs from its sound."],["Concert pitch","Actual sounding pitch."],["Voicing","Distribution of chord notes among parts."],["Doubling","Two instruments playing the same line."]],
  w:"Arranging and orchestration turn a simple tune into a full musical experience; they are the hidden craft behind every great recording.",
  src:["Arrangement","Orchestration","Transposing instrument","Voicing (music)","Concert pitch"],
  q:[
  ["How does a written C sound on a B♭ trumpet?","As B♭","As C","As F","As E♭"],
  ["What is concert pitch?","The actual sounding pitch","The pitch for concerts only","Pitch of A = 440","The highest pitch"],
  ["Why are close voicings avoided in the low register?","They sound muddy","They are too loud","They are too high","They are out of tune"],
  ["Which arranger worked famously with Frank Sinatra?","Nelson Riddle","Gil Evans","George Martin","Quincy Jones only"],
  ["How much lower than written does the French horn in F sound?","A perfect fifth","A whole step","An octave","A major sixth"],
  ["Which piece is often cited as a lesson in orchestration?","Ravel's Boléro","Bach's Goldberg Variations","Chopin's Nocturnes","Cage's 4′33″"]]},

{ t:"Recording and Production", s:"From microphone to master",
  sec:[
  ["The signal chain",[
    "Recording converts sound into an electrical signal and then into digital data. A typical signal chain: the sound source, a microphone, a preamplifier (to boost the weak mic signal), an analog-to-digital converter in the audio interface, and the digital audio workstation (DAW). Playback reverses the process through a digital-to-analog converter and speakers or headphones.",
    "CD-quality audio uses a sample rate of 44.1 kHz (44,100 measurements per second) and 16-bit depth; studios often record at 48 or 96 kHz and 24 bits."]],
  ["Microphones",[
    "Dynamic microphones, such as the Shure SM57 and SM58, are rugged and handle loud sources like drums, guitar amps, and live vocals. Condenser microphones are more sensitive and detailed, used for studio vocals, acoustic instruments, and overheads; they need power (phantom power). Ribbon microphones have a smooth, warm sound.",
    "Polar patterns describe directional sensitivity: cardioid (heart-shaped, picks up the front), omnidirectional (all around), and figure-8 (front and back). Mic placement, distance and angle, changes the sound dramatically, as does the room."]],
  ["The producer and engineer",[
    "The recording engineer operates the equipment and captures sound; the producer guides the creative process, choosing songs, shaping arrangements, coaching performances, and overseeing the final result, somewhat like a film director. Legendary producers include George Martin, Quincy Jones, Phil Spector, Brian Eno, Rick Rubin, Dr. Dre, and Max Martin.",
    "In hip-hop and electronic music, the 'producer' often creates the instrumental track itself."]],
  ["Mixing",[
    "Mixing combines and balances all the recorded tracks. The main tools: volume faders for level; panning to place sounds left to right in the stereo field; equalization (EQ) to boost or cut frequency ranges, carving space so instruments do not mask each other; compression to reduce dynamic range so quiet parts are audible and loud parts controlled; and time-based effects such as reverb (simulating a space) and delay (echo).",
    "A typical mix places the kick drum, bass, snare, and lead vocal in the center, with other instruments spread around them. Automation lets settings change over the course of the song."]],
  ["Mastering and loudness",[
    "Mastering is the final stage, preparing the mix for release: overall EQ, compression, limiting to raise loudness, consistent levels across an album, and formats for streaming, CD, or vinyl. Mastering engineers listen with fresh ears in specially treated rooms.",
    "From the 1990s to the 2000s, a 'loudness war' saw records mastered ever louder with heavy limiting, sacrificing dynamics; Metallica's Death Magnetic (2008) was a widely criticized example. Streaming services now normalize loudness (around −14 LUFS on Spotify), reducing the incentive to over-compress."]],
  ["Home recording",[
    "Today a laptop, an audio interface, a microphone, headphones, and a DAW can produce release-quality music. Billie Eilish and Finneas O'Connell recorded her Grammy-winning debut album largely in Finneas's bedroom.",
    "Basic tips: record in a quiet room with soft furnishings to reduce reflections, keep levels healthy without 'clipping' (digital distortion when the signal exceeds the maximum), use good headphones or monitors, take breaks to rest your ears, and compare your mix with professional reference tracks."]]
  ],
  terms:[["DAW","Digital audio workstation software."],["Condenser microphone","Sensitive mic needing phantom power."],["EQ","Equalization: adjusting frequency balance."],["Compression","Reducing the dynamic range of a signal."],["Mastering","Final preparation of a mix for release."]],
  w:"Almost all music you hear is shaped by production; these basics demystify how records are made.",
  src:["Sound recording and reproduction","Microphone","Audio mixing (recorded music)","Audio mastering","Loudness war"],
  q:[
  ["What is the sample rate of CD-quality audio?","44.1 kHz","22 kHz","96 kHz","192 kHz"],
  ["Which type of microphone needs phantom power?","Condenser","Dynamic","Ribbon (always)","Piezo"],
  ["What does compression do?","Reduces dynamic range","Removes noise","Adds echo","Changes pitch"],
  ["What is panning?","Placing sounds left to right in stereo","Adjusting volume over time","Adding reverb","Cutting low frequencies"],
  ["What was the 'loudness war'?","A trend of mastering records ever louder with heavy limiting","A legal dispute over noise","A rivalry between bands","A battle of the bands contest"],
  ["What is clipping?","Digital distortion when a signal exceeds the maximum","Editing a track","A drum technique","A short sample"]]},

{ t:"Practice and Performance", s:"Becoming a musician",
  sec:[
  ["Deliberate practice",[
    "Research by psychologist K. Anders Ericsson and others on expert performance suggests that improvement depends not just on hours, but on deliberate practice: focused work on specific weaknesses, with clear goals, immediate feedback, and gradual challenge. Popular claims of a fixed '10,000-hour rule' oversimplify this research; talent, starting age, teaching, and practice quality all matter.",
    "Effective practice usually means shorter, focused sessions rather than long, distracted ones; slow practice to build accuracy; isolating difficult passages; and regular review."]],
  ["Practice techniques",[
    "Musicians use techniques such as slow practice with a metronome, gradually increasing speed; 'chunking' passages into small units and linking them; practicing hands separately (on piano); varying rhythms of fast passages to secure each note; backward chaining (learning the end first); and recording themselves to listen critically.",
    "Interleaving, mixing different skills or pieces in a session, and spacing practice over days tend to improve long-term retention more than massed repetition, according to research on learning."]],
  ["Technique and health",[
    "Good technique uses the body efficiently: relaxed shoulders and hands, good posture, and avoiding excess tension. Musicians are prone to overuse injuries such as tendinitis and focal dystonia, so warming up, taking breaks, and stopping when in pain are important.",
    "Hearing protection matters: prolonged exposure to loud music can cause permanent hearing loss and tinnitus. Many professional musicians wear custom earplugs."]],
  ["Memorization",[
    "Musicians use several types of memory together: aural (hearing the music), kinesthetic or muscle memory (the feel of playing), visual (the score or the hands), and analytical (understanding the structure, harmony, and form). Relying on muscle memory alone is risky under pressure; analytical understanding provides a safety net.",
    "Clara Schumann and Franz Liszt helped establish the tradition of performing solo recitals from memory in the 19th century."]],
  ["Performance anxiety",[
    "Stage fright is extremely common, even among famous performers. Physical symptoms come from adrenaline: shaking, fast heartbeat, dry mouth. Strategies include thorough preparation, practicing performing for friends, slow breathing, focusing on the music's message rather than on mistakes, and reframing nervous energy as excitement.",
    "Some musicians work with teachers or psychologists on performance psychology. A mistake during performance is best handled by keeping going; audiences notice hesitation more than wrong notes."]],
  ["Ensemble skills",[
    "Playing with others requires listening, keeping steady time, matching dynamics, phrasing, and intonation, blending tone, watching for visual cues, and knowing your role, whether leading or supporting. Chamber musicians cue entrances with small breaths or head movements.",
    "Bands, choirs, orchestras, and informal jams offer social benefits and motivation. For adult learners, it is never too late: adults can learn instruments successfully, often with faster understanding of theory, even if young children absorb some skills more easily."]]
  ],
  terms:[["Deliberate practice","Focused practice on specific weaknesses with feedback."],["Chunking","Breaking music into small units to learn."],["Muscle memory","Learned physical patterns of playing."],["Performance anxiety","Stage fright caused by adrenaline."],["Intonation","Accuracy of pitch."]],
  w:"How you practice matters more than how long; these methods help anyone learn an instrument efficiently and healthily.",
  src:["Practice (learning method)","Deliberate practice","Stage fright","Musical memory","Focal dystonia"],
  q:[
  ["What is deliberate practice?","Focused work on weaknesses with goals and feedback","Practicing as many hours as possible","Playing only favorite pieces","Practicing with others"],
  ["Which psychologist is known for research on expert performance and deliberate practice?","K. Anders Ericsson","Daniel Levitin","Oliver Sacks","Howard Gardner"],
  ["What is the best response to a mistake during performance?","Keep going","Stop and restart","Apologize to the audience","Play louder"],
  ["Which type of memory gives a safety net under pressure?","Analytical memory of the structure","Muscle memory alone","Visual memory of the stage","Short-term memory"],
  ["What risk does prolonged loud music exposure pose?","Permanent hearing loss and tinnitus","Improved pitch","Better rhythm","None"],
  ["What is chunking?","Breaking music into small units to learn","Playing very loudly","Skipping hard passages","Playing with a metronome"]]},

{ t:"Learning an Instrument: A Roadmap", s:"From first notes to fluency",
  sec:[
  ["Choosing an instrument",[
    "The best instrument is one you love the sound of and will play. Practical factors include cost, portability, noise (headphone-compatible digital pianos and electric guitars help in apartments), physical comfort, and the music you want to play. Piano gives a clear view of harmony and is excellent for theory; guitar is portable and ideal for accompanying songs; voice requires no equipment; ukulele is an easy starting point.",
    "Band and orchestral instruments open doors to ensembles, and drums build rhythmic foundations."]],
  ["The first months",[
    "Early goals: correct posture and hand position, producing a good tone, basic reading or chord knowledge, and steady rhythm. Short daily practice, even 15 to 20 minutes, is far more effective than infrequent long sessions.",
    "A good teacher accelerates progress and prevents bad habits; online lessons, method books, and video tutorials can supplement or, for some, substitute. Learning pieces you enjoy keeps motivation high."]],
  ["Building fundamentals",[
    "Musicians across instruments practice scales and arpeggios in all keys, which build technique and familiarity with keys; etudes or exercises targeting specific skills; sight-reading; ear training and playing by ear; and repertoire, real pieces that combine these skills.",
    "Graded exam systems, such as those of ABRSM or Trinity College London (grades 1 to 8) and the Royal Conservatory of Music in Canada, provide structured goals for many students worldwide."]],
  ["Theory alongside playing",[
    "Theory makes sense when connected to what you play: identifying the key and chords of your pieces, analyzing song forms, and transposing simple melodies. Learning theory on a keyboard is helpful for all musicians, because the layout makes intervals and chords visible.",
    "Writing your own short pieces or songs, and improvising over simple progressions, reinforces theory and develops creativity."]],
  ["Plateaus and motivation",[
    "Progress is uneven; plateaus are normal. Changing routines, setting a performance goal, joining an ensemble, learning a new style, or taking a few lessons can break through. Recording yourself periodically shows how far you have come.",
    "Playing with others, at community bands, choirs, open mics, or jam sessions, is one of the most rewarding parts of music-making."]],
  ["Lifelong music-making",[
    "Research on music training suggests associations with benefits such as improved auditory processing and, in some studies, aspects of memory and attention, though claims that music makes people broadly 'smarter' (such as the 'Mozart effect' of listening to Mozart) have not held up well. The strongest reasons to play are enjoyment, expression, and community.",
    "Many musicians continue to learn throughout life, and active music-making in older age is associated with wellbeing and social connection."]]
  ],
  terms:[["Arpeggio","Notes of a chord played one after another."],["Etude","Study piece focused on a technique."],["Repertoire","Body of pieces a musician can perform."],["Graded exams","Structured levels such as ABRSM grades 1–8."],["Plateau","Period with little apparent progress."]],
  w:"A clear roadmap makes learning an instrument achievable at any age, turning listening into active music-making.",
  src:["Music education","Associated Board of the Royal Schools of Music","Mozart effect","Arpeggio","Music lesson"],
  q:[
  ["Which is more effective for beginners?","Short daily practice","One long weekly session","Practicing only before lessons","Only listening"],
  ["Which instrument is especially helpful for learning theory?","Keyboard/piano","Drums","Harmonica","Triangle"],
  ["What has research found about the 'Mozart effect'?","Broad intelligence claims have not held up well","It doubles IQ","It only works for children","It is proven for all music"],
  ["What do ABRSM grades provide?","Structured graded exam goals","Instrument rentals","Concert tickets","Recording contracts"],
  ["What is an arpeggio?","Notes of a chord played one after another","A fast scale","A type of trill","A Baroque dance"],
  ["What is a normal part of learning that can be overcome by changing routines?","Plateaus","Perfect pitch","Stage fright alone","Tone deafness"]]}

);


/* ---- from music-22.js ---- */
/* MUSIC FOUNDATIONS, part 22: extra classical chapters inserted into Unit 5 before "How to Listen" */
(function(){
const u=COURSES.music.units[4].ch;
const at=u.findIndex(c=>c.t==="How to Listen to Classical Music");
u.splice(at,0,

{ t:"Opera Since 1900", s:"New voices on the stage",
  sec:[
  ["Expressionism and realism",[
    "The 20th century began with operas that pushed emotion and dissonance to extremes: Strauss's Salome and Elektra, Schoenberg's one-woman monodrama Erwartung, and Berg's Wozzeck (1925), about a poor soldier driven to murder, which uses atonality within strict forms such as passacaglia and fugue. Leoš Janáček, from Moravia, wrote operas based on the rhythms of Czech speech, such as Jenůfa and The Cunning Little Vixen.",
    "Puccini's Turandot (1926) closed the great Italian tradition, and Debussy's Pelléas et Mélisande offered a hushed, Symbolist alternative."]],
  ["Weill and music theater",[
    "In Weimar Germany, Kurt Weill and playwright Bertolt Brecht created The Threepenny Opera (1928), a satirical reworking of The Beggar's Opera with jazz and cabaret styles; its 'Mack the Knife' became a pop standard. Brecht's 'epic theater' aimed to make audiences think critically rather than lose themselves in emotion.",
    "Weill fled Nazi Germany and wrote for Broadway. Gershwin's Porgy and Bess (1935) brought jazz and spirituals into American opera."]],
  ["Benjamin Britten",[
    "Benjamin Britten (1913–1976) revived English opera with Peter Grimes (1945), about an outsider fisherman persecuted by his village, with famous orchestral 'Sea Interludes.' He went on to write Billy Budd, The Turn of the Screw, A Midsummer Night's Dream, and Death in Venice, often with roles for his partner, tenor Peter Pears.",
    "Britten's War Requiem (1962), combining the Latin Mass with Wilfred Owen's World War I poems, was written for the consecration of the new Coventry Cathedral, built beside the ruins of the one bombed in 1940."]],
  ["Contemporary opera",[
    "Later decades brought minimalist operas by Philip Glass (Einstein on the Beach, Satyagraha, Akhnaten) and John Adams (Nixon in China, about Nixon's 1972 visit to China; The Death of Klinghoffer; Doctor Atomic). Thomas Adès (The Tempest, The Exterminating Angel), Kaija Saariaho (L'amour de loin, 2000), and George Benjamin (Written on Skin, 2012) are leading recent composers.",
    "In 2021, Terence Blanchard's Fire Shut Up in My Bones became the first opera by a Black composer performed at the Metropolitan Opera. Opera companies increasingly commission works on contemporary subjects and diverse stories."]],
  ["Opera on screen and stage",[
    "Opera reaches new audiences through cinema broadcasts, such as the Metropolitan Opera's 'Live in HD' series launched in 2006, and through innovative productions that reset classic operas in modern settings, sometimes controversially ('director's theater,' or Regietheater).",
    "Famous 20th-century singers include Enrico Caruso, one of the first recording stars; Maria Callas, celebrated for dramatic intensity; Luciano Pavarotti, Plácido Domingo, and José Carreras, the 'Three Tenors'; Leontyne Price, Jessye Norman, Joan Sutherland, Kiri Te Kanawa, and Anna Netrebko."]]
  ],
  terms:[["Expressionism","Art expressing extreme inner states."],["Epic theater","Brecht's critical, distancing theater."],["Monodrama","Opera for a single singer."],["Regietheater","Director-led reinterpretation of classic works."],["Live in HD","Met Opera cinema broadcasts since 2006."]],
  w:"Opera remains a living art, constantly reinventing itself with new subjects, styles, and technologies.",
  src:["Benjamin Britten","Peter Grimes","The Threepenny Opera","Nixon in China (opera)","Fire Shut Up in My Bones"],
  q:[
  ["Which Britten opera features the 'Sea Interludes'?","Peter Grimes","Billy Budd","Death in Venice","The Turn of the Screw"],
  ["Who wrote The Threepenny Opera with Brecht?","Kurt Weill","Paul Hindemith","Hanns Eisler","Alban Berg"],
  ["Which John Adams opera depicts a 1972 presidential visit?","Nixon in China","Doctor Atomic","The Death of Klinghoffer","El Niño"],
  ["Britten's War Requiem was written for the consecration of which cathedral?","Coventry Cathedral","St Paul's Cathedral","Westminster Abbey","Canterbury Cathedral"],
  ["Which opera became the first by a Black composer at the Met in 2021?","Fire Shut Up in My Bones","Porgy and Bess","Champion","X: The Life and Times of Malcolm X"],
  ["Which soprano was famous for dramatic intensity in the mid-20th century?","Maria Callas","Jessye Norman","Kiri Te Kanawa","Joan Sutherland"]]},

{ t:"Chamber Music", s:"The music of friends",
  sec:[
  ["What chamber music is",[
    "Chamber music is written for a small group of instruments, traditionally one player per part, originally intended for performance in a room ('chamber') of a home or palace rather than a large hall. Without a conductor, the players must listen closely, breathe together, and negotiate interpretation, which is why it has been called 'the music of friends.'",
    "Standard combinations include the duo sonata (often violin, cello, or wind instrument with piano), piano trio (piano, violin, cello), string trio, string quartet, piano quartet, piano quintet, string quintet, wind quintet, and octet."]],
  ["The string quartet",[
    "The string quartet, two violins, viola, and cello, is the most prestigious chamber genre. Haydn established it; Mozart dedicated six quartets to Haydn; Beethoven's 16 quartets, especially the late ones, are considered among the deepest works in music. Schubert's 'Death and the Maiden' quartet, Dvořák's 'American' Quartet, and the quartets of Bartók and Shostakovich are central to the repertoire.",
    "Famous ensembles include the Budapest, Juilliard, Amadeus, Emerson, Takács, and Kronos Quartets; Kronos, founded in 1973, commissioned over a thousand new works, many crossing into rock and world music."]],
  ["Piano and strings",[
    "Mixing piano with strings creates rich possibilities. Schubert's 'Trout' Quintet (piano, violin, viola, cello, double bass) uses his song 'The Trout' as a theme for variations. Schumann's Piano Quintet and Brahms's Piano Quintet and Piano Quartets are Romantic pillars.",
    "Beethoven's 'Archduke' Trio and Mendelssohn's Piano Trio No. 1 are favorites among piano trios, and violin sonatas by Beethoven ('Kreutzer'), Brahms, Franck, and Fauré are central to the violinist's repertoire."]],
  ["Winds and mixed ensembles",[
    "Mozart's Clarinet Quintet and Brahms's Clarinet Quintet show the clarinet's warmth with strings. The wind quintet (flute, oboe, clarinet, horn, bassoon) has repertoire by Reicha, Nielsen, and Ligeti.",
    "In the 20th century, mixed ensembles became common: Stravinsky's The Soldier's Tale, Schoenberg's Pierrot lunaire (whose instrumentation, the 'Pierrot ensemble,' became a standard grouping for new music), and Messiaen's Quartet for the End of Time (clarinet, violin, cello, piano)."]],
  ["Playing chamber music",[
    "Chamber music is a cornerstone of music education and amateur music-making; friends have gathered to play quartets at home for centuries. Players cue each other with breaths and gestures, balance their lines so the important voice is heard, and match articulation and vibrato.",
    "Festivals such as Marlboro (Vermont) and countless amateur workshops keep the tradition alive."]]
  ],
  terms:[["Chamber music","Music for small groups, one player per part."],["Piano quintet","Piano with string quartet."],["Wind quintet","Flute, oboe, clarinet, horn, bassoon."],["Pierrot ensemble","Flute, clarinet, violin, cello, piano (plus voice)."],["Duo sonata","Sonata for an instrument with piano."]],
  w:"Chamber music is the most intimate form of classical music, and the best way for amateurs to play great works together.",
  src:["Chamber music","String quartet","Trout Quintet","Piano trio","Kronos Quartet"],
  q:[
  ["Why is chamber music called 'the music of friends'?","Players must listen and cooperate without a conductor","It is only for amateurs","It is played at parties","It has no written parts"],
  ["Which Schubert work uses his song as a theme for variations?","Trout Quintet","Death and the Maiden","Winterreise","Unfinished Symphony"],
  ["Which quartet, founded in 1973, commissioned over a thousand new works?","Kronos Quartet","Juilliard Quartet","Amadeus Quartet","Emerson Quartet"],
  ["Which instruments make up a piano trio?","Piano, violin, cello","Piano, two violins","Piano, flute, cello","Three pianos"],
  ["Which 20th-century work gave its name to a standard new-music ensemble?","Pierrot lunaire","The Rite of Spring","Boléro","Pierrot le fou"],
  ["Which instrument appears in Mozart's and Brahms's famous quintets with strings?","Clarinet","Flute","Oboe","Horn"]]},

{ t:"Sacred Music Through the Ages", s:"Music for worship",
  sec:[
  ["The Mass",[
    "The Mass is the central Catholic service. Its fixed texts, the Ordinary, are Kyrie (Lord, have mercy), Gloria, Credo (the creed), Sanctus (Holy) with Benedictus, and Agnus Dei (Lamb of God). Composers have set these texts for over 600 years, from Machaut and Palestrina to Bach's Mass in B minor, Beethoven's Missa solemnis, and Leonard Bernstein's theatrical Mass (1971).",
    "The Requiem, the Mass for the dead, adds texts such as the Dies irae (Day of Wrath). Famous Requiems are by Mozart, Verdi (operatic and dramatic), Fauré (gentle and consoling), Brahms (A German Requiem, in German), Britten (War Requiem), and Duruflé."]],
  ["Protestant traditions",[
    "Lutheran music centered on the chorale, which Bach used in cantatas, Passions, and organ works. In England, the Anglican Church developed anthems and the choral evensong service, sung daily in cathedrals by choirs of boys (and now girls) and men; the Choir of King's College, Cambridge, famous for its Festival of Nine Lessons and Carols broadcast every Christmas Eve since 1928, embodies this tradition.",
    "Hymn singing flourished: Isaac Watts and Charles Wesley wrote thousands of hymns in the 18th century, and John Newton's 'Amazing Grace' (1779) became one of the most beloved songs in the world."]],
  ["Orthodox and other Christian music",[
    "Eastern Orthodox churches traditionally use unaccompanied voices, with Byzantine chant in Greece and rich choral harmony in Russia; Rachmaninoff's All-Night Vigil (1915) and Tchaikovsky's Liturgy are concert favorites. Ethiopian, Armenian, and Coptic churches have their own ancient chant traditions.",
    "In America, shape-note singing (Sacred Harp), using different note-head shapes to aid reading, preserves a powerful 18th–19th-century community singing style."]],
  ["Jewish music",[
    "Jewish liturgical music includes cantillation (chanting the Torah with melodic signs called trope), and the cantor (hazzan) who leads prayers in the synagogue. Melodies such as 'Kol Nidre,' sung on Yom Kippur, inspired Max Bruch's work for cello and orchestra.",
    "Jewish musical life also includes niggunim (wordless melodies of Hasidic tradition), Sephardic songs in Ladino, and klezmer."]],
  ["Islam, Hinduism, Buddhism, and more",[
    "In Islam, the call to prayer and Quran recitation are highly developed vocal arts; Sufi music, such as South Asian qawwali, made famous worldwide by Nusrat Fateh Ali Khan, uses music for spiritual ecstasy.",
    "Hindu devotional song (bhajan and kirtan) and Vedic chant are central to worship. Buddhist chant, from Tibetan monks' deep overtone chanting to Japanese shōmyō, supports meditation. Sikh worship centers on kirtan, singing hymns from the Guru Granth Sahib. Across faiths, music frames ritual, shapes community, and expresses the transcendent."]],
  ["Sacred music in concert",[
    "Many sacred works now live mainly in concert halls: Bach's Passions, Handel's Messiah, Haydn's Creation, and the Requiems of Mozart and Verdi. Contemporary composers such as Arvo Pärt, John Tavener, and James MacMillan continue to write sacred music for both churches and concerts.",
    "Even listeners without religious belief often find these works deeply moving, a sign of music's power to express what lies beyond words."]]
  ],
  terms:[["Mass Ordinary","Kyrie, Gloria, Credo, Sanctus, Agnus Dei."],["Requiem","Mass for the dead."],["Evensong","Anglican evening choral service."],["Cantillation","Chanting of scripture with melodic signs."],["Qawwali","Sufi devotional music of South Asia."]],
  w:"Much of the world's greatest music was written for worship, and sacred traditions still shape music everywhere.",
  src:["Mass (music)","Requiem","Choral evensong","Amazing Grace","Qawwali"],
  q:[
  ["Which is NOT part of the Mass Ordinary?","Dies irae","Kyrie","Gloria","Agnus Dei"],
  ["Which Requiem is known for its gentle, consoling character?","Fauré's","Verdi's","Berlioz's","Britten's"],
  ["Which choir's Christmas Eve carol service has been broadcast since 1928?","King's College, Cambridge","Westminster Abbey","St Paul's Cathedral","Vienna Boys' Choir"],
  ["Who wrote 'Amazing Grace'?","John Newton","Charles Wesley","Isaac Watts","Martin Luther"],
  ["Which singer made qawwali famous worldwide?","Nusrat Fateh Ali Khan","Ravi Shankar","Abida Parveen","A. R. Rahman"],
  ["Which Rachmaninoff work is a setting of Orthodox liturgy?","All-Night Vigil","The Bells","Isle of the Dead","Symphonic Dances"]]}

);
})();


/* ---- from music-23.js ---- */
/* MUSIC FOUNDATIONS, part 23: extra popular-music chapters inserted into Unit 7 */
(function(){
const u=COURSES.music.units[6].ch;
const after=(title,ch)=>{const i=u.findIndex(c=>c.t===title);u.splice(i+1,0,ch);};

after("The Nineties",
{ t:"Heavy Metal and Its Branches", s:"Loud, fast, and endlessly inventive",
  sec:[
  ["Foundations",[
    "Heavy metal grew from late-1960s blues rock and psychedelia, with bands like Cream, Jimi Hendrix, Led Zeppelin, and Deep Purple pushing volume and distortion. Black Sabbath's 1970 debut from Birmingham is widely considered the first true metal album: Tony Iommi's slow, doom-laden riffs, built often on the tritone (once called the 'devil's interval'), set the template.",
    "Metal's musical basics include heavily distorted guitars, power chords (root and fifth only, which sound clear under distortion), palm-muted riffs, virtuosic guitar solos, powerful drumming including double bass drums, and themes ranging from fantasy and mythology to war, alienation, and social critique."]],
  ["The 1980s",[
    "The New Wave of British Heavy Metal (about 1979–83), led by Iron Maiden and Judas Priest, added speed, twin-guitar harmonies, and operatic vocals. In Los Angeles, 'glam' or 'hair metal' bands such as Mötley Crüe, Def Leppard, and Bon Jovi dominated MTV with catchy anthems and power ballads, and Guns N' Roses' Appetite for Destruction (1987) brought back grit.",
    "Thrash metal, faster and more aggressive, emerged in the San Francisco Bay Area and elsewhere: the 'Big Four' of Metallica, Slayer, Megadeth, and Anthrax. Metallica's Master of Puppets (1986) and self-titled 'Black Album' (1991) made them one of the best-selling bands of all time."]],
  ["Extreme metal",[
    "Death metal (Death, Morbid Angel, Cannibal Corpse) uses growled vocals, blast beats (extremely fast drum patterns), and complex riffs; Florida was an early center. Black metal, centered in early-1990s Norway (Mayhem, Darkthrone, Emperor), used tremolo-picked guitars, shrieked vocals, and lo-fi production, and became notorious for crimes by some members, including church arsons.",
    "Doom metal slows everything down; grindcore makes songs seconds long; and Scandinavian melodic death metal (In Flames, At the Gates) brought melody back."]],
  ["Later branches",[
    "Nu metal (Korn, Limp Bizkit, Linkin Park, whose Hybrid Theory sold enormously) combined metal with hip-hop in the late 1990s. Progressive metal (Dream Theater, Tool, Opeth, Meshuggah, whose polyrhythmic, low-tuned style inspired 'djent') emphasized complexity. Symphonic and power metal (Nightwish) used orchestras and soaring vocals.",
    "Metalcore blended hardcore punk and metal (Killswitch Engage); Japan's Babymetal fused metal and idol pop. Metal is especially popular in Finland, which has one of the highest numbers of metal bands per capita in the world."]],
  ["Culture and community",[
    "Metal has a strong global community, with dedicated fans ('metalheads'), festivals such as Wacken Open Air in Germany and Download in Britain, and distinctive fashion and gestures like headbanging and the 'devil horns' hand sign popularized by Ronnie James Dio.",
    "Though often criticized by moral campaigners, notably during the 1980s 'Satanic Panic' and Parents Music Resource Center hearings that led to 'Parental Advisory' labels, metal has proved one of rock's most enduring and inventive genres."]]
  ],
  terms:[["Power chord","Root and fifth, played under distortion."],["Riff","Repeated short musical phrase."],["Blast beat","Extremely fast extreme-metal drum pattern."],["Thrash","Fast, aggressive 1980s metal style."],["Palm muting","Damping strings with the hand for a chugging sound."]],
  w:"Metal is one of rock's most global and technically demanding families, with dozens of distinct styles.",
  src:["Heavy metal music","Black Sabbath","Thrash metal","Extreme metal","Power chord"],
  q:[
  ["What is a power chord?","Root and fifth only","A chord with seven notes","A loud piano chord","A diminished chord"],
  ["Which bands are the 'Big Four' of thrash?","Metallica, Slayer, Megadeth, Anthrax","Iron Maiden, Judas Priest, Saxon, Motörhead","Korn, Tool, Slipknot, Deftones","Mayhem, Emperor, Darkthrone, Burzum"],
  ["Which country was the center of early-1990s black metal?","Norway","Sweden","Germany","USA"],
  ["Which band led the New Wave of British Heavy Metal?","Iron Maiden","Def Leppard only","Guns N' Roses","Pantera"],
  ["What is a blast beat?","An extremely fast drum pattern","A guitar effect","A vocal style","A slow doom riff"],
  ["Who popularized the 'devil horns' hand sign in metal?","Ronnie James Dio","Ozzy Osbourne","Lemmy","James Hetfield"]]});

after("Heavy Metal and Its Branches",
{ t:"Alternative, Indie, and R&B Since 1980", s:"Beyond the mainstream and back",
  sec:[
  ["What 'indie' means",[
    "'Indie' originally meant music released on independent record labels, outside the major-label system, such as Rough Trade, Factory, and Creation in Britain, and SST, Sub Pop, Merge, and Matador in America. Over time it came to describe a style and attitude: guitar-based, often lo-fi or experimental, valuing authenticity and creative independence.",
    "College radio, fanzines, small clubs, and later blogs and streaming playlists were key channels for indie music."]],
  ["Key bands and movements",[
    "Influential 1980s acts included R.E.M., the Smiths (Morrissey and Johnny Marr), the Cure, Sonic Youth, the Pixies (whose loud-quiet-loud dynamics influenced Nirvana), New Order, and the Jesus and Mary Chain. Shoegaze bands such as My Bloody Valentine (Loveless, 1991) created washes of distorted, dreamy sound.",
    "Manchester's 'Madchester' scene blended indie and dance music (the Stone Roses, Happy Mondays). In the 2000s, indie went mainstream with the Strokes, the White Stripes, Arcade Fire, Arctic Monkeys, Vampire Weekend, and the National; later indie embraced synths and bedroom production (Tame Impala, Phoebe Bridgers, boygenius)."]],
  ["Contemporary R&B",[
    "After 1980, R&B moved through the polished 'quiet storm' ballads of Luther Vandross and Anita Baker; the funk-pop of Prince and Janet Jackson (with producers Jimmy Jam and Terry Lewis); new jack swing; and the hip-hop soul of Mary J. Blige, crowned the 'Queen of Hip-Hop Soul.' Vocal powerhouses such as Whitney Houston and Mariah Carey made melisma a mainstream pop style.",
    "Neo-soul (D'Angelo's Voodoo, Erykah Badu's Baduizm, Lauryn Hill, Maxwell) returned to live instruments and 1970s soul. In the 2000s, Beyoncé, Usher, Alicia Keys, and Rihanna dominated; in the 2010s, 'alternative R&B' by Frank Ocean (Channel Orange, Blonde), The Weeknd, Solange, and SZA (whose SZA album Ctrl, 2017, was a landmark) brought moodier, experimental sounds."]],
  ["Beyoncé",[
    "Beyoncé Knowles-Carter, after Destiny's Child, became one of the most acclaimed artists of her era. Her 'visual album' Lemonade (2016) combined music and film, exploring Black womanhood, infidelity, and heritage, and Renaissance (2022) celebrated Black and queer dance music history.",
    "She holds the record for the most Grammy wins of any artist; Cowboy Carter (2024) won Album of the Year in 2025."]],
  ["Independence in the digital age",[
    "The internet made independent careers more viable: artists can record at home, distribute through services such as Bandcamp and DistroKid, and build audiences directly on social media. Chance the Rapper won Grammys in 2017 without selling physical copies, for a streaming-only release.",
    "Yet the major labels remain powerful, and the line between indie and mainstream is now blurred; 'indie' often names a sound more than a business model."]]
  ],
  terms:[["Indie","Music on independent labels; also a style."],["Shoegaze","Dreamy, effects-heavy guitar rock."],["Loud-quiet-loud","Dynamic contrast between soft verses and loud choruses."],["Neo-soul","Revival of classic soul with modern influences."],["Alternative R&B","Moody, experimental R&B of the 2010s."]],
  w:"Indie and R&B have continually renewed popular music from the edges, and today shape the mainstream.",
  src:["Independent music","Alternative rock","Contemporary R&B","Neo soul","Beyoncé"],
  q:[
  ["What did 'indie' originally mean?","Released on independent record labels","Music from India","Instrumental music","Music without drums"],
  ["Which band's loud-quiet-loud dynamics influenced Nirvana?","Pixies","R.E.M.","The Smiths","The Cure"],
  ["Which My Bloody Valentine album (1991) defined shoegaze?","Loveless","Isn't Anything","Disintegration","Doolittle"],
  ["Who was crowned the 'Queen of Hip-Hop Soul'?","Mary J. Blige","Erykah Badu","Lauryn Hill","Aaliyah"],
  ["Which Beyoncé 'visual album' was released in 2016?","Lemonade","Renaissance","4","B'Day"],
  ["Which artist's album Channel Orange is an alternative R&B landmark?","Frank Ocean","The Weeknd","Miguel","Childish Gambino"]]});

})();


/* ---- from music-24.js ---- */
/* MUSIC FOUNDATIONS, part 24: Unit 10 Music in Life and Society, chapters 1-6 */
COURSES.music.units.push({ t:"Music in Life and Society", ch:[

{ t:"Music and the Brain", s:"What happens when we listen",
  sec:[
  ["From ear to brain",[
    "Sound waves enter the ear canal and vibrate the eardrum; three tiny bones (malleus, incus, and stapes) pass the vibration to the cochlea, a fluid-filled spiral in the inner ear. Inside, the basilar membrane responds to different frequencies at different points, high frequencies near the base and low near the tip, and hair cells convert the motion into nerve signals.",
    "Signals travel through the brainstem to the auditory cortex in the temporal lobes. The human ear typically hears from about 20 Hz to 20,000 Hz, with the upper limit falling with age."]],
  ["A whole-brain activity",[
    "Brain imaging shows that music engages many regions at once: auditory areas for pitch and timbre, motor areas for rhythm (even when we sit still), the cerebellum for timing, memory systems including the hippocampus, emotional centers such as the amygdala, and the reward system. Pleasurable music can trigger dopamine release in the striatum, the same system involved in food and other rewards, as shown in a 2011 study by Valorie Salimpoor and colleagues.",
    "There is no single 'music center.' Neuroscientist Daniel Levitin's book This Is Your Brain on Music (2006) popularized research on how these systems work together."]],
  ["Prediction and pleasure",[
    "A leading theory holds that musical pleasure comes from expectation: the brain constantly predicts what will come next based on learned patterns. Music satisfies predictions (the resolving cadence), delays them (suspense), or violates them pleasantly (a surprising chord). Leonard Meyer's Emotion and Meaning in Music (1956) and David Huron's Sweet Anticipation (2006) developed this idea.",
    "Chills or 'frisson,' the shiver some listeners feel, often occur at moments of unexpected harmony, sudden dynamic change, or a voice entering."]],
  ["Musicians' brains",[
    "Studies have found differences in the brains of trained musicians, such as enlarged areas of the motor cortex controlling the fingers and a larger corpus callosum (connecting the hemispheres) in those who started early. Musical training is associated with better detection of pitch in speech and of speech in noise.",
    "Researchers caution that many studies show correlation, not proof of causation, and that people who take music lessons may differ in other ways."]],
  ["When music and the brain go differently",[
    "Congenital amusia ('tone deafness') affects an estimated small percentage of people, who have difficulty perceiving pitch differences and recognizing melodies, despite normal hearing. Most people who think they are tone deaf simply lack training.",
    "Musical memory is remarkably resilient: people with advanced Alzheimer's disease often still recognize and sing songs from their youth, a phenomenon explored in Oliver Sacks's book Musicophilia (2007). Some people have synesthesia, seeing colors when they hear notes or keys; composers Olivier Messiaen and Alexander Scriabin described color associations."]],
  ["Earworms and rhythm",[
    "Earworms, or 'involuntary musical imagery,' are tunes stuck in the head, typically catchy, simple, and repetitive fragments. Research suggests chewing gum or engaging with a different tune or task can help displace them.",
    "Humans are unusual in spontaneously synchronizing movement to a beat ('beat entrainment'). Few other animals do this; a famous exception was Snowball, a cockatoo whose dancing to the Backstreet Boys was studied by scientists in 2009."]]
  ],
  terms:[["Cochlea","Spiral inner-ear organ converting sound to nerve signals."],["Auditory cortex","Brain region processing sound."],["Frisson","Musical chills."],["Amusia","Impaired pitch perception."],["Entrainment","Synchronizing movement to a beat."]],
  w:"Music engages the whole brain, from prediction and reward to memory and movement, explaining its power over us.",
  src:["Cognitive neuroscience of music","Cochlea","Amusia","Earworm","Frisson"],
  q:[
  ["Which part of the inner ear converts sound vibrations into nerve signals?","Cochlea","Eardrum","Stapes","Auditory canal"],
  ["What is the approximate range of human hearing?","20 Hz to 20,000 Hz","1 Hz to 1,000 Hz","100 Hz to 100,000 Hz","50 Hz to 5,000 Hz"],
  ["Which chemical, linked to reward, is released by pleasurable music?","Dopamine","Insulin","Melatonin","Adrenaline only"],
  ["What is congenital amusia?","Difficulty perceiving pitch differences","Perfect pitch","Hearing colors","Fear of music"],
  ["Who wrote Musicophilia?","Oliver Sacks","Daniel Levitin","David Huron","Leonard Meyer"],
  ["Which bird became famous for dancing to a beat?","Snowball the cockatoo","Alex the parrot","A mockingbird","A lyrebird"]]},

{ t:"Music, Emotion, and Identity", s:"Why music matters to us",
  sec:[
  ["How music expresses emotion",[
    "Listeners across cultures tend to agree on some basic emotional cues: fast tempo, major mode, and high pitch often sound happy; slow tempo, minor mode, and low pitch often sound sad; loud, harsh timbres sound angry or aggressive; soft, smooth sounds calm. Many of these cues parallel emotional speech: excited people talk faster and higher.",
    "Yet the major–happy, minor–sad link is partly learned within Western culture; in some traditions and contexts, minor-sounding music is festive."]],
  ["Felt and perceived emotion",[
    "Psychologists distinguish between emotions perceived in music (recognizing that a piece sounds sad) and emotions felt (actually feeling sad). Interestingly, many people enjoy sad music, perhaps because it allows them to experience emotion safely, feel understood, or gain comfort, a puzzle discussed since Aristotle's idea of catharsis.",
    "Psychologists Patrik Juslin and Daniel Västfjäll proposed several mechanisms by which music evokes emotion, including brainstem reflexes (startle at a sudden loud sound), rhythmic entrainment, evaluative conditioning (associations), emotional contagion (mirroring expression), visual imagery, episodic memory, and musical expectancy."]],
  ["Music and memory",[
    "Music is a powerful trigger for autobiographical memories. The 'reminiscence bump' means people tend to have the strongest attachment to music they heard between about ages 10 and 30, especially in adolescence.",
    "The 'they're playing our song' effect, a piece linked to an important life event, shows how music becomes woven into personal history."]],
  ["Identity and belonging",[
    "Music helps people define who they are and which groups they belong to. Teenagers often use musical taste to build identity; subcultures from punks to K-pop fans are built around music, fashion, and shared values. National anthems, school songs, and football chants bond groups.",
    "Singing together releases endorphins and promotes social bonding, according to research by Robin Dunbar and others, which may help explain music's evolutionary role."]],
  ["Everyday uses of music",[
    "People use music to regulate mood, to energize exercise, to relax, to focus, to fill silence, and to accompany rituals from weddings to funerals. Shops and restaurants use background music to influence behavior; studies have found that tempo can affect how fast people shop or eat.",
    "Soundtracks shape how we feel about films, games, and ads, and personal playlists have become a kind of emotional self-care."]],
  ["Taste and openness",[
    "Musical taste is shaped by exposure, culture, personality, and the 'mere exposure effect': people tend to like what is familiar. Openness to experience, a personality trait, is associated with liking complex and unfamiliar music.",
    "Deliberately exploring new genres and repeated listening can expand taste at any age."]]
  ],
  terms:[["Perceived emotion","Emotion recognized in the music."],["Felt emotion","Emotion actually experienced by the listener."],["Reminiscence bump","Strong attachment to music from youth."],["Catharsis","Emotional release through art."],["Mere exposure effect","Liking things more as they become familiar."]],
  w:"Understanding music's emotional and social power explains why it is central to identity, memory, and community.",
  src:["Music and emotion","Reminiscence bump","Music psychology","Mere-exposure effect","Catharsis"],
  q:[
  ["Which features commonly sound happy to Western listeners?","Fast tempo, major mode, high pitch","Slow tempo, minor mode, low pitch","Loud, harsh timbres","Very quiet, slow music"],
  ["What is the reminiscence bump?","Strongest attachment to music heard from about ages 10 to 30","A sudden loud chord","A type of earworm","A memory of a concert"],
  ["What is the difference between perceived and felt emotion?","Recognizing emotion vs actually experiencing it","Live vs recorded music","Major vs minor","Sad vs happy"],
  ["What effect makes people like music more as it becomes familiar?","Mere exposure effect","Mozart effect","Placebo effect","Doppler effect"],
  ["Which researcher studied how group singing promotes social bonding?","Robin Dunbar","Oliver Sacks","B. F. Skinner","Carl Jung"],
  ["Which ancient philosopher's idea of catharsis relates to enjoying sad art?","Aristotle","Plato","Pythagoras","Confucius"]]},

{ t:"Music Therapy and Health", s:"Sound as medicine",
  sec:[
  ["What music therapy is",[
    "Music therapy is the clinical use of music by a trained, credentialed professional to achieve health goals. It developed as a profession after World War II, when musicians played for veterans in hospitals; the first degree program was established at Michigan State University in 1944. Therapists use listening, singing, playing instruments, improvisation, and songwriting.",
    "Music therapy is used with people of all ages in hospitals, schools, care homes, and mental health settings."]],
  ["Neurological rehabilitation",[
    "Rhythm can help people with Parkinson's disease walk more steadily, using rhythmic auditory stimulation to cue steps. Melodic intonation therapy helps some stroke patients with non-fluent aphasia regain speech, because singing uses brain networks partly different from speech.",
    "US Representative Gabby Giffords used music therapy to relearn speech after a 2011 shooting injured her brain, a widely publicized example."]],
  ["Dementia and mental health",[
    "For people with dementia, familiar music can reduce agitation, prompt memories, and improve mood and communication; the documentary Alive Inside (2014) showed residents responding to personalized playlists. Research also supports music therapy as an add-on treatment for depression and anxiety.",
    "Group singing programs, such as choirs for people with lung conditions or for those with dementia and their carers, show benefits for wellbeing and social connection."]],
  ["Pain, stress, and hospitals",[
    "Listening to music before and after surgery has been associated in reviews of studies with reduced anxiety and lower need for pain medication. Music can lower heart rate and stress hormones in some settings, and is used in neonatal intensive care to help premature infants.",
    "Music therapy is not a cure-all; good research uses controlled trials, and effects vary by person and condition."]],
  ["Musicians' health",[
    "Musicians face their own health risks: hearing loss and tinnitus from loud sound, repetitive strain injuries, focal dystonia (involuntary muscle contraction, which affected pianist Leon Fleisher's right hand for decades), vocal strain, and performance anxiety. Performing arts medicine is a specialty addressing these.",
    "Safe listening guidelines from the World Health Organization recommend limiting exposure to loud sound, for example by keeping personal device volume below about 60% and taking listening breaks."]],
  ["Music for wellbeing",[
    "Everyday music-making, singing in the shower, drumming circles, dancing, and community choirs, offers accessible benefits: physical activity, breathing, social connection, and emotional expression.",
    "In 2019 a World Health Organization report reviewed over 3,000 studies and concluded that the arts, including music, can play a significant role in promoting health and preventing and managing illness."]]
  ],
  terms:[["Music therapy","Clinical use of music by a trained therapist."],["Rhythmic auditory stimulation","Using beat to cue movement."],["Melodic intonation therapy","Using singing to rebuild speech."],["Tinnitus","Ringing or buzzing in the ears."],["Focal dystonia","Involuntary muscle contraction in skilled movements."]],
  w:"Music is a proven tool for health and wellbeing, and protecting your hearing protects your musical life.",
  src:["Music therapy","Melodic intonation therapy","Alive Inside","Noise-induced hearing loss","Leon Fleisher"],
  q:[
  ["Where was the first music therapy degree program established in 1944?","Michigan State University","Juilliard","Harvard","Berklee"],
  ["Which therapy uses singing to help stroke patients regain speech?","Melodic intonation therapy","Rhythmic auditory stimulation","Guided imagery","Sound bathing"],
  ["How can rhythm help people with Parkinson's disease?","By cueing steadier walking","By curing the disease","By improving eyesight","By reducing tremor permanently"],
  ["Which pianist's career was affected by focal dystonia?","Leon Fleisher","Glenn Gould","Vladimir Horowitz","Martha Argerich"],
  ["What did a 2019 WHO report conclude about the arts?","They can play a significant role in promoting health","They have no health effects","They are harmful to health","Only visual arts matter"],
  ["Which documentary showed dementia patients responding to personalized music?","Alive Inside","Searching for Sugar Man","20 Feet from Stardom","Amazing Grace"]]},

{ t:"Copyright, Royalties, and Who Owns Music", s:"The law behind the songs",
  sec:[
  ["Two copyrights in every recording",[
    "Every recorded song involves two separate copyrights: the composition (the song itself, melody and lyrics, owned by songwriters and their publishers) and the sound recording (the specific recording, or 'master,' typically owned by the record label or the artist).",
    "Each generates different royalties, which is why a songwriter can earn money when another artist covers their song."]],
  ["Types of royalties",[
    "Performance royalties are paid when compositions are performed publicly, on radio, TV, streaming, in venues, or in shops, collected by performing rights organizations (ASCAP, BMI, and SESAC in the US; PRS for Music in the UK; GEMA in Germany; SACEM in France). Mechanical royalties are paid for reproducing compositions, on records, downloads, and streams.",
    "Synchronization (sync) licenses are needed to use music with visuals, in films, TV, ads, and games, and can be very lucrative. Neighboring rights pay performers and labels for public performance of sound recordings in many countries."]],
  ["Copyright duration and public domain",[
    "Copyright lasts for a limited time, after which works enter the public domain and can be used freely. In the US and EU, compositions are generally protected for the author's life plus 70 years. Works by Bach, Mozart, and Beethoven are in the public domain, though specific modern recordings and editions may still be protected.",
    "'Happy Birthday to You,' based on a 19th-century melody by Mildred and Patty Hill, was claimed under copyright for decades until a US court ruled in 2015 that the claim was invalid, and the song is now treated as public domain."]],
  ["Sampling and infringement",[
    "Sampling a recording requires clearing both the master and the composition. Major cases shaped the rules: Grand Upright Music v. Warner Bros. (1991) ruled against Biz Markie's unlicensed sample, and Bridgeport Music v. Dimension Films (2005) suggested that even very short samples need licenses.",
    "Infringement cases about composition similarity are controversial. In 2015 a jury found that 'Blurred Lines' by Robin Thicke and Pharrell Williams infringed Marvin Gaye's 'Got to Give It Up,' a decision many musicians worried would penalize similarities in 'feel'; in contrast, Led Zeppelin won a long case over 'Stairway to Heaven' (affirmed 2020), and Ed Sheeran won a 2023 case over 'Thinking Out Loud.'"]],
  ["Fair pay debates",[
    "Streaming has prompted debates over how royalties are split, how little artists earn per stream, and how much labels and platforms keep. Artists such as Taylor Swift have publicly challenged platforms and labels. In the US, the Music Modernization Act (2018) updated mechanical licensing for streaming.",
    "Historically, many artists, especially Black musicians in the early record industry, signed exploitative contracts and lost rights to their work, a history that informs today's discussions of fairness."]],
  ["AI and new questions",[
    "Artificial intelligence raises new legal questions: whether training AI on copyrighted recordings requires permission, who owns AI-generated music, and how to protect artists' voices from imitation. A viral 2023 track using AI-cloned voices of Drake and The Weeknd ('Heart on My Sleeve') was removed from platforms after label complaints.",
    "Courts, lawmakers, and the industry are still working out answers, and rules differ between countries."]]
  ],
  terms:[["Master","The original sound recording."],["Mechanical royalty","Payment for reproducing a composition."],["Sync license","Permission to pair music with visuals."],["Public domain","Works free of copyright."],["PRO","Performing rights organization collecting performance royalties."]],
  w:"Knowing how music ownership works explains artists' careers, sampling, and today's battles over streaming and AI.",
  src:["Music copyright","Performance rights organisation","Mechanical license","Happy Birthday to You","Pharrell Williams v. Bridgeport Music"],
  q:[
  ["What two copyrights exist in every recorded song?","The composition and the sound recording","Lyrics and melody","Performance and broadcast","Album and single"],
  ["What is a sync license for?","Using music with visuals","Playing music live","Printing sheet music","Streaming audio"],
  ["Which song was found to infringe 'Got to Give It Up' in 2015?","Blurred Lines","Stairway to Heaven","Thinking Out Loud","Uptown Funk"],
  ["How long does copyright on compositions generally last in the US and EU?","Life of the author plus 70 years","50 years total","Forever","20 years"],
  ["Which organization collects performance royalties in the UK?","PRS for Music","ASCAP","GEMA","SACEM"],
  ["What happened to the copyright claim on 'Happy Birthday to You' in 2015?","A court ruled it invalid","It was renewed","It was sold","It was extended"]]},

{ t:"Music and Politics", s:"Songs of power and protest",
  sec:[
  ["Music and the state",[
    "Rulers have always used music to project power: royal fanfares, court composers, coronation anthems, and military bands. National anthems became widespread in the 19th century; the British 'God Save the King' is among the oldest, and 'La Marseillaise' (1792) was born in the French Revolution.",
    "Authoritarian regimes have tried to control music: the Nazis banned 'degenerate music,' including jazz and works by Jewish composers; the Soviet Union censored 'formalism'; China's Cultural Revolution restricted music to approved 'model works'; and the Taliban banned most music in Afghanistan during both periods of rule."]],
  ["Protest songs",[
    "Songs have long been tools of protest: abolitionist hymns, labor songs by Joe Hill and the Industrial Workers of the World, Woody Guthrie's ballads, civil rights freedom songs like 'We Shall Overcome,' and antiwar songs of the Vietnam era. Billie Holiday's 'Strange Fruit' (1939) is one of the earliest and most powerful protest recordings.",
    "Later examples include Bob Marley's 'Get Up, Stand Up,' Public Enemy's 'Fight the Power,' Kendrick Lamar's 'Alright' (an anthem of the Black Lives Matter movement), and songs of the Arab Spring."]],
  ["Music against apartheid and dictatorship",[
    "In South Africa, songs such as 'Senzeni Na?' and Hugh Masekela's 'Bring Him Back Home (Nelson Mandela)' and the Special AKA's 'Free Nelson Mandela' (1984) helped the anti-apartheid cause. Chile's nueva canción voiced resistance to Pinochet, and the 'Singing Revolution' in Estonia, Latvia, and Lithuania (1987–91) used mass song festivals to assert independence from the Soviet Union.",
    "In 2012, members of the Russian punk group Pussy Riot were imprisoned after a protest performance in a Moscow cathedral."]],
  ["Music, race, and representation",[
    "Music has been central to debates about race: segregated charts and radio, cover versions that profited white artists, and arguments about cultural appropriation. At the same time, music brought communities together, from integrated jazz bands to Motown's crossover success.",
    "Questions about who gets credit, who profits, and who is represented in orchestras, festivals, and the music industry remain active today."]],
  ["Benefit concerts and activism",[
    "Musicians have raised money and awareness through events such as the Concert for Bangladesh (1971), organized by George Harrison and Ravi Shankar; Live Aid (1985); Farm Aid; and Live 8 (2005). Artists such as Bono, Joan Baez, Nina Simone, and Fela Kuti combined music and activism.",
    "Critics sometimes question the effectiveness of celebrity activism, but music remains a powerful way to draw attention and build solidarity."]],
  ["Music in campaigns",[
    "Politicians use songs at rallies to project an image, sometimes without permission; many artists, from Bruce Springsteen ('Born in the U.S.A.,' often misread as purely patriotic) to Neil Young and the Rolling Stones, have objected to their songs being used by candidates they oppose.",
    "Music's emotional and communal power makes it a political force wherever it is heard."]]
  ],
  terms:[["National anthem","Official patriotic song of a country."],["Protest song","Song addressing social or political injustice."],["Singing Revolution","Baltic independence movement through song."],["Degenerate music","Nazi label for banned music."],["Benefit concert","Concert raising money for a cause."]],
  w:"Music has always been political: it can glorify power, resist it, and unite people for change.",
  src:["Protest song","Singing Revolution","La Marseillaise","Concert for Bangladesh","Music censorship"],
  q:[
  ["Which anthem was born in the French Revolution?","La Marseillaise","God Save the King","The Star-Spangled Banner","Deutschlandlied"],
  ["What was the 'Singing Revolution'?","Baltic independence movement using song festivals","A Beatles album","A Soviet music school","A Chinese opera reform"],
  ["Who organized the Concert for Bangladesh in 1971?","George Harrison and Ravi Shankar","Bob Geldof","Bono","Bob Dylan"],
  ["Which Kendrick Lamar song became a Black Lives Matter anthem?","Alright","HUMBLE.","King Kunta","DNA."],
  ["Which Russian punk group's members were imprisoned in 2012?","Pussy Riot","t.A.T.u.","Leningrad","DDT"],
  ["Which Springsteen song is often misread as purely patriotic?","Born in the U.S.A.","Born to Run","Thunder Road","Dancing in the Dark"]]},

{ t:"Music and Dance", s:"Moving together",
  sec:[
  ["Inseparable arts",[
    "In most cultures, music and dance are inseparable; many languages have a single word for both. Dance rhythms shaped musical forms: the Baroque suite is a set of stylized dances, the minuet became a symphony movement, and the waltz, tango, and samba began as dance music.",
    "Dance music emphasizes a clear, steady beat, characteristic rhythms, and phrase lengths (often 8 or 16 bars) that fit choreography."]],
  ["Social dances in history",[
    "Renaissance courts danced the pavane and galliard; Baroque courts the minuet and gavotte. The waltz, in 3/4 time with a turning partner embrace, scandalized early 19th-century Europe before becoming the dance of Vienna, where Johann Strauss II, the 'Waltz King,' wrote 'The Blue Danube' (1867).",
    "The polka from Bohemia swept Europe in the 1840s. In the 20th century, ragtime brought the foxtrot, the 1920s the Charleston, the swing era the Lindy Hop and jitterbug, and Latin music the rumba, mambo, and cha-cha-chá."]],
  ["Ballroom and Latin dance",[
    "Competitive ballroom dancing (DanceSport) standardizes 'Standard' dances, waltz, tango, Viennese waltz, foxtrot, and quickstep, and 'Latin' dances, cha-cha, samba, rumba, paso doble, and jive, each with specific tempos and rhythms. Television shows such as Strictly Come Dancing (2004) and Dancing with the Stars have popularized them.",
    "Salsa, bachata, kizomba, Argentine tango, and swing dancing remain thriving social dance scenes worldwide."]],
  ["Popular dance crazes",[
    "Rock and roll brought the twist (Chubby Checker, 1960), and each era since has had its dances: disco's hustle, breaking and popping in hip-hop, the Macarena (1996), and viral TikTok dance challenges in the 2020s.",
    "Line dancing in country music, the electric slide, and 'dance-along' songs show how music invites collective movement."]],
  ["Theatrical dance",[
    "Ballet, discussed earlier, developed from court spectacles into a classical art with codified technique. Modern dance, pioneered by Isadora Duncan, Martha Graham, and others in the early 20th century, rejected ballet's rules; Graham's collaboration with Copland produced Appalachian Spring. Choreographers such as George Balanchine (with Stravinsky), Merce Cunningham (with John Cage, often creating dance and music independently), Alvin Ailey (with spirituals in Revelations), and Pina Bausch expanded the relationship between music and movement.",
    "Musical theater and film dance, from Fred Astaire and Gene Kelly to Bob Fosse and today's music videos, integrate dance with popular song."]],
  ["Why we dance",[
    "Dancing combines rhythm, social bonding, courtship, exercise, and emotional expression. Research suggests that moving in synchrony with others increases feelings of trust and cooperation.",
    "For musicians, understanding dance helps in feeling groove, phrasing, and the physical energy behind rhythm."]]
  ],
  terms:[["Waltz","Turning partner dance in 3/4 time."],["DanceSport","Competitive ballroom dancing."],["Modern dance","20th-century dance rejecting ballet conventions."],["Groove","The rhythmic feel that makes people move."],["Choreography","The design of dance movements."]],
  w:"Dance and music grew up together; feeling the dance behind music unlocks rhythm, form, and groove.",
  src:["Dance music","Waltz","Ballroom dance","Modern dance","Johann Strauss II"],
  q:[
  ["Who was called the 'Waltz King'?","Johann Strauss II","Franz Lehár","Josef Lanner","Johannes Brahms"],
  ["In what meter is a waltz?","3/4","4/4","2/4","6/8"],
  ["Which is a 'Latin' dance in DanceSport?","Paso doble","Quickstep","Foxtrot","Viennese waltz"],
  ["Which choreographer collaborated with Copland on Appalachian Spring?","Martha Graham","George Balanchine","Merce Cunningham","Alvin Ailey"],
  ["Who popularized the twist in 1960?","Chubby Checker","Elvis Presley","Little Richard","Chuck Berry"],
  ["Which choreographer often created dance independently of John Cage's music?","Merce Cunningham","Martha Graham","Pina Bausch","Bob Fosse"]]}

]});


/* ---- from music-25.js ---- */
/* MUSIC FOUNDATIONS, part 25: Unit 10 chapters 7-12 */
COURSES.music.units[9].ch.push(

{ t:"Women in Music History", s:"Recovering hidden voices",
  sec:[
  ["Barriers",[
    "For most of Western history, women faced barriers to professional music: exclusion from church choirs and many institutions, lack of access to composition training, social expectations that 'respectable' women should perform only at home, and publishers' reluctance. Their work was often lost, attributed to men, or dismissed.",
    "Since the 1970s, musicologists have recovered many women's works and stories, and performers increasingly program them."]],
  ["Early figures",[
    "Hildegard of Bingen (12th century) is one of the earliest composers whose name and works are known. In the Renaissance, the Concerto delle donne, a group of virtuoso women singers at the court of Ferrara, was famous. Francesca Caccini (1587–about 1640) wrote what is often called the first opera by a woman, La liberazione di Ruggiero (1625).",
    "Barbara Strozzi (1619–1677) in Venice published more secular vocal music than almost any composer of her time. Élisabeth Jacquet de La Guerre was celebrated at the court of Louis XIV."]],
  ["The 19th century",[
    "Fanny Mendelssohn Hensel composed over 460 works, but her family discouraged publication; some of her songs were published under her brother Felix's name. Clara Schumann was a towering pianist and composer. Pauline Viardot was a great singer and composer, and Cécile Chaminade became a successful composer in France and America.",
    "Ethel Smyth in England wrote operas and 'The March of the Women' (1911), the anthem of the suffragette movement; she was imprisoned for her suffrage activism and famously conducted the song with a toothbrush from her cell window."]],
  ["The 20th century and beyond",[
    "Nadia Boulanger became the most influential composition teacher of the century and the first woman to conduct many major orchestras; her sister Lili Boulanger was the first woman to win the Prix de Rome for composition (1913). Florence Price, Rebecca Clarke, Amy Beach (the first successful American woman composer of large-scale art music), Germaine Tailleferre (of Les Six), Grażyna Bacewicz, Sofia Gubaidulina, Kaija Saariaho, Unsuk Chin, Caroline Shaw (Pulitzer Prize at 30 in 2013), and Missy Mazzoli show women's growing place in composition.",
    "Marin Alsop became the first woman to conduct the Last Night of the Proms (2013); conductors such as Simone Young, Susanna Mälkki, and Mirga Gražinytė-Tyla have led major orchestras."]],
  ["Women in jazz and popular music",[
    "Women have always been central as singers, from Bessie Smith, Billie Holiday, and Ella Fitzgerald to Aretha Franklin and Beyoncé. Instrumentalists and bandleaders were often overlooked: pianist-composer Mary Lou Williams arranged for Duke Ellington and Benny Goodman; Lil Hardin Armstrong played and wrote for the Hot Five; the International Sweethearts of Rhythm were a popular all-women, racially integrated swing band in the 1940s.",
    "In rock and pop, women such as Sister Rosetta Tharpe, Joni Mitchell, Carole King, Patti Smith, Kate Bush, Björk, and Taylor Swift shaped their art as writers and producers. Industry studies, such as the University of Southern California's Annenberg Inclusion Initiative, have found women remain a small minority of credited songwriters and producers on popular charts."]],
  ["Blind auditions",[
    "In the 1970s and 80s, major American orchestras began using blind auditions, with candidates playing behind a screen. A widely cited 2000 study by economists Claudia Goldin and Cecilia Rouse suggested that screens increased the likelihood of women advancing, though later researchers have debated the size of the effect.",
    "Women made up a small share of major orchestras' players in 1970 and now hold a much larger share, though leadership, composition, and production remain areas where change continues."]]
  ],
  terms:[["Musicology","Scholarly study of music history."],["Concerto delle donne","Famous women singers at the court of Ferrara."],["Prix de Rome","French prize for young artists and composers."],["Blind audition","Audition behind a screen."],["Suffragette","Activist for women's right to vote."]],
  w:"Recovering women's contributions completes the story of music and reveals great works long overlooked.",
  src:["Women in music","Francesca Caccini","Barbara Strozzi","Ethel Smyth","Lili Boulanger"],
  q:[
  ["Who wrote what is often called the first opera by a woman (1625)?","Francesca Caccini","Barbara Strozzi","Hildegard of Bingen","Élisabeth Jacquet de La Guerre"],
  ["Who was the first woman to win the Prix de Rome for composition?","Lili Boulanger","Nadia Boulanger","Cécile Chaminade","Germaine Tailleferre"],
  ["Which composer wrote the suffragette anthem 'The March of the Women'?","Ethel Smyth","Rebecca Clarke","Amy Beach","Clara Schumann"],
  ["Which jazz pianist arranged for Duke Ellington and Benny Goodman?","Mary Lou Williams","Lil Hardin Armstrong","Nina Simone","Marian McPartland"],
  ["Who became the first woman to conduct the Last Night of the Proms?","Marin Alsop","Simone Young","Nadia Boulanger","Susanna Mälkki"],
  ["What change did orchestras introduce to reduce bias in hiring?","Blind auditions behind a screen","Online voting","Lottery selection","Only internal promotions"]]},

{ t:"Careers in Music", s:"Many ways to make a living",
  sec:[
  ["Performing",[
    "Performing careers include orchestral musicians (who win positions through highly competitive auditions), chamber musicians, soloists, session musicians who play on others' recordings (such as the Wrecking Crew in 1960s Los Angeles or the Funk Brothers at Motown), touring band members, church musicians, cruise ship and wedding bands, and singers in opera, theater, and choirs.",
    "Most performers combine several income sources, a 'portfolio career' of performing, teaching, and other work."]],
  ["Creating",[
    "Composers write for concert, film, TV, games, advertising (jingles), and theater. Songwriters may write for themselves or other artists. Producers and beat-makers create tracks; arrangers and orchestrators adapt music; music editors and music supervisors choose and fit music in films and shows.",
    "Income often comes from commissions, fees, and royalties, which depend on copyright ownership and licensing."]],
  ["Teaching and scholarship",[
    "Music teachers work in schools, conservatories, universities, community programs, and private studios; teaching is one of the most common music careers. Musicologists, ethnomusicologists, and music theorists research and teach; music librarians and archivists preserve collections.",
    "Programs like El Sistema, founded in Venezuela in 1975 by José Antonio Abreu, which provides free orchestral training to children from poor communities and produced conductor Gustavo Dudamel, show music education's social power."]],
  ["Technical and business roles",[
    "Behind the scenes are recording, mixing, and mastering engineers; live sound engineers; instrument makers and technicians (luthiers, piano tuners); and roles in music technology and software.",
    "The business side includes artist managers, booking agents, concert promoters, record label staff (A&R, short for 'artists and repertoire,' who find and develop talent), music publishers, publicists, entertainment lawyers, and arts administrators running orchestras and festivals."]],
  ["Health and other fields",[
    "Music therapists, performing arts medicine specialists, and audiologists apply music and hearing science in healthcare. Music journalists, critics, and podcasters write and talk about music.",
    "Many people who don't work in music professionally remain serious amateurs, playing in community orchestras, bands, and choirs throughout their lives."]],
  ["Building a career today",[
    "Successful musicians today often combine artistry with entrepreneurial skills: building an audience on social media, understanding royalties and contracts, networking, collaborating, and adapting to new technologies.",
    "Training paths include conservatories (such as Juilliard, the Curtis Institute, the Royal Academy of Music, and the Paris Conservatoire), university music programs, specialized schools like Berklee College of Music for contemporary music, apprenticeships, and self-teaching, which has produced many great popular musicians."]]
  ],
  terms:[["Session musician","Musician hired to play on others' recordings."],["Portfolio career","Combining several kinds of work."],["A&R","'Artists and repertoire,' finding and developing talent."],["Luthier","Maker of string instruments."],["El Sistema","Venezuelan program of free orchestral education."]],
  w:"Music offers a wide range of careers, and understanding them helps any musician plan a sustainable life in the art.",
  src:["Musician","Session musician","El Sistema","Artists and repertoire","Music education"],
  q:[
  ["What does A&R stand for?","Artists and repertoire","Audio and recording","Arrangement and rhythm","Albums and royalties"],
  ["Which Venezuelan program produced conductor Gustavo Dudamel?","El Sistema","Juilliard","Berklee","Royal Academy"],
  ["What is a session musician?","A musician hired to play on others' recordings","A soloist","A conductor","A music teacher"],
  ["Which group of Los Angeles session players backed many 1960s hits?","The Wrecking Crew","The Funk Brothers","The Swampers","The MGs"],
  ["What is a luthier?","A maker of string instruments","A lute player","A music publisher","A sound engineer"],
  ["Which college is known for contemporary popular music and jazz training?","Berklee College of Music","Curtis Institute","Paris Conservatoire","Royal College of Organists"]]},

{ t:"Talking About Music", s:"Criticism, analysis, and vocabulary",
  sec:[
  ["Describing what you hear",[
    "Describing music clearly starts with its elements: melody (shape, range, steps or leaps), harmony (major or minor, simple or complex, consonant or dissonant), rhythm (tempo, meter, groove, syncopation), timbre (instruments and tone colors), texture (thin or dense, monophonic, homophonic, or polyphonic), dynamics, form, and lyrics.",
    "Using concrete details, such as 'the bass drops out before the chorus' or 'the strings enter in a high register,' communicates more than vague words like 'nice' or 'powerful.'"]],
  ["Music criticism",[
    "Music criticism developed with the rise of public concerts and newspapers in the 18th and 19th centuries. Influential critics include Robert Schumann, Eduard Hanslick (defender of Brahms and absolute music), George Bernard Shaw (a witty London music critic before his playwriting fame), and Virgil Thomson.",
    "Rock criticism began in the 1960s with magazines such as Crawdaddy! and Rolling Stone; Lester Bangs, Robert Christgau, and Greil Marcus became well known. Online outlets such as Pitchfork (founded 1996), and now YouTube critics and podcasts, shape taste."]],
  ["Analysis",[
    "Music analysis studies how music works. Formal analysis identifies sections and their relationships; harmonic analysis labels chords with Roman numerals and finds keys and cadences; motivic analysis traces themes and their development. Heinrich Schenker (1868–1935) developed a theory that tonal masterworks elaborate simple underlying structures, which became influential in academic theory.",
    "Popular music analysis considers production, groove, vocal style, and lyrics, as well as recordings rather than scores as the 'text.'"]],
  ["Context and meaning",[
    "Understanding music also means understanding context: who made it, for whom, why, and how it was received. Historical musicology studies scores, documents, and performance practice; ethnomusicology studies music in culture; and popular music studies examines industry, audiences, identity, and media.",
    "Meanings change over time: a work dismissed in its day may be celebrated later (Bach after Mendelssohn's revival), and songs can take on new political meanings."]],
  ["Judging quality",[
    "There is no single measure of musical quality, but listeners often consider originality, craftsmanship, emotional power, coherence, performance skill, influence, and how well a work achieves its goals within its style. Comparing music across very different traditions by one standard can mislead.",
    "Good critics separate personal preference ('I don't enjoy this') from evaluation ('this is well made and achieves its aims'), and remain open to changing their minds."]],
  ["Writing and talking about music yourself",[
    "Keeping a listening journal, noting what you notice, comparing recordings, or explaining a favorite song to a friend sharpens perception.",
    "The famous line 'writing about music is like dancing about architecture,' attributed to various people including Martin Mull and Elvis Costello, is a joke about the difficulty, not a reason not to try; good writing about music helps others hear more."]]
  ],
  terms:[["Texture","How many layers sound and how they relate."],["Homophonic","Melody with chordal accompaniment."],["Music criticism","Evaluative writing about music."],["Schenkerian analysis","Theory of underlying tonal structures."],["Performance practice","How music was performed in its own era."]],
  w:"Learning to describe and evaluate music sharpens your ears and helps you share what you hear.",
  src:["Music criticism","Musical analysis","Eduard Hanslick","Heinrich Schenker","Lester Bangs"],
  q:[
  ["Which 19th-century critic defended Brahms and absolute music?","Eduard Hanslick","George Bernard Shaw","Robert Christgau","Virgil Thomson"],
  ["Who developed a theory of underlying structures in tonal music?","Heinrich Schenker","Hugo Riemann","Johann Fux","Leonard Meyer"],
  ["What is homophonic texture?","Melody with chordal accompaniment","Many independent lines","A single unaccompanied line","Noise without pitch"],
  ["Which playwright was earlier a witty London music critic?","George Bernard Shaw","Oscar Wilde","Samuel Beckett","Noël Coward"],
  ["Which online music publication was founded in 1996?","Pitchfork","Rolling Stone","Crawdaddy!","NME"],
  ["What is a sound approach to judging music?","Separating personal preference from evaluation","Only counting sales","Comparing all music by one standard","Trusting only critics"]]},

{ t:"Great Performers and Interpretation", s:"The art of bringing music to life",
  sec:[
  ["What performers add",[
    "A score cannot specify everything: exact tempo flexibility, balance, tone color, phrasing, and character are left to the performer. Two great performances of the same piece can differ enormously, which is why listeners collect multiple recordings and argue about favorites.",
    "Interpretation balances faithfulness to the composer's intentions, the performer's personality, and the expectations of the time."]],
  ["Legendary pianists and string players",[
    "Pianists such as Sergei Rachmaninoff, Vladimir Horowitz (dazzling virtuosity), Arthur Rubinstein (warm, aristocratic Chopin), Sviatoslav Richter, Glenn Gould (whose 1955 and 1981 recordings of Bach's Goldberg Variations are landmarks, and who quit public concerts in 1964 to focus on the studio), Martha Argerich, and Daniel Barenboim shaped how we hear the repertoire.",
    "Violinists Jascha Heifetz, Itzhak Perlman, Anne-Sophie Mutter, and Hilary Hahn, and cellists Pablo Casals (who revived Bach's Cello Suites), Mstislav Rostropovich, Jacqueline du Pré (whose recording of Elgar's Concerto is legendary), and Yo-Yo Ma became household names."]],
  ["Singers",[
    "Enrico Caruso (1873–1921) was one of the first recording superstars; his recordings helped make the gramophone popular. Maria Callas transformed opera with dramatic acting through the voice. Marian Anderson, denied a concert at Constitution Hall in 1939 because she was Black, sang instead at the Lincoln Memorial to 75,000 people, a landmark civil rights event; she later became the first Black singer to perform at the Metropolitan Opera (1955).",
    "In popular music, singers such as Frank Sinatra (famous for phrasing like speech), Ella Fitzgerald, Aretha Franklin, Freddie Mercury, and Whitney Houston set standards of interpretation as much as composers do."]],
  ["Historically informed performance",[
    "From the mid-20th century, the 'early music' or historically informed performance (HIP) movement sought to perform music as it might have sounded originally, using period instruments, tunings, smaller ensembles, and research into historical treatises. Pioneers included Nikolaus Harnoncourt, Gustav Leonhardt, Christopher Hogwood, John Eliot Gardiner, and William Christie.",
    "HIP made Baroque music lighter, faster, and more dance-like than the heavy Romantic-style performances common earlier, and its influence now extends to Classical and even Romantic repertoire. Debates continue about whether 'authenticity' is possible or desirable."]],
  ["Improvisation and the performer-creator",[
    "In jazz, popular, and many world traditions, performers are also creators: every performance is different, and the recording of a performance may be the definitive 'work.' Classical improvisation, once common (Bach, Mozart, Beethoven, and Liszt were great improvisers, and cadenzas were improvised), declined in the 19th and 20th centuries but is being revived.",
    "The line between composer and performer is thus a cultural choice, not a fixed rule."]],
  ["Recording and interpretation",[
    "Recordings changed performance: musicians could compare themselves to others, styles became more standardized, and the expectation of flawless playing rose with studio editing. Some argue live performance's risk and spontaneity remain irreplaceable.",
    "Comparing recordings of the same work from different decades is one of the best ways to understand interpretation and to develop your own taste."]]
  ],
  terms:[["Interpretation","A performer's personal realization of a score."],["Historically informed performance","Performing with period instruments and practices."],["Period instrument","Instrument as made in the composer's era."],["Phrasing","Shaping musical lines like sentences."],["Virtuoso","Performer of exceptional technical skill."]],
  w:"Performers bring scores to life; comparing interpretations is one of music's greatest pleasures.",
  src:["Glenn Gould","Pablo Casals","Marian Anderson","Historically informed performance","Enrico Caruso"],
  q:[
  ["Which pianist is famous for two recordings of the Goldberg Variations (1955 and 1981)?","Glenn Gould","Vladimir Horowitz","Arthur Rubinstein","Sviatoslav Richter"],
  ["Which cellist revived Bach's Cello Suites?","Pablo Casals","Yo-Yo Ma","Mstislav Rostropovich","Jacqueline du Pré"],
  ["Where did Marian Anderson sing to 75,000 people in 1939?","The Lincoln Memorial","Carnegie Hall","Constitution Hall","The Metropolitan Opera"],
  ["What is historically informed performance?","Performing with period instruments and practices","Performing only famous historical works","Performing from memory","Performing in historic buildings"],
  ["Which tenor was one of the first recording superstars?","Enrico Caruso","Luciano Pavarotti","Plácido Domingo","Beniamino Gigli"],
  ["Which cellist's recording of Elgar's Concerto is legendary?","Jacqueline du Pré","Pablo Casals","Steven Isserlis","Sheku Kanneh-Mason"]]},

{ t:"Music Technology and the Future", s:"AI, immersive sound, and new instruments",
  sec:[
  ["A history of disruption",[
    "Every major technology changed music: notation allowed complex composition; printing spread it; the piano brought orchestral music home; recording froze performances; radio created mass audiences; electric amplification enabled rock; synthesizers and samplers created new sounds; and the internet transformed distribution.",
    "Each innovation provoked anxiety, from fears that recordings would kill live music to worries about drum machines replacing drummers, yet music-making continued to grow and change."]],
  ["Artificial intelligence",[
    "AI music tools can now generate songs from text prompts, imitate voices, separate instruments from mixed recordings ('stem separation,' used to restore the Beatles' 'Now and Then' in 2023), master tracks automatically, and suggest chords and melodies. Systems such as Suno and Udio drew both enthusiasm and lawsuits from record labels in 2024 over training on copyrighted recordings.",
    "Debates center on creativity and authorship, artists' consent and compensation, the flood of AI-generated content on streaming platforms, and how human musicians can use AI as a tool rather than be replaced by it."]],
  ["Immersive and spatial audio",[
    "Spatial audio formats such as Dolby Atmos place sounds in three-dimensional space around the listener, including above, through speakers or headphones with binaural processing. Streaming services began offering Atmos music around 2021, and some artists now mix albums specifically for it.",
    "Venues such as the Las Vegas Sphere (opened 2023), with over 160,000 speakers in its sound system, and virtual concerts in video games such as Fortnite (Travis Scott in 2020 attracted over 12 million concurrent players) point to new forms of live experience."]],
  ["New instruments and interfaces",[
    "Controllers such as MIDI keyboards, pads, and expressive instruments (like the ROLI Seaboard, which senses pressure and slides) extend performance possibilities. Live coding, where performers write code to generate music in real time (Algorave events), is a new performance practice. Accessible instruments and adaptive technologies help people with disabilities make music.",
    "Smartphone apps let anyone make music anywhere, continuing the democratization begun by cheap guitars and home recording."]],
  ["Live music's resilience",[
    "Despite recordings and streaming, live music remains central. Concert ticket revenues have grown, festival culture thrives, and the shared experience of a live performance, the risk, energy, and community, cannot be fully replicated.",
    "The COVID-19 pandemic (2020–21) shut down live music for long periods, prompting livestreamed concerts, but audiences returned in record numbers afterward."]],
  ["Thinking critically about the future",[
    "Questions to consider: Who benefits from new technologies? How do algorithms shape what music we hear? What happens to local traditions in a globalized market? How can musicians earn a living?",
    "History suggests that technology will keep changing how music is made and shared, while the human needs music serves, expression, connection, ritual, and joy, remain."]]
  ],
  terms:[["Stem separation","Isolating instruments from a mixed recording."],["Spatial audio","Sound positioned in three-dimensional space."],["Dolby Atmos","Immersive object-based audio format."],["Live coding","Generating music by writing code in performance."],["Generative AI","Systems that create new content from patterns in data."]],
  w:"Technology has always reshaped music; understanding today's changes helps you navigate and shape its future.",
  src:["Music and artificial intelligence","Dolby Atmos","Sphere (venue)","Live coding","Now and Then (Beatles song)"],
  q:[
  ["What technique helped restore the Beatles' 'Now and Then' in 2023?","AI stem separation","Tape splicing","Auto-Tune","Live re-recording only"],
  ["What does Dolby Atmos provide?","Immersive three-dimensional sound","Noise cancellation","Pitch correction","Louder mastering"],
  ["Which rapper's 2020 Fortnite concert drew over 12 million concurrent players?","Travis Scott","Drake","Kanye West","Marshmello"],
  ["What is live coding?","Generating music by writing code in real time","Recording live albums","Coding music videos","Teaching coding with music"],
  ["Which Las Vegas venue opened in 2023 with an enormous sound system?","Sphere","Caesars Palace","Allegiant Stadium","T-Mobile Arena"],
  ["In 2024, AI music generators drew lawsuits mainly over what?","Training on copyrighted recordings","Using too much electricity","Copying album covers","Concert ticket prices"]]},

{ t:"A Lifelong Life in Music", s:"Where the foundations lead",
  sec:[
  ["What you now know",[
    "These foundations have covered how music works, its instruments, its great eras from the ancient world to the streaming age, its many traditions across continents, the craft of musicianship, and music's place in our brains, bodies, and societies. Together they form the basic literacy that professional musicians, critics, and educators share.",
    "But music is endless: every chapter opens into deeper study, and the branches ahead let you specialize in any direction."]],
  ["Listening widely and deeply",[
    "Two complementary habits build musical understanding. Listening widely means exploring genres, eras, and cultures you don't know: a raga one day, a Bach cantata the next, Afrobeat, bluegrass, or a new album from a country you have never heard music from. Listening deeply means returning to works many times, following instruments, analyzing form, and comparing performances.",
    "Building listening lists by theme, era, or place, and noting what you hear, turns passive consumption into active learning."]],
  ["Making music",[
    "Understanding grows fastest when listening is joined by doing: singing, playing an instrument, composing, producing, or dancing. Even simple activities, clapping rhythms, singing intervals, or picking out a melody on a keyboard, connect theory to experience.",
    "Joining a choir, band, or community orchestra brings the social joy that has always been at music's heart."]],
  ["Live music and community",[
    "Attend concerts of every kind: symphony and opera, jazz clubs, folk sessions, festivals, school and community performances, and religious services with music. Talk to musicians; many are happy to explain their craft.",
    "Supporting local musicians, buying music directly from artists, and attending small venues helps sustain musical culture."]],
  ["Questions for a lifetime",[
    "Some questions in music have no final answer: What makes music meaningful? Why do we disagree about what is good? How should traditions be preserved and changed? What do we owe the creators whose work moves us? Can machines make art?",
    "Returning to these questions as your knowledge grows keeps music a living, ever-deepening part of life."]],
  ["Next steps",[
    "The specialized branches of this subject build on these foundations: deeper histories of single eras and genres, detailed theory, focused study of composers and artists, regional traditions, and practical skills. Your reading and listening will make the branches your own.",
    "In words often attributed to the 19th-century writer Victor Hugo, music expresses that which cannot be put into words and that which cannot remain silent. The more you learn, the more of it you will hear."]]
  ],
  terms:[["Listening widely","Exploring many genres, eras, and cultures."],["Listening deeply","Returning to works and studying them closely."],["Musical literacy","Shared knowledge of music's elements and history."],["Community music","Amateur music-making in groups."],["Branch","A specialized path building on the foundations."]],
  w:"Music is a lifelong companion; these foundations are a starting point for listening, playing, and learning without end.",
  src:["Music","Music appreciation","Community music","Victor Hugo","Musicianship"],
  q:[
  ["What does 'listening widely' mean?","Exploring many genres, eras, and cultures","Listening at high volume","Listening in large halls","Listening with others"],
  ["What does 'listening deeply' mean?","Returning to works and studying them closely","Listening to bass-heavy music","Listening late at night","Listening only to classical music"],
  ["What speeds musical understanding most, according to this chapter?","Combining listening with making music","Reading only","Memorizing composers' dates","Listening only in the background"],
  ["Who said music expresses what cannot be put into words and cannot remain silent?","Victor Hugo","Beethoven","Plato","Leonard Bernstein"],
  ["Which is a way to support musical culture?","Attending small venues and buying from artists","Only streaming free music","Avoiding live music","Ignoring local musicians"],
  ["Which question about music has no final answer?","What makes music meaningful","How many keys a piano has","Who wrote Messiah","What year MIDI was introduced"]]}

);


/* ---- from music-26.js ---- */
/* MUSIC FOUNDATIONS, part 26: genre-history chapters appended to Unit 4 */
COURSES.music.units[3].ch.push(

{ t:"The Symphony Through Time", s:"A listener's map of the great genre",
  sec:[
  ["Origins",[
    "The word symphony comes from the Greek for 'sounding together.' In the early 18th century, the Italian opera overture (sinfonia), in three short sections fast–slow–fast, began to be played as a concert piece. Composers such as Giovanni Battista Sammartini in Milan and Johann Stamitz at Mannheim turned it into an independent orchestral genre, and the Mannheim composers added a minuet as a fourth movement.",
    "By the 1760s the four-movement plan (fast sonata-form movement, slow movement, minuet, fast finale) was becoming standard."]],
  ["The Classical symphony",[
    "Haydn wrote 104 symphonies, exploring every possibility of the form, often with slow introductions, wit, and surprise. Mozart's last three symphonies (Nos. 39–41, 1788) combined lyricism and drama, ending with the 'Jupiter' finale's brilliant combination of five themes in counterpoint.",
    "Beethoven's nine symphonies transformed the genre into the most prestigious form of instrumental music: larger, more dramatic, often moving from struggle to victory, and in the Ninth adding voices. After Beethoven, writing a symphony became a test of seriousness for composers."]],
  ["The Romantic symphony",[
    "Schubert's 'Unfinished' and 'Great' C major, Mendelssohn's 'Scottish' and 'Italian,' Schumann's four symphonies, and Berlioz's programmatic Symphonie fantastique carried the genre forward. Brahms's four symphonies (1876–1885) combined Beethovenian structure with Romantic warmth; Bruckner's nine are vast and spiritual; Dvořák's Ninth 'From the New World' and Tchaikovsky's last three are among the most popular ever written.",
    "Mahler's symphonies expanded to enormous length and forces, including voices, song, and off-stage bands."]],
  ["The 20th century and beyond",[
    "Sibelius's seven symphonies explored organic growth, with themes emerging from fragments; his one-movement Seventh (1924) compresses a symphony's journey. Prokofiev, Shostakovich (15 symphonies), Vaughan Williams (9), Nielsen, Copland (Third Symphony, using Fanfare for the Common Man), Messiaen's Turangalîla-Symphonie, and Górecki's Symphony No. 3 show the form's continuing vitality.",
    "Many modern composers stopped calling large orchestral works symphonies, but the idea of an extended, multi-movement orchestral argument remains central to concert life."]],
  ["How to listen to a symphony",[
    "Before listening, note the number of movements and their tempo markings. In the first movement, listen for the contrasting themes of the exposition, the turbulence of the development, and the return in the recapitulation. In the slow movement, follow the main melody and its variations; in the minuet or scherzo, enjoy the dance-like rhythm and the contrasting trio; in the finale, listen for how the work resolves its journey.",
    "Notice how themes reappear across movements in cyclic symphonies, such as Beethoven's Fifth, Franck's Symphony in D minor, and Tchaikovsky's Fifth."]]
  ],
  terms:[["Sinfonia","Italian opera overture, ancestor of the symphony."],["Cyclic form","Themes recurring across movements."],["Scherzo","Fast, playful third movement after Beethoven."],["Finale","Last movement of a multi-movement work."],["Programmatic symphony","Symphony with a story or program."]],
  w:"The symphony is the backbone of orchestral concerts; knowing its history and plan makes any symphony easier to follow.",
  src:["Symphony","Sinfonia","Symphony No. 41 (Mozart)","Jean Sibelius","Cyclic form"],
  q:[
  ["What did the symphony develop from?","The Italian opera overture (sinfonia)","The French suite","The Baroque concerto grosso only","Gregorian chant"],
  ["Which Mozart symphony ends with a finale combining five themes?","No. 41 'Jupiter'","No. 40","No. 39","No. 38 'Prague'"],
  ["Which Sibelius symphony is in a single movement?","No. 7","No. 1","No. 2","No. 5"],
  ["How many symphonies did Shostakovich write?","15","9","7","104"],
  ["What is cyclic form?","Themes recurring across movements","A rondo","A circle of fifths progression","A repeated rhythm"],
  ["Which Mannheim composer helped establish the symphony?","Johann Stamitz","J. S. Bach","Lully","Corelli"]]},

{ t:"The Concerto and the Virtuoso", s:"Soloist versus orchestra",
  sec:[
  ["Baroque beginnings",[
    "The concerto, from the Italian concertare (perhaps 'to join together' or 'to contend'), began in the Baroque as the concerto grosso (Corelli, Handel, Bach's Brandenburg Concertos) and the solo concerto, perfected by Vivaldi in ritornello form, with orchestral refrains framing solo episodes.",
    "Bach's harpsichord concertos, adapted partly from his violin concertos, are among the first keyboard concertos."]],
  ["The Classical concerto",[
    "Mozart's 27 piano concertos established the Classical concerto: three movements (fast, slow, fast), with a 'double exposition' in which the orchestra presents themes before the soloist enters, a cadenza near the end of the first movement, and a dialogue of equals between soloist and orchestra. His concertos for violin, horn, flute, and clarinet are also central.",
    "Haydn's Trumpet and Cello Concertos and Beethoven's five piano concertos and Violin Concerto followed; Beethoven wrote out his own cadenzas in the 'Emperor' Concerto, beginning the decline of improvised cadenzas."]],
  ["The Romantic virtuoso",[
    "In the 19th century, the virtuoso became a celebrity. Niccolò Paganini (1782–1840), the Italian violinist whose technique seemed supernatural, rumored to have sold his soul to the devil, astonished Europe; his 24 Caprices inspired Liszt, Schumann, Brahms, and Rachmaninoff to write variations.",
    "Romantic concertos dramatized the hero-soloist against the orchestra: Mendelssohn's and Bruch's violin concertos, Chopin's two piano concertos, Schumann's Piano Concerto, Liszt's, Grieg's, Tchaikovsky's First Piano Concerto and Violin Concerto, Brahms's 'symphonic' concertos, Dvořák's Cello Concerto, and Rachmaninoff's Second and Third Piano Concertos."]],
  ["Modern concertos",[
    "The 20th century produced landmark concertos by Elgar (Cello Concerto), Sibelius (Violin Concerto), Ravel (two piano concertos), Prokofiev, Bartók (including the Concerto for Orchestra, where every section is treated as a soloist), Berg ('To the Memory of an Angel'), Shostakovich, Rodrigo (Concierto de Aranjuez for guitar), and Barber. Gershwin's Rhapsody in Blue and Concerto in F brought jazz into the form.",
    "Contemporary composers continue to write concertos for traditional and unusual soloists, including percussion, saxophone, electric guitar, and even turntables."]],
  ["Competitions and careers",[
    "International competitions launch soloists' careers: the Chopin Competition in Warsaw (since 1927), the Tchaikovsky Competition in Moscow (won in 1958 by American pianist Van Cliburn, a Cold War sensation), the Queen Elisabeth Competition in Brussels, and the Van Cliburn Competition in Texas.",
    "Today's soloists, such as pianists Yuja Wang and Seong-Jin Cho, violinists Hilary Hahn and Joshua Bell, and cellist Sheku Kanneh-Mason, combine virtuosity with interpretive depth, carrying on the concerto tradition."]]
  ],
  terms:[["Concerto","Work for soloist(s) and orchestra."],["Double exposition","Orchestra and soloist each present the themes."],["Ritornello","Recurring orchestral refrain."],["Virtuoso","Performer of exceptional technical skill."],["Concerto for orchestra","Work treating orchestral sections as soloists."]],
  w:"The concerto showcases the drama between individual and group, and it remains a centerpiece of concerts.",
  src:["Concerto","Niccolò Paganini","Piano concerto","Concerto for Orchestra (Bartók)","Van Cliburn"],
  q:[
  ["Which violinist was rumored to have sold his soul to the devil?","Niccolò Paganini","Jascha Heifetz","Antonio Vivaldi","Pablo de Sarasate"],
  ["How many piano concertos did Mozart write?","27","5","9","41"],
  ["What is a double exposition?","Orchestra presents themes before the soloist enters","Two soloists playing at once","Repeating the whole concerto","Two cadenzas"],
  ["Who won the 1958 Tchaikovsky Competition in a Cold War sensation?","Van Cliburn","Vladimir Ashkenazy","Glenn Gould","Leonard Bernstein"],
  ["Which Bartók work treats orchestral sections as soloists?","Concerto for Orchestra","Music for Strings, Percussion and Celesta","Mikrokosmos","Bluebeard's Castle"],
  ["Which concerto did Beethoven write with his own written-out cadenza?","Piano Concerto No. 5 'Emperor'","Violin Concerto","Triple Concerto","Piano Concerto No. 1"]]}

);
