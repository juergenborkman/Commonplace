/* ---- from hist-01.js ---- */
/* HISTORY FOUNDATIONS, part 1: Unit 1 (Thinking Like a Historian) */
COURSES.history = { units: [] };
COURSES.history.units.push({ t:"Thinking Like a Historian", ch:[

{ t:"What Is History?", s:"The past, the record, and the stories we tell",
  sec:[
  ["The past and history",[
    "The past is everything that has happened. History is our attempt to know and explain it, based on surviving evidence. The difference matters: the past is gone and cannot be changed, but history is constantly revised as historians find new sources, ask new questions, and correct earlier mistakes. The Greek word historia originally meant “inquiry,” and Herodotus (c. 484–425 BCE), often called the “Father of History,” used it for his investigation of the wars between Greeks and Persians.",
    "Herodotus' younger contemporary Thucydides, who wrote a history of the Peloponnesian War, set a stricter standard, criticizing myths and seeking accurate accounts of events and causes. In China, Sima Qian (c. 145–86 BCE) wrote the Records of the Grand Historian, a model for later Chinese official histories. In the 14th century, the North African scholar Ibn Khaldun analyzed the rise and fall of dynasties in social and economic terms. Every civilization has developed ways of remembering and explaining its past."]],
  ["Why study history?",[
    "History explains how the world came to be the way it is: why borders lie where they do, why some countries are rich and others poor, why certain conflicts persist, and why institutions such as constitutions, courts, and markets work as they do. Without history, the present is unintelligible.",
    "History also trains skills: weighing evidence, detecting bias, understanding people unlike ourselves, recognizing that events have multiple causes, and constructing arguments from incomplete information. These are the same skills used in law, journalism, intelligence analysis, and business. History cautions against easy analogies and predictions. Mark Twain is often credited with the saying that history does not repeat itself but it does rhyme, though there is no evidence he said it; the point is that patterns recur without exact repetition."]],
  ["Historiography: how history is written",[
    "Historiography is the study of how history has been written. Interpretations change with each generation. In the 19th century, the German historian Leopold von Ranke urged historians to show the past “as it actually was,” based on rigorous use of archival documents, and history became a professional academic discipline.",
    "Twentieth-century historians broadened the field. The French Annales school, led by Marc Bloch and Fernand Braudel, studied long-term structures such as geography, climate, and economics, not just political events. Social historians studied ordinary people, “history from below,” including workers, peasants, women, and enslaved people. Cultural historians studied beliefs, rituals, and meanings. Global historians study connections across regions, such as trade networks, migrations, and pandemics. Each approach reveals different aspects of the past."]],
  ["Dividing up time",[
    "Historians organize the past into periods, such as antiquity, the Middle Ages, and the modern era. These labels are useful but artificial. “Middle Ages” was coined by Renaissance writers who saw their own age as a rebirth after a dark interval, a view modern historians reject. Periods also differ by region: the “medieval” period in Europe does not map neatly onto Chinese or African history.",
    "Dates are commonly given as BCE (Before the Common Era) and CE (Common Era), which correspond to the older BC (Before Christ) and AD (Anno Domini, “in the year of the Lord”). There is no year zero: 1 BCE is followed by 1 CE. Centuries are numbered from 1, so the 1900s are the 20th century. Historians also use broad terms such as “prehistory,” the time before written records, which began around 3200 BCE in Mesopotamia and Egypt but much later in other places."]],
  ["Interpretation and bias",[
    "All history involves interpretation. Historians must select which facts matter, explain causes, and build narratives, and these choices are shaped by their questions, values, and the sources that survive. The saying that “history is written by the victors” captures a real problem: the defeated, the poor, women, and colonized peoples often left fewer records or had their stories told by others.",
    "This does not mean all interpretations are equally valid. Good history is accountable to evidence, considers alternative explanations, and acknowledges uncertainty. Historians distinguish between legitimate revision, reinterpreting the past in light of new evidence and questions, and denial, such as Holocaust denial, which ignores overwhelming evidence for ideological reasons."]],
  ["Big questions in history",[
    "Historians debate recurring big questions. How much do individuals shape history, and how much do larger forces such as economics, geography, technology, and ideas? The 19th-century writer Thomas Carlyle argued that history is “the biography of great men”; others emphasize social structures and collective action. Most historians see an interplay: individuals act within circumstances they did not choose, as Marx put it.",
    "Other questions include why some societies became more powerful than others, a question tackled by Jared Diamond's Guns, Germs, and Steel (1997), which emphasized geography, and by economic historians who stress institutions; whether history shows progress; and how much is contingent, depending on chance events that could have turned out otherwise. These questions run through the rest of this course."]]
  ],
  terms:[["Historiography","The study of how history has been written and interpreted."],["Primary vs. secondary source","Evidence from the time studied vs. later interpretation."],["Periodization","Dividing the past into named periods."],["BCE/CE","Before the Common Era / Common Era, equivalent to BC/AD."],["Annales school","French historians who studied long-term structures."],["History from below","History focused on ordinary people rather than elites."]],
  w:"Understanding how history is made helps you read every historical claim critically, from textbooks to political speeches.",
  src:["History","Historiography","Herodotus","Annales school","Periodization","Common Era"],
  q:[["Who is often called the “Father of History”?","Herodotus","Thucydides","Sima Qian","Ibn Khaldun"],
     ["Which Chinese historian wrote the Records of the Grand Historian?","Sima Qian","Confucius","Ban Gu","Zhu Xi"],
     ["Which historian urged showing the past “as it actually was”?","Leopold von Ranke","Fernand Braudel","Marc Bloch","Thomas Carlyle"],
     ["Which school studied long-term structures like geography and climate?","The Annales school","The Whig school","The Frankfurt School","The Chicago school"],
     ["What year follows 1 BCE?","1 CE","0 CE","2 CE","There is no answer"],
     ["Which book emphasized geography in explaining global inequality?","Guns, Germs, and Steel","The Wealth of Nations","Sapiens","The Clash of Civilizations"]]},

{ t:"Evidence and Method", s:"How historians know what they know",
  sec:[
  ["Primary and secondary sources",[
    "Historians work from sources. Primary sources are evidence created during the period being studied: letters, diaries, government records, newspapers, laws, photographs, maps, artifacts, buildings, and oral testimony from participants. Secondary sources are later works that interpret primary sources, such as scholarly books and articles. Textbooks and encyclopedias are often called tertiary sources, summarizing secondary work.",
    "The same document can be primary or secondary depending on the question. A 1950s history of the Civil War is a secondary source about the Civil War but a primary source about how Americans in the 1950s remembered it."]],
  ["Evaluating sources",[
    "Historians question every source. Who created it, when, and why? Who was the intended audience? What did the author know, and what might they have wanted to hide or emphasize? Is it consistent with other evidence? A general's report of a battle may exaggerate his success; a court record shows how authorities described events, not necessarily what happened.",
    "Historians practice corroboration, comparing multiple independent sources, and contextualization, understanding a source within its time and place. They also pay attention to silences: what is missing from the record, and why. The lives of enslaved people, for example, often must be reconstructed from records created by enslavers, such as plantation account books and runaway advertisements, read “against the grain” for evidence of resistance and community."]],
  ["Archaeology and material evidence",[
    "For periods and peoples without writing, and as a check on written sources, historians rely on archaeology, the study of material remains. Excavations reveal buildings, tools, pottery, burials, and food remains. Archaeologists use stratigraphy, the principle that lower layers of soil are generally older than higher ones, to establish sequences.",
    "Scientific dating methods transformed the field. Radiocarbon dating, developed by Willard Libby in the late 1940s, measures the decay of carbon-14 in organic materials and can date remains up to about 50,000 years old. Dendrochronology dates wood by tree-ring patterns. Ancient DNA analysis, which advanced rapidly in the 2010s, now reveals ancient migrations and relationships among populations, reshaping understanding of prehistory."]],
  ["Other kinds of evidence",[
    "Historians also use oral history, recorded interviews with people about their experiences, which preserves the voices of those who left few written records. The Federal Writers' Project in the 1930s recorded more than 2,300 interviews with formerly enslaved people, an invaluable though complex source because of the conditions under which interviews were conducted.",
    "Quantitative history uses statistics from censuses, tax records, prices, and trade figures to study population, economics, and social change. Historians increasingly use scientific evidence such as ice cores and tree rings to study past climate, and digital tools to analyze large collections of texts. Art, literature, and music are also historical evidence, revealing values and experiences."]],
  ["Causation and argument",[
    "Historians do not just record events; they explain them. Explanations typically involve multiple causes operating at different levels. A common distinction separates long-term causes (underlying conditions), short-term causes, and triggers. For World War I, long-term causes include alliances, militarism, imperial rivalry, and nationalism; the trigger was the assassination of Archduke Franz Ferdinand in 1914.",
    "Historians also consider contingency, the role of chance and choice. Could events have gone differently? Counterfactual questions, such as “What if the South had won at Gettysburg?”, can clarify which causes mattered, though historians use them cautiously. Good historical writing makes an argument, a thesis supported by evidence, and engages with other historians' interpretations."]],
  ["Avoiding common errors",[
    "Presentism means judging the past only by present standards or assuming past people thought like us. Historians try to understand people in their own context, while still being able to make moral judgments. Teleology, or hindsight bias, means treating outcomes as inevitable because we know they happened; people in the past did not know how events would end.",
    "Other errors include relying on a single source, confusing correlation with causation, and “great man” narratives that ignore the many people who made events possible. The historian's discipline is to follow evidence where it leads, acknowledge what cannot be known, and revise conclusions when new evidence appears."]]
  ],
  terms:[["Primary source","Evidence created during the period studied."],["Corroboration","Checking a source against independent evidence."],["Reading against the grain","Interpreting a source for information its author did not intend to reveal."],["Radiocarbon dating","Dating organic remains by the decay of carbon-14."],["Contingency","The role of chance and choice in historical outcomes."],["Presentism","Judging or interpreting the past only through present assumptions."]],
  w:"These methods are the foundation of every historical claim in this course, and they are the same evidence skills used in law and investigation.",
  src:["Primary source","Source criticism","Radiocarbon dating","Oral history","Historical method","Presentism (historical analysis)"],
  q:[["What is a primary source?","Evidence created during the period studied","A textbook","A later scholarly interpretation","An encyclopedia article"],
     ["Who developed radiocarbon dating?","Willard Libby","Marie Curie","Howard Carter","Leopold von Ranke"],
     ["What does stratigraphy rely on?","Lower layers are generally older","Tree rings","Carbon decay","DNA"],
     ["Which 1930s project recorded interviews with formerly enslaved people?","The Federal Writers' Project","The Library of Congress Map Project","The Smithsonian Archive","The WPA Art Project"],
     ["What is presentism?","Judging the past only by present standards","Focusing on recent history","Using present tense in writing","Ignoring the future"],
     ["What does dendrochronology use to date wood?","Tree rings","Carbon-14","Pollen","Soil layers"]]},

{ t:"Human Origins and the Neolithic Revolution", s:"From the first humans to the first farmers",
  sec:[
  ["Human evolution",[
    "Humans belong to the hominins, a group that diverged from the ancestors of chimpanzees roughly six to seven million years ago in Africa. Early hominins such as the australopithecines, including the famous fossil “Lucy” (about 3.2 million years old, found in Ethiopia in 1974), walked upright but had small brains. The genus Homo appeared about 2.5 million years ago. Homo erectus, which emerged around 1.9 million years ago, was the first hominin to spread out of Africa into Asia and Europe and used more sophisticated stone tools and likely fire.",
    "Our own species, Homo sapiens, evolved in Africa. Fossils from Jebel Irhoud in Morocco, dated to about 300,000 years ago, are among the oldest known. For much of prehistory, several human species coexisted, including the Neanderthals in Europe and western Asia and the Denisovans in Asia. Genetic evidence shows that Homo sapiens interbred with both; many people today carry a small percentage of Neanderthal DNA."]],
  ["Out of Africa and the peopling of the world",[
    "Modern humans spread out of Africa in waves, with a major dispersal around 60,000 to 70,000 years ago. They reached Australia by at least 50,000 years ago, crossing open water, and Europe by around 45,000 years ago. People reached the Americas from Asia by the end of the last Ice Age; most evidence points to arrivals at least 15,000 to 16,000 years ago, and footprints in New Mexico suggest possibly earlier, a question still debated.",
    "Paleolithic (Old Stone Age) people lived as hunter-gatherers in small, mobile bands. They created sophisticated tools, clothing, and art. Cave paintings at Chauvet and Lascaux in France, some more than 30,000 years old, and even older art in Indonesia show that symbolic thought and creativity are ancient features of humanity. Neanderthals disappeared around 40,000 years ago, for reasons that are still debated."]],
  ["The Neolithic Revolution",[
    "Around 10,000 BCE, as the last Ice Age ended, some humans began cultivating plants and domesticating animals, a transformation called the Neolithic (New Stone Age) Revolution or the Agricultural Revolution. The earliest well-documented farming emerged in the Fertile Crescent, an arc of land from the eastern Mediterranean through Mesopotamia, where people domesticated wheat, barley, lentils, sheep, goats, and cattle.",
    "Agriculture arose independently in several other regions: rice and millet in China; maize, beans, and squash in Mesoamerica; potatoes and llamas in the Andes; sorghum in Africa; and crops in New Guinea. This independent invention in multiple places shows that farming was a widespread human response to changing environments, not a single discovery that spread from one source."]],
  ["Consequences of farming",[
    "Farming allowed far denser populations and permanent villages, such as Çatalhöyük in Anatolia (modern Turkey), home to thousands of people around 7000 BCE. Food surpluses supported people who did not farm, such as craftspeople, priests, and rulers, leading to specialization, trade, and social hierarchy. Property in land and herds became important, and with it inequality and organized warfare.",
    "Farming also had costs. Skeletons show that early farmers were often shorter and less healthy than hunter-gatherers, with more dental problems and diseases, partly because of less varied diets and close contact with animals and with crowded neighbors. The historian Yuval Noah Harari provocatively called agriculture “history's biggest fraud,” and Jared Diamond called it “the worst mistake in the history of the human race,” though both acknowledged it made civilization possible."]],
  ["Toward civilization",[
    "Some monumental sites predate farming. Göbekli Tepe in southeastern Turkey, with massive carved stone pillars dated to around 9500 BCE, was built by people who were largely hunter-gatherers, suggesting that religious or social gatherings may have helped drive settlement. Later, the invention of pottery, weaving, and metallurgy, beginning with copper and then bronze, transformed technology. The Bronze Age began around 3300 BCE in the Near East.",
    "Historians often define “civilization” by features such as cities, specialized labor, centralized government, social classes, monumental architecture, and writing. The first societies with all these features arose in river valleys, where fertile soil and water supported large populations: Mesopotamia, Egypt, the Indus Valley, and China. The next unit begins with them."]]
  ],
  terms:[["Hominin","The group including humans and their extinct close relatives."],["Homo sapiens","Our species, which evolved in Africa about 300,000 years ago."],["Paleolithic","The Old Stone Age of hunter-gatherers."],["Neolithic Revolution","The transition to farming and settled life beginning around 10,000 BCE."],["Fertile Crescent","The region of the Near East where early farming developed."],["Bronze Age","The period when bronze tools and weapons became widespread."]],
  w:"The shift to farming set the stage for cities, states, inequality, and everything that followed. Understanding human origins puts all of recorded history in perspective.",
  src:["Human evolution","Early human migrations","Neolithic Revolution","Fertile Crescent","Göbekli Tepe","Çatalhöyük"],
  q:[["Where did Homo sapiens evolve?","Africa","Europe","Asia","Australia"],
     ["About how old are the Jebel Irhoud fossils of Homo sapiens?","300,000 years","30,000 years","3 million years","10,000 years"],
     ["Which other human species did Homo sapiens interbreed with?","Neanderthals and Denisovans","Australopithecines only","Homo erectus only","None"],
     ["Where did the earliest well-documented farming emerge?","The Fertile Crescent","The Amazon","Northern Europe","Siberia"],
     ["Which site with carved stone pillars dates to about 9500 BCE?","Göbekli Tepe","Stonehenge","Çatalhöyük","Jericho"],
     ["Which crops were domesticated in Mesoamerica?","Maize, beans, and squash","Wheat and barley","Rice and millet","Potatoes and quinoa"]]}
]});


/* ---- from hist-02.js ---- */
/* HISTORY FOUNDATIONS, part 2: Unit 2 (The Ancient World), chapters 1-5 */
COURSES.history.units.push({ t:"The Ancient World", ch:[

{ t:"Mesopotamia", s:"The land between the rivers",
  sec:[
  ["Cities on the Tigris and Euphrates",[
    "Mesopotamia, Greek for “between the rivers,” refers to the region between the Tigris and Euphrates in present-day Iraq and parts of Syria and Turkey. Its rivers flooded unpredictably, so farmers built canals and irrigation systems, which required organized labor and leadership. By around 3500 BCE, the Sumerians in southern Mesopotamia had built the world's first cities, including Uruk, which may have held tens of thousands of people.",
    "Each Sumerian city-state, such as Ur, Lagash, and Kish, was centered on a temple to its patron god, often built on a stepped platform called a ziggurat. Priests and later kings managed land, labor, and stored grain. City-states frequently fought over water and land."]],
  ["Writing and knowledge",[
    "The Sumerians invented writing around 3200 BCE. Cuneiform (“wedge-shaped”) began as pictures pressed into clay to keep accounts of grain and livestock and evolved into a script of hundreds of signs representing words and syllables. It was used for more than 3,000 years and adapted for many languages, including Akkadian, Babylonian, and Hittite. Scribes trained for years in schools called “tablet houses.”",
    "Mesopotamians developed mathematics based on the number 60, which is why we still divide hours into 60 minutes and circles into 360 degrees. They recorded astronomical observations, created calendars, and produced literature, including the Epic of Gilgamesh, the story of a king of Uruk who searches for immortality after his friend's death. It includes a flood story with striking parallels to the biblical story of Noah."]],
  ["Empires: Akkad and Babylon",[
    "Around 2334 BCE, Sargon of Akkad conquered the Sumerian cities and created what is often called the first empire, uniting many peoples under one ruler. After its collapse, Sumerian culture revived under the Third Dynasty of Ur. In the 18th century BCE, Hammurabi of Babylon unified much of Mesopotamia.",
    "Hammurabi's law code, carved on a basalt stele now in the Louvre, contains 282 laws covering trade, property, family, labor, and crime. It is famous for the principle of retaliation (“an eye for an eye”), but punishments depended on social class: injuring a noble brought harsher penalties than injuring a commoner or an enslaved person. The code's prologue claims the gods appointed Hammurabi to “bring about the rule of righteousness in the land,” an early statement of justice as a royal duty."]],
  ["Assyria and the Neo-Babylonians",[
    "From the 9th to the 7th centuries BCE, the Assyrian Empire, based in northern Mesopotamia, dominated the Near East with a powerful army that used iron weapons, siege engines, and mass deportations of conquered peoples. Its capital Nineveh housed the library of King Ashurbanipal, whose thousands of clay tablets preserved much of Mesopotamian literature, including the Epic of Gilgamesh.",
    "Assyria fell in 612 BCE to a coalition of Babylonians and Medes. The Neo-Babylonian Empire under Nebuchadnezzar II rebuilt Babylon with the famous Ishtar Gate and, according to later tradition, the Hanging Gardens. In 587 or 586 BCE, Nebuchadnezzar destroyed Jerusalem and deported many of its people to Babylon, the Babylonian Exile. In 539 BCE, Cyrus the Great of Persia conquered Babylon."]],
  ["Legacy",[
    "Mesopotamia gave the world cities, writing, written law, the 60-based measurement of time, early astronomy and mathematics, the wheel (used for pottery and then vehicles by around 3500 BCE), and some of its earliest literature. Its religions, with many gods who controlled natural forces and expected sacrifices, influenced later Near Eastern cultures.",
    "Its history also shows recurring patterns: the dependence of civilization on environmental management, the rise and fall of empires, and the use of law and religion to legitimize power. Modern Iraq's archaeological heritage has suffered from looting and war, including the looting of the National Museum in Baghdad in 2003 and the destruction of sites by the Islamic State group in the 2010s."]]
  ],
  terms:[["Mesopotamia","The region between the Tigris and Euphrates rivers."],["Ziggurat","A stepped temple platform in Mesopotamian cities."],["Cuneiform","The wedge-shaped writing system invented by the Sumerians."],["Code of Hammurabi","A Babylonian law code of 282 laws from the 18th century BCE."],["Sargon of Akkad","Founder of what is often called the first empire."],["Babylonian Exile","The deportation of people from Judah to Babylon after 587/586 BCE."]],
  w:"Mesopotamia is where cities, writing, and written law began, laying foundations for every later civilization.",
  src:["Mesopotamia","Sumer","Cuneiform","Code of Hammurabi","Assyria","Epic of Gilgamesh"],
  q:[["What does Mesopotamia mean?","Between the rivers","Land of the sun","Fertile valley","City of gods"],
     ["When did the Sumerians invent writing?","Around 3200 BCE","Around 1000 BCE","Around 500 BCE","Around 8000 BCE"],
     ["Who is often credited with creating the first empire?","Sargon of Akkad","Hammurabi","Nebuchadnezzar II","Cyrus the Great"],
     ["How many laws are in the Code of Hammurabi?","282","10","1,000","613"],
     ["Whose library at Nineveh preserved the Epic of Gilgamesh?","Ashurbanipal","Sargon","Hammurabi","Nebuchadnezzar"],
     ["Why do we divide hours into 60 minutes?","The Mesopotamians used a base-60 number system","The Egyptians had 60 gods","The Romans used 60 legions","It matches the Moon's cycle"]]},

{ t:"Ancient Egypt", s:"The gift of the Nile",
  sec:[
  ["The Nile",[
    "The Greek historian Herodotus called Egypt “the gift of the Nile.” Each summer the river flooded predictably, depositing fertile black silt along its banks, while desert on both sides protected Egypt from invasion. Egyptians called their land Kemet, “the black land.” The predictable flood shaped Egyptian life and religion, encouraging a worldview centered on order, stability, and cycles of renewal.",
    "Upper (southern) and Lower (northern) Egypt were unified around 3100 BCE, traditionally by a king named Narmer or Menes. Egyptian history is conventionally divided into the Old Kingdom, Middle Kingdom, and New Kingdom, periods of strong central rule separated by “intermediate periods” of fragmentation, with about thirty dynasties of pharaohs."]],
  ["Pharaohs, gods, and maat",[
    "The pharaoh was considered a god-king, the earthly embodiment of the falcon god Horus, responsible for maintaining maat, cosmic order, justice, and truth, against chaos. Egyptians worshipped many gods, including Ra, the sun god; Osiris, god of the dead and resurrection; his wife Isis; and Anubis, the jackal-headed god of embalming.",
    "Egyptians believed in an afterlife in which the soul would be judged. In the “weighing of the heart,” described in the Book of the Dead, the deceased's heart was weighed against the feather of maat. A heart heavy with sin was devoured by a monster; a pure heart passed to eternal life. Mummification preserved the body for the soul's use, and tombs were filled with goods for the afterlife."]],
  ["The Old Kingdom and the pyramids",[
    "During the Old Kingdom (c. 2686–2181 BCE), pharaohs built pyramids as royal tombs. The architect Imhotep designed the Step Pyramid of Djoser at Saqqara, the earliest large stone building. The Great Pyramid of Giza, built for the pharaoh Khufu around 2560 BCE, rose about 146 meters and was the tallest human-made structure for nearly four thousand years.",
    "The pyramids were built not by enslaved masses, as was long believed, but largely by paid, organized laborers, supported by rotating teams of farmers during the flood season. Archaeologists have found workers' villages, bakeries, and cemeteries near Giza. The pyramids' scale reveals the power of a centralized state able to mobilize enormous resources."]],
  ["Writing and knowledge",[
    "Egyptians developed hieroglyphs, a writing system combining pictures for words and sounds, around the same time as Mesopotamian cuneiform. Scribes also used faster scripts, hieratic and later demotic, on papyrus, an early paper made from reeds. Knowledge of hieroglyphs was lost after antiquity until the Rosetta Stone, discovered by French soldiers in 1799 and inscribed with the same decree in hieroglyphs, demotic, and Greek, allowed Jean-François Champollion to decipher them in 1822.",
    "Egyptians made advances in mathematics, used to survey fields after floods and plan buildings, and in medicine; medical papyri describe treatments for injuries and diseases. They developed a 365-day calendar, an ancestor of our own."]],
  ["The New Kingdom",[
    "During the New Kingdom (c. 1550–1070 BCE), Egypt built an empire stretching into the Levant and Nubia. Hatshepsut, one of the few female pharaohs, ruled successfully in the 15th century BCE, sponsoring trade expeditions and building projects. Akhenaten, in the 14th century BCE, attempted a religious revolution, promoting worship of the sun disk, the Aten, above all other gods, a short-lived experiment sometimes described as an early form of monotheism.",
    "Tutankhamun, a minor king who died young, became famous when Howard Carter discovered his nearly intact tomb in 1922. Ramesses II (reigned c. 1279–1213 BCE) built monuments such as Abu Simbel and fought the Hittites at the Battle of Kadesh; afterward, the two powers signed one of the earliest known peace treaties."]],
  ["Decline and legacy",[
    "After the New Kingdom, Egypt was ruled at times by Libyans, Nubians from the kingdom of Kush, Assyrians, and Persians. Alexander the Great conquered Egypt in 332 BCE, and his general Ptolemy founded a Greek-speaking dynasty that ruled from Alexandria. Its last ruler, Cleopatra VII, allied with Julius Caesar and then Mark Antony; after their defeat by Octavian at Actium in 31 BCE, Egypt became a Roman province in 30 BCE.",
    "Ancient Egypt lasted as a distinct civilization for about three thousand years, an extraordinary record of continuity. Its monuments, art, and ideas about kingship and the afterlife fascinated Greeks, Romans, and modern Europeans and Americans, inspiring the field of Egyptology."]]
  ],
  terms:[["Pharaoh","The god-king of ancient Egypt."],["Maat","The Egyptian principle of cosmic order, truth, and justice."],["Hieroglyphs","Egyptian writing combining pictures for words and sounds."],["Rosetta Stone","A trilingual inscription that enabled hieroglyphs to be deciphered."],["Old, Middle, New Kingdom","The three major periods of strong Egyptian central rule."],["Ptolemaic dynasty","The Greek-speaking dynasty that ruled Egypt after Alexander."]],
  w:"Egypt shows how geography shapes civilization, and its three-thousand-year history offers a model of continuity, monumental achievement, and centralized power.",
  src:["Ancient Egypt","Pharaoh","Great Pyramid of Giza","Rosetta Stone","New Kingdom of Egypt","Cleopatra"],
  q:[["Who called Egypt “the gift of the Nile”?","Herodotus","Plato","Champollion","Ramesses II"],
     ["For which pharaoh was the Great Pyramid built?","Khufu","Djoser","Tutankhamun","Ramesses II"],
     ["Who deciphered hieroglyphs using the Rosetta Stone?","Jean-François Champollion","Howard Carter","Napoleon","Imhotep"],
     ["Which pharaoh promoted worship of the Aten?","Akhenaten","Hatshepsut","Ramesses II","Khufu"],
     ["Who discovered Tutankhamun's tomb in 1922?","Howard Carter","Champollion","Flinders Petrie","Lord Carnarvon alone"],
     ["When did Egypt become a Roman province?","30 BCE","332 BCE","476 CE","1070 BCE"]]},

{ t:"Ancient India", s:"From the Indus Valley to the Mauryan Empire",
  sec:[
  ["The Indus Valley Civilization",[
    "One of the world's earliest urban civilizations flourished along the Indus River in present-day Pakistan and northwestern India, reaching its peak around 2600–1900 BCE. Its great cities, such as Harappa and Mohenjo-daro, were remarkably planned, with streets laid out in grids, standardized fired bricks, and sophisticated drainage systems with covered sewers, more advanced than in many later cities.",
    "The Indus people traded with Mesopotamia, used standardized weights, and produced carved stone seals bearing animal images and a script that has never been deciphered. Unlike Mesopotamia and Egypt, the Indus cities show little evidence of grand palaces or royal tombs, puzzling scholars about how they were governed. The civilization declined after about 1900 BCE, likely due to factors including climate change, shifting rivers, and declining trade."]],
  ["The Vedic period",[
    "Between about 1500 and 500 BCE, Indo-Aryan peoples speaking an early form of Sanskrit spread into northern India. Their sacred hymns, the Vedas, give the period its name. Society came to be organized into four varnas: Brahmins (priests), Kshatriyas (warriors and rulers), Vaishyas (merchants and farmers), and Shudras (laborers). Over many centuries, this framework combined with thousands of hereditary occupational groups, called jatis, to form the caste system; groups considered outside the system were later stigmatized as “untouchable.”",
    "Religious ideas developed from Vedic ritual sacrifice to the philosophical Upanishads, with concepts of karma, rebirth, and liberation that shaped Hinduism. By the 6th century BCE, northern India contained numerous kingdoms and republics and growing cities, a setting in which new religious movements arose."]],
  ["Buddhism and Jainism",[
    "In the 6th and 5th centuries BCE, Siddhartha Gautama, the Buddha, and Mahavira, the leading teacher of Jainism, challenged the authority of Brahmin priests and the Vedic sacrificial system. Both taught paths to liberation through ethical conduct and spiritual discipline open to people of any social background, and both emphasized non-violence.",
    "Buddhism spread widely, eventually becoming one of the world's major religions across Asia, while it later declined in India itself. Jainism remained smaller but influential, especially among merchant communities."]],
  ["The Mauryan Empire and Ashoka",[
    "After Alexander the Great's invasion of northwestern India in 326 BCE, Chandragupta Maurya founded the Mauryan Empire around 321 BCE, which came to rule most of the Indian subcontinent. His adviser is traditionally identified as Kautilya, author of the Arthashastra, a treatise on statecraft often compared to Machiavelli's The Prince.",
    "Chandragupta's grandson Ashoka (reigned c. 268–232 BCE) conquered the kingdom of Kalinga in a war that killed and displaced huge numbers of people. According to his own inscriptions, he was filled with remorse, embraced Buddhism, and promoted “dhamma,” a moral code of non-violence, tolerance of all religions, and care for people and animals. His edicts, carved on rocks and pillars across the empire, are among the earliest deciphered Indian texts. The lion capital of one of his pillars is India's national emblem today."]],
  ["The Gupta age",[
    "After the Mauryan Empire fragmented, the Gupta Empire (c. 320–550 CE) united much of northern India. The Gupta period is often called a classical or “golden” age for its achievements in literature, art, science, and mathematics. The poet Kalidasa wrote Sanskrit dramas, and Hindu temple architecture developed.",
    "Indian mathematicians developed the decimal place-value system with a symbol for zero. The astronomer Aryabhata (476–550 CE) calculated pi accurately and proposed that Earth rotates on its axis. Through Arab scholars, these “Hindu-Arabic” numerals reached Europe centuries later, transforming mathematics and commerce. Indian traders also carried goods and ideas across the Indian Ocean to Southeast Asia, spreading Hindu and Buddhist culture."]]
  ],
  terms:[["Indus Valley Civilization","An early urban civilization in present-day Pakistan and India."],["Mohenjo-daro","A major planned city of the Indus Valley."],["Varna","The four broad social classes of Vedic society."],["Caste system","India's hereditary social hierarchy combining varnas and jatis."],["Ashoka","Mauryan emperor who embraced Buddhism and promoted dhamma."],["Gupta Empire","The classical Indian empire of c. 320–550 CE."]],
  w:"Ancient India produced major world religions, the decimal system with zero, and enduring ideas about duty, non-violence, and social order.",
  src:["Indus Valley Civilisation","Vedic period","Maurya Empire","Ashoka","Gupta Empire","Hindu–Arabic numeral system"],
  q:[["Which Indus city is famous for its planned streets and drainage?","Mohenjo-daro","Pataliputra","Delhi","Varanasi"],
     ["What is notable about the Indus script?","It has never been deciphered","It is the ancestor of Latin","It was written on papyrus","It was deciphered with a trilingual stone"],
     ["Who founded the Mauryan Empire?","Chandragupta Maurya","Ashoka","Kautilya","Alexander"],
     ["Which war led Ashoka to embrace Buddhism?","The conquest of Kalinga","The invasion of Alexander","The Battle of Panipat","The war with Rome"],
     ["Which empire is associated with India's classical golden age?","The Gupta Empire","The Mughal Empire","The Mauryan Empire","The Delhi Sultanate"],
     ["Which mathematician-astronomer proposed that Earth rotates on its axis?","Aryabhata","Kalidasa","Kautilya","Brahmagupta"]]},

{ t:"Ancient China", s:"From the Shang to the Han",
  sec:[
  ["River valleys and early dynasties",[
    "Chinese civilization developed along the Yellow River (Huang He) and Yangtze River. The Yellow River's fertile loess soil supported millet farming, while rice was cultivated in the south. Its devastating floods earned it the name “China's Sorrow.” Traditional Chinese history begins with the Xia dynasty, but the first dynasty confirmed by archaeological and written evidence is the Shang (c. 1600–1046 BCE).",
    "The Shang developed bronze casting of extraordinary skill and the earliest Chinese writing, found on oracle bones: turtle shells and ox bones inscribed with questions to ancestors, then heated until they cracked so diviners could read the answers. Chinese writing has evolved continuously from these characters to the present, making it the oldest writing system still in use."]],
  ["The Zhou and the Mandate of Heaven",[
    "The Zhou dynasty overthrew the Shang around 1046 BCE and ruled, at least in name, until 256 BCE, longer than any other Chinese dynasty. To justify their conquest, the Zhou developed the concept of the Mandate of Heaven: Heaven grants the right to rule to a virtuous ruler and withdraws it from a corrupt one. Natural disasters and rebellion were signs that a dynasty had lost the mandate. This idea justified changes of dynasty throughout Chinese history.",
    "The Zhou ruled through a decentralized system in which nobles governed territories in exchange for loyalty. Over time these lords grew powerful, and from 771 BCE royal authority declined. The Spring and Autumn period and especially the Warring States period (c. 475–221 BCE) saw constant war among rival states, but also iron tools, expanding trade, and the “Hundred Schools of Thought,” including Confucianism, Daoism, and Legalism."]],
  ["The Qin unification",[
    "In 221 BCE, the state of Qin conquered its rivals and unified China. Its king took the new title Shi Huangdi, “First Emperor.” Applying Legalist principles, he replaced feudal lords with centrally appointed officials, standardized writing, weights, measures, currency, and axle widths, and built roads and canals. Connecting earlier walls, he began a defensive wall in the north, a precursor of the Great Wall; most of the Great Wall visible today was built much later, under the Ming dynasty.",
    "The First Emperor was also brutal. According to traditional accounts, he burned books and executed scholars who criticized him, and hundreds of thousands of laborers died on his projects. His tomb near Xi'an is guarded by the Terracotta Army, more than 7,000 life-size clay soldiers, discovered by farmers in 1974. The Qin dynasty collapsed in revolts soon after his death in 210 BCE, but the name “China” likely derives from Qin."]],
  ["The Han dynasty",[
    "The Han dynasty (206 BCE–220 CE) kept the Qin's centralized system while softening its harshness and adopting Confucianism as the official state ideology. Officials increasingly were selected and trained in Confucian classics, beginning the scholar-official tradition. The Han period was so formative that the majority ethnic group in China still calls itself the Han.",
    "Han China rivaled the Roman Empire in size and population. Its achievements included paper, invented by around the 2nd century BCE and improved by the court official Cai Lun around 105 CE; advances in astronomy, medicine, and metallurgy; and the seismoscope of Zhang Heng. The historian Sima Qian wrote the Records of the Grand Historian during this dynasty."]],
  ["The Silk Road",[
    "Under Emperor Wu (reigned 141–87 BCE), the Han expanded westward. The envoy Zhang Qian's missions to Central Asia opened contacts that developed into the Silk Road, a network of overland trade routes connecting China with Central Asia, Persia, India, and the Mediterranean. Chinese silk reached Rome, where it became a luxury so prized that Roman moralists complained about the drain of gold.",
    "Along with silk, the Silk Road carried horses, spices, glass, paper, technologies, diseases, and ideas, including Buddhism, which reached China from India in the 1st century CE. After the Han collapsed in 220 CE, China entered nearly four centuries of division before reunification under the Sui and Tang dynasties."]]
  ],
  terms:[["Shang dynasty","The first archaeologically confirmed Chinese dynasty."],["Oracle bones","Inscribed bones used for divination, bearing the earliest Chinese writing."],["Mandate of Heaven","The belief that Heaven grants the right to rule to virtuous rulers."],["Qin Shi Huang","The First Emperor, who unified China in 221 BCE."],["Han dynasty","The dynasty (206 BCE–220 CE) that made Confucianism official."],["Silk Road","Trade routes linking China with Central Asia, Persia, and the Mediterranean."]],
  w:"Ancient China established a centralized state, a continuous writing system, and ideas of legitimacy that shaped East Asia for two thousand years.",
  src:["Shang dynasty","Oracle bone","Mandate of Heaven","Qin Shi Huang","Han dynasty","Silk Road"],
  q:[["What were oracle bones used for?","Divination","Currency","Weapons","Calendars"],
     ["Which dynasty developed the concept of the Mandate of Heaven?","The Zhou","The Shang","The Qin","The Han"],
     ["In what year did the Qin unify China?","221 BCE","1046 BCE","206 BCE","618 CE"],
     ["When was the Terracotta Army discovered?","1974","1922","1799","1900"],
     ["Which dynasty made Confucianism the state ideology?","The Han","The Qin","The Zhou","The Shang"],
     ["Which religion reached China via the Silk Road in the 1st century CE?","Buddhism","Christianity","Islam","Zoroastrianism"]]},

{ t:"Persia and Ancient Israel", s:"Empire, tolerance, and monotheism",
  sec:[
  ["Cyrus and the Achaemenid Empire",[
    "In 550 BCE, Cyrus the Great of Persia, in present-day Iran, founded the Achaemenid Empire. Within decades, it became the largest empire the world had yet seen, stretching from the Indus Valley to Egypt and the Aegean. Cyrus conquered Media, Lydia (home of the fabulously wealthy King Croesus), and Babylon in 539 BCE.",
    "Cyrus was remembered for relative tolerance. The Cyrus Cylinder, a clay inscription from Babylon, describes him restoring temples and allowing deported peoples to return home. The Hebrew Bible praises him for allowing the Jewish exiles in Babylon to return to Jerusalem and rebuild their Temple. The cylinder is sometimes called an early charter of human rights, though historians caution that it was royal propaganda typical of Mesopotamian kings."]],
  ["Governing a vast empire",[
    "Darius I (reigned 522–486 BCE) organized the empire into provinces called satrapies, each governed by a satrap and required to pay tribute, while allowing local customs, laws, and religions to continue. He built the Royal Road, about 2,500 kilometers long from Sardis to Susa, with relay stations that allowed royal messengers to cross it in about a week. Herodotus' admiring description of these couriers inspired the unofficial motto of the U.S. Postal Service: “Neither snow nor rain nor heat nor gloom of night stays these couriers from the swift completion of their appointed rounds.”",
    "The Persians built magnificent capitals, such as Persepolis, standardized coinage, and used Aramaic as a common administrative language. Their religion, Zoroastrianism, founded by the prophet Zoroaster (Zarathustra), taught a cosmic struggle between Ahura Mazda, the wise lord of truth and light, and the forces of evil and falsehood, along with ideas of judgment after death that may have influenced Judaism, Christianity, and Islam."]],
  ["Persia and Greece",[
    "Persia's westward expansion brought it into conflict with Greek city-states. The Persian Wars (499–449 BCE) included famous Greek victories at Marathon (490 BCE) and Salamis (480 BCE), covered in the next chapter. Greek writers often portrayed Persia as despotic, an image that shaped later Western views, but the empire was generally well governed and culturally sophisticated.",
    "Alexander the Great conquered the Achaemenid Empire between 334 and 330 BCE, burning Persepolis. Later Persian empires, the Parthians and the Sasanians, rivaled Rome and Byzantium for centuries until the Arab Muslim conquest in the 7th century CE."]],
  ["Ancient Israel",[
    "The ancient Israelites lived in the region of Canaan, the land between the Mediterranean and the Jordan River. Their history is known from the Hebrew Bible and from archaeology, which sometimes support and sometimes complicate the biblical narratives. According to the Bible, the patriarch Abraham migrated to Canaan, his descendants were enslaved in Egypt and freed under Moses, and they received the law, including the Ten Commandments, at Mount Sinai. Historians debate how much of the early narratives reflect history.",
    "By around 1000 BCE, a kingdom had emerged; the Bible describes Saul, David, and Solomon as its kings, with David making Jerusalem his capital and Solomon building the First Temple. An inscription found at Tel Dan refers to the “House of David.” The kingdom later split into Israel in the north, conquered by Assyria in 722 BCE, and Judah in the south, conquered by Babylon in 587/586 BCE."]],
  ["Ethical monotheism and its legacy",[
    "The Israelites' most influential contribution was ethical monotheism: belief in a single, all-powerful God who demands justice and righteousness and has a covenant, or agreement, with his people. Prophets such as Amos and Isaiah condemned the mistreatment of the poor, widows, and strangers, insisting that ritual without justice was worthless.",
    "During and after the Babylonian Exile, much of the Hebrew Bible took its final form, and Judaism developed as a religion centered on the Torah. After the Persian king allowed return, the Second Temple was built. The Romans destroyed it in 70 CE, and Jews spread throughout the Mediterranean and beyond in a diaspora. Judaism's scriptures and ideas became foundations of both Christianity and Islam, making ancient Israel one of the most influential small societies in history."]]
  ],
  terms:[["Achaemenid Empire","The Persian empire founded by Cyrus the Great in 550 BCE."],["Satrapy","A province of the Persian Empire governed by a satrap."],["Royal Road","The Persian highway from Sardis to Susa."],["Zoroastrianism","The Persian religion of a cosmic struggle between good and evil."],["Covenant","The agreement between God and the Israelites."],["Ethical monotheism","Belief in one God who demands justice and righteousness."]],
  w:"Persia offered a model of a tolerant multinational empire, and ancient Israel's monotheism shaped the faith of billions of people.",
  src:["Achaemenid Empire","Cyrus the Great","Cyrus Cylinder","Zoroastrianism","History of ancient Israel and Judah","Monotheism"],
  q:[["Who founded the Achaemenid Persian Empire?","Cyrus the Great","Darius I","Xerxes","Alexander"],
     ["What were Persian provinces called?","Satrapies","Nomes","Prefectures","Themes"],
     ["Which Persian road inspired the U.S. Postal Service's unofficial motto?","The Royal Road","The Silk Road","The Appian Way","The Grand Trunk Road"],
     ["Who founded Zoroastrianism?","Zoroaster","Cyrus","Mani","Darius"],
     ["Which empire conquered the northern kingdom of Israel in 722 BCE?","Assyria","Babylon","Persia","Egypt"],
     ["When did the Romans destroy the Second Temple?","70 CE","587 BCE","135 CE","312 CE"]]}
]});


/* ---- from hist-03.js ---- */
/* HISTORY FOUNDATIONS, part 3: Unit 2 (The Ancient World), chapters 6-10 */
COURSES.history.units[1].ch.push(

{ t:"Ancient Greece", s:"City-states, democracy, and the Persian and Peloponnesian Wars",
  sec:[
  ["Geography and the polis",[
    "Greece is a land of mountains, small valleys, and islands, which encouraged the growth of many independent city-states rather than a single empire. Each polis, such as Athens, Sparta, Corinth, or Thebes, had its own government, laws, army, and patron gods, yet Greeks shared a language, religion, and festivals, including the Olympic Games, traditionally dated from 776 BCE.",
    "Before the city-states, Bronze Age Greece saw the Minoan civilization on Crete and the Mycenaean civilization on the mainland, which collapsed around 1200 BCE in a wider crisis that struck the eastern Mediterranean. After a “dark age,” Greece revived in the Archaic period (c. 800–480 BCE). Greeks adopted the Phoenician alphabet, adding vowels, and founded colonies around the Mediterranean and Black Sea, from southern Italy to Marseille. Homer's epics, the Iliad and the Odyssey, were composed in this period."]],
  ["Sparta and Athens",[
    "Sparta was a militaristic society. Spartan boys entered a harsh state training system, the agoge, at age seven, and adult men served as full-time soldiers. This was possible because a large enslaved population, the helots, farmed the land; fear of helot revolt shaped Spartan life. Spartan women had more freedom and property rights than women elsewhere in Greece.",
    "Athens developed democracy. The reforms of Solon in the early 6th century BCE abolished debt slavery, and those of Cleisthenes around 508 BCE created a democratic system in which male citizens voted directly in the Assembly, many officials were chosen by lottery, and juries had hundreds of members. Ostracism allowed citizens to exile a dangerous politician for ten years. Athenian democracy excluded women, enslaved people, and resident foreigners, so only a minority of residents participated, but it was the first known system of government by citizens on this scale."]],
  ["The Persian Wars",[
    "When Greek cities in Ionia revolted against Persian rule in 499 BCE with Athenian help, the Persian king Darius I sent an invasion force. In 490 BCE, Athenian soldiers defeated the Persians at Marathon. The legend of a runner who carried the news to Athens inspired the modern marathon race.",
    "In 480 BCE, Darius' son Xerxes invaded with a much larger army. At Thermopylae, a small force led by 300 Spartans under King Leonidas held a narrow pass for several days before being overwhelmed. Shortly after, the Athenian general Themistocles lured the Persian fleet into the narrow straits of Salamis, where the Greek navy won a decisive victory. The Greeks then defeated the Persian army at Plataea in 479 BCE. Victory gave the Greeks, especially Athens, enormous confidence."]],
  ["The Golden Age of Athens",[
    "After the wars, Athens led the Delian League, an alliance against Persia that it gradually turned into an empire, using allies' payments to fund its own projects. Under the statesman Pericles, who dominated Athenian politics from the 460s until his death in 429 BCE, Athens built the Parthenon and flourished as a center of drama, philosophy, art, and history.",
    "In the theater of Dionysus, Aeschylus, Sophocles, and Euripides wrote tragedies, and Aristophanes wrote comedies. Socrates questioned his fellow citizens, Herodotus and Thucydides wrote history, and sculptors and architects created works that defined classical style. Pericles' funeral oration, as reported by Thucydides, praised Athens as “the school of Hellas” and a democracy in which power is in the hands of the many."]],
  ["The Peloponnesian War",[
    "Rivalry between Athens and Sparta erupted in the Peloponnesian War (431–404 BCE). Thucydides, an Athenian general who wrote its history, attributed the war to “the growth of the power of Athens, and the alarm which this inspired in Sparta,” a dynamic modern scholars call the “Thucydides Trap.” Athens, a naval power, relied on its walls and fleet, while Sparta, a land power, ravaged the Athenian countryside. A devastating plague struck crowded Athens in 430 BCE, killing perhaps a quarter or more of its population, including Pericles.",
    "Athens' disastrous expedition to Sicily (415–413 BCE) destroyed much of its fleet and army. With Persian money, Sparta built a navy and won the war in 404 BCE. In the 4th century BCE, Greek city-states continued to fight one another until Philip II of Macedon defeated Athens and Thebes at Chaeronea in 338 BCE and brought Greece under Macedonian control."]],
  ["Legacy",[
    "Classical Greece gave the world democracy and the vocabulary of politics, philosophy from Socrates to Aristotle, history as critical inquiry, theater, the Olympic Games, mathematics such as Euclid's geometry and Pythagoras' theorem, early science and medicine (Hippocrates, the “father of medicine”), and architectural orders still used on courthouses and capitols.",
    "Greek ideals were revived in the Renaissance and inspired the founders of the United States, who studied Greek history closely, though they generally preferred a republic to direct democracy, partly because of Athens' instability. Modern scholars also study the limits of Greek society, including slavery, the exclusion of women, and Athenian imperialism."]]
  ],
  terms:[["Polis","A Greek city-state."],["Helots","The enslaved population that farmed Sparta's land."],["Athenian democracy","Direct rule by male citizens, established by Cleisthenes' reforms around 508 BCE."],["Thermopylae","The pass where 300 Spartans and allies resisted the Persians in 480 BCE."],["Delian League","The alliance Athens led and turned into an empire."],["Peloponnesian War","The war between Athens and Sparta, 431–404 BCE."]],
  w:"Greece created democracy, philosophy, history, and drama, and its wars and politics remain a source of lessons about power and freedom.",
  src:["Ancient Greece","Polis","Athenian democracy","Greco-Persian Wars","Peloponnesian War","Pericles"],
  q:[["Who created Athens' democratic system around 508 BCE?","Cleisthenes","Solon","Pericles","Themistocles"],
     ["What were the helots?","The enslaved population of Sparta","Athenian officials","Persian soldiers","Greek colonists"],
     ["Which battle in 490 BCE inspired the modern marathon race?","Marathon","Salamis","Thermopylae","Plataea"],
     ["Which naval battle in 480 BCE was a decisive Greek victory?","Salamis","Marathon","Chaeronea","Plataea"],
     ["Who wrote the history of the Peloponnesian War?","Thucydides","Herodotus","Xenophon","Plutarch"],
     ["Which Macedonian king defeated Athens and Thebes at Chaeronea?","Philip II","Alexander the Great","Xerxes","Darius I"]]},

{ t:"Alexander and the Hellenistic World", s:"Conquest and the spread of Greek culture",
  sec:[
  ["Alexander's conquests",[
    "Alexander III of Macedon (356–323 BCE), son of Philip II and a student of Aristotle, became king at twenty after his father's assassination in 336 BCE. In 334 BCE he invaded the Persian Empire. In a series of victories, at the Granicus River, at Issus (333 BCE), and at Gaugamela (331 BCE), he defeated the Persian king Darius III and conquered the entire Achaemenid Empire, including Egypt, where he founded the city of Alexandria.",
    "Alexander pushed on into Central Asia and in 326 BCE crossed into the Indus Valley, defeating the Indian king Porus at the Hydaspes River. His exhausted soldiers refused to go farther, and he turned back. He died in Babylon in 323 BCE at 32, possibly of illness. In about a decade, he had created an empire stretching from Greece to India, earning the title “the Great.”"]],
  ["Alexander's legacy and the successor kingdoms",[
    "Alexander encouraged the blending of Greek and Persian cultures, adopting Persian dress and court customs and arranging marriages between his officers and Persian noblewomen, which angered some Macedonians. He founded many cities, several named Alexandria, which became centers of Greek culture.",
    "After his death, his generals, the Diadochi or “successors,” fought over his empire, which split into several kingdoms. The Ptolemies ruled Egypt from Alexandria; the Seleucids ruled much of the former Persian Empire from Syria and Mesopotamia; and the Antigonids ruled Macedonia. These Hellenistic kingdoms lasted until Rome conquered them, the last being Ptolemaic Egypt in 30 BCE."]],
  ["Hellenistic culture",[
    "The Hellenistic period (323–31 BCE) spread Greek language and culture across the Near East, creating a cosmopolitan world. A simplified form of Greek called koine became the common language of trade and learning from Egypt to Afghanistan; the New Testament was later written in it. Greek-style cities with theaters, gymnasiums, and temples appeared far from Greece, and Greek and local traditions mixed. In Gandhara, in present-day Pakistan and Afghanistan, Greek artistic styles influenced the first human images of the Buddha.",
    "Alexandria became the intellectual capital of the world. Its Library, founded under the Ptolemies, aimed to collect all known books and may have held hundreds of thousands of scrolls. Its gradual decline and destruction over centuries, rather than a single fire, became a symbol of lost knowledge. The Pharos lighthouse of Alexandria was one of the Seven Wonders of the Ancient World."]],
  ["Science and philosophy",[
    "Hellenistic scholars made remarkable advances. Euclid's Elements (c. 300 BCE) organized geometry into a system of axioms and proofs that was used as a textbook for over two thousand years. Archimedes of Syracuse calculated an approximation of pi, discovered principles of levers and buoyancy, and designed war machines; according to legend, he shouted “Eureka!” on discovering how to measure volume by displacement.",
    "Eratosthenes estimated Earth's circumference with impressive accuracy by measuring shadows in two Egyptian cities. Aristarchus proposed that Earth orbits the sun, an idea that did not prevail until Copernicus. Physicians such as Herophilus studied anatomy through dissection. Philosophically, this was the age of the Stoics, Epicureans, Cynics, and Skeptics, schools covered in the Philosophy course."]],
  ["Why the Hellenistic age matters",[
    "The Hellenistic world was the bridge between classical Greece and Rome. When Rome conquered the eastern Mediterranean, it absorbed Hellenistic culture; as the Roman poet Horace wrote, “Captive Greece took captive her savage conqueror.” Through Rome, and later through Byzantium and the Islamic world, Greek learning survived to shape medieval and modern civilization.",
    "The period also set the stage for the spread of Christianity, which grew in a world of Greek-speaking cities connected by trade and a shared language. Judaism encountered Hellenism in this era, too; the Maccabean revolt against the Seleucid king Antiochus IV in the 160s BCE, remembered in the festival of Hanukkah, was partly a struggle over Greek cultural and religious influence."]]
  ],
  terms:[["Alexander the Great","Macedonian king who conquered the Persian Empire."],["Diadochi","Alexander's successors who divided his empire."],["Hellenistic period","The era from 323 to 31 BCE when Greek culture spread across the Near East."],["Koine","The common form of Greek used across the Hellenistic world."],["Library of Alexandria","The great library of the Ptolemaic capital."],["Euclid's Elements","The foundational geometry textbook of the ancient world."]],
  w:"Alexander's conquests spread Greek culture across three continents and created the cosmopolitan world in which Rome and Christianity grew.",
  src:["Alexander the Great","Hellenistic period","Diadochi","Library of Alexandria","Euclid's Elements","Archimedes"],
  q:[["Who was Alexander the Great's teacher?","Aristotle","Plato","Socrates","Diogenes"],
     ["At which battle in 331 BCE did Alexander decisively defeat Darius III?","Gaugamela","Issus","Granicus","Hydaspes"],
     ["Where did Alexander die?","Babylon","Alexandria","Pella","Persepolis"],
     ["Which dynasty ruled Egypt after Alexander?","The Ptolemies","The Seleucids","The Antigonids","The Achaemenids"],
     ["Who estimated Earth's circumference using shadows?","Eratosthenes","Archimedes","Euclid","Aristarchus"],
     ["What was koine?","The common Greek language of the Hellenistic world","A Persian coin","A Macedonian battle formation","An Egyptian god"]]},

{ t:"The Roman Republic", s:"From city to Mediterranean power",
  sec:[
  ["Origins",[
    "According to legend, Rome was founded in 753 BCE by Romulus, who with his twin Remus was raised by a she-wolf. Archaeology shows small settlements on Rome's hills by the 8th century BCE. Early Rome was ruled by kings, the last of them Etruscan; Romans were deeply influenced by the Etruscans to their north and by Greek colonies to their south.",
    "Around 509 BCE, according to tradition, the Romans expelled their last king, Tarquin the Proud, and established a republic, from res publica, “the public thing.” Romans' hatred of kingship became a lasting political value, so strong that centuries later Julius Caesar's apparent ambition to be king helped provoke his assassination."]],
  ["How the Republic worked",[
    "The Republic balanced power among several institutions. Two consuls, elected annually, led the government and army, each able to veto the other. The Senate, made up of former magistrates, mostly from aristocratic families, advised magistrates and controlled finances and foreign policy. Popular assemblies of citizens elected magistrates and passed laws. In emergencies, a dictator could be appointed for up to six months.",
    "The Greek historian Polybius praised Rome's “mixed constitution,” combining elements of monarchy (consuls), aristocracy (Senate), and democracy (assemblies), an analysis that later influenced the framers of the U.S. Constitution, who also borrowed the term “Senate.” Rome's legal tradition began with the Twelve Tables, written around 450 BCE, which made basic laws public."]],
  ["Patricians and plebeians",[
    "Roman society was divided between patricians, the aristocratic families who originally monopolized offices, and plebeians, the majority of citizens. In the “Conflict of the Orders” (c. 494–287 BCE), plebeians used strikes, including withdrawing from the city, to win rights, including their own officials, the tribunes, who could veto actions harmful to plebeians, and eventually access to all offices. In 287 BCE, decisions of the plebeian assembly became binding on all Romans.",
    "Roman society was also deeply hierarchical, based on patron-client relationships and slavery, which expanded enormously with conquest. The family was headed by the paterfamilias, the oldest male, who had legal authority over his household."]],
  ["Expansion and the Punic Wars",[
    "Rome conquered the Italian peninsula by the 270s BCE, often granting conquered peoples alliances or partial citizenship, which bound them to Rome. It then fought three Punic Wars against Carthage, a wealthy North African trading power. In the Second Punic War (218–201 BCE), the Carthaginian general Hannibal crossed the Alps with an army that included war elephants and crushed Roman forces at Cannae in 216 BCE, one of history's most studied battles. But Rome refused to surrender, and Scipio Africanus finally defeated Hannibal at Zama in 202 BCE.",
    "In the Third Punic War, Rome destroyed Carthage completely in 146 BCE, the same year it destroyed Corinth in Greece. Rome now dominated the Mediterranean, which Romans later called mare nostrum, “our sea.”"]],
  ["Crisis of the Republic",[
    "Conquest brought wealth and problems. Large estates worked by enslaved people displaced small farmers, who crowded into Rome. The brothers Tiberius and Gaius Gracchus, tribunes in 133 and 123–122 BCE, proposed land reforms and were killed by senatorial opponents, introducing political violence into Roman politics. Generals such as Marius recruited landless volunteers loyal to their commanders rather than the state, and Sulla marched his army on Rome and made himself dictator. A massive slave revolt led by Spartacus (73–71 BCE) was brutally crushed.",
    "Julius Caesar, a brilliant general and politician, conquered Gaul (58–50 BCE). Ordered to give up his command, he crossed the Rubicon River with his army in 49 BCE, starting a civil war. Victorious, he was named dictator for life. On the Ides of March, March 15, 44 BCE, senators led by Brutus and Cassius assassinated him. Another civil war followed, in which Caesar's adopted heir Octavian defeated Mark Antony and Cleopatra at Actium in 31 BCE. In 27 BCE the Senate granted Octavian the title Augustus, and the Republic gave way to the Empire."]]
  ],
  terms:[["Republic","Rome's system of elected magistrates, Senate, and assemblies, from c. 509 BCE."],["Consuls","The two annually elected chief magistrates."],["Twelve Tables","Rome's first written laws, c. 450 BCE."],["Patricians and plebeians","Rome's aristocratic families and common citizens."],["Punic Wars","Rome's three wars against Carthage."],["Crossing the Rubicon","Caesar's 49 BCE act that began civil war; now a phrase for an irreversible step."]],
  w:"The Roman Republic's institutions, law, and collapse influenced the American founders and remain a case study in how republics fail.",
  src:["Roman Republic","Constitution of the Roman Republic","Twelve Tables","Conflict of the Orders","Punic Wars","Crisis of the Roman Republic"],
  q:[["According to tradition, when was the Roman Republic established?","509 BCE","753 BCE","27 BCE","264 BCE"],
     ["How many consuls were elected each year?","Two","One","Three","Ten"],
     ["Which Greek historian praised Rome's mixed constitution?","Polybius","Herodotus","Thucydides","Plutarch"],
     ["Which Carthaginian general crossed the Alps with elephants?","Hannibal","Hamilcar","Hasdrubal","Scipio"],
     ["In what year was Carthage destroyed?","146 BCE","202 BCE","216 BCE","44 BCE"],
     ["What did Caesar cross in 49 BCE to begin civil war?","The Rubicon","The Tiber","The Rhine","The Alps"]]},

{ t:"The Roman Empire", s:"Pax Romana, Christianity, and the fall of the West",
  sec:[
  ["Augustus and the Principate",[
    "Augustus (ruled 27 BCE–14 CE) kept the forms of the Republic, the Senate, consuls, and elections, while holding real power as princeps, “first citizen.” He reformed the army, provinces, and finances and launched a building program, boasting that he found Rome a city of brick and left it a city of marble. His reign began the Pax Romana, about two centuries of relative peace and prosperity across the empire.",
    "His successors ranged from capable to notorious. The Julio-Claudian dynasty included Caligula and Nero, who was blamed for persecuting Christians after the Great Fire of Rome in 64 CE. The “Five Good Emperors,” from Nerva to Marcus Aurelius (96–180 CE), oversaw the empire's height. Under Trajan, it reached its greatest extent, from Britain to Mesopotamia."]],
  ["Life in the empire",[
    "At its height the empire held perhaps 50 to 70 million people around the Mediterranean, connected by more than 80,000 kilometers of paved roads, sea routes, a common currency, and Roman law. Engineers built aqueducts, bridges, amphitheaters such as the Colosseum (completed 80 CE), and concrete domes such as the Pantheon. Latin spread in the west and Greek remained dominant in the east.",
    "Rome extended citizenship gradually; in 212 CE, the emperor Caracalla granted citizenship to nearly all free inhabitants. Roman law, developed by jurists over centuries, distinguished legal persons and things, contracts and wrongs, and became the basis of civil law systems. Society remained deeply unequal and dependent on slavery, and public entertainments included gladiator fights. Pompeii, buried by the eruption of Mount Vesuvius in 79 CE, preserves a vivid snapshot of everyday Roman life."]],
  ["The rise of Christianity",[
    "Christianity began in the 1st century CE among Jewish followers of Jesus of Nazareth, crucified in Judaea under the Roman governor Pontius Pilate around 30–33 CE. His followers proclaimed his resurrection, and missionaries, especially Paul of Tarsus, spread the faith to non-Jews across the Greek-speaking cities of the empire.",
    "Christians faced intermittent persecution, most severely under Emperor Diocletian beginning in 303 CE. The emperor Constantine, after attributing a victory at the Milvian Bridge in 312 to the Christian God, legalized Christianity with the Edict of Milan in 313 and convened the Council of Nicaea in 325 to settle doctrinal disputes. In 380, Theodosius I made Nicene Christianity the official religion of the empire. Christianity's spread transformed Roman culture and ensured that the church would preserve much of Roman learning after the western empire fell."]],
  ["Crisis and reform",[
    "In the 3rd century CE, the empire faced civil wars, rapid turnover of emperors (around two dozen in fifty years), invasions, plague, and inflation. Diocletian (ruled 284–305) restored order by dividing the empire into eastern and western halves with multiple rulers, enlarging the army and bureaucracy, and attempting price controls.",
    "Constantine reunited the empire and in 330 founded a new capital, Constantinople, on the site of Byzantium, at the crossroads of Europe and Asia. After 395, the empire was permanently divided into a western half ruled from Rome, Milan, or Ravenna, and an eastern half ruled from Constantinople. The east was wealthier, more urban, and better defended."]],
  ["The fall of the West",[
    "In the late 4th and 5th centuries, Germanic peoples, many pushed westward by the Huns, entered the empire, sometimes as allies and sometimes as invaders. The Visigoths defeated a Roman army at Adrianople in 378 and sacked Rome in 410. The Vandals took North Africa and sacked Rome in 455. Germanic kingdoms formed in Gaul, Spain, Italy, and Africa. In 476, the Germanic commander Odoacer deposed the last western emperor, Romulus Augustulus, the conventional date for the fall of the Western Roman Empire.",
    "Historians have proposed hundreds of explanations for the fall, including political instability, economic weakness, overextension, military pressure, plague, climate change, and divisions within the elite. Edward Gibbon's The History of the Decline and Fall of the Roman Empire (1776–1789) blamed in part Christianity and the loss of civic virtue. Many modern historians prefer to speak of “transformation,” since Roman law, language, and the church continued, while others emphasize the real economic collapse and violence. The Eastern Roman Empire, known as the Byzantine Empire, survived for nearly another thousand years, until 1453."]]
  ],
  terms:[["Augustus","The first Roman emperor, ruling 27 BCE–14 CE."],["Pax Romana","About two centuries of relative peace within the Roman Empire."],["Edict of Milan","Constantine's 313 CE legalization of Christianity."],["Constantinople","The eastern capital founded by Constantine in 330 CE."],["Fall of the Western Roman Empire","Conventionally dated to 476 CE, when Odoacer deposed Romulus Augustulus."],["Roman law","The legal system that became the basis of European civil law."]],
  w:"Rome shaped the languages, laws, religions, and political vocabulary of the Western world, and its decline remains history's most debated case of collapse.",
  src:["Roman Empire","Augustus","Pax Romana","Constantine the Great","Fall of the Western Roman Empire","The History of the Decline and Fall of the Roman Empire"],
  q:[["What title did Augustus use to present himself as “first citizen”?","Princeps","Rex","Dictator","Consul"],
     ["Under which emperor did the empire reach its greatest extent?","Trajan","Augustus","Hadrian","Constantine"],
     ["Which city was buried by Vesuvius in 79 CE?","Pompeii","Ostia","Carthage","Ravenna"],
     ["Which edict legalized Christianity in 313 CE?","The Edict of Milan","The Edict of Nantes","The Edict of Thessalonica","The Edict of Diocletian"],
     ["Who deposed the last western emperor in 476 CE?","Odoacer","Alaric","Attila","Theodoric"],
     ["Who wrote The History of the Decline and Fall of the Roman Empire?","Edward Gibbon","Thomas Macaulay","Theodor Mommsen","Polybius"]]},

{ t:"Ancient Africa and the Americas", s:"Kush, Aksum, the Olmec, the Maya, and the Andes",
  sec:[
  ["Kush and Nubia",[
    "South of Egypt, along the Nile in present-day Sudan, lay Nubia, home to the kingdom of Kush. Kush was deeply connected to Egypt through trade in gold, ivory, and ebony, and was at times conquered by it. In the 8th century BCE, Kushite kings conquered Egypt and ruled as its 25th Dynasty, the “Black Pharaohs,” for nearly a century before being driven out by the Assyrians.",
    "Kush later flourished with its capital at Meroë, a major center of iron production. Its rulers built pyramids, more numerous than Egypt's, and developed their own Meroitic script, which can be read phonetically but not yet fully understood. Kush included powerful queens, known as Kandakes, one of whom resisted Roman armies in the 1st century BCE."]],
  ["Aksum and early West Africa",[
    "In the highlands of present-day Ethiopia and Eritrea, the kingdom of Aksum rose to prominence in the first centuries CE. It controlled trade between the Roman world, Arabia, and India through the Red Sea port of Adulis, minted its own coins, and erected giant carved stone obelisks. Around 330 CE, King Ezana converted to Christianity, making Aksum one of the earliest Christian states. The Persian prophet Mani reportedly listed Aksum among the four great powers of the world, with Rome, Persia, and China.",
    "In West Africa, the Nok culture of present-day Nigeria (c. 1500 BCE–1 CE) produced remarkable terracotta sculptures and early iron smelting. Over many centuries, Bantu-speaking peoples migrated from West-Central Africa across much of central, eastern, and southern Africa, spreading farming, iron working, and related languages, one of the largest migrations in human history. Trans-Saharan trade, greatly expanded after camels were introduced, later supported great West African empires covered in the next unit."]],
  ["The Olmec",[
    "In the Americas, civilizations developed independently of Afro-Eurasia. The Olmec, on the Gulf Coast of present-day Mexico (c. 1200–400 BCE), are often called the “mother culture” of Mesoamerica. They are famous for colossal stone heads, some about three meters tall, likely portraits of rulers. They built ceremonial centers such as San Lorenzo and La Venta and may have originated features shared by later Mesoamerican cultures, including the ritual ballgame, a calendar system, and possibly early writing.",
    "Mesoamerica, the cultural region of southern Mexico and Central America, shared maize agriculture, pyramid temples, complex calendars, and religious practices that included bloodletting and human sacrifice."]],
  ["The Maya",[
    "The Maya civilization of southern Mexico, Guatemala, and Belize flourished for centuries, reaching its Classic period peak between about 250 and 900 CE. The Maya built dozens of city-states, such as Tikal, Palenque, and Copán, with towering stone pyramids, palaces, and ball courts, ruled by kings who claimed divine connections. Recent laser-scanning (lidar) surveys have revealed far larger and denser settlements than previously known.",
    "The Maya developed the most complete writing system in the pre-Columbian Americas, combining logograms and syllables, which scholars largely deciphered in the late 20th century. They used a mathematics that included the concept of zero and created precise calendars, including the Long Count. Many Classic Maya cities in the southern lowlands were abandoned in the 9th and 10th centuries, a collapse attributed to drought, warfare, and environmental strain, though Maya cities continued in the north, and millions of Maya people live in the region today."]],
  ["Teotihuacan and the Andes",[
    "Teotihuacan, near present-day Mexico City, was one of the largest cities in the world around 500 CE, with perhaps 100,000 or more inhabitants. Its Avenue of the Dead is lined by the massive Pyramids of the Sun and Moon. Its influence reached Maya cities hundreds of kilometers away. The city declined around 550 CE; centuries later, the Aztecs revered its ruins and gave it its name, meaning “place where the gods were created.”",
    "In the Andes of South America, civilizations developed in one of the world's most challenging environments, from coastal deserts to high mountains. Caral in Peru, dating to around 2600 BCE, is among the oldest cities in the Americas. The Chavín culture spread a shared religious style, the Moche created fine ceramics and irrigation works, and the Nazca made enormous lines and figures in the desert visible from the air. These cultures laid foundations for the later Inca Empire. Their histories show that complex civilizations arose independently on several continents."]]
  ],
  terms:[["Kush","A Nubian kingdom that ruled Egypt as its 25th Dynasty."],["Meroë","The later Kushite capital, a center of iron production."],["Aksum","An Ethiopian trading kingdom that adopted Christianity around 330 CE."],["Bantu migrations","The spread of Bantu-speaking peoples across much of sub-Saharan Africa."],["Olmec","The early “mother culture” of Mesoamerica."],["Maya","A Mesoamerican civilization with the Americas' most complete writing system."]],
  w:"Africa and the Americas developed powerful civilizations on their own terms, correcting the myth that history happened only around the Mediterranean.",
  src:["Kingdom of Kush","Kingdom of Aksum","Bantu expansion","Olmecs","Maya civilization","Teotihuacan"],
  q:[["Which Nubian kingdom ruled Egypt as its 25th Dynasty?","Kush","Aksum","Ghana","Mali"],
     ["Around when did Aksum's King Ezana convert to Christianity?","330 CE","30 CE","800 CE","1000 CE"],
     ["Which culture is known for colossal stone heads?","The Olmec","The Maya","The Moche","The Nok"],
     ["Which civilization had the most complete writing system in the pre-Columbian Americas?","The Maya","The Olmec","The Inca","The Nazca"],
     ["Which city near Mexico City had perhaps 100,000 people around 500 CE?","Teotihuacan","Tikal","Tenochtitlan","Caral"],
     ["Which Peruvian site is among the oldest cities in the Americas?","Caral","Cusco","Machu Picchu","Chan Chan"]]}
);


/* ---- from hist-04.js ---- */
/* HISTORY FOUNDATIONS, part 4: Unit 3 (The Medieval World), chapters 1-6 */
COURSES.history.units.push({ t:"The Medieval World", ch:[

{ t:"The Byzantine Empire", s:"Rome's eastern half, 330–1453",
  sec:[
  ["New Rome",[
    "The Eastern Roman Empire, called the Byzantine Empire by later historians after the old name of its capital, survived for nearly a thousand years after the western empire fell. Its people called themselves Romans (Rhomaioi), and its capital, Constantinople, founded by Constantine in 330, was the largest and wealthiest city in Christian Europe for most of the Middle Ages. Protected by water on three sides and massive land walls built under Theodosius II in the 5th century, it withstood siege after siege.",
    "Byzantium was Greek-speaking, Orthodox Christian, and Roman in law and government. It served as a buffer between Europe and powers to the east and preserved much of classical Greek literature and learning that might otherwise have been lost."]],
  ["Justinian and Theodora",[
    "Emperor Justinian I (reigned 527–565) tried to restore the Roman Empire. His generals, especially Belisarius, reconquered North Africa, Italy, and part of Spain, though at enormous cost. He ordered the compilation of Roman law into the Corpus Juris Civilis, which later became the foundation of European civil law. He also built the Hagia Sophia (completed 537), whose vast dome was the largest in the world for centuries.",
    "His wife, Empress Theodora, a former actress, was a powerful partner. During the Nika riots of 532, when rioters nearly overthrew Justinian, she reportedly persuaded him not to flee, declaring that “royalty is a good burial shroud.” The revolt was crushed. Justinian's reign was also struck by the first recorded outbreak of bubonic plague in Europe, the Plague of Justinian (from 541), which killed vast numbers across the Mediterranean."]],
  ["Church and culture",[
    "In Byzantium, the emperor was seen as God's representative on earth and played a major role in church affairs. Religious disputes were also political. The Iconoclast controversy (726–843) divided the empire over whether religious images (icons) were holy or idolatrous; icons were ultimately restored, and they remain central to Orthodox worship.",
    "Tensions between the Greek-speaking eastern church and the Latin-speaking western church, over doctrine, language, and the authority of the pope, culminated in the Great Schism of 1054, when papal legates and the patriarch of Constantinople excommunicated each other. The split between Roman Catholic and Eastern Orthodox Christianity has never been fully healed. Byzantine missionaries Cyril and Methodius brought Christianity to the Slavs in the 9th century, and the Cyrillic alphabet, named after Cyril, developed from their work."]],
  ["Pressures and survival",[
    "Byzantium faced constant threats. In the 7th century, the newly Muslim Arab armies conquered its richest provinces, Syria, Palestine, and Egypt, and besieged Constantinople, which survived partly thanks to “Greek fire,” an incendiary weapon whose formula remains unknown. In 1071, the Seljuk Turks defeated a Byzantine army at Manzikert and overran much of Anatolia, prompting the emperor to seek Western help, which contributed to the Crusades.",
    "In 1204, the Fourth Crusade, diverted by Venetian interests and political intrigue, sacked Constantinople itself, looting churches and establishing a short-lived Latin empire. The Byzantines recovered their capital in 1261, but the empire never regained its strength."]],
  ["The fall of Constantinople",[
    "The Ottoman Turks steadily conquered Byzantine territory in Anatolia and the Balkans. In 1453, Sultan Mehmed II besieged Constantinople with a huge army and massive cannon. On May 29, 1453, the city fell; the last emperor, Constantine XI, died in the fighting. The Hagia Sophia became a mosque, and Constantinople, later called Istanbul, became the Ottoman capital.",
    "The fall of Constantinople is often used to mark the end of the Middle Ages. Greek scholars who fled to Italy brought manuscripts and knowledge that contributed to the Renaissance. Russia's rulers later claimed to be heirs of Byzantium, calling Moscow the “Third Rome” and adopting the title tsar, from “Caesar.”"]]
  ],
  terms:[["Byzantine Empire","The Eastern Roman Empire, centered on Constantinople."],["Corpus Juris Civilis","Justinian's compilation of Roman law."],["Hagia Sophia","Justinian's great domed church in Constantinople, completed 537."],["Iconoclasm","The 8th–9th-century controversy over religious images."],["Great Schism (1054)","The split between Eastern Orthodox and Roman Catholic churches."],["Fall of Constantinople","The Ottoman conquest of the city in 1453."]],
  w:"Byzantium preserved Roman law and Greek learning, shaped Eastern Orthodox Christianity and Russia, and linked ancient and modern Europe.",
  src:["Byzantine Empire","Justinian I","Hagia Sophia","East–West Schism","Fall of Constantinople","Cyrillic script"],
  q:[["Which emperor ordered the compilation of the Corpus Juris Civilis?","Justinian I","Constantine","Theodosius II","Basil II"],
     ["When was the Hagia Sophia completed?","537","330","1054","1453"],
     ["What divided the eastern and western churches in 1054?","The Great Schism","The Iconoclast controversy","The Reformation","The Council of Nicaea"],
     ["Which crusade sacked Constantinople in 1204?","The Fourth Crusade","The First Crusade","The Third Crusade","The Children's Crusade"],
     ["Which sultan conquered Constantinople in 1453?","Mehmed II","Suleiman the Magnificent","Osman I","Bayezid I"],
     ["Which alphabet developed from the work of missionaries Cyril and Methodius?","Cyrillic","Latin","Greek","Glagolitic only"]]},

{ t:"The Rise of Islam", s:"Muhammad and the first Islamic empire",
  sec:[
  ["Arabia before Islam",[
    "In the early 7th century, the Arabian Peninsula was home to nomadic Bedouin tribes and trading towns such as Mecca and Medina (then called Yathrib). Mecca was a commercial center and pilgrimage site because of the Kaaba, a cube-shaped shrine then housing images of many gods. Tribal loyalty governed society, and feuds were common. Arabia lay between two exhausted empires, Byzantium and Sasanian Persia, which had fought a long war."]],
  ["Muhammad",[
    "Muhammad was born in Mecca around 570 CE and became a respected merchant. Around 610, according to Islamic tradition, while meditating in a cave on Mount Hira, he received the first of a series of revelations from God (Allah) through the angel Gabriel. These revelations, recited over about 22 years, were later compiled as the Quran. Muhammad preached strict monotheism, submission to God (the meaning of “Islam”), social justice, and care for the poor, and he saw himself as the last in a line of prophets including Abraham, Moses, and Jesus.",
    "His message threatened Mecca's elite, and his followers were persecuted. In 622, Muhammad and his followers migrated to Medina, an event called the Hijra, which marks year one of the Islamic calendar. In Medina he became a political as well as religious leader. After years of conflict, Mecca surrendered in 630; Muhammad removed the idols from the Kaaba and dedicated it to God alone. By his death in 632, much of Arabia was united under Islam."]],
  ["The beliefs and practices of Islam",[
    "Muslims believe in one God, in angels, in prophets with Muhammad as the final prophet, in revealed scriptures, and in a Day of Judgment. The Five Pillars of Islam are the declaration of faith (shahada), that there is no god but God and Muhammad is his messenger; prayer five times a day facing Mecca (salat); almsgiving (zakat); fasting during the month of Ramadan (sawm); and pilgrimage to Mecca (hajj) at least once for those able.",
    "Besides the Quran, Muslims follow the Sunnah, the example of the Prophet, recorded in hadith, reports of his sayings and actions. Islamic law, the sharia, was developed by scholars from these sources over the following centuries and governs worship, family life, commerce, and ethics."]],
  ["The caliphate and its conquests",[
    "After Muhammad's death, his followers chose Abu Bakr as caliph, “successor,” to lead the community. The first four caliphs, called the Rashidun (“rightly guided”), oversaw extraordinarily rapid expansion. Arab Muslim armies defeated the weakened Byzantine and Sasanian empires, conquering Syria, Palestine (Jerusalem in 638), Egypt, Mesopotamia, and Persia within about two decades.",
    "Conquered peoples were not generally forced to convert. Christians and Jews, as “People of the Book,” and later others were treated as protected minorities (dhimmis), allowed to practice their religions in exchange for paying a special tax (jizya) and accepting certain restrictions. Conversion to Islam spread gradually over centuries."]],
  ["Sunni and Shia",[
    "A dispute over leadership divided the Muslim community. Some held that the caliph should be chosen by the community from among qualified leaders; they became the Sunni, today the large majority of Muslims. Others held that leadership belonged to Muhammad's family through his cousin and son-in-law Ali, the fourth caliph; they became the Shia (from Shiat Ali, “party of Ali”).",
    "Ali was assassinated in 661, and the Umayyad dynasty seized the caliphate. In 680, Ali's son Husayn and his small band were killed by Umayyad forces at Karbala in Iraq, an event Shia Muslims commemorate each year on Ashura. The Sunni-Shia division remains significant in the politics of the Middle East today, especially between Shia-majority Iran and Sunni-majority states."]],
  ["The Umayyads",[
    "The Umayyad Caliphate (661–750), ruling from Damascus, expanded the empire to its greatest extent, from Spain and Morocco to Central Asia and the borders of India. Muslim forces crossed into Spain in 711 and advanced into France until they were defeated by the Frankish leader Charles Martel at the Battle of Tours (or Poitiers) in 732.",
    "The Umayyads made Arabic the language of administration, minted distinctive coins, and built the Dome of the Rock in Jerusalem (completed 691/692) and the Great Mosque of Damascus. Discontent among non-Arab Muslims and others fueled a revolution that brought the Abbasid dynasty to power in 750. An Umayyad prince escaped to Spain and founded an independent emirate at Córdoba."]]
  ],
  terms:[["Islam","Submission to God; the religion taught by Muhammad."],["Hijra","Muhammad's migration from Mecca to Medina in 622, year one of the Islamic calendar."],["Quran","The holy book of Islam."],["Five Pillars","The core practices of Islam: faith, prayer, almsgiving, fasting, pilgrimage."],["Caliph","Successor to Muhammad as leader of the Muslim community."],["Sunni and Shia","The two main branches of Islam, divided originally over succession."]],
  w:"Islam's rise created a civilization stretching from Spain to India and a faith now practiced by roughly a quarter of humanity.",
  src:["Muhammad","Islam","Hijrah","Five Pillars of Islam","Rashidun Caliphate","Shia–Sunni relations"],
  q:[["What event in 622 marks year one of the Islamic calendar?","The Hijra","Muhammad's birth","The first revelation","The conquest of Mecca"],
     ["What does “Islam” mean?","Submission to God","Peace","Prophet","Holy war"],
     ["Which is NOT one of the Five Pillars?","Jihad","Fasting in Ramadan","Pilgrimage to Mecca","Almsgiving"],
     ["Shia Muslims hold that leadership belonged to the family of whom?","Ali","Abu Bakr","Umar","Muawiya"],
     ["Which battle in 732 halted Muslim advance into France?","Tours (Poitiers)","Karbala","Yarmouk","Manzikert"],
     ["From which city did the Umayyad caliphs rule?","Damascus","Baghdad","Mecca","Cairo"]]},

{ t:"The Islamic Golden Age", s:"The Abbasids, al-Andalus, and a world of learning",
  sec:[
  ["The Abbasid Caliphate",[
    "The Abbasids, who took power in 750, moved the capital east and in 762 founded Baghdad, a planned round city on the Tigris that quickly became one of the world's largest and most cosmopolitan cities. The Abbasid court drew on Persian traditions of government, and non-Arab converts gained a greater role.",
    "Under caliphs such as Harun al-Rashid (reigned 786–809), whose court is idealized in the tales of The Thousand and One Nights, and his son al-Mamun, Baghdad became a center of trade, scholarship, and culture. Over time, Abbasid political power fragmented as regional dynasties gained independence, and real power passed to military commanders, though the caliphs remained symbolic leaders until the Mongols destroyed Baghdad in 1258."]],
  ["Learning and translation",[
    "From the 8th to the 13th centuries, scholars in the Islamic world made major contributions to science, mathematics, medicine, and philosophy, a period often called the Islamic Golden Age. Supported by patrons and institutions such as the House of Wisdom in Baghdad, translators rendered Greek, Persian, Syriac, and Indian works into Arabic. The introduction of papermaking, learned from China, made books far cheaper.",
    "Muhammad ibn Musa al-Khwarizmi (c. 780–850) wrote a treatise whose title gave us the word “algebra” (al-jabr), and his name gave us “algorithm.” He popularized the Hindu-Arabic numerals with zero. Ibn al-Haytham (c. 965–1040) pioneered experimental optics, explaining that vision occurs when light enters the eye. Al-Biruni estimated Earth's radius and wrote a detailed study of India. Avicenna's Canon of Medicine and the works of al-Razi shaped medicine for centuries. Astronomers built observatories and improved the astrolabe."]],
  ["Trade and cities",[
    "The Islamic world sat at the center of Afro-Eurasian trade networks, linking the Mediterranean, the Indian Ocean, the Silk Roads, and trans-Saharan routes. Merchants used checks (the word comes from the Arabic sakk), letters of credit, and partnerships. Crops such as sugar cane, rice, citrus fruits, and cotton spread westward through the Muslim world.",
    "Cities such as Baghdad, Cairo, Damascus, Córdoba, and Samarkand had hospitals, libraries, markets, and schools. Religious scholars, the ulama, developed Islamic law through several schools of jurisprudence, and institutions such as madrasas (colleges) spread from the 11th century. The University of al-Qarawiyyin in Fez, Morocco, founded in 859 by Fatima al-Fihri, is often cited as the oldest continuously operating educational institution."]],
  ["Al-Andalus",[
    "Muslim-ruled Spain, called al-Andalus, flourished under the Umayyad emirs and then caliphs of Córdoba. By the 10th century Córdoba was among Europe's largest and most sophisticated cities, with paved, lit streets and a famous Great Mosque. Muslims, Christians, and Jews lived side by side; the relative tolerance and cultural exchange is often called convivencia, though historians note that it coexisted with inequality and periods of conflict.",
    "Al-Andalus produced the philosopher Averroes, the Jewish philosopher Maimonides, poets, and scholars whose works later passed into Latin Europe, especially through translation centers such as Toledo after it was captured by Christians in 1085. After the caliphate fragmented in the 11th century, Christian kingdoms advanced in the Reconquista. The last Muslim kingdom, Granada, home of the Alhambra palace, fell to Ferdinand and Isabella in 1492."]],
  ["Fragmentation and the Mongol shock",[
    "By the 10th century, the Islamic world was politically divided among rival dynasties: the Shia Fatimids, who founded Cairo in 969; the Umayyads of Spain; and others. In the 11th century, the Seljuk Turks, recent converts from Central Asia, took control of Baghdad and much of the Middle East, defeating the Byzantines at Manzikert in 1071.",
    "In 1258, the Mongols under Hulagu Khan sacked Baghdad, killing the caliph and a vast number of inhabitants; according to legend, the Tigris ran black with ink from books thrown into it. Islamic civilization continued, and new powers, including the Mamluks of Egypt, who defeated the Mongols at Ain Jalut in 1260, and later the Ottomans, Safavids, and Mughals, carried it forward. Historians now debate the idea of a single “decline” after the Golden Age, noting continued achievements in many fields."]]
  ],
  terms:[["Abbasid Caliphate","The dynasty that ruled from Baghdad from 750 to 1258."],["House of Wisdom","A center of translation and scholarship in Baghdad."],["Al-Khwarizmi","Mathematician whose work gave us “algebra” and “algorithm.”"],["Al-Andalus","Muslim-ruled Iberia."],["Reconquista","The Christian reconquest of the Iberian Peninsula, completed in 1492."],["Sack of Baghdad (1258)","The Mongol destruction of the Abbasid capital."]],
  w:"The Islamic Golden Age preserved and expanded ancient knowledge and passed it to Europe, shaping mathematics, medicine, and science everywhere.",
  src:["Abbasid Caliphate","Islamic Golden Age","Muhammad ibn Musa al-Khwarizmi","Al-Andalus","Reconquista","Siege of Baghdad (1258)"],
  q:[["Which dynasty founded Baghdad in 762?","The Abbasids","The Umayyads","The Fatimids","The Seljuks"],
     ["Whose name gave us the word “algorithm”?","Al-Khwarizmi","Ibn al-Haytham","Al-Biruni","Avicenna"],
     ["Who pioneered experimental optics?","Ibn al-Haytham","Al-Razi","Averroes","Harun al-Rashid"],
     ["Who founded the University of al-Qarawiyyin in 859?","Fatima al-Fihri","Harun al-Rashid","Saladin","Al-Mamun"],
     ["When did Granada, the last Muslim kingdom in Spain, fall?","1492","1085","1258","711"],
     ["Who sacked Baghdad in 1258?","The Mongols under Hulagu","The Crusaders","The Seljuks","The Ottomans"]]},

{ t:"Early Medieval Europe", s:"Franks, Vikings, and the feudal order",
  sec:[
  ["After Rome",[
    "After the western Roman Empire fell, Western Europe was divided among Germanic kingdoms: Visigoths in Spain, Ostrogoths and later Lombards in Italy, Anglo-Saxons in Britain, and Franks in Gaul. Cities shrank, trade declined, and literacy became rare outside the church. These centuries were once called the “Dark Ages,” a term historians now avoid because the period saw real creativity, the blending of Roman, Christian, and Germanic traditions, and the formation of European kingdoms.",
    "The Christian church provided continuity. Bishops often led cities, and monasteries, following the Rule of Saint Benedict (c. 530), became centers of prayer, farming, and learning, where monks copied manuscripts and preserved classical texts. Irish monks, in particular, kept learning alive and sent missionaries across Europe."]],
  ["The Franks and Charlemagne",[
    "The Franks became the most powerful Germanic people. Their king Clovis converted to Catholic Christianity around 496, gaining the support of the church and the Roman population. In 732, Charles Martel defeated a Muslim army at Tours. His son Pepin the Short became king with papal support and gave the pope lands in central Italy, the origin of the Papal States.",
    "Pepin's son Charlemagne (Charles the Great, reigned 768–814) conquered much of Western Europe, including northern Italy and Saxony, and was crowned emperor of the Romans by Pope Leo III on Christmas Day, 800. He sponsored the Carolingian Renaissance, gathering scholars such as Alcuin of York, founding schools, and promoting a clear new script, Carolingian minuscule, the ancestor of our lowercase letters. His empire was divided among his grandsons by the Treaty of Verdun in 843, roughly foreshadowing France and Germany."]],
  ["The Vikings",[
    "From the late 8th century, Scandinavians known as Vikings raided, traded, and settled across Europe. The raid on the monastery of Lindisfarne in England in 793 is often taken as the start of the Viking Age. With their swift longships, Vikings attacked coasts and rivers, settled in England's Danelaw, Ireland (founding Dublin), and Normandy, and traveled east along Russian rivers to Constantinople and Baghdad.",
    "Vikings also settled Iceland, where they founded the Althing, an assembly, in 930, and Greenland. Around 1000, Leif Erikson reached North America; the settlement at L'Anse aux Meadows in Newfoundland, confirmed by archaeologists in the 1960s, is the earliest known European presence in the Americas. The Rus, Scandinavians who ruled over Slavic peoples, helped found the state of Kievan Rus, which converted to Orthodox Christianity in 988."]],
  ["Feudalism and manorialism",[
    "Facing raids by Vikings, Magyars, and others, and lacking strong central governments, Europeans developed a decentralized system of military and political obligations. In feudalism, as historians traditionally describe it, a lord granted land, called a fief, to a vassal in exchange for loyalty and military service, especially as a mounted knight. Kings depended on powerful nobles, who had their own vassals. Historians now debate how uniform or “systematic” feudalism really was, but personal bonds of loyalty and land were central to medieval politics.",
    "Most people were peasants who lived on manors, agricultural estates controlled by lords. Many were serfs, legally bound to the land, owing labor and payments to the lord in exchange for protection and the right to farm plots. Improvements such as the heavy plow, the horse collar, and the three-field system increased food production after about 1000, supporting population growth."]],
  ["England and the Norman Conquest",[
    "In England, Alfred the Great (reigned 871–899) resisted the Vikings and laid foundations for a unified English kingdom. In 1066, William, Duke of Normandy, defeated the English king Harold at the Battle of Hastings and became king, an event depicted in the Bayeux Tapestry.",
    "William imposed Norman rule, built castles, and ordered the Domesday Book (1086), a remarkable survey of land and resources for taxation. The Norman Conquest blended French and English, transforming the English language, and created a strong centralized monarchy in which royal courts later developed the common law, as described in the Law course."]]
  ],
  terms:[["Rule of Saint Benedict","The guide for monastic life written around 530."],["Charlemagne","Frankish king crowned emperor in 800."],["Carolingian Renaissance","Charlemagne's revival of learning."],["Vikings","Scandinavian raiders, traders, and settlers of the 8th–11th centuries."],["Feudalism","A system of land grants in exchange for loyalty and military service."],["Manorialism","The economic system of estates worked by peasants and serfs."]],
  w:"Early medieval Europe blended Roman, Christian, and Germanic traditions into the kingdoms and institutions from which modern Europe grew.",
  src:["Early Middle Ages","Charlemagne","Carolingian Renaissance","Vikings","Feudalism","Norman Conquest"],
  q:[["Who wrote the most influential rule for monasteries around 530?","Saint Benedict","Saint Patrick","Alcuin of York","Gregory the Great"],
     ["When was Charlemagne crowned emperor?","800","768","843","1066"],
     ["Which raid in 793 is often taken as the start of the Viking Age?","Lindisfarne","Paris","Dublin","York"],
     ["Where is the earliest known European site in the Americas?","L'Anse aux Meadows","Plymouth","Jamestown","Greenland"],
     ["What was a fief?","Land granted to a vassal","A peasant's tax","A monastery","A castle"],
     ["Which survey did William the Conqueror order in 1086?","The Domesday Book","Magna Carta","The Bayeux Tapestry","The Anglo-Saxon Chronicle"]]},

{ t:"The Church and the High Middle Ages", s:"Popes, cathedrals, universities, and towns",
  sec:[
  ["Growth after 1000",[
    "Between about 1000 and 1300, Western Europe grew dramatically. Population perhaps doubled, forests were cleared, new towns were founded, and trade revived, connecting Italy, Flanders, and the fairs of Champagne. Merchants and craftsmen formed guilds to regulate their trades. Italian city-states such as Venice and Genoa built commercial empires, and banking families developed new financial techniques.",
    "Towns gained charters granting self-government, and townspeople, the bourgeoisie, formed a new social group between nobles and peasants. Medieval society was often described as composed of three orders: those who pray (clergy), those who fight (nobles), and those who work (peasants), though the growing towns did not fit neatly into this scheme."]],
  ["The power of the papacy",[
    "The Catholic Church was the most powerful institution in medieval Europe, with its own law (canon law), courts, taxes (the tithe), and vast landholdings. A reform movement, centered on the monastery of Cluny, sought to free the church from lay control and corruption. Pope Gregory VII (1073–1085) insisted that only the church could appoint bishops, setting off the Investiture Controversy with the Holy Roman Emperor Henry IV. In 1077, the excommunicated Henry famously stood in the snow at Canossa to seek the pope's forgiveness. The dispute was settled by the Concordat of Worms in 1122.",
    "Papal power peaked under Innocent III (1198–1216), who intervened in the politics of kingdoms across Europe and convened the Fourth Lateran Council in 1215. The church also suppressed dissent; the Inquisition, established in the 13th century to combat heresy, and the crusade against the Cathars in southern France used force against Christians deemed heretics."]],
  ["Monks, friars, and faith",[
    "Religion shaped every part of medieval life, from the calendar of feasts and fasts to the sacraments that marked birth, marriage, and death. New religious orders arose. The Cistercians pursued strict monastic life. In the 13th century, the mendicant friars, the Franciscans, founded by Francis of Assisi, who embraced radical poverty, and the Dominicans, founded by Dominic to preach against heresy, worked among townspeople.",
    "Pilgrimage to sites such as Rome, Jerusalem, and Santiago de Compostela was popular, and the cult of saints and relics was central to piety. Women participated as nuns, mystics such as Hildegard of Bingen (1098–1179), a composer, writer, and scientist, and lay religious women called Beguines."]],
  ["Cathedrals and universities",[
    "The great building achievement of the age was the Gothic cathedral, beginning with the Abbey of Saint-Denis near Paris in the 1140s. Pointed arches, ribbed vaults, and flying buttresses allowed soaring walls filled with stained glass, as at Chartres and Notre-Dame de Paris. Cathedrals took generations to build and served as centers of civic pride.",
    "Universities emerged from cathedral schools and guilds of teachers and students: Bologna, famous for law, in the late 11th century, Paris for theology, and Oxford, followed by Cambridge and others. Students studied the liberal arts, then law, medicine, or theology. Scholastic thinkers such as Thomas Aquinas reconciled Aristotle with Christian theology, and the rediscovery of Roman law at Bologna shaped European legal systems."]],
  ["Kings and early states",[
    "Kings gradually strengthened their power. In England, Henry II (reigned 1154–1189) expanded royal courts and the common law. Conflict with the church led to the murder of Archbishop Thomas Becket in Canterbury Cathedral in 1170. Henry's son King John lost wars in France and clashed with his barons, who forced him to accept Magna Carta in 1215, establishing that the king was subject to the law. In 1295, Edward I summoned what became known as the Model Parliament, including representatives of towns and counties.",
    "In France, kings such as Philip II Augustus and Louis IX (Saint Louis) expanded royal territory and authority. Philip IV clashed with Pope Boniface VIII, whose bull Unam Sanctam (1302) asserted papal supremacy; soon after, the papacy moved to Avignon in France. These developments laid foundations for the nation-states of Europe."]]
  ],
  terms:[["Guild","An association of merchants or craftsmen regulating a trade."],["Investiture Controversy","The conflict over whether popes or kings appointed bishops."],["Mendicant friars","Franciscans and Dominicans, who lived by begging and worked among the people."],["Gothic architecture","The cathedral style of pointed arches, ribbed vaults, and flying buttresses."],["Medieval university","Institutions such as Bologna, Paris, and Oxford."],["Magna Carta","The 1215 charter subjecting the English king to the law."]],
  w:"The High Middle Ages produced universities, cathedrals, representative assemblies, and the rule of law, institutions that still shape Western life.",
  src:["High Middle Ages","Investiture Controversy","Francis of Assisi","Gothic architecture","Medieval university","Magna Carta"],
  q:[["Where did Emperor Henry IV seek Pope Gregory VII's forgiveness in 1077?","Canossa","Worms","Rome","Avignon"],
     ["Which pope's reign marked a peak of papal power?","Innocent III","Gregory VII","Boniface VIII","Leo III"],
     ["Who founded the Franciscan order?","Francis of Assisi","Dominic","Benedict","Bernard of Clairvaux"],
     ["Which university was famous for law and emerged in the late 11th century?","Bologna","Paris","Oxford","Salamanca"],
     ["Which archbishop was murdered in Canterbury Cathedral in 1170?","Thomas Becket","Anselm","Stephen Langton","Thomas More"],
     ["Who summoned the Model Parliament in 1295?","Edward I","Henry II","King John","William the Conqueror"]]},

{ t:"The Crusades and the Late Middle Ages", s:"Holy war, plague, and crisis",
  sec:[
  ["The First Crusade",[
    "In 1095, responding to a Byzantine request for help against the Seljuk Turks, Pope Urban II called on Western Christians at the Council of Clermont to free Jerusalem from Muslim rule, promising spiritual rewards. Tens of thousands responded, motivated by piety, desire for land and wealth, and adventure. Some popular crusading bands massacred Jewish communities in the Rhineland on their way east.",
    "The First Crusade captured Jerusalem in 1099 in a brutal sack and established crusader states in the eastern Mediterranean. Military orders, such as the Knights Templar and Knights Hospitaller, formed to defend them."]],
  ["Later Crusades",[
    "In 1187, the Muslim leader Saladin, sultan of Egypt and Syria, recaptured Jerusalem. The Third Crusade (1189–1192), led by Richard I of England, Philip II of France, and Frederick Barbarossa of the Holy Roman Empire (who drowned on the way), failed to retake the city, though Richard negotiated access for Christian pilgrims. The Fourth Crusade sacked Christian Constantinople in 1204. Later crusades achieved little, and the last crusader stronghold, Acre, fell to the Mamluks in 1291.",
    "The crusading idea was also applied within Europe, against Muslims in Spain, pagans in the Baltic, and heretics in France. Historians debate the Crusades' legacy: they increased trade and contact between Europe and the Middle East, strengthened the papacy and Italian cities, and left a lasting memory of conflict between Christianity and Islam."]],
  ["The Black Death",[
    "In the 14th century, Europe suffered a series of disasters. A cooler climate and the Great Famine of 1315–1317 caused mass starvation. Then in 1347, the plague arrived. Caused by the bacterium Yersinia pestis, carried by fleas on rodents and also spread between people, it had moved along trade routes from Central Asia. It reached Crimea and then Italian ports via Genoese ships and spread across Europe, the Middle East, and North Africa by 1351.",
    "The Black Death killed an estimated 30 to 60 percent of Europe's population and similar shares in parts of the Middle East. Contemporaries blamed sin, bad air, or scapegoats; Jewish communities were falsely accused of poisoning wells and were massacred in many places. Flagellants whipped themselves in public penance."]],
  ["Consequences of the plague",[
    "The plague transformed European society. With so many workers dead, surviving laborers demanded higher wages, and lords and governments tried to freeze wages by law, as in England's Statute of Labourers (1351). Tensions contributed to revolts such as the French Jacquerie (1358) and the English Peasants' Revolt (1381), whose rebels asked, “When Adam delved and Eve span, who was then the gentleman?” Over the following century, serfdom declined in Western Europe.",
    "The crisis also shook confidence in the church, which could not stop the plague, and inspired art obsessed with death, such as the “Dance of Death.” Some historians argue that labor scarcity encouraged technological innovation and higher living standards for survivors."]],
  ["War and schism",[
    "The Hundred Years' War (1337–1453) between England and France began over English claims to the French throne. English longbowmen won stunning victories at Crécy (1346) and Agincourt (1415). The tide turned when Joan of Arc, a peasant girl who said she heard divine voices, inspired French forces to lift the siege of Orléans in 1429. Captured by allies of the English, she was tried for heresy and burned in 1431; she was later declared innocent and made a saint. The war ended with France expelling the English from nearly all its territory, and it strengthened national identity and royal power in both countries.",
    "The church faced its own crisis. From 1309 to 1377, popes resided at Avignon under French influence. Then in the Great Western Schism (1378–1417), two and later three rival popes claimed authority, until the Council of Constance resolved the schism. Critics such as John Wycliffe in England and Jan Hus in Bohemia, who was burned at Constance in 1415, attacked church wealth and corruption, anticipating the Reformation."]]
  ],
  terms:[["Crusades","Religious wars launched by the papacy, especially to capture Jerusalem."],["Saladin","The Muslim sultan who recaptured Jerusalem in 1187."],["Black Death","The plague pandemic of 1347–1351."],["Peasants' Revolt","The English uprising of 1381."],["Hundred Years' War","The 1337–1453 conflict between England and France."],["Great Western Schism","The 1378–1417 period of rival popes."]],
  w:"The Crusades shaped relations between Christianity and Islam, and the crises of the 14th century transformed labor, faith, and power in Europe.",
  src:["Crusades","First Crusade","Saladin","Black Death","Hundred Years' War","Western Schism"],
  q:[["Which pope called the First Crusade in 1095?","Urban II","Innocent III","Gregory VII","Boniface VIII"],
     ["Who recaptured Jerusalem in 1187?","Saladin","Baibars","Mehmed II","Nur ad-Din"],
     ["What caused the Black Death?","The bacterium Yersinia pestis","A virus","Bad air","Contaminated grain"],
     ["Which English uprising occurred in 1381?","The Peasants' Revolt","The Jacquerie","The Wars of the Roses","Cade's Rebellion"],
     ["Who lifted the siege of Orléans in 1429?","Joan of Arc","Charles VII","Henry V","Bertrand du Guesclin"],
     ["Which critic of the church was burned at the Council of Constance in 1415?","Jan Hus","John Wycliffe","Martin Luther","Savonarola"]]}
]});


/* ---- from hist-05.js ---- */
/* HISTORY FOUNDATIONS, part 5: Unit 3 (The Medieval World), chapters 7-12 */
COURSES.history.units[2].ch.push(

{ t:"China's Golden Ages: Sui, Tang, and Song", s:"Reunification, cosmopolitan culture, and early modern economy",
  sec:[
  ["Reunification under the Sui",[
    "After nearly four centuries of division following the Han collapse, the Sui dynasty (581–618) reunified China. In its short reign, it rebuilt the empire's administration and constructed the Grand Canal, linking the Yellow and Yangtze rivers so that grain from the fertile south could feed the north and the capital. Still in use in parts, the Grand Canal is the longest artificial waterway in the world. The Sui's heavy demands for labor and failed wars in Korea provoked revolts that brought it down."]],
  ["The Tang dynasty",[
    "The Tang dynasty (618–907) presided over one of the most brilliant periods in Chinese history. Its capital, Chang'an (modern Xi'an), with perhaps a million residents, was likely the largest city in the world, home to merchants, monks, and envoys from across Asia, including Persians, Arabs, Sogdians, Koreans, and Japanese. Tang China controlled trade routes deep into Central Asia until it was defeated by an Abbasid army at the Battle of Talas in 751.",
    "The Tang expanded the civil service examination system, which selected officials by testing knowledge of Confucian classics. Buddhism flourished, though it was later persecuted in the 840s. The period is regarded as the golden age of Chinese poetry, the era of Li Bai and Du Fu. Wu Zetian, the only woman in Chinese history to rule as emperor in her own name, reigned from 690 to 705. The An Lushan Rebellion (755–763), a devastating revolt by a frontier general, weakened the dynasty, which collapsed in 907."]],
  ["Song China's economic revolution",[
    "The Song dynasty (960–1279) is often called the most advanced society of its time. Agriculture improved with fast-ripening rice from Southeast Asia, supporting a population that grew to perhaps 100 million or more. Commerce expanded, cities such as Kaifeng and Hangzhou grew large, and the Song issued the world's first government-backed paper money.",
    "Song scholars and artisans produced major innovations. Woodblock printing, already used under the Tang (the Diamond Sutra of 868 is the oldest dated printed book), spread widely, and Bi Sheng invented movable type around the 1040s. Gunpowder, first discovered by Chinese alchemists, was used in weapons. The magnetic compass was used for navigation. Iron and steel production reached levels not seen in Europe until the Industrial Revolution."]],
  ["Society and thought",[
    "Under the Song, the examination system became the main path to office, creating a class of scholar-officials, the literati, who combined government service with poetry, calligraphy, and painting. Neo-Confucian philosophers, led by Zhu Xi, gave Confucianism a new metaphysical foundation that dominated Chinese thought for centuries.",
    "Women's lives became more constrained in some respects. The practice of footbinding, in which girls' feet were tightly bound to keep them small, spread among the elite during the Song and later more widely, as a mark of status and beauty. It caused lifelong pain and disability and was not abolished until the 20th century."]],
  ["Military weakness and the Mongols",[
    "Despite its wealth, the Song was militarily weaker than earlier dynasties. In 1127, the Jurchen people from Manchuria captured the northern capital, Kaifeng, forcing the Song to retreat south and rule from Hangzhou as the Southern Song. The Southern Song remained prosperous and developed a strong navy.",
    "In the 13th century, the Mongols conquered northern China and then, after long resistance, the Southern Song by 1279. Kublai Khan established the Yuan dynasty, the first time all of China was ruled by foreign conquerors. The innovations of the Tang and Song, especially printing, gunpowder, and the compass, eventually spread westward, where they helped transform Europe."]]
  ],
  terms:[["Grand Canal","The Sui waterway linking northern and southern China."],["Chang'an","The Tang capital, possibly the world's largest city."],["Civil service examinations","Tests on Confucian classics used to select officials."],["Wu Zetian","The only woman to rule China as emperor in her own name."],["Movable type","Printing with reusable characters, invented by Bi Sheng."],["Paper money","Government-backed currency first issued by the Song."]],
  w:"Tang and Song China were among the world's most advanced societies, and their inventions, printing, gunpowder, and the compass, reshaped world history.",
  src:["Sui dynasty","Tang dynasty","Song dynasty","Grand Canal (China)","Wu Zetian","Four Great Inventions"],
  q:[["Which dynasty built the Grand Canal?","The Sui","The Tang","The Song","The Han"],
     ["What was the Tang capital?","Chang'an","Beijing","Kaifeng","Nanjing"],
     ["Who was the only woman to rule China as emperor in her own name?","Wu Zetian","Empress Dowager Cixi","Empress Lü","Yang Guifei"],
     ["Which rebellion severely weakened the Tang in 755?","The An Lushan Rebellion","The Taiping Rebellion","The Boxer Rebellion","The Yellow Turban Rebellion"],
     ["Which dynasty issued the first government-backed paper money?","The Song","The Tang","The Ming","The Qin"],
     ["Who invented movable type in the 1040s?","Bi Sheng","Cai Lun","Zhang Heng","Shen Kuo"]]},

{ t:"The Mongol Empire", s:"The largest contiguous land empire in history",
  sec:[
  ["Genghis Khan",[
    "The Mongols were nomadic herders of the Central Asian steppe, superb horsemen and archers. Temüjin, born around 1162, survived a harsh youth and united the Mongol and Turkic tribes through alliances, warfare, and promotion based on merit and loyalty rather than family. In 1206, an assembly proclaimed him Genghis Khan, “universal ruler.”",
    "Genghis Khan organized his army into decimal units of tens, hundreds, thousands, and ten thousands, enforced strict discipline, and created a code of laws (the Yassa). He used speed, intelligence, deception, and terror: cities that surrendered were often spared, while those that resisted could be massacred. His campaigns conquered northern China and destroyed the Khwarazmian Empire in Central Asia. He died in 1227."]],
  ["Conquest across Eurasia",[
    "Genghis Khan's sons and grandsons continued expanding. Mongol armies swept into Russia, sacking Kiev in 1240, and defeated Polish and Hungarian forces in 1241 before withdrawing on the death of the Great Khan Ögedei. In the Middle East, Hulagu Khan sacked Baghdad in 1258, ending the Abbasid Caliphate. The Mamluks of Egypt finally stopped the Mongol advance at Ain Jalut in 1260.",
    "At its height, the Mongol Empire stretched from Korea and China to Eastern Europe and the Middle East, covering about 24 million square kilometers, the largest contiguous land empire in history. The conquests killed millions, and some regions, such as parts of Persia and Central Asia, took centuries to recover."]],
  ["The khanates",[
    "After the 1260s, the empire divided into four main khanates. The Yuan dynasty in China was founded by Kublai Khan, who moved the capital to what is now Beijing. The Ilkhanate ruled Persia and its rulers converted to Islam. The Chagatai Khanate ruled Central Asia. The Golden Horde ruled the Russian steppes, collecting tribute from Russian princes for over two centuries, a period Russians call the “Mongol yoke,” which helped the princes of Moscow rise as tribute collectors.",
    "Kublai Khan twice tried to invade Japan, in 1274 and 1281; both fleets were wrecked by storms, which the Japanese called kamikaze, “divine winds.”"]],
  ["The Pax Mongolica",[
    "Once conquests were complete, Mongol rule created a period of relative security along trade routes, sometimes called the Pax Mongolica. Merchants, missionaries, and diplomats traveled across Eurasia. The Mongols used a relay system of horse stations called the yam and issued passports of safe conduct. They were generally tolerant of different religions and employed skilled foreigners in their administrations.",
    "The Venetian merchant Marco Polo claimed to have spent about 17 years in Kublai Khan's service, and his account of his travels, published around 1300, amazed Europeans with descriptions of China's wealth, though some details are disputed. The Moroccan traveler Ibn Battuta journeyed across the Islamic world, India, and China in the 14th century. Goods, technologies such as gunpowder and printing techniques, and ideas moved across Eurasia faster than ever."]],
  ["Disease and decline",[
    "The same connections that carried goods also carried disease. Many historians link the spread of the Black Death in the 1340s to trade routes across the Mongol world. According to one account, Mongol forces besieging the Genoese trading post of Caffa in Crimea in 1346 catapulted plague-infected corpses over the walls, though the plague most likely spread mainly through rodents and fleas along trade routes.",
    "The khanates declined in the 14th century amid plague, succession disputes, and rebellions. In China, the Red Turban rebels drove out the Yuan, and the Ming dynasty was founded in 1368. In Central Asia, the conqueror Timur (Tamerlane) briefly built another vast empire in the late 14th century. The Mongol era permanently reshaped Eurasia's political map and connected its civilizations as never before."]]
  ],
  terms:[["Genghis Khan","The founder of the Mongol Empire, proclaimed in 1206."],["Khanate","A territory ruled by a khan; the Mongol Empire split into four."],["Yuan dynasty","The Mongol dynasty in China founded by Kublai Khan."],["Golden Horde","The khanate that dominated the Russian principalities."],["Pax Mongolica","The period of relatively secure trade across Mongol Eurasia."],["Kamikaze","The “divine winds” that wrecked Mongol fleets sent against Japan."]],
  w:"The Mongols connected Eurasia as never before, spreading goods, ideas, and disease, and reshaping China, Russia, Persia, and Central Asia.",
  src:["Mongol Empire","Genghis Khan","Kublai Khan","Golden Horde","Pax Mongolica","Marco Polo"],
  q:[["In what year was Temüjin proclaimed Genghis Khan?","1206","1162","1227","1279"],
     ["Which army stopped the Mongols at Ain Jalut in 1260?","The Mamluks","The Byzantines","The Crusaders","The Delhi Sultanate"],
     ["Who founded the Yuan dynasty?","Kublai Khan","Genghis Khan","Ögedei","Hulagu"],
     ["What did the Japanese call the storms that wrecked Mongol fleets?","Kamikaze","Tsunami","Bushido","Shogun"],
     ["Which khanate collected tribute from Russian princes?","The Golden Horde","The Ilkhanate","The Chagatai Khanate","The Yuan"],
     ["Which Venetian merchant claimed to serve Kublai Khan?","Marco Polo","Ibn Battuta","Zheng He","Christopher Columbus"]]},

{ t:"Japan, Korea, and Southeast Asia", s:"Distinctive civilizations on China's borders",
  sec:[
  ["Early Japan",[
    "Japan's islands developed distinctive cultures, including the ancient Jōmon culture, known for some of the world's oldest pottery, and the rice-farming Yayoi. By the 6th century, a state centered on the Yamato clan emerged; its rulers became Japan's imperial family, which claims an unbroken line to the present, making it the world's oldest continuing hereditary monarchy. Japan's native religion, Shinto, venerates kami, spirits present in nature, ancestors, and sacred places.",
    "Japan selectively borrowed from China: Buddhism, Confucian ideas, Chinese writing (adapted into Japanese scripts), and models of government. Prince Shōtoku's Seventeen-Article Constitution (604) promoted Confucian and Buddhist values. The capital moved to Heian (Kyoto) in 794."]],
  ["Heian culture and the samurai",[
    "During the Heian period (794–1185), an aristocratic court culture flourished, valuing refined poetry, calligraphy, and aesthetic sensibility. Court women wrote some of the greatest works of Japanese literature, including The Tale of Genji by Murasaki Shikibu, written in the early 11th century and often called the world's first novel, and Sei Shōnagon's The Pillow Book.",
    "Meanwhile, real power shifted to provincial warrior families. After the Genpei War (1180–1185), Minamoto no Yoritomo established a military government, and in 1192 he received the title shogun, “general.” For most of the next seven centuries, shoguns ruled Japan while emperors reigned in ceremonial roles. Samurai, warriors bound by loyalty to their lords, became the ruling class; later writers idealized their code as bushido. Zen Buddhism appealed to the samurai and influenced arts such as the tea ceremony and rock gardens."]],
  ["Warring states and unification",[
    "From 1467, Japan descended into more than a century of civil war, the Sengoku (“Warring States”) period, among regional lords called daimyo. Portuguese traders arrived in 1543, introducing firearms, and Jesuit missionaries such as Francis Xavier converted many Japanese to Christianity.",
    "Three leaders unified Japan: Oda Nobunaga, who used firearms effectively; Toyotomi Hideyoshi, who completed unification and launched failed invasions of Korea in the 1590s; and Tokugawa Ieyasu, who won the Battle of Sekigahara in 1600 and became shogun in 1603. The Tokugawa period is covered in the next unit."]],
  ["Korea",[
    "The Korean peninsula was divided among the Three Kingdoms, Goguryeo, Baekje, and Silla, until Silla unified most of it in 668 with Tang Chinese help. The Goryeo dynasty (918–1392), from which the name “Korea” derives, was known for celadon ceramics and for printing: the Tripitaka Koreana, a complete Buddhist canon carved on more than 80,000 woodblocks, survives today, and Korean printers used metal movable type by the 13th century. The Jikji (1377) is the oldest surviving book printed with metal movable type, decades before Gutenberg.",
    "The Joseon dynasty (1392–1897) adopted Neo-Confucianism as its ideology. King Sejong the Great (reigned 1418–1450) sponsored the creation of Hangul, an elegant phonetic alphabet designed so ordinary people could read and write. Korea repelled Hideyoshi's invasions in the 1590s, aided by Admiral Yi Sun-sin's armored “turtle ships” and Ming Chinese armies."]],
  ["Southeast Asia",[
    "Southeast Asia, at the crossroads of Indian Ocean and South China Sea trade, absorbed influences from both India and China while developing its own civilizations. The Khmer Empire (c. 802–1431), based in present-day Cambodia, built Angkor, a vast city with sophisticated water management. Angkor Wat, built in the 12th century as a Hindu temple and later Buddhist, is the largest religious monument in the world.",
    "Srivijaya, based on Sumatra, controlled the Strait of Malacca and was a center of Buddhist learning from the 7th to 13th centuries. Java's Borobudur (9th century) is the world's largest Buddhist temple. Vietnam, ruled by China for about a thousand years, won independence in 938 and resisted later invasions, including the Mongols. From the 13th century, Islam spread through trade to the Malay world and Indonesia, now the country with the world's largest Muslim population. The port of Malacca became a great trading hub in the 15th century."]]
  ],
  terms:[["Shinto","Japan's native religion venerating kami."],["The Tale of Genji","Murasaki Shikibu's early-11th-century novel."],["Shogun","The military ruler of Japan from 1192 to 1868."],["Samurai","Japan's warrior class bound by loyalty to their lords."],["Hangul","The Korean alphabet created under King Sejong."],["Angkor Wat","The Khmer temple complex, the largest religious monument in the world."]],
  w:"These societies adapted ideas from China and India into distinctive civilizations whose traditions remain strong in East and Southeast Asia today.",
  src:["History of Japan","The Tale of Genji","Shogun","Joseon","Hangul","Khmer Empire"],
  q:[["Who wrote The Tale of Genji?","Murasaki Shikibu","Sei Shōnagon","Prince Shōtoku","Yoritomo"],
     ["What title did Minamoto no Yoritomo receive in 1192?","Shogun","Emperor","Daimyo","Samurai"],
     ["Which battle in 1600 led to Tokugawa rule?","Sekigahara","Nagashino","Dan-no-ura","Okehazama"],
     ["Which Korean king sponsored the creation of Hangul?","Sejong the Great","Taejo","Gwanggaeto","Yi Sun-sin"],
     ["What is the oldest surviving book printed with metal movable type?","The Jikji","The Diamond Sutra","The Gutenberg Bible","The Tripitaka Koreana"],
     ["Which empire built Angkor Wat?","The Khmer Empire","Srivijaya","The Majapahit","Champa"]]},

{ t:"African Kingdoms and Trade", s:"Ghana, Mali, Songhai, the Swahili coast, and beyond",
  sec:[
  ["Trans-Saharan trade",[
    "After camels became widely used in the Sahara in the early centuries CE, caravans regularly crossed the desert, linking North Africa and the Mediterranean with West Africa. West Africa exported gold, ivory, and enslaved people; North Africa supplied salt, which was scarce in the forest and savanna regions, as well as cloth, horses, and manufactured goods. Muslim merchants spread Islam along these routes, and West African rulers and elites increasingly converted, though most rural people kept traditional religions for centuries."]],
  ["Ghana and Mali",[
    "The kingdom of Ghana (not the same location as the modern country), in present-day Mauritania and Mali, flourished from around the 8th century, growing rich by taxing the gold and salt trade. Arab writers called it “the land of gold.” Its power declined in the 11th and 12th centuries.",
    "Mali rose in the 13th century under Sundiata Keita, whose story is told in the Epic of Sundiata, preserved by griots, West African oral historians and musicians. Mali's most famous ruler, Mansa Musa (reigned c. 1312–1337), made a pilgrimage to Mecca in 1324 with a huge caravan carrying so much gold that his spending in Cairo depressed gold's value there for years. He is often described as one of the wealthiest people in history. Mali appeared on the 1375 Catalan Atlas, which depicts Mansa Musa holding a gold nugget. Timbuktu became a center of Islamic scholarship, with mosques such as Djinguereber and libraries whose manuscripts survive today."]],
  ["Songhai and the forest kingdoms",[
    "The Songhai Empire, centered on Gao, became the largest West African empire in the 15th and 16th centuries under rulers such as Sunni Ali and Askia Muhammad. It fell after a Moroccan army equipped with firearms defeated it at Tondibi in 1591.",
    "Farther south, in the forest regions, powerful states developed, including the kingdom of Benin, in present-day Nigeria, famous for its walled capital and bronze and brass sculptures; many of the Benin Bronzes were looted by British forces in 1897, and some have recently been returned. The Yoruba city of Ife produced naturalistic bronze heads. The Kingdom of Kongo, in central Africa, converted to Christianity after contact with the Portuguese in the late 15th century."]],
  ["East Africa and the Swahili coast",[
    "Along the East African coast, from Somalia to Mozambique, Swahili city-states such as Kilwa, Mombasa, and Mogadishu thrived on Indian Ocean trade, exchanging gold, ivory, and other goods for cloth, porcelain, and spices from Arabia, Persia, India, and China. Swahili culture blended African, Arab, and Persian influences, and its language, a Bantu language with many Arabic loanwords, is today spoken by tens of millions. Most coastal cities were Muslim, with stone mosques and houses.",
    "In 1415, an embassy from Malindi brought a giraffe to the Chinese court, and the Ming admiral Zheng He's fleets visited the coast in the early 15th century. When the Portuguese arrived around 1500, they attacked and dominated several Swahili cities to control the trade."]],
  ["Great Zimbabwe and Ethiopia",[
    "In southern Africa, the city of Great Zimbabwe flourished from roughly the 11th to the 15th centuries, controlling trade in gold with the coast. Its massive dry-stone walls, built without mortar, enclose royal and religious areas; the Great Enclosure's outer wall is about 250 meters around. European colonists in the 19th and 20th centuries falsely claimed that Africans could not have built it, a racist myth disproved by archaeology. The modern nation of Zimbabwe takes its name from the site.",
    "In the Ethiopian highlands, Christian kingdoms continued after Aksum. Under the Zagwe dynasty, King Lalibela (reigned c. 1181–1221) commissioned extraordinary churches carved down into solid rock, still used for worship. The Solomonic dynasty, claiming descent from King Solomon and the Queen of Sheba, ruled Ethiopia from 1270 until 1974. These examples show that sub-Saharan Africa had complex states, cities, and long-distance trade networks long before European colonization."]]
  ],
  terms:[["Trans-Saharan trade","Caravan trade across the Sahara, notably in gold and salt."],["Mansa Musa","Mali's ruler, famous for his 1324 pilgrimage to Mecca."],["Griot","A West African oral historian and musician."],["Timbuktu","A center of trade and Islamic scholarship in Mali."],["Swahili city-states","East African coastal trading cities blending African and Arab culture."],["Great Zimbabwe","A southern African city famous for its stone walls."]],
  w:"African kingdoms built wealth, cities, and scholarship through vast trade networks, a history often ignored but essential to understanding the continent and the world.",
  src:["Trans-Saharan trade","Mali Empire","Mansa Musa","Songhai Empire","Swahili coast","Great Zimbabwe"],
  q:[["Which two goods were most associated with trans-Saharan trade?","Gold and salt","Silk and spices","Tea and porcelain","Cotton and sugar"],
     ["Which ruler of Mali made a famous pilgrimage to Mecca in 1324?","Mansa Musa","Sundiata Keita","Askia Muhammad","Sunni Ali"],
     ["Who preserved the Epic of Sundiata?","Griots","Monks","Scribes in Cairo","Portuguese explorers"],
     ["Which city was a center of Islamic scholarship in Mali?","Timbuktu","Kilwa","Lalibela","Gao"],
     ["Which empire fell to a Moroccan army at Tondibi in 1591?","Songhai","Mali","Ghana","Benin"],
     ["Which Ethiopian king commissioned churches carved from solid rock?","Lalibela","Ezana","Menelik II","Haile Selassie"]]},

{ t:"India from the Sultanates to the Eve of the Mughals", s:"Delhi, Vijayanagara, and the Indian Ocean world",
  sec:[
  ["Regional kingdoms",[
    "After the Gupta Empire declined in the 6th century, India was divided among regional kingdoms. In the south, the Chola dynasty (flourishing c. 850–1279) built a powerful navy, launched expeditions to Sri Lanka and Southeast Asia, and constructed magnificent temples such as the Brihadisvara Temple at Thanjavur. Indian merchants, Hindu and Buddhist culture, and Sanskrit literature spread across the Indian Ocean.",
    "Indian thought and devotion flourished in this period. The bhakti movement emphasized personal, emotional devotion to a god, expressed in poetry in regional languages, and challenged caste hierarchy and ritual formalism."]],
  ["The Delhi Sultanate",[
    "Muslim rule in India began with Arab conquest of Sind in 711 and grew through raids by Turkic rulers from Afghanistan, such as Mahmud of Ghazni in the early 11th century, who plundered temples. In 1206, the Delhi Sultanate was established, ruling much of northern India under a series of Turkic and Afghan dynasties until 1526.",
    "The sultanate repelled Mongol invasions, a significant achievement, and built monuments such as the Qutb Minar, a towering minaret in Delhi. Sultan Muhammad bin Tughluq (reigned 1325–1351) attempted bold but disastrous experiments, such as moving the capital and issuing token copper currency. In 1398, the Central Asian conqueror Timur sacked Delhi. Raziya Sultan (reigned 1236–1240) was one of the few women to rule in the Islamic world."]],
  ["Cultural exchange",[
    "Under the sultanates, Persian became the language of government and high culture in much of India, and Indo-Islamic architecture combined Persian and Indian styles. Sufi mystics, Muslims emphasizing personal experience of God, attracted followers across religious lines, and Sufi shrines, such as that of Nizamuddin Auliya in Delhi, remain popular pilgrimage sites.",
    "Relations between Hindus and Muslims included both conflict, such as the destruction of some temples, and coexistence and exchange. The Urdu language developed from a mixture of Hindustani with Persian and Arabic. The poet-saint Kabir (15th century) criticized the rituals of both Hinduism and Islam and preached devotion to one God. Guru Nanak (1469–1539) founded Sikhism in the Punjab, teaching devotion to one God, equality, and service."]],
  ["Vijayanagara",[
    "In southern India, the Hindu Vijayanagara Empire (1336–1646) became one of the most powerful states in the subcontinent. Its capital, Vijayanagara (near modern Hampi), was among the largest cities in the world in the 15th and 16th centuries, impressing Persian and Portuguese visitors with its markets, temples, and waterworks. Under Krishnadevaraya (reigned 1509–1529), the empire reached its height.",
    "In 1565, an alliance of Deccan sultanates defeated Vijayanagara at the Battle of Talikota and sacked the capital, whose ruins are now a World Heritage Site."]],
  ["The Indian Ocean world and the Portuguese",[
    "For centuries, India was at the center of a vast Indian Ocean trading network, driven by the monsoon winds, which blow from the southwest in summer and the northeast in winter, allowing predictable voyages. Indian textiles, especially cotton cloth, were in demand from East Africa to Southeast Asia, while pepper from the Malabar coast was prized in Europe.",
    "In 1498, the Portuguese navigator Vasco da Gama reached Calicut in India by sailing around Africa, opening a direct sea route from Europe. The Portuguese seized Goa in 1510 and tried to control the spice trade by force, beginning centuries of European involvement in Indian Ocean trade. In 1526, Babur, a descendant of Timur and Genghis Khan, defeated the last Delhi sultan at the First Battle of Panipat and founded the Mughal Empire, covered in the next unit."]]
  ],
  terms:[["Chola dynasty","A powerful South Indian dynasty with a strong navy."],["Bhakti","A devotional movement emphasizing personal love of God."],["Delhi Sultanate","Muslim dynasties ruling northern India from 1206 to 1526."],["Sufism","Islamic mysticism emphasizing personal experience of God."],["Sikhism","The religion founded by Guru Nanak in the Punjab."],["Vijayanagara Empire","A powerful Hindu empire in southern India, 1336–1646."]],
  w:"Medieval India blended Hindu, Muslim, and other traditions and sat at the center of Indian Ocean trade that drew Europeans to Asia.",
  src:["Chola dynasty","Delhi Sultanate","Bhakti movement","Guru Nanak","Vijayanagara Empire","Vasco da Gama"],
  q:[["Which South Indian dynasty built a powerful navy and the Brihadisvara Temple?","The Chola","The Gupta","The Maurya","The Pallava only"],
     ["When was the Delhi Sultanate established?","1206","711","1526","1398"],
     ["Who founded Sikhism?","Guru Nanak","Kabir","Akbar","Nizamuddin Auliya"],
     ["Which conqueror sacked Delhi in 1398?","Timur","Genghis Khan","Babur","Mahmud of Ghazni"],
     ["Which Hindu empire's capital was near modern Hampi?","Vijayanagara","Chola","Maratha","Rajput"],
     ["Who reached Calicut by sea in 1498?","Vasco da Gama","Christopher Columbus","Bartolomeu Dias","Ferdinand Magellan"]]},

{ t:"The Aztec and Inca Empires", s:"The great American states on the eve of conquest",
  sec:[
  ["The Mexica and Tenochtitlan",[
    "The Aztecs, who called themselves the Mexica, migrated into the Valley of Mexico and, according to their tradition, founded their capital Tenochtitlan in 1325 on an island in Lake Texcoco where they saw an eagle perched on a cactus, an image now on Mexico's flag. Through alliances, especially the Triple Alliance formed in 1428 with Texcoco and Tlacopan, and military conquest, they built an empire that dominated central Mexico.",
    "By 1519, Tenochtitlan may have held 200,000 people or more, larger than any city in Spain. Causeways connected it to the shore, aqueducts brought fresh water, and chinampas, artificial island gardens, produced food. Its great market at Tlatelolco astonished the Spanish. The empire collected tribute from conquered peoples rather than governing them directly."]],
  ["Aztec religion and society",[
    "Aztec society was hierarchical, with nobles, priests, warriors, merchants, commoners, and enslaved people. Education was required for boys, and warriors rose in status by capturing enemies. The Aztecs worshipped many gods, including Huitzilopochtli, god of sun and war, and Quetzalcoatl, the feathered serpent.",
    "Aztec religion held that the gods had sacrificed themselves to create the world and needed nourishment from human blood to keep the sun moving. Human sacrifice, especially of war captives, was performed on a large scale at the Templo Mayor, though numbers reported by Spanish sources are disputed. The tribute and sacrifice demanded of subject peoples created resentment that the Spanish later exploited."]],
  ["The Inca Empire",[
    "In the Andes, the Inca built the largest empire in the pre-Columbian Americas, Tawantinsuyu, “the four parts together,” stretching about 4,000 kilometers from present-day Ecuador to Chile. From their capital at Cusco, Inca rulers, led by Pachacuti from about 1438, expanded rapidly through conquest and diplomacy, ruling perhaps ten million people.",
    "The Inca built a road network of about 40,000 kilometers, with suspension bridges and relay runners (chasquis) who carried messages. Lacking a writing system in the usual sense, they recorded numbers and possibly other information on khipus, knotted strings. They resettled populations, imposed the Quechua language, and required labor service (mit'a) in place of money taxes; the state stored food in warehouses to feed armies and aid communities in hard times. Machu Picchu, built as a royal estate in the 15th century, shows their extraordinary stonework, fitted without mortar."]],
  ["Strengths and vulnerabilities",[
    "Both empires were powerful, organized, and sophisticated, but they had vulnerabilities. The Aztecs ruled resentful subject peoples who could become allies of an invader. The Inca had just endured a civil war between two brothers, Atahualpa and Huáscar, when the Spanish arrived in 1532.",
    "Most decisive was disease. Peoples of the Americas had no immunity to Old World diseases such as smallpox, measles, and influenza. Epidemics swept ahead of the conquerors; smallpox devastated Tenochtitlan during the Spanish siege of 1521 and killed the Inca ruler Huayna Capac and his heir, triggering the civil war."]],
  ["Conquest",[
    "Hernán Cortés landed in Mexico in 1519 with a few hundred Spaniards. He allied with the Tlaxcalans and other enemies of the Aztecs, who provided thousands of warriors, and was aided by an Indigenous woman, Malintzin (La Malinche), who served as interpreter. The emperor Moctezuma II received the Spanish in Tenochtitlan and was taken hostage and killed in 1520. After a long siege, the city fell in 1521.",
    "Francisco Pizarro captured the Inca emperor Atahualpa at Cajamarca in 1532 in a surprise attack. Atahualpa offered to fill a room with gold and silver as ransom; the Spanish collected it and executed him anyway in 1533. Inca resistance continued until 1572. The conquests opened an era of Spanish colonial rule, mass death from disease and exploitation, and the Columbian Exchange, covered in the next unit. Indigenous cultures and languages, including Nahuatl and Quechua, survive and are spoken by millions today."]]
  ],
  terms:[["Mexica","The people commonly called the Aztecs."],["Tenochtitlan","The Aztec capital on Lake Texcoco, founded in 1325."],["Chinampas","Aztec artificial island gardens."],["Tawantinsuyu","The Inca name for their empire."],["Khipu","Inca knotted-string records."],["Mit'a","The Inca labor-service system."]],
  w:"The Aztec and Inca empires were among the world's great civilizations, and their conquest reshaped the Americas and the global economy.",
  src:["Aztec Empire","Tenochtitlan","Inca Empire","Quipu","Spanish conquest of the Aztec Empire","Spanish conquest of the Inca Empire"],
  q:[["According to tradition, when was Tenochtitlan founded?","1325","1519","1428","1200"],
     ["What were chinampas?","Artificial island gardens","Temples","Roads","Warriors"],
     ["What did the Inca call their empire?","Tawantinsuyu","Mexica","Cusco","Quechua"],
     ["What were khipus?","Knotted-string records","Relay runners","Suspension bridges","Labor taxes"],
     ["Who served as Cortés' interpreter?","Malintzin (La Malinche)","Moctezuma","Atahualpa","Tlaxcala"],
     ["Which Inca ruler did Pizarro capture at Cajamarca?","Atahualpa","Huáscar","Pachacuti","Huayna Capac"]]}
);


/* ---- from hist-06.js ---- */
/* HISTORY FOUNDATIONS, part 6: Unit 4 (The Early Modern World), chapters 1-5 */
COURSES.history.units.push({ t:"The Early Modern World", ch:[

{ t:"The Renaissance", s:"Rebirth in Italy and beyond, c. 1350–1600",
  sec:[
  ["Why Italy?",[
    "The Renaissance, French for “rebirth,” was a cultural movement that began in 14th-century Italy and spread across Europe, marked by renewed interest in the art, literature, and learning of ancient Greece and Rome. Italy was a natural birthplace. Its city-states, such as Florence, Venice, and Milan, were wealthy from trade and banking; Roman ruins surrounded Italians as reminders of past greatness; and contact with Byzantine and Islamic scholars brought classical texts, especially after Constantinople fell in 1453.",
    "Italian city-states competed for prestige by sponsoring art and learning. Florence, a republic dominated by the Medici banking family from the 1430s, became the movement's center. Cosimo de' Medici and his grandson Lorenzo the Magnificent were great patrons of artists and scholars."]],
  ["Humanism",[
    "The intellectual heart of the Renaissance was humanism, the study of classical texts and the humanities (grammar, rhetoric, poetry, history, and moral philosophy) as preparation for an active, virtuous life. Petrarch (1304–1374), often called the father of humanism, hunted for lost Latin manuscripts and wrote influential poetry. Humanists studied Greek, prized eloquence and critical reading of sources, and emphasized human potential and achievement.",
    "Humanist scholarship had real critical power. In 1440, Lorenzo Valla used linguistic analysis to prove that the Donation of Constantine, a document supposedly granting the pope authority over the western empire, was an 8th-century forgery. Humanism also produced new political thinking, notably Machiavelli's The Prince (written 1513)."]],
  ["Renaissance art",[
    "Renaissance artists sought realism and beauty grounded in classical models and careful observation. Giotto, around 1300, began painting figures with weight and emotion. Filippo Brunelleschi engineered the great dome of Florence Cathedral (completed 1436) and demonstrated linear perspective, which Masaccio used to create convincing depth in painting. Donatello revived freestanding bronze sculpture.",
    "The High Renaissance, around 1490 to 1527, produced its most famous masters. Leonardo da Vinci painted The Last Supper and the Mona Lisa and filled notebooks with studies of anatomy, engineering, and nature. Michelangelo carved the David (1501–1504) and painted the Sistine Chapel ceiling (1508–1512). Raphael painted The School of Athens. Venice developed its own tradition of rich color under Titian. Patrons included popes, who rebuilt Rome as a Renaissance city, including the new St. Peter's Basilica."]],
  ["The printing press",[
    "Around 1450, Johannes Gutenberg of Mainz developed a printing press with movable metal type, oil-based ink, and a press adapted from wine presses. The Gutenberg Bible was completed around 1455. Printing spread rapidly: by 1500, presses operated in more than 250 European cities, and millions of books had been printed.",
    "Printing transformed European society. Books became far cheaper, literacy spread, texts were standardized, scholars could compare identical copies, and ideas, including religious and political dissent, spread faster than authorities could control them. Without printing, the Protestant Reformation and the Scientific Revolution would have unfolded very differently."]],
  ["The Northern Renaissance",[
    "Renaissance ideas spread north to France, the Low Countries, Germany, and England, often combined with religious concerns. Christian humanists such as Erasmus of Rotterdam used classical scholarship to study the Bible in its original languages and to criticize church corruption. Thomas More wrote Utopia (1516).",
    "Northern artists such as Jan van Eyck, a pioneer of oil painting, and Albrecht Dürer, famous for his engravings, developed detailed realism. In England, the Renaissance flowered under Elizabeth I with the plays of William Shakespeare and Christopher Marlowe. Historians debate how sharply the Renaissance broke with the Middle Ages, but it clearly reshaped European art, education, and ideas about human potential."]]
  ],
  terms:[["Renaissance","The “rebirth” of classical learning and art beginning in 14th-century Italy."],["Humanism","The study of classical texts and the humanities to cultivate virtue and eloquence."],["Medici","The banking family that dominated Florence and patronized the arts."],["Linear perspective","A technique for depicting depth, developed by Brunelleschi."],["Gutenberg press","The movable-type printing press developed around 1450."],["Northern Renaissance","The Renaissance in northern Europe, often with religious emphasis."]],
  w:"The Renaissance revived classical learning, produced enduring art, and through printing set off the religious and scientific upheavals that created modern Europe.",
  src:["Renaissance","Renaissance humanism","Medici family","Printing press","Johannes Gutenberg","Northern Renaissance"],
  q:[["Which family dominated Florence and patronized the arts?","The Medici","The Borgia","The Sforza","The Habsburgs"],
     ["Who is often called the father of humanism?","Petrarch","Dante","Erasmus","Machiavelli"],
     ["What did Lorenzo Valla prove was a forgery?","The Donation of Constantine","The Gospel of Thomas","The Magna Carta","The Corpus Juris Civilis"],
     ["Who engineered the dome of Florence Cathedral?","Brunelleschi","Michelangelo","Leonardo da Vinci","Donatello"],
     ["Around when was the Gutenberg Bible completed?","1455","1300","1517","1600"],
     ["Which northern humanist studied the Bible in its original languages?","Erasmus","Dürer","Van Eyck","Marlowe"]]},

{ t:"The Reformation and the Wars of Religion", s:"The breakup of Western Christendom",
  sec:[
  ["Luther's protest",[
    "By the early 16th century, many Europeans criticized the Catholic Church's wealth, political involvement, and practices such as the sale of indulgences, documents said to reduce punishment for sins in purgatory. In 1517, Martin Luther, a German monk and professor of theology at Wittenberg, published his Ninety-Five Theses challenging indulgences. Printed copies spread across Germany within weeks.",
    "Luther developed a radical theology: salvation comes by faith alone (sola fide), through God's grace, not by good works or church rituals; the Bible alone (sola scriptura) is the supreme authority; and all believers share in the priesthood. Excommunicated by the pope, he was summoned before Emperor Charles V at the Diet of Worms in 1521, where he refused to recant. Protected by the Elector of Saxony, he translated the Bible into German, shaping the German language."]],
  ["Other reformers",[
    "Other reformers followed. In Zurich, Huldrych Zwingli led a reformation. In Geneva, John Calvin (1509–1564) developed a systematic Protestant theology emphasizing God's sovereignty and predestination, the belief that God has already chosen who will be saved. His Institutes of the Christian Religion was enormously influential. Calvinism spread to the Netherlands, Scotland (under John Knox, founding Presbyterianism), France (the Huguenots), and later England's Puritans and colonial New England.",
    "Anabaptists rejected infant baptism and often state churches, and were persecuted by Catholics and Protestants alike; their descendants include the Mennonites and Amish. The Peasants' War of 1524–1525 in Germany, partly inspired by Reformation ideas, was crushed, with Luther's approval."]],
  ["The English Reformation",[
    "In England, the Reformation began as a political act. When Pope Clement VII refused to annul Henry VIII's marriage to Catherine of Aragon, who had not produced a male heir, Parliament's Act of Supremacy (1534) made the king head of the Church of England. Henry dissolved the monasteries and seized their wealth.",
    "England swung between Protestantism under Edward VI and Catholicism under Mary I, who burned nearly 300 Protestants. Elizabeth I (reigned 1558–1603) established a moderate Protestant Church of England. In 1588, the English defeated the Spanish Armada sent by the Catholic king Philip II, a victory that secured Protestant England."]],
  ["The Catholic Reformation",[
    "The Catholic Church responded with its own reform movement, sometimes called the Counter-Reformation. The Council of Trent (1545–1563) reaffirmed Catholic doctrine, including the role of good works and the seven sacraments, while ending abuses such as the sale of indulgences and improving the training of priests. The Index of Forbidden Books and the Roman Inquisition targeted heresy.",
    "New religious orders revitalized Catholicism. The Society of Jesus, the Jesuits, founded by Ignatius of Loyola in 1540, became famous for education, founding hundreds of schools, and for missionary work in Asia, Africa, and the Americas. Baroque art and architecture, emotional and grand, became a vehicle of Catholic renewal."]],
  ["The Wars of Religion",[
    "Religious division led to more than a century of war. In France, the Wars of Religion (1562–1598) between Catholics and Huguenots included the St. Bartholomew's Day Massacre of 1572, in which thousands of Protestants were killed. Henry IV, a Protestant who converted to Catholicism to become king (reportedly saying “Paris is well worth a mass”), issued the Edict of Nantes in 1598, granting Huguenots limited toleration.",
    "The Thirty Years' War (1618–1648), beginning as a conflict between Protestants and Catholics in the Holy Roman Empire, became a European struggle for power drawing in Sweden, France, Spain, and others. It devastated Germany, killing perhaps a fifth or more of its population through war, famine, and disease. The Peace of Westphalia (1648) recognized the rulers' right to determine their territories' religion, gave independence to the Dutch Republic and Switzerland, and is often seen as the origin of the modern system of sovereign states. Exhaustion with religious war encouraged arguments for toleration and the separation of politics from religion."]]
  ],
  terms:[["Indulgences","Church documents said to reduce punishment for sins."],["Ninety-Five Theses","Luther's 1517 challenge to the sale of indulgences."],["Sola fide","Salvation by faith alone, a core Protestant teaching."],["Predestination","Calvin's teaching that God has chosen who will be saved."],["Council of Trent","The Catholic council of 1545–1563 that defined Catholic reform."],["Peace of Westphalia","The 1648 treaties ending the Thirty Years' War."]],
  w:"The Reformation divided Western Christianity, reshaped politics and education, and through its wars pushed Europe toward toleration and the modern state system.",
  src:["Reformation","Martin Luther","Ninety-five Theses","John Calvin","Counter-Reformation","Peace of Westphalia"],
  q:[["In what year did Luther publish the Ninety-Five Theses?","1517","1492","1521","1534"],
     ["Where did Luther refuse to recant before Emperor Charles V?","The Diet of Worms","The Council of Trent","Wittenberg","Augsburg"],
     ["Which reformer emphasized predestination and led Geneva?","John Calvin","Huldrych Zwingli","John Knox","Erasmus"],
     ["Which act made Henry VIII head of the Church of England?","The Act of Supremacy","The Edict of Nantes","The Act of Settlement","The Bill of Rights"],
     ["Who founded the Jesuits?","Ignatius of Loyola","Francis Xavier","Dominic","Pope Paul III"],
     ["Which 1648 treaties ended the Thirty Years' War?","The Peace of Westphalia","The Treaty of Utrecht","The Peace of Augsburg","The Treaty of Tordesillas"]]},

{ t:"The Age of Exploration", s:"Europe's oceanic expansion, 1415–1600",
  sec:[
  ["Motives and means",[
    "In the 15th century, European states, led by Portugal and Spain, began sailing beyond familiar waters. Their motives are often summarized as “God, gold, and glory”: spreading Christianity, gaining wealth, especially by reaching the spices and luxuries of Asia without Ottoman and Venetian middlemen, and winning prestige. Rivalries among European states pushed exploration forward.",
    "New tools made long voyages possible: the caravel, a small, maneuverable ship with lateen (triangular) sails that could sail against the wind; the magnetic compass and astrolabe, partly acquired from Chinese and Islamic sources; better maps; and knowledge of wind patterns. Ships carried cannons, which gave Europeans military advantages at sea."]],
  ["Portugal and the route to Asia",[
    "Portugal's Prince Henry “the Navigator” (1394–1460) sponsored voyages down the West African coast, beginning after Portugal captured Ceuta in North Africa in 1415. Portuguese sailors settled Atlantic islands such as Madeira and the Azores and established trading posts in West Africa for gold and enslaved people. In 1488, Bartolomeu Dias rounded the Cape of Good Hope at Africa's southern tip.",
    "In 1498, Vasco da Gama reached India, opening a direct sea route from Europe to Asia. The Portuguese built a trading empire of fortified ports, Goa in India, Malacca in Southeast Asia, and Macau in China, and tried to control the spice trade by force. In 1500, Pedro Álvares Cabral, sailing to India, reached Brazil and claimed it for Portugal."]],
  ["Columbus and the Americas",[
    "The Genoese navigator Christopher Columbus believed he could reach Asia by sailing west, underestimating Earth's size. After Portugal rejected his plan, Spain's monarchs Ferdinand and Isabella sponsored him in 1492, the year they completed the Reconquista and expelled Spain's Jews. On October 12, 1492, his three ships reached an island in the Bahamas. Columbus made four voyages to the Caribbean and Central America and insisted until his death that he had reached Asia.",
    "Columbus' voyages began lasting contact between the Eastern and Western Hemispheres. He also began the enslavement and brutal treatment of the Taíno people of Hispaniola, whose population collapsed within decades. The continents were later named America after Amerigo Vespucci, who argued that they were a “New World.” The Treaty of Tordesillas (1494), mediated by the pope, divided newly discovered lands between Spain and Portugal along a north-south line, which is why Brazil speaks Portuguese."]],
  ["Circumnavigation and other explorers",[
    "In 1519, Ferdinand Magellan, a Portuguese navigator sailing for Spain, set out to reach Asia by sailing west. His fleet passed through the strait at South America's tip that bears his name and crossed the vast Pacific. Magellan was killed in the Philippines in 1521, but one ship, commanded by Juan Sebastián Elcano, returned to Spain in 1522, completing the first circumnavigation of the globe. Only about 18 of roughly 270 original crew members survived the voyage.",
    "Other powers followed. John Cabot, sailing for England, reached Newfoundland in 1497. Jacques Cartier explored the St. Lawrence River for France in the 1530s. Later, the Dutch, English, and French built their own overseas empires and trading companies."]],
  ["Consequences",[
    "The voyages of exploration created the first truly global connections, linking all inhabited continents through trade, migration, and conquest. They shifted Europe's economic center from the Mediterranean to the Atlantic, enriched Spain and Portugal, and later the Netherlands, England, and France, and began centuries of European colonialism.",
    "They also brought catastrophe to many peoples, through conquest, disease, and enslavement. Historians today avoid describing the period simply as “discovery,” since the lands Europeans reached were already home to millions of people, and they emphasize the perspectives of Africans, Asians, and Indigenous Americans who experienced European expansion."]]
  ],
  terms:[["Caravel","A small, maneuverable ship used by Portuguese and Spanish explorers."],["Prince Henry the Navigator","Portuguese prince who sponsored voyages along Africa."],["Cape of Good Hope","Africa's southern cape, rounded by Dias in 1488."],["Treaty of Tordesillas","The 1494 treaty dividing new lands between Spain and Portugal."],["Circumnavigation","Sailing around the world, first completed by Magellan's expedition in 1522."],["God, gold, and glory","A summary of the motives for European exploration."]],
  w:"The Age of Exploration launched globalization and European empires, transforming the lives of people on every inhabited continent.",
  src:["Age of Discovery","Henry the Navigator","Vasco da Gama","Christopher Columbus","Treaty of Tordesillas","Magellan expedition"],
  q:[["Who first rounded the Cape of Good Hope in 1488?","Bartolomeu Dias","Vasco da Gama","Prince Henry","Pedro Cabral"],
     ["Which monarchs sponsored Columbus?","Ferdinand and Isabella","Henry VII","Manuel I","Charles V"],
     ["Which treaty divided new lands between Spain and Portugal?","The Treaty of Tordesillas","The Peace of Westphalia","The Treaty of Paris","The Treaty of Utrecht"],
     ["After whom were the Americas named?","Amerigo Vespucci","Christopher Columbus","John Cabot","Ferdinand Magellan"],
     ["Who completed the first circumnavigation after Magellan's death?","Juan Sebastián Elcano","Francis Drake","Vasco da Gama","Hernán Cortés"],
     ["Who reached Brazil in 1500 and claimed it for Portugal?","Pedro Álvares Cabral","Bartolomeu Dias","Amerigo Vespucci","Jacques Cartier"]]},

{ t:"Colonial Empires and the Columbian Exchange", s:"Conquest, disease, and a transformed world",
  sec:[
  ["The demographic catastrophe",[
    "European contact brought Old World diseases, including smallpox, measles, influenza, and typhus, to peoples of the Americas who had no prior exposure and therefore no immunity. Epidemics swept through Indigenous populations, often ahead of the conquerors themselves. Estimates vary widely, but historians commonly estimate that Indigenous populations in many regions fell by 80 to 90 percent within a century or so of contact, one of the greatest demographic disasters in human history.",
    "Disease combined with war, enslavement, forced labor, displacement, and famine. Some scholars have argued that the population collapse was so large that the regrowth of forests on abandoned farmland may have contributed to cooling during the “Little Ice Age.”"]],
  ["Spanish America",[
    "After conquering the Aztec and Inca empires, Spain built a vast colonial empire governed through viceroyalties, first New Spain (centered on Mexico City) and Peru (centered on Lima). The encomienda system granted Spanish colonists the labor and tribute of Indigenous people in return for supposedly protecting and Christianizing them; in practice it was often brutal. The Dominican friar Bartolomé de las Casas denounced these abuses, contributing to the New Laws of 1542, which aimed to limit them.",
    "Silver became the empire's lifeblood. The mountain of Potosí in present-day Bolivia, discovered in 1545, was one of the richest silver deposits ever found; Indigenous laborers forced to work there under the mit'a system died in large numbers. Spanish American silver flowed to Europe and, via the Manila galleons, which sailed between Acapulco and Manila from 1565, to China, which demanded silver for its economy. This silver trade created the first truly global economy. Colonial society developed a hierarchy based on ancestry, with Spaniards at the top and mixed-race, Indigenous, and African people below."]],
  ["Portuguese, French, Dutch, and English colonies",[
    "Portugal developed Brazil as a sugar colony worked by enslaved Africans. France built New France along the St. Lawrence and Mississippi rivers, based mainly on the fur trade with Indigenous partners, and later lucrative sugar colonies in the Caribbean, especially Saint-Domingue (Haiti).",
    "The Dutch built a commercial empire through the Dutch East India Company (VOC), founded in 1602, the first company to issue publicly traded shares, which dominated trade with Indonesia, and founded New Amsterdam (later New York). England founded colonies in North America, beginning with Jamestown in 1607, and in the Caribbean, where Barbados and Jamaica became sugar colonies. The English East India Company, chartered in 1600, later conquered much of India."]],
  ["The Columbian Exchange",[
    "The historian Alfred Crosby coined the term “Columbian Exchange” in 1972 for the transfer of plants, animals, diseases, and people between the Eastern and Western Hemispheres after 1492. From the Americas came maize, potatoes, tomatoes, cassava, chili peppers, cacao, tobacco, peanuts, and vanilla. From Afro-Eurasia came wheat, rice, sugar cane, coffee, bananas, cattle, horses, pigs, sheep, and chickens.",
    "The exchange transformed diets and societies. American crops, especially potatoes and maize, which yield more calories per acre, fueled population growth in Europe, Africa, and China. Horses transformed the life of Plains peoples in North America. Sugar cane, grown on plantations, created enormous demand for labor that was met by the transatlantic slave trade."]],
  ["A new global order",[
    "By 1600, a few European states had begun to build empires spanning oceans, connected by trade in silver, sugar, spices, textiles, and human beings. Europe was not yet dominant over Asia's great empires, Ming China and Mughal India were far wealthier and more powerful, but it controlled the Atlantic world.",
    "Mercantilism, the dominant economic theory, held that a nation's wealth depended on accumulating gold and silver and maintaining a favorable balance of trade, with colonies supplying raw materials and buying finished goods from the home country. These policies shaped colonial economies and later provoked colonial resentment, including in British North America."]]
  ],
  terms:[["Columbian Exchange","The transfer of crops, animals, diseases, and people between hemispheres after 1492."],["Encomienda","A Spanish grant of Indigenous labor and tribute to colonists."],["Potosí","A massive silver mine in present-day Bolivia."],["Manila galleons","Spanish ships linking Mexico and the Philippines."],["Dutch East India Company (VOC)","The Dutch trading company founded in 1602."],["Mercantilism","The economic theory that colonies should enrich the home country."]],
  w:"The colonial empires and the Columbian Exchange reshaped the world's populations, diets, economies, and power, with consequences that continue today.",
  src:["Columbian exchange","Population history of the Indigenous peoples of the Americas","Encomienda","Potosí","Dutch East India Company","Mercantilism"],
  q:[["Who coined the term “Columbian Exchange”?","Alfred Crosby","Jared Diamond","Fernand Braudel","Charles Mann"],
     ["Who denounced Spanish abuses of Indigenous peoples?","Bartolomé de las Casas","Hernán Cortés","Francisco Pizarro","Juan de Oñate"],
     ["Where was the great silver mountain discovered in 1545?","Potosí","Zacatecas","Cusco","Mexico City"],
     ["Which ships linked Acapulco and Manila?","The Manila galleons","The Spanish Armada","The treasure fleets of Zheng He","The East Indiamen"],
     ["Which company, founded in 1602, issued the first publicly traded shares?","The Dutch East India Company","The English East India Company","The Hudson's Bay Company","The Virginia Company"],
     ["Which crop from the Americas fueled population growth in Europe?","The potato","Wheat","Rice","Sugar cane"]]},

{ t:"The Atlantic Slave Trade", s:"Forced migration and the making of the Atlantic world",
  sec:[
  ["Origins",[
    "Slavery existed in many societies, including in Africa, Europe, and the Islamic world, long before the Atlantic trade. But the transatlantic slave trade, from the 16th to the 19th centuries, was unprecedented in scale and in its racial basis. It grew from the demand for labor on sugar plantations, first on Atlantic islands such as São Tomé and Madeira and then in Brazil and the Caribbean, after Indigenous populations collapsed.",
    "Between the early 16th and mid-19th centuries, an estimated 12.5 million Africans were forced onto ships bound for the Americas, according to the Trans-Atlantic Slave Trade Database; about 10.7 million survived the voyage. Most were taken to Brazil and the Caribbean; roughly 400,000 were brought directly to the territory that became the United States."]],
  ["How the trade worked",[
    "European traders, Portuguese, then Dutch, British, French, and others, did not usually capture people themselves. They bought captives from African rulers and merchants at coastal forts and trading posts, such as Elmina in present-day Ghana, in exchange for textiles, guns, metal goods, and alcohol. Captives were often prisoners of war or victims of raids, and the trade's demand intensified warfare and political upheaval in parts of West and Central Africa, while some African states grew powerful from it.",
    "The trade is often described as a “triangular trade”: manufactured goods from Europe to Africa, enslaved people from Africa to the Americas, and plantation products such as sugar, tobacco, rice, and cotton from the Americas to Europe. In reality, routes were more varied, including direct trade between Brazil and Africa."]],
  ["The Middle Passage",[
    "The voyage across the Atlantic, called the Middle Passage, typically took one to three months. Captives were chained and packed tightly below decks in suffocating, unsanitary conditions, with little food or water. Disease, violence, and despair killed many; roughly 12 to 15 percent of those embarked died during the voyage on average, and more died soon after arrival. Some captives resisted through shipboard revolts or refused to eat.",
    "Accounts by survivors, such as Olaudah Equiano's autobiography The Interesting Narrative (1789), along with ship records and illustrations such as the diagram of the slave ship Brookes, later became powerful tools for the abolitionist movement."]],
  ["Plantation slavery in the Americas",[
    "In the Americas, enslaved Africans and their descendants worked on plantations producing sugar, coffee, tobacco, rice, indigo, and later cotton, as well as in mines, cities, and households. Sugar plantations in the Caribbean and Brazil were especially deadly, with mortality so high that the enslaved population could only be maintained by continuous imports. Laws defined enslaved people as property, made slavery hereditary through the mother, and denied them legal rights.",
    "Enslaved people resisted in many ways: slowing work, running away, preserving African languages, religions, and music, forming families and communities, and revolting. Communities of escaped people, called maroons, formed in Jamaica, Brazil (such as Palmares, which lasted much of the 17th century), and elsewhere. The largest and most successful revolt, the Haitian Revolution (1791–1804), is covered in the next unit."]],
  ["Legacy",[
    "The Atlantic slave trade enriched European merchants, plantation owners, and states, and historians continue to debate how much it contributed to Europe's industrialization. It drained West and Central Africa of young people, fueled warfare, and contributed to the conditions that later facilitated colonial conquest.",
    "It also created the African diaspora in the Americas, whose cultures profoundly shaped the music, religion, cuisine, and language of the Western Hemisphere. Ideas of race developed partly to justify the enslavement of Africans, leaving legacies of racism that persisted long after abolition. Britain abolished the slave trade in 1807 and slavery in most of its empire in 1833; the United States banned the importation of enslaved people in 1808 but abolished slavery only in 1865; Brazil was the last country in the Americas to abolish slavery, in 1888."]]
  ],
  terms:[["Transatlantic slave trade","The forced transport of Africans to the Americas, 16th–19th centuries."],["Middle Passage","The Atlantic crossing endured by enslaved Africans."],["Triangular trade","The simplified model of trade among Europe, Africa, and the Americas."],["Maroons","Communities of people who escaped slavery."],["African diaspora","Communities of African descent outside Africa."],["Olaudah Equiano","A formerly enslaved writer whose 1789 narrative aided abolition."]],
  w:"The slave trade shaped the economies, populations, and racial divisions of the Americas, Africa, and Europe, and its legacies remain central to modern history.",
  src:["Atlantic slave trade","Middle Passage","Triangular trade","Olaudah Equiano","Maroons","Abolitionism"],
  q:[["About how many Africans were forced onto ships in the Atlantic slave trade?","12.5 million","1 million","50 million","400,000"],
     ["About how many were brought directly to what became the United States?","About 400,000","About 5 million","About 10 million","About 50,000"],
     ["What was the Atlantic crossing called?","The Middle Passage","The Northwest Passage","The Trail of Tears","The Long March"],
     ["Who wrote The Interesting Narrative (1789)?","Olaudah Equiano","Frederick Douglass","Toussaint Louverture","Phillis Wheatley"],
     ["What were communities of escaped enslaved people called?","Maroons","Creoles","Mestizos","Griots"],
     ["Which was the last country in the Americas to abolish slavery?","Brazil","The United States","Cuba","Haiti"]]}
]});


/* ---- from hist-07.js ---- */
/* HISTORY FOUNDATIONS, part 7: Unit 4 (The Early Modern World), chapters 6-9 */
COURSES.history.units[3].ch.push(

{ t:"The Gunpowder Empires", s:"Ottomans, Safavids, and Mughals",
  sec:[
  ["Three Islamic empires",[
    "Between the 15th and 18th centuries, three powerful Islamic empires dominated much of the Middle East and South Asia: the Ottoman Empire in Anatolia, the Balkans, the Arab world, and North Africa; the Safavid Empire in Persia; and the Mughal Empire in India. Historians Marshall Hodgson and William McNeill called them “gunpowder empires” because their rise depended partly on the effective use of cannon and firearms, though their success also rested on administration, religion, and trade."]],
  ["The Ottoman Empire",[
    "The Ottomans, a Turkish dynasty named after its founder Osman I (died c. 1323), expanded from northwestern Anatolia into the Balkans. In 1453, Mehmed II conquered Constantinople, which became Istanbul, the Ottoman capital. Selim I conquered Syria, Egypt, and the holy cities of Mecca and Medina in 1516–1517, and the Ottoman sultans claimed the title of caliph.",
    "The empire reached its height under Suleiman the Magnificent (reigned 1520–1566), known to Ottomans as “the Lawgiver” for his legal codes. His forces conquered Hungary after the Battle of Mohács (1526) and besieged Vienna in 1529. The architect Mimar Sinan built magnificent mosques such as the Süleymaniye. The Ottoman army included the Janissaries, elite infantry recruited through the devshirme, a system that took boys from Christian families, converted them to Islam, and trained them as soldiers and administrators.",
    "The Ottomans governed a diverse population through the millet system, which allowed religious communities, such as Orthodox Christians, Armenians, and Jews, to manage their own religious and legal affairs. Many Jews expelled from Spain in 1492 found refuge in Ottoman lands. Ottoman naval power was checked at the Battle of Lepanto in 1571, and a second siege of Vienna failed in 1683, after which the empire slowly lost territory in Europe. It survived until 1922."]],
  ["The Safavid Empire",[
    "In 1501, Ismail I, leader of a Sufi religious order, founded the Safavid dynasty in Persia and made Twelver Shia Islam the state religion, imposing it on a largely Sunni population. This decision made Iran the center of Shia Islam, as it remains today, and set the Safavids against the Sunni Ottomans in long wars; the Ottomans defeated Ismail at Chaldiran in 1514.",
    "Under Shah Abbas I (reigned 1588–1629), the empire reached its height. He reformed the army with firearms, recaptured territory from the Ottomans, and made Isfahan his capital, building one of the most beautiful cities in the world around a vast central square with mosques and palaces; Persians said “Isfahan is half the world.” The Safavids were famous for silk, carpets, and miniature painting. The dynasty collapsed after an Afghan invasion in 1722."]],
  ["The Mughal Empire",[
    "In 1526, Babur, a Central Asian prince descended from Timur and Genghis Khan, defeated the Delhi Sultanate at the First Battle of Panipat and founded the Mughal Empire. His grandson Akbar (reigned 1556–1605) built a centralized administration, expanded the empire across northern India, and pursued religious tolerance toward the Hindu majority: he abolished the jizya tax on non-Muslims, married Hindu Rajput princesses, appointed Hindus to high office, and hosted debates among scholars of many religions.",
    "Mughal India was among the world's richest states, producing perhaps a quarter of global manufacturing output by some estimates, especially textiles. Shah Jahan (reigned 1628–1658) built the Taj Mahal in Agra as a tomb for his wife Mumtaz Mahal. His son Aurangzeb (reigned 1658–1707) expanded the empire to its greatest extent but reimposed the jizya and pursued policies that alienated many Hindus, Sikhs, and others. After his death, the empire fragmented as regional powers such as the Marathas rose, opening the way for the British East India Company."]],
  ["Strengths and limits",[
    "The gunpowder empires were wealthy, sophisticated, and powerful, rivaling or exceeding European states in the 16th and 17th centuries. They patronized spectacular art and architecture and governed diverse populations for centuries.",
    "Over time, they faced challenges: succession struggles, the cost of large armies and courts, the shift of world trade to oceanic routes controlled by Europeans, and, by the 18th century, falling behind Europe in military technology and economic change. Historians debate how inevitable their decline was; many now emphasize their adaptability and stress that European dominance arrived relatively late."]]
  ],
  terms:[["Gunpowder empires","The Ottoman, Safavid, and Mughal empires."],["Suleiman the Magnificent","Ottoman sultan at the empire's height."],["Janissaries","Elite Ottoman infantry recruited through the devshirme."],["Millet system","Ottoman self-governance for religious communities."],["Shah Abbas I","Safavid ruler who made Isfahan his capital."],["Akbar","Mughal emperor known for religious tolerance."]],
  w:"These empires shaped the modern Middle East and South Asia, including the Sunni-Shia divide, the Taj Mahal, and the diversity of Turkey, Iran, and India.",
  src:["Gunpowder empires","Ottoman Empire","Suleiman the Magnificent","Safavid Iran","Mughal Empire","Akbar"],
  q:[["Which Ottoman sultan conquered Constantinople?","Mehmed II","Suleiman","Selim I","Osman I"],
     ["What were the Janissaries?","Elite Ottoman infantry","Persian poets","Mughal tax collectors","Safavid priests"],
     ["Which empire made Twelver Shia Islam its state religion?","The Safavid","The Ottoman","The Mughal","The Abbasid"],
     ["Which city did Shah Abbas make his capital?","Isfahan","Tabriz","Tehran","Baghdad"],
     ["Which Mughal emperor abolished the jizya and promoted tolerance?","Akbar","Aurangzeb","Babur","Shah Jahan"],
     ["Who built the Taj Mahal?","Shah Jahan","Akbar","Aurangzeb","Jahangir"]]},

{ t:"Ming and Qing China and Tokugawa Japan", s:"East Asia's great early modern states",
  sec:[
  ["The Ming dynasty",[
    "After driving out the Mongols, the Ming dynasty (1368–1644) restored native Chinese rule. Its founder, the Hongwu Emperor, a former peasant and monk, rebuilt the country after war and famine. The Yongle Emperor moved the capital to Beijing and built the Forbidden City, the vast palace complex completed in 1420.",
    "From 1405 to 1433, the Ming admiral Zheng He, a Muslim eunuch, led seven enormous naval expeditions through Southeast Asia and the Indian Ocean as far as East Africa, with fleets of perhaps hundreds of ships, some far larger than any European vessel of the time. The voyages displayed Ming power and collected tribute, but the court halted them, and later Ming emperors restricted maritime trade. Historians still debate why. The Ming rebuilt the Great Wall in the stone and brick form most visitors see today."]],
  ["Ming society and economy",[
    "Ming China was the world's most populous state and a manufacturing powerhouse, producing silk and blue-and-white porcelain exported worldwide. Its economy increasingly ran on silver, much of it from Spanish America via Manila and from Japan. Novels such as Journey to the West and The Water Margin became classics.",
    "Jesuit missionaries, led by Matteo Ricci, who arrived in Beijing in 1601, introduced European science and maps to the Ming court and adapted Christianity to Chinese customs. Late in the dynasty, corruption, factional struggles, fiscal crisis, and a series of droughts and famines during the global cooling of the 17th century led to massive rebellions. In 1644, rebels captured Beijing, and the last Ming emperor hanged himself."]],
  ["The Qing dynasty",[
    "The Manchus, a people from the northeast, took advantage of the chaos, seized Beijing in 1644, and founded the Qing dynasty, which ruled China until 1912. The Manchus required Han Chinese men to wear their hair in the Manchu queue as a sign of submission but governed largely through Chinese institutions and the Confucian examination system.",
    "Under the long reigns of the Kangxi (1661–1722), Yongzheng, and Qianlong (1735–1796) emperors, the Qing reached its height, roughly doubling China's territory to include Taiwan, Mongolia, Xinjiang, and Tibet, close to the borders of modern China. The population grew to around 300 million by 1800. When the British envoy Lord Macartney sought trade concessions in 1793, Qianlong replied that China had no need of British manufactures, reflecting China's confidence but also, in hindsight, the beginning of a fateful confrontation."]],
  ["Tokugawa Japan",[
    "After unifying Japan, Tokugawa Ieyasu became shogun in 1603, establishing a government at Edo (modern Tokyo) that lasted until 1868. The Tokugawa shogunate kept the regional lords, the daimyo, under control through the system of “alternate attendance,” requiring them to spend every other year in Edo and to leave their families there as hostages.",
    "Fearing foreign influence, especially Christianity, the shogunate banned the religion, persecuted Japanese Christians, and from the 1630s adopted a policy later called sakoku (“closed country”), restricting foreign trade to the Dutch and Chinese at the port of Nagasaki and to a few other contacts. Japan was not entirely isolated, but contact was tightly controlled for more than two centuries."]],
  ["Peace and culture in Edo Japan",[
    "The Tokugawa period brought more than 250 years of peace. Society was officially divided into samurai, peasants, artisans, and merchants, with samurai becoming bureaucrats rather than warriors. Yet merchants grew wealthy, and cities such as Edo, which may have had a million people by the 18th century, Osaka, and Kyoto flourished.",
    "A lively urban culture developed, the “floating world” of kabuki theater, bunraku puppet plays, and woodblock prints, such as Hokusai's The Great Wave off Kanagawa (c. 1831). The poet Matsuo Bashō perfected the haiku. Literacy spread widely. These developments helped prepare Japan for rapid modernization after American warships forced it to open in the 1850s."]]
  ],
  terms:[["Ming dynasty","The Chinese dynasty of 1368–1644 that followed Mongol rule."],["Zheng He","Ming admiral who led seven great voyages from 1405 to 1433."],["Forbidden City","The imperial palace in Beijing completed in 1420."],["Qing dynasty","The Manchu dynasty that ruled China from 1644 to 1912."],["Tokugawa shogunate","Japan's military government from 1603 to 1868."],["Sakoku","Japan's policy of tightly restricting foreign contact."]],
  w:"Ming and Qing China and Tokugawa Japan were stable, prosperous societies whose choices about trade and contact shaped their encounters with the West in the 19th century.",
  src:["Ming dynasty","Zheng He","Qing dynasty","Qianlong Emperor","Tokugawa shogunate","Sakoku"],
  q:[["Which Ming emperor built the Forbidden City?","The Yongle Emperor","The Hongwu Emperor","The Kangxi Emperor","The Qianlong Emperor"],
     ["Who led seven great Ming naval expeditions?","Zheng He","Matteo Ricci","Kublai Khan","Koxinga"],
     ["Which people founded the Qing dynasty?","The Manchus","The Mongols","The Han","The Jurchens of Korea"],
     ["Which British envoy sought trade concessions from Qianlong in 1793?","Lord Macartney","Lord Elgin","Lord Palmerston","Lord Amherst"],
     ["Which port remained open to Dutch traders under Tokugawa rule?","Nagasaki","Edo","Osaka","Kyoto"],
     ["Who created The Great Wave off Kanagawa?","Hokusai","Hiroshige","Bashō","Utamaro"]]},

{ t:"Absolutism and the English Revolutions", s:"Kings, parliaments, and the struggle over sovereignty",
  sec:[
  ["Absolute monarchy",[
    "In the 17th century, many European monarchs sought to concentrate power in their own hands, a system called absolutism. Absolute monarchs claimed to rule by divine right, answerable only to God, built large standing armies and bureaucracies, and reduced the power of nobles and representative assemblies. Political thinkers such as Jean Bodin and Thomas Hobbes argued that order required an undivided sovereign power."]],
  ["Louis XIV",[
    "The model absolute monarch was Louis XIV of France, who reigned for 72 years (1643–1715), the longest reign of any European monarch. Called the “Sun King,” he is famously but probably apocryphally credited with saying “L'état, c'est moi” (“I am the state”). He built the enormous palace of Versailles and required nobles to live at court, where they competed for his favor in elaborate rituals rather than plotting rebellion.",
    "Louis' finance minister Jean-Baptiste Colbert promoted mercantilist policies, manufacturing, and the navy. Louis revoked the Edict of Nantes in 1685, driving hundreds of thousands of Huguenots into exile. His many wars, including the War of the Spanish Succession (1701–1714), expanded French territory but left the state deeply in debt, a burden that contributed to the French Revolution decades later."]],
  ["Other absolutisms",[
    "In Russia, Peter the Great (reigned 1682–1725) forced rapid Westernization: he traveled incognito in Western Europe to study shipbuilding, built a navy, reformed the army and government, required nobles to shave their beards, and founded a new capital, St. Petersburg, as a “window on Europe.” He defeated Sweden in the Great Northern War. Catherine the Great (reigned 1762–1796) expanded Russia further and corresponded with Enlightenment thinkers while strengthening serfdom.",
    "In Central Europe, the Habsburgs ruled Austria and a diverse empire, and the Hohenzollerns built Prussia into a military power. Frederick the Great of Prussia (reigned 1740–1786) was an “enlightened despot” who promoted religious toleration and legal reform while waging aggressive wars. Maria Theresa held the Habsburg lands together after a war over her succession."]],
  ["The English Civil War",[
    "England took a different path. The Stuart kings, James I and Charles I, believed in divine right and clashed with Parliament, which controlled taxation, and with Puritans who wanted further religious reform. Charles I ruled without Parliament for eleven years, raising money through questionable means. When rebellion in Scotland forced him to recall Parliament in 1640, conflict erupted into the English Civil War (1642–1651) between Royalists (“Cavaliers”) and Parliamentarians (“Roundheads”).",
    "Parliament's New Model Army, led by Oliver Cromwell, won. In 1649, Charles I was tried and beheaded, an unprecedented act. England became a republic, the Commonwealth, and from 1653 Cromwell ruled as Lord Protector, increasingly like a military dictator. During these years, radical groups such as the Levellers called for broad male suffrage and equality before the law, and Hobbes wrote Leviathan."]],
  ["Restoration and the Glorious Revolution",[
    "After Cromwell's death, the monarchy was restored in 1660 under Charles II. In 1679, Parliament passed the Habeas Corpus Act, strengthening protection against arbitrary imprisonment. When Charles' Catholic brother James II tried to expand royal power and favor Catholics, leading Protestants invited the Dutch prince William of Orange, married to James' Protestant daughter Mary, to intervene. In 1688, William landed with an army, James fled, and Parliament offered the throne to William and Mary jointly, the Glorious Revolution, largely bloodless in England though not in Ireland and Scotland.",
    "The English Bill of Rights (1689) established that the monarch could not suspend laws, levy taxes, or maintain a standing army in peacetime without Parliament's consent; guaranteed free elections and freedom of speech in Parliament; and banned cruel and unusual punishments. England became a constitutional monarchy, and John Locke's Two Treatises justified the revolution. These developments directly influenced the American colonists, who later claimed the rights of Englishmen, and the U.S. Bill of Rights."]]
  ],
  terms:[["Absolutism","A system in which a monarch holds concentrated, unchecked power."],["Divine right of kings","The claim that monarchs answer only to God."],["Versailles","Louis XIV's palace, a symbol of absolutism."],["English Civil War","The 1642–1651 conflict between king and Parliament."],["Glorious Revolution","The 1688 replacement of James II by William and Mary."],["English Bill of Rights","The 1689 act limiting royal power and protecting Parliament's rights."]],
  w:"The contest between absolute monarchy and parliamentary government shaped modern constitutions, including the American one, and the very idea of limited government.",
  src:["Absolute monarchy","Louis XIV","Peter the Great","English Civil War","Glorious Revolution","Bill of Rights 1689"],
  q:[["Which French king built Versailles?","Louis XIV","Louis XVI","Henry IV","Louis XIII"],
     ["Which Russian tsar founded St. Petersburg?","Peter the Great","Ivan the Terrible","Catherine the Great","Alexander I"],
     ["Who led Parliament's New Model Army?","Oliver Cromwell","Charles I","John Pym","Thomas Fairfax alone"],
     ["In what year was Charles I executed?","1649","1642","1660","1688"],
     ["Who took the English throne in the Glorious Revolution?","William and Mary","Charles II","James II","Anne"],
     ["Which 1689 act limited royal power in England?","The Bill of Rights","Magna Carta","The Act of Supremacy","The Habeas Corpus Act"]]},

{ t:"Science and Enlightenment in History", s:"New knowledge and the critique of old orders",
  sec:[
  ["A revolution in knowledge",[
    "Between about 1543 and 1687, a series of discoveries transformed European understanding of nature, a process historians call the Scientific Revolution. Copernicus proposed a sun-centered universe; Kepler showed planets move in ellipses; Galileo's telescope revealed moons around Jupiter and phases of Venus; and Isaac Newton's Principia (1687) unified the laws of motion and gravity. William Harvey demonstrated the circulation of the blood in 1628, and Andreas Vesalius corrected ancient anatomy through dissection in 1543.",
    "The Philosophy course covers the ideas of this period in depth; here the focus is its historical impact. Science gained institutions, including the Royal Society of London (1660) and the French Academy of Sciences (1666), and its own methods of experiment, publication, and peer criticism. The conflict between Galileo and the Catholic Church in 1633 became a lasting symbol, though historians note that many scientists of the era were devoutly religious."]],
  ["The Enlightenment",[
    "In the 18th century, the Enlightenment applied the confidence of the new science to society, government, religion, and economics. Thinkers believed that reason could reveal natural laws governing human affairs and that institutions should be judged by reason and human welfare rather than tradition or authority. Paris salons, often hosted by women such as Madame Geoffrin, coffeehouses, academies, and a booming print culture spread these ideas among educated Europeans and colonists.",
    "Key figures included Voltaire, who campaigned against religious intolerance; Montesquieu, who analyzed separation of powers; Rousseau, who theorized popular sovereignty; Diderot, who edited the Encyclopédie; Adam Smith, who founded modern economics; and Kant, who defined enlightenment as daring to think for oneself."]],
  ["Enlightened reform",[
    "Enlightenment ideas inspired reforms. Cesare Beccaria's On Crimes and Punishments (1764) led several states to restrict torture and capital punishment. Some monarchs, the “enlightened despots,” such as Frederick the Great of Prussia, Catherine the Great of Russia, and Joseph II of Austria, adopted reforms in law, education, and religious toleration, though they kept absolute power and often abandoned reforms that threatened it.",
    "Enlightenment thinkers increasingly criticized slavery, and in the late 18th century organized abolitionist movements emerged, especially among British Quakers and evangelicals; the Society for Effecting the Abolition of the Slave Trade was founded in London in 1787. Yet many Enlightenment figures also promoted theories of racial hierarchy or excluded women from equal rights, contradictions their critics exposed."]],
  ["From ideas to revolutions",[
    "Enlightenment ideas of natural rights, popular sovereignty, and government by consent provided the language for the revolutions that ended the early modern era. The American Declaration of Independence (1776) drew on Locke; the U.S. Constitution drew on Montesquieu; the French Declaration of the Rights of Man and of the Citizen (1789) proclaimed universal rights.",
    "These ideas spread beyond Europe and its colonies. Enslaved people in Saint-Domingue invoked the rights of man in their revolution, and Latin American independence leaders read Enlightenment authors. The next unit traces this Age of Revolutions."]]
  ],
  terms:[["Scientific Revolution","The transformation of natural knowledge from about 1543 to 1687."],["Royal Society","London's scientific society, founded in 1660."],["Salon","A gathering, often hosted by women, for discussing ideas."],["Enlightened despot","An absolute monarch who adopted Enlightenment-inspired reforms."],["Abolitionism","The movement to end the slave trade and slavery."],["Natural rights","Rights held by all people by nature, central to Enlightenment politics."]],
  w:"The Scientific Revolution and the Enlightenment created the intellectual foundations of modern science, human rights, and democratic revolution.",
  src:["Scientific Revolution","Age of Enlightenment","Salon (gathering)","Enlightened absolutism","Abolitionism in the United Kingdom","Natural rights and legal rights"],
  q:[["Which book by Newton, published in 1687, unified motion and gravity?","Principia","Opticks","De Revolutionibus","Dialogue"],
     ["Who demonstrated the circulation of the blood in 1628?","William Harvey","Andreas Vesalius","Galen","Robert Hooke"],
     ["Which Enlightenment gatherings were often hosted by women in Paris?","Salons","Guilds","Lodges","Diets"],
     ["Which monarch is an example of an enlightened despot?","Frederick the Great","Louis XIV","Charles I","Philip II"],
     ["In what year was the London society to abolish the slave trade founded?","1787","1807","1833","1760"],
     ["Which 1789 French document proclaimed universal rights?","The Declaration of the Rights of Man and of the Citizen","The Social Contract","The Napoleonic Code","The Tennis Court Oath"]]}
);


/* ---- from hist-08.js ---- */
/* HISTORY FOUNDATIONS, part 8: Unit 5 (The Age of Revolutions) */
COURSES.history.units.push({ t:"The Age of Revolutions", ch:[

{ t:"The French Revolution", s:"Liberty, equality, fraternity, and terror, 1789–1799",
  sec:[
  ["Causes",[
    "By the 1780s, France was the most populous and powerful state in Western Europe, but its government was nearly bankrupt, partly from wars, including its expensive support of the American Revolution. Society was divided into three estates: the clergy (First Estate), the nobility (Second Estate), and everyone else, about 97 percent of the population (Third Estate). The first two estates enjoyed privileges, including exemptions from many taxes, while peasants bore heavy burdens and a growing middle class, the bourgeoisie, resented its exclusion from power.",
    "Enlightenment ideas had spread widely, and the American example showed that a people could overthrow a monarchy. Poor harvests in 1788 drove bread prices to crisis levels. To raise taxes, King Louis XVI summoned the Estates-General in 1789, a body that had not met since 1614."]],
  ["1789",[
    "When the Estates-General met at Versailles in May 1789, the Third Estate demanded voting by head rather than by estate. Locked out of their meeting hall, its deputies gathered at an indoor tennis court on June 20 and swore the Tennis Court Oath not to separate until they had written a constitution, declaring themselves the National Assembly.",
    "When the king appeared to be massing troops, Parisian crowds stormed the Bastille, a royal fortress and prison, on July 14, 1789, now France's national holiday. In the countryside, the “Great Fear” led peasants to attack manor houses. On August 4, the Assembly abolished feudal privileges, and on August 26 it adopted the Declaration of the Rights of Man and of the Citizen, proclaiming that “men are born and remain free and equal in rights,” sovereignty resides in the nation, and liberty, property, and resistance to oppression are natural rights. In October, a crowd of women marched to Versailles and forced the royal family to move to Paris."]],
  ["From constitutional monarchy to republic",[
    "The Assembly reorganized France: it nationalized church lands, made clergy state employees (the Civil Constitution of the Clergy, which divided Catholics), created departments, and wrote a constitution establishing a limited monarchy (1791). Olympe de Gouges responded to the Declaration with a Declaration of the Rights of Woman (1791), arguing that women deserved equal rights; she was later executed.",
    "In June 1791, the royal family tried to flee and was caught at Varennes, destroying trust in the king. In 1792, France went to war with Austria and Prussia, which threatened to restore Louis' power. Radicalized Parisians stormed the Tuileries palace, the monarchy was abolished, and France became a republic in September 1792. Louis XVI was tried for treason and guillotined in January 1793; Queen Marie Antoinette followed in October."]],
  ["The Terror",[
    "Facing foreign war, civil war in the Vendée region, and economic crisis, the radical Jacobins, led by Maximilien Robespierre, dominated the Committee of Public Safety. During the Reign of Terror (1793–1794), revolutionary tribunals sentenced suspected enemies to death; about 17,000 people were officially executed, many by guillotine, and many more died in prison or in the brutal suppression of revolts.",
    "The Republic also pursued radical change: it abolished slavery in the colonies in 1794, introduced the metric system, adopted a new calendar starting from Year I, and attempted to replace Christianity with civic cults. Mass conscription, the levée en masse, created huge citizen armies that turned the tide of war. In July 1794 (Thermidor), Robespierre's fellow revolutionaries, fearing for their own lives, overthrew and executed him."]],
  ["The Directory and the legacy",[
    "A more conservative government, the Directory (1795–1799), followed, weak and corrupt. In November 1799, the popular general Napoleon Bonaparte seized power in a coup.",
    "The French Revolution transformed politics everywhere. It popularized the ideas of national sovereignty, citizenship, equality before the law, and human rights. Its seating arrangements gave us the terms “left” and “right”: radicals sat on the left of the Assembly, conservatives on the right. It also showed how revolutions can turn violent and authoritarian, a lesson drawn by critics such as Edmund Burke, whose Reflections on the Revolution in France (1790) founded modern conservatism, while defenders such as Thomas Paine, in Rights of Man (1791), championed its principles."]]
  ],
  terms:[["Three estates","Clergy, nobility, and commoners in pre-revolutionary France."],["Tennis Court Oath","The Third Estate's 1789 pledge to write a constitution."],["Storming of the Bastille","The July 14, 1789 assault, now France's national holiday."],["Declaration of the Rights of Man","The 1789 statement of universal rights."],["Reign of Terror","The 1793–1794 period of mass executions under the Jacobins."],["Left and right","Political terms derived from seating in the revolutionary assemblies."]],
  w:"The French Revolution spread ideas of rights, citizenship, and nationhood, and its trajectory from liberty to terror remains a defining lesson of modern politics.",
  src:["French Revolution","Estates of the realm","Storming of the Bastille","Declaration of the Rights of Man and of the Citizen","Reign of Terror","Reflections on the Revolution in France"],
  q:[["Who belonged to the Third Estate?","Everyone except clergy and nobles","The nobility","The clergy","The royal family"],
     ["On what date was the Bastille stormed?","July 14, 1789","August 4, 1789","January 21, 1793","June 20, 1789"],
     ["Who wrote the Declaration of the Rights of Woman?","Olympe de Gouges","Marie Antoinette","Mary Wollstonecraft","Madame Roland"],
     ["Which Jacobin leader dominated the Reign of Terror?","Maximilien Robespierre","Georges Danton","Napoleon","Lafayette"],
     ["Whose Reflections on the Revolution in France founded modern conservatism?","Edmund Burke","Thomas Paine","Joseph de Maistre","Alexis de Tocqueville"],
     ["Where were the royal family caught trying to flee in 1791?","Varennes","Versailles","Calais","Marseille"]]},

{ t:"Napoleon", s:"Emperor, lawgiver, and conqueror, 1799–1815",
  sec:[
  ["Rise to power",[
    "Napoleon Bonaparte was born in 1769 on Corsica, shortly after France acquired the island. A brilliant artillery officer, he rose rapidly during the Revolution, won fame for victories in Italy in 1796–1797, and led an expedition to Egypt (1798–1801), during which French scholars documented ancient Egypt and soldiers found the Rosetta Stone.",
    "In 1799, Napoleon seized power in a coup and became First Consul. He confirmed his rule through plebiscites and in 1804 crowned himself Emperor of the French in Notre-Dame Cathedral, taking the crown from the pope's hands. He presented himself as the heir of the Revolution, preserving equality before the law and careers open to talent, while ending political liberty, censoring the press, and building a police state."]],
  ["The Napoleonic Code and reforms",[
    "Napoleon's most enduring achievement was the Civil Code of 1804, known as the Napoleonic Code. It established equality of male citizens before the law, secular authority, freedom of religion, the right to property, and the abolition of feudal privileges, in clear, uniform rules. It also reinforced the authority of husbands and fathers over women and children. The code spread with French conquests and influenced legal systems across Europe, Latin America, Louisiana, and beyond.",
    "Napoleon also centralized administration through prefects, founded the Bank of France, created elite secondary schools (lycées), and reached the Concordat of 1801 with the pope, restoring the Catholic Church's position while keeping it under state control. In 1802 he reinstated slavery in French colonies, and his attempt to reconquer Saint-Domingue failed."]],
  ["Conquest of Europe",[
    "Napoleon's armies dominated Europe. His victory at Austerlitz in 1805 over Austria and Russia is considered his masterpiece. He dissolved the thousand-year-old Holy Roman Empire in 1806, crushed Prussia at Jena, and reorganized much of Europe into French-dominated states ruled by his relatives and allies. But the British navy, under Admiral Horatio Nelson, destroyed the French and Spanish fleets at Trafalgar in 1805, ending any hope of invading Britain.",
    "Napoleon tried to defeat Britain economically through the Continental System, a blockade forbidding European trade with Britain, which hurt Europe's economies and encouraged smuggling. In 1803, needing money and having failed in Haiti, he sold the vast Louisiana territory to the United States, doubling its size."]],
  ["Downfall",[
    "Resistance grew. In Spain, after Napoleon installed his brother as king in 1808, a brutal guerrilla war (a Spanish word meaning “little war”) tied down French troops, aided by a British army under the Duke of Wellington. In 1812, Napoleon invaded Russia with an army of around 600,000 men. The Russians retreated, burning the land; Napoleon took Moscow, but the city burned and the tsar refused to negotiate. In the retreat through the Russian winter, the Grande Armée was destroyed; only a small fraction returned.",
    "A coalition defeated Napoleon at Leipzig in 1813, and he abdicated in 1814 and was exiled to the island of Elba. In 1815 he escaped, returned to France, and ruled for the “Hundred Days” before his final defeat by Wellington and the Prussian general Blücher at Waterloo in Belgium in June 1815. He was exiled to the remote island of Saint Helena in the South Atlantic, where he died in 1821."]],
  ["The Congress of Vienna and the legacy",[
    "At the Congress of Vienna (1814–1815), the victorious powers, led by Austria's Prince Metternich, redrew Europe's map, restored many monarchs, and created a balance of power to prevent any single state from dominating. The resulting “Concert of Europe” helped prevent a general European war for nearly a century, until 1914, though smaller wars occurred.",
    "Napoleon's legacy is mixed. He spread revolutionary reforms, legal equality, and the Napoleonic Code across Europe, and stimulated nationalism, both among French people and among peoples who resisted him, such as Germans and Spaniards. He was also an authoritarian ruler whose wars killed millions. He remains one of history's most studied and debated figures."]]
  ],
  terms:[["Napoleonic Code","The 1804 French civil code of uniform, secular law."],["Austerlitz","Napoleon's 1805 victory over Austria and Russia."],["Trafalgar","Nelson's 1805 naval victory securing British sea power."],["Continental System","Napoleon's blockade of trade with Britain."],["Waterloo","Napoleon's final defeat in 1815."],["Congress of Vienna","The 1814–1815 conference that restored European order."]],
  w:"Napoleon spread revolutionary law and nationalism across Europe, and the settlement after his fall shaped international politics for a century.",
  src:["Napoleon","Napoleonic Code","Battle of Austerlitz","French invasion of Russia","Battle of Waterloo","Congress of Vienna"],
  q:[["On which island was Napoleon born?","Corsica","Elba","Saint Helena","Sardinia"],
     ["What did Napoleon issue in 1804?","The Civil Code","The Declaration of Rights","The Concordat","The Continental System"],
     ["Which 1805 battle destroyed the French fleet?","Trafalgar","Austerlitz","Jena","Waterloo"],
     ["What did Napoleon sell to the United States in 1803?","Louisiana","Florida","Haiti","Quebec"],
     ["Where was Napoleon finally defeated in 1815?","Waterloo","Leipzig","Moscow","Austerlitz"],
     ["Who led the Congress of Vienna?","Prince Metternich","Talleyrand","Wellington","Tsar Alexander I alone"]]},

{ t:"Revolutions in Haiti and Latin America", s:"The first Black republic and the end of Iberian empires",
  sec:[
  ["Saint-Domingue",[
    "In the 1780s, the French colony of Saint-Domingue, on the western part of Hispaniola, was the world's richest colony, producing a large share of the world's sugar and coffee. Its wealth rested on the labor of about half a million enslaved Africans, who vastly outnumbered the white colonists and free people of color, and endured some of the harshest conditions in the Americas.",
    "The French Revolution's declarations of liberty and equality inspired free people of color to demand rights. In August 1791, enslaved people in the northern plain launched a massive, coordinated uprising, traditionally said to have begun after a Vodou ceremony at Bois Caïman, burning plantations and killing enslavers."]],
  ["Toussaint Louverture",[
    "Toussaint Louverture, a formerly enslaved, literate coachman, emerged as the revolution's leading military and political figure. Shifting alliances among Spain, Britain, and France, he built a disciplined army. In 1793 the French commissioners in the colony abolished slavery, and France confirmed abolition throughout its empire in 1794. Toussaint allied with France, defeated Spanish and British forces, and by 1801 controlled the whole island, issuing a constitution that made him governor for life while affirming the end of slavery.",
    "In 1802, Napoleon sent a large army under his brother-in-law Charles Leclerc to restore French control and, as it became clear, slavery. Toussaint was tricked into negotiations, arrested, and deported to France, where he died in a prison in the Jura Mountains in 1803."]],
  ["Independence",[
    "Resistance continued under Jean-Jacques Dessalines. Yellow fever devastated the French army, and Haitian forces defeated it at the Battle of Vertières in November 1803. On January 1, 1804, Dessalines declared independence, naming the country Haiti, from an Indigenous Taíno name for the island. Haiti became the first independent nation in Latin America and the Caribbean, the second independent republic in the Americas after the United States, and the first state founded after a successful revolt by enslaved people.",
    "Haiti's success terrified slaveholding societies. The United States refused to recognize it until 1862. In 1825, under threat of naval force, France demanded an indemnity of 150 million francs, later reduced to 90 million, to compensate former enslavers in exchange for recognition. Haiti paid it, with interest, for many decades, a burden that historians link to its long-term poverty."]],
  ["Latin American independence",[
    "In Spanish America, Creoles, people of Spanish descent born in the Americas, resented the privileges of Spanish-born officials, trade restrictions, and taxes. When Napoleon invaded Spain in 1808 and deposed its king, colonial elites began governing themselves, and movements for independence followed.",
    "In northern South America, Simón Bolívar, “the Liberator,” led campaigns that freed Venezuela, Colombia, Ecuador, Peru, and Bolivia, which is named after him. In the south, José de San Martín liberated Argentina and Chile, crossing the Andes in 1817, and helped free Peru. In Mexico, the priest Miguel Hidalgo launched a revolt in 1810 with his famous “Grito de Dolores”; he was executed, but independence came in 1821. By 1826, nearly all of Spain's mainland American colonies were independent. Brazil took a different path: the Portuguese royal family had fled there in 1808, and in 1822 the king's son declared Brazil an independent empire with himself as emperor."]],
  ["Aftermath",[
    "Bolívar dreamed of a united Spanish America, but the region fragmented into many states, often ruled by military strongmen called caudillos. Independence ended Spanish rule but did not transform social hierarchies; Creole elites held power, Indigenous and mixed-race people remained largely excluded, and slavery persisted in some countries for decades.",
    "In 1823, the United States issued the Monroe Doctrine, warning European powers against further colonization or intervention in the Western Hemisphere. Britain, whose navy could enforce it and whose merchants wanted access to Latin American markets, supported the principle. The revolutions in Haiti and Latin America showed that the Age of Revolutions was a hemispheric, not just European and North American, phenomenon."]]
  ],
  terms:[["Saint-Domingue","The French colony that became Haiti."],["Toussaint Louverture","The leading figure of the Haitian Revolution."],["Haitian independence","Declared January 1, 1804, by Jean-Jacques Dessalines."],["Creoles","People of European descent born in the Americas."],["Simón Bolívar","The Liberator of much of northern South America."],["Monroe Doctrine","The 1823 U.S. warning against European intervention in the Americas."]],
  w:"The Haitian Revolution was the only successful slave revolution to found a nation, and Latin American independence created the modern map of the Americas.",
  src:["Haitian Revolution","Toussaint Louverture","Jean-Jacques Dessalines","Simón Bolívar","Latin American wars of independence","Monroe Doctrine"],
  q:[["In what year did the enslaved uprising in Saint-Domingue begin?","1791","1776","1804","1810"],
     ["Who was the leading figure of the Haitian Revolution until his capture?","Toussaint Louverture","Simón Bolívar","Jean-Jacques Dessalines","Henri Christophe"],
     ["Who declared Haitian independence on January 1, 1804?","Jean-Jacques Dessalines","Toussaint Louverture","Napoleon","Alexandre Pétion"],
     ["Which country is named after Simón Bolívar?","Bolivia","Venezuela","Colombia","Ecuador"],
     ["Who launched Mexico's independence revolt with the Grito de Dolores?","Miguel Hidalgo","Agustín de Iturbide","Benito Juárez","José Morelos"],
     ["How did Brazil become independent?","The Portuguese king's son declared it an empire","A slave revolt","A war led by Bolívar","A U.S. intervention"]]},

{ t:"The Industrial Revolution", s:"Machines, factories, and a new world of work",
  sec:[
  ["Why Britain?",[
    "The Industrial Revolution, the shift from hand production to machines and factories powered by water and steam, began in Britain around 1760. Historians point to many factors: abundant coal and iron; a large colonial empire and overseas trade providing markets and raw materials such as cotton; an agricultural revolution that increased food production and freed labor; a stable government that protected property and patents; banks and investors; navigable rivers and canals; high wages that encouraged labor-saving machines; and a culture of practical tinkering and scientific societies.",
    "Historians such as Kenneth Pomeranz have argued that before 1800, parts of China were about as economically advanced as Britain, and that Britain's “great divergence” owed much to accessible coal and colonial resources."]],
  ["Textiles and steam",[
    "The revolution began in cotton textiles. Inventions such as John Kay's flying shuttle (1733), James Hargreaves' spinning jenny (c. 1764), Richard Arkwright's water frame (1769), and Samuel Crompton's spinning mule (1779) multiplied output. Arkwright's mills at Cromford are often considered the first modern factories. In the United States, Eli Whitney's cotton gin (1793) made cotton far more profitable, which greatly expanded slavery in the American South.",
    "James Watt's improved steam engine, patented in 1769 and developed with Matthew Boulton, made steam power efficient enough to drive factories, freeing them from rivers. Steam then transformed transport: George Stephenson's Rocket won a famous competition in 1829, and the Liverpool and Manchester Railway, opened in 1830, was the first intercity railway with steam locomotives. Steamships crossed oceans, and by mid-century railways and telegraph lines were knitting together national economies."]],
  ["Life in the industrial city",[
    "Industrialization drew millions from the countryside into rapidly growing cities such as Manchester, which became a symbol of the new age. Workers, including women and children, labored long hours, often 12 to 16 hours a day, in dangerous factories and mines. Cities were crowded, polluted, and disease-ridden; cholera epidemics struck repeatedly. Charles Dickens depicted these conditions in novels such as Hard Times (1854), and Friedrich Engels documented them in The Condition of the Working Class in England (1845).",
    "Some workers resisted machines. The Luddites (1811–1816) smashed textile machinery that threatened their livelihoods; their name now describes anyone opposed to new technology. Workers formed trade unions, which were initially illegal in Britain, and mass movements such as Chartism (1838–1857) demanded voting rights for working men."]],
  ["Reform",[
    "Over the 19th century, governments responded with reforms. British Factory Acts, beginning in 1833, limited child labor and working hours. Public health acts built sewers and clean water systems after investigators such as John Snow showed in 1854 that cholera spread through contaminated water. Reform Acts in 1832, 1867, and 1884 gradually extended the vote. Unions gained legal recognition.",
    "Over the long run, industrialization raised living standards dramatically. Real wages in Britain began rising substantially after about the 1840s, and life expectancy increased in the later 19th century. Economic historians still debate how much ordinary workers benefited in the first decades, a debate known as the “standard of living” controversy."]],
  ["The Second Industrial Revolution and its spread",[
    "From around 1870, a Second Industrial Revolution brought steel (made cheaply by the Bessemer process), chemicals, electricity, the internal combustion engine, the telephone, and mass production. Germany and the United States overtook Britain in many industries. Thomas Edison's laboratory, Alexander Graham Bell's telephone (1876), and later Henry Ford's assembly line (1913) symbolized the new era.",
    "Industrialization spread to Belgium, France, Germany, the United States, Russia, and Japan. It transformed warfare, imperialism, the environment, and the global economy, giving industrialized nations enormous power over others, and it began the large-scale burning of fossil fuels that drives modern climate change. Few developments since the Neolithic Revolution have changed human life as profoundly."]]
  ],
  terms:[["Industrial Revolution","The shift to machine production and factories beginning in Britain around 1760."],["Steam engine","The power source, improved by Watt, that drove factories and railways."],["Factory system","Concentrating workers and machines in one place."],["Luddites","Workers who smashed machinery in 1811–1816."],["Chartism","A British movement demanding voting rights for working men."],["Second Industrial Revolution","The era of steel, electricity, and chemicals from about 1870."]],
  w:"The Industrial Revolution created the modern economy, cities, working class, and environmental challenges, the basis of the world we live in.",
  src:["Industrial Revolution","Watt steam engine","Liverpool and Manchester Railway","Luddite","Chartism","Second Industrial Revolution"],
  q:[["Around when did the Industrial Revolution begin in Britain?","1760","1650","1850","1900"],
     ["Who improved the steam engine with Matthew Boulton?","James Watt","George Stephenson","Richard Arkwright","Thomas Newcomen"],
     ["Which invention expanded slavery in the American South?","The cotton gin","The spinning jenny","The steam engine","The telegraph"],
     ["Who were the Luddites?","Workers who smashed textile machines","Factory owners","Railway engineers","Chartist leaders"],
     ["Who showed that cholera spread through contaminated water?","John Snow","Louis Pasteur","Edwin Chadwick","Florence Nightingale"],
     ["Which steelmaking process made steel cheap?","The Bessemer process","The Watt process","The Haber process","The Ford process"]]},

{ t:"Ideologies, Reform, and 1848", s:"Liberalism, conservatism, nationalism, and socialism",
  sec:[
  ["The great ideologies",[
    "The French and Industrial Revolutions produced the main political ideologies of the modern world. Conservatism, inspired by Edmund Burke and practiced by Metternich, valued tradition, established institutions, monarchy, religion, and gradual change, and feared revolution. Liberalism, drawing on Locke, Smith, and the Enlightenment, championed individual rights, constitutional government, free speech, free markets, and the rule of law; early liberals often favored voting rights only for property owners.",
    "Nationalism held that people sharing a language, culture, and history form a nation that deserves its own state. It inspired movements to unify divided peoples, such as Germans and Italians, and to free peoples under foreign rule, such as Greeks, Poles, and Hungarians. Socialism, responding to industrial inequality, called for collective or public ownership of the means of production to benefit workers; early “utopian” socialists such as Robert Owen built model communities, while Karl Marx developed a revolutionary theory."]],
  ["Revolts after 1815",[
    "The conservative order established at Vienna faced repeated challenges. Greece won independence from the Ottoman Empire after a war (1821–1829) that attracted romantic European supporters, including the poet Lord Byron, who died there. In France, the July Revolution of 1830 replaced the restored Bourbon king with the more liberal Louis-Philippe. Belgium won independence from the Netherlands in 1830. Polish revolts against Russian rule were crushed."]],
  ["The revolutions of 1848",[
    "In 1848, revolutions swept across Europe in what was called the “Springtime of Peoples.” Economic crisis, including the potato blight that caused the Great Famine in Ireland, and demands for liberal constitutions and national unity sparked uprisings in France, the German states, the Austrian Empire, Italy, and elsewhere. In France, the monarchy fell and the Second Republic introduced universal male suffrage. In Vienna, Metternich fled.",
    "But the revolutionaries were divided between liberals and radicals and among competing nationalities, and by 1849 conservative forces had crushed most of the revolts. In France, Napoleon's nephew Louis-Napoleon was elected president and in 1852 made himself Emperor Napoleon III. Although the 1848 revolutions largely failed in the short term, serfdom was abolished in the Austrian Empire, and their ideas of national unity and constitutional government soon reemerged."]],
  ["Reform and abolition",[
    "Some countries changed through reform rather than revolution. Britain gradually expanded voting rights and abolished slavery in most of its empire by an act of 1833. Russia's Tsar Alexander II emancipated the serfs in 1861, freeing about 23 million people, though they had to pay for land. In the United States, slavery ended only after the Civil War, with the 13th Amendment in 1865.",
    "Other reform movements flourished: campaigns for public education, temperance, prison reform, and women's rights. The Seneca Falls Convention of 1848 in New York launched the organized women's suffrage movement in the United States. In 1893, New Zealand became the first self-governing country to grant women the vote in national elections."]],
  ["Ideologies in the long run",[
    "These ideologies, and their conflicts, shaped the next two centuries. Liberalism expanded into democratic liberalism, supporting universal suffrage. Socialism split into democratic socialist and labor parties, which pursued reform through elections, and revolutionary communism. Nationalism unified nations but also fueled rivalry, imperialism, and eventually world war. Later movements such as fascism combined extreme nationalism with authoritarianism.",
    "Understanding these ideologies, their origins, assumptions, and debates, is essential for understanding modern politics, since today's parties and arguments still grow from them."]]
  ],
  terms:[["Conservatism","An ideology valuing tradition, established institutions, and gradual change."],["Liberalism","An ideology championing individual rights and constitutional government."],["Nationalism","The belief that a nation should have its own state."],["Socialism","An ideology favoring collective or public ownership to benefit workers."],["Revolutions of 1848","The wave of European revolts known as the Springtime of Peoples."],["Emancipation of the serfs","Russia's 1861 abolition of serfdom."]],
  w:"The ideologies born in this era, conservatism, liberalism, nationalism, and socialism, still define political debate around the world.",
  src:["Conservatism","Liberalism","Nationalism","Socialism","Revolutions of 1848","Emancipation reform of 1861"],
  q:[["Which ideology valued tradition and feared revolution?","Conservatism","Liberalism","Socialism","Anarchism"],
     ["Which British poet died supporting Greek independence?","Lord Byron","Percy Shelley","John Keats","William Wordsworth"],
     ["What were the 1848 revolutions called?","The Springtime of Peoples","The Glorious Revolution","The Age of Reason","The Concert of Europe"],
     ["Who made himself Emperor Napoleon III?","Louis-Napoleon","Louis-Philippe","Charles X","Napoleon's son"],
     ["Which tsar emancipated the serfs in 1861?","Alexander II","Nicholas I","Alexander III","Nicholas II"],
     ["Which country first granted women the vote in national elections in 1893?","New Zealand","The United States","Britain","Finland"]]},

{ t:"Nationalism and the Unification of Italy and Germany", s:"New nations in the heart of Europe",
  sec:[
  ["Divided peoples",[
    "In 1815, both Italy and Germany were collections of separate states. Italy was divided among the Kingdom of Piedmont-Sardinia, the Papal States, the Kingdom of the Two Sicilies, and territories controlled by Austria. Germany consisted of 39 states loosely joined in the German Confederation, dominated by Austria and Prussia. Nationalists in both regions dreamed of unity, but conservative rulers, Austria, and the papacy stood in the way."]],
  ["Italian unification",[
    "Italian nationalism, the Risorgimento (“resurgence”), had three famous leaders. Giuseppe Mazzini founded Young Italy in 1831 and inspired a democratic, republican nationalism. Count Camillo di Cavour, prime minister of Piedmont-Sardinia, was a pragmatic statesman who modernized the kingdom and used diplomacy, securing French support to defeat Austria in 1859 and annex Lombardy.",
    "Giuseppe Garibaldi, a charismatic guerrilla leader, sailed with about a thousand volunteers, the “Redshirts,” to Sicily in 1860 and conquered the Kingdom of the Two Sicilies, then handed it to King Victor Emmanuel II of Piedmont-Sardinia. In 1861 the Kingdom of Italy was proclaimed. Venice was added in 1866, and Rome in 1870, when French troops protecting the pope withdrew; Rome became the capital. The pope refused to recognize the new state, a dispute resolved only by the Lateran Treaty of 1929, which created Vatican City. Unification left deep divisions between the industrializing north and the poorer south."]],
  ["Bismarck and German unification",[
    "Germany was unified by Prussia under Otto von Bismarck, who became minister-president in 1862. A conservative Prussian aristocrat, Bismarck declared that the great questions of the day would be decided not by speeches and majority votes “but by iron and blood.” He practiced Realpolitik, pragmatic politics based on power rather than ideals.",
    "Bismarck engineered three short wars. In 1864, Prussia and Austria defeated Denmark. In 1866, Prussia crushed Austria in the Seven Weeks' War, excluding it from German affairs and forming the North German Confederation. In 1870, Bismarck provoked France into the Franco-Prussian War; the southern German states joined Prussia, and the French were defeated at Sedan, where Napoleon III was captured. On January 18, 1871, in the Hall of Mirrors at Versailles, King Wilhelm I of Prussia was proclaimed German Emperor (Kaiser). Germany annexed Alsace-Lorraine, leaving France bitter and eager for revenge."]],
  ["The new German Empire",[
    "The German Empire quickly became Europe's leading industrial and military power. Bismarck, as chancellor until 1890, built alliances to keep France isolated. At home, he fought the Catholic Church in the Kulturkampf and tried to weaken the socialists by banning their organizations while introducing the world's first national social insurance programs, for sickness (1883), accidents (1884), and old age and disability (1889), models for later welfare states.",
    "After the young Kaiser Wilhelm II dismissed Bismarck in 1890, Germany pursued a more aggressive foreign policy, building a navy to challenge Britain, which helped push Europe toward the alliances of World War I."]],
  ["Nationalism elsewhere",[
    "Nationalism also transformed other states. The Austrian Empire, home to Germans, Hungarians, Czechs, Poles, Croats, Serbs, and others, was weakened by competing nationalisms. In 1867 it reorganized as the Dual Monarchy of Austria-Hungary, giving Hungarians self-rule but frustrating Slavic peoples. In the Balkans, Serbia, Greece, Romania, and Bulgaria won independence from the Ottoman Empire during the 19th century, creating a volatile region.",
    "Nationalism could be liberal and inclusive, uniting people around shared citizenship, or exclusive and aggressive, defining nations by ethnicity and treating minorities as outsiders. In the late 19th century, a new, more radical nationalism, often combined with antisemitism and racial theories, gained ground, foreshadowing the catastrophes of the 20th century."]]
  ],
  terms:[["Risorgimento","The movement for Italian unification."],["Garibaldi","Leader of the Redshirts who conquered southern Italy in 1860."],["Realpolitik","Politics based on practical power rather than ideals."],["Bismarck","Prussian statesman who unified Germany."],["Franco-Prussian War","The 1870–1871 war that completed German unification."],["Dual Monarchy","Austria-Hungary, created in 1867."]],
  w:"The unifications of Italy and Germany redrew Europe's map and created the power rivalries and nationalism that led to the world wars.",
  src:["Italian unification","Giuseppe Garibaldi","Camillo Benso, Count of Cavour","Otto von Bismarck","Unification of Germany","Franco-Prussian War"],
  q:[["Who founded Young Italy?","Giuseppe Mazzini","Cavour","Garibaldi","Victor Emmanuel II"],
     ["Who led the Redshirts to Sicily in 1860?","Giuseppe Garibaldi","Mazzini","Cavour","Bismarck"],
     ["When did Rome become part of Italy?","1870","1861","1848","1929"],
     ["Who said great questions are decided “by iron and blood”?","Otto von Bismarck","Wilhelm II","Metternich","Cavour"],
     ["Where was the German Empire proclaimed in 1871?","The Hall of Mirrors at Versailles","Berlin","Frankfurt","Vienna"],
     ["Which country first introduced national social insurance programs?","Germany","Britain","France","The United States"]]}
]});


/* ---- from hist-09.js ---- */
/* HISTORY FOUNDATIONS, part 9: Unit 6 (Empires and the Modern World) */
COURSES.history.units.push({ t:"Empires and the Modern World, 1800–1914", ch:[

{ t:"The New Imperialism and the Scramble for Africa", s:"Europe's conquest of much of the world",
  sec:[
  ["A new wave of empire",[
    "Between about 1870 and 1914, European powers, joined by the United States and Japan, expanded their empires at an extraordinary pace, a period historians call the “New Imperialism.” By 1914, European powers and their offshoots controlled most of the world's land surface. Britain's empire alone covered about a quarter of the globe, the empire “on which the sun never sets.”",
    "Motives included economic interests, such as raw materials (rubber, cotton, minerals), markets for industrial goods, and investment opportunities; strategic rivalry among powers; nationalism and prestige; and ideologies of racial superiority and a “civilizing mission.” Social Darwinism misapplied Darwin's ideas to claim that some races were destined to dominate others. Rudyard Kipling's poem “The White Man's Burden” (1899) expressed the paternalistic justification."]],
  ["Tools of empire",[
    "New technologies made conquest possible. Steamships could travel up rivers into the interior. Quinine, derived from cinchona bark, protected Europeans against malaria, which had long limited their presence in tropical Africa. Above all, new weapons such as breech-loading rifles and the Maxim gun, an early machine gun, gave small European forces devastating advantages. At the Battle of Omdurman in Sudan in 1898, British forces killed about 10,000 Sudanese fighters while losing only a few dozen soldiers. As the writer Hilaire Belloc put it, “Whatever happens, we have got the Maxim gun, and they have not.”",
    "The telegraph allowed rapid communication with distant colonies, and railways moved troops and extracted resources. The Suez Canal, opened in 1869, shortened the route between Europe and Asia, and Britain took control of Egypt in 1882 partly to secure it."]],
  ["The Scramble for Africa",[
    "In 1870, Europeans controlled only about 10 percent of Africa, mostly along the coasts. By 1914, they controlled about 90 percent; only Ethiopia and Liberia remained independent. At the Berlin Conference (1884–1885), organized by Bismarck, European powers set rules for claiming African territory without consulting any Africans. Borders were drawn for European convenience, often cutting across ethnic and linguistic groups, a legacy that still affects African states.",
    "Britain claimed territories from Egypt to South Africa, and Cecil Rhodes dreamed of a railway “from Cape to Cairo.” France took much of West and North Africa. Germany, Italy, Portugal, Spain, and Belgium also took colonies. In South Africa, Britain fought the Boer War (1899–1902) against Dutch-descended settlers, using concentration camps in which tens of thousands of Boer and Black African civilians died."]],
  ["Atrocity and exploitation",[
    "Colonial rule was often brutal. In the Congo Free State, which King Leopold II of Belgium ruled as his personal property from 1885 to 1908, forced labor to collect wild rubber, enforced by mutilation, hostage-taking, and killing, caused a catastrophic loss of life; estimates of the death toll run into the millions. Reports by activists such as E. D. Morel and Roger Casement and photographs of mutilated workers caused an international outcry, and Belgium took over the colony in 1908.",
    "In German South West Africa (Namibia), German forces responded to an uprising of the Herero and Nama peoples in 1904 with a campaign of extermination, driving many into the desert to die and imprisoning others in camps. It is widely considered the first genocide of the 20th century, and Germany officially acknowledged it as genocide in 2021. Colonial economies were generally organized to extract resources for the colonizers, with forced labor and taxes that pushed Africans into cash-crop production or wage work."]],
  ["African resistance",[
    "Africans resisted conquest in many ways. The most dramatic victory came at Adwa in 1896, where Emperor Menelik II of Ethiopia decisively defeated an invading Italian army, preserving Ethiopian independence and becoming a symbol of African pride. Samori Touré resisted the French in West Africa for nearly two decades. The Zulu defeated a British army at Isandlwana in 1879 before being conquered. The Maji Maji rebellion (1905–1907) against German rule in Tanganyika united diverse peoples.",
    "Most armed resistance was eventually crushed, but Africans also resisted through religious movements, labor actions, and preserving their cultures, and a new class of Western-educated Africans would later lead independence movements. The colonial era in Africa lasted only about 70 to 80 years, but its effects on borders, economies, languages, and politics remain profound."]]
  ],
  terms:[["New Imperialism","The rapid expansion of empires between about 1870 and 1914."],["Social Darwinism","The misapplication of evolution to justify racial domination."],["Maxim gun","An early machine gun that gave colonial forces overwhelming firepower."],["Berlin Conference","The 1884–1885 meeting that set rules for partitioning Africa."],["Congo Free State","Leopold II's personal colony, notorious for atrocities."],["Battle of Adwa","Ethiopia's 1896 victory over Italy."]],
  w:"The New Imperialism drew many of today's borders, shaped global inequality, and set the stage for 20th-century independence movements.",
  src:["New Imperialism","Scramble for Africa","Berlin Conference","Congo Free State","Herero and Nama genocide","Battle of Adwa"],
  q:[["About what share of Africa did Europeans control by 1914?","About 90 percent","About 10 percent","About 50 percent","All of it"],
     ["Which two African states remained independent?","Ethiopia and Liberia","Egypt and Morocco","Ghana and Nigeria","Kenya and Sudan"],
     ["Who organized the Berlin Conference of 1884–1885?","Otto von Bismarck","Leopold II","Cecil Rhodes","Queen Victoria"],
     ["Which colony did Leopold II rule as personal property?","The Congo Free State","Rwanda","Namibia","Angola"],
     ["Which emperor defeated Italy at Adwa in 1896?","Menelik II","Haile Selassie","Tewodros II","Yohannes IV"],
     ["What did the Maxim gun give colonial forces?","Overwhelming firepower","Protection from malaria","Faster communication","River transport"]]},

{ t:"British India", s:"From trading company to the Raj",
  sec:[
  ["The East India Company",[
    "The English East India Company, chartered in 1600, began as a trading company competing with the Dutch and Portuguese for Asian goods. As the Mughal Empire fragmented in the 18th century, the Company exploited local rivalries. In 1757, Robert Clive defeated the Nawab of Bengal at the Battle of Plassey, aided by bribery and defections, giving the Company control of wealthy Bengal. In 1765 it gained the right to collect revenue there.",
    "A private company with its own army, largely of Indian soldiers called sepoys, thus became a territorial power. Company rule was marked by exploitation; a famine in Bengal in 1770 killed millions while revenue collection continued. Over the following decades the Company conquered or dominated most of India through wars and alliances, defeating the Marathas, Mysore under Tipu Sultan, and the Sikhs."]],
  ["The rebellion of 1857",[
    "In 1857, sepoys in the Company's army rose in revolt, sparked by rumors that new rifle cartridges were greased with cow and pig fat, offensive to Hindus and Muslims, but rooted in broader grievances: annexations of Indian states, disrespect for religious customs, economic disruption, and high taxes. The rebellion spread across northern India; rebels proclaimed the aged Mughal emperor Bahadur Shah II their leader. Both sides committed atrocities, and the British suppressed the revolt brutally by 1858.",
    "British historians long called it the “Sepoy Mutiny”; many Indians call it the First War of Independence. Its consequences were major: the British government abolished the East India Company's rule, the last Mughal emperor was exiled, and in 1858 India came under direct rule of the British Crown, the British Raj. In 1877, Queen Victoria was proclaimed Empress of India."]],
  ["The Raj",[
    "The Raj governed India through a viceroy and the elite Indian Civil Service, while about a third of the subcontinent remained under Indian princes allied to Britain. The British built railways, telegraphs, irrigation canals, universities, and a unified legal system, and English became the language of administration and of a new Indian educated class.",
    "Critics, including Indian nationalists such as Dadabhai Naoroji, argued that British rule drained India's wealth through taxes, unfavorable trade, and payments to Britain. Indian textile industries, once world leaders, suffered from competition with British factory goods. Devastating famines in the late 19th century killed millions while grain continued to be exported, and policies were shaped by laissez-faire economics and imperial priorities."]],
  ["The rise of Indian nationalism",[
    "Western education, newspapers, and railways helped create a sense of Indian national identity across regions. In 1885, educated Indians founded the Indian National Congress, which initially sought a greater Indian role in government and later demanded self-rule. Reformers such as Ram Mohan Roy, earlier in the century, had campaigned against practices such as sati, the burning of widows, which the British banned in 1829, and promoted modern education.",
    "In 1905, the British partition of Bengal, seen as an attempt to divide Hindus and Muslims, provoked mass protests and a boycott of British goods (the Swadeshi movement). The All-India Muslim League was founded in 1906. The 20th-century independence struggle, led by Mahatma Gandhi, is covered in the decolonization chapter."]],
  ["The legacy of colonial India",[
    "British rule left a complex legacy: parliamentary institutions, a civil service, a legal system, railways, and the English language, alongside economic exploitation, famines, and policies that sometimes hardened religious and caste divisions. Historians and the public in India and Britain continue to debate how to assess this history.",
    "The Raj also shaped the wider empire. Indian soldiers fought in British wars around the world, Indian laborers were taken as indentured workers to plantations in the Caribbean, Fiji, Mauritius, and South Africa, creating new diaspora communities, and the defense of India shaped British foreign policy across Asia and the Middle East."]]
  ],
  terms:[["East India Company","The English trading company that conquered much of India."],["Battle of Plassey","Clive's 1757 victory giving the Company control of Bengal."],["Sepoys","Indian soldiers in the Company's army."],["Rebellion of 1857","The uprising that ended Company rule."],["British Raj","Direct British Crown rule over India, 1858–1947."],["Indian National Congress","The nationalist organization founded in 1885."]],
  w:"British rule transformed India's economy, politics, and identity, and the struggle against it inspired anti-colonial movements worldwide.",
  src:["East India Company","Battle of Plassey","Indian Rebellion of 1857","British Raj","Indian National Congress","Partition of Bengal (1905)"],
  q:[["Who won the Battle of Plassey in 1757?","Robert Clive","Warren Hastings","Tipu Sultan","Lord Cornwallis"],
     ["What were sepoys?","Indian soldiers in the Company's army","British officials","Mughal nobles","Tax collectors"],
     ["What did the rebellion of 1857 lead to?","Direct British Crown rule","Indian independence","Mughal restoration","Company expansion"],
     ["When was Queen Victoria proclaimed Empress of India?","1877","1858","1857","1901"],
     ["When was the Indian National Congress founded?","1885","1857","1906","1947"],
     ["Which 1905 British policy sparked the Swadeshi movement?","The partition of Bengal","The salt tax","The Rowlatt Act","The Government of India Act"]]},

{ t:"China's Century of Crisis", s:"Opium Wars, rebellion, and the fall of the Qing, 1839–1912",
  sec:[
  ["Opium",[
    "In the early 19th century, Britain bought large quantities of Chinese tea, silk, and porcelain but had few goods China wanted, so silver flowed into China. British merchants found a solution: opium grown in British India and smuggled into China. Opium addiction spread, and silver began flowing out of China.",
    "In 1839, the Qing official Lin Zexu, sent to stop the trade, confiscated and destroyed more than 20,000 chests of British opium at Canton (Guangzhou). He even wrote to Queen Victoria asking how Britain could sell a drug banned in its own country. Britain responded with war."]],
  ["The Opium Wars and unequal treaties",[
    "In the First Opium War (1839–1842), British steamships and modern weapons defeated Qing forces. The Treaty of Nanjing (1842) forced China to cede Hong Kong to Britain, open five ports to British trade, pay a large indemnity, and later grant extraterritoriality, which meant British citizens in China were tried in British, not Chinese, courts. Other powers, including France and the United States, demanded similar terms. The Chinese call these the “unequal treaties.”",
    "In the Second Opium War (1856–1860), British and French forces captured Beijing and looted and burned the emperor's Summer Palace. China was forced to legalize opium, open more ports, and allow foreign envoys in Beijing. Russia gained a large territory in the northeast, including the site of Vladivostok."]],
  ["The Taiping Rebellion",[
    "The Qing faced massive internal rebellions. The largest, the Taiping Rebellion (1850–1864), was led by Hong Xiuquan, a failed civil service candidate who, after reading Christian tracts, came to believe he was the younger brother of Jesus. His Taiping Heavenly Kingdom, which promised land redistribution and equality of men and women and banned opium and footbinding, conquered much of southern China and made Nanjing its capital.",
    "The Qing, aided by regional armies led by Confucian officials such as Zeng Guofan and by Western-officered forces, finally crushed the Taiping in 1864. The rebellion and its suppression killed an estimated 20 to 30 million people, making it one of the deadliest conflicts in history."]],
  ["Self-strengthening and defeat",[
    "In response, reformers launched the Self-Strengthening Movement (c. 1861–1895), building arsenals, shipyards, and modern schools while keeping Confucian institutions, summed up in the phrase “Chinese learning as the essence, Western learning for practical use.” Real power at court lay with the Empress Dowager Cixi, who dominated the government from 1861 until her death in 1908.",
    "China's weakness was exposed when Japan, which had modernized more thoroughly, defeated it in the First Sino-Japanese War (1894–1895); China lost Taiwan and recognized Korean independence. Foreign powers then carved China into “spheres of influence.” The United States proposed the Open Door Policy (1899), calling for equal trading access for all powers. A brief reform effort in 1898, the Hundred Days' Reform, was crushed by Cixi."]],
  ["The Boxers and the 1911 Revolution",[
    "In 1899–1901, the Boxer Rebellion, led by a secret society practicing martial arts that believed it was invulnerable to bullets, attacked foreigners and Chinese Christians, besieging the foreign legations in Beijing with the court's support. An eight-nation force, including Japan, Russia, Britain, the United States, and Germany, captured Beijing and imposed another huge indemnity.",
    "Discredited, the Qing attempted late reforms, abolishing the civil service examinations in 1905. But revolutionaries led by Sun Yat-sen, who promoted his Three Principles of the People, nationalism, democracy, and people's livelihood, gained support. An uprising at Wuchang in October 1911 spread rapidly, and in February 1912 the last emperor, the child Puyi, abdicated. More than two thousand years of imperial rule ended, and China became a republic, though it soon fragmented under warlords. Chinese nationalists remember 1839 to 1949 as the “century of humiliation,” a memory that still shapes China's politics."]]
  ],
  terms:[["Opium Wars","Wars in 1839–1842 and 1856–1860 in which Britain forced opium trade on China."],["Treaty of Nanjing","The 1842 treaty ceding Hong Kong and opening ports."],["Unequal treaties","Treaties imposed on China by foreign powers."],["Taiping Rebellion","A massive 1850–1864 rebellion led by Hong Xiuquan."],["Boxer Rebellion","The 1899–1901 anti-foreign uprising."],["1911 Revolution","The revolution that ended imperial rule in China."]],
  w:"China's century of crisis explains modern Chinese nationalism and its sensitivity to foreign interference, central to understanding China today.",
  src:["First Opium War","Treaty of Nanjing","Taiping Rebellion","Empress Dowager Cixi","Boxer Rebellion","1911 Revolution"],
  q:[["Which Qing official destroyed British opium in 1839?","Lin Zexu","Zeng Guofan","Li Hongzhang","Sun Yat-sen"],
     ["Which treaty ceded Hong Kong to Britain?","The Treaty of Nanjing","The Treaty of Shimonoseki","The Treaty of Tianjin","The Treaty of Versailles"],
     ["Who led the Taiping Rebellion?","Hong Xiuquan","Sun Yat-sen","Cixi","Yuan Shikai"],
     ["Who dominated the Qing government from 1861 to 1908?","Empress Dowager Cixi","The Guangxu Emperor","Puyi","Prince Gong"],
     ["Which country defeated China in 1894–1895?","Japan","Britain","Russia","France"],
     ["Who was the last emperor of China?","Puyi","Guangxu","Tongzhi","Qianlong"]]},

{ t:"Meiji Japan", s:"From closed country to modern power",
  sec:[
  ["The opening of Japan",[
    "In 1853, U.S. Commodore Matthew Perry sailed into Edo Bay with steam-powered warships, the “black ships,” and demanded that Japan open its ports. Aware of China's defeat in the Opium Wars, the Tokugawa shogunate signed the Treaty of Kanagawa in 1854 and later unequal treaties granting foreigners trading rights and extraterritoriality.",
    "The shogunate's capitulation outraged many samurai, especially in the southwestern domains of Satsuma and Chōshū, who rallied around the emperor under the slogan “Revere the emperor, expel the barbarians.” After clashes with Western ships showed that expulsion was impossible, they turned to overthrowing the shogunate and modernizing Japan."]],
  ["The Meiji Restoration",[
    "In 1867–1868, the rebels forced the last shogun to resign and “restored” power to the young Emperor Meiji, whose reign name means “enlightened rule.” The capital moved to Edo, renamed Tokyo (“eastern capital”). In fact, a small group of former samurai oligarchs governed in the emperor's name, determined to make Japan strong enough to avoid colonization. Their slogan was “rich country, strong army.”",
    "The Charter Oath of 1868 promised that “knowledge shall be sought throughout the world.” The Iwakura Mission (1871–1873) sent leaders to study the institutions of the United States and Europe."]],
  ["Transforming society",[
    "The Meiji government carried out sweeping reforms with astonishing speed. It abolished the feudal domains and replaced them with prefectures, abolished the samurai class and its privileges, created a conscript army modeled on Germany's and a navy modeled on Britain's, established universal education, and built railways, telegraphs, and modern industry, often through state enterprises later sold to private conglomerates (zaibatsu) such as Mitsubishi and Mitsui.",
    "Some samurai resisted; the Satsuma Rebellion of 1877, led by Saigō Takamori, was crushed by the new conscript army. The Meiji Constitution of 1889, modeled partly on Prussia's, created a parliament (the Diet) with limited powers while declaring the emperor sacred and inviolable. Shinto was promoted as a state ideology centered on the emperor."]],
  ["Rise to great power",[
    "Japan quickly became an imperial power itself. It defeated China in 1894–1895, acquiring Taiwan. In 1902, it allied with Britain. In the Russo-Japanese War (1904–1905), Japan defeated Russia on land and destroyed the Russian fleet at the Battle of Tsushima, the first major modern victory of an Asian power over a European one, which electrified nationalists across Asia. President Theodore Roosevelt mediated the peace, winning the Nobel Peace Prize.",
    "Japan annexed Korea in 1910, ruling it harshly until 1945, suppressing Korean language and culture at times. By 1911, Japan had revised its unequal treaties and was recognized as a great power."]],
  ["Significance",[
    "The Meiji transformation is one of the most remarkable cases of rapid modernization in history. In about forty years, Japan went from a feudal, largely isolated country to an industrial and military power. Its success showed that modernization did not require Westernization in every respect; Japan combined Western technology and institutions with its own traditions.",
    "But the Meiji model also combined modernization with militarism, emperor worship, and imperial expansion, a combination that led toward aggression in Asia and war with the United States in the 1930s and 1940s."]]
  ],
  terms:[["Black ships","Perry's steam-powered warships that arrived in 1853."],["Treaty of Kanagawa","The 1854 treaty opening Japan to the United States."],["Meiji Restoration","The 1868 overthrow of the shogunate and restoration of imperial rule."],["Rich country, strong army","The Meiji slogan for modernization."],["Meiji Constitution","Japan's 1889 constitution."],["Russo-Japanese War","Japan's 1904–1905 victory over Russia."]],
  w:"Meiji Japan showed how a non-Western nation could rapidly modernize, and its path toward militarism shaped 20th-century Asia.",
  src:["Perry Expedition","Convention of Kanagawa","Meiji Restoration","Meiji Constitution","Russo-Japanese War","Battle of Tsushima"],
  q:[["Who led the U.S. ships that arrived in Japan in 1853?","Matthew Perry","Theodore Roosevelt","Townsend Harris","Douglas MacArthur"],
     ["What does Meiji mean?","Enlightened rule","Eastern capital","Rich country","Divine wind"],
     ["What was Edo renamed?","Tokyo","Kyoto","Osaka","Yokohama"],
     ["Who led the Satsuma Rebellion of 1877?","Saigō Takamori","Itō Hirobumi","Emperor Meiji","Ōkubo Toshimichi"],
     ["Which naval battle in 1905 destroyed the Russian fleet?","Tsushima","Midway","Port Arthur","Jutland"],
     ["Which country did Japan annex in 1910?","Korea","Taiwan","Manchuria","The Philippines"]]},

{ t:"Russia and the Ottoman Empire in the 19th Century", s:"Old empires under pressure",
  sec:[
  ["Russia's vast empire",[
    "In the 19th century, the Russian Empire stretched from Poland to the Pacific, the largest country on Earth. Its victory over Napoleon in 1812 made it a great power, and it expanded into the Caucasus and Central Asia. Yet Russia remained an autocracy, ruled by tsars with unlimited power, and most of its people were peasant serfs.",
    "In December 1825, liberal army officers, the Decembrists, staged a failed revolt demanding a constitution. Tsar Nicholas I (reigned 1825–1855) responded with repression under the motto “Orthodoxy, Autocracy, Nationality.” Russia's defeat in the Crimean War (1853–1856) against Britain, France, and the Ottomans exposed its backwardness. The war is also remembered for Florence Nightingale's nursing reforms and the disastrous Charge of the Light Brigade."]],
  ["Reform and reaction",[
    "Alexander II (reigned 1855–1881), the “Tsar Liberator,” emancipated the serfs in 1861, created elected local councils (zemstvos), reformed the courts with jury trials, and modernized the army. But reforms disappointed radicals, some of whom turned to terrorism; the revolutionary group People's Will assassinated Alexander II with a bomb in 1881.",
    "His successors, Alexander III and Nicholas II, reverted to repression, persecuted religious minorities, and encouraged pogroms, violent attacks on Jewish communities, which drove millions of Jews to emigrate, many to the United States. Meanwhile, Russia industrialized rapidly from the 1890s under Finance Minister Sergei Witte, building the Trans-Siberian Railway, completed in 1916, and creating a new industrial working class in cities."]],
  ["1905",[
    "Defeat by Japan in 1904–1905 triggered revolution. On “Bloody Sunday,” January 22, 1905, troops fired on peaceful workers marching to the Winter Palace in St. Petersburg to petition the tsar, killing many. Strikes, peasant revolts, and mutinies, including on the battleship Potemkin, spread across the empire. Workers formed councils called soviets.",
    "Nicholas II issued the October Manifesto, promising civil liberties and an elected parliament, the Duma. But he soon limited the Duma's powers, and his prime minister Pyotr Stolypin combined land reform with harsh repression. Unresolved tensions led to revolution in 1917, covered in the next unit."]],
  ["The “sick man of Europe”",[
    "The Ottoman Empire, still vast in 1800, faced military defeats, nationalist revolts, and economic dependence on European powers, leading Europeans to call it the “sick man of Europe.” Greece won independence in 1830, Egypt became effectively autonomous under Muhammad Ali, and Serbia, Romania, and Bulgaria gained independence or autonomy later in the century. European powers competed over the empire's fate, the so-called “Eastern Question.”",
    "Ottoman reformers responded with the Tanzimat (“reorganization”) reforms (1839–1876), modernizing the army, law, and administration and declaring equality of Muslim and non-Muslim subjects. In 1876, the empire adopted a constitution, but Sultan Abdul Hamid II suspended it in 1878 and ruled autocratically. In the 1890s, massacres of Armenians killed many thousands."]],
  ["The Young Turks",[
    "In 1908, the Young Turks, nationalist army officers and reformers in the Committee of Union and Progress, forced the restoration of the constitution and soon took effective control. The empire continued to lose territory, including Libya to Italy in 1911–1912 and most of its remaining European lands in the Balkan Wars of 1912–1913.",
    "Increasingly committed to Turkish nationalism, the Young Turk leadership brought the empire into World War I on Germany's side in 1914, with catastrophic consequences, including the Armenian Genocide in 1915. Both the Russian and Ottoman empires, along with Austria-Hungary and Germany, collapsed as a result of that war."]]
  ],
  terms:[["Autocracy","Rule by a single person with unlimited power, as by the tsars."],["Decembrists","Officers who staged a failed liberal revolt in 1825."],["Crimean War","The 1853–1856 war in which Russia was defeated."],["Bloody Sunday","The 1905 massacre of peaceful marchers in St. Petersburg."],["Tanzimat","Ottoman modernizing reforms of 1839–1876."],["Young Turks","Reformers and officers who took power in the Ottoman Empire after 1908."]],
  w:"The pressures on Russia and the Ottoman Empire in the 19th century set up the revolutions, wars, and new states of the 20th century, from the Soviet Union to modern Turkey.",
  src:["Russian Empire","Decembrist revolt","Crimean War","Russian Revolution of 1905","Tanzimat","Young Turks"],
  q:[["Who led the failed revolt of December 1825?","The Decembrists","The Bolsheviks","The Young Turks","People's Will"],
     ["Which war exposed Russia's backwardness in the 1850s?","The Crimean War","The Russo-Japanese War","The Napoleonic Wars","The Balkan Wars"],
     ["Which group assassinated Alexander II in 1881?","People's Will","The Decembrists","The Bolsheviks","The Black Hand"],
     ["What did Nicholas II issue after the 1905 Revolution?","The October Manifesto","The Emancipation Edict","The Tanzimat","The April Theses"],
     ["What were the Ottoman reforms of 1839–1876 called?","The Tanzimat","The Meiji","The Risorgimento","The Duma"],
     ["Which group forced restoration of the Ottoman constitution in 1908?","The Young Turks","The Janissaries","The Decembrists","The Mamluks"]]}
]});


/* ---- from hist-10.js ---- */
/* HISTORY FOUNDATIONS, part 10: Unit 7 (The United States), chapters 1-7 */
COURSES.history.units.push({ t:"The United States", ch:[

{ t:"Native America and Colonial Beginnings", s:"Before and after 1607",
  sec:[
  ["Native North America",[
    "Before European arrival, North America was home to millions of people in hundreds of nations with diverse languages, economies, and political systems. Mississippian peoples built Cahokia, near present-day St. Louis, which around 1100 CE may have held 10,000 to 20,000 people and featured Monks Mound, the largest earthwork in the Americas. Ancestral Puebloans built cliff dwellings and multistory towns in the Southwest, such as Chaco Canyon and Mesa Verde.",
    "In the Northeast, the Haudenosaunee (Iroquois) Confederacy united five, later six, nations under the Great Law of Peace, a political union that impressed some colonial observers. Native peoples farmed maize, beans, and squash (the “Three Sisters”), hunted, fished, and traded across long distances. European diseases, spreading ahead of settlers, devastated many communities before sustained contact even began."]],
  ["Spanish and French beginnings",[
    "Spain established the first permanent European settlement in what is now the United States at St. Augustine, Florida, in 1565, and colonized New Mexico, founding Santa Fe around 1610. The Pueblo Revolt of 1680, led by Popé, drove the Spanish out of New Mexico for twelve years, one of the most successful Native uprisings. France founded Quebec in 1608 and built an empire along the St. Lawrence, Great Lakes, and Mississippi based largely on the fur trade and alliances with Native nations."]],
  ["Virginia and the Chesapeake",[
    "England's first permanent colony was Jamestown, founded in 1607 by the Virginia Company. Early years were catastrophic: during the “starving time” of 1609–1610, most colonists died. Relations with the Powhatan Confederacy alternated between trade and war; the marriage of Pocahontas, the daughter of the paramount chief, to the colonist John Rolfe in 1614 brought a brief peace. Rolfe's cultivation of tobacco made the colony profitable.",
    "In 1619, two crucial events occurred: the House of Burgesses, the first elected representative assembly in English America, met, and the first documented enslaved Africans arrived in English Virginia. At first, most laborers were English indentured servants, who worked for several years in exchange for passage. After Bacon's Rebellion (1676), an uprising of poor whites and some Black servants against Virginia's government, planters increasingly turned to enslaved Africans, and Virginia's laws made slavery a hereditary, race-based status."]],
  ["New England",[
    "In 1620, the Pilgrims, religious Separatists, arrived at Plymouth on the Mayflower and signed the Mayflower Compact, an agreement to form a self-governing community, before landing. About half died in the first winter; the Wampanoag people, led by Massasoit, helped the survivors, and the 1621 harvest feast is the origin of the Thanksgiving tradition.",
    "Beginning in 1630, a much larger Puritan migration founded the Massachusetts Bay Colony. Governor John Winthrop urged colonists to build “a city upon a hill,” a model Christian community. New England developed towns, town meetings, widespread literacy, and Harvard College (1636). Religious dissenters such as Roger Williams, who founded Rhode Island on principles of religious freedom, and Anne Hutchinson were banished. Conflicts with Native peoples culminated in King Philip's War (1675–1676), one of the deadliest wars in American history relative to population."]],
  ["The middle and southern colonies",[
    "The Dutch founded New Netherland, with New Amsterdam on Manhattan, which England seized in 1664 and renamed New York. William Penn, a Quaker, founded Pennsylvania in 1681 as a “holy experiment” in religious toleration and fair dealing with Native peoples; Philadelphia became the largest colonial city. Maryland was founded in 1634 as a haven for English Catholics, and its Toleration Act of 1649 protected Christians of different denominations.",
    "The Carolinas developed plantation economies based on rice and indigo, using the labor and expertise of enslaved Africans; South Carolina had a Black majority for much of the colonial period. The Stono Rebellion of 1739 was the largest slave revolt in the British mainland colonies. Georgia, founded in 1732, was the last of the thirteen colonies."]],
  ["Colonial society",[
    "By 1750, the thirteen colonies had more than a million people. They enjoyed considerable self-government through elected assemblies, but were bound to Britain by trade laws (the Navigation Acts) and loyalty to the Crown. A religious revival in the 1730s and 1740s, the Great Awakening, led by preachers such as Jonathan Edwards and George Whitefield, created emotional, evangelical Christianity and challenged established authority.",
    "Colonists were also influenced by the Enlightenment; Benjamin Franklin, printer, scientist, and civic leader, embodied its spirit. The French and Indian War (1754–1763), part of the global Seven Years' War, ended with Britain taking Canada and lands east of the Mississippi from France, setting the stage for conflict between Britain and its colonies."]]
  ],
  terms:[["Cahokia","A major Mississippian city near present-day St. Louis."],["Haudenosaunee","The Iroquois Confederacy, united by the Great Law of Peace."],["Jamestown","The first permanent English colony, founded in 1607."],["Mayflower Compact","The Pilgrims' 1620 agreement to form a self-governing community."],["Indentured servitude","Labor for a set term in exchange for passage to the colonies."],["Great Awakening","An 18th-century evangelical religious revival."]],
  w:"The colonial era established American self-government, religious diversity, and race-based slavery, foundations and contradictions of the nation that followed.",
  src:["Cahokia","Iroquois","Jamestown, Virginia","Plymouth Colony","Bacon's Rebellion","First Great Awakening"],
  q:[["Which Mississippian city featured Monks Mound?","Cahokia","Chaco Canyon","Mesa Verde","St. Augustine"],
     ["What was the first permanent European settlement in what is now the U.S.?","St. Augustine","Jamestown","Plymouth","Santa Fe"],
     ["What two events occurred in Virginia in 1619?","The first elected assembly and the arrival of enslaved Africans","The founding of Jamestown and Plymouth","Bacon's Rebellion and the starving time","Tobacco's introduction and Pocahontas' marriage"],
     ["Who founded Pennsylvania as a holy experiment?","William Penn","Roger Williams","John Winthrop","Lord Baltimore"],
     ["Which colony was founded as a haven for English Catholics?","Maryland","Rhode Island","Pennsylvania","Georgia"],
     ["Which 1739 revolt was the largest in the British mainland colonies?","The Stono Rebellion","Bacon's Rebellion","Nat Turner's Rebellion","The Pueblo Revolt"]]},

{ t:"The American Revolution", s:"From loyal subjects to an independent nation, 1763–1783",
  sec:[
  ["The imperial crisis",[
    "After the French and Indian War, Britain faced enormous debts and the cost of defending a larger empire. It tried to tighten control and raise revenue from the colonies. The Proclamation of 1763 barred settlement west of the Appalachians to reduce conflict with Native nations, angering land-hungry colonists. The Sugar Act (1764) and especially the Stamp Act (1765), which taxed printed materials, provoked fierce opposition.",
    "Colonists argued that only their own elected assemblies could tax them: “no taxation without representation.” They organized boycotts, the Stamp Act Congress, and groups such as the Sons of Liberty. Parliament repealed the Stamp Act in 1766 but asserted its right to legislate for the colonies “in all cases whatsoever.” The Townshend Acts (1767) taxed imports such as tea and glass, sparking new boycotts."]],
  ["Toward rebellion",[
    "Tensions escalated. In the Boston Massacre of March 1770, British soldiers fired on a crowd, killing five people, including Crispus Attucks, a man of African and Native descent. John Adams, a future president, defended the soldiers in court, upholding the right to counsel. In 1773, to protest the Tea Act, colonists disguised as Mohawks dumped British East India Company tea into Boston Harbor, the Boston Tea Party.",
    "Parliament responded with the Coercive (“Intolerable”) Acts of 1774, closing Boston's port and restricting Massachusetts self-government. Colonies sent delegates to the First Continental Congress in Philadelphia. In April 1775, British troops marching to seize colonial weapons clashed with militia at Lexington and Concord, the “shot heard round the world.” The Second Continental Congress created a Continental Army and appointed George Washington commander."]],
  ["Independence",[
    "Many colonists still hoped for reconciliation, but Thomas Paine's pamphlet Common Sense (January 1776), which sold over a hundred thousand copies, argued powerfully for independence and against monarchy itself. On July 2, 1776, Congress voted for independence, and on July 4 it adopted the Declaration of Independence, drafted mainly by Thomas Jefferson.",
    "The Declaration proclaimed that “all men are created equal,” endowed with unalienable rights including “Life, Liberty and the pursuit of Happiness,” that governments derive “their just powers from the consent of the governed,” and that people may abolish governments that destroy these rights. It then listed grievances against King George III. Its universal language contrasted sharply with the reality of slavery, a contradiction noted at the time by critics and enslaved people themselves, and later invoked by abolitionists, women's rights advocates, and civil rights leaders."]],
  ["The war",[
    "The war was long and difficult. The British captured New York and Philadelphia, and Washington's army suffered through the winter at Valley Forge (1777–1778). Washington's surprise crossing of the Delaware River to attack Trenton on December 26, 1776 revived American morale. The turning point came at Saratoga in 1777, where an American victory persuaded France to enter the war as an ally in 1778, bringing money, troops, and a navy; Spain and the Netherlands later joined against Britain.",
    "About a fifth of colonists remained Loyalists, and many Native nations sided with Britain, which they saw as a check on settler expansion. Thousands of enslaved people escaped to British lines after British officials promised freedom, while about 5,000 Black soldiers served in the Continental forces. In 1781, American and French forces trapped General Cornwallis at Yorktown, Virginia, where a French fleet blocked rescue by sea; his surrender effectively ended the war. The Treaty of Paris (1783) recognized American independence with borders extending to the Mississippi."]],
  ["A revolutionary legacy",[
    "The Revolution created the first large modern republic based on Enlightenment principles. Its ideas inspired revolutions in France, Haiti, and Latin America. Several northern states began abolishing slavery, starting with Vermont (1777) and Pennsylvania's gradual abolition act (1780), and Massachusetts courts ended slavery in the 1780s.",
    "Yet the Revolution's promises were incomplete. Slavery expanded in the South, women remained largely excluded from political rights despite appeals such as Abigail Adams' request that her husband “remember the ladies,” and Native nations lost their British allies and faced accelerating dispossession. The struggle to fulfill the Declaration's ideals shaped the rest of American history."]]
  ],
  terms:[["No taxation without representation","The colonists' argument that only their own assemblies could tax them."],["Boston Tea Party","The 1773 destruction of British tea in Boston Harbor."],["Common Sense","Thomas Paine's 1776 pamphlet urging independence."],["Declaration of Independence","The July 4, 1776 statement of American independence and natural rights."],["Saratoga","The 1777 American victory that brought France into the war."],["Treaty of Paris (1783)","The treaty recognizing American independence."]],
  w:"The Revolution created the United States and its founding ideals, whose universal language Americans have argued over and expanded ever since.",
  src:["American Revolution","Stamp Act 1765","Boston Tea Party","Common Sense","United States Declaration of Independence","Siege of Yorktown"],
  q:[["Which 1765 tax on printed materials provoked fierce opposition?","The Stamp Act","The Sugar Act","The Tea Act","The Townshend Acts"],
     ["Who defended the British soldiers after the Boston Massacre?","John Adams","Samuel Adams","Patrick Henry","James Otis"],
     ["Where did the first battles of the war occur in April 1775?","Lexington and Concord","Bunker Hill","Saratoga","Trenton"],
     ["Who drafted most of the Declaration of Independence?","Thomas Jefferson","John Adams","Benjamin Franklin","James Madison"],
     ["Which battle persuaded France to ally with the Americans?","Saratoga","Yorktown","Trenton","Brandywine"],
     ["Where did Cornwallis surrender in 1781?","Yorktown","Saratoga","Valley Forge","Charleston"]]},

{ t:"The Early Republic", s:"Building a nation, 1783–1824",
  sec:[
  ["From Confederation to Constitution",[
    "The Articles of Confederation, the first national government, proved too weak, unable to tax, regulate commerce, or respond effectively to crises such as Shays' Rebellion (1786–1787). It did achieve one landmark: the Northwest Ordinance of 1787, which organized the territory north of the Ohio River, provided for new states equal to the original ones, and banned slavery there.",
    "The Constitutional Convention of 1787 created the Constitution, ratified in 1788, and the Bill of Rights followed in 1791 (both covered in depth in the Law course). George Washington became the first president in 1789, establishing precedents such as a cabinet of advisers and, by stepping down after two terms, the peaceful transfer of power. His Farewell Address (1796) warned against permanent foreign alliances and the dangers of political parties."]],
  ["Hamilton, Jefferson, and the first parties",[
    "Despite Washington's warnings, political parties emerged from disagreements between Treasury Secretary Alexander Hamilton and Secretary of State Thomas Jefferson. Hamilton sought a strong national government, federal assumption of state debts, a national bank, and support for commerce and manufacturing; his supporters became the Federalists. Jefferson and James Madison favored a limited government, states' rights, an agrarian republic of independent farmers, and strict reading of the Constitution; they formed the Democratic-Republicans.",
    "The parties also divided over the French Revolution and relations with Britain. Under President John Adams, the Federalists passed the Alien and Sedition Acts (1798), which criminalized criticism of the government; Jefferson and Madison responded with the Kentucky and Virginia Resolutions, asserting states' rights. The election of 1800, which brought Jefferson to the presidency, was the first transfer of power between opposing parties, which Jefferson called a “revolution” accomplished peacefully."]],
  ["Jefferson and expansion",[
    "In 1803, Jefferson purchased the Louisiana Territory from France for $15 million, roughly doubling the nation's size, even though he doubted the Constitution authorized it. He sent Meriwether Lewis and William Clark on an expedition (1804–1806) to explore the new territory and reach the Pacific, aided by guides including Sacagawea, a Lemhi Shoshone woman. In the same year, Chief Justice John Marshall's decision in Marbury v. Madison established judicial review.",
    "Jefferson also struggled with conflicts between Britain and France, which seized American ships. His Embargo Act of 1807, banning foreign trade, devastated the American economy. In 1808, Congress banned the importation of enslaved people, the earliest date the Constitution allowed, though the domestic slave trade continued."]],
  ["The War of 1812",[
    "Under President Madison, the United States declared war on Britain in 1812 over British impressment of American sailors (forcing them into the Royal Navy), interference with trade, and British support for Native resistance in the West, led by the Shawnee leader Tecumseh, who sought to unite Native nations. American invasions of Canada failed, and in 1814 British forces burned Washington, D.C., including the White House and Capitol. The successful defense of Fort McHenry in Baltimore inspired Francis Scott Key's “The Star-Spangled Banner.”",
    "The Treaty of Ghent (December 1814) restored prewar conditions. Andrew Jackson's victory at New Orleans in January 1815, fought before news of the treaty arrived, made him a national hero. The war boosted American nationalism, weakened Native resistance in the Old Northwest after Tecumseh's death in 1813, and destroyed the Federalist Party, whose opposition to the war appeared disloyal."]],
  ["The Era of Good Feelings",[
    "Under President James Monroe (1817–1825), one-party rule produced the “Era of Good Feelings.” The Supreme Court under Marshall strengthened national power in McCulloch v. Maryland (1819) and Gibbons v. Ogden (1824). The Monroe Doctrine (1823), drafted largely by Secretary of State John Quincy Adams, warned European powers against new colonization in the Americas.",
    "Sectional tension over slavery surfaced in 1819 when Missouri sought admission as a slave state. The Missouri Compromise of 1820 admitted Missouri as a slave state and Maine as a free state and banned slavery in the rest of the Louisiana Territory north of latitude 36°30'. The aging Jefferson called the crisis “a fire bell in the night” that filled him with terror for the Union's future."]]
  ],
  terms:[["Northwest Ordinance","The 1787 law organizing territory north of the Ohio River and banning slavery there."],["Federalists and Democratic-Republicans","The first American political parties."],["Louisiana Purchase","The 1803 acquisition that doubled U.S. territory."],["War of 1812","The 1812–1815 war between the United States and Britain."],["Monroe Doctrine","The 1823 warning against European colonization in the Americas."],["Missouri Compromise","The 1820 agreement balancing slave and free states."]],
  w:"The early republic tested the Constitution, created political parties and judicial review, and revealed the slavery conflict that would later divide the nation.",
  src:["Northwest Ordinance","Federalist Party","Louisiana Purchase","War of 1812","Era of Good Feelings","Missouri Compromise"],
  q:[["Which 1787 law banned slavery north of the Ohio River?","The Northwest Ordinance","The Missouri Compromise","The Constitution","The Land Ordinance of 1785"],
     ["Who led the Federalists' program for a national bank?","Alexander Hamilton","Thomas Jefferson","James Madison","John Marshall"],
     ["How much did the Louisiana Purchase cost?","$15 million","$1 million","$50 million","$7.2 million"],
     ["Which Shawnee leader sought to unite Native nations against U.S. expansion?","Tecumseh","Pontiac","Sitting Bull","Black Hawk"],
     ["The defense of which fort inspired “The Star-Spangled Banner”?","Fort McHenry","Fort Sumter","Fort Ticonderoga","Fort Detroit"],
     ["Which 1820 compromise admitted Missouri as a slave state and Maine as free?","The Missouri Compromise","The Compromise of 1850","The Great Compromise","The Kansas-Nebraska Act"]]},

{ t:"Jacksonian America and Reform", s:"Democracy, removal, and the reform impulse, 1824–1850",
  sec:[
  ["The age of the common man",[
    "By the 1820s, most states had dropped property requirements for voting, extending suffrage to nearly all white men, while excluding women and, in most places, Black men. Andrew Jackson, a war hero from Tennessee, lost the disputed election of 1824 to John Quincy Adams, which his supporters called a “corrupt bargain,” but won the presidency in 1828 as a champion of ordinary people against elites.",
    "Jackson's supporters formed the Democratic Party, and his opponents formed the Whig Party, creating the Second Party System. Campaigns became mass events with rallies and party newspapers. Jackson expanded the “spoils system,” rewarding supporters with government jobs, and fought the Second Bank of the United States, vetoing its recharter in 1832 as a tool of privileged elites."]],
  ["Nullification",[
    "In 1832, South Carolina, led by John C. Calhoun, Jackson's former vice president, declared federal tariffs “null and void” within the state, claiming states could nullify federal laws they deemed unconstitutional. Jackson, though a defender of states' rights in other matters, threatened to use force to enforce federal law, and a compromise tariff resolved the crisis. The nullification theory, rooted in defense of slavery and Southern interests, foreshadowed secession."]],
  ["Indian Removal",[
    "Jackson strongly supported removing Native nations from the Southeast to lands west of the Mississippi to open their land to white settlement, especially for cotton. Congress passed the Indian Removal Act in 1830. The Cherokee Nation, which had adopted a written constitution, a newspaper, and a writing system created by Sequoyah, challenged Georgia's attempts to take its land. In Worcester v. Georgia (1832), the Supreme Court ruled that Georgia had no authority over Cherokee territory, but Jackson refused to enforce the ruling.",
    "Between 1830 and 1850, the Choctaw, Creek, Chickasaw, Cherokee, and Seminole nations were forced west to Indian Territory (present-day Oklahoma). During the Cherokee removal of 1838–1839, roughly 4,000 of about 16,000 Cherokee died from exposure, disease, and hunger, a journey remembered as the Trail of Tears. The Seminole resisted in long wars in Florida."]],
  ["The market revolution",[
    "Between 1815 and 1850, a “market revolution” transformed the American economy. The Erie Canal (completed 1825) linked the Great Lakes to New York City, making it the nation's commercial capital. Steamboats, canals, and then railroads cut transport costs. Factories appeared, notably the textile mills of Lowell, Massachusetts, which employed young New England women. Samuel Morse's telegraph (1844) transmitted messages instantly.",
    "The North industrialized and urbanized, drawing waves of immigrants, especially Irish fleeing the Great Famine and Germans, which provoked a nativist backlash. The South's economy became ever more dependent on cotton grown by enslaved people; by 1860, cotton was the nation's leading export."]],
  ["The reform impulse",[
    "A religious revival, the Second Great Awakening, encouraged Americans to perfect society. Reformers campaigned for temperance (limiting alcohol), public schools (led by Horace Mann), prison reform, and better treatment of the mentally ill (Dorothea Dix). Utopian communities, such as Brook Farm and the Oneida Community, experimented with new ways of living.",
    "The most important reform movement was abolitionism. William Lloyd Garrison began publishing The Liberator in 1831, demanding immediate emancipation. Frederick Douglass, who escaped slavery in Maryland in 1838, became a powerful orator and author. Women's rights grew partly out of abolitionism; at the Seneca Falls Convention in 1848, Elizabeth Cady Stanton and Lucretia Mott issued the Declaration of Sentiments, modeled on the Declaration of Independence, declaring that “all men and women are created equal” and demanding the vote."]]
  ],
  terms:[["Jacksonian democracy","The expansion of political participation for white men under Andrew Jackson."],["Spoils system","Rewarding political supporters with government jobs."],["Nullification","The claim that states could void federal laws."],["Indian Removal Act","The 1830 law authorizing forced removal of Native nations."],["Trail of Tears","The deadly forced removal of the Cherokee in 1838–1839."],["Seneca Falls Convention","The 1848 meeting that launched the organized women's rights movement."]],
  w:"The Jacksonian era expanded democracy for white men while dispossessing Native nations, and its reform movements launched the struggles for abolition and women's rights.",
  src:["Jacksonian democracy","Nullification crisis","Indian Removal Act","Trail of Tears","Erie Canal","Seneca Falls Convention"],
  q:[["What did Jackson's supporters call the outcome of the 1824 election?","A corrupt bargain","The revolution of 1800","The spoils system","Manifest Destiny"],
     ["Which state declared federal tariffs null and void in 1832?","South Carolina","Georgia","Virginia","Massachusetts"],
     ["Which Supreme Court case ruled for the Cherokee against Georgia?","Worcester v. Georgia","Marbury v. Madison","Dred Scott v. Sandford","Johnson v. M'Intosh"],
     ["Which canal, completed in 1825, linked the Great Lakes to New York City?","The Erie Canal","The Chesapeake and Ohio Canal","The Panama Canal","The Suez Canal"],
     ["Who published The Liberator beginning in 1831?","William Lloyd Garrison","Frederick Douglass","Harriet Beecher Stowe","John Brown"],
     ["Who organized the Seneca Falls Convention with Lucretia Mott?","Elizabeth Cady Stanton","Susan B. Anthony","Sojourner Truth","Lucy Stone"]]},

{ t:"Slavery and the Road to Civil War", s:"Expansion and sectional crisis, 1830–1861",
  sec:[
  ["Slavery in the antebellum South",[
    "By 1860, about four million enslaved people lived in the United States, nearly all in the South. Slavery was the foundation of the Southern economy and, through cotton, of much of the national economy. A massive domestic slave trade forcibly moved roughly a million enslaved people from the Upper South to the cotton lands of the Deep South, tearing apart families.",
    "Enslaved people endured violence, family separation, and the denial of education and legal rights, but they built families, communities, and a distinctive religious culture, and they resisted in many ways. Nat Turner's rebellion in Virginia in 1831, which killed about 60 white people, led to harsh crackdowns. Thousands escaped north, some aided by the Underground Railroad, a network of free Black and white abolitionists; Harriet Tubman, who escaped from Maryland, returned repeatedly to lead others to freedom."]],
  ["Manifest Destiny and the Mexican War",[
    "In the 1840s, many Americans believed in “Manifest Destiny,” a term coined in 1845, the idea that the United States was destined to expand across the continent. Texas, which had won independence from Mexico in 1836, was annexed in 1845. The United States and Britain divided the Oregon Country in 1846.",
    "A border dispute led to the Mexican–American War (1846–1848), which critics, including Congressman Abraham Lincoln and Henry David Thoreau, saw as an unjust war to expand slavery. U.S. forces captured Mexico City, and the Treaty of Guadalupe Hidalgo (1848) transferred about half of Mexico's territory, including California and the Southwest, to the United States. Gold was discovered in California that same year, triggering the Gold Rush. The new territories reopened the question of slavery's expansion."]],
  ["Compromise and conflict",[
    "The Compromise of 1850 admitted California as a free state, allowed popular sovereignty on slavery in Utah and New Mexico territories, ended the slave trade in Washington, D.C., and enacted a harsh Fugitive Slave Act requiring Northerners to help return escaped people. The act radicalized many Northerners. Harriet Beecher Stowe's novel Uncle Tom's Cabin (1852), depicting slavery's cruelty, became a bestseller.",
    "The Kansas-Nebraska Act (1854), sponsored by Senator Stephen Douglas, allowed settlers in those territories to decide on slavery, repealing the Missouri Compromise line. Pro- and anti-slavery settlers fought in “Bleeding Kansas.” In the Senate, a South Carolina congressman beat Senator Charles Sumner with a cane after an antislavery speech. The new Republican Party formed in 1854 to oppose the expansion of slavery."]],
  ["Dred Scott and Lincoln",[
    "In Dred Scott v. Sandford (1857), the Supreme Court, led by Chief Justice Roger Taney, ruled that Black Americans could not be citizens and that Congress could not ban slavery in the territories, striking at the Republican platform.",
    "Abraham Lincoln, an Illinois lawyer, challenged Douglas for the Senate in 1858 in a series of famous debates, declaring that “a house divided against itself cannot stand.” Lincoln opposed slavery's expansion and called it a moral wrong, though he did not then propose abolishing it where it existed. In 1859, the abolitionist John Brown led a raid on the federal arsenal at Harpers Ferry, Virginia, hoping to spark a slave uprising; he was captured and hanged, becoming a martyr to many Northerners and a terrorist to Southerners."]],
  ["Secession",[
    "In the election of 1860, the Democratic Party split along sectional lines, and Lincoln won the presidency with no electoral votes from the South. Viewing his election as a threat to slavery, South Carolina seceded in December 1860, followed by six more Deep South states, which formed the Confederate States of America in February 1861, with Jefferson Davis as president. Confederate Vice President Alexander Stephens declared that its “cornerstone rests upon the great truth that the negro is not equal to the white man; that slavery... is his natural and normal condition.”",
    "Lincoln, inaugurated in March 1861, declared secession illegal but promised not to interfere with slavery where it existed. On April 12, 1861, Confederate forces fired on Fort Sumter in Charleston Harbor, and the Civil War began. Four more slave states, including Virginia, then seceded; four border slave states, including Maryland, stayed in the Union."]]
  ],
  terms:[["Underground Railroad","A network helping enslaved people escape to freedom."],["Manifest Destiny","The belief that the U.S. was destined to expand across the continent."],["Treaty of Guadalupe Hidalgo","The 1848 treaty ceding Mexican territory to the U.S."],["Fugitive Slave Act","The 1850 law requiring the return of escaped enslaved people."],["Kansas-Nebraska Act","The 1854 law allowing popular sovereignty on slavery in those territories."],["Secession","The withdrawal of Southern states from the Union in 1860–1861."]],
  w:"The conflict over slavery's expansion divided the nation and led directly to the Civil War, the central crisis of American history.",
  src:["Slavery in the United States","Underground Railroad","Mexican–American War","Compromise of 1850","Kansas–Nebraska Act","Secession in the United States"],
  q:[["About how many enslaved people lived in the U.S. in 1860?","Four million","One million","Ten million","400,000"],
     ["Which Maryland-born woman led many people to freedom on the Underground Railroad?","Harriet Tubman","Sojourner Truth","Harriet Beecher Stowe","Phillis Wheatley"],
     ["Which treaty ended the Mexican–American War?","The Treaty of Guadalupe Hidalgo","The Treaty of Ghent","The Adams-Onís Treaty","The Treaty of Paris"],
     ["Which novel by Harriet Beecher Stowe depicted slavery's cruelty?","Uncle Tom's Cabin","Beloved","Twelve Years a Slave","Clotel"],
     ["Who said “a house divided against itself cannot stand” in 1858?","Abraham Lincoln","Stephen Douglas","Frederick Douglass","William Seward"],
     ["Where did the Civil War begin on April 12, 1861?","Fort Sumter","Harpers Ferry","Bull Run","Fort McHenry"]]},

{ t:"The Civil War", s:"The war that ended slavery and saved the Union, 1861–1865",
  sec:[
  ["Two sides",[
    "The Union had enormous advantages: more than twice the population, most of the nation's factories, railroads, and banks, and a navy. The Confederacy had capable generals, especially Robert E. Lee, the advantage of fighting defensively on its own territory, and hopes of European recognition because of Britain's dependence on Southern cotton. The Union strategy, the “Anaconda Plan,” aimed to blockade Southern ports and seize the Mississippi River.",
    "The war was far bloodier than anyone expected. Rifled muskets, which were accurate at long range, made frontal assaults deadly. An estimated 620,000 to 750,000 soldiers died, more than in all other American wars combined until Vietnam, with disease killing more than combat."]],
  ["The war in the East and West",[
    "In the East, Lee defeated a series of Union commanders, but his invasion of Maryland ended at Antietam (September 17, 1862), the bloodiest single day in American history, with about 23,000 casualties. Lee's second invasion of the North was defeated at Gettysburg, Pennsylvania (July 1–3, 1863), the war's largest battle, ending with the failed assault known as Pickett's Charge.",
    "In the West, Ulysses S. Grant won key victories. On July 4, 1863, a day after Gettysburg, his siege of Vicksburg, Mississippi, ended in Confederate surrender, giving the Union control of the Mississippi River and splitting the Confederacy. Lincoln made Grant general-in-chief in 1864."]],
  ["Emancipation",[
    "The war began as a war to preserve the Union, but it became a war to end slavery. Enslaved people forced the issue by escaping to Union lines, where some commanders declared them “contraband of war.” After Antietam, Lincoln issued the preliminary Emancipation Proclamation, and on January 1, 1863, the final proclamation declared free all enslaved people in areas still in rebellion. It did not immediately free people in the loyal border states, but it transformed the war's purpose, made freedom advance with Union armies, and discouraged European recognition of the Confederacy.",
    "The proclamation also authorized Black enlistment. About 180,000 Black soldiers served in the Union Army, including the 54th Massachusetts Infantry, famous for its assault on Fort Wagner, and about 19,000 in the Navy. In November 1863, Lincoln's Gettysburg Address redefined the war as a struggle for “a new birth of freedom” so that “government of the people, by the people, for the people, shall not perish from the earth.”"]],
  ["Total war and victory",[
    "In 1864–1865, Grant pressed Lee relentlessly in Virginia, accepting enormous casualties, while General William Tecumseh Sherman captured Atlanta in September 1864, helping Lincoln win reelection, and then marched to the sea through Georgia, destroying railroads, crops, and property to break the South's ability and will to fight.",
    "Lee surrendered to Grant at Appomattox Court House, Virginia, on April 9, 1865. Five days later, on April 14, the actor and Confederate sympathizer John Wilkes Booth shot Lincoln at Ford's Theatre in Washington; he died the next morning. The 13th Amendment, abolishing slavery throughout the United States, was ratified in December 1865."]],
  ["Meaning of the war",[
    "The Civil War preserved the Union and established that states could not secede. It ended slavery, freeing about four million people, and transformed the federal government, which expanded its power, created a national currency, and passed laws such as the Homestead Act (1862) and the Pacific Railway Act (1862). Women took on new roles as nurses, including Clara Barton, who later founded the American Red Cross, and as workers.",
    "After the war, many white Southerners promoted the “Lost Cause” myth, claiming the war was about states' rights rather than slavery and romanticizing the Confederacy. Historians have thoroughly documented that the protection of slavery was the central cause of secession, as secession documents themselves declared. Debates over Confederate monuments in recent years reflect this contested memory."]]
  ],
  terms:[["Anaconda Plan","The Union strategy of blockade and control of the Mississippi."],["Antietam","The bloodiest single day in American history, September 17, 1862."],["Emancipation Proclamation","Lincoln's January 1, 1863 order freeing enslaved people in rebel areas."],["Gettysburg","The war's largest battle, July 1–3, 1863."],["Appomattox","Where Lee surrendered to Grant on April 9, 1865."],["Lost Cause","The myth that the Confederacy fought for states' rights, not slavery."]],
  w:"The Civil War ended slavery, redefined American freedom and federal power, and remains the most consequential event in U.S. history.",
  src:["American Civil War","Battle of Antietam","Emancipation Proclamation","Battle of Gettysburg","Gettysburg Address","Lost Cause of the Confederacy"],
  q:[["Which battle was the bloodiest single day in American history?","Antietam","Gettysburg","Shiloh","Bull Run"],
     ["Which Union victory on July 4, 1863 gave control of the Mississippi?","Vicksburg","Gettysburg","Chattanooga","New Orleans"],
     ["When did the final Emancipation Proclamation take effect?","January 1, 1863","April 12, 1861","July 4, 1863","December 6, 1865"],
     ["About how many Black soldiers served in the Union Army?","180,000","18,000","1 million","500,000"],
     ["Which general marched to the sea through Georgia?","William Tecumseh Sherman","Ulysses S. Grant","George McClellan","Philip Sheridan"],
     ["Where did Lee surrender to Grant?","Appomattox Court House","Richmond","Petersburg","Gettysburg"]]},

{ t:"Reconstruction and the West", s:"Freedom, backlash, and conquest, 1865–1890",
  sec:[
  ["Rebuilding the Union",[
    "Reconstruction (1865–1877) addressed how to reintegrate the Southern states and what freedom would mean for four million formerly enslaved people. Lincoln's successor, Andrew Johnson, a Southern Democrat, pursued a lenient policy, allowing Southern states to pass “Black Codes” that restricted freedpeople's rights and forced them into labor contracts.",
    "Outraged, Republicans in Congress took control of Reconstruction. They passed the Civil Rights Act of 1866 over Johnson's veto, the 14th Amendment (1868), guaranteeing citizenship and equal protection, and the 15th Amendment (1870), prohibiting racial discrimination in voting. The Reconstruction Acts of 1867 placed the South under military districts. The House impeached Johnson in 1868, and the Senate acquitted him by a single vote."]],
  ["Freedom in practice",[
    "Freedpeople reunited families, founded churches and schools, and sought land. The Freedmen's Bureau, created in 1865, helped establish schools, including the foundations of historically Black colleges such as Howard University. Without land redistribution, most freedpeople became sharecroppers, farming land owned by others in exchange for a share of the crop, a system that often trapped them in debt.",
    "Black men voted and held office in large numbers. Hiram Revels of Mississippi became the first Black U.S. senator in 1870, and hundreds of Black officials served in state legislatures. Reconstruction governments built public schools and hospitals. But white Southerners formed terrorist groups such as the Ku Klux Klan, founded in 1865, which used violence to intimidate Black voters and Republicans."]],
  ["The end of Reconstruction",[
    "Northern commitment faded amid economic depression, scandal, and racism. Supreme Court decisions narrowed the new amendments. The disputed presidential election of 1876 was resolved by the Compromise of 1877, in which Republican Rutherford B. Hayes became president and federal troops were withdrawn from the South.",
    "White “Redeemer” Democrats regained control and, over the following decades, disenfranchised Black voters through poll taxes, literacy tests, white primaries, and violence, and imposed Jim Crow segregation, upheld by the Supreme Court in Plessy v. Ferguson (1896). Lynching terrorized Black communities; the journalist Ida B. Wells documented and campaigned against it from the 1890s. Historian W. E. B. Du Bois later called Reconstruction a brief moment in which “the slave went free; stood a brief moment in the sun; then moved back again toward slavery.”"]],
  ["The West",[
    "After the war, Americans settled the West at a rapid pace. The Homestead Act (1862) offered 160 acres of public land to settlers who farmed it for five years. The first transcontinental railroad, built largely by Irish and Chinese laborers, was completed at Promontory Summit, Utah, in 1869. Cattle drives, mining booms, and farming transformed the Great Plains. The Chinese Exclusion Act of 1882 barred Chinese laborers, the first major U.S. law restricting immigration by nationality.",
    "Westward expansion came at the expense of Native nations. The near-extermination of the bison, from tens of millions to a few hundred by the late 1880s, destroyed the economy of Plains peoples. The U.S. Army fought wars against the Sioux, Cheyenne, Apache, Nez Perce, and others. Lakota and Cheyenne warriors led by Sitting Bull and Crazy Horse defeated George Custer at the Little Bighorn in 1876, but resistance was eventually crushed. At Wounded Knee, South Dakota, in 1890, U.S. troops killed about 250 to 300 Lakota men, women, and children."]],
  ["Assimilation policy",[
    "Native peoples were confined to reservations, often on poor land. The Dawes Act (1887) broke up reservation land into individual allotments, with “surplus” land sold to white settlers; Native landholdings fell from about 138 million acres in 1887 to about 48 million by 1934. Boarding schools, such as the Carlisle Indian Industrial School, founded in 1879 with the motto “Kill the Indian, save the man,” separated children from families and forbade Native languages and customs.",
    "In 1890, the Census Bureau declared that a continuous frontier line no longer existed. In 1893, the historian Frederick Jackson Turner argued that the frontier had shaped American democracy and character. Later historians criticized his thesis for ignoring Native peoples, women, and the conquest involved. Native nations survived these policies, and the Indian Reorganization Act of 1934 began, partially, to reverse them."]]
  ],
  terms:[["Reconstruction","The 1865–1877 effort to rebuild the South and define freedom."],["Black Codes","Southern laws restricting freedpeople's rights after the war."],["Freedmen's Bureau","The federal agency aiding freedpeople after the war."],["Sharecropping","Farming another's land for a share of the crop."],["Compromise of 1877","The deal ending Reconstruction."],["Dawes Act","The 1887 law dividing reservations into individual allotments."]],
  w:"Reconstruction's promise and failure shaped civil rights struggles for a century, and the conquest of the West shaped the nation's land and its relations with Native nations.",
  src:["Reconstruction era","Freedmen's Bureau","Sharecropping","Compromise of 1877","Battle of the Little Bighorn","Dawes Act"],
  q:[["Who was the first Black U.S. senator?","Hiram Revels","Frederick Douglass","Blanche Bruce","Robert Smalls"],
     ["Which amendment prohibited racial discrimination in voting?","The 15th","The 13th","The 14th","The 19th"],
     ["Which deal ended Reconstruction?","The Compromise of 1877","The Compromise of 1850","The Missouri Compromise","The Treaty of Ghent"],
     ["Who documented and campaigned against lynching?","Ida B. Wells","Booker T. Washington","Harriet Tubman","Mary Church Terrell"],
     ["Where was the transcontinental railroad completed in 1869?","Promontory Summit, Utah","Omaha, Nebraska","Sacramento, California","Denver, Colorado"],
     ["Which 1887 law broke up reservations into individual allotments?","The Dawes Act","The Homestead Act","The Indian Removal Act","The Indian Reorganization Act"]]}
]});


/* ---- from hist-11.js ---- */
/* HISTORY FOUNDATIONS, part 11: Unit 7 (The United States), chapters 8-14 */
COURSES.history.units[6].ch.push(

{ t:"Industrial America and the Gilded Age", s:"Capital, labor, and immigration, 1870–1900",
  sec:[
  ["An industrial giant",[
    "Between the Civil War and 1900, the United States became the world's largest industrial economy. Railroads, which grew from about 35,000 miles of track in 1865 to around 190,000 by 1900, created a national market, and the government granted them vast tracts of land. Steel, oil, electricity, and new technologies such as the telephone (1876) and Edison's electric light (1879) transformed daily life.",
    "Business leaders built giant enterprises. Andrew Carnegie dominated steel through vertical integration, controlling every stage from ore to finished product. John D. Rockefeller's Standard Oil controlled about 90 percent of American oil refining by the 1880s through horizontal integration and the trust device. J. P. Morgan reorganized railroads and in 1901 created U.S. Steel, the first billion-dollar corporation. Admirers called them “captains of industry”; critics called them “robber barons.”"]],
  ["Workers and labor conflict",[
    "Industrial workers faced long hours, low wages, dangerous conditions, child labor, and periodic unemployment. Workers organized. The Knights of Labor welcomed nearly all workers, and Samuel Gompers' American Federation of Labor (1886) organized skilled workers into craft unions focused on wages and hours.",
    "Labor conflict was often violent. The Great Railroad Strike of 1877 spread nationwide before federal troops crushed it. At Haymarket Square in Chicago in 1886, a bomb killed police officers at a labor rally, leading to the execution of anarchists on thin evidence. The Homestead Strike (1892) at Carnegie's steelworks and the Pullman Strike (1894), broken by federal troops and a court injunction, showed the power of companies backed by government."]],
  ["Immigration and cities",[
    "Between 1880 and 1920, about 20 million immigrants arrived, increasingly from southern and eastern Europe: Italians, Poles, Jews from the Russian Empire, Greeks, and others. Ellis Island in New York Harbor, opened in 1892, processed millions. Immigrants filled factories and cities, often living in crowded tenements, which the photographer Jacob Riis exposed in How the Other Half Lives (1890). Settlement houses, such as Jane Addams' Hull House in Chicago (1889), offered services and education.",
    "Cities grew explosively, with skyscrapers, electric streetcars, and department stores. Political machines such as New York's Tammany Hall, led for a time by Boss William Tweed, traded jobs and favors for votes, mixing corruption with services for immigrants. Nativists pushed for restrictions, which culminated in the Immigration Act of 1924, which imposed national-origin quotas that sharply limited immigration from southern and eastern Europe and barred most Asian immigrants."]],
  ["Politics and the Populists",[
    "Gilded Age politics, named after Mark Twain and Charles Dudley Warner's 1873 novel, featured close elections, high voter turnout, and corruption. After a disappointed office-seeker assassinated President James Garfield in 1881, the Pendleton Act (1883) began a merit-based civil service. The Interstate Commerce Act (1887) and the Sherman Antitrust Act (1890) were early attempts to regulate railroads and monopolies.",
    "Farmers, squeezed by falling crop prices, debt, and railroad rates, organized the Farmers' Alliance and in 1892 the People's (Populist) Party, which demanded government ownership of railroads, a graduated income tax, direct election of senators, and coinage of silver to expand the money supply. In 1896, the Democrat William Jennings Bryan, backed by the Populists, gave his “Cross of Gold” speech but lost to the Republican William McKinley. Many Populist demands were later adopted."]],
  ["An American empire",[
    "In the 1890s, the United States became an overseas imperial power. American planters and businessmen overthrew Hawaii's Queen Liliʻuokalani in 1893, and the U.S. annexed Hawaii in 1898. The Spanish-American War of 1898, fueled by sensational “yellow journalism” and the mysterious explosion of the battleship USS Maine in Havana harbor, lasted only months. The U.S. gained Puerto Rico, Guam, and the Philippines, and Cuba became a U.S. protectorate.",
    "Filipino nationalists who had fought Spain resisted American rule in the Philippine-American War (1899–1902), in which hundreds of thousands of Filipinos died, mostly civilians, from violence, famine, and disease. Anti-imperialists, including Mark Twain, opposed the conquest. Theodore Roosevelt's “big stick” diplomacy and the construction of the Panama Canal (completed 1914) extended American power in the Caribbean and Central America."]]
  ],
  terms:[["Vertical and horizontal integration","Controlling all stages of production vs. buying out competitors."],["Robber barons","A critical term for powerful Gilded Age industrialists."],["Haymarket affair","The 1886 Chicago bombing at a labor rally."],["Ellis Island","The immigration station that opened in 1892."],["Populist Party","The 1890s farmers' party demanding economic reforms."],["Spanish-American War","The 1898 war that gave the U.S. an overseas empire."]],
  w:"The Gilded Age created modern American industry, cities, and immigrant communities, and its conflicts over monopoly, labor, and empire shaped the 20th century.",
  src:["Gilded Age","Robber baron (industrialist)","Pullman Strike","Immigration to the United States","Populist Party (United States)","Spanish–American War"],
  q:[["Who dominated the steel industry through vertical integration?","Andrew Carnegie","John D. Rockefeller","J. P. Morgan","Cornelius Vanderbilt"],
     ["Who founded the American Federation of Labor?","Samuel Gompers","Eugene Debs","Terence Powderly","Mother Jones"],
     ["Whose book How the Other Half Lives exposed tenement conditions?","Jacob Riis","Upton Sinclair","Ida Tarbell","Lincoln Steffens"],
     ["Which 1883 act began a merit-based civil service?","The Pendleton Act","The Sherman Act","The Interstate Commerce Act","The Hatch Act"],
     ["Who gave the “Cross of Gold” speech?","William Jennings Bryan","William McKinley","Grover Cleveland","Theodore Roosevelt"],
     ["Which territories did the U.S. gain from Spain in 1898?","Puerto Rico, Guam, and the Philippines","Hawaii and Alaska","Cuba and Mexico","Samoa and Midway"]]},

{ t:"The Progressive Era and World War I", s:"Reform at home and war abroad, 1900–1920",
  sec:[
  ["Progressivism",[
    "Progressives were reformers, mostly middle-class, who sought to address the problems of industrial society through government action, expert knowledge, and civic engagement. Muckraking journalists exposed abuses: Ida Tarbell investigated Standard Oil, Lincoln Steffens exposed urban corruption in The Shame of the Cities, and Upton Sinclair's The Jungle (1906) revealed conditions in the meatpacking industry.",
    "Progressives won reforms at every level: city commissions and managers, the secret ballot, initiatives, referendums, and recalls, especially in states such as Wisconsin under Robert La Follette; workplace safety and child labor laws, spurred by tragedies like the Triangle Shirtwaist Factory fire of 1911, which killed 146 garment workers in New York; and regulation of food and drugs through the Pure Food and Drug Act (1906)."]],
  ["Progressive presidents",[
    "Theodore Roosevelt (1901–1909) promised a “Square Deal,” used the Sherman Act to break up trusts such as the Northern Securities railroad company, mediated a coal strike, and greatly expanded national forests, parks, and wildlife refuges. William Howard Taft continued trust-busting. In 1912, Roosevelt ran as the Progressive (“Bull Moose”) candidate, splitting the Republican vote and allowing the Democrat Woodrow Wilson to win.",
    "Wilson's “New Freedom” program lowered tariffs, introduced a federal income tax under the 16th Amendment (1913), created the Federal Reserve System (1913), strengthened antitrust law with the Clayton Act, and created the Federal Trade Commission (1914). Progressivism had limits: Wilson segregated the federal civil service, and many progressives supported immigration restriction and eugenics."]],
  ["Women's suffrage and Black activism",[
    "The women's suffrage movement, led by figures such as Susan B. Anthony, Carrie Chapman Catt, and the more militant Alice Paul, whose followers picketed the White House, won the vote in many western states and finally nationally with the 19th Amendment (1920).",
    "Black Americans faced segregation, disenfranchisement, and lynching. Booker T. Washington urged economic self-improvement and accommodation, while W. E. B. Du Bois demanded full civil and political rights and helped found the NAACP in 1909. Beginning around 1910, the Great Migration brought millions of Black Southerners to Northern and Western cities in search of work and freedom from Jim Crow, transforming American cities and culture."]],
  ["World War I",[
    "When war broke out in Europe in 1914, Wilson declared neutrality, and he won reelection in 1916 with the slogan “He kept us out of war.” But Germany's unrestricted submarine warfare, including the sinking of the British liner Lusitania in 1915, which killed 128 Americans, and the Zimmermann Telegram, a German proposal for an alliance with Mexico, pushed the U.S. toward war. Congress declared war in April 1917, and Wilson said the world “must be made safe for democracy.”",
    "About two million American soldiers reached France, helping defeat Germany's final offensives in 1918; more than 116,000 Americans died, many from the 1918 influenza pandemic. At home, the government expanded its power over the economy and suppressed dissent through the Espionage Act (1917) and Sedition Act (1918); the Socialist leader Eugene Debs was imprisoned for an antiwar speech, and the Supreme Court upheld such prosecutions in Schenck v. United States (1919)."]],
  ["After the war",[
    "Wilson's Fourteen Points proposed open diplomacy, free trade, national self-determination, and a League of Nations to prevent future wars. At the Paris Peace Conference, he won the League's creation, but the U.S. Senate, led by Henry Cabot Lodge, refused to ratify the Treaty of Versailles, and the United States never joined the League.",
    "The years 1919–1920 brought turmoil: a wave of strikes, the first Red Scare, with raids and deportations of suspected radicals under Attorney General A. Mitchell Palmer, and deadly race riots in Chicago and other cities during the “Red Summer” of 1919, as returning Black veterans and migrants faced white violence. Prohibition of alcohol took effect in 1920 under the 18th Amendment, a final Progressive reform."]]
  ],
  terms:[["Muckrakers","Journalists who exposed corruption and abuses."],["Square Deal","Theodore Roosevelt's program of fair treatment and regulation."],["19th Amendment","The 1920 amendment granting women the vote."],["Great Migration","The movement of millions of Black Southerners north and west."],["Zimmermann Telegram","Germany's 1917 proposal of an alliance with Mexico."],["Fourteen Points","Wilson's 1918 plan for peace, including a League of Nations."]],
  w:"The Progressive Era built much of the modern regulatory state, and World War I made the United States a world power while testing civil liberties at home.",
  src:["Progressive Era","Triangle Shirtwaist Factory fire","Women's suffrage in the United States","Great Migration (African American)","United States in World War I","Fourteen Points"],
  q:[["Which 1911 disaster killed 146 garment workers?","The Triangle Shirtwaist Factory fire","The Haymarket bombing","The Johnstown Flood","The Great Chicago Fire"],
     ["Which party did Roosevelt run with in 1912?","The Progressive (Bull Moose) Party","The Populist Party","The Socialist Party","The Whig Party"],
     ["Which leader helped found the NAACP and demanded full civil rights?","W. E. B. Du Bois","Booker T. Washington","Marcus Garvey","Frederick Douglass"],
     ["Which telegram pushed the U.S. toward war in 1917?","The Zimmermann Telegram","The Ems Dispatch","The Lusitania Note","The Balfour Declaration"],
     ["Which case upheld wartime speech prosecutions in 1919?","Schenck v. United States","Brandenburg v. Ohio","Gitlow v. New York","Debs v. Wilson"],
     ["Which body refused to ratify the Treaty of Versailles?","The U.S. Senate","The House of Representatives","The Supreme Court","The League of Nations"]]},

{ t:"Boom, Bust, and the New Deal", s:"The 1920s, the Great Depression, and FDR, 1920–1940",
  sec:[
  ["The Roaring Twenties",[
    "The 1920s brought prosperity for many Americans and a new consumer culture. Automobiles, made affordable by Henry Ford's assembly line, transformed daily life; by 1929 there were more than 20 million cars on American roads. Radio, movies (with sound after 1927's The Jazz Singer), advertising, and installment buying spread mass culture. Republican presidents Harding, Coolidge, and Hoover favored business, low taxes, and limited regulation.",
    "The decade saw cultural change and conflict. Jazz spread from New Orleans and Chicago, and the Harlem Renaissance produced Black writers and artists such as Langston Hughes, Zora Neale Hurston, and Duke Ellington. Young women called “flappers” challenged traditional norms. At the same time, Prohibition fueled bootlegging and organized crime, the revived Ku Klux Klan claimed millions of members, the 1924 Immigration Act restricted immigration, and the Scopes “Monkey” Trial (1925) dramatized conflict over teaching evolution."]],
  ["The crash and the Depression",[
    "Beneath the prosperity lay weaknesses: unequal income distribution, struggling farmers, weak banks, and speculation in the stock market, often with borrowed money. The stock market crashed in October 1929, with the worst days on October 24 (Black Thursday) and October 29 (Black Tuesday). The crash triggered and deepened the Great Depression, the worst economic downturn in modern history.",
    "Thousands of banks failed, wiping out savings. Industrial production fell by nearly half. Unemployment reached about 25 percent in 1933. Homeless people built shantytowns mockingly called “Hoovervilles,” after President Herbert Hoover, whose response was seen as inadequate. The Dust Bowl, caused by drought and farming practices that destroyed the plains' topsoil, drove hundreds of thousands of farm families, “Okies,” west to California, as depicted in John Steinbeck's The Grapes of Wrath (1939)."]],
  ["Roosevelt and the New Deal",[
    "Franklin D. Roosevelt won the 1932 election promising a “New Deal.” In his inaugural address he declared that “the only thing we have to fear is fear itself.” In his first “Hundred Days,” Congress passed a flood of legislation: an emergency banking act, the Federal Deposit Insurance Corporation (FDIC) to insure bank deposits, the Civilian Conservation Corps, which employed young men in conservation work, the Tennessee Valley Authority, which built dams and brought electricity to a poor region, and programs to raise farm prices and regulate industry. Roosevelt explained his policies in radio “fireside chats.”",
    "The Second New Deal (1935) added the Works Progress Administration, which employed millions building roads, schools, and public works and sponsored artists and writers; the Social Security Act, creating old-age pensions and unemployment insurance; and the National Labor Relations (Wagner) Act, protecting the right to unionize. The Fair Labor Standards Act (1938) set a minimum wage and maximum hours."]],
  ["Critics and limits",[
    "The New Deal faced critics from both sides. Conservatives and business leaders saw it as dangerous expansion of government. Populist critics, such as Louisiana's Senator Huey Long, with his “Share Our Wealth” plan, and the radio priest Father Charles Coughlin, argued it did not go far enough. The Supreme Court struck down several programs, and Roosevelt's 1937 plan to add justices, “court packing,” failed, though the Court soon began upholding New Deal laws.",
    "The New Deal did not end the Depression; unemployment remained high until World War II spending revived the economy. Many programs discriminated against Black Americans, partly because of Southern Democratic influence; for example, agricultural and domestic workers were initially excluded from Social Security. Yet the New Deal permanently expanded the federal government's role in the economy and created a safety net that endures."]],
  ["A new political order",[
    "Roosevelt built the New Deal coalition of Southern whites, urban workers, union members, immigrants and their children, Catholics, Jews, and, increasingly, Black voters who shifted from the party of Lincoln to the Democrats. This coalition dominated American politics for decades.",
    "Eleanor Roosevelt transformed the role of First Lady, advocating for the poor, women, and civil rights; in 1939, she resigned from the Daughters of the American Revolution after it barred the Black singer Marian Anderson from performing in its hall, and helped arrange Anderson's historic concert at the Lincoln Memorial. Frances Perkins, Secretary of Labor and the first woman in a U.S. cabinet, helped design Social Security."]]
  ],
  terms:[["Harlem Renaissance","A flowering of Black art and literature in the 1920s."],["Black Tuesday","October 29, 1929, the worst day of the stock market crash."],["Dust Bowl","Drought and soil erosion that devastated the Great Plains in the 1930s."],["New Deal","Roosevelt's programs of relief, recovery, and reform."],["Social Security Act","The 1935 law creating old-age pensions and unemployment insurance."],["Court packing","Roosevelt's failed 1937 plan to add Supreme Court justices."]],
  w:"The Depression and New Deal created the modern American safety net and federal role in the economy, debates that continue today.",
  src:["Roaring Twenties","Harlem Renaissance","Wall Street crash of 1929","Great Depression in the United States","New Deal","Dust Bowl"],
  q:[["Which 1927 film introduced synchronized sound to feature films?","The Jazz Singer","Gone with the Wind","Metropolis","The Birth of a Nation"],
     ["What were Depression-era shantytowns called?","Hoovervilles","Rooseveltowns","Okievilles","Dust towns"],
     ["Who said “the only thing we have to fear is fear itself”?","Franklin D. Roosevelt","Herbert Hoover","Eleanor Roosevelt","Huey Long"],
     ["Which agency insures bank deposits?","The FDIC","The WPA","The TVA","The SEC"],
     ["Which novel depicted Dust Bowl migrants?","The Grapes of Wrath","The Great Gatsby","Of Mice and Men","Babbitt"],
     ["Who was the first woman in a U.S. cabinet?","Frances Perkins","Eleanor Roosevelt","Jeannette Rankin","Mary McLeod Bethune"]]},

{ t:"America in World War II", s:"The arsenal of democracy, 1939–1945",
  sec:[
  ["From isolation to involvement",[
    "In the 1930s, many Americans, disillusioned by World War I, wanted to stay out of foreign conflicts, and Congress passed Neutrality Acts. After war began in Europe in 1939, Roosevelt gradually aided Britain. The Lend-Lease Act (1941) supplied weapons to Britain and later the Soviet Union, making the U.S. the “arsenal of democracy.” In August 1941, Roosevelt and British Prime Minister Winston Churchill issued the Atlantic Charter, outlining shared war aims.",
    "On December 7, 1941, Japan attacked the U.S. Pacific Fleet at Pearl Harbor, Hawaii, killing about 2,400 Americans. Roosevelt called it “a date which will live in infamy.” Congress declared war on Japan, and Germany and Italy declared war on the United States."]],
  ["The home front",[
    "The war transformed the American economy. Industry converted to military production, building some 300,000 aircraft, and unemployment vanished. About 16 million Americans served in the armed forces. Women entered factories and shipyards in huge numbers, symbolized by “Rosie the Riveter,” and about 350,000 women served in the military.",
    "Black Americans, who served in segregated units such as the Tuskegee Airmen, launched the “Double V” campaign, for victory over fascism abroad and racism at home. Under pressure from labor leader A. Philip Randolph's threatened march on Washington, Roosevelt banned discrimination in defense industries in 1941. The war also brought injustice: Executive Order 9066 (1942) led to the forced removal and incarceration of about 120,000 people of Japanese ancestry, most of them American citizens, which the Supreme Court upheld in Korematsu v. United States (1944). Congress formally apologized and paid reparations in 1988."]],
  ["The war in Europe",[
    "The Allies agreed to defeat Germany first. American forces landed in North Africa in 1942, then invaded Sicily and Italy in 1943. On D-Day, June 6, 1944, under General Dwight D. Eisenhower, Allied forces landed on the beaches of Normandy in the largest seaborne invasion in history and liberated France. After Germany's last major offensive, the Battle of the Bulge (December 1944–January 1945), Allied armies advanced into Germany from the west while the Soviet Union, which bore the heaviest fighting and losses, advanced from the east. Germany surrendered on May 8, 1945, V-E Day.",
    "As American troops liberated concentration camps such as Dachau and Buchenwald, they witnessed the horrors of the Holocaust. Eisenhower ordered the camps documented so no one could later deny what had happened."]],
  ["The war in the Pacific",[
    "In the Pacific, the U.S. Navy's victory at Midway in June 1942 turned the tide against Japan. American forces advanced through “island hopping,” fighting brutal battles at Guadalcanal, Iwo Jima, and Okinawa, while General Douglas MacArthur returned to the Philippines.",
    "The Manhattan Project, a secret program led by physicist J. Robert Oppenheimer and General Leslie Groves, developed the atomic bomb. Roosevelt died in April 1945, and President Harry Truman approved its use. On August 6 and 9, 1945, atomic bombs destroyed Hiroshima and Nagasaki, killing more than 100,000 people immediately and many more afterward. The Soviet Union declared war on Japan on August 8. Japan announced its surrender on August 15 and signed it on September 2, 1945. Historians continue to debate whether the bombings were necessary to end the war."]],
  ["A superpower",[
    "World War II made the United States the world's leading economic and military power. More than 400,000 Americans died, far fewer than the tens of millions of deaths suffered by the Soviet Union, China, Poland, and others. The U.S. led the creation of the United Nations (1945) and of international economic institutions such as the International Monetary Fund and World Bank, created at Bretton Woods in 1944.",
    "At home, the GI Bill (1944) helped millions of veterans attend college and buy homes, building the postwar middle class, though Black veterans were often excluded from its benefits by discriminatory local administration. The war's demands for unity and its fight against racist regimes also strengthened the movement for civil rights."]]
  ],
  terms:[["Lend-Lease","The 1941 program supplying weapons to Allied nations."],["Pearl Harbor","Japan's December 7, 1941 attack that brought the U.S. into the war."],["Executive Order 9066","The 1942 order leading to the incarceration of Japanese Americans."],["D-Day","The June 6, 1944 Allied invasion of Normandy."],["Manhattan Project","The secret program that built the atomic bomb."],["GI Bill","The 1944 law providing education and housing benefits to veterans."]],
  w:"World War II transformed the United States into a superpower and reshaped its economy, society, and role in the world.",
  src:["Lend-Lease","Attack on Pearl Harbor","Internment of Japanese Americans","Normandy landings","Manhattan Project","G.I. Bill"],
  q:[["When did Japan attack Pearl Harbor?","December 7, 1941","June 6, 1944","September 1, 1939","August 6, 1945"],
     ["Which program made the U.S. the “arsenal of democracy”?","Lend-Lease","The Marshall Plan","The New Deal","The GI Bill"],
     ["Which case upheld the incarceration of Japanese Americans?","Korematsu v. United States","Schenck v. United States","Brown v. Board","Ex parte Milligan"],
     ["Which Pacific battle in June 1942 turned the tide against Japan?","Midway","Guadalcanal","Iwo Jima","Okinawa"],
     ["Who led the scientific work of the Manhattan Project?","J. Robert Oppenheimer","Albert Einstein","Enrico Fermi","Leslie Groves"],
     ["Which 1944 law helped veterans attend college and buy homes?","The GI Bill","The Social Security Act","The Wagner Act","The Fair Housing Act"]]},

{ t:"Cold War America", s:"Containment, prosperity, and fear, 1945–1960",
  sec:[
  ["Containment",[
    "After World War II, the wartime alliance between the United States and the Soviet Union collapsed into the Cold War, a long rivalry fought through arms races, alliances, propaganda, and proxy wars rather than direct combat between the superpowers. The U.S. adopted the strategy of containment, proposed by diplomat George Kennan, to prevent the spread of communism.",
    "The Truman Doctrine (1947) pledged aid to countries resisting communism, beginning with Greece and Turkey. The Marshall Plan (1948) provided about $13 billion to rebuild Western Europe. When the Soviets blockaded West Berlin in 1948, the U.S. and Britain supplied the city by air for nearly a year in the Berlin Airlift. In 1949, the U.S. joined its first peacetime military alliance, NATO."]],
  ["Korea and the nuclear age",[
    "In 1949, the Soviet Union tested an atomic bomb and Communists won China's civil war. In June 1950, Communist North Korea invaded South Korea. U.S.-led United Nations forces under MacArthur pushed north until China intervened. Truman fired MacArthur in 1951 for publicly challenging his policy of limited war, asserting civilian control of the military. The war ended in a 1953 armistice near the original border, after about 36,000 American and millions of Korean and Chinese deaths. Korea remains divided.",
    "Both superpowers built hydrogen bombs and missiles, and the doctrine later called “mutually assured destruction” held that nuclear war would destroy both sides. Schoolchildren practiced “duck and cover” drills. The Soviet launch of Sputnik in 1957 spurred the creation of NASA and new federal investment in science education."]],
  ["The Red Scare",[
    "Fear of communist subversion produced a second Red Scare. The House Un-American Activities Committee investigated Hollywood and others, and many people were blacklisted. Spy cases, including the conviction of Alger Hiss for perjury and the execution of Julius and Ethel Rosenberg in 1953 for passing atomic secrets, heightened fears.",
    "Senator Joseph McCarthy of Wisconsin claimed in 1950 to have a list of communists in the State Department and made reckless accusations that ruined careers. During televised hearings in 1954, the Army's lawyer Joseph Welch confronted him: “Have you no sense of decency, sir, at long last?” The Senate censured McCarthy later that year."]],
  ["Affluence and suburbia",[
    "The postwar years brought unprecedented prosperity. The economy grew rapidly, and a baby boom raised the birth rate from 1946 to 1964. Millions of families moved to new suburbs, such as Levittown, New York, built with mass-production techniques and financed by federally backed mortgages. The Federal-Aid Highway Act of 1956, championed by President Eisenhower, created the Interstate Highway System. Television spread to most homes within a decade.",
    "Prosperity was unequal. Federal housing policies, through “redlining,” denied mortgages in Black and mixed neighborhoods, and many suburbs excluded Black families, widening racial gaps in wealth. Michael Harrington's The Other America (1962) exposed persistent poverty. Critics questioned conformity, and rock and roll and the Beat writers expressed youthful restlessness."]],
  ["Eisenhower's America",[
    "Dwight D. Eisenhower (president 1953–1961), the wartime commander, accepted most of the New Deal while promoting moderate “modern Republicanism.” Abroad, he relied on nuclear deterrence and covert operations; the CIA helped overthrow governments in Iran (1953) and Guatemala (1954).",
    "In his 1961 farewell address, Eisenhower warned against the “unwarranted influence” of the “military-industrial complex,” the growing alliance of the armed forces and defense industry. The 1950s also saw the beginnings of the modern civil rights movement, covered in the next chapter."]]
  ],
  terms:[["Containment","The U.S. strategy to prevent the spread of communism."],["Marshall Plan","The 1948 program to rebuild Western Europe."],["NATO","The Western military alliance founded in 1949."],["McCarthyism","Reckless accusations of communist subversion."],["Baby boom","The surge in births from 1946 to 1964."],["Military-industrial complex","Eisenhower's term for the alliance of military and defense industry."]],
  w:"The early Cold War shaped American foreign policy, prosperity, suburbs, and civil liberties for decades.",
  src:["Cold War","Containment","Marshall Plan","Korean War","McCarthyism","Interstate Highway System"],
  q:[["Who proposed the strategy of containment?","George Kennan","Harry Truman","George Marshall","Dean Acheson"],
     ["What was the 1948–1949 operation to supply West Berlin called?","The Berlin Airlift","The Marshall Plan","Operation Overlord","The Truman Doctrine"],
     ["Why did Truman fire MacArthur?","He publicly challenged Truman's policy","He lost the war","He refused to fight","He supported McCarthy"],
     ["Who confronted McCarthy with “Have you no sense of decency”?","Joseph Welch","Edward R. Murrow","Dwight Eisenhower","Margaret Chase Smith"],
     ["Which 1956 law created the Interstate Highway System?","The Federal-Aid Highway Act","The GI Bill","The Housing Act","The Defense Act"],
     ["Who warned against the military-industrial complex?","Dwight Eisenhower","John F. Kennedy","Harry Truman","Douglas MacArthur"]]},

{ t:"Civil Rights and the 1960s", s:"Freedom struggles and upheaval, 1954–1970",
  sec:[
  ["The movement begins",[
    "Building on decades of activism and the NAACP's legal campaign, the modern civil rights movement gained momentum in the 1950s. Brown v. Board of Education (1954) declared school segregation unconstitutional. In 1955, the brutal murder of 14-year-old Emmett Till in Mississippi, and his mother's decision to hold an open-casket funeral, shocked the nation.",
    "In December 1955, Rosa Parks, a seamstress and NAACP activist, was arrested in Montgomery, Alabama, for refusing to give up her bus seat to a white man. The Montgomery Bus Boycott, lasting 381 days, brought the young minister Martin Luther King Jr. to leadership and ended with a Supreme Court ruling against bus segregation. In 1957, President Eisenhower sent federal troops to protect nine Black students integrating Little Rock Central High School in Arkansas."]],
  ["Direct action",[
    "In 1960, four Black college students sat at a segregated Woolworth's lunch counter in Greensboro, North Carolina, launching a wave of sit-ins. Students formed the Student Nonviolent Coordinating Committee (SNCC), with the guidance of the organizer Ella Baker. In 1961, Freedom Riders rode interstate buses into the South to challenge segregated terminals and were attacked by mobs.",
    "In Birmingham, Alabama, in 1963, police used fire hoses and dogs against marching children, images that shocked the world; King wrote his Letter from Birmingham Jail. In August 1963, the March on Washington drew about 250,000 people, where King delivered his “I Have a Dream” speech. Violence continued: the civil rights leader Medgar Evers was assassinated in 1963, four girls were killed in the bombing of Birmingham's 16th Street Baptist Church, and President John F. Kennedy was assassinated in Dallas on November 22, 1963."]],
  ["Landmark laws",[
    "President Lyndon B. Johnson used his legislative skill to pass the Civil Rights Act of 1964, which banned discrimination in public accommodations and employment. During the 1964 “Freedom Summer,” volunteers registering Black voters in Mississippi faced violence, including the murder of three civil rights workers. In March 1965, state troopers beat marchers on Selma's Edmund Pettus Bridge on “Bloody Sunday,” including the future congressman John Lewis.",
    "Days later, Johnson called for a voting rights law, and the Voting Rights Act of 1965 suspended literacy tests and authorized federal oversight of elections in places with histories of discrimination; Black voter registration in the South soared. The Immigration and Nationality Act of 1965 abolished the national-origin quotas of 1924, transforming American immigration. Johnson's Great Society programs created Medicare and Medicaid and launched a “War on Poverty.”"]],
  ["Vietnam",[
    "The U.S. had supported France and then South Vietnam against Communist forces in Vietnam. After the Gulf of Tonkin incident in 1964, Congress authorized Johnson to use force, and U.S. troop levels rose to over 500,000 by 1968. The war became a bloody stalemate. The Tet Offensive of January 1968, though a military defeat for North Vietnam, shattered public confidence in official claims of progress.",
    "A massive antiwar movement grew, especially on campuses. Johnson declined to seek reelection in 1968. The war continued under President Richard Nixon, who gradually withdrew troops while expanding bombing into Cambodia. At Kent State University in 1970, National Guard troops killed four students during a protest. U.S. forces withdrew in 1973, and Saigon fell to North Vietnam in 1975. About 58,000 Americans and millions of Vietnamese, Cambodians, and Laotians died."]],
  ["1968 and new movements",[
    "The year 1968 was one of the most turbulent in American history: the Tet Offensive; the assassinations of Martin Luther King Jr. in April, followed by riots in many cities, and of Senator Robert F. Kennedy in June; violent clashes at the Democratic National Convention in Chicago; and Nixon's election on a promise of “law and order.”",
    "The decade also saw new movements. Malcolm X, before his assassination in 1965, and later Black Power advocates emphasized self-defense, pride, and independence. César Chávez and Dolores Huerta organized farmworkers. The women's movement revived, with Betty Friedan's The Feminine Mystique (1963) and the founding of the National Organization for Women (1966). The Stonewall uprising in New York (1969) launched the modern gay rights movement. Native American activists occupied Alcatraz (1969). A counterculture challenged traditional values, and the Apollo 11 Moon landing in July 1969 showed American technological power."]]
  ],
  terms:[["Montgomery Bus Boycott","The 381-day boycott that began with Rosa Parks' arrest."],["Sit-ins","Nonviolent protests at segregated lunch counters, beginning in 1960."],["March on Washington","The 1963 march where King gave his “I Have a Dream” speech."],["Civil Rights Act of 1964","The law banning discrimination in public accommodations and employment."],["Voting Rights Act of 1965","The law ending literacy tests and protecting Black voting rights."],["Tet Offensive","The 1968 North Vietnamese offensive that undermined support for the war."]],
  w:"The civil rights movement and the 1960s transformed American law, politics, and society, and their legacies remain central to American life.",
  src:["Civil rights movement","Montgomery bus boycott","March on Washington for Jobs and Freedom","Selma to Montgomery marches","Vietnam War","1968 in the United States"],
  q:[["How long did the Montgomery Bus Boycott last?","381 days","30 days","One year exactly","Two years"],
     ["Where did the lunch-counter sit-ins begin in 1960?","Greensboro, North Carolina","Birmingham, Alabama","Montgomery, Alabama","Atlanta, Georgia"],
     ["What event happened on Selma's Edmund Pettus Bridge in 1965?","Bloody Sunday","The March on Washington","Freedom Summer","The Freedom Rides"],
     ["Which 1965 law abolished national-origin immigration quotas?","The Immigration and Nationality Act","The Voting Rights Act","The Civil Rights Act","The McCarran-Walter Act"],
     ["Which 1968 offensive undermined public support for the Vietnam War?","The Tet Offensive","The Gulf of Tonkin","Dien Bien Phu","Operation Rolling Thunder"],
     ["Which 1969 uprising launched the modern gay rights movement?","Stonewall","Kent State","Alcatraz","Woodstock"]]},

{ t:"From Watergate to the Present", s:"The United States since 1970",
  sec:[
  ["The 1970s",[
    "President Nixon opened relations with Communist China, visiting Beijing in 1972, and pursued détente with the Soviet Union, including arms control agreements. He also created the Environmental Protection Agency (1970). But the Watergate scandal, which began with a 1972 break-in at Democratic headquarters and involved a cover-up by the White House, led to his resignation on August 9, 1974, the only presidential resignation in U.S. history. The Supreme Court's unanimous ruling in United States v. Nixon forced the release of tapes that revealed his role in the cover-up.",
    "The decade brought economic trouble: the 1973 oil embargo, gasoline lines, and “stagflation,” combined inflation and unemployment. President Jimmy Carter brokered the Camp David Accords (1978) between Egypt and Israel. In 1979, Iranian revolutionaries seized the U.S. embassy in Tehran and held 52 Americans hostage for 444 days, contributing to Carter's defeat in 1980. Roe v. Wade (1973) legalized abortion nationwide, and the Equal Rights Amendment passed Congress but fell short of ratification."]],
  ["The Reagan era and the end of the Cold War",[
    "Ronald Reagan (president 1981–1989) championed a conservative movement that combined free-market economics, tax cuts, deregulation, a military buildup, and social conservatism. Inflation fell, the economy grew, and the federal deficit rose. Reagan called the Soviet Union an “evil empire” but later negotiated arms reductions with the reformist Soviet leader Mikhail Gorbachev. His administration was damaged by the Iran-Contra affair, involving secret arms sales to Iran with proceeds funneled to Nicaraguan rebels.",
    "The Berlin Wall fell in November 1989, and the Soviet Union dissolved in December 1991, ending the Cold War. Under President George H. W. Bush, the U.S. led a coalition that expelled Iraq from Kuwait in the 1991 Gulf War."]],
  ["The 1990s",[
    "President Bill Clinton (1993–2001) presided over a long economic expansion fueled by the internet and technology boom, signed the North American Free Trade Agreement (NAFTA), and, with a Republican Congress, enacted welfare reform and balanced budgets. He was impeached by the House in 1998 over perjury and obstruction related to a personal scandal and acquitted by the Senate in 1999.",
    "The disputed 2000 election between George W. Bush and Al Gore was decided when the Supreme Court halted a Florida recount in Bush v. Gore. The internet and personal computers transformed communication, commerce, and culture."]],
  ["September 11 and the 2000s",[
    "On September 11, 2001, al-Qaeda terrorists hijacked four airliners, crashing two into the World Trade Center in New York and one into the Pentagon; the fourth crashed in Pennsylvania after passengers fought back. Nearly 3,000 people died. The U.S. invaded Afghanistan in 2001 to topple the Taliban, which had sheltered al-Qaeda, and in 2003 invaded Iraq, citing weapons of mass destruction that were never found. The wars lasted for years; U.S. forces withdrew from Afghanistan in 2021, and the Taliban returned to power. Osama bin Laden was killed by U.S. forces in Pakistan in 2011.",
    "The government expanded surveillance and security powers through the USA PATRIOT Act and created the Department of Homeland Security. In 2008, a housing bubble and risky financial practices triggered the worst financial crisis since the Great Depression, the Great Recession."]],
  ["Recent decades",[
    "In 2008, Barack Obama became the first Black president. His administration passed the Affordable Care Act (2010), expanding health insurance, and steered recovery from the recession. In Obergefell v. Hodges (2015), the Supreme Court recognized same-sex marriage nationwide. Political polarization deepened. Donald Trump, a businessman and television personality, won the 2016 election on a populist and nationalist platform; he was impeached twice by the House and acquitted both times by the Senate.",
    "The COVID-19 pandemic, beginning in 2020, killed more than a million Americans and disrupted the economy. The murder of George Floyd by a Minneapolis police officer in May 2020 sparked mass protests. After losing the 2020 election to Joe Biden, Trump disputed the result, and on January 6, 2021, a mob of his supporters stormed the U.S. Capitol. The Supreme Court's Dobbs decision (2022) overturned Roe v. Wade. Trump won the 2024 election and returned to the presidency in January 2025. Debates over democracy, inequality, immigration, technology, and America's role in the world remain at the center of national life, and their history is still being written."]]
  ],
  terms:[["Watergate","The scandal that led to Nixon's 1974 resignation."],["Stagflation","Simultaneous inflation and economic stagnation."],["Iran hostage crisis","The 1979–1981 detention of 52 Americans in Tehran."],["End of the Cold War","The fall of the Berlin Wall in 1989 and the Soviet collapse in 1991."],["September 11 attacks","The 2001 al-Qaeda attacks that killed nearly 3,000 people."],["Great Recession","The financial crisis and downturn beginning in 2007–2008."]],
  w:"Recent American history explains the political divisions, institutions, and global position of the United States today.",
  src:["Watergate scandal","Iran hostage crisis","Reagan era","September 11 attacks","Great Recession","January 6 United States Capitol attack"],
  q:[["Which president resigned in 1974?","Richard Nixon","Gerald Ford","Lyndon Johnson","Jimmy Carter"],
     ["How long were the American hostages held in Iran?","444 days","100 days","One year","Two years"],
     ["Which Soviet leader negotiated arms reductions with Reagan?","Mikhail Gorbachev","Leonid Brezhnev","Boris Yeltsin","Nikita Khrushchev"],
     ["Which case decided the 2000 election?","Bush v. Gore","Roe v. Wade","Citizens United v. FEC","United States v. Nixon"],
     ["When did U.S. forces withdraw from Afghanistan?","2021","2011","2014","2001"],
     ["Who became the first Black U.S. president in 2008?","Barack Obama","Colin Powell","Jesse Jackson","Kamala Harris"]]}
);


/* ---- from hist-12.js ---- */
/* HISTORY FOUNDATIONS, part 12: Unit 8 (The Twentieth Century and Beyond), chapters 1-5 */
COURSES.history.units.push({ t:"The Twentieth Century and Beyond", ch:[

{ t:"The First World War", s:"The war that ended the old world, 1914–1918",
  sec:[
  ["Long-term causes",[
    "Historians often summarize the deep causes of the First World War with four words: militarism, alliances, imperialism, and nationalism. The great powers had built huge conscript armies and detailed mobilization plans; Britain and Germany were locked in a naval arms race after Germany began building a battle fleet to rival the Royal Navy. Colonial rivalries, such as the Moroccan crises of 1905 and 1911, repeatedly brought the powers close to war.",
    "By 1914 Europe was divided into two blocs. The Triple Alliance joined Germany, Austria-Hungary, and Italy. The Triple Entente linked France, Russia, and Britain, though Britain's commitment was informal. Nationalism was most explosive in the Balkans, where the decline of the Ottoman Empire had produced new states such as Serbia, and where the multinational Austro-Hungarian Empire feared that South Slav nationalism, backed by Serbia and Russia, would tear it apart. The Balkan Wars of 1912–1913 left Serbia enlarged and Austria alarmed."]],
  ["The July Crisis",[
    "On 28 June 1914, Gavrilo Princip, a young Bosnian Serb linked to the secret Serbian nationalist society known as the Black Hand, assassinated Archduke Franz Ferdinand, heir to the Austro-Hungarian throne, in Sarajevo. Austria-Hungary, assured of German support (the so-called “blank check”), sent Serbia a harsh ultimatum and declared war on 28 July.",
    "The alliance system turned a local war into a continental one within days. Russia mobilized to support Serbia; Germany declared war on Russia (1 August) and France (3 August). Germany's Schlieffen Plan called for knocking France out quickly by marching through neutral Belgium before turning east. The invasion of Belgium brought Britain into the war on 4 August. The Ottoman Empire joined the Central Powers in late 1914 and Bulgaria in 1915; Italy, despite its earlier alliance, joined the Allies in 1915."]],
  ["The Western Front and total war",[
    "The German advance was stopped at the First Battle of the Marne in September 1914. Both sides then dug in, and a line of trenches soon stretched from the North Sea to Switzerland. Machine guns, barbed wire, and massed artillery gave defenders a huge advantage. Generals launched offensives that cost hundreds of thousands of lives for a few miles of ground: at Verdun (1916) the French and Germans suffered roughly 700,000 combined casualties, and on the first day of the Somme (1 July 1916) the British army suffered about 57,000 casualties, including some 19,000 dead.",
    "New weapons appeared: poison gas (first used on a large scale by Germany at Ypres in 1915), tanks (introduced by Britain in 1916), airplanes, and submarines. It was a total war: governments took control of economies, rationed food, conscripted millions, used propaganda, and drew women into factories and services in unprecedented numbers."]],
  ["A world war",[
    "The war was fought far beyond the Western Front. On the Eastern Front, armies moved over vast distances; Germany crushed a Russian army at Tannenberg in 1914, but Russia's losses and hardships mounted until revolution broke out in 1917. The Allied attempt to knock the Ottomans out of the war at Gallipoli (1915–1916), in which Australian and New Zealand (ANZAC) troops played a major role, failed. In the Middle East, Britain encouraged an Arab revolt against the Ottomans, while fighting also took place in Africa and at sea.",
    "Colonial empires mobilized their subjects: over a million Indian soldiers served Britain, and France recruited heavily in West and North Africa. Within the Ottoman Empire, the government carried out the Armenian Genocide beginning in 1915, killing roughly one million or more Armenians through massacres and death marches."]],
  ["America enters and the war ends",[
    "Germany's unrestricted submarine warfare, including the sinking of the liner Lusitania in 1915 and the resumption of unrestricted attacks in 1917, along with the Zimmermann Telegram proposing a German alliance with Mexico, brought the United States into the war in April 1917. Meanwhile, Russia's new Bolshevik government left the war through the Treaty of Brest-Litovsk (March 1918), giving up vast territories.",
    "Germany's final spring offensive of 1918 failed, and fresh American troops helped the Allies push back in the Hundred Days Offensive. Germany's allies collapsed, mutinies and revolution broke out at home, and the Kaiser abdicated. The armistice took effect at 11 a.m. on 11 November 1918. About 9 to 10 million soldiers died, along with millions of civilians, and the influenza pandemic of 1918–1919 killed tens of millions more worldwide."]],
  ["The peace settlement",[
    "At the Paris Peace Conference of 1919, the “Big Four” leaders, Woodrow Wilson, David Lloyd George of Britain, Georges Clemenceau of France, and Vittorio Orlando of Italy, dominated. The Treaty of Versailles forced Germany to accept responsibility for the war in the “war guilt clause” (Article 231), pay reparations, give up territory including Alsace-Lorraine and its colonies, and limit its army to 100,000 men. Many Germans saw it as a humiliating dictated peace.",
    "Four empires had collapsed: the German, Austro-Hungarian, Russian, and Ottoman. New states such as Poland, Czechoslovakia, and Yugoslavia emerged, partly on Wilson's principle of national self-determination. Wilson's Fourteen Points inspired the League of Nations, but the U.S. Senate rejected the treaty and the United States never joined. The Ottoman Arab lands were divided into British and French mandates, planting conflicts that would shape the Middle East."]]
  ],
  terms:[["Triple Entente","The informal alignment of France, Russia, and Britain before 1914."],["Schlieffen Plan","Germany's plan to defeat France quickly by invading through Belgium."],["Trench warfare","Static fighting from fortified ditches that dominated the Western Front."],["Total war","A war in which entire societies and economies are mobilized."],["Armenian Genocide","The Ottoman government's mass killing of Armenians beginning in 1915."],["Treaty of Versailles","The 1919 peace treaty imposed on Germany."],["League of Nations","The international organization created after WWI to keep the peace."]],
  w:"World War I destroyed four empires, killed millions, redrew the maps of Europe and the Middle East, and set the stage for revolution, fascism, and a second world war.",
  src:["World War I","July Crisis","Assassination of Archduke Franz Ferdinand","Battle of the Somme","Armenian genocide","Treaty of Versailles"],
  q:[["Who assassinated Archduke Franz Ferdinand in 1914?","Gavrilo Princip","Leon Czolgosz","Dragutin Dimitrijević","Lajos Kossuth"],
     ["What brought Britain into the war in August 1914?","Germany's invasion of neutral Belgium","The sinking of the Lusitania","The Zimmermann Telegram","The Russian Revolution"],
     ["Which 1914 battle halted the German advance on Paris?","The First Battle of the Marne","Verdun","The Somme","Tannenberg"],
     ["The failed 1915–1916 Allied campaign against the Ottomans took place where?","Gallipoli","Verdun","Ypres","Tannenberg"],
     ["Which treaty took Bolshevik Russia out of the war?","Brest-Litovsk","Versailles","Trianon","Sèvres"],
     ["Which article of the Treaty of Versailles is known as the war guilt clause?","Article 231","Article 10","Article 1","Article 48"]]},

{ t:"The Russian Revolution and the Soviet Union", s:"From tsars to Stalin, 1905–1953",
  sec:[
  ["Russia before the revolution",[
    "In 1900 Russia was a vast autocracy ruled by Tsar Nicholas II of the Romanov dynasty. Most people were peasants, freed from serfdom only in 1861 and still poor and land-hungry. Rapid state-sponsored industrialization in the 1890s created a small but concentrated working class in cities such as St. Petersburg and Moscow. Revolutionary parties grew, including the Marxist Social Democrats, which split in 1903 into Vladimir Lenin's Bolsheviks, who wanted a disciplined party of professional revolutionaries, and the more moderate Mensheviks.",
    "Defeat in the Russo-Japanese War (1904–1905) and the “Bloody Sunday” massacre of peaceful petitioners in January 1905 triggered the Revolution of 1905. Nicholas granted a parliament, the Duma, in the October Manifesto, but soon restricted its powers. Prime Minister Pyotr Stolypin combined land reform with harsh repression."]],
  ["1917: two revolutions",[
    "World War I overwhelmed Russia. Millions of soldiers were killed or captured, food and fuel ran short, and the court was discredited, partly by the influence of the mystic Grigori Rasputin. In the February Revolution of 1917 (March by the Western calendar), strikes and bread riots in Petrograd, joined by mutinying soldiers, forced Nicholas to abdicate. A Provisional Government took power, but it shared authority with the Petrograd Soviet, a council of workers' and soldiers' deputies.",
    "The Provisional Government, later led by Alexander Kerensky, kept fighting the war and postponed land reform. Lenin, returning from exile with German help, promised “Peace, Land, and Bread” and “All Power to the Soviets.” In the October Revolution (November 1917), the Bolsheviks, with Leon Trotsky organizing, seized power in Petrograd in a largely bloodless coup. When an elected Constituent Assembly met in January 1918 with a non-Bolshevik majority, Lenin dissolved it."]],
  ["Civil war and the new state",[
    "From 1918 to about 1921, the Bolshevik Reds fought a brutal civil war against the Whites, a loose coalition of monarchists, liberals, and others, supported by foreign intervention, and against nationalist and peasant movements. Trotsky built the Red Army. The secret police, the Cheka, carried out the Red Terror; the Bolsheviks executed Nicholas II and his family in July 1918. Under “War Communism,” the state seized grain and nationalized industry, contributing to famine.",
    "Facing economic collapse and the Kronstadt sailors' revolt of 1921, Lenin introduced the New Economic Policy (NEP), allowing small private trade and farming. In 1922 the Union of Soviet Socialist Republics (USSR) was formed as a federation of republics, though real power lay with the Communist Party, the only legal party."]],
  ["Stalin's rise and the Five-Year Plans",[
    "After Lenin's death in 1924, Joseph Stalin, the party's General Secretary, used control of party appointments to outmaneuver rivals, above all Trotsky, who was expelled and later murdered in Mexico in 1940. Stalin championed “socialism in one country” over Trotsky's international revolution.",
    "From 1928, Stalin ended the NEP and launched Five-Year Plans to industrialize at breakneck speed, building steel mills, dams, and new industrial cities. Agriculture was forcibly collectivized into state and collective farms. Peasants who resisted, labeled kulaks, were deported or killed. Collectivization and grain requisitioning caused the famine of 1932–1933, which killed millions; in Ukraine, where it is known as the Holodomor, roughly 3.5 to 5 million died."]],
  ["Terror and the Gulag",[
    "In the Great Terror of 1936–1938, Stalin's secret police, the NKVD, arrested well over a million people. Old Bolshevik leaders confessed to absurd crimes in public show trials, and the military leadership was purged. Roughly 680,000 to 750,000 people were executed in 1937–1938 alone. Millions passed through the Gulag, a vast system of forced-labor camps.",
    "At the same time, the regime promoted literacy, mass education, and social mobility, and propaganda built a cult of personality around Stalin. Art was required to follow “socialist realism.” This mix of real modernization and enormous violence remains central to debates about the Soviet experience."]],
  ["War and the postwar USSR",[
    "In August 1939 Stalin signed the Nazi-Soviet (Molotov-Ribbentrop) Pact with Hitler, which secretly divided Eastern Europe into spheres. Germany invaded the USSR in June 1941. The Soviet Union bore the heaviest burden of the war in Europe, losing an estimated 27 million people, and its victories at Moscow, Stalingrad, and Kursk turned the tide.",
    "The USSR emerged from the war as a superpower controlling Eastern Europe. Stalin's final years saw renewed repression until his death in 1953. His successor Nikita Khrushchev denounced Stalin's crimes in the “Secret Speech” of 1956, released many prisoners, and began a partial thaw, though the one-party system remained."]]
  ],
  terms:[["Bolsheviks","Lenin's faction of Russian Marxists, later the Communist Party."],["Soviet","A council of workers' and soldiers' deputies."],["October Revolution","The Bolshevik seizure of power in 1917."],["New Economic Policy","Lenin's 1921 partial return to private trade."],["Collectivization","The forced merger of peasant farms into state-controlled collectives."],["Holodomor","The 1932–1933 famine in Soviet Ukraine."],["Gulag","The Soviet system of forced-labor camps."]],
  w:"The Russian Revolution created the world's first communist state, whose model of one-party rule and state planning shaped much of the 20th century, and whose terror remains a warning.",
  src:["Russian Revolution","Vladimir Lenin","Russian Civil War","Joseph Stalin","Holodomor","Great Purge","Gulag"],
  q:[["Which faction did Lenin lead?","The Bolsheviks","The Mensheviks","The Socialist Revolutionaries","The Kadets"],
     ["What slogan did Lenin use in 1917?","Peace, Land, and Bread","Liberty, Equality, Fraternity","Workers of the world, unite","Socialism in one country"],
     ["Who organized the Red Army during the Russian Civil War?","Leon Trotsky","Joseph Stalin","Alexander Kerensky","Nikolai Bukharin"],
     ["What policy allowed limited private trade in 1921?","The New Economic Policy","War Communism","The Five-Year Plan","Perestroika"],
     ["What is the Ukrainian famine of 1932–1933 called?","The Holodomor","The Gulag","The Great Terror","The Thaw"],
     ["Who denounced Stalin in the 1956 Secret Speech?","Nikita Khrushchev","Leonid Brezhnev","Georgy Malenkov","Lavrentiy Beria"]]},

{ t:"The Interwar Years and the Rise of Fascism", s:"Democracy in crisis, 1919–1939",
  sec:[
  ["A fragile peace",[
    "The 1920s began with hope. The League of Nations was founded, and the Locarno Treaties (1925) seemed to reconcile Germany with France. The Kellogg-Briand Pact (1928) renounced war as an instrument of policy. But the postwar world was unstable. Germany's new Weimar Republic faced uprisings from left and right and hyperinflation in 1923, when the mark became nearly worthless and middle-class savings were wiped out.",
    "Women won the vote in many countries, including Britain (partially in 1918), Germany, and the United States, and mass culture grew through radio, cinema, and jazz. But the war had left bitterness, unemployment, and millions of veterans used to violence."]],
  ["The Great Depression",[
    "The Wall Street Crash of October 1929 triggered the Great Depression, the worst economic crisis of modern times. American banks recalled loans from Europe, world trade collapsed as countries raised tariffs, and unemployment soared: by 1932 roughly a quarter of American workers and about six million Germans were jobless.",
    "The Depression discredited liberal democracy and free-market capitalism for many people and strengthened extremist parties. Democracies responded in different ways, from the New Deal in the United States to the coalition National Government in Britain and the Popular Front in France, while new economic ideas, notably those of John Maynard Keynes, argued for government spending to fight unemployment."]],
  ["What was fascism?",[
    "Fascism was a new political movement of the interwar era. It glorified the nation and often a racial community, rejected liberalism, democracy, and Marxism, celebrated violence, youth, and war, and demanded a single party led by a charismatic leader. It promised national rebirth after humiliation and decline. Fascists mobilized the masses through rallies, uniforms, and propaganda, and they often won support from elites who feared communism.",
    "The word comes from Italy, where Benito Mussolini, a former socialist, founded the Fascist movement in 1919. His Blackshirts attacked socialists and unions, and after the “March on Rome” in 1922, King Victor Emmanuel III appointed him prime minister. By 1925–1926 he had made Italy a one-party dictatorship. He signed the Lateran Treaty with the Catholic Church in 1929 and invaded Ethiopia in 1935–1936."]],
  ["Hitler and Nazi Germany",[
    "Adolf Hitler, an Austrian-born veteran, led the National Socialist German Workers' (Nazi) Party. After a failed coup, the Beer Hall Putsch of 1923, he wrote Mein Kampf in prison, setting out his racial antisemitism and his demand for “living space” (Lebensraum) in the east. The Depression made the Nazis the largest party in the Reichstag in July 1932, and in January 1933 conservative politicians persuaded President Paul von Hindenburg to appoint Hitler chancellor, believing they could control him.",
    "Hitler quickly built a dictatorship. After the Reichstag fire, the Enabling Act of March 1933 allowed him to rule by decree. Other parties and trade unions were abolished, and in the Night of the Long Knives (1934) he purged rivals in his own movement. The Gestapo and the SS enforced terror, and concentration camps such as Dachau held political opponents. The Nuremberg Laws of 1935 stripped Jews of citizenship, and on Kristallnacht in November 1938, mobs burned synagogues and attacked Jewish homes and businesses."]],
  ["Militarism in Japan and the road to war",[
    "Japan, hit hard by the Depression, came under the growing influence of the military. In 1931 Japanese officers staged an incident to justify seizing Manchuria, where Japan created the puppet state of Manchukuo. When the League of Nations condemned this, Japan left the League. In 1937 Japan launched a full-scale war against China. Japanese troops massacred civilians and prisoners in the Nanjing Massacre (1937–1938).",
    "In Europe, Hitler rearmed in defiance of Versailles and remilitarized the Rhineland in 1936. Germany and Italy aided Francisco Franco's Nationalists in the Spanish Civil War (1936–1939), while the Soviet Union aided the Republicans. Germany, Italy, and Japan drew together in what became the Axis."]],
  ["Appeasement",[
    "Britain and France, haunted by the losses of World War I and focused on their economic problems, followed a policy of appeasement, making concessions to avoid war. In March 1938 Germany annexed Austria (the Anschluss). At the Munich Conference in September 1938, Britain's Neville Chamberlain and France's Édouard Daladier agreed to let Hitler take the Sudetenland from Czechoslovakia; Chamberlain claimed he had secured “peace for our time.”",
    "In March 1939, Hitler seized the rest of Czech lands, ending appeasement. Britain and France guaranteed Poland. In August 1939, the Nazi-Soviet Pact shocked the world and freed Hitler to attack Poland without fear of a two-front war. On 1 September 1939 Germany invaded Poland, and Britain and France declared war two days later."]]
  ],
  terms:[["Weimar Republic","Germany's democratic government from 1919 to 1933."],["Hyperinflation","Extremely rapid price increases, as in Germany in 1923."],["Fascism","An ultranationalist, authoritarian movement rejecting democracy and Marxism."],["March on Rome","The 1922 event that brought Mussolini to power."],["Enabling Act","The 1933 law that let Hitler rule by decree."],["Kristallnacht","The November 1938 Nazi pogrom against German Jews."],["Appeasement","The policy of conceding to aggressive demands to avoid war."]],
  w:"The interwar years show how democracies can collapse under economic crisis and how fascism used fear and resentment to win power, lessons that remain urgent.",
  src:["Interwar period","Great Depression","Fascism","Benito Mussolini","Nazi Germany","Munich Agreement","Japanese invasion of Manchuria"],
  q:[["In what year did hyperinflation peak in Germany?","1923","1919","1929","1933"],
     ["Which economist argued for government spending to fight unemployment?","John Maynard Keynes","Friedrich Hayek","Milton Friedman","Adam Smith"],
     ["What event brought Mussolini to power in 1922?","The March on Rome","The Beer Hall Putsch","The Reichstag fire","The Lateran Treaty"],
     ["What 1933 law allowed Hitler to rule by decree?","The Enabling Act","The Nuremberg Laws","The Weimar Constitution","The Anschluss"],
     ["Which region did Japan seize in 1931?","Manchuria","Korea","Taiwan","Indochina"],
     ["At which 1938 conference did Britain and France allow Germany to take the Sudetenland?","Munich","Locarno","Yalta","Versailles"]]},

{ t:"The Second World War", s:"The deadliest conflict in history, 1939–1945",
  sec:[
  ["Blitzkrieg and the fall of France",[
    "Germany conquered Poland in weeks in 1939 using Blitzkrieg (“lightning war”), combining tanks, motorized infantry, and aircraft. The Soviet Union invaded eastern Poland under its pact with Hitler. After a quiet winter, the so-called Phoney War, Germany overran Denmark and Norway in April 1940 and then struck the Netherlands, Belgium, and France in May.",
    "German armored forces broke through the Ardennes and reached the English Channel. Over 330,000 British and French troops were evacuated from Dunkirk. France surrendered in June 1940; Germany occupied the north, and a collaborationist regime under Marshal Philippe Pétain ruled from Vichy. General Charles de Gaulle led the Free French from London. Italy entered the war on Germany's side."]],
  ["Britain alone",[
    "Winston Churchill, who became British prime minister in May 1940, vowed never to surrender. In the Battle of Britain (summer and autumn 1940), the Royal Air Force, aided by radar, defeated the German air force's attempt to gain air superiority for an invasion. German bombing of British cities, the Blitz, continued into 1941.",
    "The Battle of the Atlantic, fought between German U-boats and Allied convoys, lasted the entire war and was vital to Britain's survival. The United States, though neutral, supplied Britain through the Lend-Lease Act of 1941. Fighting also raged in North Africa, where Erwin Rommel's Afrika Korps fought British Commonwealth forces."]],
  ["The war in the East",[
    "On 22 June 1941, Germany invaded the Soviet Union in Operation Barbarossa, the largest invasion in history. German forces advanced rapidly, besieging Leningrad (a siege that lasted nearly 900 days and killed around a million civilians) and reaching the outskirts of Moscow before being stopped in December 1941.",
    "The war in the East was a war of annihilation, aimed at destroying “Judeo-Bolshevism” and enslaving Slavic peoples. The turning point came at Stalingrad (August 1942 to February 1943), where the Soviet army encircled and destroyed the German Sixth Army. After the Battle of Kursk (July 1943), the largest tank battle in history, the Red Army advanced steadily westward."]],
  ["The Pacific War",[
    "Japan, seeking resources and facing an American oil embargo, attacked the U.S. Pacific Fleet at Pearl Harbor, Hawaii, on 7 December 1941, and simultaneously struck the Philippines, Malaya, and Hong Kong. Germany then declared war on the United States. Japan quickly conquered Southeast Asia, including Singapore, the Dutch East Indies, and Burma.",
    "The U.S. Navy's victory at Midway in June 1942, in which four Japanese aircraft carriers were sunk, turned the tide. The Americans then advanced through the Pacific by “island hopping,” fighting brutal battles at Guadalcanal, Iwo Jima, and Okinawa, while British and Indian forces fought in Burma and Chinese forces kept much of the Japanese army tied down in China."]],
  ["Allied victory in Europe",[
    "The Allies, led by the “Big Three” (Churchill, Franklin D. Roosevelt, and Stalin), coordinated strategy at conferences such as Tehran (1943) and Yalta (February 1945). Allied forces drove the Axis from North Africa after El Alamein (1942), invaded Sicily and Italy in 1943, and toppled Mussolini. Allied strategic bombing devastated German cities.",
    "On D-Day, 6 June 1944, Allied forces under General Dwight D. Eisenhower landed in Normandy, opening a second front. Paris was liberated in August. Germany's last major offensive, the Battle of the Bulge (December 1944), failed. Soviet forces captured Berlin; Hitler killed himself on 30 April 1945, and Germany surrendered unconditionally, with Victory in Europe (V-E) Day on 8 May 1945."]],
  ["The atomic bomb and the cost of the war",[
    "With Japan refusing to surrender, the United States dropped atomic bombs on Hiroshima (6 August 1945) and Nagasaki (9 August), killing well over 100,000 people by the end of 1945. The Soviet Union declared war on Japan on 8 August. Japan announced its surrender on 15 August and signed the formal instrument on 2 September 1945. The decision to use the bomb remains debated.",
    "World War II killed an estimated 70 to 85 million people, most of them civilians, including the victims of the Holocaust, the Chinese killed in Japan's war, and civilians killed by bombing. The war left Europe and East Asia devastated, began the atomic age, created the United Nations (1945), and launched war-crimes trials at Nuremberg and Tokyo. It left the United States and the Soviet Union as rival superpowers."]]
  ],
  terms:[["Blitzkrieg","Fast-moving warfare combining tanks and aircraft."],["Vichy France","The collaborationist French regime under Pétain."],["Battle of Britain","The 1940 air battle that prevented a German invasion of Britain."],["Operation Barbarossa","Germany's 1941 invasion of the Soviet Union."],["Stalingrad","The 1942–1943 battle that turned the tide on the Eastern Front."],["D-Day","The Allied invasion of Normandy on 6 June 1944."],["Midway","The 1942 naval battle that turned the Pacific War."]],
  w:"World War II was the largest and deadliest war in history, and its outcome created the postwar world order, from the United Nations to the Cold War.",
  src:["World War II","Battle of Britain","Operation Barbarossa","Battle of Stalingrad","Attack on Pearl Harbor","Normandy landings","Atomic bombings of Hiroshima and Nagasaki"],
  q:[["Who led the collaborationist Vichy regime in France?","Philippe Pétain","Charles de Gaulle","Pierre Laval","Édouard Daladier"],
     ["What helped the RAF win the Battle of Britain?","Radar","Jet fighters","Atomic weapons","Aircraft carriers"],
     ["What was the code name for Germany's 1941 invasion of the USSR?","Operation Barbarossa","Operation Overlord","Operation Sea Lion","Operation Torch"],
     ["Which 1942 naval battle turned the tide in the Pacific?","Midway","Coral Sea","Leyte Gulf","Okinawa"],
     ["On what date was D-Day?","6 June 1944","7 December 1941","8 May 1945","1 September 1939"],
     ["Which conference of the Big Three took place in February 1945?","Yalta","Tehran","Potsdam","Casablanca"]]},

{ t:"The Holocaust", s:"Genocide in the heart of Europe, 1933–1945",
  sec:[
  ["Antisemitism and Nazi ideology",[
    "The Holocaust was the systematic, state-sponsored persecution and murder of six million European Jews by Nazi Germany and its allies and collaborators between 1933 and 1945. It grew out of centuries of religious hostility toward Jews in Christian Europe, but Nazi antisemitism was racial: it defined Jews as a biologically distinct and dangerous race, regardless of religion or assimilation, and blamed them for Germany's defeat in 1918, for communism, and for capitalism alike.",
    "Nazi ideology imagined a racial hierarchy with “Aryans” at the top. Besides Jews, the Nazis persecuted and murdered Roma and Sinti, people with disabilities, Polish and Soviet civilians, Soviet prisoners of war, political opponents, Jehovah's Witnesses, and gay men."]],
  ["Persecution, 1933–1939",[
    "Persecution began immediately in 1933 with a boycott of Jewish businesses and the expulsion of Jews from the civil service. The Nuremberg Laws of 1935 stripped Jews of citizenship and banned marriage between Jews and non-Jews. Jews were progressively excluded from professions, schools, and public life, and their property was seized through “Aryanization.”",
    "The Kristallnacht pogrom of 9–10 November 1938 marked an escalation: synagogues were burned, Jewish shops smashed, around 30,000 Jewish men were sent to concentration camps, and many were killed. Many Jews tried to emigrate, but most countries limited refugees; at the Évian Conference of 1938, few nations agreed to take more."]],
  ["Ghettos and mass shootings",[
    "After conquering Poland in 1939, the Germans forced Jews into ghettos, such as those in Warsaw and Łódź, where overcrowding, starvation, and disease killed many thousands. In 1943 the Jews of the Warsaw Ghetto rose in armed revolt, holding out for nearly a month before being crushed.",
    "With the invasion of the Soviet Union in 1941, mobile killing units called Einsatzgruppen, along with police battalions, local collaborators, and army units, shot Jews in mass executions. At Babi Yar near Kyiv, nearly 34,000 Jews were murdered in two days in September 1941. By the end of the war, around 1.5 to 2 million Jews had been killed by shooting."]],
  ["The “Final Solution” and the death camps",[
    "At the Wannsee Conference in January 1942, senior Nazi officials coordinated the “Final Solution to the Jewish Question,” the plan to murder all the Jews of Europe; mass killing had in fact already begun. The Nazis built killing centers in occupied Poland, including Chełmno, Bełżec, Sobibór, and Treblinka, where victims were murdered in gas chambers on arrival.",
    "Auschwitz-Birkenau, the largest camp, was both a slave-labor camp and a killing center, where about 1.1 million people were murdered, about one million of them Jews. Jews were deported from across Europe, from France and the Netherlands to Greece and, in 1944, Hungary, in sealed freight trains. Prisoners not killed on arrival faced forced labor, starvation, and deadly medical experiments."]],
  ["Perpetrators, bystanders, rescuers, and resistance",[
    "The Holocaust required the participation of hundreds of thousands of people: SS leaders such as Heinrich Himmler and Reinhard Heydrich, bureaucrats such as Adolf Eichmann who organized deportations, soldiers and police, railway workers, and collaborating governments and individuals. Historians have studied how “ordinary men” became killers through ideology, peer pressure, and careerism.",
    "Most people were bystanders, but some rescued Jews at great risk. Denmark smuggled most of its Jews to neutral Sweden in 1943; Oskar Schindler protected about 1,200 workers; the Swedish diplomat Raoul Wallenberg saved thousands in Budapest. Israel's Yad Vashem honors such people as the Righteous Among the Nations. Jews also resisted, through armed uprisings in ghettos and camps such as Treblinka and Sobibór, partisan warfare, and efforts to preserve records and culture."]],
  ["Liberation and legacy",[
    "As Allied armies advanced, the Nazis forced prisoners on death marches. Soviet troops liberated Auschwitz on 27 January 1945, now International Holocaust Remembrance Day, and British and American troops liberated camps such as Bergen-Belsen and Dachau. Survivors faced illness, loss of entire families, and displacement.",
    "At the Nuremberg trials (1945–1946), leading Nazis were tried for crimes against humanity and other crimes. The Holocaust led to the 1948 Genocide Convention, based on the term “genocide” coined by the lawyer Raphael Lemkin, and the Universal Declaration of Human Rights. It also strengthened support for a Jewish state, and Israel was founded in 1948. Holocaust denial is rejected by historians, as the event is among the most thoroughly documented in history."]]
  ],
  terms:[["Holocaust (Shoah)","The Nazi genocide of six million European Jews."],["Nuremberg Laws","The 1935 laws that stripped German Jews of citizenship."],["Ghetto","A sealed district where Jews were forced to live."],["Einsatzgruppen","Mobile killing units that shot Jews in the occupied East."],["Wannsee Conference","The 1942 meeting that coordinated the Final Solution."],["Righteous Among the Nations","Non-Jews honored for risking their lives to save Jews."],["Genocide","Acts intended to destroy a national, ethnic, racial, or religious group."]],
  w:"The Holocaust is history's most documented genocide, and understanding how it happened is essential to recognizing and preventing persecution and mass atrocity.",
  src:["The Holocaust","Nuremberg Laws","Kristallnacht","Einsatzgruppen","Wannsee Conference","Auschwitz concentration camp","Righteous Among the Nations"],
  q:[["About how many Jews were murdered in the Holocaust?","Six million","One million","Twelve million","Six hundred thousand"],
     ["What did the Nuremberg Laws of 1935 do?","Stripped Jews of German citizenship","Created the death camps","Started the war","Established the ghettos"],
     ["Where did a major armed Jewish uprising take place in 1943?","The Warsaw Ghetto","Dachau","Vichy","Nuremberg"],
     ["What was coordinated at the Wannsee Conference?","The Final Solution","The Nazi-Soviet Pact","The Anschluss","The invasion of Poland"],
     ["Which camp was the largest Nazi killing center?","Auschwitz-Birkenau","Dachau","Bergen-Belsen","Buchenwald"],
     ["Who coined the term genocide?","Raphael Lemkin","Simon Wiesenthal","Primo Levi","Elie Wiesel"]]}

]});


/* ---- from hist-13.js ---- */
/* HISTORY FOUNDATIONS, part 13: Unit 8 chapters 6-10 */
COURSES.history.units[7].ch.push(

{ t:"The Cold War", s:"A divided world, 1945–1991",
  sec:[
  ["Origins",[
    "The Cold War was a long rivalry between the United States and its allies and the Soviet Union and its allies, fought through ideology, arms races, propaganda, espionage, and proxy wars rather than direct war between the superpowers. Its roots lay in the clash between liberal-democratic capitalism and one-party communism, and in disputes over postwar Europe. At Yalta and Potsdam in 1945 the Allies agreed on zones of occupation in Germany, but the Soviet Union installed communist governments across Eastern Europe.",
    "In 1946 Churchill warned that an “iron curtain” had descended across Europe. In 1947 the Truman Doctrine pledged U.S. support for countries resisting communist pressure, beginning with Greece and Turkey, and the diplomat George Kennan's idea of containment became the core of American strategy. The Marshall Plan (1948–1952) gave roughly 13 billion dollars to rebuild Western Europe."]],
  ["Germany, Berlin, and the blocs",[
    "When the Western powers introduced a new currency in their zones, the Soviets blockaded West Berlin (1948–1949). The Western allies supplied the city by air for nearly a year in the Berlin Airlift until Stalin lifted the blockade. In 1949 Germany split into the Federal Republic (West Germany) and the German Democratic Republic (East Germany).",
    "Two military alliances formed: NATO in 1949, uniting the U.S., Canada, and Western European states, and the Warsaw Pact in 1955, led by the USSR. The Soviets crushed uprisings in East Germany (1953) and Hungary (1956) and ended the Prague Spring reforms in Czechoslovakia (1968). To stop East Germans from fleeing, the East German regime built the Berlin Wall in August 1961, which became the symbol of the divided world."]],
  ["The nuclear age",[
    "The Soviet Union tested its first atomic bomb in 1949, ending the American monopoly. Both powers developed hydrogen bombs in the early 1950s and then intercontinental ballistic missiles. The Soviet launch of Sputnik, the first artificial satellite, in 1957 shocked Americans and began the Space Race, which culminated in the American Moon landing of 1969.",
    "The logic of mutually assured destruction (MAD), in which each side could destroy the other even after being attacked, deterred direct war. The closest the world came to nuclear war was the Cuban Missile Crisis of October 1962, when the U.S. discovered Soviet missiles in Cuba. After thirteen tense days, Khrushchev agreed to remove them in exchange for a U.S. pledge not to invade Cuba and a secret promise to remove American missiles from Turkey. Afterward a hotline was set up and the Limited Test Ban Treaty (1963) was signed."]],
  ["Hot wars in a cold war",[
    "The Cold War turned violent in Asia. In the Korean War (1950–1953), North Korea, backed by the Soviet Union and later by Chinese troops, invaded South Korea, which was defended by U.N. forces led by the United States. The war ended in an armistice near the 38th parallel, leaving Korea divided to this day.",
    "In Vietnam, after the communist-led Viet Minh defeated France at Dien Bien Phu in 1954, the country was divided. The United States backed South Vietnam and from 1965 sent large ground forces, over half a million by 1968. Despite massive bombing, the U.S. could not defeat the communist North and the Viet Cong. American troops withdrew in 1973, and Saigon fell in 1975. The Soviets fought their own failed war in Afghanistan (1979–1989)."]],
  ["A global competition",[
    "The superpowers competed for influence across the developing world. The CIA helped overthrow governments in Iran (1953), Guatemala (1954), and Chile (1973), while the Soviet Union and Cuba backed revolutionary movements and governments in places such as Angola and Ethiopia. Many newly independent nations, led by India's Jawaharlal Nehru, Egypt's Gamal Abdel Nasser, Indonesia's Sukarno, and Yugoslavia's Josip Broz Tito, formed the Non-Aligned Movement, formally founded in 1961, to avoid taking sides.",
    "The communist world itself split. The Sino-Soviet split, which deepened after 1960, set China and the USSR against each other, and in 1972 Richard Nixon visited China, opening relations. The 1970s saw détente, an easing of tensions marked by arms-control agreements such as SALT I (1972) and the Helsinki Accords (1975), which included human-rights commitments."]],
  ["Renewed tension",[
    "Détente collapsed after the Soviet invasion of Afghanistan in 1979. Ronald Reagan called the Soviet Union an “evil empire,” built up American forces, and proposed the Strategic Defense Initiative. In 1983 a NATO exercise and Soviet fears of a surprise attack produced another dangerous moment.",
    "The Cold War shaped domestic life on both sides: loyalty investigations and McCarthyism in the U.S., civil defense drills, heavy military spending, and censorship and surveillance in the Soviet bloc. It ended in 1989–1991 with the fall of communism in Eastern Europe and the collapse of the Soviet Union."]]
  ],
  terms:[["Iron curtain","Churchill's term for the division of Europe."],["Containment","The U.S. strategy of stopping the spread of communism."],["Marshall Plan","American aid to rebuild Western Europe."],["NATO","The Western military alliance founded in 1949."],["Mutually assured destruction","Deterrence through each side's ability to destroy the other."],["Cuban Missile Crisis","The 1962 standoff over Soviet missiles in Cuba."],["Détente","The 1970s easing of Cold War tensions."]],
  w:"The Cold War divided the world for nearly half a century, drove the nuclear arms race and the space race, and shaped wars and politics on every continent.",
  src:["Cold War","Containment","Marshall Plan","Berlin Blockade","Cuban Missile Crisis","Korean War","Vietnam War","Non-Aligned Movement"],
  q:[["Who coined the strategy of containment?","George Kennan","George Marshall","Harry Truman","John Foster Dulles"],
     ["How did the West respond to the Berlin Blockade?","With an airlift","By invading East Germany","By building a wall","By using atomic weapons"],
     ["In what year was the Berlin Wall built?","1961","1949","1956","1968"],
     ["What did the Soviets launch in 1957?","Sputnik","The first ICBM test in Cuba","The first space station","Apollo"],
     ["Where did the French lose decisively in 1954?","Dien Bien Phu","Saigon","Hanoi","Khe Sanh"],
     ["Which U.S. president visited China in 1972?","Richard Nixon","Jimmy Carter","Lyndon Johnson","Gerald Ford"]]},

{ t:"Decolonization in Asia", s:"The end of empire, 1945–1975",
  sec:[
  ["Why empires fell",[
    "Between 1945 and the mid-1970s, most of the world's colonies became independent nations, one of the largest political transformations in history. World War II weakened the colonial powers, especially Britain, France, and the Netherlands. Japan's conquest of Southeast Asia had shattered the myth of European invincibility. Nationalist movements, often led by Western-educated elites, had grown for decades, and the new United Nations and both superpowers, for their own reasons, opposed old-style colonialism.",
    "Decolonization took different forms: negotiated transfers of power, long wars of independence, and partitions that caused enormous violence. Its legacy includes borders drawn by colonizers, economies built around exports, and political institutions that were often fragile."]],
  ["India's independence movement",[
    "The Indian National Congress, founded in 1885, became the main vehicle of Indian nationalism. Mohandas Gandhi, who returned from South Africa in 1915, transformed it into a mass movement through satyagraha (“truth-force”), nonviolent civil disobedience. The 1919 Amritsar massacre, in which British troops killed hundreds of unarmed Indians, turned many against British rule. Gandhi's Salt March of 1930 defied the British salt monopoly and drew global attention.",
    "During World War II the Congress launched the Quit India Movement (1942), and its leaders were jailed. Meanwhile, the Muslim League under Muhammad Ali Jinnah demanded a separate state for Muslims, Pakistan. After the war, a weakened Britain decided to leave quickly."]],
  ["Partition",[
    "On 14 and 15 August 1947, British India was partitioned into two independent states: India, led by Prime Minister Jawaharlal Nehru, and Pakistan, led by Jinnah, which included West Pakistan and East Pakistan (later Bangladesh). Borders were drawn hastily by the British lawyer Cyril Radcliffe.",
    "Partition caused one of the largest migrations in history: some 10 to 20 million people crossed the new borders, as Hindus and Sikhs fled Pakistan and Muslims fled India. Communal violence killed perhaps several hundred thousand to two million people. Gandhi was assassinated by a Hindu nationalist in January 1948. The dispute over Kashmir led to wars between India and Pakistan, and in 1971 East Pakistan broke away to become Bangladesh."]],
  ["Southeast Asia",[
    "In the Dutch East Indies, Sukarno declared Indonesian independence in August 1945, and after four years of war and diplomacy the Netherlands recognized Indonesia in 1949. The Philippines gained independence from the United States in 1946. Burma became independent of Britain in 1948, and Malaya in 1957 after the British defeated a communist insurgency known as the Malayan Emergency.",
    "In French Indochina, Ho Chi Minh, a communist and nationalist, declared Vietnamese independence in 1945. France fought to restore its rule until its defeat at Dien Bien Phu in 1954. The Geneva Accords divided Vietnam at the 17th parallel and recognized the independence of Laos and Cambodia, setting the stage for the American war in Vietnam."]],
  ["Korea and East Asia",[
    "Korea, ruled harshly by Japan from 1910 to 1945, was divided at the 38th parallel into Soviet and American occupation zones. In 1948, two states were proclaimed: the Republic of Korea in the south and the Democratic People's Republic of Korea, under Kim Il Sung, in the north, which led to the Korean War.",
    "Taiwan, a Japanese colony since 1895, returned to Chinese rule in 1945 and became the refuge of the Nationalist government after its defeat in 1949. In 1947 a crackdown on protest there, the February 28 Incident, killed thousands. Hong Kong remained British until 1997, and Macau Portuguese until 1999."]],
  ["Legacies",[
    "Newly independent Asian nations pursued different paths. India built a parliamentary democracy and a planned mixed economy; Pakistan alternated between civilian and military rule; Indonesia moved from Sukarno's “guided democracy” to the military regime of Suharto after mass killings of suspected communists in 1965–1966.",
    "The Bandung Conference of 1955 in Indonesia brought together 29 Asian and African nations to promote cooperation and oppose colonialism, laying the foundation for the Non-Aligned Movement. Decolonization in Asia inspired movements in Africa and elsewhere."]]
  ],
  terms:[["Decolonization","The process by which colonies gained independence."],["Satyagraha","Gandhi's method of nonviolent resistance."],["Salt March","Gandhi's 1930 protest against the British salt tax."],["Partition of India","The 1947 division of British India into India and Pakistan."],["Muslim League","The party that demanded the creation of Pakistan."],["Bandung Conference","The 1955 meeting of Asian and African nations."]],
  w:"Decolonization created most of the world's countries, and the partitions and borders of that era still shape conflicts in South Asia and beyond.",
  src:["Decolonisation of Asia","Indian independence movement","Mahatma Gandhi","Partition of India","Indonesian National Revolution","First Indochina War","Bandung Conference"],
  q:[["What is Gandhi's method of nonviolent resistance called?","Satyagraha","Swaraj","Ahimsa Raj","Purna"],
     ["Who led the Muslim League's demand for Pakistan?","Muhammad Ali Jinnah","Jawaharlal Nehru","Liaquat Ali Khan","Subhas Chandra Bose"],
     ["In what year were India and Pakistan partitioned?","1947","1945","1950","1971"],
     ["What did East Pakistan become in 1971?","Bangladesh","Sri Lanka","Burma","Nepal"],
     ["Who declared Indonesian independence in 1945?","Sukarno","Suharto","Ho Chi Minh","Aung San"],
     ["Where did 29 Asian and African nations meet in 1955?","Bandung","Geneva","Delhi","Cairo"]]},

{ t:"Decolonization in Africa", s:"Independence and its aftermath, 1945–1994",
  sec:[
  ["The rise of African nationalism",[
    "By the 1940s, African nationalism had grown through churches, trade unions, newspapers, veterans of the world wars, and students educated abroad. The Pan-African Congress held in Manchester in 1945, attended by Kwame Nkrumah and Jomo Kenyatta, demanded independence. The ideas of Pan-Africanism, associated with W. E. B. Du Bois and Marcus Garvey, linked Africans and the African diaspora.",
    "Independence came in a rush. Ghana, led by Nkrumah, was the first sub-Saharan colony to gain independence from Britain, in 1957. In 1960, the “Year of Africa,” seventeen African countries became independent, most of them former French colonies. By the late 1960s, most of the continent was independent."]],
  ["North Africa and Algeria",[
    "Egypt, formally independent from 1922 but under British influence, saw a military coup in 1952. Gamal Abdel Nasser became its leader and nationalized the Suez Canal in 1956, prompting a failed British, French, and Israeli invasion, the Suez Crisis, which showed that the old colonial powers could no longer act without American support. Libya (1951), Tunisia (1956), and Morocco (1956) gained independence.",
    "Algeria, which France considered part of France itself and which had about a million European settlers, endured a brutal war of independence (1954–1962). The National Liberation Front (FLN) used guerrilla war and terrorism, and the French army used torture. The war brought down France's Fourth Republic and returned Charles de Gaulle to power in 1958; he eventually accepted Algerian independence in 1962."]],
  ["Settler colonies and liberation wars",[
    "Where large numbers of European settlers lived, independence was often violently resisted. In Kenya, the Mau Mau uprising (1952–1960) was suppressed by the British with mass detention and abuse; Kenya nevertheless became independent in 1963 under Jomo Kenyatta. In Southern Rhodesia, white settlers declared independence in 1965 to preserve minority rule; after a guerrilla war, the country became Zimbabwe in 1980.",
    "Portugal held on to Angola, Mozambique, and Guinea-Bissau through long wars until a coup in Lisbon in 1974, the Carnation Revolution, led to independence in 1975. Angola then fell into a long civil war in which the superpowers, Cuba, and South Africa intervened."]],
  ["The Congo crisis",[
    "Belgium's rule in the Congo had begun with King Leopold II's personal colony, notorious for forced labor and atrocities in the rubber trade. Belgium granted independence hastily in 1960, with very few Congolese trained for administration. The new country quickly descended into crisis: the army mutinied and the mineral-rich province of Katanga seceded with Belgian support.",
    "Prime Minister Patrice Lumumba appealed for help and turned to the Soviet Union; he was overthrown and murdered in 1961 with Belgian involvement and American approval. In 1965 Joseph Mobutu seized power and ruled for over thirty years, renaming the country Zaire and becoming notorious for corruption, though backed by the West as an anti-communist ally."]],
  ["Apartheid South Africa",[
    "South Africa, independent within the British Commonwealth since 1910, was ruled by its white minority. After the National Party won the 1948 election, it built apartheid, a system of legal racial segregation that classified every person by race, banned interracial marriage, reserved the best land and jobs for whites, and confined Black Africans to impoverished “homelands.” Pass laws controlled movement.",
    "The African National Congress (ANC) led resistance. After police killed 69 protesters at Sharpeville in 1960, the ANC was banned and turned to armed struggle; Nelson Mandela was sentenced to life imprisonment in 1964. The Soweto uprising of 1976 and international sanctions increased pressure. President F. W. de Klerk released Mandela in 1990, and in 1994 South Africa held its first democratic elections, with Mandela becoming president."]],
  ["After independence",[
    "Independent Africa faced severe challenges: borders drawn by colonial powers that divided ethnic groups and combined rivals, economies dependent on exporting a few raw materials, limited infrastructure and education, and Cold War interference. Many states became one-party regimes or military dictatorships; Nigeria endured the Biafran War (1967–1970), in which famine killed perhaps a million or more people.",
    "The Organization of African Unity, founded in 1963 and replaced by the African Union in 2002, promoted cooperation. The 1994 Rwandan genocide, in which Hutu extremists killed roughly 500,000 to 800,000 people, mostly Tutsi, in about 100 days, was a catastrophe. Since the 1990s, many African countries have held multiparty elections and experienced rapid population and economic growth, and the continent's history is increasingly told from African sources and perspectives."]]
  ],
  terms:[["Pan-Africanism","A movement for unity among Africans and the African diaspora."],["Year of Africa","1960, when seventeen African nations became independent."],["Suez Crisis","The failed 1956 Anglo-French-Israeli invasion of Egypt."],["Mau Mau uprising","The 1950s Kenyan rebellion against British rule."],["Apartheid","South Africa's system of legal racial segregation, 1948–1994."],["African National Congress","The main movement against apartheid."]],
  w:"African decolonization created more than fifty nations in a few decades, and its struggles over borders, development, and democracy continue to shape the continent.",
  src:["Decolonisation of Africa","Kwame Nkrumah","Algerian War","Mau Mau rebellion","Congo Crisis","Apartheid","Nelson Mandela"],
  q:[["Which was the first sub-Saharan colony to gain independence from Britain, in 1957?","Ghana","Nigeria","Kenya","Uganda"],
     ["Who nationalized the Suez Canal in 1956?","Gamal Abdel Nasser","Anwar Sadat","Habib Bourguiba","King Farouk"],
     ["Which war of independence lasted from 1954 to 1962?","The Algerian War","The Mau Mau uprising","The Angolan War","The Biafran War"],
     ["Which Congolese prime minister was murdered in 1961?","Patrice Lumumba","Joseph Mobutu","Moïse Tshombe","Laurent Kabila"],
     ["Which party built apartheid after 1948?","The National Party","The African National Congress","The United Party","The Inkatha Freedom Party"],
     ["In what year did South Africa hold its first democratic elections?","1994","1990","1976","1964"]]},

{ t:"Modern China", s:"Revolution, Mao, and reform, 1911 to today",
  sec:[
  ["The Republic and the warlords",[
    "The Qing dynasty collapsed in the Revolution of 1911, and in 1912 China became a republic, with the revolutionary Sun Yat-sen as its first provisional president. Power soon passed to the general Yuan Shikai, and after his death in 1916 China fragmented among regional warlords.",
    "On 4 May 1919, students protested the Versailles treaty's transfer of German rights in Shandong to Japan. The May Fourth Movement promoted science, democracy, and vernacular literature and rejected Confucian tradition. The Chinese Communist Party (CCP) was founded in 1921, and Sun's Nationalist Party, the Guomindang (Kuomintang), reorganized with Soviet help."]],
  ["Nationalists and Communists",[
    "After Sun's death, Chiang Kai-shek led the Northern Expedition (1926–1928), which nominally unified China. In 1927 he turned on his communist allies, massacring them in Shanghai. The Communists retreated to the countryside, where Mao Zedong argued that peasants, not urban workers, would make the revolution. Under Nationalist attack, they made the Long March (1934–1935), a retreat of thousands of miles to Yan'an in the northwest, during which Mao rose to leadership.",
    "Japan's full-scale invasion in 1937 forced an uneasy alliance. The war killed perhaps 15 to 20 million Chinese. The Communists expanded behind Japanese lines, while the Nationalists bore much of the conventional fighting and were weakened by corruption and inflation. Civil war resumed after 1945."]],
  ["Mao's China",[
    "Communist victory came in 1949. On 1 October, Mao proclaimed the People's Republic of China, and Chiang's government fled to Taiwan. The new state carried out land reform, in which hundreds of thousands of landlords were killed, and campaigns against counterrevolutionaries. It intervened in the Korean War and followed the Soviet model of planning.",
    "In the Great Leap Forward (1958–1962), Mao tried to industrialize overnight through communes and backyard steel furnaces. Unrealistic targets, false reports, and grain requisitioning caused the worst famine in history, in which perhaps 15 to 45 million people died. In the Cultural Revolution (1966–1976), Mao mobilized young Red Guards against supposed enemies of revolution; officials, teachers, and intellectuals were persecuted, cultural heritage was destroyed, and between hundreds of thousands and over a million people died."]],
  ["Deng Xiaoping and reform",[
    "After Mao's death in 1976, the radical “Gang of Four,” including his widow Jiang Qing, was arrested. Deng Xiaoping emerged as paramount leader by 1978 and launched “reform and opening up.” Collective farms were dismantled in favor of household farming, Special Economic Zones such as Shenzhen welcomed foreign investment, and markets gradually replaced planning. Deng's pragmatism was summed up in the saying that it does not matter whether a cat is black or white as long as it catches mice.",
    "Political reform did not follow. In spring 1989, students and workers gathered in Tiananmen Square in Beijing calling for reform and freedom of expression. On 3–4 June the army cleared the square and surrounding streets, killing hundreds or more people. The event remains censored in China."]],
  ["China's rise",[
    "China's economy grew at roughly 10 percent a year for three decades, lifting hundreds of millions of people out of extreme poverty and making China the world's manufacturing center. It joined the World Trade Organization in 2001 and became the world's second-largest economy around 2010. The one-child policy (1980–2015) slowed population growth but contributed to an aging society and a gender imbalance.",
    "Under Xi Jinping, leader since 2012, the Party tightened control, removed presidential term limits in 2018, launched the Belt and Road Initiative to build infrastructure abroad, and pursued an assertive foreign policy. The mass detention of Uyghurs in Xinjiang and the crackdown in Hong Kong after 2019 drew international condemnation."]],
  ["Taiwan and the Chinese world",[
    "On Taiwan, the Nationalist government ruled under martial law from 1949 to 1987. Taiwan then democratized, holding its first direct presidential election in 1996, and became a high-tech economy. Beijing considers Taiwan part of China, and its status is one of the most dangerous issues in world politics.",
    "Hong Kong returned to China in 1997 under “one country, two systems,” promising autonomy for fifty years. Understanding modern China requires seeing both its extraordinary economic transformation and the enormous human costs of its revolutionary century."]]
  ],
  terms:[["May Fourth Movement","The 1919 movement for modernization and nationalism."],["Guomindang","The Chinese Nationalist Party of Sun Yat-sen and Chiang Kai-shek."],["Long March","The Communists' 1934–1935 retreat to Yan'an."],["Great Leap Forward","Mao's 1958–1962 campaign that caused a vast famine."],["Cultural Revolution","Mao's 1966–1976 campaign of mass political persecution."],["Reform and opening up","Deng Xiaoping's market reforms from 1978."]],
  w:"China's 20th century moved from collapse and civil war through Maoist upheaval to market-driven growth, producing the great power whose choices now shape the world.",
  src:["Xinhai Revolution","May Fourth Movement","Long March","Great Leap Forward","Cultural Revolution","Deng Xiaoping","1989 Tiananmen Square protests and massacre"],
  q:[["Who was the first provisional president of the Republic of China?","Sun Yat-sen","Chiang Kai-shek","Yuan Shikai","Mao Zedong"],
     ["What was the Communists' 1934–1935 retreat called?","The Long March","The Northern Expedition","The Great Leap","The Hundred Flowers"],
     ["When was the People's Republic of China proclaimed?","1 October 1949","4 May 1919","1 July 1921","1 January 1912"],
     ["Which campaign caused a massive famine from 1958 to 1962?","The Great Leap Forward","The Cultural Revolution","Land reform","The Hundred Flowers Campaign"],
     ["Who launched “reform and opening up” in 1978?","Deng Xiaoping","Zhou Enlai","Hua Guofeng","Jiang Zemin"],
     ["In what year did Hong Kong return to China?","1997","1984","1999","2001"]]},

{ t:"The Modern Middle East", s:"Mandates, oil, nations, and conflict since 1918",
  sec:[
  ["After the Ottomans",[
    "The defeat of the Ottoman Empire in World War I reshaped the Middle East. During the war Britain had made conflicting commitments: the Hussein-McMahon correspondence encouraged Arab independence, the secret Sykes-Picot Agreement (1916) divided the region between Britain and France, and the Balfour Declaration (1917) supported “a national home for the Jewish people” in Palestine.",
    "After the war, the League of Nations gave Britain mandates over Iraq, Transjordan, and Palestine, and France mandates over Syria and Lebanon. In Anatolia, Mustafa Kemal (later Atatürk) defeated invading Greek forces and founded the Republic of Turkey in 1923, which he rapidly secularized: he abolished the caliphate, adopted the Latin alphabet, and gave women the vote. In Arabia, Ibn Saud founded Saudi Arabia in 1932."]],
  ["Oil and Iran",[
    "Oil, discovered in Iran in 1908 and later in Iraq, Saudi Arabia, and the Gulf, made the region vital to the world economy. In Iran, Prime Minister Mohammad Mosaddegh nationalized the British-controlled oil industry in 1951 and was overthrown in a 1953 coup organized by American and British intelligence, strengthening Shah Mohammad Reza Pahlavi.",
    "The Shah pursued rapid modernization while repressing opposition. In the Iranian Revolution of 1979, a broad movement overthrew him, and Ayatollah Ruhollah Khomeini established an Islamic Republic ruled by clerics. Revolutionaries took American diplomats hostage for 444 days. Iraq under Saddam Hussein invaded Iran in 1980, beginning a war that lasted until 1988 and killed hundreds of thousands."]],
  ["Israel and the Arab-Israeli conflict",[
    "Zionism, the movement for a Jewish homeland, founded by Theodor Herzl in the 1890s, brought Jewish immigrants to Palestine, where they came into conflict with the Arab majority. After the Holocaust, the U.N. proposed partition in 1947. Israel declared independence in May 1948, and neighboring Arab states invaded. Israel won the war; about 700,000 Palestinian Arabs fled or were expelled, an event Palestinians call the Nakba (“catastrophe”).",
    "In the Six-Day War of 1967, Israel seized the West Bank and East Jerusalem from Jordan, the Gaza Strip and Sinai from Egypt, and the Golan Heights from Syria. After the 1973 Yom Kippur War, Egypt's Anwar Sadat made peace with Israel at Camp David (1978–1979) and regained the Sinai. The Palestine Liberation Organization under Yasser Arafat fought for Palestinian statehood; the Oslo Accords of 1993 created limited Palestinian self-government, but a final settlement has not been reached."]],
  ["Arab nationalism and authoritarian states",[
    "In the 1950s and 1960s, Arab nationalism, championed by Egypt's Nasser and by the Baath parties that took power in Syria and Iraq, promised unity, modernization, and independence from the West. Military officers seized power in several countries. The 1967 defeat discredited secular Arab nationalism and strengthened Islamist movements, such as the Muslim Brotherhood, founded in Egypt in 1928.",
    "Oil wealth transformed the Gulf states. During the 1973 war, Arab oil producers imposed an embargo on countries supporting Israel, quadrupling oil prices and showing the power of OPEC."]],
  ["Wars in the Gulf and beyond",[
    "In 1990 Iraq invaded Kuwait. A U.S.-led coalition expelled Iraqi forces in the Gulf War of 1991. After the attacks of 11 September 2001 by al-Qaeda, the United States invaded Afghanistan in 2001 and Iraq in 2003, toppling Saddam Hussein. The Iraq war led to sectarian civil war and years of instability, and the U.S. withdrew from Afghanistan in 2021 as the Taliban returned to power.",
    "In 2010–2011, the Arab Spring uprisings toppled rulers in Tunisia, Egypt, Libya, and Yemen. Only Tunisia made a lasting, if fragile, democratic transition. Syria descended into a devastating civil war from 2011, which saw the rise of the Islamic State (ISIS), which proclaimed a caliphate in 2014 before being defeated territorially by 2019."]],
  ["Understanding the region",[
    "The modern Middle East is often wrongly described as defined by ancient hatreds. Historians emphasize more recent forces: the collapse of the Ottoman order, colonial borders, oil, the Arab-Israeli conflict, Cold War rivalries, authoritarian governments, the rivalry between Iran and Saudi Arabia, and debates over the role of religion in politics.",
    "The region is also home to dynamic societies, rapidly growing populations, and some of the world's oldest continuous cities. Its history connects to every earlier unit in this course, from Mesopotamia and Persia to the rise of Islam and the Ottomans."]]
  ],
  terms:[["Sykes-Picot Agreement","The secret 1916 Anglo-French plan to divide Ottoman lands."],["Balfour Declaration","Britain's 1917 support for a Jewish national home in Palestine."],["Mandate","A League of Nations territory governed by a colonial power."],["Nakba","The 1948 flight and expulsion of Palestinian Arabs."],["Six-Day War","The 1967 war in which Israel occupied new territories."],["Iranian Revolution","The 1979 revolution that created an Islamic Republic."],["Arab Spring","The 2010–2011 wave of uprisings in the Arab world."]],
  w:"The modern Middle East's conflicts grew from the post-Ottoman settlement, oil, nationalism, and great-power intervention, and they continue to affect global politics and energy.",
  src:["Sykes–Picot Agreement","Balfour Declaration","Mustafa Kemal Atatürk","Iranian revolution","1948 Arab–Israeli War","Six-Day War","Arab Spring"],
  q:[["Which 1916 agreement secretly divided Ottoman lands?","Sykes-Picot","Balfour","Camp David","Oslo"],
     ["Who founded the Republic of Turkey in 1923?","Mustafa Kemal Atatürk","Enver Pasha","Ibn Saud","Reza Shah"],
     ["Which Iranian prime minister was overthrown in 1953?","Mohammad Mosaddegh","Ruhollah Khomeini","Abolhassan Banisadr","Reza Shah"],
     ["What do Palestinians call the events of 1948?","The Nakba","The Intifada","The Hijra","The Naksa"],
     ["Which Egyptian leader made peace with Israel at Camp David?","Anwar Sadat","Gamal Abdel Nasser","Hosni Mubarak","King Farouk"],
     ["In which country did the Arab Spring begin?","Tunisia","Egypt","Syria","Libya"]]}

);


/* ---- from hist-14.js ---- */
/* HISTORY FOUNDATIONS, part 14: Unit 8 chapters 11-18 */
COURSES.history.units[7].ch.push(

{ t:"Latin America in the Twentieth Century", s:"Revolution, dictatorship, and democracy",
  sec:[
  ["Export economies and the Mexican Revolution",[
    "After independence, most Latin American economies depended on exporting raw materials, such as coffee, sugar, beef, copper, nitrates, and bananas, often controlled by local elites and foreign companies. The American United Fruit Company was so powerful in Central America that critics coined the term “banana republic.” The United States intervened militarily in the Caribbean and Central America many times in the early 20th century.",
    "The Mexican Revolution (1910–1920) began as a revolt against the long dictatorship of Porfirio Díaz and became a complex civil war involving leaders such as Francisco Madero, the peasant leader Emiliano Zapata, who demanded “land and liberty,” and Pancho Villa. Perhaps a million people died. The Constitution of 1917 promised land reform, workers' rights, and national control of resources. The ruling party, later called the PRI, governed Mexico from 1929 to 2000, and President Lázaro Cárdenas nationalized the oil industry in 1938."]],
  ["Populism",[
    "The Great Depression devastated export economies. Many countries turned to import-substitution industrialization, building domestic industries behind tariffs. Populist leaders appealed directly to urban workers and the poor. Getúlio Vargas ruled Brazil for much of 1930–1954, creating a corporatist “New State.”",
    "In Argentina, Juan Perón, elected president in 1946, built a movement of workers, expanded social welfare, and nationalized industries, while repressing opponents. His wife Eva Perón (Evita) became an icon to the poor. Peronism remains a powerful force in Argentine politics."]],
  ["The Cuban Revolution",[
    "In 1959 Fidel Castro, his brother Raúl, and Ernesto “Che” Guevara overthrew the dictator Fulgencio Batista. Castro nationalized American-owned property, allied with the Soviet Union, and created a one-party communist state that expanded literacy and healthcare while suppressing dissent. Hundreds of thousands of Cubans emigrated, many to Florida.",
    "The failed U.S.-backed Bay of Pigs invasion (1961) and the Cuban Missile Crisis (1962) made Cuba a Cold War flashpoint. The U.S. embargo, begun in 1960, has lasted for decades. The revolution inspired guerrilla movements across the region and alarmed the United States and Latin American elites."]],
  ["Military dictatorships",[
    "From the 1960s to the 1980s, military regimes took power in much of South America, often with U.S. support, claiming to fight communism. Brazil's military ruled from 1964 to 1985. In Chile, General Augusto Pinochet overthrew the elected socialist president Salvador Allende on 11 September 1973; his regime killed or “disappeared” thousands and imposed free-market reforms.",
    "Argentina's junta (1976–1983) waged a “Dirty War” in which perhaps up to 30,000 people disappeared; mothers of the disappeared protested weekly in Buenos Aires as the Mothers of the Plaza de Mayo. Operation Condor coordinated repression across several dictatorships. Central America saw brutal civil wars in Guatemala, El Salvador, and Nicaragua, where the Sandinista revolution of 1979 was opposed by U.S.-backed Contras."]],
  ["Democracy and new challenges",[
    "In the 1980s, the debt crisis, when many countries could not repay huge foreign loans, caused a “lost decade” of economic stagnation. Military regimes, discredited by repression and economic failure, gave way to elected governments across the region: Argentina after its defeat by Britain in the Falklands War (1982), Brazil in 1985, and Chile after Pinochet lost a 1988 plebiscite.",
    "The 1990s brought free-market reforms and trade agreements such as NAFTA (1994). In the 2000s, a “pink tide” of left-wing governments, including Hugo Chávez in Venezuela and Luiz Inácio Lula da Silva in Brazil, expanded social programs. Latin America today faces persistent inequality, the drug trade and organized crime, and debates over democracy and development."]]
  ],
  terms:[["Mexican Revolution","The 1910–1920 upheaval that overthrew Díaz."],["Import-substitution industrialization","Building domestic industries to replace imports."],["Peronism","The populist movement of Juan Perón in Argentina."],["Cuban Revolution","Castro's 1959 overthrow of Batista."],["Dirty War","Argentina's state terror campaign of 1976–1983."],["The disappeared","People secretly abducted and killed by dictatorships."]],
  w:"Latin America's 20th century, from revolution and populism to dictatorship and democratization, explains much about the region's politics and its relationship with the United States.",
  src:["Mexican Revolution","Juan Perón","Cuban Revolution","1973 Chilean coup d'état","Dirty War","Latin American debt crisis"],
  q:[["Whose long dictatorship sparked the Mexican Revolution?","Porfirio Díaz","Emiliano Zapata","Lázaro Cárdenas","Benito Juárez"],
     ["Which Mexican president nationalized the oil industry in 1938?","Lázaro Cárdenas","Francisco Madero","Venustiano Carranza","Álvaro Obregón"],
     ["Which populist leader was elected president of Argentina in 1946?","Juan Perón","Getúlio Vargas","Augusto Pinochet","Hugo Chávez"],
     ["Whom did Castro overthrow in 1959?","Fulgencio Batista","Anastasio Somoza","Manuel Noriega","Rafael Trujillo"],
     ["Which Chilean president was overthrown in 1973?","Salvador Allende","Augusto Pinochet","Eduardo Frei","Michelle Bachelet"],
     ["Who protested Argentina's disappearances weekly in Buenos Aires?","The Mothers of the Plaza de Mayo","The Sandinistas","The Contras","The Montoneros"]]},

{ t:"Europe after 1945", s:"Rebuilding, welfare, and integration",
  sec:[
  ["Ruin and recovery",[
    "Europe in 1945 was devastated: cities lay in rubble, tens of millions were displaced, and borders had shifted. Millions of Germans were expelled from Eastern Europe, and Poland's borders moved westward. With Marshall Plan aid and cheap energy, Western Europe then enjoyed nearly three decades of rapid growth, called the “economic miracle” (Wirtschaftswunder) in West Germany and the trente glorieuses (“thirty glorious years”) in France.",
    "West Germany, under Chancellor Konrad Adenauer, became a stable democracy and confronted, slowly and incompletely, the crimes of the Nazi past. Italy and France rebuilt democratic republics; France's Fifth Republic, created under de Gaulle in 1958, gave strong powers to the president."]],
  ["The welfare state",[
    "Postwar governments built welfare states. Britain's Labour government under Clement Attlee, elected in 1945, created the National Health Service in 1948, offering free healthcare, and expanded social insurance based on the Beveridge Report. Scandinavian countries developed especially extensive systems.",
    "Christian Democrats and Social Democrats largely agreed on a mixed economy, strong unions, and social protection, a consensus that held until the economic shocks of the 1970s, when inflation and unemployment led to the market-oriented policies of leaders such as Margaret Thatcher, British prime minister from 1979 to 1990."]],
  ["European integration",[
    "Determined to make war between France and Germany impossible, leaders such as Jean Monnet and Robert Schuman proposed pooling coal and steel production. The European Coal and Steel Community (1951) joined France, West Germany, Italy, and the Benelux countries. The Treaty of Rome (1957) created the European Economic Community, a common market.",
    "The community expanded to include Britain, Ireland, and Denmark (1973) and later Greece, Spain, and Portugal after they emerged from dictatorship. The Maastricht Treaty (1992) created the European Union, with common citizenship, and the euro became a shared currency in 1999 (with notes and coins from 2002). After 2004 the EU expanded into former communist Central and Eastern Europe. Britain voted to leave in a 2016 referendum and left in 2020."]],
  ["Society and culture",[
    "Postwar Europe changed dramatically. Mass consumption, cars, and television spread. Immigrants from former colonies and southern Europe, including “guest workers” in West Germany, made European societies more diverse. In 1968, student protests and strikes erupted, most dramatically in Paris in May 1968, challenging authority and traditional values.",
    "Religious practice declined in much of Western Europe, women's rights expanded, and memory of the war and Holocaust became central to European identity."]],
  ["Eastern Europe under communism",[
    "Behind the Iron Curtain, communist regimes nationalized industry, collectivized farms in most countries, and used secret police such as East Germany's Stasi to watch citizens. Yugoslavia under Tito broke with Stalin in 1948 and followed its own path.",
    "Revolts were crushed in East Germany (1953), Hungary (1956), and Czechoslovakia (1968). In Poland, the independent trade union Solidarity, led by the shipyard electrician Lech Wałęsa and supported by the Polish Pope John Paul II, emerged in 1980; martial law suppressed it in 1981, but it survived underground and helped bring communism down."]]
  ],
  terms:[["Economic miracle","Rapid postwar growth in West Germany and Western Europe."],["Welfare state","A state providing extensive social insurance and services."],["National Health Service","Britain's free public healthcare system, created in 1948."],["Treaty of Rome","The 1957 treaty creating the European Economic Community."],["Maastricht Treaty","The 1992 treaty creating the European Union."],["Solidarity","The independent Polish trade union founded in 1980."]],
  w:"Postwar Europe turned from the world's battlefield into a zone of peace, prosperity, and integration, a transformation central to the modern world order.",
  src:["Aftermath of World War II","Marshall Plan","Welfare state","European Coal and Steel Community","European Union","Solidarity (Polish trade union)"],
  q:[["What is West Germany's postwar boom called?","The Wirtschaftswunder","The Anschluss","Ostpolitik","The Kulturkampf"],
     ["In what year was Britain's National Health Service created?","1948","1945","1957","1979"],
     ["Which treaty created the European Economic Community?","The Treaty of Rome","The Maastricht Treaty","The Treaty of Versailles","The Lisbon Treaty"],
     ["Which treaty created the European Union?","The Maastricht Treaty","The Treaty of Rome","The Schengen Agreement","The Paris Treaty"],
     ["Who led the Polish union Solidarity?","Lech Wałęsa","Václav Havel","Wojciech Jaruzelski","Imre Nagy"],
     ["In what year did Britain leave the EU?","2020","2016","2008","2012"]]},

{ t:"The End of the Cold War", s:"The fall of communism, 1985–1991",
  sec:[
  ["Gorbachev's reforms",[
    "By the 1980s the Soviet economy was stagnant, burdened by military spending, inefficient planning, and the costly war in Afghanistan. Mikhail Gorbachev, who became Soviet leader in 1985, launched glasnost (“openness”), loosening censorship and allowing criticism, and perestroika (“restructuring”), an attempt to reform the economy. The 1986 Chernobyl nuclear disaster exposed the costs of secrecy.",
    "Gorbachev also sought to end the arms race. He and Ronald Reagan signed the Intermediate-Range Nuclear Forces (INF) Treaty in 1987, eliminating a whole class of missiles. He withdrew Soviet troops from Afghanistan and abandoned the Brezhnev Doctrine, under which the USSR had intervened to keep communist regimes in power in Eastern Europe."]],
  ["The revolutions of 1989",[
    "Once it was clear Moscow would not use force, communist rule in Eastern Europe collapsed with astonishing speed. In Poland, Solidarity won semi-free elections in June 1989. Hungary opened its border with Austria. In East Germany, mass protests grew, and on 9 November 1989 the Berlin Wall was opened, as crowds poured through and began to tear it down.",
    "Czechoslovakia's peaceful Velvet Revolution brought the dissident playwright Václav Havel to the presidency. Bulgaria's leadership fell. In Romania, the only violent revolution, the dictator Nicolae Ceaușescu was overthrown and executed in December 1989. Germany reunified on 3 October 1990."]],
  ["The collapse of the Soviet Union",[
    "Glasnost unleashed nationalism within the Soviet Union itself. The Baltic republics of Estonia, Latvia, and Lithuania pressed for independence. In August 1991, hardline communists attempted a coup against Gorbachev; it collapsed in three days after Boris Yeltsin, president of the Russian Republic, rallied resistance in Moscow.",
    "The coup accelerated the breakup. Republics declared independence, and on 25 December 1991 Gorbachev resigned and the Soviet Union dissolved into fifteen independent states. The Cold War was over."]],
  ["Why did it end?",[
    "Historians debate the causes. Some emphasize Western pressure, including Reagan's military buildup. Others stress the Soviet system's economic failures, the role of Gorbachev's choices, the courage of dissidents and ordinary citizens, nationalism in the republics, and the influence of the Helsinki human-rights commitments and Western media.",
    "Most agree that the peaceful nature of the end was remarkable and owed much to Gorbachev's refusal to use mass force to save the empire."]],
  ["Aftermath",[
    "The 1990s brought both hope and turmoil. Russia under Yeltsin experienced economic collapse, corruption, and the rise of oligarchs; Vladimir Putin, president from 2000, restored central power and authoritarian rule. Yugoslavia broke apart in wars (1991–2001) that included the genocide at Srebrenica in 1995.",
    "NATO and the EU expanded eastward. Some declared “the end of history,” the triumph of liberal democracy, but new conflicts followed, including Russia's annexation of Crimea in 2014 and its full-scale invasion of Ukraine in 2022."]]
  ],
  terms:[["Glasnost","Gorbachev's policy of openness."],["Perestroika","Gorbachev's attempt to restructure the Soviet economy."],["Brezhnev Doctrine","The Soviet claim to intervene to preserve communist rule."],["Velvet Revolution","Czechoslovakia's peaceful 1989 revolution."],["Fall of the Berlin Wall","The opening of the Wall on 9 November 1989."],["August Coup","The failed 1991 hardline coup against Gorbachev."]],
  w:"The peaceful collapse of communism in Europe ended the Cold War and created today's map of Europe and the former Soviet Union.",
  src:["Revolutions of 1989","Mikhail Gorbachev","Glasnost","Fall of the Berlin Wall","Dissolution of the Soviet Union","1991 Soviet coup attempt"],
  q:[["What does glasnost mean?","Openness","Restructuring","Acceleration","Détente"],
     ["Which 1987 treaty eliminated a class of nuclear missiles?","The INF Treaty","SALT I","START I","The Test Ban Treaty"],
     ["On what date was the Berlin Wall opened?","9 November 1989","3 October 1990","25 December 1991","13 August 1961"],
     ["Who became president of Czechoslovakia after the Velvet Revolution?","Václav Havel","Alexander Dubček","Lech Wałęsa","Gustáv Husák"],
     ["Which leader was executed in Romania's 1989 revolution?","Nicolae Ceaușescu","Erich Honecker","Todor Zhivkov","János Kádár"],
     ["Who rallied resistance to the August 1991 coup?","Boris Yeltsin","Vladimir Putin","Eduard Shevardnadze","Yegor Ligachev"]]},

{ t:"Asia's Economic Rise", s:"Japan, the Tigers, and India",
  sec:[
  ["Postwar Japan",[
    "Defeated Japan was occupied by the United States under General Douglas MacArthur from 1945 to 1952. The occupation demilitarized the country, introduced a new constitution in 1947 in which Japan renounced war (Article 9), made the emperor a symbol without political power, gave women the vote, and carried out land reform.",
    "Japan then achieved spectacular growth, averaging about 10 percent a year in the 1950s and 1960s, guided by close cooperation between government ministries such as MITI and large business groups. Japanese firms such as Toyota and Sony became world leaders, and Japan became the world's second-largest economy by 1968. After a stock and property bubble burst around 1990, Japan entered a long period of slow growth."]],
  ["The Asian Tigers",[
    "South Korea, Taiwan, Hong Kong, and Singapore, the “Four Asian Tigers,” industrialized rapidly from the 1960s through export-oriented manufacturing, high saving and investment, and heavy investment in education. South Korea rose from one of the poorest countries in the world after the Korean War to an industrial powerhouse with firms such as Samsung and Hyundai.",
    "Growth in South Korea and Taiwan happened at first under authoritarian rule, but both democratized in the late 1980s and 1990s. Singapore, under Lee Kuan Yew, combined prosperity with tight political control. The Asian financial crisis of 1997–1998 hit the region hard but did not end its rise."]],
  ["India since independence",[
    "Independent India became the world's most populous democracy. Its constitution of 1950, drafted under the leadership of B. R. Ambedkar, abolished untouchability. Nehru pursued state-led industrialization and non-alignment. His daughter Indira Gandhi led India to victory in the 1971 war and imposed a period of emergency rule (1975–1977); she was assassinated in 1984.",
    "Economic growth was slow until a balance-of-payments crisis led to liberalizing reforms in 1991, opening the economy to trade and investment. India became a major center of information technology and services, and in 2023 it overtook China as the world's most populous country."]],
  ["Southeast Asia",[
    "Southeast Asian countries such as Malaysia, Thailand, and Indonesia grew rapidly from the 1970s, and the Association of Southeast Asian Nations (ASEAN), founded in 1967, promoted regional cooperation. Vietnam, after its war, adopted market reforms called Đổi Mới in 1986 and became a fast-growing exporter.",
    "Cambodia suffered one of the century's worst atrocities: the Khmer Rouge regime under Pol Pot (1975–1979) emptied cities and caused the deaths of roughly 1.5 to 2 million people, about a quarter of the population, through execution, forced labor, and starvation."]],
  ["Why Asia rose",[
    "Economists and historians debate the sources of East Asian growth: market openness and export orientation, active government industrial policy, high rates of saving, education, land reform, American aid and markets during the Cold War, and cultural factors. Most stress a combination.",
    "The rise of Asia, including China, has shifted the center of the world economy back toward the region that, before 1800, produced most of the world's goods, one of the great long-term stories of world history."]]
  ],
  terms:[["Article 9","The clause of Japan's constitution renouncing war."],["Four Asian Tigers","South Korea, Taiwan, Hong Kong, and Singapore."],["Export-oriented industrialization","Growth through manufacturing for world markets."],["ASEAN","The Association of Southeast Asian Nations, founded in 1967."],["Đổi Mới","Vietnam's 1986 market reforms."],["Khmer Rouge","The Cambodian communist regime of Pol Pot."]],
  w:"Asia's economic rise since 1945 has reshaped global trade and power and lifted more people out of poverty than any other development in history.",
  src:["Occupation of Japan","Japanese economic miracle","Four Asian Tigers","Economic liberalisation in India","Đổi Mới","Cambodian genocide"],
  q:[["Who led the American occupation of Japan?","Douglas MacArthur","Dwight Eisenhower","George Marshall","Chester Nimitz"],
     ["Which article of Japan's constitution renounces war?","Article 9","Article 1","Article 231","Article 5"],
     ["Which of these is NOT one of the Four Asian Tigers?","Thailand","Singapore","Taiwan","South Korea"],
     ["Who led the drafting of India's constitution?","B. R. Ambedkar","Indira Gandhi","Vallabhbhai Patel","Rajiv Gandhi"],
     ["In what year did India launch major liberalizing reforms?","1991","1950","1971","2001"],
     ["Who led the Khmer Rouge?","Pol Pot","Ho Chi Minh","Norodom Sihanouk","Hun Sen"]]},

{ t:"Rights and Social Movements", s:"Women, workers, and human rights in the modern world",
  sec:[
  ["The struggle for women's rights",[
    "The first wave of feminism focused on legal rights, especially the vote. New Zealand became the first self-governing country to grant women the vote in national elections, in 1893. Britain's suffragettes, led by Emmeline Pankhurst, used militant tactics; women gained the vote in Britain partly in 1918 and on equal terms in 1928, and in the United States through the 19th Amendment in 1920. France granted it only in 1944, and Switzerland at the federal level in 1971.",
    "The second wave, from the 1960s, addressed equality in work, education, family, and sexuality. Simone de Beauvoir's The Second Sex (1949) and Betty Friedan's The Feminine Mystique (1963) were influential. The birth control pill, legal reforms, and women's mass entry into paid employment transformed societies, although gaps in pay and political representation persist."]],
  ["Human rights",[
    "After World War II, the idea of universal human rights became central to international politics. The Universal Declaration of Human Rights, adopted by the U.N. General Assembly in 1948 with Eleanor Roosevelt chairing the drafting commission, set out civil, political, economic, and social rights for all people.",
    "Organizations such as Amnesty International (founded 1961) campaigned for political prisoners. International courts, including the International Criminal Court (established 2002), were created to try genocide and war crimes. Human-rights ideas inspired dissidents in communist countries and opponents of dictatorships worldwide."]],
  ["Nonviolent resistance",[
    "The 20th century saw the rise of organized nonviolent resistance as a method of political change. Gandhi's campaigns in India influenced Martin Luther King Jr. and the American civil rights movement, as well as anti-apartheid activists and others.",
    "Research by political scientists has found that nonviolent campaigns have often been more successful than violent ones in achieving their goals, partly because they attract wider participation. Examples include the Philippines' People Power Revolution of 1986, which toppled Ferdinand Marcos, and many of the revolutions of 1989."]],
  ["Labor, religion, and identity",[
    "Workers' movements shaped the century, winning the eight-hour day, collective bargaining, and social insurance in many countries; the International Labour Organization was founded in 1919. Religious movements also mobilized for political change, from Christian Democracy in Europe and liberation theology in Latin America to Islamist movements in the Middle East.",
    "From the late 1960s, movements for the rights of gay and lesbian people grew, symbolized by the Stonewall uprising in New York in 1969, along with movements for the rights of Indigenous peoples and people with disabilities."]],
  ["Environmentalism",[
    "The modern environmental movement grew in response to industrial pollution and nuclear testing. Rachel Carson's Silent Spring (1962) exposed the dangers of pesticides such as DDT. The first Earth Day took place in 1970, and governments created environmental agencies and laws.",
    "International agreements followed, including the Montreal Protocol (1987), which successfully phased out chemicals that damaged the ozone layer, and agreements on climate change such as the Kyoto Protocol (1997) and the Paris Agreement (2015)."]]
  ],
  terms:[["Suffrage","The right to vote."],["First-wave feminism","The early movement focused on legal rights and the vote."],["Second-wave feminism","The 1960s–1980s movement for broader social equality."],["Universal Declaration of Human Rights","The 1948 U.N. statement of universal rights."],["Nonviolent resistance","Political change through civil disobedience and mass protest."],["Silent Spring","Rachel Carson's 1962 book that helped launch environmentalism."]],
  w:"Social movements for women's rights, human rights, labor, and the environment changed laws and values worldwide, showing how ordinary people shape history.",
  src:["Women's suffrage","Feminism","Universal Declaration of Human Rights","Nonviolent resistance","Stonewall riots","Silent Spring"],
  q:[["Which was the first self-governing country to grant women the national vote?","New Zealand","The United States","Britain","Finland"],
     ["Who led Britain's militant suffragettes?","Emmeline Pankhurst","Millicent Fawcett","Mary Wollstonecraft","Virginia Woolf"],
     ["Who wrote The Second Sex?","Simone de Beauvoir","Betty Friedan","Gloria Steinem","Germaine Greer"],
     ["Who chaired the commission that drafted the Universal Declaration of Human Rights?","Eleanor Roosevelt","Ralph Bunche","Dag Hammarskjöld","René Cassin"],
     ["Which 1986 nonviolent revolution toppled Ferdinand Marcos?","People Power Revolution","Velvet Revolution","Carnation Revolution","Saffron Revolution"],
     ["Which agreement phased out chemicals damaging the ozone layer?","The Montreal Protocol","The Kyoto Protocol","The Paris Agreement","The Rio Declaration"]]},

{ t:"Globalization and the Twenty-First Century", s:"An interconnected and contested world",
  sec:[
  ["What is globalization?",[
    "Globalization is the growing integration of the world through trade, investment, migration, communication, and culture. It is not new: the Silk Roads, the Columbian Exchange, and 19th-century imperialism all connected the world. But since the late 20th century, the pace has accelerated dramatically.",
    "Its foundations were laid after World War II by institutions created at the Bretton Woods conference in 1944, the International Monetary Fund and the World Bank, and by the General Agreement on Tariffs and Trade (GATT), succeeded by the World Trade Organization in 1995. Container shipping, which spread from the 1950s and 1960s, slashed transport costs."]],
  ["The digital revolution",[
    "Computers developed during and after World War II, and the invention of the transistor (1947) and the microchip made them ever smaller and cheaper. The personal computer spread in the 1980s. The internet grew from the U.S. military's ARPANET (1969), and Tim Berners-Lee invented the World Wide Web in 1989–1991.",
    "Mobile phones, smartphones (the iPhone appeared in 2007), and social media transformed communication, commerce, politics, and daily life. Artificial intelligence emerged in the 2020s as a major new technology with uncertain consequences."]],
  ["Winners, losers, and crises",[
    "Globalization helped reduce extreme poverty dramatically, especially in China and India, but it also contributed to job losses in some industrial regions of rich countries and to rising inequality within many nations. Protesters at the 1999 WTO meeting in Seattle criticized its effects.",
    "Financial crises spread quickly in a connected world. The global financial crisis of 2007–2008, triggered by the collapse of the U.S. housing bubble and risky mortgage-backed securities, caused the worst recession since the 1930s. The eurozone debt crisis followed. These crises fueled populist movements on both left and right."]],
  ["Terrorism and war",[
    "On 11 September 2001, the Islamist terrorist group al-Qaeda, led by Osama bin Laden, hijacked four airliners and attacked the World Trade Center and the Pentagon, killing nearly 3,000 people. The United States launched a “War on Terror,” including wars in Afghanistan (2001–2021) and Iraq (2003–2011).",
    "In 2022 Russia launched a full-scale invasion of Ukraine, the largest war in Europe since 1945, deepening tensions between Russia and the West. Rivalry between the United States and China became a defining feature of world politics."]],
  ["Pandemic, climate, and migration",[
    "The COVID-19 pandemic, which began in late 2019, killed millions worldwide, disrupted economies, and showed both the vulnerabilities of a connected world and the speed of modern science, as vaccines were developed within a year.",
    "Climate change, driven mainly by greenhouse gases from burning fossil fuels since the Industrial Revolution, has become one of the defining challenges of the century. Global population grew from about 2.5 billion in 1950 to over 8 billion by 2022, and migration, driven by war, poverty, and opportunity, reshaped societies."]],
  ["History and the present",[
    "Historians caution against assuming the present is the end point of history. Each era believed its arrangements were permanent; empires, alliances, and ideologies that seemed eternal have repeatedly collapsed.",
    "Studying history does not predict the future, but it provides perspective: an understanding of how institutions, ideas, and conflicts developed, of the role of choice and contingency, and of the many ways people have lived. That perspective is the goal of every branch you explore from here."]]
  ],
  terms:[["Globalization","The growing integration of the world's economies and societies."],["Bretton Woods","The 1944 conference that created the IMF and World Bank."],["World Trade Organization","The body overseeing global trade rules since 1995."],["World Wide Web","The internet information system invented by Tim Berners-Lee."],["Global financial crisis","The 2007–2008 financial collapse and recession."],["Climate change","Long-term warming driven mainly by greenhouse gas emissions."]],
  w:"Globalization explains the interconnected world we live in, its opportunities and its crises, and why events anywhere now affect people everywhere.",
  src:["Globalization","Bretton Woods system","World Trade Organization","World Wide Web","2007–2008 financial crisis","September 11 attacks","COVID-19 pandemic"],
  q:[["Which 1944 conference created the IMF and World Bank?","Bretton Woods","Yalta","Potsdam","San Francisco"],
     ["In what year was the World Trade Organization established?","1995","1944","1971","2001"],
     ["Who invented the World Wide Web?","Tim Berners-Lee","Vint Cerf","Bill Gates","Steve Jobs"],
     ["The internet grew out of which network?","ARPANET","Ethernet","Minitel","BITNET"],
     ["What triggered the 2007–2008 financial crisis?","The collapse of the U.S. housing bubble","The oil embargo","The fall of the Berlin Wall","The COVID-19 pandemic"],
     ["Roughly what was world population in 1950?","2.5 billion","1 billion","5 billion","8 billion"]]},

{ t:"The Big Patterns of History", s:"Tying the course together",
  sec:[
  ["Long-term forces",[
    "Looking back across this course, several long-term forces stand out. Agriculture, beginning about 12,000 years ago, made settled life, cities, and states possible. Writing allowed records, law, and literature. Large-scale states and empires repeatedly rose by combining military force, taxation, and ideology, and fell through overextension, internal conflict, and external pressure.",
    "The Industrial Revolution was the greatest transformation since agriculture: before it, most people lived as farmers near subsistence; after it, economies could grow continuously, populations exploded, and a few nations gained enormous power over others."]],
  ["Connections and exchange",[
    "History is a story of connection. Trade routes such as the Silk Roads, the Indian Ocean network, and the trans-Saharan trade spread goods, religions, technologies, and diseases. The Columbian Exchange after 1492 transformed diets and populations on every continent and devastated the Americas through epidemic disease.",
    "World religions such as Buddhism, Christianity, and Islam spread along these networks, as did ideas such as the printing press, gunpowder, and later Enlightenment and nationalist thought."]],
  ["Power and inequality",[
    "Much of history involves the struggle over power: between rulers and subjects, conquerors and conquered, masters and the enslaved, and among classes, religions, and nations. Slavery and coerced labor existed in many societies, and the Atlantic slave trade and colonialism created inequalities whose effects persist.",
    "Equally important are the movements that challenged domination: slave revolts, abolitionism, democratic revolutions, labor and women's movements, anti-colonial struggles, and civil rights movements."]],
  ["Contingency and choice",[
    "Historians stress contingency: outcomes were not inevitable. Battles could have gone the other way, leaders made choices, and accidents mattered. The assassination at Sarajevo, the decisions of 1914, Gorbachev's refusal to use force in 1989: each shows that individuals and chance shape events within larger structures.",
    "Good historical thinking balances structure and agency, avoids judging the past solely by present standards while still making moral judgments, and recognizes that sources are partial and perspectives differ."]],
  ["Where to go next",[
    "These foundations give you a framework: the major civilizations, eras, turning points, and concepts. Each branch from here, whether American history, a particular century, a region, or a theme like military or economic history, builds on this structure, adding depth, detail, and debate.",
    "The more you learn, the more connections you will see. There is always more to learn: new sources, new questions, and new perspectives continually reshape our understanding of the past."]]
  ],
  terms:[["Contingency","The idea that historical outcomes depended on choices and chance."],["Structure and agency","Large forces versus individual choices in history."],["Columbian Exchange","The transfer of plants, animals, and diseases after 1492."],["Great Divergence","The 19th-century gap in wealth between the West and the rest."],["Periodization","Dividing history into eras."]],
  w:"Seeing the big patterns of history helps you place any new fact or story into a larger framework, turning knowledge into understanding.",
  src:["World history (field)","Neolithic Revolution","Industrial Revolution","Columbian exchange","Great Divergence","Contingency (philosophy)"],
  q:[["Which transformation do many historians call the greatest since agriculture?","The Industrial Revolution","The Renaissance","The Reformation","The French Revolution"],
     ["What is the term for the idea that historical outcomes were not inevitable?","Contingency","Determinism","Teleology","Periodization"],
     ["Which exchange transferred crops, animals, and diseases after 1492?","The Columbian Exchange","The Silk Road exchange","The Bretton Woods exchange","The trans-Saharan trade"],
     ["Roughly when did agriculture begin?","About 12,000 years ago","About 2,000 years ago","About 100,000 years ago","About 5,000 years ago"],
     ["What does “structure and agency” contrast?","Large forces and individual choices","Primary and secondary sources","Ancient and modern history","East and West"],
     ["Which of these spread along trade networks?","Religions, technologies, and diseases","Only luxury goods","Only languages","Nothing besides goods"]]}

);


/* ---- from hist-15.js ---- */
/* HISTORY FOUNDATIONS, part 15: extra chapters inserted into earlier units */
COURSES.history.units[2].ch.push(
{ t:"The Silk Roads and the Indian Ocean", s:"Trade networks that connected Afro-Eurasia",
  sec:[
  ["The Silk Roads",[
    "The Silk Roads were not a single road but a shifting web of overland routes linking China with Central Asia, India, Persia, the Middle East, and the Mediterranean. The term was coined by the German geographer Ferdinand von Richthofen in 1877. The network took shape after the Han dynasty envoy Zhang Qian traveled west in the 2nd century BCE and the Han extended control into Central Asia.",
    "Few merchants traveled the whole route; goods passed through many hands. Chinese silk, paper, and porcelain moved west, while horses, glassware, silver, wool, and precious stones moved east. Central Asian oasis cities such as Samarkand, Bukhara, and Kashgar grew rich, and the Sogdians of Central Asia were among the most important middlemen for centuries."]],
  ["Ideas, religions, and disease",[
    "The Silk Roads carried far more than goods. Buddhism spread from India through Central Asia to China, Korea, and Japan, leaving monuments such as the cave temples at Dunhuang. Nestorian Christianity, Manichaeism, Zoroastrianism, and later Islam traveled the same routes. Technologies spread too: papermaking reached the Islamic world by the 8th century, traditionally after the Battle of Talas in 751.",
    "Disease also traveled. The Black Death, the plague pandemic caused by the bacterium Yersinia pestis, spread from Central Asia along trade routes in the 1340s, killing perhaps a third or more of Europe's population and devastating the Middle East and North Africa. The Silk Roads flourished most under unifying empires, especially the Tang dynasty and the Mongol Empire, whose Pax Mongolica allowed travelers such as Marco Polo to cross Eurasia."]],
  ["The Indian Ocean world",[
    "Maritime trade across the Indian Ocean was even larger than the overland trade. Sailors learned to use the monsoon winds, which blow from the southwest in summer and the northeast in winter, to make predictable voyages between East Africa, Arabia, India, Southeast Asia, and China. Ships such as the Arab dhow and later huge Chinese junks carried bulk goods: textiles, spices, pepper, rice, timber, horses, and ceramics.",
    "Port cities linked the network: Kilwa, Mombasa, and Zanzibar on the Swahili coast of East Africa; Aden and Hormuz in the Middle East; Calicut and Cambay in India; and Malacca, which controlled the strait between Sumatra and the Malay Peninsula. Merchant communities of many faiths settled in these ports, creating cosmopolitan societies."]],
  ["Islam, the Swahili coast, and Southeast Asia",[
    "Islam spread across the Indian Ocean largely through merchants rather than conquest. The Swahili city-states of East Africa developed a culture that blended African Bantu language and traditions with Arabic and Persian influences, and stone mosques and palaces arose at Kilwa and elsewhere. Gold from Great Zimbabwe in the interior reached the coast and the wider ocean trade.",
    "In Southeast Asia, the trading empire of Srivijaya, based on Sumatra, flourished from about the 7th to the 13th centuries and was a center of Buddhist learning. Later, rulers of port cities such as Malacca converted to Islam, which spread across much of today's Indonesia and Malaysia."]],
  ["The Ming voyages and the arrival of the Portuguese",[
    "Between 1405 and 1433, the Ming admiral Zheng He, a Muslim eunuch, led seven great voyages with fleets of hundreds of ships and tens of thousands of men, reaching India, Arabia, and East Africa. The voyages displayed Ming power and collected tribute but were then halted, and China turned inward.",
    "In 1498 the Portuguese navigator Vasco da Gama reached Calicut by sailing around Africa. The Portuguese used armed ships and fortified bases, such as Goa (1510) and Malacca (1511), to try to control the spice trade. Later the Dutch and English East India Companies took over much of this trade, beginning the era of European dominance in the Indian Ocean."]],
  ["Why these networks matter",[
    "The Silk Roads and the Indian Ocean show that the world was connected long before European expansion. They spread crops, technologies, religions, art, and disease, and they enriched the empires and cities that controlled them.",
    "Historians increasingly study world history through such networks rather than through single civilizations, emphasizing exchange and interaction as engines of change."]]
  ],
  terms:[["Silk Roads","The overland trade network linking China and the Mediterranean."],["Sogdians","Central Asian merchants who dominated Silk Road trade."],["Monsoon","Seasonal winds that made Indian Ocean voyages predictable."],["Swahili coast","The East African coast of trading city-states."],["Srivijaya","A maritime trading empire based on Sumatra."],["Zheng He","The Ming admiral who led seven great voyages."]],
  w:"The Silk Roads and Indian Ocean trade connected Asia, Africa, and Europe for centuries, spreading goods, faiths, technologies, and diseases that shaped every civilization they touched.",
  src:["Silk Road","Indian Ocean trade","Swahili coast","Srivijaya","Zheng He","Black Death"],
  q:[["Who coined the term Silk Road?","Ferdinand von Richthofen","Marco Polo","Zhang Qian","Ibn Battuta"],
     ["Which Central Asian people were major Silk Road middlemen?","The Sogdians","The Vikings","The Phoenicians","The Aztecs"],
     ["What made Indian Ocean voyages predictable?","The monsoon winds","The Gulf Stream","The trade winds of the Atlantic","Steam power"],
     ["Which empire based on Sumatra dominated maritime trade from about the 7th century?","Srivijaya","Majapahit","Khmer","Champa"],
     ["Who led the Ming treasure voyages?","Zheng He","Kublai Khan","Hongwu","Yongle"],
     ["Who reached Calicut in 1498 by sailing around Africa?","Vasco da Gama","Christopher Columbus","Bartolomeu Dias","Ferdinand Magellan"]]}
);

COURSES.history.units[5].ch.push(
{ t:"Settler Societies: Canada, Australia, and New Zealand", s:"Colonization, Indigenous peoples, and new nations",
  sec:[
  ["Settler colonialism",[
    "Settler colonies were places where Europeans came not just to rule or trade but to settle permanently in large numbers, displacing Indigenous peoples and building new societies. Besides the United States, the most important British examples were Canada, Australia, and New Zealand, while South Africa and Argentina also attracted many settlers.",
    "In all of them, Indigenous peoples suffered loss of land, epidemic disease, violence, and policies of forced assimilation, and their histories and continuing presence are now central to how these nations understand themselves."]],
  ["Canada",[
    "France founded New France along the St. Lawrence River, with Quebec established by Samuel de Champlain in 1608, and built a fur-trade economy in partnership and conflict with First Nations. Britain conquered New France in the Seven Years' War; the Treaty of Paris (1763) confirmed it. After the American Revolution, Loyalists moved north.",
    "Canada became a self-governing Dominion through Confederation in 1867, uniting Ontario, Quebec, New Brunswick, and Nova Scotia, and expanded west, building a transcontinental railway completed in 1885. The Métis leader Louis Riel led resistance movements in 1869–1870 and 1885 and was executed. From the 1880s to the 1990s, Indigenous children were sent to residential schools designed to erase their cultures, where many suffered abuse and thousands died."]],
  ["Australia",[
    "Aboriginal and Torres Strait Islander peoples had lived in Australia for at least 50,000 to 65,000 years, forming the world's oldest continuous cultures. Britain, after James Cook's voyage of 1770, established a penal colony at Sydney in 1788 with the First Fleet; about 160,000 convicts were transported over the next eighty years.",
    "Colonists treated the land as terra nullius, “nobody's land,” and settlement brought frontier violence, disease, and dispossession. Gold rushes in the 1850s brought migrants and wealth. The six colonies federated as the Commonwealth of Australia in 1901, adopting a “White Australia” policy restricting non-European immigration that was dismantled only in the 1960s and 1970s. The High Court's Mabo decision of 1992 rejected terra nullius and recognized native title."]],
  ["New Zealand",[
    "The Māori, Polynesian voyagers, settled New Zealand around 1250–1300 CE, among the last major landmasses settled by humans. In 1840, British officials and many Māori chiefs signed the Treaty of Waitangi, whose English and Māori versions differed on the key issue of sovereignty.",
    "As settlers demanded land, the New Zealand Wars (1845–1872) were fought between the government and some Māori groups, and much Māori land was confiscated or purchased under pressure. Since 1975, the Waitangi Tribunal has investigated breaches of the treaty, leading to settlements. New Zealand became a pioneer of social reform, granting women the vote in 1893."]],
  ["Independence by evolution",[
    "Unlike the United States, these dominions gained independence gradually and peacefully. Their soldiers fought in large numbers in both world wars, and battles such as Gallipoli for Australia and New Zealand and Vimy Ridge (1917) for Canada became symbols of national identity.",
    "The Statute of Westminster (1931) recognized the dominions' legislative independence, and later acts completed the process, such as Canada's patriation of its constitution in 1982. All remain constitutional monarchies within the Commonwealth, and all have become diverse, high-immigration democracies."]]
  ],
  terms:[["Settler colonialism","Colonization in which settlers replace Indigenous populations on the land."],["Confederation","The 1867 union that created the Dominion of Canada."],["Residential schools","Canadian boarding schools meant to assimilate Indigenous children."],["Terra nullius","The false claim that Australia belonged to no one."],["Treaty of Waitangi","The 1840 treaty between the British Crown and Māori chiefs."],["Statute of Westminster","The 1931 act recognizing the dominions' legislative independence."]],
  w:"The histories of Canada, Australia, and New Zealand show how settler societies were built, how Indigenous peoples were dispossessed, and how nations gained independence without revolution.",
  src:["Settler colonialism","Canadian Confederation","Canadian Indian residential school system","History of Australia","Treaty of Waitangi","Statute of Westminster 1931"],
  q:[["Who founded Quebec in 1608?","Samuel de Champlain","Jacques Cartier","Louis Riel","James Wolfe"],
     ["In what year did Canadian Confederation occur?","1867","1763","1901","1931"],
     ["Which Métis leader was executed in 1885?","Louis Riel","Tecumseh","Joseph Brant","Gabriel Dumont"],
     ["When did the First Fleet arrive at Sydney?","1788","1770","1851","1901"],
     ["Which 1992 court decision rejected terra nullius in Australia?","Mabo","Wik","Waitangi","Westminster"],
     ["Which 1840 treaty was signed between the British Crown and Māori chiefs?","The Treaty of Waitangi","The Treaty of Paris","The Treaty of Nanjing","The Statute of Westminster"]]}
);

/* insert before the closing "Big Patterns" chapter */
COURSES.history.units[7].ch.splice(COURSES.history.units[7].ch.length-1, 0,
{ t:"Money, Markets, and Capitalism", s:"An economic history of the modern world",
  sec:[
  ["Before capitalism",[
    "For most of history, the great majority of people were farmers, and economic growth per person was extremely slow. Coinage appeared in Lydia in western Anatolia around the 7th century BCE, and paper money in Song China around the 11th century. Long-distance trade, banking, and credit flourished in many societies, from the Islamic world to Renaissance Italy, where families such as the Medici built banking empires and double-entry bookkeeping spread.",
    "Many societies limited markets through customs, guilds, religious rules against usury, and the power of landed elites. The question of why sustained growth began in some places and not others is one of the great debates in history."]],
  ["Mercantilism and the commercial revolution",[
    "From the 16th to the 18th centuries, European states pursued mercantilism, the belief that national power depended on accumulating gold and silver, maximizing exports, and controlling colonial trade. Chartered companies such as the Dutch East India Company (VOC, 1602), which issued shares traded on the Amsterdam exchange, and the English East India Company (1600) combined trade, war, and government.",
    "New financial institutions appeared: the Bank of Amsterdam (1609), the Bank of England (1694), stock markets, and national debts. Speculative bubbles, such as the Dutch tulip mania of the 1630s and the South Sea Bubble of 1720, showed the risks."]],
  ["Adam Smith and industrial capitalism",[
    "In The Wealth of Nations (1776), the Scottish philosopher Adam Smith argued that the division of labor and free markets, guided by the “invisible hand” of self-interest and competition, would create wealth more effectively than mercantilist controls. His ideas became the basis of classical economics and the free-trade movement; Britain repealed its protectionist Corn Laws in 1846.",
    "The Industrial Revolution combined capital, wage labor, and machines in the factory system. Critics, above all Karl Marx in Capital (1867), argued that capitalism exploited workers and would be overthrown. Others, such as the founders of social insurance in Bismarck's Germany in the 1880s, sought to reform it."]],
  ["The gold standard and the first globalization",[
    "By the late 19th century, most major economies were on the gold standard, under which currencies were convertible into fixed amounts of gold. With steamships, railways, and the telegraph, the decades before 1914 saw a “first globalization” of trade, investment, and migration. London was the center of world finance.",
    "World War I shattered this system. Attempts to restore it in the 1920s contributed to the Great Depression, and most countries abandoned gold in the 1930s. After 1945, the Bretton Woods system tied currencies to the U.S. dollar, which was convertible into gold, until President Nixon ended convertibility in 1971."]],
  ["Debates of the 20th century",[
    "The 20th century featured a great contest of economic systems: capitalism, socialism, and state planning. John Maynard Keynes argued that governments should manage demand to fight unemployment, and Keynesian policies dominated the postwar decades. Friedrich Hayek and Milton Friedman argued for free markets and against central planning, ideas that influenced the market reforms of the 1980s under Reagan and Thatcher.",
    "The failure of Soviet-style planning and the success of market reforms in China after 1978 led most of the world to adopt market economies, though with very different degrees of state involvement, welfare, and regulation. Debates over inequality, financial instability, and the environment continue."]],
  ["The Great Divergence and Great Enrichment",[
    "Before about 1800, living standards in the most advanced parts of China, India, and Europe may have been broadly comparable. During the 19th century, Western Europe and North America industrialized and pulled far ahead, a process historians call the Great Divergence. Explanations include coal, colonies, institutions, science, and culture.",
    "Since then, sustained economic growth has transformed human life: average incomes in many countries have risen by more than ten times, and life expectancy worldwide has more than doubled. Understanding how this happened, and why it remains uneven, is one of the central questions of modern history."]]
  ],
  terms:[["Mercantilism","Policies aimed at national wealth through exports and colonial control."],["Joint-stock company","A company owned by shareholders, such as the VOC."],["Invisible hand","Smith's image of markets coordinating self-interest."],["Gold standard","A system tying currency to a fixed amount of gold."],["Keynesian economics","Using government spending to manage the economy."],["Great Divergence","The 19th-century pulling ahead of the West economically."]],
  w:"Economic history explains why some societies grew rich, how capitalism developed, and why debates over markets and the state still dominate politics.",
  src:["Economic history of the world","Mercantilism","Dutch East India Company","The Wealth of Nations","Gold standard","Great Divergence"],
  q:[["Where did coinage first appear?","Lydia","Egypt","China","Rome"],
     ["Which company, founded in 1602, issued shares traded in Amsterdam?","The Dutch East India Company","The English East India Company","The Hudson's Bay Company","The South Sea Company"],
     ["Who wrote The Wealth of Nations?","Adam Smith","David Ricardo","Karl Marx","John Locke"],
     ["In what year did Britain repeal the Corn Laws?","1846","1776","1815","1873"],
     ["When did Nixon end the dollar's convertibility into gold?","1971","1944","1929","1989"],
     ["What is the 19th-century economic gap between the West and the rest called?","The Great Divergence","The Great Depression","The Great Leap","The Great Moderation"]]},

{ t:"Science, Medicine, and Technology in the Modern World", s:"How knowledge changed human life",
  sec:[
  ["The age of science",[
    "Building on the Scientific Revolution, the 19th century made science a profession and an engine of change. Charles Darwin's On the Origin of Species (1859) proposed evolution by natural selection, transforming biology and challenging traditional views of humanity's place in nature. Chemistry, physics, and geology became organized disciplines, and research universities, beginning in Germany, linked teaching with discovery.",
    "In the early 20th century, Albert Einstein's theories of relativity (1905 and 1915) and the development of quantum mechanics overturned classical physics. Splitting the atom led to nuclear energy and the atomic bomb, developed by the American-led Manhattan Project during World War II."]],
  ["The medical revolution",[
    "Medicine changed more in the last two centuries than in all previous history. Edward Jenner developed smallpox vaccination in 1796. In the 1860s and 1870s Louis Pasteur and Robert Koch established the germ theory of disease, and Joseph Lister introduced antiseptic surgery. Anesthesia made surgery bearable.",
    "Public health measures such as clean water and sewers, pioneered after cholera epidemics, may have saved even more lives than medicine itself. Alexander Fleming discovered penicillin in 1928, and antibiotics became widely available in the 1940s. Smallpox was declared eradicated in 1980, the only human disease eliminated so far. Global life expectancy rose from about 30 years in 1900 to over 70 today."]],
  ["Energy and transportation",[
    "Fossil fuels powered modern civilization: coal in the 19th century, then oil and natural gas. Electricity, spread by inventors and entrepreneurs such as Thomas Edison and Nikola Tesla, transformed homes and industry. The internal-combustion engine made automobiles possible; Henry Ford's assembly line made the Model T affordable from 1913.",
    "The Wright brothers made the first powered airplane flight in 1903; within half a century, jet airliners crossed oceans in hours. Rockets carried satellites and, in 1969, humans to the Moon."]],
  ["Food and population",[
    "The Haber-Bosch process, developed in Germany around 1909–1913, allowed the industrial production of nitrogen fertilizer, and today it helps feed roughly half of the world's population. The Green Revolution of the 1950s–1970s, associated with the plant scientist Norman Borlaug, spread high-yield crop varieties, irrigation, and fertilizers, greatly increasing harvests in Asia and Latin America.",
    "Together with medicine, these advances made possible the explosive growth of world population, from about 1 billion around 1800 to over 8 billion today, and the movement of most of humanity into cities."]],
  ["Costs and questions",[
    "Science and technology also brought new dangers: industrialized warfare, nuclear weapons, environmental destruction, and climate change from burning fossil fuels. Scientific racism and eugenics, which claimed to rank human groups, were used to justify discrimination, forced sterilization, and genocide.",
    "Modern history thus shows both the immense power of knowledge to improve human life and the need for ethical choices about its use, a question that continues with genetics, artificial intelligence, and other new technologies."]]
  ],
  terms:[["Natural selection","Darwin's mechanism of evolution."],["Germ theory","The theory that microorganisms cause many diseases."],["Penicillin","The first widely used antibiotic, discovered in 1928."],["Haber-Bosch process","The industrial production of ammonia for fertilizer."],["Green Revolution","The spread of high-yield agriculture after 1950."],["Eugenics","The discredited movement to 'improve' human heredity."]],
  w:"Science, medicine, and technology have doubled life expectancy and transformed daily life, while also creating dangers that demand wise choices.",
  src:["On the Origin of Species","Germ theory of disease","Penicillin","Haber process","Green Revolution","Eugenics"],
  q:[["In what year did Darwin publish On the Origin of Species?","1859","1809","1871","1905"],
     ["Who developed smallpox vaccination?","Edward Jenner","Louis Pasteur","Robert Koch","Joseph Lister"],
     ["Who discovered penicillin?","Alexander Fleming","Jonas Salk","Howard Florey","Paul Ehrlich"],
     ["In what year was smallpox declared eradicated?","1980","1955","1967","2000"],
     ["Which process made industrial nitrogen fertilizer possible?","The Haber-Bosch process","The Bessemer process","The Solvay process","The Green Revolution"],
     ["Who is most associated with the Green Revolution?","Norman Borlaug","Fritz Haber","Gregor Mendel","Rachel Carson"]]}
);
