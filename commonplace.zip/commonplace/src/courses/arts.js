/* ---- from arts-01.js ---- */
/* ARTS FOUNDATIONS, part 1: Unit 1 How to Look at Art, chapters 1-5 */
COURSES.arts = { units: [] };
COURSES.arts.units.push({ t:"How to Look at Art", ch:[

{ t:"What Is Art?", s:"Making, meaning, and looking",
  sec:[
  ["A human universal",[
    "Every known human society has made art: images, carvings, ornaments, music, dance, and stories. The oldest known figurative paintings, in caves on the Indonesian island of Sulawesi, are at least 45,000 to 51,000 years old, and engraved patterns and shell beads go back even further. Making art seems to be one of the things that makes us human.",
    "The visual arts traditionally include painting, drawing, sculpture, printmaking, and architecture, and in modern times photography, film, video, installation, performance, and digital media. The decorative or applied arts include ceramics, textiles, furniture, metalwork, glass, and jewelry. The line between “fine art” and “craft” is a European idea from the Renaissance onward; many cultures make no such distinction."]],
  ["Changing definitions",[
    "What counts as art has changed over time. For the ancient Greeks, the word technē meant skill in any craft. During the Renaissance, painters and sculptors fought to be seen as intellectuals rather than manual workers, and in the 18th century the idea of the “fine arts,” valued for beauty rather than usefulness, took shape. Philosophers such as Immanuel Kant connected art with aesthetic experience, a special kind of disinterested pleasure.",
    "The 20th century broke many rules. In 1917 Marcel Duchamp submitted a store-bought urinal, signed “R. Mutt” and titled Fountain, to an exhibition, asking whether an artist's choice alone could make something art. Since then, philosophers such as Arthur Danto and George Dickie have argued that art is defined partly by its context, the “artworld” of artists, critics, museums, and audiences."]],
  ["Why people make art",[
    "Art has served many purposes. It has been religious, giving form to gods and stories, as in Egyptian tombs, Gothic cathedrals, and Buddhist temples. It has been political, glorifying rulers or protesting injustice, from Roman triumphal arches to Picasso's Guernica. It has recorded people and events, through portraits and history paintings, and decorated homes and objects.",
    "Art also expresses emotion and individual vision, explores ideas, entertains, and shows off wealth and status. Many works do several of these at once. Asking “What was this made for?” is one of the best ways to begin understanding any artwork."]],
  ["Looking slowly",[
    "Studies of museum visitors have found that people often spend only a few seconds in front of each artwork. Looking slowly reveals much more. A useful approach is to move through three stages: first, describe what you actually see, colors, shapes, figures, materials, size; second, analyze how it is put together and what effects those choices create; third, interpret what it might mean, considering its context.",
    "Questions to ask include: What is the subject? What materials and techniques were used? How is the composition arranged, and where does my eye go first? What mood does it create? Who made it, when, where, and for whom? How would its original viewers have seen it?"]],
  ["Form and content",[
    "Art historians distinguish form, the visual elements and how they are arranged, from content, the subject and meaning. Formal analysis, championed by critics such as Heinrich Wölfflin and later Clement Greenberg, focuses on line, color, composition, and space. Iconography, developed by Erwin Panofsky, studies the meaning of symbols and subjects, such as why a lily in a painting of the Virgin Mary signifies purity.",
    "Other approaches consider the social and economic conditions in which art was made, the role of patrons, gender, race, and power, and how viewers' responses shape meaning. No single approach is complete; each reveals different aspects."]],
  ["Style and period",[
    "Style refers to the distinctive manner of an artist, a school, a region, or a period. Art historians group works into periods and movements, such as Gothic, Renaissance, Baroque, Impressionism, and Cubism, to understand shared features and changes over time. A trained eye can often date and place a work by its style.",
    "These labels are useful but imperfect; many were coined later, sometimes as insults (“Gothic,” “Baroque,” “Impressionism,” and “Fauvism” all began as criticisms), and artists rarely fit neatly into one category. This course will introduce the major traditions of world art, the ways artists work, and the tools you need to look, understand, and enjoy."]]
  ],
  terms:[["Visual arts","Painting, drawing, sculpture, printmaking, photography, film, and related media."],["Decorative arts","Crafted objects such as ceramics, textiles, and furniture."],["Aesthetics","The philosophy of beauty and artistic experience."],["Form and content","How a work looks versus what it shows and means."],["Iconography","The study of symbols and subjects in art."],["Style","The distinctive manner of an artist, school, or period."]],
  w:"Learning what art is and how to look at it slowly turns a glance into understanding, and opens up every work you will meet in this course.",
  src:["Art","Visual arts","Fountain (Duchamp)","Aesthetics","Iconography","Erwin Panofsky","Formal analysis"],
  q:[["Where are some of the oldest known figurative cave paintings?","Sulawesi, Indonesia","Lascaux, France","Altamira, Spain","Chauvet, France"],
     ["What did Duchamp submit to an exhibition in 1917?","A urinal titled Fountain","A bicycle wheel","A blank canvas","A shovel"],
     ["Who developed iconography as a method of studying meaning in art?","Erwin Panofsky","Clement Greenberg","Heinrich Wölfflin","Giorgio Vasari"],
     ["What does formal analysis focus on?","Visual elements and composition","The artist's biography","The price of the work","The museum's history"],
     ["Which of these style names began as an insult?","Impressionism","Renaissance","Neoclassicism","Romanesque"],
     ["What did the Greek word technē mean?","Skill in any craft","Beauty","Painting","Religion"]]},

{ t:"The Elements of Art", s:"Line, shape, color, value, texture, and space",
  sec:[
  ["Line",[
    "The elements of art are the basic visual building blocks of any image. Line is a mark longer than it is wide. Lines can be straight or curved, thick or thin, smooth or jagged, and they convey movement and feeling: horizontal lines suggest calm, verticals stability or aspiration, diagonals energy and movement, curves grace.",
    "Lines define contours, the outer edges of forms, and can create texture and shading through hatching (parallel lines) and cross-hatching. Implied lines, such as the direction of a figure's gaze or pointing arm, guide the viewer's eye. Some artists are famous for line, from the flowing contours of Botticelli and Japanese printmakers to the energetic brushwork of Van Gogh."]],
  ["Shape and form",[
    "Shape is a flat, two-dimensional area defined by edges, color, or value. Geometric shapes, circles, squares, and triangles, look regular and ordered; organic shapes are irregular and found in nature. Positive shapes are the objects themselves; negative space is the area around and between them, which skilled artists treat as carefully as the subject.",
    "Form is three-dimensional, having height, width, and depth, as in sculpture and architecture, or the illusion of three dimensions in painting, created through shading. Mass refers to the bulk or weight of a form."]],
  ["Value",[
    "Value is the lightness or darkness of a tone or color. A value scale runs from white through grays to black. Contrast between light and dark creates drama and focus; low contrast creates softness and calm.",
    "Renaissance artists developed chiaroscuro (Italian for “light-dark”), the modeling of forms through gradations of light and shadow to create the illusion of volume. Caravaggio pushed this to tenebrism, dramatic contrasts of bright light against deep darkness. Leonardo da Vinci perfected sfumato (“smoky”), soft, almost invisible transitions between tones, as in the Mona Lisa's face."]],
  ["Color",[
    "Color has three properties: hue, the name of the color (red, blue, yellow); value, its lightness or darkness; and intensity or saturation, its brightness or dullness. Adding white to a hue makes a tint; adding black makes a shade; adding gray makes a tone.",
    "Colors are often described as warm (reds, oranges, yellows), which tend to advance and feel energetic, or cool (blues, greens, violets), which tend to recede and feel calm. Color carries symbolic and emotional meaning that varies between cultures: white signifies purity in much of the West but mourning in parts of East Asia. The next chapters explore color theory in more depth."]],
  ["Texture",[
    "Texture is the surface quality of a work, how it feels or looks like it would feel. Actual texture can be touched, as in the rough surface of a sculpture or the thick paint of impasto, where paint is applied in heavy layers that stand out from the canvas, as in Van Gogh's and Rembrandt's late works.",
    "Implied texture is the illusion of texture created by an artist, such as the gleam of satin, the softness of fur, or the roughness of bark rendered on a flat surface. Dutch painters of the 17th century were famous for their ability to imitate the textures of silver, glass, fabric, and food."]],
  ["Space",[
    "Space is the area around, between, and within objects. In three-dimensional works, space is real. In two-dimensional works, artists create the illusion of depth through several techniques: overlapping, placing objects higher on the picture plane to suggest distance, making distant objects smaller, and atmospheric (aerial) perspective, in which distant objects appear paler, bluer, and less distinct, as they do in nature.",
    "Linear perspective, developed in Renaissance Florence, uses converging lines meeting at a vanishing point on the horizon to create a convincing illusion of depth. Some traditions, such as Byzantine icons, Japanese prints, and much modern art, deliberately use flat or shallow space for expressive or spiritual reasons."]]
  ],
  terms:[["Contour","A line defining the outer edge of a form."],["Negative space","The space around and between objects."],["Chiaroscuro","Modeling forms through contrasts of light and shadow."],["Sfumato","Soft, smoky transitions between tones."],["Hue, value, intensity","The three properties of color."],["Impasto","Thick paint that stands out from the surface."],["Atmospheric perspective","Depth shown by paler, bluer distant objects."],["Linear perspective","Depth shown by lines converging at a vanishing point."]],
  w:"The elements of art are the vocabulary of every image, and naming them lets you see and describe exactly how a work achieves its effects.",
  src:["Elements of art","Line (art)","Negative space","Chiaroscuro","Sfumato","Impasto","Aerial perspective"],
  q:[["Which kind of line often suggests energy and movement?","Diagonal","Horizontal","Vertical","Contour"],
     ["What is the space around and between objects called?","Negative space","Positive space","Mass","Form"],
     ["What does chiaroscuro mean?","Light-dark","Smoky","Thick paint","Warm-cool"],
     ["Which technique did Leonardo use for soft transitions in the Mona Lisa?","Sfumato","Tenebrism","Impasto","Pointillism"],
     ["Adding white to a hue creates a:","Tint","Shade","Tone","Complement"],
     ["What makes distant objects appear paler and bluer?","Atmospheric perspective","Linear perspective","Foreshortening","Overlapping"]]},

{ t:"Principles of Design and Composition", s:"How artists organize what we see",
  sec:[
  ["Composition",[
    "Composition is the arrangement of elements within a work. Artists use principles of design to organize those elements into a satisfying whole. The main principles are balance, emphasis, movement, rhythm and pattern, proportion and scale, contrast, variety, and unity.",
    "A strong composition guides the viewer's eye, establishes a focal point, and supports the work's meaning. Analyzing composition often begins by asking: Where does my eye go first, and how does it travel around the picture?"]],
  ["Balance",[
    "Balance is the distribution of visual weight. Symmetrical (formal) balance mirrors elements on either side of a central axis, creating stability, order, and dignity; it is common in religious art and architecture, as in Leonardo's Last Supper, with Christ at the center.",
    "Asymmetrical (informal) balance uses different elements that balance one another, such as a large light shape against a small dark one, creating more dynamic, natural compositions; Japanese prints and Impressionist paintings often use it. Radial balance arranges elements around a central point, as in rose windows and mandalas."]],
  ["Emphasis and movement",[
    "Emphasis creates a focal point that draws attention, through contrast of color or value, isolation, placement, size, or lines leading to it. In Caravaggio's The Calling of Saint Matthew, a beam of light and Christ's pointing hand direct attention to Matthew.",
    "Movement is the path the viewer's eye follows, created by lines, shapes, and repeated elements. Rhythm is created by repeating elements with regular or varied intervals, like a beat in music; pattern is a repeated decorative design. Artists such as Hokusai in The Great Wave use rhythm and movement to create energy."]],
  ["Proportion and scale",[
    "Proportion is the relationship of sizes of parts to each other and to the whole. Ancient Greek sculptors, such as Polykleitos, developed canons, systems of ideal proportions for the human body. The golden ratio, about 1.618, has been claimed to underlie many artworks, though its use is often exaggerated.",
    "Scale is the size of an object relative to the viewer or to other objects. Hierarchical scale makes the most important figures largest, regardless of their position in space, as in Egyptian reliefs and medieval art, where pharaohs, gods, or saints tower over others. Monumental scale, as in Michelangelo's David, more than 5 meters tall, creates awe."]],
  ["Contrast, unity, and variety",[
    "Contrast places opposing elements together, light and dark, rough and smooth, large and small, to create interest and emphasis. Variety introduces differences to keep a work lively.",
    "Unity is the sense that all parts belong together, achieved through repetition, consistent style, and harmonious color. Great works balance unity and variety: too much unity becomes monotonous, too much variety chaotic."]],
  ["Classic compositional devices",[
    "Artists have used many recurring devices. The pyramidal composition, perfected by Leonardo and Raphael in High Renaissance paintings of the Madonna and Child, groups figures in a stable triangle. The rule of thirds, a later guideline popular in photography, places points of interest along lines dividing the image into thirds.",
    "Other devices include framing within the picture, such as windows and doorways; leading lines such as roads and rivers; the diagonal compositions of Baroque art, which create drama; and cropping, popularized by Degas under the influence of photography and Japanese prints, which cuts figures at the edges to suggest a moment glimpsed. Foreshortening depicts an object receding sharply toward the viewer, as in Mantegna's Lamentation over the Dead Christ."]]
  ],
  terms:[["Composition","The arrangement of elements in a work."],["Symmetrical balance","Mirror-image arrangement around an axis."],["Asymmetrical balance","Balance achieved with unlike elements."],["Focal point","The area that draws the viewer's attention first."],["Hierarchical scale","Making important figures larger."],["Canon of proportions","A system of ideal body proportions."],["Pyramidal composition","Figures arranged in a stable triangle."],["Foreshortening","Depicting an object receding sharply toward the viewer."]],
  w:"The principles of design explain why a composition feels calm or dramatic, ordered or dynamic, and help you see how artists steer your eye and emotions.",
  src:["Composition (visual arts)","Balance (design)","Hierarchical proportion","Polykleitos","Golden ratio","Rule of thirds","Foreshortening"],
  q:[["Which kind of balance mirrors elements around a central axis?","Symmetrical","Asymmetrical","Radial","Hierarchical"],
     ["What does hierarchical scale do?","Makes the most important figures largest","Arranges figures in a triangle","Mirrors the composition","Uses perspective"],
     ["Which Greek sculptor developed a canon of proportions?","Polykleitos","Phidias","Praxiteles","Myron"],
     ["Which Renaissance compositional device groups figures in a triangle?","Pyramidal composition","Rule of thirds","Radial balance","Foreshortening"],
     ["Which painting is a famous example of foreshortening?","Mantegna's Lamentation over the Dead Christ","The Mona Lisa","The Birth of Venus","Las Meninas"],
     ["Which 19th-century painter popularized dramatic cropping?","Edgar Degas","Jacques-Louis David","J. M. W. Turner","Gustave Courbet"]]},

{ t:"Color Theory", s:"How colors work together",
  sec:[
  ["Light and pigment",[
    "Color is how our eyes and brains perceive different wavelengths of light. In 1666 Isaac Newton showed with a prism that white sunlight contains the spectrum of colors, and he arranged them in a circle, the first color wheel.",
    "There are two systems of color mixing. Additive mixing, with light, as on screens, uses red, green, and blue (RGB) primaries; combining all three produces white. Subtractive mixing, with paints and inks, absorbs some wavelengths and reflects others; combining pigments makes darker colors. Printers use cyan, magenta, yellow, and black (CMYK)."]],
  ["The color wheel",[
    "The traditional artist's color wheel has three primary colors, red, yellow, and blue, which cannot be mixed from other colors. Mixing two primaries makes secondary colors: orange, green, and violet. Mixing a primary with an adjacent secondary makes tertiary colors such as red-orange or blue-green.",
    "Color harmonies are combinations that work well together. Complementary colors lie opposite each other on the wheel, red and green, blue and orange, yellow and violet; placed side by side they intensify each other, and mixed together they neutralize into grays and browns. Analogous colors are neighbors on the wheel, such as yellow, yellow-green, and green, creating harmony. Triadic schemes use three colors equally spaced around the wheel."]],
  ["Simultaneous contrast",[
    "Colors change appearance depending on their surroundings. In 1839 the French chemist Michel Eugène Chevreul, working at the Gobelins tapestry factory, published his law of simultaneous contrast: a color looks different depending on the colors next to it. A gray square looks warmer on a blue background and cooler on an orange one.",
    "Chevreul's ideas strongly influenced Delacroix, the Impressionists, and especially the Neo-Impressionists Georges Seurat and Paul Signac, who placed small dots of pure color side by side, a technique called pointillism, so that they would mix optically in the viewer's eye. Josef Albers explored these effects in his Interaction of Color (1963) and series Homage to the Square."]],
  ["Pigments through history",[
    "For most of history, artists depended on natural pigments. Earth pigments, ochres, siennas, and umbers, are among the oldest, used in cave paintings. Ultramarine blue, made from the semi-precious stone lapis lazuli mined in Afghanistan, was more expensive than gold in Renaissance Europe and often reserved for the Virgin Mary's robes. Tyrian purple, made from sea snails, was reserved for emperors.",
    "Some pigments were dangerous: lead white and vermilion (mercury sulfide) are toxic, and Scheele's green contained arsenic. The 18th and 19th centuries brought synthetic pigments, Prussian blue (1704), cobalt blue, synthetic ultramarine (1826), and chrome yellow, which, together with paint in collapsible metal tubes (invented in 1841), helped make Impressionist painting outdoors possible."]],
  ["Color and meaning",[
    "Colors carry symbolic meanings that vary across cultures and periods. In medieval Christian art, blue often signified heaven and the Virgin Mary, red the blood of Christ and martyrdom, and gold divine light. In China, red signifies good fortune and celebration, and yellow was the imperial color.",
    "Artists have also used color expressively. Van Gogh wrote that he used color “arbitrarily” to express himself; the Fauves used intense, unnatural colors; Kandinsky associated colors with musical tones and spiritual states; and Mark Rothko's large fields of color aimed to provoke profound emotional responses."]],
  ["Local and expressive color",[
    "Local color is the actual color of an object under neutral light, such as the red of an apple. Optical color is how the object appears under particular light and atmosphere; the Impressionists, observing nature closely, noticed that shadows on snow are often blue or violet rather than gray.",
    "Expressive or arbitrary color departs from reality to convey emotion or ideas. Understanding these differences helps explain why the same subject, a landscape or a face, can look so different in the hands of a Renaissance master, an Impressionist, and an Expressionist."]]
  ],
  terms:[["Additive color","Color mixing with light (RGB)."],["Subtractive color","Color mixing with pigments (CMYK)."],["Primary colors","Colors that cannot be mixed from others."],["Complementary colors","Colors opposite each other on the color wheel."],["Simultaneous contrast","Colors changing appearance next to other colors."],["Pointillism","Painting with dots of pure color that blend optically."],["Ultramarine","A precious blue pigment made from lapis lazuli."]],
  w:"Color theory explains how artists create harmony, contrast, light, and emotion, and why pigments shaped the history of painting.",
  src:["Color theory","Color wheel","Complementary colors","Michel Eugène Chevreul","Pointillism","Ultramarine","Interaction of Color"],
  q:[["Who showed with a prism that white light contains all colors?","Isaac Newton","Johann Wolfgang von Goethe","Michel Eugène Chevreul","Josef Albers"],
     ["What are the primary colors for mixing light?","Red, green, and blue","Red, yellow, and blue","Cyan, magenta, and yellow","Red, orange, and yellow"],
     ["Which pair are complementary colors?","Blue and orange","Blue and green","Red and orange","Yellow and green"],
     ["Who formulated the law of simultaneous contrast?","Michel Eugène Chevreul","Georges Seurat","Isaac Newton","Eugène Delacroix"],
     ["From what stone was ultramarine made?","Lapis lazuli","Malachite","Turquoise","Azurite"],
     ["What 1841 invention helped painters work outdoors?","Paint in collapsible metal tubes","The easel","Acrylic paint","Synthetic brushes"]]},

{ t:"Painting and Drawing Media", s:"Fresco, tempera, oil, watercolor, and more",
  sec:[
  ["What paint is",[
    "All paint consists of pigment, the coloring material, suspended in a binder, which holds the pigment together and attaches it to a surface. The choice of binder determines a paint's properties, and each medium has shaped the look of art in its era. The surface painted on is called the support: walls, wooden panels, canvas, paper, silk, and more.",
    "Drawing media include charcoal, graphite (pencil), chalk, pastel, ink, and metalpoint, such as silverpoint, which leaves a fine gray line on prepared paper and was used by Leonardo and Dürer. Drawings have served as preparatory studies, as finished works, and as a way of thinking on paper."]],
  ["Fresco",[
    "Fresco (Italian for “fresh”) is painting on wet lime plaster, so that the pigment binds chemically into the wall as it dries, making the image extremely durable. In buon fresco, true fresco, the artist must paint quickly on a section of fresh plaster, a giornata (“day's work”), before it dries. Fresco secco is painting on dry plaster, which is less durable.",
    "Fresco was used in Minoan palaces, Roman villas such as those at Pompeii, and above all in Renaissance Italy: Giotto's Arena Chapel in Padua, Masaccio's Brancacci Chapel in Florence, and Michelangelo's Sistine Chapel ceiling (1508–1512) and Last Judgment. Leonardo's Last Supper, painted experimentally in tempera and oil on dry plaster, began deteriorating within his lifetime."]],
  ["Tempera and encaustic",[
    "Egg tempera uses egg yolk as a binder. It dries quickly to a matte, luminous finish but cannot be blended easily, so artists build up tones with fine hatched strokes. It was the main panel-painting medium of medieval and early Renaissance Europe, used by Duccio, Fra Angelico, and Botticelli, often on wooden panels covered with gesso and combined with gold leaf.",
    "Encaustic uses pigments mixed with hot wax. It produced the vivid Fayum mummy portraits of Roman Egypt (1st–3rd centuries CE) and was revived in the 20th century, notably by Jasper Johns in his Flag paintings."]],
  ["Oil paint",[
    "Oil paint uses drying oils, usually linseed oil, as a binder. It dries slowly, allowing artists to blend colors seamlessly, rework passages, and build up translucent layers called glazes, which give depth and glow. Oil painting was perfected in the Netherlands in the early 15th century; Jan van Eyck's works, such as the Ghent Altarpiece (completed 1432) and the Arnolfini Portrait (1434), showed its astonishing capacity for detail and light.",
    "Oil spread to Italy, where Venetian painters such as Giovanni Bellini and Titian embraced it, and Venetians began painting on canvas, which was lighter and cheaper than wood and suited Venice's damp climate. Oil on canvas became the dominant medium of Western painting for five centuries, used for effects from Rembrandt's thick impasto to the smooth surfaces of Ingres."]],
  ["Watercolor, gouache, and ink",[
    "Watercolor uses pigments in a water-soluble binder, usually gum arabic, applied in transparent washes on paper, with the white of the paper providing highlights. Albrecht Dürer made pioneering watercolor landscapes and nature studies around 1500, and the medium flourished in 18th- and 19th-century Britain with J. M. W. Turner and in America with Winslow Homer and John Singer Sargent. Gouache is an opaque form of watercolor.",
    "Ink painting with brush on paper or silk is central to East Asian art. Chinese and Japanese ink painters, using a few carefully controlled strokes, valued spontaneity and expressive brushwork; ink was closely tied to calligraphy, considered the highest art in China."]],
  ["Modern media",[
    "Acrylic paint, developed in the mid-20th century, uses a synthetic polymer emulsion as a binder. It dries quickly, is water-soluble when wet but permanent when dry, and can be used thin like watercolor or thick like oil. Painters such as David Hockney, Helen Frankenthaler, and Andy Warhol used it, and it became popular for its bright colors and versatility.",
    "Modern artists have also used spray paint, industrial enamel (Jackson Pollock dripped house paint), collage, mixed media, and digital painting. The medium always shapes the message: knowing how a work was made helps explain why it looks as it does."]]
  ],
  terms:[["Pigment and binder","Coloring material and the substance holding it together."],["Support","The surface on which a work is painted."],["Fresco","Painting on wet lime plaster."],["Egg tempera","Paint bound with egg yolk."],["Encaustic","Paint mixed with hot wax."],["Glaze","A thin translucent layer of oil paint."],["Gouache","Opaque watercolor."],["Acrylic","Fast-drying synthetic polymer paint."]],
  w:"Every painting medium has its own possibilities and limits, and understanding them explains why art from different periods and places looks the way it does.",
  src:["Paint","Fresco","Tempera","Encaustic painting","Oil painting","Watercolor painting","Acrylic paint"],
  q:[["What are the two components of all paint?","Pigment and binder","Oil and water","Canvas and gesso","Chalk and ink"],
     ["What is painting on wet lime plaster called?","Fresco","Tempera","Encaustic","Gouache"],
     ["What binder does egg tempera use?","Egg yolk","Linseed oil","Wax","Gum arabic"],
     ["Which artist's works showed the power of early oil painting?","Jan van Eyck","Giotto","Duccio","Fra Angelico"],
     ["Which Roman-era paintings used encaustic?","The Fayum mummy portraits","The Pompeii frescoes","The catacomb paintings","The Ravenna mosaics"],
     ["When did Michelangelo paint the Sistine Chapel ceiling?","1508–1512","1495–1498","1534–1541","1475–1480"]]}

]});


/* ---- from arts-02.js ---- */
/* ARTS FOUNDATIONS, part 2: Unit 1 chapters 6-9 */
COURSES.arts.units[0].ch.push(

{ t:"Printmaking", s:"Art in multiples",
  sec:[
  ["What a print is",[
    "A print is an image made by transferring ink from a prepared surface, called a matrix, such as a block of wood, a metal plate, or a stone, onto paper. Because the matrix can be inked again and again, printmaking produces multiple original impressions, making images affordable and spreading them widely. Prints are usually numbered in editions, such as 12/50, and signed by the artist.",
    "Printmaking techniques fall into four families: relief, intaglio, planographic (lithography), and stencil (screen printing)."]],
  ["Relief: woodcut and linocut",[
    "In relief printing, the artist cuts away the parts of a block that should stay white; ink is rolled onto the raised surface and pressed onto paper. Woodblock printing was developed in China, where the Diamond Sutra of 868 CE is the oldest surviving dated printed book. In Europe, woodcuts spread in the 15th century alongside the printing press, and Albrecht Dürer raised the medium to high art with series such as the Apocalypse (1498).",
    "Japanese ukiyo-e (“pictures of the floating world”) woodblock prints, made by teams of designers, carvers, and printers using multiple blocks for color, flourished from the 17th to 19th centuries. Katsushika Hokusai's The Great Wave off Kanagawa (about 1831) is one of the most recognized images in the world. Linocut, using linoleum, was adopted by Picasso and Matisse in the 20th century."]],
  ["Intaglio: engraving and etching",[
    "In intaglio (Italian for “incised”) printing, lines are cut or etched into a metal plate, usually copper. Ink is pushed into the grooves and wiped from the surface, and the plate is run through a press with damp paper under heavy pressure. In engraving, the artist cuts lines directly with a sharp tool called a burin, producing crisp, controlled lines; Dürer's Melencolia I and Knight, Death and the Devil (both 1513–1514) are masterpieces.",
    "In etching, the artist draws through an acid-resistant coating on the plate, and acid bites the exposed lines. Etching allows a freer, more sketch-like line; Rembrandt was its greatest master. Other intaglio techniques include drypoint, scratching directly to produce soft, velvety lines; aquatint, creating tonal areas, used brilliantly by Goya in his series Los Caprichos and The Disasters of War; and mezzotint."]],
  ["Lithography",[
    "Lithography, invented by Alois Senefelder in Bavaria in 1796, is based on the fact that oil and water repel each other. The artist draws on a flat stone or plate with a greasy crayon; the surface is wetted, and oily ink sticks only to the drawn areas. Because the artist draws directly, lithographs can look like drawings.",
    "Lithography allowed mass printing of illustrations, political cartoons, such as Honoré Daumier's satires, and posters. Henri de Toulouse-Lautrec's color lithograph posters for Paris cabarets such as the Moulin Rouge in the 1890s helped create modern graphic design."]],
  ["Screen printing",[
    "Screen printing (serigraphy) pushes ink through a fine mesh screen onto paper or fabric, with a stencil blocking areas that should not print. Developed commercially in the early 20th century, it produces flat, bright areas of color.",
    "In the 1960s Andy Warhol made screen printing central to Pop Art, using photographic stencils to repeat images of Marilyn Monroe, Campbell's Soup cans, and celebrities, deliberately imitating the look of mass production. Screen printing remains widely used for posters and T-shirts."]],
  ["Prints and the spread of images",[
    "Printmaking democratized art. Prints spread religious images, scientific illustrations, maps, and reproductions of famous paintings across Europe, so that artists in one country could study works in another. Prints also carried satire and political protest, from Hogarth's moral series such as A Rake's Progress to Goya's Disasters of War and Käthe Kollwitz's prints about poverty and war.",
    "Japanese prints, arriving in Europe in large numbers after Japan opened to trade in the 1850s, inspired a craze called Japonisme and profoundly influenced Monet, Degas, Van Gogh, Whistler, and Toulouse-Lautrec with their flat colors, bold outlines, and unusual viewpoints."]]
  ],
  terms:[["Matrix","The block, plate, or stone from which a print is made."],["Edition","A set of impressions from the same matrix."],["Relief printing","Printing from raised surfaces, such as woodcut."],["Intaglio","Printing from incised lines, such as engraving and etching."],["Etching","Intaglio printing using acid to bite lines into metal."],["Lithography","Printing from a flat surface based on oil and water repelling."],["Ukiyo-e","Japanese woodblock prints of the floating world."]],
  w:"Printmaking made art reproducible and portable, spreading images, ideas, and styles across the world long before photography.",
  src:["Printmaking","Woodcut","Ukiyo-e","Engraving","Etching","Lithography","Screen printing"],
  q:[["What is the oldest surviving dated printed book?","The Diamond Sutra","The Gutenberg Bible","The Book of Kells","The Lotus Sutra"],
     ["Who made The Great Wave off Kanagawa?","Katsushika Hokusai","Utagawa Hiroshige","Kitagawa Utamaro","Toshusai Sharaku"],
     ["Which artist was the greatest master of etching?","Rembrandt","Dürer","Goya","Hogarth"],
     ["Who invented lithography in 1796?","Alois Senefelder","Johannes Gutenberg","William Hogarth","Honoré Daumier"],
     ["Which artist made screen printing central to Pop Art?","Andy Warhol","Roy Lichtenstein","Jasper Johns","Robert Rauschenberg"],
     ["Which intaglio technique did Goya use to create tonal areas?","Aquatint","Mezzotint","Drypoint","Woodcut"]]},

{ t:"Sculpture", s:"Art in three dimensions",
  sec:[
  ["Sculpture in space",[
    "Sculpture is art that occupies three-dimensional space. Freestanding sculpture, or sculpture in the round, can be viewed from all sides, like Michelangelo's David. Relief sculpture projects from a flat background: low relief (bas-relief), as on coins and the Parthenon frieze, projects only slightly; high relief projects more deeply, with forms partly detached.",
    "Sculptors think about mass, volume, the way forms occupy space, surface, and how the work changes as the viewer moves around it and as light falls on it. Since the 20th century, sculpture has expanded to include installations, environments, and works of light and motion."]],
  ["Subtractive methods: carving",[
    "Carving is a subtractive process: the sculptor removes material from a block of stone, wood, ivory, or bone. Stone carving requires careful planning, as mistakes cannot easily be fixed. Marble, especially white marble from Carrara in Italy and Paros and Mount Pentelicus in Greece, was prized by Western sculptors for its fine grain and translucence.",
    "Michelangelo described sculpture as freeing the figure imprisoned in the stone, and his unfinished Prisoners (or Slaves) show figures seemingly struggling out of the block. Wood carving has been central in many traditions, from African masks and figures to medieval altarpieces and Japanese Buddhist sculpture."]],
  ["Additive methods: modeling",[
    "Modeling is an additive process: the artist builds up a form from soft, pliable materials such as clay, wax, or plaster. Clay can be fired in a kiln to make terracotta, a hard ceramic, as in China's Terracotta Army of about 8,000 figures made for the tomb of the first emperor, Qin Shi Huang, in the 3rd century BCE.",
    "Modeled clay or wax figures are often used as models for works in other materials, especially bronze."]],
  ["Casting",[
    "Casting is a replacement process in which liquid material, usually molten metal, is poured into a mold. The lost-wax method (cire perdue), used since ancient times, involves making a wax model, encasing it in a heat-resistant mold, melting the wax out, and pouring bronze into the space. Bronze, an alloy of copper and tin, is strong, allowing outstretched limbs that would break in stone.",
    "Great bronze traditions include Shang dynasty China's ritual vessels, ancient Greek statues such as the Riace bronzes and the Charioteer of Delphi, the Benin Bronzes of West Africa, Chola dynasty bronzes of Hindu deities in southern India, such as Shiva as Nataraja, Lord of the Dance, and Renaissance works such as Donatello's David and Ghiberti's Gates of Paradise. Because bronze could be melted down for weapons or coins, many ancient bronzes have been lost."]],
  ["Assemblage and construction",[
    "In the 20th century, artists began assembling sculptures from found objects and industrial materials. Picasso's constructions of sheet metal and wire and his Bull's Head (1942), made from a bicycle seat and handlebars, are early examples. Assemblage became important with artists such as Louise Nevelson, who built wall-sized constructions of painted wooden scraps.",
    "Constructivists used industrial materials such as steel, glass, and plastic; David Smith welded steel; Alexander Calder invented the mobile, a kinetic sculpture that moves with air currents. Minimalists such as Donald Judd used factory-made boxes, and contemporary artists use everything from light and sound to living plants."]],
  ["Monuments and public sculpture",[
    "Sculpture has long served public purposes: commemorating rulers, gods, and heroes, marking sacred places, and expressing civic identity. Examples range from the Great Sphinx of Giza and Trajan's Column to equestrian statues of rulers, Auguste Bartholdi's Statue of Liberty (1886), and Mount Rushmore.",
    "Modern public sculpture includes abstract works in city plazas, such as Anish Kapoor's Cloud Gate (“the Bean”) in Chicago, and memorials such as Maya Lin's Vietnam Veterans Memorial (1982) in Washington, a polished black granite wall inscribed with names. Public monuments are often debated and sometimes removed as societies reassess the figures and values they honor."]]
  ],
  terms:[["Sculpture in the round","Freestanding sculpture viewable from all sides."],["Relief","Sculpture projecting from a background."],["Carving","Removing material to create a form."],["Modeling","Building up form with soft material."],["Lost-wax casting","Casting metal using a melted-out wax model."],["Terracotta","Fired clay."],["Assemblage","Sculpture made from found objects."],["Mobile","A kinetic sculpture that moves with air currents."]],
  w:"Understanding how sculpture is carved, modeled, cast, and assembled helps you appreciate works from ancient bronzes to modern installations.",
  src:["Sculpture","Relief","Carrara marble","Terracotta Army","Lost-wax casting","Assemblage (art)","Alexander Calder"],
  q:[["Which is a subtractive sculptural process?","Carving","Modeling","Casting","Assemblage"],
     ["For whom was the Terracotta Army made?","Qin Shi Huang","Kublai Khan","Emperor Wu of Han","Tang Taizong"],
     ["What is bronze an alloy of?","Copper and tin","Copper and zinc","Iron and carbon","Tin and lead"],
     ["What does cire perdue mean?","Lost wax","Cast bronze","Carved stone","Fired clay"],
     ["Who invented the mobile?","Alexander Calder","David Smith","Louise Nevelson","Constantin Brâncuși"],
     ["Who designed the Vietnam Veterans Memorial?","Maya Lin","Anish Kapoor","Richard Serra","Frank Gehry"]]},

{ t:"Subjects and Genres", s:"History, portrait, landscape, still life, and everyday life",
  sec:[
  ["The hierarchy of genres",[
    "In Western art, paintings have traditionally been classified by subject into genres. In 1667 André Félibien, historian of the French Royal Academy of Painting and Sculpture, ranked them in a hierarchy: history painting at the top, followed by portraiture, genre scenes of everyday life, landscape, and still life at the bottom.",
    "The ranking reflected the belief that depicting noble human actions required the most imagination and learning, while depicting objects merely copied nature. The hierarchy shaped training, prices, and prestige for two centuries, until 19th-century Realists and Impressionists overturned it."]],
  ["History painting",[
    "History painting depicts significant narrative subjects from the Bible, classical mythology, ancient history, literature, and allegory, usually on a large scale with idealized figures. Examples include Raphael's School of Athens, Poussin's mythological scenes, and Jacques-Louis David's Oath of the Horatii (1784).",
    "In the late 18th and 19th centuries, artists began painting contemporary events as history, such as Benjamin West's The Death of General Wolfe (1770), Goya's The Third of May 1808, Géricault's The Raft of the Medusa (1818–1819), and Delacroix's Liberty Leading the People (1830)."]],
  ["Portraiture",[
    "Portraits depict particular individuals, recording likeness, status, character, and memory. Roman portrait busts were famously realistic. Renaissance portraits, such as the Mona Lisa, began showing sitters in three-quarter view with psychological depth. Court painters such as Hans Holbein, Anthony van Dyck, and Diego Velázquez portrayed royalty with symbols of power.",
    "Self-portraits became an important genre from the Renaissance onward; Rembrandt made about 80 over his life, charting his aging with unflinching honesty, and Frida Kahlo made self-portraits central to her art. Portraits often include attributes, objects that reveal the sitter's profession, status, or virtues."]],
  ["Genre painting",[
    "Genre painting depicts scenes of everyday life: peasants, markets, taverns, households, and festivals. Pieter Bruegel the Elder's peasant scenes and the Dutch painters of the 17th century, such as Johannes Vermeer, Pieter de Hooch, and Jan Steen, made it a major art; Vermeer's The Milkmaid elevates a simple domestic task to quiet grandeur.",
    "Genre scenes often carry moral messages: a messy household in a Jan Steen painting warned against disorder, giving rise to the Dutch expression “a Jan Steen household.” In the 19th century, Realists such as Courbet and Millet painted rural workers on the scale once reserved for history painting."]],
  ["Landscape",[
    "Landscape painting depicts natural scenery. In China, landscape (shanshui, “mountain-water”) painting was regarded as the highest form of painting from about the 10th century. In Europe, landscape was usually a background until the 16th and 17th centuries, when artists such as Albrecht Altdorfer, Claude Lorrain, Nicolas Poussin, and Dutch painters such as Jacob van Ruisdael made it an independent subject.",
    "Romantic painters such as J. M. W. Turner, John Constable, and Caspar David Friedrich made landscape a vehicle for emotion and the sublime, and the American Hudson River School celebrated wilderness. The Impressionists painted landscapes outdoors (en plein air) to capture light and atmosphere."]],
  ["Still life",[
    "Still life depicts inanimate objects: fruit, flowers, food, vessels, books, and skulls. Still lifes appeared in Roman wall paintings and mosaics and flourished in the Netherlands in the 17th century, displaying the painter's skill at rendering textures and the wealth of a trading society.",
    "Vanitas still lifes include symbols of mortality, such as skulls, extinguished candles, wilting flowers, and hourglasses, reminding viewers of the brevity of life and vanity of earthly goods. In the modern era, Cézanne used still life to explore form and structure, the Cubists to fracture space, and Warhol to reflect consumer culture."]]
  ],
  terms:[["Hierarchy of genres","The academic ranking of painting subjects."],["History painting","Large narrative paintings of noble subjects."],["Portraiture","Depictions of specific individuals."],["Attribute","An object identifying a person or figure."],["Genre painting","Scenes of everyday life."],["Plein air","Painting outdoors."],["Vanitas","A still life symbolizing mortality."]],
  w:"Knowing the traditional genres and their meanings helps you recognize what a painting is about and why artists made the choices they did.",
  src:["Hierarchy of genres","History painting","Portrait painting","Genre painting","Landscape painting","Still life","Vanitas"],
  q:[["Which genre ranked highest in the academic hierarchy?","History painting","Portraiture","Landscape","Still life"],
     ["Who painted The Oath of the Horatii?","Jacques-Louis David","Nicolas Poussin","Eugène Delacroix","Théodore Géricault"],
     ["About how many self-portraits did Rembrandt make?","About 80","About 10","About 200","About 25"],
     ["Who painted The Milkmaid?","Johannes Vermeer","Jan Steen","Pieter de Hooch","Frans Hals"],
     ["What does shanshui, the Chinese term for landscape painting, mean?","Mountain-water","Sky-earth","Wind-cloud","Tree-stone"],
     ["What does a vanitas still life symbolize?","Mortality and the vanity of earthly goods","Wealth and success","Religious devotion to saints","The changing seasons"]]},

{ t:"Patrons, Museums, and the Art World", s:"Who pays for art, who shows it, and who decides",
  sec:[
  ["Patronage",[
    "For most of history, art was made on commission for patrons: rulers, religious institutions, aristocrats, guilds, and wealthy merchants. Patrons often specified the subject, materials, size, and even how much expensive pigment should be used. In ancient Egypt, pharaohs and priests commissioned art; in medieval Europe, the Church was the main patron.",
    "In Renaissance Florence, the Medici banking family sponsored artists such as Donatello, Botticelli, and Michelangelo, and popes such as Julius II commissioned Michelangelo and Raphael. Patronage shaped what art was made and how it looked, and artists often negotiated for creative freedom."]],
  ["Academies and the market",[
    "From the 16th century, art academies trained artists and set standards. The French Royal Academy of Painting and Sculpture, founded in 1648, controlled official taste, and its annual exhibition, the Paris Salon, could make or break careers. Academies emphasized drawing from classical sculpture and the live model and ranked genres in a hierarchy.",
    "In the 17th-century Dutch Republic, a market for art emerged in which artists painted for anonymous buyers rather than specific patrons, specializing in landscapes, still lifes, and genre scenes. In the 19th century, art dealers, such as Paul Durand-Ruel, who championed the Impressionists, critics, and independent exhibitions replaced the Salon's monopoly, creating the modern art market."]],
  ["The rise of museums",[
    "Collecting art goes back to ancient times, and Renaissance princes created “cabinets of curiosities.” Public museums emerged in the Enlightenment. The British Museum opened in 1759, and the Louvre in Paris opened as a public museum in 1793 during the French Revolution, turning a royal collection into national property; Napoleon later filled it with art seized across Europe.",
    "Great museums followed in the 19th century, including the Prado in Madrid (1819), the National Gallery in London (1824), and the Metropolitan Museum of Art in New York (1870). The Museum of Modern Art (MoMA) in New York, founded in 1929, shaped the story of modern art. Today the Louvre is the most visited museum in the world, with around 9 million visitors a year."]],
  ["Questions of ownership",[
    "Many museum collections include objects acquired through colonial conquest, looting, or unequal relationships. The Benin Bronzes, looted by British forces from the Kingdom of Benin in 1897, have become a focus of debate, and some museums have begun returning them to Nigeria. Greece has long requested the return of the Parthenon Marbles, removed by Lord Elgin in the early 1800s and held by the British Museum.",
    "Art looted by the Nazis from Jewish collectors during the 1930s and 1940s has been the subject of restitution efforts, guided by the Washington Principles of 1998. Provenance research, tracing the ownership history of a work, has become central to museum ethics."]],
  ["The contemporary art world",[
    "Today's art world includes artists, commercial galleries, auction houses such as Christie's and Sotheby's, collectors, museums, critics, curators, and international exhibitions such as the Venice Biennale, first held in 1895, and Documenta in Germany. Art fairs such as Art Basel have become major marketplaces.",
    "Prices for top works can be extraordinary: Leonardo's Salvator Mundi sold for about 450 million dollars in 2017, the highest price ever paid at auction. Critics debate how markets, wealth, and fashion influence which artists are celebrated."]],
  ["Authenticity and conservation",[
    "Attribution, deciding who made a work, relies on connoisseurship, the trained eye of experts, along with documents and scientific analysis such as X-rays, infrared reflectography, and pigment analysis, which can reveal underdrawings and changes. Famous forgers, such as Han van Meegeren, who sold fake Vermeers to the Nazi leader Hermann Göring, have fooled experts.",
    "Conservators preserve and restore artworks, cleaning grime and old varnish and stabilizing damage. Restorations can be controversial; the cleaning of the Sistine Chapel frescoes (1980–1994) revealed unexpectedly bright colors, sparking debate. The aim of modern conservation is to be reversible and respectful of the artist's original intentions."]]
  ],
  terms:[["Patron","A person or institution that commissions or supports art."],["Academy","An institution that trained artists and set official standards."],["Salon","The official exhibition of the French Academy."],["Provenance","The ownership history of a work."],["Restitution","The return of looted or wrongly taken art."],["Connoisseurship","Expert judgment of attribution and quality."],["Conservation","The preservation and restoration of artworks."]],
  w:"Understanding patrons, academies, markets, and museums reveals the forces behind what art is made, who sees it, and how its value and meaning are decided.",
  src:["Patronage in art","French Academy of Fine Arts","Paris Salon","Louvre","Benin Bronzes","Provenance","Art conservation and restoration"],
  q:[["Which family were famous patrons in Renaissance Florence?","The Medici","The Borgia","The Sforza","The Este"],
     ["What was the official exhibition of the French Academy called?","The Salon","The Biennale","Documenta","The Academy Show"],
     ["When did the Louvre open as a public museum?","1793","1759","1824","1870"],
     ["Which artworks were looted by British forces in 1897?","The Benin Bronzes","The Parthenon Marbles","The Elgin Marbles","The Rosetta Stone"],
     ["Which work set the auction record in 2017?","Salvator Mundi","The Card Players","Interchange","Les Femmes d'Alger"],
     ["Who sold fake Vermeers to Hermann Göring?","Han van Meegeren","Elmyr de Hory","Tom Keating","Wolfgang Beltracchi"]]}

);


/* ---- from arts-03.js ---- */
/* ARTS FOUNDATIONS, part 3: Unit 2 Ancient Art, chapters 1-4 */
COURSES.arts.units.push({ t:"Art of the Ancient World", ch:[

{ t:"Prehistoric Art", s:"The first images",
  sec:[
  ["The oldest art",[
    "Art is older than writing, farming, or cities. Engraved patterns on ochre found at Blombos Cave in South Africa date to about 75,000–100,000 years ago, and shell beads are even older. The oldest known figurative paintings, of animals and human-like figures, were found in caves on Sulawesi, Indonesia, and date to at least 45,000 to 51,000 years ago. Hand stencils, made by blowing pigment around a hand pressed to the rock wall, appear on cave walls across the world.",
    "Most surviving Paleolithic (Old Stone Age) art comes from the last ice age, roughly 40,000 to 12,000 years ago, especially in Europe, where it is concentrated in caves of southern France and northern Spain."]],
  ["The painted caves",[
    "Chauvet Cave in southern France, discovered in 1994, contains paintings of horses, lions, rhinoceroses, and mammoths about 30,000–36,000 years old, showing sophisticated shading and a sense of movement. Lascaux in France, discovered by teenagers in 1940, contains about 600 paintings and 1,500 engravings made about 17,000 years ago, including the famous Hall of the Bulls. Altamira in Spain, discovered in the 1870s, has a ceiling of polychrome bison; experts at first refused to believe such art could be prehistoric.",
    "Artists used mineral pigments, red and yellow ochre, charcoal, and manganese, applied with fingers, brushes, and spraying through tubes, and they used the natural bulges of the rock to give animals volume. The paintings were made deep in dark caves, lit by stone lamps burning animal fat."]],
  ["Why were they made?",[
    "The purpose of cave art remains debated. Early theories suggested hunting magic, to ensure success in the hunt, though the animals depicted are often not those most commonly eaten. Others propose shamanistic rituals, in which images were linked to trance and the spirit world, or that the caves were sacred spaces for initiation and storytelling.",
    "Abstract signs, dots, lines, and grids, appear alongside animals and may have carried meanings now lost. Humans are rarely depicted, and usually schematically."]],
  ["Portable art and figurines",[
    "Paleolithic people also carved small portable objects. The Lion Man of Hohlenstein-Stadel in Germany, a mammoth-ivory figure with a lion's head and human body about 35,000–41,000 years old, is among the oldest known figurative sculptures and suggests imagination beyond the visible world.",
    "Female figurines, often called “Venus” figures, such as the Venus of Willendorf (about 25,000–30,000 years old) from Austria, have exaggerated breasts, bellies, and hips and usually lack facial features. Their meaning is uncertain: they may relate to fertility, abundance, or female identity. The oldest, the Venus of Hohle Fels, is about 35,000–40,000 years old."]],
  ["Neolithic art and megaliths",[
    "With the Neolithic (New Stone Age) and the spread of farming, art changed. People made painted pottery, figurines, and decorated houses. At Çatalhöyük in Turkey, one of the earliest towns (about 7100–5700 BCE), walls were painted with hunting scenes and decorated with bull horns. Göbekli Tepe in Turkey, with massive carved stone pillars from about 9500 BCE, is older than farming in the region and may be the oldest known monumental religious site.",
    "Across Europe, Neolithic people built megaliths, monuments of huge stones. Stonehenge in England, built in stages from about 3000 to 1500 BCE, aligns with the sunrise at the summer solstice and the sunset at the winter solstice. Newgrange in Ireland, a passage tomb from about 3200 BCE, is lit by the rising sun at the winter solstice. The thousands of standing stones at Carnac in France are another example."]],
  ["Rock art around the world",[
    "Rock art is found on every inhabited continent. Australian Aboriginal rock art, in places such as Kakadu and the Kimberley, is among the longest continuous artistic traditions on Earth, spanning tens of thousands of years. The San people of southern Africa painted vivid scenes of animals, hunting, and trance dances.",
    "In the Sahara, thousands of paintings and engravings at sites such as Tassili n'Ajjer in Algeria record a time when the desert was green, showing giraffes, cattle, and people. These images are invaluable records of ancient environments and ways of life."]]
  ],
  terms:[["Paleolithic","The Old Stone Age, before farming."],["Hand stencil","An image made by blowing pigment around a hand."],["Lascaux","A French cave with paintings about 17,000 years old."],["Venus figurine","A small prehistoric female figure."],["Lion Man","An ivory figure, one of the oldest figurative sculptures."],["Megalith","A monument of large stones."],["Stonehenge","A Neolithic stone circle aligned with the solstices."]],
  w:"Prehistoric art reveals that imagination, symbolism, and the urge to make images are as old as our species.",
  src:["Prehistoric art","Cave painting","Lascaux","Chauvet Cave","Venus of Willendorf","Löwenmensch figurine","Stonehenge"],
  q:[["Which French cave was discovered by teenagers in 1940?","Lascaux","Chauvet","Altamira","Niaux"],
     ["Where are some of the oldest known figurative cave paintings?","Sulawesi, Indonesia","Lascaux, France","Altamira, Spain","Blombos, South Africa"],
     ["Which Spanish cave has a ceiling of painted bison?","Altamira","Lascaux","Chauvet","El Castillo"],
     ["What is the Lion Man made of?","Mammoth ivory","Limestone","Clay","Bone"],
     ["Which site with carved pillars dates to about 9500 BCE?","Göbekli Tepe","Çatalhöyük","Stonehenge","Newgrange"],
     ["Stonehenge is aligned with what?","The solstices","The equinoxes","The North Star","The Moon's phases"]]},

{ t:"Mesopotamia and Persia", s:"Art of the first cities and empires",
  sec:[
  ["Sumer",[
    "Mesopotamia, “the land between the rivers” Tigris and Euphrates, saw the rise of the first cities, such as Uruk, around 3500 BCE. The Sumerians built temples on massive stepped platforms called ziggurats; the Ziggurat of Ur, built around 2100 BCE, was partly reconstructed in modern times. The Warka Vase from Uruk, around 3200 BCE, shows offerings to the goddess Inanna in registers, horizontal bands, an organizing device used throughout Mesopotamian art.",
    "Sumerian votive statues from Tell Asmar, with huge staring eyes and clasped hands, were placed in temples to pray perpetually on behalf of worshippers. The Royal Cemetery of Ur, excavated by Leonard Woolley in the 1920s, yielded spectacular objects of gold, lapis lazuli, and shell, including the Standard of Ur, with scenes of war and peace, and a lyre decorated with a bull's head."]],
  ["Akkad and Babylon",[
    "Sargon of Akkad created the first empire around 2300 BCE. Akkadian art emphasized the ruler: the bronze head possibly of Sargon or his grandson Naram-Sin, and the Victory Stele of Naram-Sin, which breaks with registers to show the king, wearing a horned helmet of divinity, climbing a mountain above his defeated enemies, use hierarchical scale to glorify kingship.",
    "The Babylonian king Hammurabi (reigned about 1792–1750 BCE) had his law code carved on a basalt stele topped by a relief of the king receiving authority from the sun god Shamash, a powerful image of law's divine origin; it is now in the Louvre. Mesopotamian cylinder seals, small carved stones rolled across clay to leave impressions, show remarkable miniature artistry."]],
  ["Assyria",[
    "The Assyrian Empire, at its height in the 9th to 7th centuries BCE, decorated its palaces at Nimrud and Nineveh with long stone reliefs showing the king's military campaigns, the punishment of enemies, and royal lion hunts. The lion hunt reliefs of Ashurbanipal (7th century BCE), now in the British Museum, are famous for their dramatic depictions of wounded and dying lions.",
    "Palace gateways were guarded by lamassu, colossal winged bulls or lions with human heads. Carved with five legs, they appear to stand still when seen from the front and to stride forward when seen from the side. Such art was designed to project the overwhelming power of the Assyrian king."]],
  ["Neo-Babylon",[
    "After Assyria's fall, the Neo-Babylonian Empire under Nebuchadnezzar II (reigned 605–562 BCE) rebuilt Babylon as one of the ancient world's greatest cities. The Ishtar Gate, faced with glazed blue bricks decorated with dragons, bulls, and lions in relief, led to the Processional Way; it has been reconstructed in Berlin's Pergamon Museum.",
    "Babylon was also said to have the Hanging Gardens, one of the Seven Wonders of the Ancient World, though no archaeological evidence has confirmed them, and the great ziggurat Etemenanki, which may have inspired the biblical story of the Tower of Babel."]],
  ["Persia",[
    "The Achaemenid Persian Empire (550–330 BCE), founded by Cyrus the Great, was the largest empire the world had yet seen, stretching from Egypt and Anatolia to India. Its art blended traditions from across the empire, Mesopotamian, Egyptian, Greek, and others, into a unified imperial style.",
    "At Persepolis, the ceremonial capital begun by Darius I around 518 BCE, the Apadana, a great audience hall with 72 columns topped by capitals of animals, stood on a terrace whose staircases are carved with reliefs of delegations from 23 subject nations bringing tribute in orderly procession, an image of a harmonious, ordered empire. Alexander the Great burned Persepolis in 330 BCE. Persian goldsmiths produced superb objects such as the Oxus Treasure."]],
  ["Legacy",[
    "Mesopotamian art established enduring conventions: registers for narrative, hierarchical scale, composite views of the human figure, the use of art to glorify rulers and record their deeds, and monumental architecture on raised platforms.",
    "Later Persian empires, the Parthians and Sasanians, continued these traditions, and Sasanian art influenced Islamic and Byzantine art. Many Mesopotamian sites and museums suffered damage and looting during recent wars in Iraq and Syria, including the destruction of Nimrud by the Islamic State in 2015."]]
  ],
  terms:[["Ziggurat","A Mesopotamian stepped temple platform."],["Register","A horizontal band organizing images."],["Stele","An upright carved stone slab."],["Cylinder seal","A carved stone rolled on clay to leave an image."],["Lamassu","A winged guardian figure with a human head."],["Ishtar Gate","Babylon's glazed-brick gateway."],["Persepolis","The ceremonial capital of Achaemenid Persia."]],
  w:"Mesopotamian and Persian art created the first monumental images of kingship, law, and empire, establishing conventions that lasted for millennia.",
  src:["Art of Mesopotamia","Ziggurat of Ur","Standard of Ur","Code of Hammurabi","Lamassu","Ishtar Gate","Persepolis"],
  q:[["What is a stepped Mesopotamian temple platform called?","A ziggurat","A pyramid","A stupa","A mastaba"],
     ["What does the Victory Stele of Naram-Sin show?","The king climbing a mountain above defeated enemies","A lion hunt","A law code","An offering to Inanna"],
     ["Whose law code is carved on a basalt stele in the Louvre?","Hammurabi's","Sargon's","Ashurbanipal's","Nebuchadnezzar's"],
     ["What are the winged, human-headed guardians of Assyrian palaces called?","Lamassu","Sphinxes","Griffins","Cherubim"],
     ["Which gate was faced with glazed blue bricks?","The Ishtar Gate","The Lion Gate","The Gate of All Nations","The Golden Gate"],
     ["Who began Persepolis?","Darius I","Cyrus the Great","Xerxes I","Alexander the Great"]]},

{ t:"Ancient Egyptian Art", s:"Art for eternity",
  sec:[
  ["Art for the afterlife",[
    "Ancient Egyptian civilization lasted about 3,000 years, and its art remained remarkably consistent, because it served religious and political purposes that valued order, stability, and permanence. Much Egyptian art was made for tombs, to provide for the deceased in the afterlife and to house the ka, the life force, which needed an image or body to dwell in.",
    "Egyptian art was the work of anonymous workshops of trained craftsmen following strict conventions. The Palette of Narmer (about 3100 BCE), commemorating the unification of Upper and Lower Egypt, already shows the key features: registers, hierarchical scale, and the king smiting his enemies."]],
  ["The Egyptian canon",[
    "Egyptian artists depicted the human figure using a composite view, combining the most characteristic angles of each body part: the head in profile, the eye frontal, the shoulders frontal, and the hips, legs, and feet in profile. Figures were laid out on a grid to maintain consistent proportions, a canon that changed only slightly over millennia.",
    "Important figures, pharaohs and gods, appeared larger; men were typically painted with reddish-brown skin and women with lighter yellowish skin. Formal statues show the pharaoh in a rigid, frontal, idealized pose, as in the statue of Khafre enthroned (about 2500 BCE), carved in hard diorite to last forever, and the pair statue of Menkaure and his queen, striding forward with the left foot."]],
  ["Pyramids and tombs",[
    "Early kings were buried in mastabas, rectangular tombs. Around 2650 BCE the architect Imhotep designed the Step Pyramid of Djoser at Saqqara, the first monumental stone building. The pyramids of Giza, built for Khufu, Khafre, and Menkaure in the Fourth Dynasty (about 2600–2500 BCE), are the most famous; the Great Pyramid of Khufu, originally about 146 meters high, was the tallest human-made structure for nearly 4,000 years. The Great Sphinx, a lion with a pharaoh's head, guards Khafre's complex.",
    "In the New Kingdom (about 1550–1070 BCE), pharaohs were buried in rock-cut tombs in the Valley of the Kings near Thebes, decorated with painted scenes and texts guiding the soul through the underworld. Tomb walls in nobles' tombs show lively scenes of daily life, banquets, and hunting."]],
  ["Temples",[
    "Egyptian temples, such as those at Karnak and Luxor in Thebes, were conceived as houses of the gods. Visitors passed through massive gateways called pylons into open courtyards, then into hypostyle halls, forests of columns, and finally to the dark sanctuary holding the god's statue. The Great Hypostyle Hall at Karnak has 134 columns, some about 21 meters tall, carved like papyrus plants.",
    "Ramesses II (reigned 1279–1213 BCE) built colossal monuments, including the rock-cut temple at Abu Simbel with four seated statues of himself about 20 meters tall; in the 1960s the temple was cut into blocks and moved to higher ground to save it from Lake Nasser behind the Aswan High Dam."]],
  ["The Amarna revolution",[
    "Around 1350 BCE, the pharaoh Akhenaten broke with tradition, promoting the worship of a single sun god, the Aten, and moving the capital to a new city, Amarna. Art of the Amarna period became more naturalistic and intimate, showing the royal family in affectionate scenes and depicting Akhenaten with an elongated face, narrow shoulders, and a full belly.",
    "The painted limestone bust of his queen Nefertiti, found in 1912 in the workshop of the sculptor Thutmose and now in Berlin, is one of the most famous works of ancient art. After Akhenaten's death, the old religion and style were restored."]],
  ["Tutankhamun and later Egypt",[
    "Tutankhamun, probably Akhenaten's son, was a minor king who died young, but his tomb, discovered nearly intact by Howard Carter in 1922, revealed the splendor of royal burials: over 5,000 objects, including his solid gold innermost coffin and the gold funerary mask inlaid with lapis lazuli and glass.",
    "Egyptian art continued under foreign rulers, including the Greek Ptolemies, the last of whom was Cleopatra VII, and the Romans, absorbing new influences. Hieroglyphs, the sacred script that was itself an art form, could be read again after Jean-François Champollion deciphered them in 1822 using the Rosetta Stone."]]
  ],
  terms:[["Ka","The life force that needed an image to dwell in."],["Composite view","Combining frontal and profile views in one figure."],["Canon of proportions","A grid-based system for consistent figures."],["Mastaba","A rectangular Egyptian tomb."],["Pylon","A massive temple gateway."],["Hypostyle hall","A hall filled with columns."],["Amarna period","Akhenaten's era of new religion and naturalistic art."]],
  w:"Egyptian art shows how religion, kingship, and the quest for eternity produced one of the most enduring and recognizable artistic traditions in history.",
  src:["Art of ancient Egypt","Narmer Palette","Giza pyramid complex","Karnak","Amarna art","Nefertiti Bust","Tutankhamun"],
  q:[["What did the Egyptians believe needed an image to dwell in?","The ka","The ba","The akh","The heart"],
     ["Who designed the Step Pyramid of Djoser?","Imhotep","Khufu","Senenmut","Thutmose"],
     ["Which pharaoh built the Great Pyramid?","Khufu","Khafre","Menkaure","Djoser"],
     ["Which pharaoh built Abu Simbel?","Ramesses II","Tutankhamun","Akhenaten","Thutmose III"],
     ["Which pharaoh introduced worship of the Aten?","Akhenaten","Ramesses II","Hatshepsut","Amenhotep III"],
     ["Who discovered Tutankhamun's tomb?","Howard Carter","Jean-François Champollion","Flinders Petrie","Auguste Mariette"]]},

{ t:"The Aegean and Archaic Greece", s:"Minoans, Mycenaeans, and the beginnings of Greek art",
  sec:[
  ["Cycladic art",[
    "The Bronze Age cultures of the Aegean Sea produced some of Europe's earliest sophisticated art. On the Cycladic Islands, around 3000–2000 BCE, sculptors carved marble figurines, mostly female, with folded arms and highly simplified, geometric forms. Originally painted, they now appear starkly white, and their abstraction inspired 20th-century artists such as Brâncuși and Modigliani.",
    "Their function, perhaps funerary or religious, remains unknown."]],
  ["Minoan Crete",[
    "The Minoan civilization on Crete (about 2000–1450 BCE), named by the archaeologist Arthur Evans after the legendary King Minos, built sprawling palaces, most famously at Knossos, with light wells, colonnades, and colorful frescoes. Minoan art is lively and naturalistic, showing marine life, flowers, processions, and the famous Bull-Leaping Fresco, in which acrobats vault over a charging bull.",
    "On the island of Thera (Santorini), the town of Akrotiri was buried by a massive volcanic eruption around 1600 BCE, preserving frescoes of landscapes, ships, and boys carrying fish. Minoan artists also made the Snake Goddess figurines in faience and fine painted pottery decorated with octopuses."]],
  ["Mycenae",[
    "The Mycenaeans of mainland Greece (about 1600–1100 BCE), the warrior culture of Homer's heroes, built fortified citadels with walls of enormous stones, called Cyclopean masonry because later Greeks thought only giants could have lifted them. The Lion Gate at Mycenae (about 1250 BCE) is topped by a relief of two lions flanking a column.",
    "In shaft graves at Mycenae, Heinrich Schliemann found gold funerary masks in 1876, including one he believed was the mask of Agamemnon, though it predates the legendary king by centuries. Beehive-shaped tholos tombs, such as the Treasury of Atreus, show advanced corbelled construction."]],
  ["Geometric and Orientalizing",[
    "After the collapse of Mycenaean civilization around 1100 BCE, Greek art revived in the Geometric period (about 900–700 BCE), named for the bands of meanders, zigzags, and triangles on pottery. Huge vases used as grave markers, such as the Dipylon Amphora from Athens, show funeral processions with stick-like figures.",
    "In the Orientalizing period (7th century BCE), Greek artists adopted motifs from Egypt and the Near East, such as lions, sphinxes, griffins, and floral patterns, as trade expanded."]],
  ["Archaic sculpture",[
    "In the Archaic period (about 700–480 BCE), Greek sculptors began making large stone statues, influenced by Egypt. The kouros (youth), a standing nude male with one foot forward, arms at the sides, and the characteristic “Archaic smile,” served as grave markers and temple offerings; the kore (maiden) was clothed. The New York Kouros (about 590 BCE) and the Peplos Kore (about 530 BCE) are examples.",
    "Over the 6th century BCE, kouroi became steadily more naturalistic, with more accurate anatomy, showing Greek artists' growing interest in the human body. The Kritios Boy (about 480 BCE) shifts weight onto one leg, a crucial step toward the Classical style."]],
  ["Painted pottery",[
    "Greek vase painting is one of the richest sources for Greek art and life. In black-figure painting, developed in Corinth and perfected in Athens in the 6th century BCE, figures were painted in a slip that turned black in firing, with details incised. Exekias's amphora showing Achilles and Ajax playing a board game (about 530 BCE) is a masterpiece.",
    "Around 530 BCE Athenian potters invented red-figure painting, reversing the scheme: the background was painted black, leaving figures in the red of the clay, with details drawn with a brush, allowing more fluid and natural lines. Vases depicted myths, athletics, warfare, banquets, and daily life, and were exported across the Mediterranean, especially to Etruscan Italy."]]
  ],
  terms:[["Cycladic figurine","A simplified marble figure from the Cyclades."],["Minoan","The Bronze Age civilization of Crete."],["Knossos","The largest Minoan palace."],["Cyclopean masonry","Walls of huge, roughly shaped stones."],["Kouros and kore","Archaic Greek statues of a youth and a maiden."],["Archaic smile","The slight smile of Archaic Greek statues."],["Black-figure and red-figure","Two techniques of Greek vase painting."]],
  w:"Aegean and Archaic Greek art laid the foundations for the Classical tradition that shaped Western art for over two thousand years.",
  src:["Cycladic art","Minoan art","Knossos","Mask of Agamemnon","Kouros","Black-figure pottery","Red-figure pottery"],
  q:[["Which civilization built the palace at Knossos?","The Minoans","The Mycenaeans","The Cycladic culture","The Phoenicians"],
     ["Which Minoan fresco shows acrobats vaulting over a bull?","The Bull-Leaping Fresco","The Prince of the Lilies","The Fisherman","The Toreador of Thera"],
     ["Who found the so-called Mask of Agamemnon?","Heinrich Schliemann","Arthur Evans","Howard Carter","Carl Blegen"],
     ["What is a standing nude male statue of Archaic Greece called?","A kouros","A kore","A caryatid","A herm"],
     ["Who painted Achilles and Ajax playing a board game?","Exekias","Euphronios","Polygnotos","Douris"],
     ["In red-figure painting, which part is painted black?","The background","The figures","Only the outlines","Nothing"]]}

]});


/* ---- from arts-04.js ---- */
/* ARTS FOUNDATIONS, part 4: Unit 2 chapters 5-8 */
COURSES.arts.units[1].ch.push(

{ t:"Classical Greek Art", s:"The ideal human form, 480–323 BCE",
  sec:[
  ["The Classical moment",[
    "The Classical period of Greek art began after the Greeks defeated the Persian invasions in 480–479 BCE and lasted until the death of Alexander the Great in 323 BCE. Athens, under the leadership of Pericles, became a center of democracy, philosophy, drama, and art. Classical art pursued an ideal of harmony, balance, proportion, and naturalism, representing the human body with unprecedented accuracy yet idealized beyond any individual.",
    "This art has had enormous influence: Roman, Renaissance, Neoclassical, and academic art all looked back to it as the standard of beauty."]],
  ["Contrapposto and the canon",[
    "Classical sculptors introduced contrapposto (Italian for “counterpose”), a stance in which the figure's weight rests on one leg, so that hips and shoulders tilt in opposite directions, creating a natural, relaxed sense of life and potential movement. The Kritios Boy was an early example.",
    "The sculptor Polykleitos wrote a treatise, the Canon, defining ideal proportions based on mathematical ratios, and demonstrated it in his Doryphoros (Spear Bearer, about 450–440 BCE), known from Roman marble copies. Myron's Discobolus (Discus Thrower) captured a moment of athletic action. Many famous Greek bronzes survive only as Roman marble copies; rare originals include the Riace Warriors, recovered from the sea in 1972."]],
  ["The Parthenon",[
    "The Parthenon, the temple of Athena Parthenos on the Athenian Acropolis, was built in 447–432 BCE under Pericles by the architects Iktinos and Kallikrates, with sculpture supervised by Phidias. It is the supreme example of the Doric order, with subtle refinements: columns swell slightly (entasis) and lean inward, and the floor curves upward, correcting optical illusions and giving the building life.",
    "Its sculptures included pediment groups showing the birth of Athena and her contest with Poseidon, metopes depicting mythical battles, and a continuous frieze, about 160 meters long, probably showing the Panathenaic procession in honor of Athena. Inside stood Phidias's colossal gold and ivory statue of Athena, now lost. Much of the surviving sculpture, the Parthenon (Elgin) Marbles, is in the British Museum, and Greece seeks its return."]],
  ["The orders of architecture",[
    "Greek temples followed systems called orders. The Doric order, sturdy and plain, has columns without bases and simple cushion-like capitals. The Ionic order, from eastern Greece, is more slender, with bases and scroll-shaped capitals called volutes; the Erechtheion on the Acropolis, with its Porch of the Maidens, whose columns are carved as women called caryatids, is Ionic.",
    "The Corinthian order, developed later, has capitals decorated with acanthus leaves; it became the favorite order of the Romans. These orders have shaped Western architecture ever since, from Roman temples to banks and government buildings."]],
  ["Late Classical sculpture",[
    "In the 4th century BCE, sculptors made figures more graceful, sensuous, and human. Praxiteles carved the Aphrodite of Knidos (about 350 BCE), the first monumental female nude in Greek art, which became famous throughout the ancient world. His Hermes and the Infant Dionysus shows a relaxed S-curve pose.",
    "Lysippos, court sculptor to Alexander the Great, introduced a new canon with smaller heads and slimmer bodies, making figures seem taller, and his Apoxyomenos (Scraper) extends an arm into the viewer's space, inviting viewing from many angles. Skopas brought intense emotion to faces."]],
  ["Painting and the minor arts",[
    "Ancient writers praised Greek painters such as Polygnotos, Zeuxis, and Apelles, whose works were famous for realism; Zeuxis was said to have painted grapes so lifelike that birds tried to eat them. Almost none of their panel and wall paintings survive, so we know Greek painting mainly through vases, Roman copies, and a few tomb paintings in Macedonia.",
    "Red-figure vase painting reached its height in the 5th century BCE, and white-ground lekythoi, oil jugs for funerals, show delicate drawings on a white background. Greek statues and buildings were originally brightly painted; modern research has revealed traces of color on many marbles, overturning the long-held image of pure white classical art."]]
  ],
  terms:[["Contrapposto","A pose with weight on one leg, creating natural balance."],["Canon of Polykleitos","A system of ideal proportions."],["Parthenon","The temple of Athena on the Athenian Acropolis."],["Entasis","The slight swelling of a column."],["Doric, Ionic, Corinthian","The three Greek architectural orders."],["Caryatid","A column carved as a female figure."],["Polychromy","The original painted colors of ancient sculpture and architecture."]],
  w:"Classical Greek art created the ideal of harmonious proportion and naturalism that became the foundation of the Western artistic tradition.",
  src:["Ancient Greek art","Contrapposto","Doryphoros","Parthenon","Elgin Marbles","Classical order","Aphrodite of Knidos"],
  q:[["What is the relaxed pose with weight on one leg called?","Contrapposto","Chiaroscuro","Entasis","Sfumato"],
     ["Who wrote the Canon and sculpted the Doryphoros?","Polykleitos","Phidias","Praxiteles","Myron"],
     ["Who supervised the Parthenon's sculpture?","Phidias","Iktinos","Lysippos","Skopas"],
     ["Which order has scroll-shaped capitals?","Ionic","Doric","Corinthian","Tuscan"],
     ["Who carved the Aphrodite of Knidos?","Praxiteles","Lysippos","Polykleitos","Phidias"],
     ["What did modern research reveal about Greek statues?","They were originally brightly painted","They were made of plaster","They were all bronze","They were made in Rome"]]},

{ t:"Hellenistic Art", s:"Drama, emotion, and realism, 323–31 BCE",
  sec:[
  ["A wider world",[
    "After Alexander the Great's conquests, Greek culture spread across a vast area from Egypt to Afghanistan. The Hellenistic period, from Alexander's death in 323 BCE to the Roman conquest of Ptolemaic Egypt in 31 BCE, saw new cities such as Alexandria, Antioch, and Pergamon become centers of art, learning, and patronage by wealthy kings.",
    "Hellenistic art moved away from the calm idealism of the Classical period toward drama, emotion, movement, theatricality, and realism, depicting a wider range of subjects: the old, the young, the suffering, the foreign, and the everyday."]],
  ["Drama in stone",[
    "The Great Altar of Pergamon (about 180–160 BCE), now reconstructed in Berlin, has a frieze over 100 meters long showing the battle of the gods and giants, with figures twisting, straining, and bursting out of the background in high relief. The Dying Gaul, known from a Roman copy, portrays a defeated Celtic warrior with dignity and pathos.",
    "Laocoön and His Sons, showing a Trojan priest and his sons attacked by sea serpents, is a supreme example of anguished emotion and writhing movement. When it was unearthed in Rome in 1506, Michelangelo was among the first to see it, and it profoundly influenced him."]],
  ["Masterpieces",[
    "The Winged Victory of Samothrace (about 190 BCE), now at the top of a staircase in the Louvre, shows the goddess Nike alighting on the prow of a ship, her garments whipped by the wind. The Venus de Milo (about 150–125 BCE), found on the island of Melos in 1820, is one of the most famous sculptures in the world.",
    "The Boxer at Rest, a bronze of an exhausted fighter with a broken nose and cauliflower ears, and the Old Market Woman show a new interest in realism and in ordinary, even aging and battered, people."]],
  ["Portraiture and new subjects",[
    "Hellenistic artists developed individualized portraits, especially of rulers, philosophers, and poets. Alexander the Great's portraits by Lysippos, with upturned gaze and tousled hair, set a model for rulers. Coins carried ruler portraits throughout the Hellenistic kingdoms.",
    "Artists also depicted children, rustic scenes, comic figures, and sensuous subjects. Small terracotta figurines from Tanagra show elegantly dressed women, and mosaics such as the Alexander Mosaic from Pompeii, a Roman copy of a Hellenistic painting showing Alexander defeating the Persian king Darius III, reveal the lost achievements of Greek painting."]],
  ["Art across cultures",[
    "Hellenistic art spread far beyond Greece. In Ptolemaic Egypt, Greek and Egyptian styles blended. In Gandhara, in present-day Pakistan and Afghanistan, Greco-Buddhist art combined Hellenistic naturalism with Buddhist subjects, producing some of the earliest images of the Buddha in human form, with wavy hair and draped robes reminiscent of Greek statues.",
    "The Colossus of Rhodes, a bronze statue of the sun god Helios about 33 meters tall, and the Lighthouse of Alexandria were among the Seven Wonders of the Ancient World."]],
  ["Legacy",[
    "The Romans conquered the Hellenistic kingdoms and became avid collectors and copyists of Greek art, carrying statues to Rome and commissioning copies; much of what we know of Greek sculpture survives only through them.",
    "Hellenistic drama and emotion later inspired Baroque artists such as Bernini, and the rediscovery of works such as the Laocoön and the Belvedere Torso shaped the Renaissance."]]
  ],
  terms:[["Hellenistic","The period of Greek culture after Alexander, 323–31 BCE."],["Pergamon Altar","A monumental altar with a dramatic battle frieze."],["Laocoön","A sculpture of a priest and his sons attacked by serpents."],["Winged Victory of Samothrace","A Hellenistic statue of Nike alighting on a ship."],["Alexander Mosaic","A Pompeian mosaic of Alexander battling Darius."],["Gandhara art","Greco-Buddhist art of ancient Pakistan and Afghanistan."]],
  w:"Hellenistic art expanded the range of human experience in art, from agony to everyday life, and influenced artists from Gandhara to the Baroque.",
  src:["Hellenistic art","Pergamon Altar","Laocoön and His Sons","Winged Victory of Samothrace","Venus de Milo","Alexander Mosaic","Greco-Buddhist art"],
  q:[["Which altar has a frieze of the battle of gods and giants?","The Pergamon Altar","The Ara Pacis","The Altar of Zeus at Olympia","The Parthenon"],
     ["Which famous artist saw the Laocoön when it was unearthed in 1506?","Michelangelo","Leonardo","Raphael","Donatello"],
     ["Where was the Venus de Milo found?","Melos","Samothrace","Rhodes","Delos"],
     ["Which mosaic shows Alexander defeating Darius III?","The Alexander Mosaic","The Nile Mosaic","The Ravenna Mosaic","The Battle of Issus Fresco"],
     ["Where did Greco-Buddhist art develop?","Gandhara","Bengal","Sri Lanka","Tibet"],
     ["Which statue was one of the Seven Wonders?","The Colossus of Rhodes","The Venus de Milo","The Laocoön","The Dying Gaul"]]},

{ t:"Etruscan and Roman Art", s:"Realism, power, and engineering",
  sec:[
  ["The Etruscans",[
    "Before Rome's rise, the Etruscans dominated central Italy (about 800–300 BCE). They traded with Greece and absorbed Greek influences but developed their own style. Their tombs, carved into rock or built as mounds at necropolises such as Cerveteri and Tarquinia, were painted with lively scenes of banquets, dancing, music, and games.",
    "Etruscan sculptors excelled in terracotta and bronze: the Sarcophagus of the Spouses (about 520 BCE) shows a couple reclining affectionately at a banquet, and the Apollo of Veii shows striding energy. The Capitoline She-Wolf, the symbol of Rome, was long considered Etruscan, though some scholars now date it to the Middle Ages."]],
  ["Roman portraiture",[
    "Roman art drew heavily on Greek models, but Romans also valued realism, especially in portraiture. Republican-era portrait busts (verism) depicted elderly men with wrinkles, sagging skin, and receding hair, celebrating age, experience, and dignity; the tradition may relate to the wax masks of ancestors that Roman families kept and displayed.",
    "Imperial portraits served propaganda. The statue of Augustus of Prima Porta (early 1st century CE) shows the first emperor in an idealized, youthful pose based on Polykleitos's Doryphoros, with symbolic armor celebrating his diplomatic victories. Later emperors' portraits varied with their image: Hadrian wore a Greek-style beard, and the equestrian statue of Marcus Aurelius became the model for Renaissance equestrian monuments."]],
  ["Public monuments",[
    "Romans commemorated victories and emperors with monuments. The Ara Pacis Augustae (Altar of Augustan Peace, 13–9 BCE) shows the imperial family in procession. Triumphal arches, such as the Arch of Titus (about 81 CE), whose reliefs show soldiers carrying spoils from the Temple of Jerusalem, and the Arch of Constantine (315 CE), celebrated military triumphs.",
    "Trajan's Column (113 CE) is wrapped by a spiral relief about 200 meters long depicting the emperor's campaigns against the Dacians, with some 2,500 figures, a vast visual narrative."]],
  ["Architecture and engineering",[
    "Roman architecture's great innovations were the arch, the vault, the dome, and concrete, which allowed vast enclosed spaces. The Colosseum (completed 80 CE), which could hold about 50,000 spectators, combined arches and vaults with the Doric, Ionic, and Corinthian orders on its facade. Roman aqueducts, such as the Pont du Gard in France, carried water to cities.",
    "The Pantheon in Rome (about 125 CE), rebuilt under Hadrian, has a concrete dome about 43 meters across with an open oculus at its top, still the largest unreinforced concrete dome in the world. Its interior is a perfect sphere's height and width, a space of cosmic harmony that influenced architects for centuries."]],
  ["Painting and mosaics",[
    "Much Roman painting survives at Pompeii and Herculaneum, buried by the eruption of Vesuvius in 79 CE. Scholars group it into four styles: the First imitating marble panels; the Second creating illusions of architecture and landscapes opening the wall, as in the Villa of the Mysteries with its life-size figures of a mysterious ritual; the Third with delicate ornament on flat colored grounds; and the Fourth combining the earlier styles.",
    "Romans also loved mosaics, images made of small pieces of stone or glass called tesserae, decorating floors and walls throughout the empire. Still lifes, landscapes, garden paintings like those from Livia's villa, and portraits show a rich tradition of naturalistic painting."]],
  ["Late Roman art",[
    "From the 3rd century CE, Roman art became more abstract, frontal, and symbolic, reflecting political crisis and changing values. The porphyry statue of the Tetrarchs (about 300 CE), now in Venice, shows four rulers as identical, stocky figures embracing, emphasizing unity rather than individuality. The colossal head of Constantine, from a statue over 12 meters tall, with huge upward-gazing eyes, projects imperial and spiritual authority.",
    "This shift toward abstraction prepared the way for Early Christian and Byzantine art."]]
  ],
  terms:[["Necropolis","A large ancient cemetery."],["Verism","Extreme realism in Roman Republican portraits."],["Augustus of Prima Porta","An idealized statue of the first emperor."],["Triumphal arch","A monumental arch commemorating victory."],["Concrete","The Roman building material enabling vaults and domes."],["Oculus","An opening at the top of a dome."],["Tesserae","Small pieces used in mosaics."]],
  w:"Roman art combined Greek ideals with realism, propaganda, and engineering genius, creating forms of portraiture and architecture that still shape our cities.",
  src:["Etruscan art","Roman art","Roman portraiture","Augustus of Prima Porta","Trajan's Column","Pantheon, Rome","Roman wall painting"],
  q:[["Which Etruscan work shows a couple reclining at a banquet?","The Sarcophagus of the Spouses","The Apollo of Veii","The Capitoline Wolf","The Chimera of Arezzo"],
     ["What is the extreme realism of Republican portraits called?","Verism","Idealism","Contrapposto","Classicism"],
     ["Which statue of Augustus is based on the Doryphoros?","Augustus of Prima Porta","Augustus as Pontifex Maximus","The Via Labicana Augustus","The Ara Pacis"],
     ["What does Trajan's Column depict?","Campaigns against the Dacians","The sack of Jerusalem","The founding of Rome","The Battle of Actium"],
     ["What is the opening at the top of the Pantheon dome called?","The oculus","The lantern","The apse","The tholos"],
     ["Which villa at Pompeii has life-size figures of a mysterious ritual?","The Villa of the Mysteries","The House of the Faun","The Villa of Livia","The House of the Vettii"]]},

{ t:"Early Christian and Byzantine Art", s:"Images of heaven, 200–1453",
  sec:[
  ["Early Christian art",[
    "The earliest Christian art, from the 3rd century, appears in the catacombs of Rome, underground burial places, and on sarcophagi. It borrowed Roman forms but gave them new meanings: Christ was shown as the Good Shepherd, a youthful figure carrying a lamb, and scenes from the Old and New Testaments, such as Jonah and the whale and the raising of Lazarus, symbolized salvation and resurrection.",
    "After Emperor Constantine legalized Christianity in 313 CE, the Church built large churches on the model of the Roman basilica, a long hall with a central nave, side aisles, and an apse at the end, such as Old St. Peter's in Rome. Churches were plain outside but glowing with mosaics inside."]],
  ["Mosaics of Ravenna",[
    "Ravenna, in northern Italy, which served as an imperial capital in the 5th and 6th centuries, preserves the finest early Christian mosaics. The Mausoleum of Galla Placidia (about 425–450) has a starry blue dome and an image of the Good Shepherd.",
    "The Church of San Vitale (consecrated 547) contains famous mosaic panels of the Byzantine emperor Justinian and Empress Theodora with their courts, bearing offerings, shown frontal, elongated, and weightless against gold backgrounds that suggest a heavenly realm. Such images united political and religious authority."]],
  ["Hagia Sophia",[
    "The Byzantine Empire, the eastern Roman Empire centered on Constantinople, lasted until 1453. Its greatest monument is Hagia Sophia (“Holy Wisdom”), built for Justinian in just five years (532–537) by the architects Anthemius of Tralles and Isidore of Miletus. Its vast dome, about 31 meters across, rests on pendentives, curved triangular sections that allow a round dome to sit on a square base, and a ring of windows at its base makes it seem to float on light.",
    "Justinian is said to have exclaimed on entering, “Solomon, I have surpassed thee.” Hagia Sophia was the world's largest church for nearly a thousand years. After the Ottoman conquest in 1453 it became a mosque, then a museum in 1934, and again a mosque in 2020."]],
  ["Icons and Iconoclasm",[
    "Icons, from the Greek eikon, “image,” are sacred images of Christ, the Virgin Mary, and saints, usually painted in tempera on wooden panels, venerated in Orthodox Christianity as windows to the divine. Their style is deliberately unnaturalistic: flat, frontal, with gold backgrounds, large eyes, and elongated forms, emphasizing spiritual rather than earthly reality. The 6th-century icon of Christ Pantocrator at Saint Catherine's Monastery in Sinai is among the oldest.",
    "From 726 to 843, with a break, the Byzantine Empire was torn by Iconoclasm (“image breaking”), when emperors banned and destroyed religious images as idolatry. The victory of icon supporters in 843, still celebrated as the Triumph of Orthodoxy, made images central to Orthodox worship."]],
  ["Middle and Late Byzantine art",[
    "After Iconoclasm, churches were decorated according to a hierarchical scheme: Christ Pantocrator (“Ruler of All”) in the central dome, the Virgin in the apse, and scenes of the life of Christ and saints below. Fine examples are at Hosios Loukas in Greece, Daphni near Athens, and St. Mark's Basilica in Venice, whose mosaics were made in the Byzantine style.",
    "Late Byzantine art, after the Crusaders sacked Constantinople in 1204, became more emotional and narrative, as in the frescoes of the Chora Church (Kariye) in Istanbul (about 1315–1321), including the dramatic Anastasis, Christ pulling Adam and Eve from their tombs."]],
  ["Byzantine influence",[
    "Byzantine art spread across the Orthodox world: to Russia, where Andrei Rublev painted the famous Trinity icon in the early 15th century; to the Balkans; and to Georgia and Armenia. It influenced Italian painting, whose early masters such as Cimabue and Duccio worked in the “Greek manner” before Giotto's innovations.",
    "After Constantinople fell to the Ottomans in 1453, Greek scholars and artists fled to Italy, and Byzantine traditions continued in icon painting in Crete, Russia, and elsewhere. The Cretan-born painter El Greco began as an icon painter before developing his distinctive style in Spain."]]
  ],
  terms:[["Catacombs","Underground burial places of early Christians."],["Basilica","A long church with nave, aisles, and apse."],["Pendentive","A curved triangle supporting a dome over a square base."],["Icon","A sacred image venerated in Orthodox Christianity."],["Iconoclasm","The destruction of religious images."],["Christ Pantocrator","Christ as ruler of all, often in a dome."],["Hagia Sophia","Justinian's great church in Constantinople."]],
  w:"Early Christian and Byzantine art transformed Roman forms into images of a heavenly realm, shaping religious art across Europe and the Orthodox world for a thousand years.",
  src:["Early Christian art and architecture","Byzantine art","Basilica of San Vitale","Hagia Sophia","Icon","Byzantine Iconoclasm","Chora Church"],
  q:[["Where does the earliest Christian art appear?","The catacombs of Rome","Hagia Sophia","Ravenna","Jerusalem"],
     ["Which church contains mosaics of Justinian and Theodora?","San Vitale, Ravenna","Hagia Sophia","St. Mark's, Venice","Old St. Peter's"],
     ["What allows a round dome to sit on a square base?","Pendentives","Buttresses","Squinches only","Columns"],
     ["Who were the architects of Hagia Sophia?","Anthemius of Tralles and Isidore of Miletus","Iktinos and Kallikrates","Apollodorus of Damascus","Sinan"],
     ["What was the period of image destruction in Byzantium called?","Iconoclasm","The Reformation","The Great Schism","The Triumph"],
     ["Who painted the famous Trinity icon in Russia?","Andrei Rublev","Theophanes the Greek","Dionisius","El Greco"]]}

);


/* ---- from arts-05.js ---- */
/* ARTS FOUNDATIONS, part 5: Unit 3 Medieval Europe */
COURSES.arts.units.push({ t:"Medieval Art in Europe", ch:[

{ t:"Early Medieval Art", s:"Interlace, gold, and illuminated books, 500–1000",
  sec:[
  ["Art of the migrations",[
    "After the Western Roman Empire fell in the 5th century, Germanic peoples, Goths, Franks, Lombards, Anglo-Saxons, and Vikings, established kingdoms across Europe. Their art, often called migration-period art, centered on portable metalwork, brooches, buckles, and weapons, decorated with abstract patterns, intricate interlace, and stylized animals twisting into knots.",
    "The Sutton Hoo ship burial in England, excavated in 1939, the grave of a 7th-century Anglo-Saxon king, probably Rædwald of East Anglia, contained a magnificent gold belt buckle, shoulder clasps inlaid with garnets in cloisonné, and an iron helmet. Viking art produced carved wooden ships, such as the Oseberg ship (about 820), decorated with gripping beasts."]],
  ["Insular manuscripts",[
    "In Ireland and Britain, monks combined Celtic and Anglo-Saxon ornament with Christian texts to create Insular art, especially illuminated manuscripts, handwritten books decorated with color and gold. The Lindisfarne Gospels (about 715–720) and the Book of Kells (about 800), made by monks probably at Iona and Kells and now at Trinity College Dublin, are masterpieces.",
    "Their “carpet pages” are covered entirely with dense interlace, spirals, and animals, and the Chi-Rho page of the Book of Kells, with the first letters of Christ's name in Greek, is so intricate that it rewards magnification. Medieval writers said such work seemed the work of angels."]],
  ["Carolingian art",[
    "Charlemagne, crowned emperor in 800, sought to revive the culture of the Roman Empire, a movement called the Carolingian Renaissance. He gathered scholars at his court in Aachen, promoted learning and the copying of classical and Christian texts, and introduced a clear script, Carolingian minuscule, the ancestor of our lowercase letters.",
    "His Palatine Chapel in Aachen, inspired by San Vitale in Ravenna, is an octagonal domed structure. Carolingian manuscripts, such as the Coronation Gospels and the Ebbo Gospels, whose evangelist portrait of Saint Mark is drawn with frenzied, energetic lines, show a revival of classical figure drawing. The Utrecht Psalter is illustrated with lively pen drawings."]],
  ["Ottonian art",[
    "The Ottonian emperors of Germany (919–1024) continued the Carolingian tradition. Bishop Bernward of Hildesheim commissioned massive bronze doors (1015), cast in single pieces, with Old Testament scenes of the Fall on one side matched with New Testament scenes of Redemption on the other.",
    "The Gero Crucifix in Cologne Cathedral (about 970) is one of the first large sculptures of the crucified Christ shown as dead and suffering, with a sagging body, a powerful new emotional image."]],
  ["Monasteries and treasures",[
    "Monasteries were the main centers of learning and art in the early Middle Ages, where monks copied books, made metalwork, and preserved knowledge. The plan of St. Gall (about 820), an ideal design for a monastery, shows how they were organized.",
    "Church treasuries held reliquaries, containers for relics of saints, made of gold and precious stones, such as the Reliquary of Sainte-Foy at Conques, a seated gold figure covered with jewels. Precious materials expressed the glory of God and the power of the saints."]],
  ["Spain and the Islamic encounter",[
    "In Spain, Christian kingdoms in the north and the Islamic caliphate of Córdoba in the south produced distinctive art. Mozarabic manuscripts, such as illustrated commentaries on the Apocalypse by Beatus of Liébana, used flat, brilliantly colored patterns influenced by Islamic art.",
    "The Great Mosque of Córdoba, begun in 785, with its forest of red-and-white striped double arches, influenced Christian architecture. This exchange between cultures was a recurring feature of medieval art."]]
  ],
  terms:[["Migration-period art","The metalwork art of Germanic peoples after Rome's fall."],["Interlace","A pattern of interwoven lines and bands."],["Cloisonné","Inlaid compartments of enamel or gemstones divided by metal strips."],["Illuminated manuscript","A handwritten book decorated with color and gold."],["Book of Kells","A masterpiece of Insular manuscript art."],["Carolingian Renaissance","Charlemagne's revival of learning and classical culture."],["Reliquary","A container for holy relics."]],
  w:"Early medieval art fused Germanic, Celtic, Roman, and Christian traditions, preserving learning and producing some of the most intricate art ever made.",
  src:["Migration Period art","Sutton Hoo","Book of Kells","Insular art","Carolingian art","Ottonian art","Reliquary"],
  q:[["Which ship burial contained a 7th-century king's treasures?","Sutton Hoo","Oseberg","Gokstad","Lindisfarne"],
     ["Where is the Book of Kells kept?","Trinity College Dublin","The British Library","The Vatican","Kells Abbey"],
     ["Which emperor led a revival of classical learning around 800?","Charlemagne","Otto I","Justinian","Constantine"],
     ["Which script is the ancestor of our lowercase letters?","Carolingian minuscule","Uncial","Gothic textura","Roman capitals"],
     ["Who commissioned the bronze doors of Hildesheim?","Bishop Bernward","Charlemagne","Otto III","Pope Leo III"],
     ["What is a container for relics called?","A reliquary","A chalice","A monstrance","A tabernacle"]]},

{ t:"Romanesque Art", s:"Pilgrimage churches and sculpture, about 1000–1150",
  sec:[
  ["A new age of building",[
    "Around the year 1000, Europe experienced growing stability, population, and prosperity, and a surge of church building. A monk named Raoul Glaber wrote that it was as if the world were clothing itself in a “white robe of churches.” The style of this era, called Romanesque, “in the manner of the Romans,” a 19th-century term, was marked by thick walls, round arches, barrel and groin vaults, and massive piers.",
    "Romanesque churches were often built of stone vaults to reduce the risk of fire, which required thick walls and small windows, giving interiors a solid, fortress-like character."]],
  ["Pilgrimage churches",[
    "Pilgrimage to holy sites was central to medieval religion. The great pilgrimage route to Santiago de Compostela in Spain, where the relics of Saint James were venerated, was lined with churches such as Sainte-Foy at Conques and Saint-Sernin in Toulouse.",
    "These churches developed a plan to handle crowds: a long nave, side aisles, a transept forming a cross shape, and an ambulatory, a walkway around the apse, with radiating chapels where pilgrims could view relics without disturbing services. The great abbey of Cluny in Burgundy, the head of a powerful monastic order, had the largest church in Christendom until the rebuilding of St. Peter's in Rome."]],
  ["The return of monumental sculpture",[
    "Large-scale stone sculpture, rare since Roman times, returned to Europe in the Romanesque period. Sculptors carved the capitals of columns with biblical scenes, monsters, and plants, and decorated church portals, the main doorways, with dramatic images meant to teach and warn the faithful as they entered.",
    "The semicircular area above the door, the tympanum, often showed the Last Judgment or Christ in Majesty. At Saint-Lazare in Autun (about 1130), the sculptor Gislebertus signed his Last Judgment, with its elongated Christ and terrifying demons weighing souls. At Sainte-Madeleine in Vézelay, the tympanum shows Christ sending the apostles to preach to all peoples, and at Moissac, Christ is surrounded by the elders of the Apocalypse."]],
  ["Painting and manuscripts",[
    "Romanesque churches were covered with paintings, now mostly lost. The church of Saint-Savin-sur-Gartempe in France retains a barrel-vaulted ceiling painted with Old Testament scenes, and Catalan churches preserve vivid apse paintings, many now in the National Art Museum of Catalonia in Barcelona.",
    "Illuminated manuscripts continued to flourish, and artists such as the nun Hildegard of Bingen, an abbess, mystic, and composer, had her visions illustrated in luminous images."]],
  ["The Bayeux Tapestry",[
    "The Bayeux Tapestry, actually an embroidery in wool on linen about 70 meters long, tells the story of the Norman conquest of England, culminating in the Battle of Hastings in 1066. Probably made in England in the 1070s, it is a remarkable visual narrative with over 600 figures, horses, ships, and even Halley's Comet.",
    "Its border scenes include fables and daily life. It is a vital historical source as well as a work of art, presenting events from the Norman point of view."]],
  ["Regional variety",[
    "Romanesque art varied across Europe. In Norman England, massive churches such as Durham Cathedral (begun 1093) used ribbed vaults that anticipated Gothic architecture. Italy's Romanesque buildings, such as the cathedral complex of Pisa, with its famous leaning bell tower begun in 1173, used colored marble and arcades inspired by classical models.",
    "In Germany, imperial cathedrals at Speyer, Mainz, and Worms rose with grand towers. The Romanesque style shows how a shared Christian culture produced distinct regional expressions."]]
  ],
  terms:[["Romanesque","The style of about 1000–1150, with round arches and heavy walls."],["Barrel vault","A continuous semicircular vault."],["Transept","The arm crossing the nave in a cross-shaped church."],["Ambulatory","A walkway around the apse."],["Portal","A monumental church doorway."],["Tympanum","The semicircular space above a doorway."],["Bayeux Tapestry","The embroidered narrative of the Norman Conquest."]],
  w:"Romanesque art revived monumental architecture and sculpture in Europe and created powerful images that taught and moved medieval worshippers.",
  src:["Romanesque art","Romanesque architecture","Pilgrimage church","Cluny Abbey","Gislebertus","Tympanum (architecture)","Bayeux Tapestry"],
  q:[["What did the term Romanesque originally mean?","In the manner of the Romans","Built in Rome","Before Rome","Against Rome"],
     ["Which Spanish pilgrimage site held the relics of Saint James?","Santiago de Compostela","Toledo","Burgos","León"],
     ["What is the semicircular space above a doorway called?","The tympanum","The transept","The ambulatory","The apse"],
     ["Which sculptor signed the Last Judgment at Autun?","Gislebertus","Wiligelmo","Benedetto Antelami","Nicola Pisano"],
     ["What does the Bayeux Tapestry depict?","The Norman conquest of England","The First Crusade","The life of Christ","The Viking invasions"],
     ["Which English cathedral used early ribbed vaults?","Durham","Canterbury","Salisbury","Westminster"]]},

{ t:"Gothic Art and Architecture", s:"Cathedrals of light, about 1140–1500",
  sec:[
  ["Abbot Suger and Saint-Denis",[
    "The Gothic style began at the royal abbey church of Saint-Denis, near Paris, rebuilt under Abbot Suger in the 1140s. Suger believed that light was a manifestation of the divine, and his new choir combined pointed arches, ribbed vaults, and large stained-glass windows to flood the interior with colored light, which he called “lux nova,” new light.",
    "The name “Gothic” was coined by Renaissance Italians as an insult, implying the style was barbaric, like the Goths. Its builders called it opus francigenum, “French work.”"]],
  ["The Gothic system",[
    "Gothic architecture combined three key structural elements. The pointed arch directs weight more steeply downward than a round arch and can span different widths at the same height. The ribbed vault concentrates the weight of the ceiling onto ribs and piers, rather than thick walls. The flying buttress, an external arch, carries the outward thrust of the vaults over the side aisles to massive piers outside.",
    "Together these allowed walls to be thinner, taller, and filled with glass. Gothic cathedrals soared: the vaults of Chartres reach about 37 meters, Amiens about 42, and Beauvais about 48, so high that its choir vaults partially collapsed in 1284."]],
  ["Great cathedrals",[
    "The great French cathedrals include Notre-Dame de Paris (begun 1163), badly damaged by fire in 2019 and reopened in December 2024; Chartres, rebuilt after a fire in 1194 and famous for its stained glass and sculpture; Reims, where French kings were crowned; and Amiens, the largest. The Sainte-Chapelle in Paris (1240s), built by Louis IX to house the Crown of Thorns, is almost entirely walls of stained glass.",
    "The style spread across Europe: Salisbury, Canterbury, and Westminster Abbey in England; Cologne in Germany, begun in 1248 and finished only in 1880; Burgos, León, and Toledo in Spain; and Milan Cathedral in Italy. English Gothic developed into the decorative Perpendicular style, with fan vaults such as those at King's College Chapel, Cambridge."]],
  ["Stained glass",[
    "Stained glass windows were made of pieces of colored glass held together by lead strips, with details painted on. They transformed cathedral interiors into luminous spaces and taught biblical stories to a largely illiterate population, sometimes called the “Bible of the poor.” Chartres retains about 150 of its original windows, renowned for their deep “Chartres blue.”",
    "Rose windows, huge circular windows with radiating tracery, such as those of Notre-Dame and Chartres, symbolized the perfection of heaven and the Virgin Mary."]],
  ["Gothic sculpture",[
    "Gothic sculpture grew more naturalistic and humane. At Chartres, the Royal Portal (about 1145–1155) has elongated column statues of Old Testament kings and queens. Later figures, such as the Annunciation and Visitation groups at Reims (about 1230–1255), turn toward each other, smile, and wear deeply carved drapery, suggesting renewed interest in classical sculpture and human emotion.",
    "Gargoyles, carved waterspouts often shaped as grotesque creatures, drained rain from roofs. In Germany, the statues of the founders at Naumburg Cathedral, such as Uta, are strikingly lifelike portraits."]],
  ["Gothic in daily life",[
    "Gothic style extended beyond cathedrals to town halls, guild halls, castles, and private devotional objects. Small ivory carvings, enamelled reliquaries, and books of hours, personal prayer books for wealthy laypeople, flourished in the late Middle Ages.",
    "The Très Riches Heures of the Duke of Berry (about 1412–1416), illuminated by the Limbourg brothers, includes a famous calendar showing aristocratic pleasures and peasant labors for each month in front of real castles, an exquisite example of the International Gothic style, elegant and courtly, that spread across European courts around 1400."]]
  ],
  terms:[["Gothic","The style of soaring cathedrals from about 1140 to 1500."],["Pointed arch","An arch rising to a point, directing weight downward."],["Ribbed vault","A vault supported by a framework of ribs."],["Flying buttress","An external arch supporting the walls."],["Stained glass","Colored glass windows held together with lead."],["Rose window","A large circular window with radiating tracery."],["Book of hours","A personal prayer book for laypeople."],["International Gothic","An elegant courtly style of around 1400."]],
  w:"Gothic cathedrals combined engineering, light, and sculpture into the most ambitious works of medieval Europe, expressing a vision of heaven on earth.",
  src:["Gothic art","Gothic architecture","Basilica of Saint-Denis","Chartres Cathedral","Flying buttress","Stained glass","Très Riches Heures du Duc de Berry"],
  q:[["Where did the Gothic style begin?","The abbey church of Saint-Denis","Notre-Dame de Paris","Chartres","Canterbury"],
     ["Which abbot led the rebuilding of Saint-Denis?","Suger","Bernard of Clairvaux","Hugh of Cluny","Bernward"],
     ["Which structural element supports walls from the outside?","The flying buttress","The pendentive","The barrel vault","The pier"],
     ["Which cathedral is famous for its deep blue stained glass?","Chartres","Amiens","Reims","Beauvais"],
     ["Which Paris chapel is almost entirely stained glass?","The Sainte-Chapelle","Saint-Denis","Notre-Dame","Saint-Germain"],
     ["Who illuminated the Très Riches Heures?","The Limbourg brothers","Jan van Eyck","Jean Pucelle","The Master of Flémalle"]]},

{ t:"Giotto and Siena", s:"The dawn of a new painting, about 1280–1400",
  sec:[
  ["The Italo-Byzantine style",[
    "In 13th-century Italy, painting followed the Byzantine “Greek manner”: flat figures, gold backgrounds, and stylized forms. Altarpieces, painted panels placed behind altars, showed the Virgin and Child enthroned among saints. Cimabue's Santa Trinita Madonna (about 1280–1290) began to give figures more volume and the throne more depth while retaining Byzantine elegance.",
    "At the same time, sculptors Nicola Pisano and his son Giovanni Pisano carved pulpits in Pisa and Siena with figures inspired by ancient Roman sarcophagi, an early revival of classical forms."]],
  ["Giotto",[
    "Giotto di Bondone (about 1267–1337), from Florence, is often called the father of Western painting. He gave his figures weight, solidity, and emotion, placing them in convincing three-dimensional spaces, as if on a stage. The Renaissance writer Giorgio Vasari wrote that Giotto revived the art of painting after centuries of decline.",
    "His masterpiece is the fresco cycle in the Arena (Scrovegni) Chapel in Padua (about 1305), commissioned by the banker Enrico Scrovegni. Its scenes from the lives of the Virgin and Christ include the Lamentation, in which mourners bend over the dead Christ, their grief conveyed through gesture and posture, and angels wail in the sky. A diagonal rock leads the eye to Christ's face. Giotto also designed the bell tower (campanile) of Florence Cathedral."]],
  ["Duccio and Sienese painting",[
    "Siena, Florence's rival, developed its own refined style. Duccio di Buoninsegna (about 1255–1319) painted the Maestà (“Majesty”), an enormous double-sided altarpiece for Siena Cathedral (1308–1311), showing the Virgin enthroned among angels and saints on the front and scenes of Christ's life on the back. When it was finished, it was carried in a joyous procession through the city.",
    "Sienese painting combined Byzantine elegance, gold, and rich color with Gothic grace and a new interest in narrative. Simone Martini's Annunciation (1333), with its elegant gold background and the angel's message in raised letters, is a masterpiece of the International Gothic style."]],
  ["The Lorenzetti brothers",[
    "Pietro and Ambrogio Lorenzetti of Siena experimented with space and naturalism. Ambrogio's frescoes of the Allegory of Good and Bad Government (1338–1339) in Siena's Palazzo Pubblico, the city hall, show the effects of good government on city and countryside: busy shops, dancers, builders, and farmers in a sweeping landscape, among the first panoramic landscapes in Western art since antiquity.",
    "The paintings reminded the city's rulers of their responsibilities, an early example of civic art."]],
  ["The Black Death",[
    "In 1348 the Black Death struck Italy, killing perhaps half the population of Florence and Siena, including probably both Lorenzetti brothers. Some historians have argued that the plague led to a more somber, conservative religious art in the following decades, with an emphasis on death, judgment, and penitence.",
    "Images such as the Triumph of Death frescoes in the Camposanto at Pisa, showing elegant aristocrats confronting corpses, reflect this preoccupation with mortality."]],
  ["Toward the Renaissance",[
    "Giotto's naturalism, interest in space and human emotion, and the narrative innovations of Siena laid the foundations for the Renaissance. Florentine artists of the early 15th century, such as Masaccio, consciously built on Giotto's achievement.",
    "The 14th century also saw the beginnings of humanism, the revival of classical learning promoted by the poet Petrarch, which would shape the art and thought of the coming centuries."]]
  ],
  terms:[["Altarpiece","A painted or carved work behind an altar."],["Italo-Byzantine style","Italian painting in the Byzantine manner."],["Arena (Scrovegni) Chapel","Giotto's fresco cycle in Padua."],["Maestà","A large image of the Virgin enthroned in majesty."],["Allegory of Good and Bad Government","Ambrogio Lorenzetti's civic frescoes in Siena."],["Humanism","The revival of classical learning beginning in the 14th century."]],
  w:"Giotto and the Sienese painters broke with Byzantine conventions to create space, weight, and emotion, opening the way to the Renaissance.",
  src:["Giotto","Scrovegni Chapel","Duccio","Maestà (Duccio)","Simone Martini","Ambrogio Lorenzetti","Cimabue"],
  q:[["Who is often called the father of Western painting?","Giotto","Cimabue","Duccio","Masaccio"],
     ["Where are Giotto's most famous frescoes?","The Arena Chapel in Padua","The Sistine Chapel","Siena Cathedral","The Brancacci Chapel"],
     ["Who painted the Maestà for Siena Cathedral?","Duccio","Simone Martini","Ambrogio Lorenzetti","Cimabue"],
     ["Who painted the Allegory of Good and Bad Government?","Ambrogio Lorenzetti","Pietro Lorenzetti","Giotto","Simone Martini"],
     ["Which disaster struck Italy in 1348?","The Black Death","A great earthquake","The sack of Rome","A famine"],
     ["Which poet promoted the revival of classical learning?","Petrarch","Dante","Boccaccio","Chaucer"]]}

]});


/* ---- from arts-06.js ---- */
/* ARTS FOUNDATIONS, part 6: Unit 4 The Renaissance, chapters 1-5 */
COURSES.arts.units.push({ t:"The Renaissance", ch:[

{ t:"The Early Renaissance in Florence", s:"Brunelleschi, Donatello, and Masaccio",
  sec:[
  ["Rebirth",[
    "The Renaissance (French for “rebirth”) was a cultural movement that began in Italy in the 14th and 15th centuries and spread across Europe. It was driven by humanism, the study of classical Greek and Roman texts, and by a new confidence in human abilities. Artists studied ancient ruins, sculpture, and texts, and sought to represent the natural world accurately, using mathematics, anatomy, and observation.",
    "Florence, a wealthy republic of bankers, merchants, and wool and silk guilds, was the movement's center. Its leading families, especially the Medici, and its guilds competed to adorn the city with art, and Florentines saw themselves as heirs to ancient Rome."]],
  ["The Baptistery doors",[
    "A famous competition in 1401 to design new bronze doors for the Florence Baptistery is often said to mark the start of the Renaissance. Seven artists submitted panels showing the Sacrifice of Isaac; the finalists were Lorenzo Ghiberti and Filippo Brunelleschi, and Ghiberti won. Both panels survive in the Bargello museum.",
    "Ghiberti spent over 20 years on these doors and then another 27 on a second set (1425–1452), whose ten gilded panels of Old Testament scenes use perspective to create deep, convincing spaces. Michelangelo reportedly called them worthy to be the Gates of Paradise, the name they still bear."]],
  ["Brunelleschi and perspective",[
    "Brunelleschi turned to architecture. He solved the problem of covering the enormous crossing of Florence Cathedral, about 45 meters wide, with a dome (1420–1436), using a double shell of brick laid in herringbone patterns and built without centering, the usual wooden scaffolding, an engineering triumph. His buildings, such as the Foundling Hospital and the churches of San Lorenzo and Santo Spirito, revived classical columns, round arches, and harmonious proportions.",
    "Around 1415–1420, Brunelleschi demonstrated linear perspective, a mathematical system in which parallel lines converge at a single vanishing point on the horizon, creating a convincing illusion of depth. Leon Battista Alberti described the method in his treatise On Painting (1435), defining a painting as a window through which the viewer sees the world."]],
  ["Donatello",[
    "Donatello (about 1386–1466) was the greatest sculptor of the early Renaissance. His Saint Mark (1411–1413) for the guild church of Orsanmichele uses classical contrapposto. His bronze David (probably 1440s), likely made for the Medici, was the first freestanding life-size nude statue since antiquity, showing a youthful, sensuous hero standing on Goliath's head.",
    "His Gattamelata (1445–1453) in Padua was the first large bronze equestrian statue since ancient Rome, and his late wooden Mary Magdalene, emaciated and haggard, shows intense emotion. Donatello also developed schiacciato (“flattened”), a very shallow relief that created the illusion of depth."]],
  ["Masaccio",[
    "Masaccio (1401–1428), who died at 26, revolutionized painting. His Holy Trinity fresco in Santa Maria Novella (about 1427) is the first painting to use Brunelleschi's linear perspective systematically, creating the illusion of a chapel opening into the wall, with a skeleton below bearing the inscription “I was once what you are, and what I am you will also be.”",
    "In the Brancacci Chapel, his frescoes such as The Tribute Money show solid, weighty figures lit by a consistent light source, set in a landscape with atmospheric perspective, and his Expulsion from the Garden of Eden shows Adam and Eve's raw anguish. Later Florentine artists, including Michelangelo, studied these frescoes."]],
  ["A new status for artists",[
    "In the Middle Ages, artists were considered craftsmen, trained in workshops through apprenticeship and organized in guilds. Renaissance artists sought recognition as intellectuals, practicing liberal arts based on mathematics, geometry, and learning. Alberti argued that painting deserved the same respect as poetry.",
    "Artists began signing works more often, writing treatises, and becoming celebrated individuals. Giorgio Vasari's Lives of the Most Excellent Painters, Sculptors, and Architects (1550) told the story of Italian art as a progress from Giotto to Michelangelo and founded the discipline of art history."]]
  ],
  terms:[["Renaissance","The rebirth of classical culture in 14th–16th-century Europe."],["Humanism","The study of classical texts and human potential."],["Linear perspective","A system of converging lines meeting at a vanishing point."],["Gates of Paradise","Ghiberti's gilded bronze Baptistery doors."],["Florence Cathedral dome","Brunelleschi's engineering masterpiece."],["Schiacciato","Very shallow relief creating an illusion of depth."],["Holy Trinity","Masaccio's fresco using systematic perspective."]],
  w:"The early Renaissance in Florence created linear perspective, revived classical forms, and raised the status of the artist, setting the course of Western art.",
  src:["Italian Renaissance painting","Florence Baptistery","Filippo Brunelleschi","Linear perspective","Donatello","Masaccio","Lives of the Most Excellent Painters, Sculptors, and Architects"],
  q:[["Who won the 1401 competition for the Florence Baptistery doors?","Lorenzo Ghiberti","Filippo Brunelleschi","Donatello","Jacopo della Quercia"],
     ["Who designed the dome of Florence Cathedral?","Filippo Brunelleschi","Leon Battista Alberti","Michelangelo","Giotto"],
     ["Who wrote On Painting, describing perspective?","Leon Battista Alberti","Giorgio Vasari","Leonardo da Vinci","Piero della Francesca"],
     ["What was Donatello's David the first of since antiquity?","A freestanding life-size nude","A bronze statue","An equestrian statue","A relief"],
     ["Which painting first used linear perspective systematically?","Masaccio's Holy Trinity","Giotto's Lamentation","Duccio's Maestà","Botticelli's Primavera"],
     ["Who wrote the Lives of the artists?","Giorgio Vasari","Alberti","Cellini","Castiglione"]]},

{ t:"Florence and Italy in the 15th Century", s:"Fra Angelico, Piero, Mantegna, and Botticelli",
  sec:[
  ["Religious painting",[
    "Fra Angelico (about 1395–1455), a Dominican friar, combined new perspective and modeling with serene piety. His frescoes in the cells of the Convent of San Marco in Florence, such as the Annunciation at the top of the stairs, were made to aid the friars' meditation, with simple, luminous forms.",
    "Fra Filippo Lippi, a Carmelite friar with a scandalous life, painted tender Madonnas whose grace influenced his pupil Botticelli. Paolo Uccello was obsessed with perspective, as in his three panels of The Battle of San Romano, with foreshortened soldiers and broken lances arranged in perspective lines."]],
  ["Piero della Francesca",[
    "Piero della Francesca (about 1415–1492), from Borgo San Sepolcro, was also a mathematician who wrote treatises on perspective and geometry. His paintings have a calm, timeless clarity, with geometrically pure forms and pale, luminous color.",
    "His masterpieces include The Baptism of Christ, the fresco cycle The Legend of the True Cross in Arezzo, and the mysterious Flagellation of Christ, whose enigmatic composition places the scene of Christ's whipping in the background while three unidentified men talk in the foreground. His profile portraits of the Duke and Duchess of Urbino, Federico da Montefeltro and Battista Sforza, set against a vast landscape, are icons of the Renaissance."]],
  ["Beyond Florence",[
    "The Renaissance spread to other Italian courts. In Mantua, Andrea Mantegna (about 1431–1506) painted the Camera degli Sposi (“Bridal Chamber”) for the Gonzaga family, with a ceiling oculus painted to look open to the sky, with figures peering down, an early example of illusionistic ceiling painting. His Lamentation over the Dead Christ is a startling exercise in foreshortening.",
    "In Urbino, Federico da Montefeltro built a ducal palace that was a model of Renaissance court culture, and in Milan, the Sforza dukes employed Leonardo da Vinci. Rome, under popes such as Sixtus IV, who built the Sistine Chapel (1473–1481), became a magnet for artists, who decorated its walls with frescoes."]],
  ["The Medici",[
    "Cosimo de' Medici (1389–1464), head of the Medici bank, effectively ruled Florence and patronized artists, architects, and scholars, founding a Platonic Academy. His grandson Lorenzo de' Medici, called Lorenzo the Magnificent (1449–1492), was a poet and patron who supported Botticelli, the young Michelangelo, and humanist philosophers.",
    "Medici patronage, rivalry among wealthy families, and civic pride made Florence the artistic capital of Europe. Benozzo Gozzoli's Procession of the Magi frescoes in the Medici Palace chapel (1459) include portraits of the Medici among the kings' retinue."]],
  ["Botticelli",[
    "Sandro Botticelli (about 1445–1510) painted with graceful, flowing lines and delicate beauty. His most famous works, Primavera (about 1480) and The Birth of Venus (about 1484–1486), both in the Uffizi, depict mythological subjects drawn from classical poetry, a new departure for large-scale painting, interpreted through Neoplatonic philosophy that saw earthly beauty as a reflection of divine love.",
    "The Birth of Venus shows the goddess, in a pose borrowed from classical sculpture, arriving on a scallop shell, blown ashore by the winds. Late in life, Botticelli was influenced by the fiery preacher Girolamo Savonarola, who denounced worldly luxury and organized the “bonfire of the vanities” in 1497, and his late works became more austere and religious."]],
  ["Workshops and techniques",[
    "Renaissance art was produced in busy workshops (botteghe), where a master trained apprentices who ground pigments, prepared panels, and painted parts of works. Verrocchio's workshop trained Leonardo da Vinci, Perugino, and others. Contracts specified materials, deadlines, and payment.",
    "During the 15th century, Italian painters gradually adopted oil paint from the Netherlands, combining it with or replacing egg tempera, which allowed richer color, subtler modeling, and softer transitions. Antonello da Messina helped spread oil technique in Italy."]]
  ],
  terms:[["San Marco frescoes","Fra Angelico's meditative paintings in a Dominican convent."],["Piero della Francesca","A painter-mathematician known for calm, geometric clarity."],["Camera degli Sposi","Mantegna's illusionistic room in Mantua."],["Medici","The banking family that dominated Florence and its art."],["Neoplatonism","Philosophy linking earthly beauty to divine love."],["Bottega","A Renaissance artist's workshop."]],
  w:"Fifteenth-century Italian painters refined perspective, light, and grace and introduced mythological subjects, preparing the way for the High Renaissance.",
  src:["Fra Angelico","Piero della Francesca","Andrea Mantegna","Lorenzo de' Medici","Sandro Botticelli","The Birth of Venus","Primavera (Botticelli)"],
  q:[["Who painted the Annunciation in the Convent of San Marco?","Fra Angelico","Fra Filippo Lippi","Botticelli","Uccello"],
     ["Who was a painter and mathematician who wrote on perspective?","Piero della Francesca","Paolo Uccello","Andrea Mantegna","Benozzo Gozzoli"],
     ["Who painted the illusionistic Camera degli Sposi?","Andrea Mantegna","Piero della Francesca","Giovanni Bellini","Melozzo da Forlì"],
     ["Who was called the Magnificent?","Lorenzo de' Medici","Cosimo de' Medici","Federico da Montefeltro","Ludovico Sforza"],
     ["Who painted The Birth of Venus?","Sandro Botticelli","Fra Filippo Lippi","Leonardo da Vinci","Domenico Ghirlandaio"],
     ["Which preacher organized the bonfire of the vanities?","Girolamo Savonarola","Martin Luther","Marsilio Ficino","Pico della Mirandola"]]},

{ t:"Leonardo da Vinci", s:"The universal genius",
  sec:[
  ["Life",[
    "Leonardo da Vinci (1452–1519) was born near the town of Vinci in Tuscany, the illegitimate son of a notary. He trained in the Florence workshop of Andrea del Verrocchio, where, according to Vasari, the angel he painted in Verrocchio's Baptism of Christ was so beautiful that his master gave up painting.",
    "Leonardo worked in Florence, then for Ludovico Sforza, Duke of Milan, from about 1482 to 1499, then again in Florence, Milan, and Rome, and finally in France for King Francis I, dying at Amboise in 1519. He finished relatively few paintings, about 15 to 20 are generally attributed to him, because of his perfectionism and his many other interests."]],
  ["The Last Supper",[
    "The Last Supper (about 1495–1498), painted on the wall of the refectory of the convent of Santa Maria delle Grazie in Milan, captures the dramatic moment when Christ announces that one of his apostles will betray him. The apostles react in four groups of three with varied gestures of shock and questioning, while Christ sits calmly at the center, framed by a window, at the vanishing point of the perspective.",
    "Leonardo experimented with tempera and oil on dry plaster instead of true fresco so he could work slowly, but the paint began flaking within decades. The painting has been restored many times; a major restoration finished in 1999."]],
  ["The Mona Lisa",[
    "The Mona Lisa (begun about 1503), probably a portrait of Lisa Gherardini, wife of the Florentine merchant Francesco del Giocondo, is perhaps the most famous painting in the world. Leonardo kept it for the rest of his life, and it is now in the Louvre.",
    "Its fame rests on its mysterious smile, the use of sfumato, soft, smoky transitions between light and shadow, especially at the corners of the mouth and eyes, the three-quarter pose, the hands resting calmly, and the dreamlike landscape behind, which does not quite match on either side. Its theft from the Louvre in 1911 by an Italian handyman, Vincenzo Peruggia, and its recovery in 1913 made it a global celebrity."]],
  ["Other paintings",[
    "Leonardo's other works include The Annunciation; Lady with an Ermine (about 1489–1491), a portrait of Cecilia Gallerani, now in Kraków; two versions of The Virgin of the Rocks, in the Louvre and London, showing his pyramidal compositions and rocky landscapes; the unfinished Adoration of the Magi; and The Virgin and Child with Saint Anne.",
    "His design for a mural of The Battle of Anghiari in Florence's Palazzo Vecchio, a whirling mass of horses and soldiers, was never finished and is known only through copies, but it influenced generations of artists."]],
  ["The notebooks",[
    "Leonardo filled thousands of pages of notebooks with drawings and notes, written in mirror script from right to left, on anatomy, botany, geology, optics, water, flight, engineering, and military machines. He dissected human corpses and made remarkably accurate anatomical drawings of the heart, the skull, and a fetus in the womb.",
    "His Vitruvian Man (about 1490), a drawing of a man inscribed in a circle and a square, illustrates the ancient Roman architect Vitruvius's ideas of human proportion and has become a symbol of the Renaissance union of art and science. He designed flying machines, armored vehicles, and canals, most never built."]],
  ["Legacy",[
    "Leonardo embodied the Renaissance ideal of the “universal man” (uomo universale), skilled in many fields. His art introduced sfumato, deeper psychological insight, unified compositions, and atmospheric landscapes, establishing the High Renaissance style.",
    "His influence on Raphael and many others was immense, and his notebooks reveal a mind that saw art as a way of understanding nature. In 2017 a painting attributed to him, Salvator Mundi, sold at auction for about 450 million dollars, though its attribution is debated."]]
  ],
  terms:[["Verrocchio","Leonardo's teacher in Florence."],["The Last Supper","Leonardo's mural in Santa Maria delle Grazie, Milan."],["Mona Lisa","Leonardo's portrait famous for its smile and sfumato."],["Sfumato","Soft, smoky transitions between tones."],["Mirror script","Writing reversed from right to left."],["Vitruvian Man","Leonardo's drawing of ideal human proportions."],["Uomo universale","The Renaissance ideal of the universal man."]],
  w:"Leonardo united art and science, creating the most famous images of the Renaissance and embodying the ideal of boundless curiosity.",
  src:["Leonardo da Vinci","The Last Supper (Leonardo)","Mona Lisa","Lady with an Ermine","Vitruvian Man","Andrea del Verrocchio","Personal life of Leonardo da Vinci"],
  q:[["In whose workshop did Leonardo train?","Andrea del Verrocchio","Domenico Ghirlandaio","Sandro Botticelli","Perugino"],
     ["Where is The Last Supper?","Santa Maria delle Grazie, Milan","The Vatican","The Louvre","Santa Croce, Florence"],
     ["Who is the probable sitter of the Mona Lisa?","Lisa Gherardini","Cecilia Gallerani","Isabella d'Este","Ginevra de' Benci"],
     ["When was the Mona Lisa stolen from the Louvre?","1911","1939","1871","1956"],
     ["How did Leonardo write in his notebooks?","In mirror script","In Latin code","In shorthand","In Greek"],
     ["Which drawing illustrates the proportions of Vitruvius?","Vitruvian Man","The Proportions of Man","The Ideal Figure","Homo Universalis"]]},

{ t:"Michelangelo", s:"Sculptor, painter, architect, poet",
  sec:[
  ["Early life",[
    "Michelangelo Buonarroti (1475–1564) trained briefly with the painter Domenico Ghirlandaio and then studied sculpture in the garden of Lorenzo de' Medici, where he encountered ancient statues and humanist thinkers. He considered himself above all a sculptor and believed that the figure already existed within the marble, waiting to be freed.",
    "At about 24 he carved the Pietà (1498–1499) in St. Peter's Basilica, showing the Virgin Mary holding the dead Christ across her lap, with extraordinary polish and tenderness. It is the only work he signed, carving his name on the sash across Mary's chest after overhearing visitors attribute it to another sculptor."]],
  ["David",[
    "Michelangelo's David (1501–1504), carved from a huge block of marble that other sculptors had abandoned, stands about 5.17 meters tall. Unlike earlier Davids shown after victory, his figure is poised before the fight with Goliath, tense and alert, his brow furrowed, in classical contrapposto.",
    "Originally placed in front of Florence's Palazzo della Signoria as a symbol of the republic's defiance of powerful enemies, it was moved to the Galleria dell'Accademia in 1873 and replaced by a copy. It became perhaps the most famous sculpture in the world."]],
  ["The Sistine Chapel ceiling",[
    "In 1508 Pope Julius II commissioned Michelangelo, who protested that he was a sculptor, not a painter, to paint the ceiling of the Sistine Chapel in the Vatican. Working on scaffolding for four years until 1512, he painted over 300 figures, including nine scenes from Genesis along the center, from the Separation of Light and Darkness to the Drunkenness of Noah, surrounded by prophets, sibyls, and nude youths called ignudi.",
    "The Creation of Adam, in which God's finger reaches toward Adam's to give him life, is one of the most famous images in Western art. Michelangelo's powerful, muscular figures in dramatic poses transformed painting. A restoration completed in 1994 revealed bright, vivid colors beneath centuries of grime."]],
  ["Tombs and the Medici Chapel",[
    "Michelangelo spent decades on the tomb of Julius II, originally planned as a vast monument with over 40 statues, eventually reduced to a wall tomb in San Pietro in Vincoli in Rome, with his powerful Moses, horned according to a mistranslation of the Hebrew Bible. The unfinished Slaves or Prisoners, figures struggling out of the stone, show his method.",
    "For the Medici family he designed the New Sacristy at San Lorenzo in Florence (1520–1534), with tombs of two Medici dukes and reclining allegorical figures of Night and Day, Dawn and Dusk, and the Laurentian Library, whose staircase broke classical rules in ways that influenced Mannerism."]],
  ["The Last Judgment",[
    "From 1536 to 1541 Michelangelo painted The Last Judgment on the altar wall of the Sistine Chapel, a vast, swirling composition of over 300 figures around a muscular, judging Christ. The saved rise to heaven on the left, while the damned are dragged down to hell on the right. Michelangelo painted his own face on the flayed skin held by Saint Bartholomew.",
    "Its many nudes provoked controversy, and after the Council of Trent, drapery was painted over some figures by Daniele da Volterra, who became known as Il Braghettone, “the breeches-maker.”"]],
  ["Architect and poet",[
    "In his later years, Michelangelo turned to architecture. He redesigned the Campidoglio, the Capitoline Hill in Rome, as a harmonious piazza, and in 1546 he became chief architect of the new St. Peter's Basilica, designing its great dome, completed after his death by Giacomo della Porta in 1590.",
    "He also wrote over 300 poems, including sonnets to the nobleman Tommaso dei Cavalieri and the poet Vittoria Colonna, revealing his spiritual struggles. His late Pietàs, such as the unfinished Rondanini Pietà, which he worked on until days before his death at 88, are deeply moving. Contemporaries called him “Il Divino,” the divine one, and his terribilità, awesome power, influenced artists for centuries."]]
  ],
  terms:[["Pietà","An image of Mary holding the dead Christ."],["David","Michelangelo's colossal marble statue in Florence."],["Sistine Chapel ceiling","Michelangelo's frescoes of Genesis, 1508–1512."],["Ignudi","Nude youths on the Sistine ceiling."],["The Last Judgment","Michelangelo's altar wall fresco, 1536–1541."],["Terribilità","The awesome power of Michelangelo's art."],["St. Peter's dome","Michelangelo's design completed in 1590."]],
  w:"Michelangelo's sculpture, painting, and architecture set new standards of power and expression, making him one of the most influential artists who ever lived.",
  src:["Michelangelo","Pietà (Michelangelo)","David (Michelangelo)","Sistine Chapel ceiling","The Creation of Adam","The Last Judgment (Michelangelo)","St. Peter's Basilica"],
  q:[["What is the only work Michelangelo signed?","The Pietà in St. Peter's","David","Moses","The Sistine ceiling"],
     ["Which pope commissioned the Sistine Chapel ceiling?","Julius II","Leo X","Sixtus IV","Paul III"],
     ["Which image shows God giving life to Adam?","The Creation of Adam","The Separation of Light and Darkness","The Fall","The Flood"],
     ["Whose face did Michelangelo paint on Saint Bartholomew's flayed skin?","His own","Pope Julius II's","Raphael's","Leonardo's"],
     ["Who painted drapery over some nudes in The Last Judgment?","Daniele da Volterra","Raphael","Giorgio Vasari","Sebastiano del Piombo"],
     ["What did contemporaries call Michelangelo?","Il Divino","Il Magnifico","Il Moro","Il Rosso"]]},

{ t:"Raphael and the High Renaissance in Rome", s:"Harmony, grace, and papal splendor",
  sec:[
  ["The High Renaissance",[
    "The High Renaissance, roughly 1490 to 1527, was a brief period when Leonardo, Michelangelo, and Raphael produced works of supreme balance, harmony, and idealized beauty. Its center shifted from Florence to Rome, where ambitious popes, above all Julius II (1503–1513) and Leo X (1513–1521), a Medici, sought to restore the city's ancient grandeur.",
    "In 1506 Julius II laid the foundation stone of a new St. Peter's Basilica designed by Donato Bramante, whose small Tempietto (about 1502), a circular temple marking the traditional site of Saint Peter's martyrdom, was an ideal of classical architecture."]],
  ["Raphael",[
    "Raphael (Raffaello Sanzio, 1483–1520), from Urbino, trained with the painter Perugino and absorbed lessons from Leonardo and Michelangelo in Florence. Known for his grace, clarity, and sweetness, he painted many Madonnas, such as the Madonna of the Meadow and The Sistine Madonna, whose two dreamy cherubs at the bottom have become famous on their own.",
    "Raphael was admired for his charm and courtly manners, and he ran a large workshop. He died on his 37th birthday in 1520 and was buried, at his own wish, in the Pantheon."]],
  ["The School of Athens",[
    "In 1508 Julius II commissioned Raphael to fresco the papal apartments in the Vatican, now called the Raphael Rooms (Stanze). The Stanza della Segnatura, probably the pope's library, contains frescoes representing theology, philosophy, poetry, and law.",
    "The School of Athens (1509–1511) gathers the great philosophers of antiquity in a vast classical hall inspired by Bramante's designs. At the center, Plato points upward to the realm of ideas while Aristotle gestures toward the earth. Raphael gave Plato the features of Leonardo, painted Michelangelo as the brooding Heraclitus, and included himself among the figures. Opposite, the Disputa depicts a discussion of the Eucharist, uniting heaven and earth."]],
  ["Portraits and late works",[
    "Raphael was a superb portraitist. His portrait of Pope Julius II shows the aged, powerful pope lost in thought, and his Portrait of Baldassare Castiglione depicts the author of The Book of the Courtier, the guide to refined behavior, with subtle warmth.",
    "His final work, The Transfiguration, combines Christ's radiant transfiguration above with a dramatic scene of the healing of a possessed boy below, anticipating Baroque drama. Raphael also designed tapestries for the Sistine Chapel, decorated the Villa Farnesina with the Triumph of Galatea, and served as architect of St. Peter's and supervisor of Rome's antiquities."]],
  ["Ideal beauty",[
    "Raphael's art became the model of ideal beauty and classical harmony for centuries. Academies of art in the 17th to 19th centuries held him up as the greatest painter, and students copied his works.",
    "In the 19th century, a group of English painters rejected this academic ideal and called themselves the Pre-Raphaelite Brotherhood, wanting to return to the sincerity of art before Raphael."]],
  ["The end of an era",[
    "The High Renaissance ended in crisis. The Protestant Reformation, launched by Martin Luther in 1517 partly in protest against the sale of indulgences to fund St. Peter's, divided Western Christianity. In 1527 the troops of Emperor Charles V sacked Rome, scattering artists and shattering the city's confidence.",
    "The harmonious ideal gave way to new styles, Mannerism and later the Baroque, while in Venice and northern Europe, artists developed their own Renaissance traditions."]]
  ],
  terms:[["High Renaissance","The peak of Renaissance art, about 1490–1527."],["Bramante","Architect of the Tempietto and the new St. Peter's."],["Raphael Rooms","Raphael's frescoed papal apartments in the Vatican."],["The School of Athens","Raphael's fresco of ancient philosophers."],["The Sistine Madonna","Raphael's altarpiece with two famous cherubs."],["Sack of Rome","The 1527 attack on Rome by imperial troops."]],
  w:"Raphael and the High Renaissance created a classical ideal of harmony and beauty that guided Western art and teaching for over three hundred years.",
  src:["High Renaissance","Raphael","The School of Athens","Raphael Rooms","Donato Bramante","Sistine Madonna","Sack of Rome (1527)"],
  q:[["Who designed the Tempietto and the new St. Peter's?","Donato Bramante","Michelangelo","Raphael","Antonio da Sangallo"],
     ["Where was Raphael born?","Urbino","Florence","Rome","Perugia"],
     ["In The School of Athens, who points upward?","Plato","Aristotle","Socrates","Pythagoras"],
     ["Whose features did Raphael give to Plato?","Leonardo's","Michelangelo's","Bramante's","Julius II's"],
     ["Where was Raphael buried?","The Pantheon","St. Peter's","Santa Croce","Urbino Cathedral"],
     ["In what year was Rome sacked by imperial troops?","1527","1492","1517","1555"]]}

]});


/* ---- from arts-07.js ---- */
/* ARTS FOUNDATIONS, part 7: Unit 4 chapters 6-9 */
COURSES.arts.units[3].ch.push(

{ t:"The Venetian Renaissance", s:"Color, light, and oil on canvas",
  sec:[
  ["Venice",[
    "Venice, a maritime republic built on islands in a lagoon, grew rich from trade with the eastern Mediterranean and Asia. Its art reflected its unique setting of water, shimmering light, and a cosmopolitan mix of Byzantine, Islamic, and Western influences. While Florentine artists emphasized disegno, drawing and design, Venetians emphasized colorito, color and the application of paint.",
    "Venetian painters were early adopters of oil paint and, in the damp climate where frescoes deteriorated, of canvas, which allowed large paintings and rich, glowing color built up in layers of glazes."]],
  ["Giovanni Bellini",[
    "Giovanni Bellini (about 1430–1516), from a family of painters, transformed Venetian art with warm light, rich color, and serene landscapes. His altarpieces, such as the San Zaccaria Altarpiece (1505), place the Virgin and saints in a calm, harmonious space bathed in soft light, a type called sacra conversazione (“holy conversation”).",
    "His Saint Francis in the Desert shows the saint in ecstasy in a luminous, detailed landscape. Bellini's workshop trained Giorgione and Titian."]],
  ["Giorgione",[
    "Giorgione (about 1477–1510), who died young of the plague, left few works but enormous influence. He introduced poetic, mysterious subjects in which landscape and mood dominate. The Tempest (about 1506–1508) shows a soldier and a nursing woman in a landscape under a stormy sky with a bolt of lightning; its meaning remains debated.",
    "His Sleeping Venus, finished by Titian after his death, established the reclining female nude in a landscape, a subject that would inspire Titian, Velázquez, Goya, and Manet."]],
  ["Titian",[
    "Titian (Tiziano Vecellio, about 1488–1576) dominated Venetian painting for over 60 years and became one of the most celebrated painters in Europe, working for popes, the Holy Roman Emperor Charles V, who made him a count, and Philip II of Spain. His Assumption of the Virgin (1516–1518) for the Frari church in Venice is a towering, dynamic altarpiece.",
    "Titian's Venus of Urbino (1538) reworked Giorgione's sleeping Venus as an awake, sensual woman in a Venetian palace. His mythological “poesie” for Philip II, such as Diana and Actaeon, and his portraits, such as Charles V on horseback at Mühlberg, were hugely influential. In his late works, such as The Flaying of Marsyas, he applied paint loosely with brushes and even fingers, anticipating later painterly styles."]],
  ["Tintoretto and Veronese",[
    "Tintoretto (1518–1594) aimed, it was said, to combine “the drawing of Michelangelo and the color of Titian.” His dramatic, swirling compositions with strong contrasts of light, such as the Last Supper in San Giorgio Maggiore, with a diagonal table and glowing angels, and the vast cycle in the Scuola Grande di San Rocco, anticipated the Baroque.",
    "Paolo Veronese (1528–1588) painted sumptuous, crowded banquet scenes with splendid architecture and costumes. His Feast in the House of Levi (1573), originally a Last Supper, included dogs, dwarfs, and German soldiers; when the Inquisition questioned him, he simply changed the title."]],
  ["Venetian architecture and legacy",[
    "Venice also produced the architect Andrea Palladio (1508–1580), whose villas in the Veneto, such as Villa Rotonda, and churches in Venice, such as San Giorgio Maggiore, revived classical temple forms. His treatise The Four Books of Architecture (1570) influenced architecture across Europe and America, including Thomas Jefferson's Monticello.",
    "Venetian color and painterly brushwork influenced Rubens, Velázquez, Rembrandt, and later painters such as Delacroix and the Impressionists, establishing an alternative to the Florentine emphasis on line."]]
  ],
  terms:[["Disegno and colorito","Drawing and design vs. color and painting."],["Sacra conversazione","The Virgin and saints together in one space."],["Poesie","Titian's mythological paintings for Philip II."],["Reclining nude","A subject established by Giorgione and Titian."],["Scuola Grande di San Rocco","A building filled with Tintoretto's paintings."],["Palladian architecture","Classical style based on Palladio's designs."]],
  w:"Venetian painters made color, light, and oil on canvas the foundation of a tradition that shaped European painting for centuries.",
  src:["Venetian painting","Giovanni Bellini","Giorgione","The Tempest (Giorgione)","Titian","Tintoretto","Andrea Palladio"],
  q:[["What did Venetian painters emphasize over disegno?","Colorito (color)","Perspective","Fresco","Sculpture"],
     ["Who painted The Tempest?","Giorgione","Titian","Bellini","Tintoretto"],
     ["Which Titian painting shows a reclining nude in a Venetian palace?","Venus of Urbino","Sleeping Venus","Danaë","Venus and Adonis"],
     ["Which painter aimed to combine Michelangelo's drawing with Titian's color?","Tintoretto","Veronese","Giorgione","Lotto"],
     ["Why did Veronese rename his Last Supper?","The Inquisition questioned its details","He sold it","It was damaged","The patron asked"],
     ["Who wrote The Four Books of Architecture?","Andrea Palladio","Leon Battista Alberti","Vitruvius","Sebastiano Serlio"]]},

{ t:"Early Netherlandish Painting", s:"Van Eyck, van der Weyden, and the miracle of oil",
  sec:[
  ["The Burgundian Netherlands",[
    "In the 15th century, the cities of Flanders, especially Bruges, Ghent, and later Antwerp, part of the territories of the wealthy Dukes of Burgundy, were among the richest in Europe, centers of the cloth trade and international banking. There a school of painting arose that rivaled Florence, called Early Netherlandish or Flemish Primitives.",
    "Unlike the Italians, Netherlandish painters did not rely on mathematical perspective or classical models. Instead they observed the world with microscopic precision, rendering every texture, reflection, and detail, and filled their works with religious symbolism hidden in everyday objects, sometimes called disguised symbolism."]],
  ["Jan van Eyck",[
    "Jan van Eyck (about 1390–1441), court painter to Duke Philip the Good, perfected oil painting, building up translucent glazes to achieve jewel-like color and astonishing detail. With his brother Hubert, he created the Ghent Altarpiece (completed 1432) in St. Bavo's Cathedral, a huge polyptych with the Adoration of the Mystic Lamb at its center. It is one of the most stolen artworks in history; one panel, the Just Judges, stolen in 1934, has never been recovered.",
    "The Arnolfini Portrait (1434) shows a wealthy couple in their home, with a convex mirror on the back wall reflecting the room and two figures in the doorway, and above it the inscription “Jan van Eyck was here, 1434.” His Madonna of Chancellor Rolin and portraits such as the Man in a Red Turban, possibly a self-portrait, show extraordinary realism."]],
  ["Rogier van der Weyden",[
    "Rogier van der Weyden (about 1399–1464), city painter of Brussels, brought intense emotion to Netherlandish painting. His Descent from the Cross (about 1435), now in the Prado, places life-size figures in a shallow gold space like a carved altarpiece; the fainting Virgin's body echoes the curve of Christ's, expressing her shared suffering.",
    "His compositions were widely copied across Europe. Robert Campin, often identified as the Master of Flémalle, whose Mérode Altarpiece sets the Annunciation in a Flemish middle-class home full of symbolic objects, may have been his teacher."]],
  ["Later masters",[
    "Hugo van der Goes's Portinari Altarpiece (about 1475), commissioned by a Florentine banker in Bruges and shipped to Florence, astonished Italian painters with its realistic shepherds. Hans Memling, in Bruges, painted serene altarpieces and portraits. Dieric Bouts and Gerard David continued the tradition.",
    "Petrus Christus and others spread the techniques, and Netherlandish paintings were collected by Italian patrons, influencing Italian artists' adoption of oil and attention to detail and landscape."]],
  ["Hieronymus Bosch",[
    "Hieronymus Bosch (about 1450–1516), from 's-Hertogenbosch, created some of the most fantastical images in art. His triptych The Garden of Earthly Delights (about 1490–1510), in the Prado, shows Paradise on the left wing, a vast garden of naked figures indulging in strange pleasures with giant fruits and birds in the center, and a nightmarish Hell on the right, full of monsters and torture involving musical instruments.",
    "Bosch's work is usually interpreted as a moral warning against sin, but its imagery remains mysterious. The Surrealists admired him as a forerunner."]],
  ["The triptych and devotion",[
    "Many Netherlandish works were triptychs, three hinged panels that could be closed, revealing different images on the outside, often painted in grisaille (shades of gray) to imitate sculpture, and opened on feast days to reveal brilliant color.",
    "Smaller devotional paintings and portraits were made for private homes, reflecting a growing middle class and new forms of personal piety. Donors were often painted kneeling in the wings, inserting themselves into sacred scenes."]]
  ],
  terms:[["Early Netherlandish painting","The 15th-century school of Flanders."],["Disguised symbolism","Religious meaning hidden in everyday objects."],["Ghent Altarpiece","The van Eyck brothers' great polyptych."],["Arnolfini Portrait","Van Eyck's portrait of a couple with a convex mirror."],["Triptych","A work of three hinged panels."],["Grisaille","Painting in shades of gray."],["The Garden of Earthly Delights","Bosch's fantastical triptych."]],
  w:"Early Netherlandish painters perfected oil painting and observed the world in microscopic detail, rivaling and influencing the Italian Renaissance.",
  src:["Early Netherlandish painting","Jan van Eyck","Ghent Altarpiece","Arnolfini Portrait","Rogier van der Weyden","Hieronymus Bosch","The Garden of Earthly Delights"],
  q:[["Who painted the Arnolfini Portrait?","Jan van Eyck","Rogier van der Weyden","Hans Memling","Robert Campin"],
     ["Where is the Ghent Altarpiece?","St. Bavo's Cathedral, Ghent","Bruges","The Louvre","The Prado"],
     ["Who painted The Descent from the Cross in the Prado?","Rogier van der Weyden","Jan van Eyck","Hugo van der Goes","Dieric Bouts"],
     ["Which altarpiece did a Florentine banker ship to Florence?","The Portinari Altarpiece","The Mérode Altarpiece","The Ghent Altarpiece","The Isenheim Altarpiece"],
     ["Who painted The Garden of Earthly Delights?","Hieronymus Bosch","Pieter Bruegel","Hans Memling","Jan van Eyck"],
     ["What is painting in shades of gray called?","Grisaille","Sfumato","Chiaroscuro","Tenebrism"]]},

{ t:"The Northern Renaissance", s:"Dürer, Grünewald, Holbein, and Bruegel",
  sec:[
  ["Renaissance in the north",[
    "In the 16th century, Renaissance ideas spread north of the Alps to Germany, the Netherlands, France, and England, blending with local traditions of detailed realism. Printing, invented by Johannes Gutenberg in Mainz around 1450, spread humanist learning and images, and the Protestant Reformation, beginning in 1517, transformed religious art in much of northern Europe.",
    "Protestant reformers criticized religious images, and in waves of iconoclasm, statues and paintings were destroyed in churches. Artists in Protestant regions turned increasingly to portraits, landscapes, prints, and secular subjects."]],
  ["Albrecht Dürer",[
    "Albrecht Dürer (1471–1528) of Nuremberg was the greatest artist of the German Renaissance. He traveled twice to Italy, studied perspective and proportion, and brought Italian ideas north while retaining northern precision. He was also a theorist who wrote on geometry and human proportion.",
    "Dürer was the first great artist to build his reputation largely through prints, woodcuts and engravings sold across Europe, including the Apocalypse series, Melencolia I, and the Rhinoceros (1515), drawn from a description without seeing the animal. His Self-Portrait of 1500 shows him frontally, resembling Christ, asserting the dignity of the artist. His watercolors, such as Young Hare (1502), are pioneering nature studies."]],
  ["Grünewald and Cranach",[
    "Matthias Grünewald's Isenheim Altarpiece (about 1512–1516), made for a hospital monastery treating patients with skin diseases such as ergotism, includes one of the most harrowing Crucifixions ever painted: Christ's body is covered with sores, his hands contorted in agony, offering comfort to the suffering patients. When opened, it reveals a radiant Resurrection.",
    "Lucas Cranach the Elder, a friend of Martin Luther, painted portraits of the reformer and Protestant religious images as well as elegant mythological nudes, and ran a large workshop in Wittenberg."]],
  ["Hans Holbein the Younger",[
    "Hans Holbein the Younger (about 1497–1543), born in Augsburg, worked in Basel and then in England, where he became court painter to Henry VIII. His portraits are marvels of precise observation and psychological insight, including Sir Thomas More, Erasmus, and Henry VIII himself, whose broad, imposing image shaped how the king is remembered.",
    "The Ambassadors (1533), in London's National Gallery, shows two French diplomats surrounded by scientific instruments, books, and a lute with a broken string, symbols of learning and discord. In the foreground floats a strange distorted shape that, seen from an angle, becomes a skull, an anamorphosis and memento mori, a reminder of death."]],
  ["Pieter Bruegel the Elder",[
    "Pieter Bruegel the Elder (about 1525–1569), working in Antwerp and Brussels, painted peasant life, proverbs, and landscapes with humor and insight. Netherlandish Proverbs (1559) illustrates over 100 sayings, and The Peasant Wedding and The Peasant Dance show village festivities.",
    "His series of the seasons (1565), including Hunters in the Snow, with hunters returning to a village over a snowy hill with skaters below, is among the greatest landscapes in Western art. The Tower of Babel and The Triumph of Death show his imaginative power, and Landscape with the Fall of Icarus, attributed to him, shows Icarus's tiny legs disappearing into the sea while a ploughman works on, unaware, inspiring W. H. Auden's poem “Musée des Beaux Arts.”"]],
  ["France and the court",[
    "In France, King Francis I invited Italian artists, including the elderly Leonardo, and decorated his palace at Fontainebleau with elegant Mannerist frescoes and stucco by Rosso Fiorentino and Primaticcio, creating the School of Fontainebleau.",
    "Jean Clouet and his son François painted refined court portraits. Renaissance architecture appeared in the Loire Valley châteaux, such as Chambord, with its famous double-helix staircase, possibly designed by Leonardo."]]
  ],
  terms:[["Northern Renaissance","The Renaissance north of the Alps."],["Iconoclasm","The destruction of religious images, as in the Reformation."],["Isenheim Altarpiece","Grünewald's altarpiece for a hospital."],["The Ambassadors","Holbein's double portrait with a hidden skull."],["Anamorphosis","A distorted image that appears correct from an angle."],["Memento mori","A reminder of death."],["Hunters in the Snow","Bruegel's winter landscape."]],
  w:"Northern Renaissance artists combined Italian ideas with northern precision, and their prints, portraits, and peasant scenes widened the subjects of European art.",
  src:["Northern Renaissance","Albrecht Dürer","Isenheim Altarpiece","Hans Holbein the Younger","The Ambassadors (Holbein)","Pieter Bruegel the Elder","The Hunters in the Snow"],
  q:[["Which German artist built his reputation largely through prints?","Albrecht Dürer","Hans Holbein","Matthias Grünewald","Lucas Cranach"],
     ["Which altarpiece was made for a hospital treating skin diseases?","The Isenheim Altarpiece","The Ghent Altarpiece","The Portinari Altarpiece","The Mérode Altarpiece"],
     ["Who was court painter to Henry VIII?","Hans Holbein the Younger","Albrecht Dürer","Lucas Cranach","Jean Clouet"],
     ["What hidden object appears in The Ambassadors?","A distorted skull","A cross","A coin","A letter"],
     ["Who painted Hunters in the Snow?","Pieter Bruegel the Elder","Hieronymus Bosch","Jan van Eyck","Albrecht Altdorfer"],
     ["Which French king invited Leonardo to France?","Francis I","Louis XII","Henry II","Charles VIII"]]},

{ t:"Mannerism", s:"Elegance, artifice, and tension, about 1520–1600",
  sec:[
  ["After perfection",[
    "After the High Renaissance seemed to have achieved perfect harmony, younger artists in the 1520s began deliberately departing from it. Their style, later named Mannerism after the Italian maniera, “style” or “manner,” valued elegance, artifice, complexity, and virtuosity over natural balance.",
    "Mannerist works often feature elongated figures in twisting poses, crowded or ambiguous spaces, unusual colors, unexpected scale, and emotional tension. The style arose in a troubled period marked by the Reformation, the Sack of Rome in 1527, and the Italian Wars."]],
  ["Pontormo and Rosso",[
    "Jacopo Pontormo's Entombment (about 1525–1528) in the Capponi Chapel in Florence shows figures with elongated bodies and anxious faces floating in an indeterminate space with no ground or cross, painted in luminous pinks and blues; it is unclear exactly what moment is depicted.",
    "Rosso Fiorentino's Deposition (1521) in Volterra has angular, almost abstract figures and acid colors. Both painters rejected the calm of the High Renaissance for emotional intensity and strangeness."]],
  ["Parmigianino and Bronzino",[
    "Parmigianino's Madonna with the Long Neck (about 1534–1540) shows the Virgin with an impossibly long, swan-like neck and fingers, holding an oversized Christ Child, while a tiny prophet stands among columns in the background. His Self-Portrait in a Convex Mirror reproduces the distortion of a curved mirror on a convex panel.",
    "Agnolo Bronzino, court painter to Cosimo I de' Medici, painted cool, polished portraits of aristocrats with masklike faces and splendid clothes. His Allegory with Venus and Cupid, an erotic and enigmatic puzzle of figures representing love, jealousy, deceit, and time, is a quintessential Mannerist work."]],
  ["Mannerist sculpture",[
    "Benvenuto Cellini, goldsmith and sculptor, made the gold Salt Cellar of Francis I and the bronze Perseus with the Head of Medusa (1545–1554) in Florence, and wrote a famously boastful autobiography.",
    "Giambologna, a Flemish-born sculptor in Florence, created the Abduction of a Sabine Woman (1581–1583), a group of three intertwined figures spiraling upward, designed to be viewed from all sides, the figura serpentinata (serpentine figure) in sculpture. His flying bronze Mercury was widely copied."]],
  ["El Greco",[
    "Domenikos Theotokopoulos, called El Greco (“the Greek,” 1541–1614), born in Crete, trained as an icon painter, studied in Venice and Rome, and settled in Toledo, Spain. His art combined Byzantine spirituality, Venetian color, and Mannerist elongation into a unique, visionary style.",
    "The Burial of the Count of Orgaz (1586–1588) divides into an earthly realm below, with sober Toledan nobles attending a miraculous burial, and a swirling, flame-like heaven above. His View of Toledo shows the city under a stormy sky. Long neglected, El Greco was rediscovered in the late 19th and 20th centuries and admired by Expressionists and Picasso."]],
  ["Legacy",[
    "Mannerism spread to courts across Europe, from Fontainebleau to Prague, where Emperor Rudolf II collected art and patronized Giuseppe Arcimboldo, who painted portraits composed of fruits, vegetables, and objects.",
    "Long dismissed as decadent, Mannerism was reevaluated in the 20th century, when its distortions and psychological tension seemed to anticipate modern art. Toward the end of the 16th century, the Catholic Church's Counter-Reformation called for clear, direct, emotionally engaging religious art, leading to the Baroque."]]
  ],
  terms:[["Mannerism","The elegant, artificial style that followed the High Renaissance."],["Maniera","Italian for style or manner."],["Figura serpentinata","A spiraling, serpentine figure."],["Madonna with the Long Neck","Parmigianino's elongated Mannerist painting."],["Perseus","Cellini's bronze statue in Florence."],["El Greco","A Cretan-born painter in Toledo with a visionary style."],["Arcimboldo","A painter of portraits made of fruits and objects."]],
  w:"Mannerism shows how artists responded to the perfection of the High Renaissance with elegance, distortion, and tension, and anticipated later expressive art.",
  src:["Mannerism","Pontormo","Parmigianino","Bronzino","Giambologna","El Greco","Giuseppe Arcimboldo"],
  q:[["What does the Italian word maniera mean?","Style or manner","Distortion","Beauty","Elegance"],
     ["Who painted the Madonna with the Long Neck?","Parmigianino","Pontormo","Bronzino","Rosso Fiorentino"],
     ["Who made the bronze Perseus with the Head of Medusa?","Benvenuto Cellini","Giambologna","Donatello","Michelangelo"],
     ["Which sculptor made the Abduction of a Sabine Woman?","Giambologna","Cellini","Bernini","Bandinelli"],
     ["Where was El Greco born?","Crete","Venice","Toledo","Constantinople"],
     ["Who painted portraits made of fruits and vegetables?","Giuseppe Arcimboldo","Bronzino","Pontormo","Caravaggio"]]}

);


/* ---- from arts-08.js ---- */
/* ARTS FOUNDATIONS, part 8: Unit 5 Baroque and Rococo, chapters 1-5 */
COURSES.arts.units.push({ t:"Baroque and Rococo", ch:[

{ t:"Caravaggio and Baroque Painting in Italy", s:"Drama, light, and the Counter-Reformation",
  sec:[
  ["What was the Baroque?",[
    "The Baroque style dominated European art from about 1600 to 1750. Its name may come from the Portuguese barroco, an irregularly shaped pearl, and was first used as an insult meaning bizarre or overwrought. Baroque art is dramatic, dynamic, emotional, and theatrical, using movement, strong contrasts of light and dark, rich color, diagonal compositions, and illusion to overwhelm and engage the viewer.",
    "The Baroque arose in Rome in the context of the Counter-Reformation, the Catholic Church's response to Protestantism. The Council of Trent (1545–1563) called for religious art that was clear, accurate, and emotionally moving, to inspire piety and reaffirm Catholic doctrine. Baroque art also served absolute monarchs who wished to display their power."]],
  ["Caravaggio's revolution",[
    "Michelangelo Merisi da Caravaggio (1571–1610) transformed painting with radical naturalism and dramatic light. He painted saints and biblical figures as ordinary, even rough, working people, using real models from the streets of Rome, with dirty feet and wrinkled faces, a choice that shocked some patrons; several of his altarpieces were rejected.",
    "His technique of tenebrism placed figures in deep darkness, lit by a harsh, raking light from a single source, as if spotlighted on a stage. In The Calling of Saint Matthew (1599–1600) in the church of San Luigi dei Francesi in Rome, a beam of light follows Christ's pointing hand toward the tax collector Matthew at a table of money-counters. The Conversion of Saint Paul shows Paul flung from his horse, arms outstretched, in a moment of blinding revelation."]],
  ["A violent life",[
    "Caravaggio's life was as dramatic as his art. He was repeatedly arrested for brawling, and in 1606 he killed a man, Ranuccio Tomassoni, in a fight and fled Rome under a death sentence. He worked in Naples, Malta, where he was briefly made a Knight of Malta before being imprisoned and escaping, and Sicily.",
    "His late works, such as The Beheading of Saint John the Baptist in Malta, the only painting he signed, written in the Baptist's blood, and David with the Head of Goliath, in which Goliath's severed head is a self-portrait, are dark and sorrowful. He died in 1610 at 38 while trying to return to Rome for a pardon."]],
  ["The Caravaggisti",[
    "Caravaggio's style spread rapidly across Europe through followers called the Caravaggisti, in Italy, France, the Netherlands, and Spain. The Utrecht Caravaggisti, such as Gerrit van Honthorst, carried his influence to the Dutch Republic, where it affected Rembrandt, and Spanish painters including the young Velázquez and Ribera absorbed it.",
    "Artemisia Gentileschi (1593–about 1656), daughter of the painter Orazio Gentileschi, was one of the most accomplished Caravaggesque painters and the first woman admitted to the Florentine Academy of Design. Her Judith Slaying Holofernes shows two powerful women beheading the Assyrian general with grim determination. Her works, often depicting strong biblical and mythological heroines, have been widely reassessed in recent decades."]],
  ["The Carracci and classicism",[
    "A different path was taken by the Carracci family of Bologna, Annibale, Agostino, and Ludovico, who founded an academy that emphasized drawing from life combined with study of Raphael, Michelangelo, and Titian. Annibale Carracci's ceiling of the Farnese Gallery in Rome (1597–1608), with mythological love scenes framed by painted architecture and sculpture, became a model for Baroque decoration.",
    "Their followers, such as Guido Reni, Domenichino, and Guercino, developed a more idealized, classical Baroque, which, alongside Caravaggio's naturalism, shaped 17th-century painting."]],
  ["Illusionistic ceilings",[
    "Baroque painters covered church and palace ceilings with dizzying illusions in which the architecture seems to open to the heavens and figures soar upward. Pietro da Cortona's Glorification of the Barberini Pope Urban VIII in the Palazzo Barberini (1633–1639) is a vast celebration of the pope's family.",
    "Andrea Pozzo's ceiling of the church of Sant'Ignazio in Rome (1691–1694), Glorification of Saint Ignatius, uses quadratura, painted architecture in perspective, so convincingly that from a marked spot on the floor the ceiling appears to rise into the sky. Pozzo also painted a fake dome on a flat ceiling. Such works merged painting, sculpture, and architecture into total spectacles."]]
  ],
  terms:[["Baroque","The dramatic style of about 1600–1750."],["Counter-Reformation","The Catholic Church's response to Protestantism."],["Tenebrism","Dramatic contrast of deep darkness and harsh light."],["Caravaggisti","Followers of Caravaggio's style."],["Artemisia Gentileschi","A leading female Baroque painter."],["Quadratura","Painted architecture creating illusions of space."],["Farnese Gallery","Annibale Carracci's influential ceiling."]],
  w:"Baroque painting, led by Caravaggio's dramatic realism and light, used emotion and theatricality to move viewers in an age of religious and political conflict.",
  src:["Baroque painting","Caravaggio","The Calling of Saint Matthew","Artemisia Gentileschi","Annibale Carracci","Andrea Pozzo","Counter-Reformation"],
  q:[["Which council called for clear, emotionally moving religious art?","The Council of Trent","The Council of Nicaea","Vatican II","The Council of Florence"],
     ["What is Caravaggio's technique of deep darkness and harsh light called?","Tenebrism","Sfumato","Quadratura","Pointillism"],
     ["In which painting does light follow Christ's hand toward a tax collector?","The Calling of Saint Matthew","The Conversion of Saint Paul","The Supper at Emmaus","The Entombment"],
     ["What is the only painting Caravaggio signed?","The Beheading of Saint John the Baptist","David with the Head of Goliath","The Calling of Saint Matthew","Medusa"],
     ["Who was the first woman admitted to the Florentine Academy of Design?","Artemisia Gentileschi","Sofonisba Anguissola","Lavinia Fontana","Elisabetta Sirani"],
     ["Who painted the illusionistic ceiling of Sant'Ignazio?","Andrea Pozzo","Pietro da Cortona","Annibale Carracci","Guercino"]]},

{ t:"Bernini and Baroque Rome", s:"Sculpture and architecture as theater",
  sec:[
  ["Gian Lorenzo Bernini",[
    "Gian Lorenzo Bernini (1598–1680), sculptor, architect, painter, and stage designer, dominated Baroque Rome as Michelangelo had dominated the Renaissance. A child prodigy, he was favored by a series of popes, especially Urban VIII Barberini, and shaped the appearance of Rome more than any other artist.",
    "Bernini's sculptures seem to capture a single dramatic moment and to burst into the viewer's space. He could make marble look like soft flesh, flowing hair, leaves, or billowing cloth."]],
  ["Early sculptures",[
    "For Cardinal Scipione Borghese, the young Bernini carved a series of dynamic marble groups now in the Galleria Borghese. His David (1623–1624), unlike the calm figures of Donatello and Michelangelo, twists in the act of hurling the stone, his lips clenched in concentration, said to be Bernini's own face.",
    "Apollo and Daphne (1622–1625) captures the instant when the nymph, fleeing Apollo, transforms into a laurel tree, her fingers sprouting leaves and her toes becoming roots. The Rape of Proserpina shows Pluto's fingers pressing into Proserpina's thigh as if it were real flesh."]],
  ["The Ecstasy of Saint Teresa",[
    "Bernini's Cornaro Chapel in the church of Santa Maria della Vittoria (1647–1652) is a total work of art combining architecture, sculpture, painting, and light. At its center, The Ecstasy of Saint Teresa depicts the Spanish mystic swooning in spiritual rapture as a smiling angel prepares to pierce her heart with a golden arrow, as she described in her writings.",
    "Hidden windows bathe the figures in light, and gilded rays descend behind them. On the side walls, marble members of the Cornaro family appear in theater boxes, watching the miracle, as if the scene were a performance."]],
  ["St. Peter's Basilica",[
    "Bernini worked at St. Peter's for much of his life. Beneath Michelangelo's dome he built the Baldacchino (1623–1634), a colossal bronze canopy nearly 30 meters high over the high altar and the tomb of Saint Peter, with twisting Solomonic columns. Bronze for it was reportedly stripped from the Pantheon's portico, prompting the quip “What the barbarians did not do, the Barberini did.”",
    "In the apse, his Cathedra Petri (Chair of Saint Peter) surrounds a relic believed to be Peter's throne with gilded bronze clouds, angels, and a window of golden light with the dove of the Holy Spirit. Outside, he designed St. Peter's Square (1656–1667), whose two curving colonnades of 284 columns embrace visitors like the “maternal arms” of the Church."]],
  ["Fountains and rivals",[
    "Bernini's fountains enliven Rome's piazzas. The Fountain of the Four Rivers (1648–1651) in Piazza Navona has figures representing the Nile, Ganges, Danube, and Río de la Plata, the four continents then known, around an obelisk. The Triton Fountain in Piazza Barberini is another example.",
    "His great rival was the architect Francesco Borromini (1599–1667), whose churches, such as San Carlo alle Quattro Fontane (1638–1641), with its undulating facade and oval dome, and Sant'Ivo alla Sapienza, with its spiraling lantern, used complex geometry to create dynamic spaces. A legend claims that one of Bernini's river gods raises his arm to shield himself from Borromini's church of Sant'Agnese, though the fountain predates the church's facade."]],
  ["Baroque across Europe",[
    "The Baroque spread across Catholic Europe and its colonies. In Austria and southern Germany, architects such as Johann Bernhard Fischer von Erlach and Balthasar Neumann created churches and palaces of dazzling light and ornament. In Spain and Latin America, extremely ornate Churrigueresque altarpieces and facades developed, and colonial cathedrals from Mexico to Peru blended Baroque forms with Indigenous craftsmanship.",
    "Baroque art aimed to overwhelm the senses and draw viewers into a spiritual or political experience, combining every art form into a unified spectacle."]]
  ],
  terms:[["Bernini","The sculptor-architect who shaped Baroque Rome."],["Apollo and Daphne","Bernini's sculpture of transformation into a tree."],["Ecstasy of Saint Teresa","Bernini's sculpture of mystical rapture."],["Baldacchino","Bernini's bronze canopy in St. Peter's."],["St. Peter's Square","Bernini's colonnaded piazza."],["Borromini","Bernini's rival, known for complex geometric churches."],["Churrigueresque","An extremely ornate Spanish Baroque style."]],
  w:"Bernini and Baroque Rome fused sculpture, architecture, and light into theatrical spectacles that still define the city's appearance.",
  src:["Gian Lorenzo Bernini","Apollo and Daphne (Bernini)","Ecstasy of Saint Teresa","St. Peter's Baldachin","St. Peter's Square","Fontana dei Quattro Fiumi","Francesco Borromini"],
  q:[["Which pope especially favored Bernini?","Urban VIII","Julius II","Sixtus V","Leo X"],
     ["Which Bernini sculpture shows a nymph becoming a laurel tree?","Apollo and Daphne","The Rape of Proserpina","David","Truth Unveiled by Time"],
     ["In which chapel is The Ecstasy of Saint Teresa?","The Cornaro Chapel","The Sistine Chapel","The Chigi Chapel","The Cerasi Chapel"],
     ["What is Bernini's bronze canopy in St. Peter's called?","The Baldacchino","The Cathedra Petri","The Tempietto","The Ciborium"],
     ["Which rivers does the Fountain of the Four Rivers represent?","The Nile, Ganges, Danube, and Río de la Plata","The Tiber, Nile, Rhine, and Amazon","The Nile, Tigris, Euphrates, and Jordan","The Thames, Seine, Danube, and Po"],
     ["Who designed San Carlo alle Quattro Fontane?","Francesco Borromini","Bernini","Carlo Maderno","Pietro da Cortona"]]},

{ t:"The Spanish Golden Age", s:"El Greco's heirs, Zurbarán, Velázquez, and Murillo",
  sec:[
  ["Spain's Golden Age",[
    "The 16th and 17th centuries were Spain's Golden Age (Siglo de Oro), when it ruled a vast empire in the Americas, Europe, and Asia and produced great literature, including Cervantes's Don Quixote, and painting. Spanish art was shaped by intense Catholic piety, the Counter-Reformation, and royal patronage, and its Baroque painting was often austere and realistic rather than lavish.",
    "Seville, the port for trade with the Americas, and Madrid, the royal capital from 1561, were the main centers."]],
  ["Ribera and Zurbarán",[
    "Jusepe de Ribera, a Spaniard working in Spanish-ruled Naples, adopted Caravaggio's tenebrism and painted harrowing martyrdoms and powerful images of saints and beggars, such as The Clubfooted Boy.",
    "Francisco de Zurbarán (1598–1664), in Seville, painted monks and saints for monasteries with stark, sculptural clarity and meditative stillness. His Saint Serapion shows a martyred friar in white robes against a dark background, and his still lifes of a few objects arranged in a row have a quiet spiritual intensity."]],
  ["Diego Velázquez",[
    "Diego Velázquez (1599–1660), from Seville, is often considered the greatest Spanish painter. His early bodegones, kitchen scenes such as An Old Woman Cooking Eggs, show remarkable realism. In 1623 he became court painter to King Philip IV in Madrid, a position he held for the rest of his life, painting the royal family, courtiers, and court dwarfs and jesters with equal dignity and psychological insight.",
    "Two trips to Italy deepened his art; in Rome he painted the Portrait of Pope Innocent X (1650), so penetrating that the pope reportedly said it was “too true.” His The Surrender of Breda depicts a Spanish victory with unusual humanity, the victor consoling the vanquished. His brushwork became increasingly loose, so that up close his paintings dissolve into strokes that cohere at a distance, anticipating Impressionism."]],
  ["Las Meninas",[
    "Las Meninas (“The Ladies-in-Waiting,” 1656), in the Prado, is one of the most analyzed paintings in Western art. It shows the young Infanta Margarita surrounded by her maids of honor, a dwarf, a dog, and courtiers, while Velázquez himself stands at a large canvas, brush in hand, looking out at the viewer. In a mirror on the back wall appear the king and queen, apparently standing where the viewer stands.",
    "The painting raises puzzling questions about seeing and representation: what is Velázquez painting, and who is the true subject? Philosophers such as Michel Foucault have written about it, and Picasso painted 58 variations on it in 1957. Velázquez painted himself wearing the red cross of the Order of Santiago, a knighthood he received after the painting was finished; tradition says the king had it added."]],
  ["Murillo",[
    "Bartolomé Esteban Murillo (1617–1682) of Seville painted gentle, sweet religious images, especially of the Immaculate Conception, showing the Virgin floating on clouds surrounded by cherubs, and charming scenes of street children, such as Young Beggar and boys eating fruit.",
    "Murillo's soft style and warm color made him extremely popular, especially in the 18th and 19th centuries. Juan de Valdés Leal, also in Seville, painted gruesome vanitas images of death."]],
  ["Spanish legacy",[
    "Spanish Baroque art spread throughout Spain's American empire, where schools such as the Cuzco School in Peru and painters in Mexico produced religious art combining European models with local styles and materials.",
    "Velázquez's influence was immense in the 19th century, when Manet, visiting the Prado in 1865, called him “the painter of painters.” Goya, the next great Spanish painter, studied his works closely."]]
  ],
  terms:[["Siglo de Oro","Spain's Golden Age of the 16th and 17th centuries."],["Bodegón","A Spanish kitchen scene or still life."],["Velázquez","Court painter to Philip IV."],["Las Meninas","Velázquez's famous painting of the Infanta and her court."],["Immaculate Conception","A popular subject showing the Virgin on clouds."],["Cuzco School","A colonial painting tradition in Peru."]],
  w:"Spain's Golden Age produced painting of austere piety and profound realism, culminating in Velázquez, whom later painters called the painter of painters.",
  src:["Spanish Golden Age","Jusepe de Ribera","Francisco de Zurbarán","Diego Velázquez","Las Meninas","Portrait of Innocent X","Bartolomé Esteban Murillo"],
  q:[["To which king was Velázquez court painter?","Philip IV","Philip II","Charles II","Charles V"],
     ["Which pope reportedly called his Velázquez portrait too true?","Innocent X","Urban VIII","Alexander VII","Clement IX"],
     ["Who appears in the mirror in Las Meninas?","The king and queen","The Infanta","Velázquez","A courtier"],
     ["How many variations on Las Meninas did Picasso paint?","58","12","100","3"],
     ["Who painted meditative monks for Spanish monasteries?","Francisco de Zurbarán","Murillo","Ribera","Velázquez"],
     ["Who called Velázquez the painter of painters?","Édouard Manet","Pablo Picasso","Francisco Goya","Salvador Dalí"]]},

{ t:"Rubens and Flemish Baroque", s:"Energy, color, and abundance",
  sec:[
  ["Flanders after the split",[
    "In the late 16th century the Netherlands split: the northern provinces, mostly Protestant, became the independent Dutch Republic, while the southern provinces, Flanders, remained Catholic and under Spanish Habsburg rule. Antwerp, the main city of Flanders, became a center of Catholic Baroque art, with churches to be redecorated after Protestant iconoclasm.",
    "Flemish Baroque art combined the Netherlandish tradition of detail and oil technique with Italian grandeur and Counter-Reformation drama."]],
  ["Peter Paul Rubens",[
    "Peter Paul Rubens (1577–1640) was the leading artist of Flemish Baroque and one of the most prolific and successful painters in history. Educated, multilingual, and charming, he spent eight years in Italy studying Titian, Michelangelo, and Caravaggio, and served as a diplomat for the Spanish Habsburgs, helping negotiate peace between England and Spain, for which he was knighted by Charles I of England.",
    "Rubens ran a large, efficient studio in Antwerp, where assistants worked from his oil sketches, and he collaborated with specialists in animals, landscapes, and flowers. His house and studio, the Rubenshuis, can still be visited."]],
  ["Style and masterpieces",[
    "Rubens's paintings burst with energy, swirling movement, glowing color, and full, fleshy figures; the term “Rubenesque” now describes plump, voluptuous women. His altarpieces for Antwerp Cathedral, The Elevation of the Cross (1610–1611) and The Descent from the Cross (1611–1614), show muscular figures straining along powerful diagonals.",
    "For the French queen Marie de' Medici he painted a cycle of 24 huge canvases (1622–1625), now in the Louvre, glorifying her life with allegory and mythology. He also painted the ceiling of the Banqueting House in Whitehall, London, for Charles I, and late in life tender portraits of his young second wife, Helena Fourment, and luminous landscapes."]],
  ["Anthony van Dyck",[
    "Anthony van Dyck (1599–1641), Rubens's most brilliant assistant, became the leading portrait painter of his time. As court painter to Charles I of England from 1632, he created an image of aristocratic elegance and ease, with elongated figures, refined hands, and shimmering silks, as in Charles I at the Hunt, which shows the king casually dismounted, effortlessly regal.",
    "Van Dyck's elegant style shaped British portraiture for two centuries, influencing Gainsborough and Reynolds. A pointed beard style is named after him."]],
  ["Jordaens and others",[
    "Jacob Jordaens painted boisterous, earthy scenes, such as The King Drinks, a lively feast celebrating Epiphany, with crowded, robust figures. Frans Snyders specialized in hunting scenes and lavish still lifes of game and fruit.",
    "Jan Brueghel the Elder, son of Pieter Bruegel, painted exquisitely detailed flower pieces and paradise landscapes, often collaborating with Rubens. Flemish painters were also famous for “gallery paintings,” depicting collectors' rooms crammed with paintings."]],
  ["Legacy",[
    "Rubens's influence extended across Europe for centuries. In 18th-century France, a debate in the Royal Academy between the Poussinistes, who valued drawing and rational composition following Nicolas Poussin, and the Rubénistes, who championed color and feeling following Rubens, ended with the triumph of color and opened the way to the Rococo painters such as Watteau.",
    "Later colorists, including Delacroix and Renoir, admired Rubens deeply."]]
  ],
  terms:[["Flemish Baroque","The Catholic Baroque art of Flanders."],["Rubenesque","Full and voluptuous, after Rubens's figures."],["Oil sketch","A small preparatory painting used to guide assistants."],["Marie de' Medici cycle","Rubens's 24 allegorical paintings of the French queen."],["Van Dyck","Court portraitist to Charles I."],["Poussinistes and Rubénistes","Advocates of drawing versus color in the French Academy."]],
  w:"Rubens and the Flemish Baroque brought exuberant color, movement, and grandeur to European painting and shaped portraiture for centuries.",
  src:["Flemish Baroque painting","Peter Paul Rubens","The Elevation of the Cross","Marie de' Medici cycle","Anthony van Dyck","Jacob Jordaens","Poussinists and Rubenists"],
  q:[["Which city was the center of Flemish Baroque art?","Antwerp","Amsterdam","Brussels","Ghent"],
     ["Which English king knighted Rubens?","Charles I","James I","Charles II","Henry VIII"],
     ["For which queen did Rubens paint a 24-canvas cycle?","Marie de' Medici","Elizabeth I","Anne of Austria","Catherine de' Medici"],
     ["Who was Rubens's most brilliant assistant?","Anthony van Dyck","Jacob Jordaens","Frans Snyders","Jan Brueghel"],
     ["Who painted Charles I at the Hunt?","Anthony van Dyck","Rubens","Velázquez","Rembrandt"],
     ["Which side won the debate in the French Academy?","The Rubénistes, favoring color","The Poussinistes, favoring drawing","Neither","The Caravaggisti"]]},

{ t:"Rembrandt", s:"Light, humanity, and the self",
  sec:[
  ["The Dutch Republic",[
    "The Dutch Republic, independent from Spain after a long revolt (1568–1648), became in the 17th century one of the richest and most powerful nations in Europe, centered on trade, finance, and the Dutch East India Company. It was largely Protestant, Calvinist churches had no religious images, and its prosperous middle-class citizens bought paintings for their homes on an open market, creating an unprecedented boom in art. Thousands of painters produced millions of paintings.",
    "Artists specialized in genres, landscapes, seascapes, still lifes, portraits, and scenes of daily life, for which buyers had a strong appetite."]],
  ["Rembrandt's career",[
    "Rembrandt van Rijn (1606–1669), born in Leiden, moved to Amsterdam in the early 1630s and quickly became its most fashionable portrait painter. His Anatomy Lesson of Dr. Nicolaes Tulp (1632) made his name, transforming the traditional group portrait into a dramatic scene. He married Saskia van Uylenburgh, bought a grand house, and collected art and curiosities.",
    "His fortunes declined: Saskia died in 1642, his spending exceeded his income, and in 1656 he was declared insolvent; his house and collection were sold. His later years brought more personal losses, including the death of his partner Hendrickje Stoffels and his son Titus, but his art grew ever deeper."]],
  ["The Night Watch",[
    "The Night Watch (1642), properly The Militia Company of Captain Frans Banninck Cocq, is Rembrandt's most famous painting, now in the Rijksmuseum in Amsterdam. Instead of the usual static rows of figures, he showed the civic guard company bursting into action, with dramatic light picking out the captain, his lieutenant in yellow, and a mysterious girl carrying a chicken.",
    "It acquired its nickname because darkened varnish made it look like a night scene. The painting was trimmed on its sides in 1715 to fit a wall. It has been the subject of a major, publicly viewable restoration and research project, Operation Night Watch, begun in 2019."]],
  ["Self-portraits",[
    "Rembrandt painted, drew, and etched about 80 self-portraits over 40 years, more than any major artist before him, creating an unparalleled visual autobiography. Early ones show him experimenting with expressions and costumes; the late self-portraits, such as the Self-Portrait with Two Circles at Kenwood House, show him aging, weathered, and unflinchingly honest.",
    "His late style used thick impasto, sometimes applied with a palette knife, and warm, glowing colors emerging from darkness. Works such as The Jewish Bride and The Return of the Prodigal Son, showing a father embracing his kneeling, ragged son, express deep tenderness and spiritual feeling."]],
  ["Etchings and drawings",[
    "Rembrandt was also the greatest etcher in history. His prints, such as the Hundred Guilder Print, showing Christ healing the sick, and The Three Crosses, which he reworked through several dramatically different states, explore light and darkness with the same intensity as his paintings.",
    "His hundreds of drawings in pen and wash capture everyday life, landscapes, and biblical scenes with a few swift strokes. He also ran a busy workshop and trained many pupils, which has made attribution of his paintings difficult; the Rembrandt Research Project, from 1968, reexamined hundreds of attributed works."]],
  ["Rembrandt's humanity",[
    "Rembrandt is often admired above all for his humanity: his ability to convey inner life, emotion, and dignity in ordinary people, biblical figures, and himself. Unlike many contemporaries, he painted biblical stories with intimate, psychological realism, often using the Jewish residents of his Amsterdam neighborhood as models.",
    "His use of light, not as a dramatic spotlight like Caravaggio's but as a warm, glowing presence emerging from shadow, became one of the most admired achievements in painting."]]
  ],
  terms:[["Dutch Golden Age","The 17th-century flourishing of the Dutch Republic."],["Art market","Selling art to anonymous buyers rather than on commission."],["The Night Watch","Rembrandt's dramatic group portrait of a militia company."],["Self-portrait","An artist's portrait of himself or herself."],["Impasto","Thick, textured paint."],["States (printmaking)","Successive versions of a print as the plate is reworked."]],
  w:"Rembrandt's mastery of light and his profound portrayal of human feeling make him one of the greatest artists in history.",
  src:["Dutch Golden Age painting","Rembrandt","The Anatomy Lesson of Dr. Nicolaes Tulp","The Night Watch","The Return of the Prodigal Son (Rembrandt)","Rembrandt Research Project"],
  q:[["Which painting made Rembrandt's name in Amsterdam?","The Anatomy Lesson of Dr. Nicolaes Tulp","The Night Watch","The Jewish Bride","The Syndics"],
     ["Where is The Night Watch?","The Rijksmuseum","The Mauritshuis","The Louvre","The National Gallery"],
     ["Why is it called The Night Watch?","Darkened varnish made it look like night","It shows a night patrol","Rembrandt painted it at night","It was hung in a dark room"],
     ["About how many self-portraits did Rembrandt make?","About 80","About 10","About 25","About 300"],
     ["In what year was Rembrandt declared insolvent?","1656","1642","1632","1669"],
     ["Which late painting shows a father embracing his kneeling son?","The Return of the Prodigal Son","The Jewish Bride","The Sacrifice of Isaac","Jacob Blessing"]]}

]});


/* ---- from arts-09.js ---- */
/* ARTS FOUNDATIONS, part 9: Unit 5 chapters 6-9 */
COURSES.arts.units[4].ch.push(

{ t:"Vermeer and the Dutch Golden Age", s:"Light, interiors, landscapes, and still lifes",
  sec:[
  ["Johannes Vermeer",[
    "Johannes Vermeer (1632–1675) of Delft left only about 35 paintings, mostly quiet interior scenes of one or two figures, usually women, reading letters, playing music, pouring milk, or weighing pearls, bathed in soft daylight from a window on the left. His paintings are admired for their stillness, perfect compositions, luminous color, and the way light seems to fall on every surface.",
    "Vermeer used expensive ultramarine lavishly and may have used a camera obscura, a device projecting an image through a lens, to study optical effects; his paintings show small dots of light, called pointillés, on highlights. He died in debt, and was largely forgotten until the French critic Théophile Thoré-Bürger rediscovered him in the 1860s."]],
  ["Vermeer's masterpieces",[
    "Girl with a Pearl Earring (about 1665), in the Mauritshuis in The Hague, is not a portrait but a tronie, a study of a face in exotic costume, a turbaned girl turning to look over her shoulder with parted lips. The Milkmaid shows a kitchen maid pouring milk with complete absorption, dignifying humble labor.",
    "View of Delft, a cityscape of shimmering light and reflections, was praised by the novelist Marcel Proust as the most beautiful painting in the world. The Art of Painting shows an artist from behind painting a model posing as Clio, the muse of history, an allegory of the art itself."]],
  ["Genre painters",[
    "Many Dutch painters specialized in scenes of everyday life. Pieter de Hooch painted courtyards and orderly domestic interiors with views through doorways. Jan Steen painted rowdy households and taverns full of humor and moral warnings. Gerard ter Borch painted elegant figures in shimmering satin, and Gerrit Dou's tiny, meticulously detailed “fine paintings” were among the most expensive of the age.",
    "Frans Hals (about 1582–1666) of Haarlem painted lively portraits with bold, loose brushstrokes that capture fleeting expressions, as in The Laughing Cavalier, and group portraits of civic guards and the regents of almshouses. Judith Leyster, a member of the Haarlem painters' guild, painted cheerful genre scenes and a confident self-portrait at her easel."]],
  ["Landscapes and seascapes",[
    "The Dutch made landscape a major independent genre, painting their own flat country with low horizons and vast, cloudy skies. Jacob van Ruisdael's The Windmill at Wijk bij Duurstede and views of Haarlem convey grandeur and melancholy. Meindert Hobbema's The Avenue at Middelharnis shows a road lined with tall trees receding into the distance.",
    "Seascapes celebrated the maritime nation's ships and naval battles, and painters such as Aelbert Cuyp painted cattle in golden light. Pieter Saenredam painted precise, whitewashed church interiors. Cityscapes and topographical views recorded the prosperous towns."]],
  ["Still lifes",[
    "Dutch still-life painters achieved astonishing realism. Banquet pieces showed tables with silver, glass, lemons with spiraling peel, and half-eaten food; flower paintings, by artists such as Rachel Ruysch, one of the most successful painters of her time, combined blooms from different seasons that could never appear together, symbolizing the transience of beauty.",
    "Many still lifes carried moral meanings: vanitas paintings with skulls, hourglasses, and snuffed candles warned against vanity. Tulip mania, a speculative bubble in tulip bulbs that collapsed in 1637, shows how luxury goods fascinated this commercial society."]],
  ["A middle-class art",[
    "Dutch Golden Age painting reflected a society of merchants, artisans, and Protestant values, with paintings of modest size suited to homes rather than churches or palaces. Its emphasis on careful observation of everyday reality and its range of secular subjects profoundly influenced later art.",
    "The Mauritshuis in The Hague and the Rijksmuseum in Amsterdam hold the greatest collections of this art today."]]
  ],
  terms:[["Vermeer","The Delft painter of luminous interiors."],["Camera obscura","A device projecting an image through a lens."],["Tronie","A study of a face or character type."],["Frans Hals","A Haarlem portraitist known for loose brushwork."],["Dutch landscape","Low horizons and vast skies."],["Banquet piece","A still life of a table with food and tableware."],["Tulip mania","The speculative bubble in tulip bulbs, 1637."]],
  w:"The Dutch Golden Age turned everyday life, landscape, and objects into great art, with Vermeer's luminous interiors among its finest achievements.",
  src:["Johannes Vermeer","Girl with a Pearl Earring","View of Delft","Frans Hals","Jacob van Ruisdael","Rachel Ruysch","Dutch Golden Age painting"],
  q:[["About how many paintings by Vermeer survive?","About 35","About 350","About 100","About 10"],
     ["Where is Girl with a Pearl Earring?","The Mauritshuis","The Rijksmuseum","The Louvre","The Prado"],
     ["Which novelist called View of Delft the most beautiful painting?","Marcel Proust","Victor Hugo","Émile Zola","Gustave Flaubert"],
     ["Who painted The Laughing Cavalier?","Frans Hals","Rembrandt","Jan Steen","Gerard ter Borch"],
     ["Which female painter was famous for flower pieces?","Rachel Ruysch","Judith Leyster","Clara Peeters","Maria van Oosterwijck"],
     ["When did tulip mania collapse?","1637","1648","1600","1672"]]},

{ t:"French Classicism and Versailles", s:"Poussin, Claude, and the art of absolutism",
  sec:[
  ["Classicism in France",[
    "In 17th-century France, a more restrained, rational form of Baroque developed, called French Classicism. It valued order, clarity, balance, and noble subjects drawn from antiquity and the Bible, in line with the ideals of the French Royal Academy of Painting and Sculpture, founded in 1648.",
    "This classical style served the absolute monarchy of Louis XIV, the “Sun King” (reigned 1643–1715), who used art and architecture to glorify his reign and centralize culture under royal control."]],
  ["Nicolas Poussin",[
    "Nicolas Poussin (1594–1665), though French, spent most of his career in Rome, studying ancient sculpture and Raphael. He painted carefully composed, intellectual works on classical, biblical, and mythological subjects, with figures arranged like a sculptural frieze in balanced landscapes, and believed painting should appeal to reason.",
    "His Et in Arcadia Ego (about 1637–1638), in the Louvre, shows shepherds in an idyllic landscape discovering a tomb inscribed “Even in Arcadia, I am,” a meditation on death. Poussin became the model for the French Academy, and his followers, the Poussinistes, championed drawing over color."]],
  ["Claude Lorrain",[
    "Claude Lorrain (about 1600–1682), also French and also working in Rome, painted idealized landscapes of the Roman countryside, the Campagna, and imaginary seaports bathed in golden light, often with the sun low on the horizon. Small figures from classical myths or the Bible appear, but light and atmosphere are the real subjects.",
    "Claude's landscapes were collected eagerly by English aristocrats and inspired English landscape gardens and later painters such as Turner, who asked to have two of his paintings hung beside two of Claude's in the National Gallery."]],
  ["Georges de La Tour and the Le Nain",[
    "Georges de La Tour (1593–1652), from Lorraine, painted quiet, candlelit scenes with simplified forms and profound stillness, such as The Penitent Magdalene and Joseph the Carpenter, in which a child's hand glows red against a candle flame. Forgotten for centuries, he was rediscovered in the 20th century.",
    "The Le Nain brothers painted dignified, sober scenes of peasant families, showing the influence of Caravaggio and Dutch genre painting."]],
  ["Versailles",[
    "Louis XIV transformed a hunting lodge at Versailles, about 20 kilometers from Paris, into the largest and most splendid palace in Europe, moving the court there in 1682. The architects Louis Le Vau and Jules Hardouin-Mansart, the painter Charles Le Brun, who directed the decoration, and the gardener André Le Nôtre created an ensemble glorifying the Sun King.",
    "The Hall of Mirrors (1678–1684), with 357 mirrors facing 17 windows overlooking the gardens and a ceiling painted by Le Brun with the king's triumphs, is its most famous room; there the German Empire was proclaimed in 1871 and the Treaty of Versailles signed in 1919. Le Nôtre's formal gardens, with geometric parterres, avenues, fountains, and the Grand Canal, imposed order on nature, expressing royal power. Versailles was imitated by rulers across Europe."]],
  ["Royal portraiture",[
    "Hyacinthe Rigaud's portrait of Louis XIV (1701) shows the aging king in coronation robes lined with ermine and decorated with fleurs-de-lis, displaying his elegant legs, a supreme image of royal majesty that defined official portraiture for a century.",
    "The French Academy, under Le Brun, codified rules for art, including the depiction of emotions through standardized facial expressions. Academic classicism remained influential in France until the 19th century."]]
  ],
  terms:[["French Classicism","The rational, ordered form of 17th-century French art."],["Louis XIV","The Sun King, who used art to glorify absolute monarchy."],["Poussin","The classical painter admired by the French Academy."],["Et in Arcadia Ego","Poussin's painting of shepherds discovering a tomb."],["Claude Lorrain","Painter of idealized landscapes in golden light."],["Versailles","Louis XIV's palace and gardens."],["Hall of Mirrors","The famous gallery of Versailles."]],
  w:"French Classicism and Versailles show how art could express reason, order, and absolute royal power, shaping European taste for generations.",
  src:["French Baroque","Nicolas Poussin","Et in Arcadia ego","Claude Lorrain","Georges de La Tour","Palace of Versailles","Hall of Mirrors"],
  q:[["Which king was called the Sun King?","Louis XIV","Louis XIII","Louis XV","Henry IV"],
     ["Where did Poussin spend most of his career?","Rome","Paris","Versailles","Venice"],
     ["Which painter is famous for landscapes in golden light?","Claude Lorrain","Georges de La Tour","Charles Le Brun","Hyacinthe Rigaud"],
     ["Who designed the gardens of Versailles?","André Le Nôtre","Louis Le Vau","Jules Hardouin-Mansart","Charles Le Brun"],
     ["Which painter is known for candlelit scenes?","Georges de La Tour","Poussin","Claude","Le Brun"],
     ["In what year did Louis XIV move the court to Versailles?","1682","1661","1715","1648"]]},

{ t:"Rococo", s:"Pleasure, grace, and pastel, about 1715–1780",
  sec:[
  ["A lighter style",[
    "After Louis XIV died in 1715, French aristocrats left Versailles for elegant townhouses in Paris and turned from grandeur to pleasure, intimacy, and wit. The resulting style, Rococo, from the French rocaille, the shell and rock work used in grottoes, was light, playful, and decorative, with pastel colors, curving asymmetrical forms, gilded ornament, and themes of love, flirtation, and leisure.",
    "Rococo flourished in French salons, small rooms where hostesses gathered writers and thinkers, and spread to Germany, Austria, and elsewhere."]],
  ["Watteau",[
    "Jean-Antoine Watteau (1684–1721) created a new genre, the fête galante, showing elegantly dressed couples in parklands, conversing, making music, and courting. The Academy accepted his Pilgrimage to Cythera (1717), showing couples departing from (or arriving at) the island of Venus, the goddess of love, as his reception piece and invented the category for it.",
    "Watteau's paintings have a dreamy, melancholy quality, as if pleasure were fleeting. His Pierrot (Gilles) shows a commedia dell'arte clown standing awkwardly, a figure of lonely poignancy. He died of tuberculosis at 36."]],
  ["Boucher and Fragonard",[
    "François Boucher (1703–1770), favorite painter of Madame de Pompadour, mistress of Louis XV, painted sensual mythological scenes, pastoral fantasies, and portraits in soft pinks and blues. He also designed tapestries and porcelain.",
    "Jean-Honoré Fragonard (1732–1806) painted with dazzling, quick brushwork. The Swing (1767) shows a young woman in a frothy pink dress swinging high, kicking off her slipper toward her hidden admirer in the bushes, while an older man pushes her, unaware. His series The Progress of Love was painted for Madame du Barry, who rejected it. Rococo eventually fell from favor as critics and Enlightenment thinkers called for more serious, moral art."]],
  ["Chardin and the quiet alternative",[
    "Jean-Siméon Chardin (1699–1779) painted modest still lifes and domestic genre scenes, such as Grace Before a Meal and Soap Bubbles, with quiet dignity, soft light, and subtle textures, admired for their truth and simplicity.",
    "The philosopher Denis Diderot, who wrote reviews of the Paris Salon, praised Chardin and Jean-Baptiste Greuze, whose sentimental moralizing scenes of family life suited the new taste for virtue, while criticizing Boucher's frivolity."]],
  ["Rococo architecture and decoration",[
    "In southern Germany and Austria, Rococo created some of the most dazzling church interiors in Europe, such as the pilgrimage churches of Vierzehnheiligen by Balthasar Neumann and Die Wies by Dominikus Zimmermann, with white and gold stucco, pastel frescoes, and swirling ornament creating an impression of heavenly joy.",
    "The Venetian painter Giovanni Battista Tiepolo (1696–1770) painted vast, airy ceiling frescoes, including the Würzburg Residence's staircase ceiling, showing Apollo and the four continents. Rococo also shaped furniture, porcelain from factories such as Meissen and Sèvres, and decorative arts; the fashion for chinoiserie imitated Chinese motifs."]],
  ["Venice in the 18th century",[
    "Eighteenth-century Venice attracted wealthy tourists on the Grand Tour, an educational journey through Italy undertaken by young British aristocrats. They bought vedute, detailed views of the city, by Canaletto (Giovanni Antonio Canal), whose precise, sunny scenes of the Grand Canal and Saint Mark's Square were especially popular in England, and Francesco Guardi, whose views are more atmospheric.",
    "In Rome, Giovanni Battista Piranesi made dramatic etchings of ancient ruins and imaginary prisons (Carceri), which influenced Romantic and Neoclassical artists."]]
  ],
  terms:[["Rococo","The light, playful, decorative style of the 18th century."],["Rocaille","Shell and rock ornament that gave Rococo its name."],["Fête galante","Watteau's scenes of elegant outdoor courtship."],["The Swing","Fragonard's playful Rococo painting."],["Chinoiserie","European imitation of Chinese decorative styles."],["Grand Tour","An educational journey through Italy by young aristocrats."],["Veduta","A detailed view of a city."]],
  w:"Rococo art captured the grace and pleasures of 18th-century aristocratic life before the Enlightenment and revolution called for more serious art.",
  src:["Rococo","Antoine Watteau","Pilgrimage to Cythera","François Boucher","The Swing (Fragonard)","Jean-Siméon Chardin","Canaletto"],
  q:[["What does rocaille refer to?","Shell and rock ornament","A dance","A color","A French city"],
     ["Who invented the fête galante?","Antoine Watteau","François Boucher","Jean-Honoré Fragonard","Chardin"],
     ["Who painted The Swing?","Jean-Honoré Fragonard","François Boucher","Watteau","Greuze"],
     ["Who was Boucher's famous patron?","Madame de Pompadour","Madame du Barry","Marie Antoinette","Catherine the Great"],
     ["Which painter of quiet still lifes did Diderot praise?","Chardin","Boucher","Fragonard","Watteau"],
     ["Who painted detailed views of Venice for Grand Tourists?","Canaletto","Tiepolo","Piranesi","Longhi"]]},

{ t:"Art in 18th-Century Britain", s:"Hogarth, Reynolds, Gainsborough, and the Royal Academy",
  sec:[
  ["A British school",[
    "For centuries, British patrons had imported foreign artists such as Holbein and van Dyck. In the 18th century, a distinctly British school of painting emerged, shaped by a growing commercial society, a Protestant culture wary of religious images, and a strong demand for portraits, sporting pictures, and landscapes of country estates.",
    "The Royal Academy of Arts was founded in London in 1768 under King George III, with Joshua Reynolds as its first president, to train artists and hold annual exhibitions."]],
  ["William Hogarth",[
    "William Hogarth (1697–1764) invented the satirical narrative series, which he called “modern moral subjects.” A Harlot's Progress (1732) and A Rake's Progress (1733–1735) follow characters through stages of corruption and ruin, and Marriage A-la-Mode (1743–1745) mocks a loveless marriage arranged for money and status.",
    "Hogarth sold engraved versions of his paintings to a wide public and campaigned for the Engraving Copyright Act of 1735, sometimes called Hogarth's Act, protecting artists' rights. His prints Gin Lane and Beer Street (1751) contrast the misery caused by gin with the health of beer-drinking London."]],
  ["Joshua Reynolds",[
    "Sir Joshua Reynolds (1723–1792) promoted the “Grand Manner,” elevating portraiture by borrowing poses and settings from classical sculpture and Old Masters, presenting sitters as heroes or goddesses. His Mrs. Siddons as the Tragic Muse shows the actress enthroned like a prophet from the Sistine ceiling.",
    "His Discourses, lectures delivered to Royal Academy students, argued that artists should study the great masters and pursue ideal beauty rather than copy nature, and remained influential for decades."]],
  ["Thomas Gainsborough",[
    "Thomas Gainsborough (1727–1788), Reynolds's rival, preferred painting landscapes but earned his living from portraits. His sitters appear naturally at ease, often in landscape settings, painted with light, feathery brushwork. Mr. and Mrs. Andrews (about 1750) shows a young couple beside their fields, an image of landed property.",
    "The Blue Boy (about 1770), a portrait of a young man in a satin costume echoing van Dyck, became one of the most famous paintings in Britain; its sale to the American collector Henry Huntington in 1921 caused a public outcry."]],
  ["Other genres",[
    "George Stubbs studied horse anatomy by dissecting carcasses and published The Anatomy of the Horse (1766); his painting Whistlejacket shows a rearing racehorse life-size against a plain background. Joseph Wright of Derby painted scenes of science and industry by candlelight, such as An Experiment on a Bird in the Air Pump (1768), capturing the drama of the Enlightenment.",
    "American-born painters, such as Benjamin West, who succeeded Reynolds as Royal Academy president, and John Singleton Copley, worked in London and pioneered contemporary history painting. Angelica Kauffman, a Swiss-born painter, was one of two women among the Royal Academy's founding members."]],
  ["Gardens and the picturesque",[
    "Britain's great contribution to European design was the English landscape garden, which replaced formal geometric gardens with apparently natural parks of lawns, lakes, clumps of trees, and classical temples, inspired by Claude's paintings. Lancelot “Capability” Brown designed over 170 parks, such as Blenheim, and Stourhead is a famous example.",
    "The aesthetic of the picturesque, valuing irregularity, roughness, and variety, and Edmund Burke's theory of the sublime (1757), the awe and terror inspired by vast, powerful nature, prepared the way for Romanticism."]]
  ],
  terms:[["Royal Academy","Britain's academy of art founded in 1768."],["Modern moral subjects","Hogarth's satirical narrative series."],["Grand Manner","Elevating portraits with classical and Old Master references."],["Discourses","Reynolds's lectures on art."],["English landscape garden","A naturalistic park replacing formal gardens."],["Picturesque","An aesthetic valuing irregularity and variety."],["Sublime","Awe and terror inspired by vast nature."]],
  w:"Eighteenth-century Britain created its own school of painting and the landscape garden, and its ideas of the sublime opened the way to Romanticism.",
  src:["William Hogarth","A Rake's Progress","Joshua Reynolds","Thomas Gainsborough","The Blue Boy","George Stubbs","English landscape garden"],
  q:[["Who painted A Rake's Progress?","William Hogarth","Joshua Reynolds","Thomas Gainsborough","George Stubbs"],
     ["Who was the first president of the Royal Academy?","Joshua Reynolds","Thomas Gainsborough","Benjamin West","William Hogarth"],
     ["Who painted The Blue Boy?","Thomas Gainsborough","Joshua Reynolds","Thomas Lawrence","George Romney"],
     ["Who painted Whistlejacket?","George Stubbs","Joseph Wright of Derby","Gainsborough","Reynolds"],
     ["Who painted An Experiment on a Bird in the Air Pump?","Joseph Wright of Derby","William Hogarth","Benjamin West","John Constable"],
     ["Who designed over 170 English landscape parks?","Capability Brown","Humphry Repton","William Kent","John Nash"]]}

);


/* ---- from arts-10.js ---- */
/* ARTS FOUNDATIONS, part 10: Unit 6 The Nineteenth Century, chapters 1-5 */
COURSES.arts.units.push({ t:"Revolution to Realism: 1760–1870", ch:[

{ t:"Neoclassicism", s:"Virtue, reason, and the antique",
  sec:[
  ["Return to antiquity",[
    "Neoclassicism, from about 1760 to 1830, was a reaction against the frivolity of Rococo and a revival of the art of ancient Greece and Rome. It was inspired by the Enlightenment's faith in reason and virtue and by archaeological discoveries, especially the excavations of Herculaneum (from 1738) and Pompeii (from 1748), which revealed ancient Roman life and art in astonishing detail.",
    "The German scholar Johann Joachim Winckelmann, often called the father of art history, praised Greek art for its “noble simplicity and calm grandeur” in 1755 and argued that modern artists should imitate the ancients. Neoclassical art featured clear outlines, smooth surfaces, balanced compositions, and morally elevating subjects."]],
  ["Jacques-Louis David",[
    "Jacques-Louis David (1748–1825) was the leading Neoclassical painter. His Oath of the Horatii (1784) shows three Roman brothers swearing to fight to the death for their city, arms outstretched toward swords held by their father, while the women collapse in grief, a stark lesson in patriotic self-sacrifice set in a severe Doric hall.",
    "David became a revolutionary, voting for the execution of Louis XVI. His Death of Marat (1793) presents the murdered radical journalist Jean-Paul Marat, stabbed in his bath by Charlotte Corday, as a secular martyr, echoing images of the dead Christ. David later became Napoleon's official painter, creating the heroic Napoleon Crossing the Alps and the vast Coronation of Napoleon."]],
  ["Ingres and the Academy",[
    "Jean-Auguste-Dominique Ingres (1780–1867), David's student, became the champion of line and drawing in French art. His portraits are meticulous, and his nudes, such as La Grande Odalisque (1814), have elongated, smooth bodies; critics complained the woman had too many vertebrae.",
    "Ingres led the academic establishment in opposition to the Romantics, especially Delacroix, a rivalry between line and color that echoed earlier debates."]],
  ["Neoclassical sculpture",[
    "The Italian sculptor Antonio Canova (1757–1822) carved marble with exquisite smoothness and grace. His Psyche Revived by Cupid's Kiss and his portrait of Napoleon's sister Pauline Borghese reclining as Venus Victrix, partly nude, are famous. The Danish sculptor Bertel Thorvaldsen worked in a severe classical style in Rome.",
    "Jean-Antoine Houdon made realistic portrait busts and statues of Enlightenment figures, including Voltaire, Benjamin Franklin, and George Washington, whose statue stands in the Virginia State Capitol."]],
  ["Neoclassical architecture",[
    "Neoclassical architecture revived Greek and Roman temples, columns, and domes for public buildings, symbolizing reason, democracy, and civic virtue. Examples include the Panthéon in Paris (originally the church of Sainte-Geneviève), the Brandenburg Gate in Berlin (1791), and the British Museum.",
    "In the young United States, Thomas Jefferson championed Neoclassicism as the style of the republic: he designed the Virginia State Capitol on the model of a Roman temple, his home Monticello, and the University of Virginia. The U.S. Capitol and countless courthouses, banks, and government buildings followed this style."]],
  ["Women artists of the era",[
    "Élisabeth Vigée Le Brun (1755–1842), portraitist to Marie Antoinette, painted over 600 portraits, including about 30 of the queen, with charm and warmth, and fled France during the Revolution, working successfully across Europe. Adélaïde Labille-Guiard, admitted to the Academy the same day in 1783, campaigned for more places for women.",
    "Angelica Kauffman, a founder of the Royal Academy in London, painted history subjects, rare for a woman at the time, as women were generally barred from studying the nude model essential to history painting."]]
  ],
  terms:[["Neoclassicism","The revival of Greek and Roman art from about 1760."],["Winckelmann","The scholar who praised Greek noble simplicity."],["Oath of the Horatii","David's painting of patriotic self-sacrifice."],["The Death of Marat","David's image of a revolutionary martyr."],["La Grande Odalisque","Ingres's elongated nude."],["Canova","The leading Neoclassical sculptor."],["Monticello","Jefferson's Neoclassical home."]],
  w:"Neoclassicism used the art of antiquity to express Enlightenment ideals of reason and virtue, shaping the art of revolution and the architecture of modern republics.",
  src:["Neoclassicism","Johann Joachim Winckelmann","Jacques-Louis David","Oath of the Horatii","The Death of Marat","Jean-Auguste-Dominique Ingres","Antonio Canova"],
  q:[["Which excavations inspired Neoclassicism?","Herculaneum and Pompeii","Troy and Mycenae","Knossos","Giza"],
     ["Who praised Greek art's noble simplicity and calm grandeur?","Winckelmann","Diderot","Rousseau","Goethe"],
     ["Who painted The Death of Marat?","Jacques-Louis David","Ingres","Gros","Delacroix"],
     ["Which Ingres nude was criticized for having too many vertebrae?","La Grande Odalisque","The Valpinçon Bather","The Turkish Bath","The Source"],
     ["Who sculpted Pauline Borghese as Venus?","Antonio Canova","Bertel Thorvaldsen","Jean-Antoine Houdon","Bernini"],
     ["Who painted about 30 portraits of Marie Antoinette?","Élisabeth Vigée Le Brun","Adélaïde Labille-Guiard","Angelica Kauffman","Rosalba Carriera"]]},

{ t:"Goya", s:"Court painter and witness to darkness",
  sec:[
  ["Court painter",[
    "Francisco de Goya (1746–1828) began his career designing cheerful tapestry cartoons of Spanish life for the royal factory and rose to become First Court Painter to King Charles IV in 1799. His portraits are brilliant but often unflattering.",
    "In The Family of Charles IV (1800–1801), modeled on Las Meninas, with Goya himself in the shadows at his easel, the royal family glitters in finery, but their faces appear dull and self-satisfied; one critic later said they looked like a grocer and his wife who had won the lottery. Goya also painted the famous pair The Clothed Maja and The Nude Maja, which led to his questioning by the Inquisition."]],
  ["Los Caprichos",[
    "After a severe illness in 1792–1793 left him permanently deaf, Goya's art turned darker and more personal. In 1799 he published Los Caprichos, a series of 80 etchings and aquatints satirizing superstition, ignorance, the corruption of the clergy and aristocracy, and the follies of Spanish society.",
    "The most famous plate, The Sleep of Reason Produces Monsters, shows the artist slumped over a desk while owls and bats swarm around him, a statement that reason must keep imagination's nightmares in check, an Enlightenment idea with a dark Romantic twist."]],
  ["The Third of May 1808",[
    "In 1808 Napoleon's armies occupied Spain, sparking the Peninsular War. On 2 May, the people of Madrid rose against French troops; the next day the French executed hundreds of Spaniards in reprisal. In 1814, Goya painted The Second of May 1808 and The Third of May 1808.",
    "The Third of May shows a faceless line of French soldiers aiming rifles at a group of terrified civilians, lit by a lantern. At the center, a man in a white shirt flings his arms wide in a Christ-like pose; a stigmata-like mark appears on his hand. It has been called the first great modern war painting, focusing not on heroic battle but on the slaughter of ordinary people, and it influenced Manet and Picasso's Guernica."]],
  ["The Disasters of War",[
    "Goya's series of 82 etchings, The Disasters of War (1810–1820), records atrocities committed by both French and Spanish forces: executions, mutilations, rape, and famine, with captions such as “This is worse” and “I saw it.” The prints were so unflinching that they were not published until 1863, decades after his death.",
    "The series is among the most powerful protests against war in the history of art, refusing to glorify violence."]],
  ["The Black Paintings",[
    "Late in life, disillusioned by political repression under the restored king Ferdinand VII, Goya painted 14 haunting murals directly on the walls of his house outside Madrid, the Quinta del Sordo (“House of the Deaf Man”), between 1819 and 1823. Known as the Black Paintings, they were never meant for public view.",
    "They include Saturn Devouring His Son, a terrifying image of the Titan eating one of his children, and dark scenes of witches, pilgrimages, and a dog almost submerged in sand. They were later transferred to canvas and are now in the Prado. Goya went into exile in Bordeaux, France, where he died in 1828."]],
  ["Between eras",[
    "Goya bridges the 18th and 19th centuries, the Enlightenment and Romanticism, the court artist and the independent modern artist. His freedom of brushwork, his commitment to depicting brutal truth, and his exploration of the irrational and nightmarish have led many to call him the first modern artist.",
    "His influence extended to Delacroix, Manet, the Expressionists, and the Surrealists."]]
  ],
  terms:[["Tapestry cartoon","A full-size design for a tapestry."],["Los Caprichos","Goya's satirical prints of 1799."],["The Sleep of Reason Produces Monsters","Goya's most famous Caprichos plate."],["The Third of May 1808","Goya's painting of French executions of Spanish civilians."],["The Disasters of War","Goya's etchings of wartime atrocities."],["Black Paintings","Goya's dark murals on the walls of his house."]],
  w:"Goya's unflinching vision of war, folly, and the irrational made him a bridge to modern art and one of history's most powerful witnesses to cruelty.",
  src:["Francisco Goya","Charles IV of Spain and His Family","Los Caprichos","The Sleep of Reason Produces Monsters","The Third of May 1808","The Disasters of War","Black Paintings"],
  q:[["To which king did Goya become First Court Painter?","Charles IV","Ferdinand VII","Philip IV","Charles III"],
     ["What illness affected Goya in 1792–1793?","An illness that left him deaf","Blindness","Paralysis","The plague"],
     ["Which print shows owls and bats swarming a sleeping artist?","The Sleep of Reason Produces Monsters","Saturn Devouring His Son","The Colossus","The Third of May"],
     ["What does The Third of May 1808 depict?","French soldiers executing Spanish civilians","A royal family portrait","A bullfight","A witches' sabbath"],
     ["When were The Disasters of War first published?","1863","1810","1820","1828"],
     ["Where did Goya paint the Black Paintings?","On the walls of his house","In the royal palace","In a church","In Bordeaux"]]},

{ t:"Romanticism in France", s:"Passion, imagination, and the exotic",
  sec:[
  ["The Romantic movement",[
    "Romanticism, from about 1800 to 1850, was a broad movement in art, literature, and music that rejected the Enlightenment's emphasis on reason and Neoclassicism's restraint in favor of emotion, imagination, individualism, nature, the sublime, the exotic, and the irrational. Romantics valued intense feeling, heroic struggle, the past, especially the Middle Ages, and national identity.",
    "In painting, Romantics favored dramatic subjects, dynamic compositions, rich color, and expressive brushwork, the opposite of Ingres's polished line."]],
  ["Géricault",[
    "Théodore Géricault (1791–1824) painted The Raft of the Medusa (1818–1819), a huge canvas depicting the survivors of the French naval frigate Medusa, which ran aground off West Africa in 1816. Its incompetent captain, appointed through political favor, and officers took the lifeboats, abandoning about 150 people on a makeshift raft; after nearly two weeks of starvation, madness, and cannibalism, only 15 survived.",
    "Géricault interviewed survivors, built a model of the raft, and studied corpses and the dying in hospitals. The painting arranges bodies in a pyramid rising from despair to the figure of a Black man waving a cloth at a distant rescue ship, a powerful image of suffering and hope that also implicitly criticized the government and slavery. Géricault also painted moving portraits of the insane and died at 32 after riding accidents."]],
  ["Delacroix",[
    "Eugène Delacroix (1798–1863) was the leader of French Romanticism. His Death of Sardanapalus (1827), showing an Assyrian king reclining on his bed while his concubines and horses are slaughtered around him before his palace burns, shocked critics with its violence, sensuality, and swirling color.",
    "Liberty Leading the People (1830) commemorates the July Revolution that overthrew King Charles X: a bare-breasted woman personifying Liberty, carrying the tricolor flag, leads Parisians of all classes over the barricades. It became an icon of the French Republic. A trip to Morocco in 1832 inspired paintings of North African life, and his free brushwork and vivid color theory influenced the Impressionists and Van Gogh."]],
  ["Orientalism",[
    "Many 19th-century European artists painted scenes of North Africa and the Middle East, a fashion called Orientalism, depicting harems, markets, deserts, and battles, often mixing observation with fantasy. Artists such as Jean-Léon Gérôme painted these subjects with photographic precision.",
    "In his influential 1978 book Orientalism, the scholar Edward Said argued that such imagery often presented the East as exotic, sensual, timeless, and inferior, serving European colonial attitudes, prompting critical reassessment of these works."]],
  ["Romantic sculpture and history",[
    "François Rude's relief The Departure of the Volunteers of 1792 (La Marseillaise) on the Arc de Triomphe in Paris shows a winged Liberty urging citizens to war with dramatic energy. Antoine-Louis Barye sculpted animals locked in combat.",
    "Romantic history painting turned to medieval and national subjects, and the revival of Gothic architecture, such as the Houses of Parliament in London, rebuilt from 1840, reflected the Romantic love of the Middle Ages."]],
  ["Romanticism's legacy",[
    "Romanticism transformed the idea of the artist into a passionate, misunderstood genius following inner vision rather than rules. Its emphasis on emotion, freedom, and expressive color paved the way for later movements from Impressionism to Expressionism.",
    "The rivalry between Delacroix's color and Ingres's line dominated French art in the mid-19th century, until Realism challenged both."]]
  ],
  terms:[["Romanticism","The movement valuing emotion, imagination, and nature."],["The Raft of the Medusa","Géricault's painting of shipwreck survivors."],["Liberty Leading the People","Delacroix's painting of the July Revolution."],["Orientalism","Western depictions of North Africa and the Middle East."],["Sublime","Awe-inspiring grandeur, often of nature."],["Gothic Revival","The 19th-century revival of medieval architecture."]],
  w:"French Romanticism made passion, freedom, and expressive color central to painting, transforming the image of the artist and opening the way to modern art.",
  src:["Romanticism","The Raft of the Medusa","Théodore Géricault","Eugène Delacroix","Liberty Leading the People","The Death of Sardanapalus","Orientalism (book)"],
  q:[["Who painted The Raft of the Medusa?","Théodore Géricault","Eugène Delacroix","Jacques-Louis David","Antoine-Jean Gros"],
     ["What does Liberty Leading the People commemorate?","The July Revolution of 1830","The storming of the Bastille","Napoleon's victories","The Revolution of 1848"],
     ["Which country did Delacroix visit in 1832?","Morocco","Egypt","Algeria","Turkey"],
     ["Who wrote Orientalism in 1978?","Edward Said","Michel Foucault","John Berger","Linda Nochlin"],
     ["Whose relief on the Arc de Triomphe is called La Marseillaise?","François Rude","Antoine-Louis Barye","Jean-Baptiste Carpeaux","Auguste Rodin"],
     ["Which painter was the rival of Delacroix, championing line?","Ingres","Géricault","Courbet","David"]]},

{ t:"Romantic Landscape", s:"Turner, Constable, Friedrich, and the Hudson River School",
  sec:[
  ["Nature as feeling",[
    "For Romantic artists, landscape became a primary means of expressing emotion, spirituality, and the power of nature. Influenced by ideas of the sublime and the picturesque, they painted storms, mountains, seas, and changing light, often to evoke awe, melancholy, or the presence of God.",
    "The Industrial Revolution, which was transforming the countryside, gave new urgency to images of unspoiled nature."]],
  ["J. M. W. Turner",[
    "Joseph Mallord William Turner (1775–1851), son of a London barber, entered the Royal Academy schools at 14 and became the most daring landscape painter of his age. His early works rivaled Claude, but over time his paintings dissolved into swirling light, color, and atmosphere.",
    "Snow Storm: Hannibal and His Army Crossing the Alps (1812) shows soldiers dwarfed by a vortex of storm. The Fighting Temeraire (1839) shows a heroic old warship being towed by a steam tug to be broken up, under a blazing sunset, a meditation on the passing of an age. Rain, Steam and Speed (1844) shows a train speeding across a bridge through rain. Turner reportedly had himself tied to a ship's mast during a storm to observe it. He left almost 300 paintings and 30,000 works on paper to the nation, and Britain's leading contemporary art award, the Turner Prize, is named after him."]],
  ["John Constable",[
    "John Constable (1776–1837) painted the gentle countryside of his native Suffolk, especially the Stour Valley, with fresh observation and love. He made outdoor oil sketches of clouds and weather, which he called “skying,” and his large “six-footers,” such as The Hay Wain (1821), showing a cart crossing a millstream beside a cottage, celebrate rural England.",
    "Constable's fresh greens and flecks of white paint representing light on leaves, sometimes called “Constable's snow,” were praised when The Hay Wain was exhibited at the Paris Salon of 1824, influencing French painters, including Delacroix and later the Barbizon School."]],
  ["Caspar David Friedrich",[
    "The German painter Caspar David Friedrich (1774–1840) painted landscapes charged with spiritual meaning and solitude. His figures, often seen from behind (Rückenfigur), contemplate vast, mysterious spaces, inviting viewers to share their gaze.",
    "Wanderer above the Sea of Fog (about 1818) shows a man on a rocky summit gazing over mist-shrouded peaks, an iconic image of Romanticism. The Monk by the Sea shows a tiny figure before an empty sea and sky, and The Sea of Ice depicts a shipwreck crushed by jagged ice. Forgotten after his death, Friedrich was rediscovered in the 20th century."]],
  ["The Hudson River School",[
    "In the United States, a group of painters later called the Hudson River School, founded by Thomas Cole (1801–1848), painted the American wilderness as a symbol of national identity and divine creation. Cole's The Oxbow (1836) contrasts wild forest with cultivated farmland, and his series The Course of Empire traces a civilization's rise and fall.",
    "Frederic Edwin Church painted vast, detailed panoramas such as Niagara and Heart of the Andes, and Albert Bierstadt painted the dramatic landscapes of the American West, such as Yosemite, which helped inspire the national parks movement."]],
  ["The Barbizon School",[
    "In France, painters of the Barbizon School, named after a village near the Forest of Fontainebleau, painted landscapes directly from nature in the 1830s–1860s, rejecting idealized classical landscapes. Théodore Rousseau painted forests, and Jean-François Millet painted peasants.",
    "Jean-Baptiste-Camille Corot painted silvery, poetic landscapes and fresh outdoor studies of Italy that influenced the Impressionists, and the new availability of paint in tubes made outdoor work practical."]]
  ],
  terms:[["Romantic landscape","Landscape expressing emotion and spiritual meaning."],["Turner","The English painter of light, storm, and atmosphere."],["The Hay Wain","Constable's painting of rural Suffolk."],["Rückenfigur","A figure seen from behind contemplating a scene."],["Wanderer above the Sea of Fog","Friedrich's iconic Romantic image."],["Hudson River School","American painters of wilderness landscapes."],["Barbizon School","French painters who worked directly from nature."]],
  w:"Romantic landscape painters made nature a mirror of the soul and a symbol of nations, and their study of light led directly to Impressionism.",
  src:["J. M. W. Turner","The Fighting Temeraire","John Constable","The Hay Wain","Caspar David Friedrich","Wanderer above the Sea of Fog","Hudson River School"],
  q:[["Who painted The Fighting Temeraire?","J. M. W. Turner","John Constable","Thomas Cole","Caspar David Friedrich"],
     ["Which British art prize is named after Turner?","The Turner Prize","The Stirling Prize","The Booker Prize","The Constable Award"],
     ["Who painted The Hay Wain?","John Constable","Turner","Thomas Gainsborough","Richard Wilson"],
     ["What is a figure seen from behind called in German?","Rückenfigur","Wanderjahr","Sehnsucht","Weltschmerz"],
     ["Who founded the Hudson River School?","Thomas Cole","Frederic Church","Albert Bierstadt","Asher Durand"],
     ["Near which forest did the Barbizon painters work?","Fontainebleau","Compiègne","The Ardennes","Saint-Germain"]]},

{ t:"Realism", s:"Courbet, Millet, Daumier, and painting modern life",
  sec:[
  ["Painting what is real",[
    "Realism emerged in France around 1848, the year of revolutions across Europe, as artists rejected both Neoclassical idealism and Romantic drama in favor of depicting ordinary people and everyday life truthfully, including poverty and labor. Influenced by new social and political ideas, Realists painted peasants, workers, and the urban poor on a scale previously reserved for kings and heroes.",
    "The movement was connected to the rise of photography, scientific observation, and Realist literature, such as the novels of Honoré de Balzac, Gustave Flaubert, and Émile Zola."]],
  ["Gustave Courbet",[
    "Gustave Courbet (1819–1877) declared, “Show me an angel and I will paint one,” insisting on painting only what he could see. His Stone Breakers (1849, destroyed in World War II) showed two laborers, one young and one old, at back-breaking work. A Burial at Ornans (1849–1850) depicts a village funeral on a huge canvas with life-size, unidealized townspeople, scandalizing critics who thought such subjects unworthy of history painting's scale.",
    "When his works were rejected for the 1855 Paris World's Fair, Courbet built his own Pavilion of Realism to exhibit them, an early independent exhibition. His The Painter's Studio presents an allegory of his artistic life. A socialist, he took part in the Paris Commune of 1871 and was blamed for the toppling of the Vendôme Column, leading to imprisonment and exile in Switzerland."]],
  ["Millet and rural labor",[
    "Jean-François Millet (1814–1875) of the Barbizon School painted peasants with quiet dignity and monumentality. The Gleaners (1857) shows three poor women bent over to pick up leftover grain after the harvest, with the abundant harvest of the landowner in the background; conservative critics saw it as dangerous social commentary.",
    "The Angelus (1857–1859) shows a peasant couple pausing in a field to pray at the sound of a distant church bell, and became one of the most reproduced paintings of the 19th century. The Sower inspired Van Gogh."]],
  ["Daumier",[
    "Honoré Daumier (1808–1879) was the greatest political caricaturist of his time, producing about 4,000 lithographs for satirical newspapers. A caricature of King Louis-Philippe as the gluttonous Gargantua (1831) earned him six months in prison.",
    "His painting The Third-Class Carriage (about 1862–1864) shows working-class passengers crowded on a train bench, a grandmother, a nursing mother, and a sleeping boy, with sympathetic dignity. Daumier also painted lawyers, laundresses, and Don Quixote."]],
  ["Realism beyond France",[
    "In Britain, the Pre-Raphaelite Brotherhood, founded in 1848 by Dante Gabriel Rossetti, John Everett Millais, and William Holman Hunt, rejected academic conventions and painted with intense, detailed truth to nature and bright colors, often on medieval, literary, and moral subjects, as in Millais's Ophelia (1851–1852). The critic John Ruskin championed them.",
    "In Russia, the Peredvizhniki (Wanderers), such as Ilya Repin, whose Barge Haulers on the Volga (1870–1873) shows exhausted men dragging a boat, depicted Russian life and social injustice. In the United States, Winslow Homer and Thomas Eakins, whose The Gross Clinic (1875) depicts a surgical operation in graphic detail, brought Realism to American art."]],
  ["Realism's significance",[
    "Realism challenged the hierarchy of genres and the authority of the Academy, insisting that modern, everyday life, including the lives of the poor, was a worthy subject for serious art. It linked art to social and political questions.",
    "Its demand that artists be of their own time, “il faut être de son temps,” set the stage for Manet and the Impressionists, who would paint the modern city and its leisure."]]
  ],
  terms:[["Realism","The movement depicting ordinary life truthfully, from about 1848."],["A Burial at Ornans","Courbet's huge painting of a village funeral."],["Pavilion of Realism","Courbet's independent exhibition of 1855."],["The Gleaners","Millet's painting of poor women collecting leftover grain."],["Caricature","An exaggerated satirical portrait."],["Pre-Raphaelite Brotherhood","English painters seeking truth to nature, founded 1848."],["Peredvizhniki","Russian Realist painters called the Wanderers."]],
  w:"Realism made ordinary people and modern life worthy subjects for serious art and tied painting to the social questions of its time.",
  src:["Realism (art movement)","Gustave Courbet","A Burial at Ornans","The Gleaners","Honoré Daumier","Pre-Raphaelite Brotherhood","Ilya Repin"],
  q:[["Who said Show me an angel and I will paint one?","Gustave Courbet","Jean-François Millet","Honoré Daumier","Édouard Manet"],
     ["What did Courbet build to show his rejected works in 1855?","The Pavilion of Realism","The Salon des Refusés","The Barbizon gallery","The Commune exhibition"],
     ["Who painted The Gleaners?","Jean-François Millet","Courbet","Corot","Rosa Bonheur"],
     ["Which caricaturist was jailed for depicting Louis-Philippe as Gargantua?","Honoré Daumier","Gustave Doré","Paul Gavarni","Grandville"],
     ["Who painted Ophelia in 1851–1852?","John Everett Millais","Dante Gabriel Rossetti","William Holman Hunt","Edward Burne-Jones"],
     ["Who painted Barge Haulers on the Volga?","Ilya Repin","Ivan Shishkin","Vasily Perov","Isaac Levitan"]]}

]});


/* ---- from arts-11.js ---- */
/* ARTS FOUNDATIONS, part 11: Unit 7 Impressionism and After, chapters 1-4 */
COURSES.arts.units.push({ t:"Impressionism and After: 1839–1905", ch:[

{ t:"The Invention of Photography", s:"A new way of making images",
  sec:[
  ["The camera obscura and fixing images",[
    "The camera obscura, a darkened box or room in which light passing through a small opening projects an image of the outside world, had been known since antiquity and used by artists as a drawing aid. The challenge was to fix that image permanently using light-sensitive chemicals.",
    "Around 1826–1827, the Frenchman Nicéphore Niépce made the oldest surviving photograph, View from the Window at Le Gras, on a pewter plate coated with bitumen, requiring an exposure of many hours, perhaps days."]],
  ["The daguerreotype",[
    "Niépce's partner Louis Daguerre developed the daguerreotype, publicly announced in 1839, the conventional birth year of photography. It produced a unique, highly detailed image on a silvered copper plate, with exposures of minutes, later seconds. The French government bought the rights and gave the process to the world.",
    "Daguerreotypes became wildly popular for portraits; studios opened in cities everywhere. Because each image was unique and mirror-reversed, it could not be copied. Daguerre's 1838 view of the Boulevard du Temple in Paris includes the first known photograph of a person, a man having his shoes shined who stood still long enough to be recorded."]],
  ["Talbot and the negative",[
    "In England, William Henry Fox Talbot invented the calotype, patented in 1841, which produced a paper negative from which many positive prints could be made, the basis of photography for over 150 years. His book The Pencil of Nature (1844–1846) was the first commercially published book illustrated with photographs.",
    "In the 1850s the wet collodion process, using glass plates, combined sharp detail with reproducibility and shorter exposures. It was used to photograph wars, landscapes, and people across the world."]],
  ["Photography as document",[
    "Photographers documented war: Roger Fenton in the Crimean War (1855) and Mathew Brady's team, including Alexander Gardner and Timothy O'Sullivan, in the American Civil War, whose images of the dead at Antietam and Gettysburg shocked the public. Photographers recorded landscapes of the American West, such as Carleton Watkins's views of Yosemite, which helped persuade Congress to protect it.",
    "Eadweard Muybridge's sequential photographs of a galloping horse in 1878 proved that all four hooves leave the ground at once, overturning centuries of painted conventions, and his motion studies paved the way for cinema."]],
  ["Photography as art",[
    "Early photographers debated whether photography was art or merely a mechanical record. Julia Margaret Cameron made soft-focus, expressive portraits of Victorian figures such as Alfred Tennyson and Charles Darwin. Nadar, in Paris, photographed the celebrities of his day and lent his studio for the first Impressionist exhibition in 1874.",
    "Around 1900, Pictorialists such as Alfred Stieglitz and Edward Steichen manipulated prints to resemble paintings. Stieglitz then championed “straight” photography, and his gallery 291 in New York promoted both photography and modern art."]],
  ["Photography's effect on painting",[
    "When he first saw a daguerreotype, the painter Paul Delaroche is said to have exclaimed, “From today, painting is dead!” Photography took over many of painting's documentary functions, especially portraiture, and pushed painters to explore what photography could not do: color, subjective vision, and expressive brushwork.",
    "At the same time, painters used photographs as aids and learned from them: the cropped compositions, unusual viewpoints, and frozen moments of photography influenced Degas and others. The relationship between painting and photography has shaped art ever since."]]
  ],
  terms:[["Camera obscura","A dark box or room projecting an outside image."],["Daguerreotype","An early unique photograph on a silvered plate, announced in 1839."],["Calotype","Talbot's negative-positive paper process."],["Wet collodion","A glass-plate process of the 1850s."],["Motion studies","Muybridge's sequential photographs of movement."],["Pictorialism","Photography imitating painting around 1900."]],
  w:"Photography transformed how people saw and recorded the world and forced painting to redefine its purpose, shaping all modern art.",
  src:["History of photography","View from the Window at Le Gras","Daguerreotype","Henry Fox Talbot","Mathew Brady","Eadweard Muybridge","Julia Margaret Cameron"],
  q:[["Who made the oldest surviving photograph?","Nicéphore Niépce","Louis Daguerre","Henry Fox Talbot","Nadar"],
     ["In what year was the daguerreotype announced?","1839","1826","1851","1878"],
     ["Who invented the calotype negative process?","William Henry Fox Talbot","Louis Daguerre","Frederick Scott Archer","George Eastman"],
     ["Who photographed a galloping horse in sequence in 1878?","Eadweard Muybridge","Mathew Brady","Carleton Watkins","Étienne-Jules Marey"],
     ["In whose studio was the first Impressionist exhibition held?","Nadar's","Daguerre's","Courbet's","Durand-Ruel's"],
     ["Who said From today, painting is dead?","Paul Delaroche","Ingres","Delacroix","Baudelaire"]]},

{ t:"Manet and the Painting of Modern Life", s:"Scandal and the birth of modern painting",
  sec:[
  ["Paris transformed",[
    "In the 1850s and 1860s, under Emperor Napoleon III, Baron Georges-Eugène Haussmann rebuilt Paris with broad boulevards, parks, cafés, and new apartment buildings, creating the modern city of crowds, leisure, and spectacle. The poet Charles Baudelaire, in The Painter of Modern Life (1863), called on artists to capture the fleeting beauty of contemporary urban life rather than ancient subjects.",
    "Édouard Manet (1832–1883), a wealthy Parisian, answered that call, painting modern subjects with a radically flat, direct technique that many consider the beginning of modern painting."]],
  ["The Salon des Refusés",[
    "In 1863 the official Salon jury rejected about 3,000 works, provoking such protest that Napoleon III ordered an exhibition of rejected works, the Salon des Refusés. Its sensation was Manet's Le Déjeuner sur l'herbe (Luncheon on the Grass), showing a nude woman picnicking with two fully clothed young men in a park, while another woman bathes behind.",
    "Though its composition was borrowed from Renaissance sources, including an engraving after Raphael and Titian's Pastoral Concert, viewers were outraged that the nude was not a goddess but a contemporary woman, who looks frankly out at the viewer, and by the flat, sketchy painting."]],
  ["Olympia",[
    "Olympia (painted 1863, shown at the 1865 Salon) caused an even greater scandal. Based on Titian's Venus of Urbino, it shows a nude courtesan reclining on a bed, gazing coolly at the viewer, while a Black maid brings flowers from a client and a black cat arches its back at her feet. The model, Victorine Meurent, also posed for Le Déjeuner.",
    "Critics were scandalized by the painting's frank reference to prostitution and its harsh, flat lighting, which abandoned traditional modeling. Guards had to protect it from angry visitors. Today it is in the Musée d'Orsay and is considered a cornerstone of modern art; scholars have also examined the role of the maid, modeled by a woman named Laure."]],
  ["Manet's style",[
    "Manet admired Velázquez, Goya, and Frans Hals, and his paintings use bold contrasts of light and dark with little middle tone, flattened forms, visible brushstrokes, and black used as a color. He painted Parisians in cafés, at the races, in the street, and at concerts, as in Music in the Tuileries.",
    "His The Execution of Emperor Maximilian, based on Goya's Third of May, depicted a contemporary political event, and the French government banned its exhibition."]],
  ["A Bar at the Folies-Bergère",[
    "Manet's last major painting, A Bar at the Folies-Bergère (1882), shows a barmaid behind a marble counter loaded with bottles and fruit at a fashionable Paris music hall. Behind her, a mirror reflects the glittering crowd and a man who seems to be speaking to her, but the reflection does not line up with what we see in front, creating an unsettling puzzle.",
    "The barmaid's detached, melancholy expression amid the spectacle has been read as a comment on modern alienation and commercialized relationships."]],
  ["Manet's legacy",[
    "Manet never exhibited with the Impressionists, preferring to seek success at the official Salon, but he was their friend and inspiration, and in later years adopted their lighter palette and outdoor painting. Younger painters gathered around him at the Café Guerbois.",
    "Manet's flatness, emphasis on the painted surface, and frank modern subjects led the critic Clement Greenberg and others to see him as the first modernist painter."]]
  ],
  terms:[["Haussmannization","The rebuilding of Paris with broad boulevards."],["Painter of modern life","Baudelaire's ideal of an artist of contemporary life."],["Salon des Refusés","The 1863 exhibition of works rejected by the Salon."],["Le Déjeuner sur l'herbe","Manet's scandalous picnic painting."],["Olympia","Manet's painting of a modern courtesan."],["Flatness","Emphasis on the flat painted surface rather than illusion."]],
  w:"Manet broke with academic tradition by painting modern life with a frank, flat style, and is widely regarded as the first modern painter.",
  src:["Édouard Manet","Haussmann's renovation of Paris","Salon des Refusés","Le Déjeuner sur l'herbe","Olympia (Manet)","A Bar at the Folies-Bergère","The Painter of Modern Life"],
  q:[["Who rebuilt Paris with broad boulevards?","Baron Haussmann","Napoleon I","Gustave Eiffel","Charles Garnier"],
     ["Who wrote The Painter of Modern Life?","Charles Baudelaire","Émile Zola","Gustave Flaubert","Stéphane Mallarmé"],
     ["In which exhibition was Le Déjeuner sur l'herbe shown?","The Salon des Refusés","The first Impressionist exhibition","The 1855 World's Fair","The official Salon"],
     ["Which painting is Olympia based on?","Titian's Venus of Urbino","Giorgione's Sleeping Venus","Ingres's Grande Odalisque","Goya's Nude Maja"],
     ["Who modeled for Olympia and Le Déjeuner?","Victorine Meurent","Berthe Morisot","Suzanne Valadon","Méry Laurent"],
     ["What is Manet's last major painting?","A Bar at the Folies-Bergère","Olympia","The Railway","Music in the Tuileries"]]},

{ t:"Impressionism", s:"Light, color, and the fleeting moment",
  sec:[
  ["The first exhibition",[
    "In 1874 a group of artists frustrated by repeated Salon rejections formed a cooperative society and held their own exhibition in the former studio of the photographer Nadar in Paris. Among the 30 participants were Claude Monet, Pierre-Auguste Renoir, Edgar Degas, Camille Pissarro, Alfred Sisley, Paul Cézanne, and Berthe Morisot.",
    "Monet showed a painting of the harbor of Le Havre at dawn, Impression, Sunrise (1872). The critic Louis Leroy mockingly titled his review “Exhibition of the Impressionists,” and the name stuck. The group held eight exhibitions between 1874 and 1886."]],
  ["Aims and methods",[
    "The Impressionists sought to capture the fleeting effects of light and atmosphere at a particular moment, and the sensations of modern life. They often painted outdoors (en plein air), working quickly to record changing conditions, made possible by portable easels and paint in tubes.",
    "They used short, broken brushstrokes of bright, unmixed color placed side by side, rather than smooth blending; avoided black, depicting shadows with colors such as blue and violet; worked on light-toned grounds; and left their paintings looking sketch-like, which critics saw as unfinished. Their subjects were landscapes, rivers, gardens, Parisian boulevards, cafés, train stations, and middle-class leisure."]],
  ["Claude Monet",[
    "Claude Monet (1840–1926) was the most consistent Impressionist, devoting his long life to painting light. He painted series of the same subject under different light and weather conditions: Haystacks (1890–1891), Rouen Cathedral (1892–1894), whose facade he painted over 30 times, and the Houses of Parliament in London.",
    "From 1883 he lived at Giverny, where he created a garden with a water-lily pond and a Japanese bridge, which he painted about 250 times. His huge Water Lilies (Nymphéas) murals, installed in the Musée de l'Orangerie in Paris in 1927, immerse viewers in reflections and color and anticipated abstract painting. Cataracts affected his vision in his last years."]],
  ["Renoir, Pissarro, and Sisley",[
    "Pierre-Auguste Renoir (1841–1919) loved painting people enjoying themselves. Bal du moulin de la Galette (1876) shows Parisians dancing and chatting in an open-air dance garden, with dappled sunlight filtering through trees. Luncheon of the Boating Party (1880–1881) shows his friends on a restaurant terrace by the Seine. He later turned to a more classical style and voluptuous nudes.",
    "Camille Pissarro (1830–1903), the oldest of the group and the only one to show at all eight exhibitions, painted rural scenes and later views of Paris boulevards from hotel windows. He was a generous mentor to Cézanne and Gauguin. Alfred Sisley, of English parents, painted quiet landscapes along the Seine."]],
  ["Reception and success",[
    "The Impressionists were at first ridiculed, and many lived in poverty. The dealer Paul Durand-Ruel supported them, buying their works and organizing exhibitions, including a successful show in New York in 1886 that found American buyers.",
    "By the 1890s, Impressionism had won acceptance, and the painters' prices rose. Today they are among the most beloved and expensive artists in the world, and the Musée d'Orsay in Paris holds the largest collection."]],
  ["Impressionism's influence",[
    "Impressionism liberated painting from academic rules, emphasizing the artist's perception, the act of painting, and the visible brushstroke. It spread internationally: American Impressionists such as Childe Hassam, and painters in Britain, Scandinavia, Australia, and elsewhere adopted its methods.",
    "It also provoked reactions, as younger artists, the Post-Impressionists, sought to give painting more structure, meaning, or emotion."]]
  ],
  terms:[["Impressionism","The movement capturing light and fleeting moments, named in 1874."],["Impression, Sunrise","Monet's painting that gave the movement its name."],["En plein air","Painting outdoors."],["Broken color","Short strokes of unmixed color placed side by side."],["Series painting","Painting the same subject under different conditions."],["Water Lilies","Monet's late paintings of his pond at Giverny."],["Durand-Ruel","The dealer who championed the Impressionists."]],
  w:"Impressionism transformed painting by capturing light, color, and modern life in a fresh, spontaneous way, opening the door to modern art.",
  src:["Impressionism","Impression, Sunrise","Claude Monet","Water Lilies (Monet series)","Pierre-Auguste Renoir","Camille Pissarro","Paul Durand-Ruel"],
  q:[["In what year was the first Impressionist exhibition?","1874","1863","1886","1855"],
     ["Which painting gave Impressionism its name?","Impression, Sunrise","Le Déjeuner sur l'herbe","Water Lilies","Bal du moulin de la Galette"],
     ["How many times did Monet paint Rouen Cathedral's facade?","Over 30","About 5","About 100","Twice"],
     ["Where did Monet create his water-lily garden?","Giverny","Argenteuil","Barbizon","Pontoise"],
     ["Who painted Luncheon of the Boating Party?","Renoir","Monet","Degas","Sisley"],
     ["Which Impressionist showed at all eight exhibitions?","Camille Pissarro","Claude Monet","Edgar Degas","Renoir"]]},

{ t:"Degas, Morisot, Cassatt, and Modern Life", s:"Figures, women artists, and Japonisme",
  sec:[
  ["Edgar Degas",[
    "Edgar Degas (1834–1917) exhibited with the Impressionists but preferred to call himself a Realist or Independent. Trained in the academic tradition and an admirer of Ingres, he valued drawing and worked in the studio from memory and sketches rather than outdoors.",
    "His subjects were modern Parisian life: ballet dancers rehearsing and resting, racehorses, laundresses, milliners, café scenes, and women bathing, often seen from unusual angles. Inspired by photography and Japanese prints, he used off-center compositions, high viewpoints, and dramatic cropping, as in The Dance Class and L'Absinthe, showing two lonely figures in a café."]],
  ["Degas's media",[
    "Degas was a master of pastel, using it in vivid layers, often combined with other media, and an innovative printmaker. Late in life, as his eyesight failed, he turned more to sculpture.",
    "His wax sculpture Little Dancer Aged Fourteen, shown in 1881, dressed in a real tutu, bodice, and hair ribbon, shocked viewers with its realism; after his death it was cast in bronze. Degas's ballet scenes have been reconsidered in light of the hard lives of young dancers, many from poor families."]],
  ["Berthe Morisot",[
    "Berthe Morisot (1841–1895) was a founding member of the Impressionist group and exhibited in seven of their eight exhibitions. Women in her time could not attend the École des Beaux-Arts or freely paint in cafés and on the boulevards, so she painted the spaces open to her: domestic interiors, gardens, and women and children.",
    "Her paintings, such as The Cradle (1872), showing her sister watching over her sleeping baby, are marked by feathery, sketch-like brushwork and luminous whites. She married Manet's brother Eugène, and Manet painted her portrait several times."]],
  ["Mary Cassatt",[
    "Mary Cassatt (1844–1926), an American from Pennsylvania, settled in Paris and was invited by Degas to exhibit with the Impressionists in 1879. She is best known for tender images of mothers and children, such as The Child's Bath (1893), which avoid sentimentality through strong design.",
    "Inspired by an 1890 exhibition of Japanese prints, she made a series of ten color prints combining drypoint and aquatint with flat areas of color. Cassatt advised American collectors such as Louisa Havemeyer, helping bring Impressionist works to American museums."]],
  ["Japonisme",[
    "After Japan opened to Western trade in the 1850s, Japanese art, especially ukiyo-e woodblock prints, flooded into Europe, appearing in shops and international exhibitions. The fashion, called Japonisme, profoundly influenced Western artists.",
    "Japanese prints offered flat areas of bold color, strong outlines, asymmetrical compositions, high viewpoints, everyday subjects, and cropping. Monet filled his house with prints and built a Japanese bridge; Van Gogh copied prints by Hiroshige; Whistler, Toulouse-Lautrec, and the Nabis absorbed their lessons."]],
  ["Toulouse-Lautrec and Whistler",[
    "Henri de Toulouse-Lautrec (1864–1901), from an aristocratic family, his growth stunted by a genetic condition and childhood injuries, chronicled the nightlife of Montmartre: the cabarets, dance halls, brothels, and performers such as the dancer La Goulue and the singer Aristide Bruant. His posters for the Moulin Rouge, with flat colors and bold design, helped create modern graphic art.",
    "The American painter James McNeill Whistler, working in London, pursued “art for art's sake,” titling paintings like music, such as Arrangement in Grey and Black No. 1, known as Whistler's Mother. When the critic John Ruskin accused him of “flinging a pot of paint in the public's face” over his Nocturne in Black and Gold: The Falling Rocket, Whistler sued for libel in 1878 and won a farthing in damages."]]
  ],
  terms:[["Degas","Painter of dancers and modern life with unusual compositions."],["Pastel","Sticks of powdered pigment used for drawing in color."],["Little Dancer Aged Fourteen","Degas's sculpture with a real tutu."],["Berthe Morisot","A founding woman member of the Impressionists."],["Mary Cassatt","An American Impressionist known for mothers and children."],["Japonisme","The influence of Japanese art in the West."],["Art for art's sake","The idea that art needs no moral purpose."]],
  w:"Degas, Morisot, Cassatt, and their contemporaries widened modern art's view of city life and private life, shaped by photography and Japanese prints.",
  src:["Edgar Degas","Little Dancer of Fourteen Years","Berthe Morisot","Mary Cassatt","Japonisme","Henri de Toulouse-Lautrec","Whistler v Ruskin"],
  q:[["Which subject did Degas paint most famously?","Ballet dancers","Water lilies","Haystacks","Mountains"],
     ["What did Degas's Little Dancer wear?","A real tutu and ribbon","Nothing","A painted dress","Armor"],
     ["Who painted The Cradle?","Berthe Morisot","Mary Cassatt","Eva Gonzalès","Marie Bracquemond"],
     ["Which American painter was invited by Degas to exhibit?","Mary Cassatt","Whistler","John Singer Sargent","Childe Hassam"],
     ["Whose posters for the Moulin Rouge helped create modern graphic art?","Toulouse-Lautrec","Degas","Manet","Mucha"],
     ["What did Whistler win in his libel case against Ruskin?","A farthing","A thousand pounds","Nothing","An apology only"]]}

]});


/* ---- from arts-12.js ---- */
/* ARTS FOUNDATIONS, part 12: Unit 7 chapters 5-8 */
COURSES.arts.units[6].ch.push(

{ t:"Cézanne and Seurat", s:"Structure and science after Impressionism",
  sec:[
  ["Post-Impressionism",[
    "Post-Impressionism is a term coined by the English critic Roger Fry for a 1910 exhibition in London. It describes artists of the 1880s and 1890s, Cézanne, Seurat, Van Gogh, Gauguin, and others, who built on Impressionism's bright color and modern subjects but rejected its focus on fleeting appearance.",
    "Each went in a different direction: toward structure and solidity, scientific color, emotional expression, or symbolism. Together they laid the foundations of 20th-century modern art."]],
  ["Paul Cézanne",[
    "Paul Cézanne (1839–1906), from Aix-en-Provence, exhibited with the Impressionists but wanted, he said, “to make of Impressionism something solid and durable, like the art of the museums.” Working slowly and deliberately, he analyzed nature into its underlying geometric structure, telling a young painter to “treat nature by means of the cylinder, the sphere, the cone.”",
    "He built forms with patches of color applied in parallel, constructive brushstrokes, modeling with color rather than light and shade. He abandoned single-point perspective, combining multiple viewpoints so that tabletops tilt and objects seem seen from different angles at once, as in his still lifes of apples."]],
  ["Mont Sainte-Victoire and Card Players",[
    "Cézanne painted the limestone mountain Mont Sainte-Victoire, near his home, over 60 times in oils and watercolors, turning it into an architecture of colored planes that grow increasingly abstract in his late works. His series of Card Players shows Provençal peasants absorbed in their game with monumental stillness; one version sold privately in 2011 for a reported 250 million dollars or more.",
    "His late Large Bathers, with figures integrated into a triangular landscape, influenced Picasso and Matisse. Long ridiculed, Cézanne had his first solo exhibition in 1895 with the dealer Ambroise Vollard. After his death, a retrospective in 1907 had a decisive impact on the Cubists; both Picasso and Matisse reportedly called him “the father of us all.”"]],
  ["Georges Seurat",[
    "Georges Seurat (1859–1891) sought to make Impressionism scientific. Studying color theories by Chevreul and the American physicist Ogden Rood, he developed pointillism (or divisionism), applying small dots of pure color side by side so that they would mix optically in the viewer's eye, producing more luminous color than mixed paint.",
    "His masterpiece, A Sunday Afternoon on the Island of La Grande Jatte (1884–1886), in the Art Institute of Chicago, shows Parisians relaxing by the Seine, rendered in countless dots, with stiff, frozen figures arranged with geometric precision, giving the scene a strange, timeless stillness. It took him about two years. Seurat died suddenly at 31."]],
  ["Neo-Impressionism",[
    "Seurat's followers, including Paul Signac, who wrote a treatise on the method, formed the Neo-Impressionist movement. Pissarro briefly adopted pointillism, and its ideas influenced Van Gogh, Matisse, and the Fauves.",
    "Seurat also explored the emotional effects of line and color, believing upward lines and warm colors expressed joy and downward lines and cool colors sadness, ideas he applied in works such as Le Chahut and The Circus."]],
  ["Cézanne's revolution",[
    "Cézanne's emphasis on the painting as a constructed object, with its own logic of color and form rather than a window onto the world, was perhaps the most important single influence on modern art. His multiple viewpoints led directly to Cubism, and his reduction of nature to geometric forms anticipated abstraction.",
    "Seurat's systematic approach to color and composition likewise showed that painting could be built on principles rather than on imitation alone."]]
  ],
  terms:[["Post-Impressionism","Artists of the 1880s–1890s who moved beyond Impressionism."],["Constructive brushstroke","Cézanne's parallel strokes building form."],["Multiple viewpoints","Showing objects from several angles at once."],["Mont Sainte-Victoire","The mountain Cézanne painted over 60 times."],["Pointillism","Painting with dots of pure color that mix optically."],["A Sunday Afternoon on La Grande Jatte","Seurat's pointillist masterpiece."]],
  w:"Cézanne and Seurat gave painting new structure and system, and Cézanne's analysis of form became the foundation of Cubism and abstraction.",
  src:["Post-Impressionism","Paul Cézanne","Mont Sainte-Victoire (Cézanne)","The Card Players","Georges Seurat","A Sunday Afternoon on the Island of La Grande Jatte","Neo-impressionism"],
  q:[["Who coined the term Post-Impressionism?","Roger Fry","Clement Greenberg","Louis Leroy","Charles Baudelaire"],
     ["Who said to treat nature by the cylinder, sphere, and cone?","Paul Cézanne","Georges Seurat","Pablo Picasso","Paul Gauguin"],
     ["Which mountain did Cézanne paint over 60 times?","Mont Sainte-Victoire","Mont Blanc","Mount Fuji","Montmartre"],
     ["What is Seurat's technique of dots called?","Pointillism","Impasto","Cloisonnism","Sfumato"],
     ["Where is A Sunday Afternoon on La Grande Jatte?","The Art Institute of Chicago","The Musée d'Orsay","MoMA","The National Gallery"],
     ["Who was called the father of us all by Picasso and Matisse?","Cézanne","Manet","Seurat","Gauguin"]]},

{ t:"Vincent van Gogh", s:"Color, emotion, and a short life",
  sec:[
  ["A late start",[
    "Vincent van Gogh (1853–1890), son of a Dutch Protestant minister, worked as an art dealer, teacher, and lay preacher among coal miners in Belgium before deciding at 27 to become an artist. His career lasted only about ten years, during which he made around 860 oil paintings and over 1,200 drawings and watercolors, sold very few during his lifetime, and was supported financially by his devoted younger brother Theo, an art dealer in Paris.",
    "His more than 800 letters, most to Theo, are a remarkable record of his thoughts about art and life."]],
  ["The Dutch years",[
    "Van Gogh's early works, painted in the Netherlands, used dark earthy colors to depict peasants and laborers, inspired by Millet. The Potato Eaters (1885) shows a peasant family eating their simple meal by lamplight, with coarse faces and hands that, he wrote, had “dug the earth.”",
    "He intended to show the honest dignity of manual labor, and he considered it one of his most important works."]],
  ["Paris and color",[
    "In 1886 Van Gogh moved to Paris to live with Theo, where he encountered Impressionism, Neo-Impressionism, and Japanese prints. His palette brightened dramatically, and he adopted short, broken brushstrokes. He made dozens of self-portraits, partly because he could not afford models, and copied prints by Hiroshige.",
    "He met Toulouse-Lautrec, Gauguin, Pissarro, Signac, and Bernard, and dreamed of founding an artists' community."]],
  ["Arles",[
    "In February 1888 Van Gogh moved to Arles in the south of France, seeking bright light and color like that of Japan. In an intense burst of creativity, he painted orchards in blossom, wheatfields, The Night Café, Café Terrace at Night, his bedroom, and a series of Sunflowers to decorate a room for Gauguin. His color became expressive rather than descriptive; in The Night Café, he wrote, he tried “to express the terrible passions of humanity by means of red and green.”",
    "Gauguin joined him in October 1888, but their relationship was stormy. On 23 December, after a quarrel, Van Gogh, in a mental crisis, cut off part or all of his left ear. He was hospitalized and suffered recurring attacks thereafter."]],
  ["Saint-Rémy and The Starry Night",[
    "In May 1889 Van Gogh voluntarily entered an asylum at Saint-Rémy-de-Provence, where between attacks he painted irises, olive groves, cypresses, and the view from his window. The Starry Night (June 1889), now at MoMA in New York, shows a swirling, turbulent night sky with blazing stars and a crescent moon over a quiet village, with a flame-like cypress rising in the foreground; it became one of the most famous paintings in the world.",
    "His thick, rhythmic, energetic brushstrokes and intense, expressive color conveyed emotion and spiritual feeling."]],
  ["Auvers and legacy",[
    "In May 1890 Van Gogh moved to Auvers-sur-Oise near Paris, under the care of Dr. Paul Gachet, whose portrait he painted, and produced about 70 paintings in about 70 days, including Wheatfield with Crows. On 27 July 1890 he shot himself in the chest and died two days later, aged 37; Theo died six months later.",
    "Theo's widow, Johanna van Gogh-Bonger, worked tirelessly to promote Vincent's art and publish his letters, and within two decades he had become one of the most celebrated artists in history. His expressive use of color and brushwork influenced Fauvism and Expressionism. The Van Gogh Museum in Amsterdam holds the largest collection of his work."]]
  ],
  terms:[["Theo van Gogh","Vincent's brother and supporter."],["The Potato Eaters","Van Gogh's early painting of a peasant family."],["Expressive color","Color used to convey emotion rather than describe reality."],["Sunflowers","Van Gogh's series painted in Arles."],["The Starry Night","Van Gogh's swirling night sky, painted at Saint-Rémy."],["Johanna van Gogh-Bonger","Theo's widow, who promoted Vincent's art."]],
  w:"Van Gogh used color and brushwork to express emotion, and his art and life became one of the most influential stories in modern art.",
  src:["Vincent van Gogh","The Potato Eaters","Sunflowers (Van Gogh series)","The Starry Night","The Night Café","Theo van Gogh (art dealer)","Johanna van Gogh-Bonger"],
  q:[["At about what age did Van Gogh decide to become an artist?","27","17","35","40"],
     ["Who supported Van Gogh financially?","His brother Theo","Paul Gauguin","Dr. Gachet","His father"],
     ["Which early painting shows a peasant family at a meal?","The Potato Eaters","The Night Café","The Bedroom","Sunflowers"],
     ["Where did Van Gogh paint Sunflowers and The Night Café?","Arles","Paris","Saint-Rémy","Auvers"],
     ["Where is The Starry Night?","MoMA, New York","The Van Gogh Museum","The Musée d'Orsay","The Kröller-Müller Museum"],
     ["Who promoted Van Gogh's art after his death?","Johanna van Gogh-Bonger","Paul Gauguin","Émile Bernard","Dr. Gachet"]]},

{ t:"Gauguin and Symbolism", s:"Dreams, myth, and the search for meaning",
  sec:[
  ["Paul Gauguin",[
    "Paul Gauguin (1848–1903) was a successful stockbroker and amateur painter until a financial crash in 1882 led him to devote himself to art, eventually abandoning his family. He sought a primal, spiritual authenticity he believed European civilization had lost, first in Brittany, where at Pont-Aven he and Émile Bernard developed Synthetism, using flat areas of bold color outlined in dark contours.",
    "His Vision after the Sermon (1888) shows Breton women in white caps beholding Jacob wrestling the angel on a field of pure red, mixing the real and the imagined."]],
  ["Tahiti",[
    "In 1891 Gauguin sailed to Tahiti, then a French colony, hoping to find an unspoiled paradise, though he found it already changed by colonialism. He painted Tahitian women and landscapes in rich, non-naturalistic colors and simplified forms, blending Polynesian, Christian, and other imagery.",
    "His largest painting, Where Do We Come From? What Are We? Where Are We Going? (1897–1898), in Boston, is a panoramic meditation on life from birth to death. He died in the Marquesas Islands in 1903."]],
  ["Reassessing Gauguin",[
    "Gauguin's use of flat color and his interest in non-Western art strongly influenced Picasso, Matisse, the Fauves, and the Expressionists. But he is also a controversial figure: in Tahiti he took girls as young as 13 as “wives” and his work reflects colonial and exoticizing fantasies.",
    "Recent exhibitions and scholarship have examined these issues critically, raising questions about how to view the art of artists whose lives involved exploitation."]],
  ["Symbolism",[
    "Symbolism, a movement in literature and art of the 1880s and 1890s, rejected realism and the observation of the visible world in favor of dreams, imagination, myth, mysticism, and the inner life. Symbolist artists used suggestive images to evoke ideas and emotions rather than describe reality.",
    "Gustave Moreau painted jewel-like mythological and biblical scenes such as The Apparition, showing Salome confronting the floating head of John the Baptist. Odilon Redon made dreamlike charcoal “noirs,” such as an eye rising like a balloon, and later radiant pastels of flowers. Pierre Puvis de Chavannes painted serene, pale murals."]],
  ["Symbolism across Europe",[
    "The Norwegian Edvard Munch (1863–1944) painted anxiety, love, jealousy, illness, and death. The Scream (1893), a figure clutching its face on a bridge under a blood-red sky, became a universal image of modern anxiety; he made several versions in paint, pastel, and lithograph.",
    "In Vienna, Gustav Klimt (1862–1918), a founder of the Vienna Secession in 1897, painted sensuous, decorative works with gold leaf, such as The Kiss (1907–1908), and portraits like Adele Bloch-Bauer I, looted by the Nazis and returned to her heirs in 2006. The Belgian James Ensor painted crowds of grotesque masks, and the Swiss Arnold Böcklin painted the haunting Isle of the Dead."]],
  ["The Nabis",[
    "A group of young French painters influenced by Gauguin called themselves the Nabis, Hebrew for “prophets.” One, Maurice Denis, wrote in 1890: “Remember that a picture, before being a battle horse, a nude woman, or some anecdote, is essentially a flat surface covered with colors assembled in a certain order,” a statement often seen as a manifesto of modern art.",
    "Pierre Bonnard and Édouard Vuillard, also Nabis, painted intimate domestic interiors and gardens with rich, patterned color."]]
  ],
  terms:[["Synthetism","Gauguin and Bernard's style of flat color and dark outlines."],["Primitivism","Western artists' borrowing from art they considered primitive."],["Symbolism","The movement expressing dreams, myth, and inner life."],["The Scream","Munch's image of modern anxiety."],["Vienna Secession","An Austrian art movement founded in 1897."],["The Kiss","Klimt's golden painting of lovers."],["The Nabis","French painters influenced by Gauguin."]],
  w:"Gauguin and the Symbolists turned art inward toward dreams, emotions, and myth, paving the way for Expressionism and abstraction.",
  src:["Paul Gauguin","Where Do We Come From? What Are We? Where Are We Going?","Symbolism (arts)","Odilon Redon","The Scream","Gustav Klimt","Les Nabis"],
  q:[["Where did Gauguin develop Synthetism?","Pont-Aven in Brittany","Arles","Tahiti","Paris"],
     ["Where did Gauguin die?","The Marquesas Islands","Tahiti","Paris","Brittany"],
     ["Who painted The Scream?","Edvard Munch","Gustav Klimt","James Ensor","Odilon Redon"],
     ["Which Klimt painting is covered in gold leaf?","The Kiss","The Scream","The Apparition","Isle of the Dead"],
     ["Who painted The Apparition with Salome?","Gustave Moreau","Odilon Redon","Puvis de Chavannes","Arnold Böcklin"],
     ["What does Nabis mean?","Prophets","Rebels","Painters","Dreamers"]]},

{ t:"Rodin and Art Nouveau", s:"Sculpture and design at the turn of the century",
  sec:[
  ["Auguste Rodin",[
    "Auguste Rodin (1840–1917) revitalized sculpture, which had become rigid and academic. His figures convey intense emotion and inner life through dynamic, rough-textured surfaces that catch the light, showing the marks of his hands in clay. His first major work, The Age of Bronze (1877), was so lifelike that critics accused him of casting it from a living model.",
    "Rodin often used fragments, a torso, a hand, a figure without arms, as complete works, and left parts of marble rough, an idea borrowed from Michelangelo's unfinished sculptures."]],
  ["The Gates of Hell",[
    "In 1880 Rodin was commissioned to make a doorway for a planned museum of decorative arts in Paris. He worked on The Gates of Hell, inspired by Dante's Inferno, for the rest of his life; it was cast in bronze only after his death. Its surface swarms with about 180 tormented figures.",
    "Many of Rodin's most famous sculptures began as figures for the Gates. The Thinker, originally representing Dante contemplating his poem, sits above the doors; enlarged as an independent work, it became one of the most recognized sculptures in the world. The Kiss, showing the lovers Paolo and Francesca, was also originally part of the Gates."]],
  ["Balzac and the Burghers",[
    "The Burghers of Calais (1884–1895) commemorates six citizens who in 1347 offered their lives to the English king to save their besieged city. Rodin rejected the heroic monument, showing the men at ground level, each in a different state of despair and resolve.",
    "His Monument to Balzac, a towering figure wrapped in a dressing gown with a powerful head, was rejected by the writers' society that commissioned it in 1898 but is now seen as a landmark of modern sculpture. Rodin's assistant and lover Camille Claudel was a gifted sculptor in her own right, whose works such as The Waltz and The Age of Maturity have been rediscovered."]],
  ["Art Nouveau",[
    "Art Nouveau (“New Art”), flourishing from about 1890 to 1910, was an international style in architecture, design, and decorative arts characterized by flowing, organic lines inspired by plants, flowers, and natural forms, often in whiplash curves. It sought to break with historical styles and unify fine and applied arts, bringing beauty to everyday objects.",
    "It had many names: Jugendstil in Germany, Sezessionsstil in Austria, Modernisme in Catalonia, and Stile Liberty in Italy."]],
  ["Masters of Art Nouveau",[
    "Alphonse Mucha, a Czech artist in Paris, designed posters for the actress Sarah Bernhardt with elegant women surrounded by swirling hair and flowers. Hector Guimard designed the cast-iron entrances of the Paris Métro (1900), with plant-like stems. The Belgian architect Victor Horta's Hôtel Tassel (1893) in Brussels has curving iron and mosaics.",
    "In Barcelona, Antoni Gaudí created fantastical buildings inspired by nature, such as Casa Batlló and Casa Milà, and his still-unfinished basilica of the Sagrada Família, begun in 1882. Louis Comfort Tiffany in New York made iridescent glass lamps and windows, and René Lalique and Émile Gallé produced exquisite glass and jewelry."]],
  ["Arts and Crafts",[
    "In Britain, the Arts and Crafts movement, led by the designer, writer, and socialist William Morris (1834–1896), rejected cheap machine-made goods and championed handcraftsmanship, honest materials, and design inspired by nature and medieval traditions. Morris's company produced wallpapers, textiles, furniture, and books.",
    "Arts and Crafts ideals of uniting art and life influenced Art Nouveau and later the Bauhaus. In Glasgow, Charles Rennie Mackintosh developed a distinctive geometric style, and in Vienna, the Wiener Werkstätte produced elegant modern design."]]
  ],
  terms:[["Rodin","The sculptor who revitalized modern sculpture."],["The Gates of Hell","Rodin's lifelong project inspired by Dante."],["The Thinker","Rodin's famous seated figure."],["The Burghers of Calais","Rodin's monument to six self-sacrificing citizens."],["Art Nouveau","An international style of flowing organic lines, about 1890–1910."],["Sagrada Família","Gaudí's unfinished basilica in Barcelona."],["Arts and Crafts","The movement championing handcraft, led by William Morris."]],
  w:"Rodin brought emotion and energy back to sculpture, while Art Nouveau and Arts and Crafts sought to unite art with everyday life, preparing the way for modern design.",
  src:["Auguste Rodin","The Gates of Hell","The Thinker","The Burghers of Calais","Art Nouveau","Antoni Gaudí","Arts and Crafts movement"],
  q:[["Which Rodin work led critics to accuse him of casting from life?","The Age of Bronze","The Thinker","The Kiss","Balzac"],
     ["Which poem inspired The Gates of Hell?","Dante's Inferno","Milton's Paradise Lost","Goethe's Faust","Homer's Odyssey"],
     ["Which gifted sculptor was Rodin's assistant and lover?","Camille Claudel","Berthe Morisot","Suzanne Valadon","Gwen John"],
     ["Who designed the Paris Métro entrances?","Hector Guimard","Victor Horta","Alphonse Mucha","Antoni Gaudí"],
     ["Who designed the Sagrada Família?","Antoni Gaudí","Lluís Domènech i Montaner","Victor Horta","Otto Wagner"],
     ["Who led the Arts and Crafts movement?","William Morris","John Ruskin","Charles Rennie Mackintosh","Louis Comfort Tiffany"]]}

);


/* ---- from arts-13.js ---- */
/* ARTS FOUNDATIONS, part 13: Unit 8 Modern Art, chapters 1-5 */
COURSES.arts.units.push({ t:"Modern Art: 1905–1945", ch:[

{ t:"Fauvism and Matisse", s:"Wild color",
  sec:[
  ["The wild beasts",[
    "At the 1905 Salon d'Automne in Paris, a room of paintings by Henri Matisse, André Derain, Maurice de Vlaminck, and others shocked visitors with violent, unnatural color: green faces, red trees, orange skies, applied in bold, flat patches. The critic Louis Vauxcelles, seeing a classical-style sculpture among them, exclaimed “Donatello among the wild beasts (fauves)!” and the name Fauvism stuck.",
    "Fauvism was short-lived, from about 1905 to 1908, but it was the first major avant-garde movement of the 20th century, freeing color from its descriptive role and making it a means of expression and structure in its own right."]],
  ["Matisse's early work",[
    "Henri Matisse (1869–1954) studied law before taking up painting during a convalescence. Influenced by Cézanne, Gauguin, Van Gogh, and Signac's pointillism, he developed a radical use of color. His Woman with a Hat (1905), a portrait of his wife Amélie with a face streaked with green and violet, provoked ridicule at the Salon but was bought by the American collectors Leo and Gertrude Stein.",
    "The Joy of Life (Le Bonheur de vivre, 1905–1906) shows nude figures dancing, playing music, and embracing in an Arcadian landscape of flat, brilliant color and sinuous lines."]],
  ["Harmony and decoration",[
    "Matisse said he dreamed of “an art of balance, of purity and serenity,” “something like a good armchair” for the tired mind. He painted interiors filled with patterned textiles, windows, and odalisques, and works such as The Red Studio (1911), in which the walls and floor of his studio dissolve into a single field of red, with his own works floating within it.",
    "The Dance (1909–1910), painted for the Russian collector Sergei Shchukin, shows five red nudes dancing in a ring against blue sky and green earth, reduced to the simplest forms and colors. Matisse also traveled to Morocco, absorbing Islamic decoration."]],
  ["Cut-outs and the chapel",[
    "In his last years, after cancer surgery left him largely confined to a wheelchair or bed, Matisse invented a new technique: cutting shapes from sheets of paper painted with gouache, which assistants pinned to the wall under his direction. He called it “drawing with scissors.”",
    "The cut-outs, such as the book Jazz (1947), Blue Nudes (1952), and The Snail, are among his most joyful works. He designed every element of the Chapel of the Rosary in Vence (1948–1951), including stained-glass windows, wall drawings, and priests' vestments, which he considered his masterpiece."]],
  ["Derain, Vlaminck, and Dufy",[
    "André Derain painted the Thames in London and the fishing port of Collioure in vivid, unnatural colors, and Maurice de Vlaminck, a self-taught former racing cyclist and violinist, used thick, Van Gogh-inspired strokes of pure color. Raoul Dufy and Georges Braque also passed through a Fauve phase before moving on.",
    "After about 1908, most Fauves moved in other directions, Braque toward Cubism, Derain toward classicism."]],
  ["Matisse and Picasso",[
    "Matisse and Pablo Picasso were the two giants of early 20th-century painting, rivals and friends who constantly watched each other's work. Matisse represented color, harmony, and decorative serenity; Picasso, form, disruption, and restless invention.",
    "Matisse's liberation of color influenced the Expressionists, abstract painters such as Mark Rothko, and countless designers."]]
  ],
  terms:[["Fauvism","The movement of wild, expressive color, 1905–1908."],["Fauves","French for wild beasts."],["Woman with a Hat","Matisse's portrait shown at the 1905 Salon."],["The Dance","Matisse's painting of five dancing figures."],["Cut-outs","Matisse's late works of cut painted paper."],["Chapel of the Rosary","Matisse's chapel in Vence."]],
  w:"Fauvism freed color from describing reality, and Matisse's lifelong exploration of color made him one of the two greatest painters of the 20th century.",
  src:["Fauvism","Henri Matisse","Woman with a Hat","Dance (Matisse)","The Red Studio","Paper cutouts (Matisse)","André Derain"],
  q:[["What does Fauves mean?","Wild beasts","Wild colors","Free painters","New artists"],
     ["Which critic named the Fauves?","Louis Vauxcelles","Louis Leroy","Roger Fry","Guillaume Apollinaire"],
     ["Who bought Woman with a Hat?","Leo and Gertrude Stein","Sergei Shchukin","Ambroise Vollard","Albert Barnes"],
     ["Who commissioned Matisse's The Dance?","Sergei Shchukin","Gertrude Stein","Ivan Morozov","Albert Barnes"],
     ["What did Matisse call his cut-out technique?","Drawing with scissors","Paper painting","Collage","Cutting color"],
     ["Which chapel did Matisse design?","The Chapel of the Rosary in Vence","The Rothko Chapel","Ronchamp","The Sistine Chapel"]]},

{ t:"Expressionism", s:"The inner world made visible",
  sec:[
  ["What is Expressionism?",[
    "Expressionism, centered in Germany and Austria from about 1905 to the 1920s, sought to express inner emotional experience rather than outward appearance, using distortion, exaggeration, harsh color, and jagged lines. It drew on Van Gogh, Gauguin, Munch, and the art of medieval Germany, Africa, and Oceania.",
    "Expressionism also spread to literature, theater, music, architecture, and film, such as The Cabinet of Dr. Caligari (1920), with its distorted painted sets."]],
  ["Die Brücke",[
    "Die Brücke (The Bridge), founded in Dresden in 1905 by architecture students Ernst Ludwig Kirchner, Erich Heckel, and Karl Schmidt-Rottluff, aimed to bridge the past and future. Its members painted nudes in nature, studio scenes, and later the city, with crude, angular forms and clashing colors, and revived the woodcut as a raw, expressive medium.",
    "Kirchner's Berlin street scenes (1913–1915), showing elegantly dressed prostitutes and men in jagged, crowded compositions, capture the anxiety and alienation of the modern metropolis. Emil Nolde, briefly a member, painted religious scenes with violent color."]],
  ["Der Blaue Reiter",[
    "Der Blaue Reiter (The Blue Rider), formed in Munich in 1911 by Wassily Kandinsky and Franz Marc, was more spiritual and moved toward abstraction. Its name came from a love of the color blue and horses. Marc painted animals in symbolic colors, such as Blue Horse I and The Large Blue Horses, believing animals were purer than humans.",
    "The group published an almanac in 1912 that included children's art, folk art, and non-Western art alongside modern works. Paul Klee and August Macke were associated with it. Marc and Macke were both killed in World War I."]],
  ["Austrian Expressionism",[
    "In Vienna, Egon Schiele (1890–1918), a protégé of Klimt, drew and painted contorted, emaciated, often erotic figures and anguished self-portraits with nervous, angular lines; he died at 28 in the 1918 influenza pandemic. Oskar Kokoschka painted psychologically probing portraits and The Bride of the Wind, an image of his stormy love affair with Alma Mahler.",
    "The sculptor and printmaker Käthe Kollwitz (1867–1945), in Berlin, created powerful images of poverty, war, grief, and motherhood, such as her series The Weavers and The Peasants' War, and the sculpture The Grieving Parents for the grave of her son, killed in 1914."]],
  ["War and the New Objectivity",[
    "World War I traumatized a generation. Max Beckmann, a medical orderly, painted crowded, nightmarish scenes of violence, such as The Night. After the war, artists of the New Objectivity (Neue Sachlichkeit) depicted Weimar Germany with cold, satirical realism.",
    "Otto Dix, a veteran, made the print series The War (1924), showing horrors of the trenches, and paintings of crippled veterans and decadent nightlife. George Grosz savagely caricatured profiteers, generals, and the bourgeoisie."]],
  ["Degenerate art",[
    "The Nazis, who came to power in 1933, condemned modern art as “degenerate” and seized about 20,000 works from German museums. In 1937 they mounted the Degenerate Art (Entartete Kunst) exhibition in Munich, displaying works by Kirchner, Nolde, Dix, Kandinsky, Klee, Chagall, and others with mocking slogans; more than two million people visited it.",
    "Many works were sold abroad or burned, and many artists were forbidden to work or fled into exile. Kirchner, despairing, took his own life in 1938. The episode is a stark example of political control over art."]]
  ],
  terms:[["Expressionism","Art expressing inner emotion through distortion and color."],["Die Brücke","The Dresden Expressionist group founded in 1905."],["Der Blaue Reiter","The Munich group founded by Kandinsky and Marc in 1911."],["Woodcut revival","Expressionists' use of the raw woodcut medium."],["New Objectivity","The cold, satirical realism of Weimar Germany."],["Degenerate Art","The 1937 Nazi exhibition condemning modern art."]],
  w:"Expressionism made inner emotion the subject of art and confronted the anxiety and violence of the modern age, until the Nazis tried to suppress it.",
  src:["Expressionism","Die Brücke","Der Blaue Reiter","Ernst Ludwig Kirchner","Egon Schiele","Käthe Kollwitz","Degenerate art"],
  q:[["Where was Die Brücke founded?","Dresden","Munich","Berlin","Vienna"],
     ["Who founded Der Blaue Reiter with Kandinsky?","Franz Marc","Paul Klee","August Macke","Ernst Ludwig Kirchner"],
     ["Which Viennese artist died at 28 in the 1918 pandemic?","Egon Schiele","Oskar Kokoschka","Gustav Klimt","Richard Gerstl"],
     ["Who made The Grieving Parents for her son's grave?","Käthe Kollwitz","Paula Modersohn-Becker","Gabriele Münter","Hannah Höch"],
     ["Who made the print series The War?","Otto Dix","George Grosz","Max Beckmann","Emil Nolde"],
     ["In what year was the Degenerate Art exhibition?","1937","1933","1945","1925"]]},

{ t:"Picasso", s:"The restless inventor",
  sec:[
  ["Early years",[
    "Pablo Picasso (1881–1973), born in Málaga, Spain, son of an art teacher, was a prodigy who could draw like an academic master as a teenager. He settled in Paris in 1904 and became the most famous and influential artist of the 20th century, working in painting, sculpture, printmaking, ceramics, and stage design, and producing tens of thousands of works over his long life.",
    "His career is often divided into periods. In his Blue Period (1901–1904), after the suicide of his friend Carles Casagemas, he painted beggars, the blind, and the poor in somber blues, as in The Old Guitarist. In the Rose Period (1904–1906), he painted circus performers and harlequins in warmer pinks and earth tones."]],
  ["Les Demoiselles d'Avignon",[
    "In 1907 Picasso painted Les Demoiselles d'Avignon, now at MoMA, showing five nude women in a Barcelona brothel. Their bodies are broken into angular planes, the space is flattened and fractured, and the faces of two figures on the right resemble African masks, which Picasso had seen in the ethnographic museum at the Trocadéro, while others recall ancient Iberian sculpture.",
    "Even his friends were shocked; Braque said it was like drinking kerosene. Kept in his studio until 1916, it is now seen as a turning point in modern art and the beginning of Cubism, though its use of African art is also examined critically today for how it treated other cultures as “primitive.”"]],
  ["Cubism and beyond",[
    "With Georges Braque, Picasso developed Cubism from 1908, the subject of the next chapter. During and after World War I, he surprised the art world by also painting in a monumental Neoclassical style, with massive, statuesque women, while continuing Cubist work, refusing to be confined to one style.",
    "He designed sets and costumes for Sergei Diaghilev's Ballets Russes, including Parade (1917), and married the Russian ballerina Olga Khokhlova. In the late 1920s and 1930s, his work took on Surrealist distortions, and the Minotaur, a half-bull, half-man creature, became a recurring alter ego."]],
  ["Guernica",[
    "On 26 April 1937, during the Spanish Civil War, German and Italian bombers supporting Franco's Nationalists bombed the Basque town of Guernica, killing many civilians. Picasso, commissioned to make a mural for the Spanish Republic's pavilion at the 1937 Paris World's Fair, painted Guernica in about five weeks.",
    "The huge black, white, and gray canvas, nearly 8 meters wide, shows a screaming woman holding a dead child, a wounded, shrieking horse, a bull, a fallen soldier with a broken sword, and a figure thrusting a lamp into the scene, in fragmented, Cubist-derived forms. Picasso refused to let it go to Spain while Franco ruled; it hung at MoMA until it was returned to Spain in 1981 and now hangs in the Museo Reina Sofía in Madrid. It is one of the most powerful anti-war images ever made."]],
  ["Sculpture and later work",[
    "Picasso was also an innovative sculptor: his constructed Guitar (1912) of sheet metal and wire helped invent assemblage sculpture, and Bull's Head (1942) combined a bicycle seat and handlebars. He made thousands of ceramics at Vallauris in southern France.",
    "In his last decades he painted variations on old masters, Velázquez's Las Meninas, Delacroix's Women of Algiers, and Manet's Déjeuner, and worked with tireless energy until his death in 1973 at 91."]],
  ["Legacy and debate",[
    "Picasso's influence is almost impossible to overstate: he helped invent Cubism, collage, and assemblage and constantly reinvented his art. Museums devoted to him exist in Paris, Barcelona, Málaga, and Antibes. Les Femmes d'Alger (Version O) sold for about 179 million dollars in 2015.",
    "His treatment of the women in his life, including Fernande Olivier, Olga Khokhlova, Marie-Thérèse Walter, Dora Maar, Françoise Gilot, and Jacqueline Roque, who often appear in his art, has drawn increasing criticism, prompting debates about the relationship between an artist's life and work."]]
  ],
  terms:[["Blue Period","Picasso's somber paintings of 1901–1904."],["Rose Period","Picasso's warmer circus paintings of 1904–1906."],["Les Demoiselles d'Avignon","Picasso's 1907 painting that began Cubism."],["Guernica","Picasso's 1937 painting of the bombing of a Basque town."],["Minotaur","Picasso's recurring half-bull alter ego."],["Ballets Russes","Diaghilev's ballet company for which Picasso designed."]],
  w:"Picasso constantly reinvented art over seven decades, and works such as Les Demoiselles d'Avignon and Guernica changed what painting could do.",
  src:["Pablo Picasso","Picasso's Blue Period","Picasso's Rose Period","Les Demoiselles d'Avignon","Guernica (Picasso)","Bombing of Guernica","Bull's Head"],
  q:[["Where was Picasso born?","Málaga","Barcelona","Madrid","Paris"],
     ["Which color dominated Picasso's paintings of 1901–1904?","Blue","Rose","Green","Red"],
     ["Which 1907 painting began Cubism?","Les Demoiselles d'Avignon","Guernica","The Old Guitarist","Three Musicians"],
     ["What event does Guernica depict?","The bombing of a Basque town","The Battle of the Somme","The fall of Madrid","The Paris Commune"],
     ["Where does Guernica hang today?","Museo Reina Sofía, Madrid","MoMA","The Prado","Musée Picasso, Paris"],
     ["What did Picasso use to make Bull's Head?","A bicycle seat and handlebars","Sheet metal and wire","Ceramic tiles","Found wood"]]},

{ t:"Cubism and Futurism", s:"Fragmenting space and celebrating speed",
  sec:[
  ["Cubism",[
    "Cubism, developed by Picasso and Georges Braque in Paris from 1908, was perhaps the most influential movement of the 20th century. Building on Cézanne, it abandoned single-point perspective and the illusion of depth, breaking objects into geometric facets and showing them from multiple viewpoints at once, as the mind knows them rather than as the eye sees them from one position.",
    "The name came from the critic Louis Vauxcelles, who described Braque's landscapes at L'Estaque in 1908 as made of “little cubes.” Picasso and Braque worked so closely, Braque said, “like two mountaineers roped together,” that their paintings of the period are sometimes hard to tell apart."]],
  ["Analytic Cubism",[
    "In Analytic Cubism (about 1909–1912), forms were broken into many small, overlapping, transparent planes in a narrow range of browns, grays, and ochres, so that subjects such as figures, guitars, and bottles became nearly unrecognizable, with only hints such as a mustache, a pipe, or stenciled letters.",
    "Picasso's Portrait of Ambroise Vollard (1910) and Braque's Violin and Candlestick are examples. Muted color kept attention on the analysis of form and space."]],
  ["Synthetic Cubism and collage",[
    "In Synthetic Cubism (about 1912–1919), Picasso and Braque built up images from flatter, simpler, more colorful shapes. They invented collage: Picasso's Still Life with Chair Caning (1912) glued a piece of printed oilcloth imitating chair caning onto the canvas and framed it with rope. Braque invented papier collé, pasted paper such as wallpaper and newspaper.",
    "Bringing real materials from everyday life into art was a revolutionary step that would lead to assemblage, Dada, and much later art. Other Cubists included Juan Gris, Fernand Léger, whose tubular forms celebrated machines, Robert and Sonia Delaunay, whose colorful circles were called Orphism, and the sculptors Jacques Lipchitz and Alexander Archipenko."]],
  ["Futurism",[
    "Futurism was launched by the Italian poet Filippo Tommaso Marinetti with a manifesto published on the front page of the Paris newspaper Le Figaro on 20 February 1909. It glorified speed, machines, technology, cities, youth, violence, and war, and demanded the destruction of museums and libraries; Marinetti declared that “a roaring motor car … is more beautiful than the Victory of Samothrace.”",
    "Futurist painters Umberto Boccioni, Giacomo Balla, Carlo Carrà, Gino Severini, and Luigi Russolo combined Cubist fragmentation with the depiction of motion. Balla's Dynamism of a Dog on a Leash shows a dachshund's many blurred legs, and Boccioni's bronze Unique Forms of Continuity in Space (1913), a striding figure with flame-like forms, appears on the Italian 20-cent euro coin."]],
  ["Futurism's fate",[
    "Futurists enthusiastically supported Italy's entry into World War I; Boccioni and the architect Antonio Sant'Elia were killed in it. After the war, Marinetti allied the movement with Mussolini's Fascism, which has shadowed Futurism's reputation.",
    "Futurism nonetheless influenced movements across Europe, including Russian Cubo-Futurism, British Vorticism, and Dada, and its performances and sound experiments, such as Russolo's noise machines, anticipated later performance and sound art."]],
  ["Marcel Duchamp's Nude",[
    "Marcel Duchamp's Nude Descending a Staircase, No. 2 (1912) combined Cubist fragmentation with Futurist-like motion and chronophotography, showing a figure as a sequence of overlapping planes. Rejected by the Cubists in Paris, it caused a sensation at the 1913 Armory Show in New York, which introduced modern European art to America; one critic called it “an explosion in a shingle factory.”",
    "Cubism's fragmentation of space influenced abstract art, architecture, and design throughout the century."]]
  ],
  terms:[["Cubism","Fragmenting objects into facets and multiple viewpoints."],["Analytic Cubism","Early Cubism of small, muted, overlapping planes."],["Synthetic Cubism","Later Cubism of flatter, colorful shapes and collage."],["Collage","Gluing real materials onto a picture surface."],["Futurism","The Italian movement glorifying speed and machines."],["Armory Show","The 1913 New York exhibition of modern art."]],
  w:"Cubism shattered the centuries-old system of perspective and invented collage, while Futurism celebrated the speed of modern life, together transforming 20th-century art.",
  src:["Cubism","Georges Braque","Collage","Juan Gris","Futurism","Unique Forms of Continuity in Space","Armory Show"],
  q:[["Who developed Cubism with Picasso?","Georges Braque","Henri Matisse","Juan Gris","Fernand Léger"],
     ["Which critic described Braque's landscapes as made of little cubes?","Louis Vauxcelles","Guillaume Apollinaire","Roger Fry","Clement Greenberg"],
     ["Which work was the first collage?","Picasso's Still Life with Chair Caning","Braque's Violin and Candlestick","Gris's The Sunblind","Léger's The City"],
     ["Who wrote the Futurist manifesto?","Filippo Tommaso Marinetti","Umberto Boccioni","Giacomo Balla","Carlo Carrà"],
     ["Which Futurist sculpture appears on the Italian 20-cent euro coin?","Unique Forms of Continuity in Space","Dynamism of a Dog on a Leash","The City Rises","Bottle Evolving in Space"],
     ["Which painting caused a sensation at the 1913 Armory Show?","Nude Descending a Staircase, No. 2","Les Demoiselles d'Avignon","The Dance","Black Square"]]},

{ t:"The Birth of Abstraction", s:"Kandinsky, Malevich, Mondrian, and the Russian avant-garde",
  sec:[
  ["Toward abstraction",[
    "Abstract art does not depict recognizable objects; it uses color, line, and form for their own sake or to express spiritual or emotional ideas. Several artists in different countries arrived at pure abstraction around 1910–1915, building on Post-Impressionism, Fauvism, and Cubism.",
    "The Swedish artist Hilma af Klint (1862–1944), a spiritualist, painted large abstract works beginning in 1906, earlier than the better-known pioneers, but she kept them private and asked that they not be shown until 20 years after her death; major exhibitions since 2013 have established her as a pioneer."]],
  ["Kandinsky",[
    "Wassily Kandinsky (1866–1944), a Russian who trained as a lawyer before turning to art in Munich, is often credited with painting some of the first abstract paintings around 1910–1913. In Concerning the Spiritual in Art (1911), he argued that colors and forms have spiritual and emotional effects like music, comparing colors to musical tones; he may have had synesthesia.",
    "He titled works like music, Improvisations and Compositions; Composition VII (1913) is a swirling explosion of color. Later, teaching at the Bauhaus, he moved to more geometric forms."]],
  ["Malevich and Suprematism",[
    "In Russia, Kazimir Malevich (1879–1935) founded Suprematism, seeking “the supremacy of pure feeling” in art through basic geometric forms. At the 0,10 exhibition in Petrograd in 1915, he hung Black Square, a black square on a white ground, high in the corner of the room, where an icon would traditionally hang in a Russian home, declaring it a new beginning for art.",
    "His White on White (1918) reduced painting further to a tilted white square on a white ground. Under Stalin, abstraction was condemned and Malevich returned to figurative painting."]],
  ["Russian Constructivism",[
    "After the 1917 Revolution, Russian Constructivists such as Vladimir Tatlin, Alexander Rodchenko, El Lissitzky, Lyubov Popova, and Varvara Stepanova rejected art for art's sake and sought to use art and design to build a new socialist society, working with industrial materials, graphic design, photography, architecture, and textiles.",
    "Tatlin's model for a Monument to the Third International (1919–1920), a spiraling tower of steel and glass meant to be taller than the Eiffel Tower, was never built. Rodchenko's photographs with dramatic angles and El Lissitzky's propaganda poster Beat the Whites with the Red Wedge are icons. Socialist Realism, mandated from 1932 under Stalin, ended the experiment."]],
  ["Mondrian and De Stijl",[
    "The Dutch painter Piet Mondrian (1872–1944) moved from naturalistic landscapes through Cubism to a strict abstract style he called Neo-Plasticism, using only horizontal and vertical black lines, the three primary colors, and white, gray, and black, to express universal harmony.",
    "With Theo van Doesburg and others, he founded the De Stijl (“The Style”) movement in 1917, which applied these principles to architecture and design, as in Gerrit Rietveld's Red and Blue Chair and Schröder House in Utrecht. In New York late in life, Mondrian painted Broadway Boogie Woogie (1942–1943), with bright blocks of color inspired by the city's grid and jazz."]],
  ["Klee and the language of form",[
    "Paul Klee (1879–1940), Swiss-German, made thousands of small, poetic works combining abstraction with signs, symbols, and childlike figures, saying that “a line is a dot that went for a walk.” His works, such as Twittering Machine and Angelus Novus, are whimsical yet profound.",
    "By the 1920s, abstraction had become one of the central languages of modern art, influencing architecture, design, typography, and later movements such as Abstract Expressionism and Minimalism."]]
  ],
  terms:[["Abstract art","Art that does not depict recognizable objects."],["Hilma af Klint","A Swedish pioneer of abstract painting from 1906."],["Concerning the Spiritual in Art","Kandinsky's 1911 treatise."],["Suprematism","Malevich's art of pure geometric form."],["Black Square","Malevich's 1915 icon of abstraction."],["Constructivism","Russian art in service of building a new society."],["De Stijl","The Dutch movement of Mondrian and Rietveld."]],
  w:"The birth of abstraction freed art from representing the visible world, making pure color and form a language for spiritual, emotional, and social ideas.",
  src:["Abstract art","Hilma af Klint","Wassily Kandinsky","Kazimir Malevich","Black Square (painting)","Constructivism (art)","Piet Mondrian"],
  q:[["Which Swedish artist painted abstract works from 1906?","Hilma af Klint","Sonia Delaunay","Gabriele Münter","Sophie Taeuber-Arp"],
     ["Who wrote Concerning the Spiritual in Art?","Wassily Kandinsky","Kazimir Malevich","Piet Mondrian","Paul Klee"],
     ["Who founded Suprematism?","Kazimir Malevich","Vladimir Tatlin","El Lissitzky","Alexander Rodchenko"],
     ["Where did Malevich hang Black Square in 1915?","High in a corner, like an icon","Over a doorway","On the floor","In a church"],
     ["Which movement did Mondrian help found?","De Stijl","Bauhaus","Constructivism","Orphism"],
     ["Who said a line is a dot that went for a walk?","Paul Klee","Kandinsky","Mondrian","Miró"]]}

]});


/* ---- from arts-14.js ---- */
/* ARTS FOUNDATIONS, part 14: Unit 8 chapters 6-10 */
COURSES.arts.units[7].ch.push(

{ t:"Dada and Duchamp", s:"Anti-art in an age of war",
  sec:[
  ["Born in Zurich",[
    "Dada began in 1916 at the Cabaret Voltaire in Zurich, neutral Switzerland, where artists and writers who had fled World War I, including Hugo Ball, Emmy Hennings, Tristan Tzara, Jean (Hans) Arp, and Marcel Janco, staged chaotic performances of nonsense poetry, noise music, and costumes. Disgusted by the slaughter of the war, which they blamed on the rational, bourgeois society that also produced conventional art, they attacked logic, tradition, and art itself.",
    "The name Dada, reportedly chosen by sticking a knife into a dictionary, is a French children's word for hobby horse and also means “yes, yes” in Romanian and Russian. Its nonsense was the point."]],
  ["Chance and nonsense",[
    "Dadaists embraced chance and absurdity. Arp made collages by dropping torn paper squares onto a sheet and gluing them where they fell. Tzara wrote poems by drawing words cut from newspapers out of a hat. Hugo Ball recited sound poems of invented words while wearing a cardboard costume.",
    "Dada spread to Berlin, Cologne, Hanover, Paris, and New York, taking on different characters in each city."]],
  ["Berlin Dada and photomontage",[
    "Berlin Dada, after Germany's defeat, was fiercely political. Its artists invented photomontage, combining cut-up photographs and printed text into new images. Hannah Höch's Cut with the Kitchen Knife Dada through the Last Weimar Beer-Belly Cultural Epoch of Germany (1919) mixes politicians, machines, and images of modern women into a chaotic satire of Weimar society.",
    "John Heartfield used photomontage to attack Hitler and the Nazis in magazine covers, such as one showing Hitler swallowing gold coins. Kurt Schwitters in Hanover made collages and assemblages from tickets, wrappers, and rubbish, which he called Merz, and built the Merzbau, a room-filling sculptural environment."]],
  ["Marcel Duchamp and the readymade",[
    "Marcel Duchamp (1887–1968), a French artist who moved to New York in 1915, made the most radical gesture of Dada and perhaps of 20th-century art: the readymade, an ordinary manufactured object that the artist selects and declares to be art. His Bicycle Wheel (1913) mounted a wheel on a stool, and Bottle Rack (1914) was simply a bought bottle rack.",
    "Most famously, Fountain (1917), a porcelain urinal turned on its back and signed “R. Mutt 1917,” was submitted to an exhibition of the Society of Independent Artists in New York, which supposedly accepted anything, and was refused. Duchamp argued that what mattered was the artist's choice and idea, not skill or beauty, challenging the very definition of art. The original was lost; replicas are in many museums. Some scholars have suggested the Dada artist Elsa von Freytag-Loringhoven may have been involved in Fountain."]],
  ["L.H.O.O.Q. and The Large Glass",[
    "In L.H.O.O.Q. (1919), Duchamp drew a mustache and goatee on a postcard of the Mona Lisa; the title, read aloud in French, sounds like a crude joke. He also worked for years on The Bride Stripped Bare by Her Bachelors, Even (The Large Glass, 1915–1923), an enigmatic construction of paint, lead foil, and wire between glass panels, which cracked in transit and which he declared finished with its cracks.",
    "Duchamp later appeared to give up art for chess, though he secretly worked for 20 years on Étant donnés, a peephole installation revealed after his death."]],
  ["Dada's legacy",[
    "Dada dissolved in the early 1920s, many members joining Surrealism, but its ideas proved enormously influential. Duchamp's readymades opened the way to Conceptual Art, Pop Art, installation, and the idea that art is defined by the idea and context rather than craft.",
    "In a 2004 poll of 500 art experts, Fountain was voted the most influential modern artwork of the 20th century."]]
  ],
  terms:[["Dada","The anti-art movement begun in Zurich in 1916."],["Cabaret Voltaire","The Zurich nightclub where Dada began."],["Photomontage","Images made by combining cut photographs."],["Merz","Schwitters's collages of everyday rubbish."],["Readymade","An ordinary object chosen and presented as art."],["Fountain","Duchamp's urinal of 1917."],["L.H.O.O.Q.","Duchamp's mustached Mona Lisa."]],
  w:"Dada and Duchamp questioned the very definition of art, and the readymade changed the course of 20th-century and contemporary art.",
  src:["Dada","Cabaret Voltaire (Zurich)","Hannah Höch","Kurt Schwitters","Marcel Duchamp","Readymades of Marcel Duchamp","Fountain (Duchamp)"],
  q:[["Where did Dada begin?","The Cabaret Voltaire in Zurich","A Paris café","A Berlin gallery","New York"],
     ["Which technique did Berlin Dada invent?","Photomontage","Collage","Frottage","Readymades"],
     ["Who made Cut with the Kitchen Knife?","Hannah Höch","John Heartfield","Kurt Schwitters","Raoul Hausmann"],
     ["What did Schwitters call his collages of rubbish?","Merz","Dada","Readymades","Assemblage"],
     ["How was Fountain signed?","R. Mutt 1917","M. Duchamp","Rrose Sélavy","Dada 1917"],
     ["What did Duchamp add to the Mona Lisa in L.H.O.O.Q.?","A mustache and goatee","A hat","Glasses","A frame"]]},

{ t:"Surrealism", s:"Dreams and the unconscious",
  sec:[
  ["The movement",[
    "Surrealism was founded in Paris in 1924 when the poet André Breton published the first Surrealist Manifesto, defining it as “pure psychic automatism” expressing “the actual functioning of thought … in the absence of any control exercised by reason.” Influenced by Sigmund Freud's theories of the unconscious and dreams, and growing out of Dada, Surrealists sought to unlock the irrational, hidden mind and to reconcile dream and reality in a “surreality.”",
    "Surrealism was also political, aiming at revolution in society and consciousness, and it spread to literature, film, photography, and objects."]],
  ["Automatism",[
    "One Surrealist approach was automatism, creating without conscious control to let the unconscious emerge, through automatic writing and drawing. André Masson made automatic drawings and sand paintings; Joan Miró, from Barcelona, painted playful, biomorphic forms floating in dreamlike spaces, as in The Harlequin's Carnival.",
    "Max Ernst invented frottage, rubbing pencil over paper laid on textured surfaces such as wood grain, and grattage and decalcomania, using the accidental textures as starting points for strange forests and creatures. Surrealists also played collective games such as the “exquisite corpse,” in which each participant added to a drawing or sentence without seeing the others' parts."]],
  ["Dreamlike realism",[
    "Another approach painted impossible, dreamlike scenes with meticulous realism. Giorgio de Chirico's earlier “metaphysical” paintings of empty Italian piazzas with long shadows, arcades, and distant trains, such as The Melancholy of an Afternoon, inspired the Surrealists.",
    "Salvador Dalí (1904–1989), the most famous Surrealist, developed a “paranoiac-critical method” to produce hallucinatory images. The Persistence of Memory (1931), at MoMA, shows soft, melting pocket watches draped over a branch and a strange creature in a barren landscape. Dalí's flamboyant self-promotion eventually led Breton to expel him."]],
  ["Magritte",[
    "The Belgian René Magritte (1898–1967) painted ordinary objects in startling, witty, puzzling combinations to make viewers question perception and language. The Treachery of Images (1929) shows a carefully painted pipe with the caption “Ceci n'est pas une pipe” (“This is not a pipe”), reminding us that a picture of a pipe is not a pipe.",
    "His men in bowler hats, apples in front of faces, as in The Son of Man, and nighttime streets under daylit skies, as in The Empire of Light, influenced Pop Art and advertising."]],
  ["Surrealist women and objects",[
    "Women artists played significant roles in Surrealism, though often marginalized at first. Meret Oppenheim's Object (1936), a teacup, saucer, and spoon covered in gazelle fur, became an emblem of Surrealism. Leonora Carrington and Remedios Varo, both of whom settled in Mexico, painted mystical, fantastical worlds, and Dorothea Tanning and Kay Sage explored dream imagery.",
    "Lee Miller, a model turned photographer, made Surrealist photographs and later became a war correspondent. Man Ray, an American, experimented with “rayographs” (photograms made without a camera) and solarization."]],
  ["Surrealism's spread",[
    "Surrealism became an international movement, with groups in Belgium, Britain, Czechoslovakia, Japan, Mexico, and the Caribbean. Luis Buñuel and Dalí's film Un Chien Andalou (1929) begins with a shocking image of a razor slicing an eye.",
    "World War II scattered the Surrealists; many, including Breton, Ernst, and Masson, fled to New York, where their ideas about automatism and the unconscious profoundly influenced young American painters who would create Abstract Expressionism."]]
  ],
  terms:[["Surrealism","The movement exploring dreams and the unconscious, founded 1924."],["Surrealist Manifesto","Breton's 1924 founding text."],["Automatism","Creating without conscious control."],["Frottage","Making rubbings from textured surfaces."],["Exquisite corpse","A collaborative Surrealist game."],["The Persistence of Memory","Dalí's painting of melting watches."],["The Treachery of Images","Magritte's This is not a pipe."]],
  w:"Surrealism brought dreams and the unconscious into art and culture, and its techniques and imagery still shape painting, film, and advertising.",
  src:["Surrealism","André Breton","Joan Miró","Max Ernst","Salvador Dalí","The Persistence of Memory","The Treachery of Images"],
  q:[["Who wrote the first Surrealist Manifesto?","André Breton","Salvador Dalí","Tristan Tzara","Paul Éluard"],
     ["Whose theories of the unconscious influenced Surrealism?","Sigmund Freud","Carl Jung","Karl Marx","Henri Bergson"],
     ["Who invented frottage?","Max Ernst","Joan Miró","André Masson","Yves Tanguy"],
     ["Which painting shows melting watches?","The Persistence of Memory","The Son of Man","The Elephant Celebes","The Harlequin's Carnival"],
     ["Who painted This is not a pipe?","René Magritte","Salvador Dalí","Giorgio de Chirico","Paul Delvaux"],
     ["Who made the fur-covered teacup?","Meret Oppenheim","Leonora Carrington","Dorothea Tanning","Lee Miller"]]},

{ t:"Bauhaus and Modern Design", s:"Art, craft, and industry",
  sec:[
  ["The Bauhaus school",[
    "The Bauhaus was a school of art, design, and architecture founded in 1919 in Weimar, Germany, by the architect Walter Gropius. It aimed to unite fine art, craft, and industry, abolishing the distinction between artist and craftsman, and to design well-made, functional, beautiful objects for modern life and mass production.",
    "Students took a famous preliminary course exploring materials, color, and form, then trained in workshops for metal, weaving, furniture, ceramics, typography, wall painting, and theater. Teachers included Wassily Kandinsky, Paul Klee, Johannes Itten, László Moholy-Nagy, Josef Albers, and Marcel Breuer."]],
  ["Dessau and design",[
    "In 1925 the Bauhaus moved to Dessau, into a building designed by Gropius with glass curtain walls, flat roofs, and asymmetrical wings, an icon of modern architecture. Bauhaus designers produced influential objects: Marcel Breuer's tubular steel Wassily Chair, Marianne Brandt's metal teapots and lamps, and textiles by Anni Albers and Gunta Stölzl, who led the weaving workshop.",
    "Bauhaus graphic design, by Herbert Bayer and others, used sans-serif type, grids, and photography, shaping modern typography and advertising."]],
  ["Closure and diaspora",[
    "Under pressure from the Nazis, who considered it un-German and politically suspect, the Bauhaus moved to Berlin in 1932 under its last director, the architect Ludwig Mies van der Rohe, and closed in 1933.",
    "Its teachers and students emigrated and spread its ideas worldwide: Gropius and Breuer taught at Harvard, Mies van der Rohe led architecture at what became the Illinois Institute of Technology in Chicago, Moholy-Nagy founded the New Bauhaus in Chicago, and Josef and Anni Albers taught at Black Mountain College in North Carolina and later Yale. Tel Aviv's “White City” contains thousands of Bauhaus-style buildings."]],
  ["Form follows function",[
    "Bauhaus ideals were part of the broader modern movement in architecture and design, which rejected historical ornament in favor of clean lines, industrial materials, and function. The phrase “form follows function,” coined by the American architect Louis Sullivan in 1896, became its motto, and the Austrian architect Adolf Loos argued in 1908 that ornament was a waste.",
    "Le Corbusier, the Swiss-French architect, designed the Villa Savoye (1928–1931) and called the house “a machine for living in.” The International Style, named by a 1932 MoMA exhibition, spread steel-and-glass modernism worldwide."]],
  ["Art Deco",[
    "Art Deco, named after the 1925 International Exhibition of Modern Decorative and Industrial Arts in Paris, was a glamorous, decorative style of the 1920s and 1930s, using geometric patterns, zigzags, sunbursts, streamlined forms, and luxurious materials such as chrome, lacquer, and exotic woods.",
    "It shaped skyscrapers such as the Chrysler Building (1930) and Empire State Building (1931) in New York, ocean liners, cinemas, jewelry, and posters, such as those of A. M. Cassandre, and the paintings of Tamara de Lempicka."]],
  ["Design for everyday life",[
    "Twentieth-century designers brought modern aesthetics into homes and everyday objects. Scandinavian designers such as Alvar Aalto developed warm, organic modernism in bentwood furniture. Industrial designers such as Raymond Loewy streamlined trains, cars, and refrigerators.",
    "After World War II, Charles and Ray Eames designed molded plywood and fiberglass furniture for mass production, and design museums and departments, beginning with MoMA's in 1932, recognized design as an art."]]
  ],
  terms:[["Bauhaus","The German school of art and design, 1919–1933."],["Walter Gropius","The founder of the Bauhaus."],["Preliminary course","The Bauhaus foundation course on materials and form."],["Form follows function","The motto that design should derive from purpose."],["International Style","Modernist architecture of steel, glass, and concrete."],["Art Deco","The glamorous geometric style of the 1920s–1930s."]],
  w:"The Bauhaus and modern design united art with industry and everyday life, shaping the buildings, furniture, typography, and objects around us today.",
  src:["Bauhaus","Walter Gropius","Bauhaus Dessau","Marcel Breuer","Anni Albers","Form follows function","Art Deco"],
  q:[["Who founded the Bauhaus?","Walter Gropius","Mies van der Rohe","Le Corbusier","Marcel Breuer"],
     ["Where was the Bauhaus founded in 1919?","Weimar","Dessau","Berlin","Munich"],
     ["Who designed the tubular steel Wassily Chair?","Marcel Breuer","Mies van der Rohe","Alvar Aalto","Charles Eames"],
     ["In what year did the Bauhaus close under Nazi pressure?","1933","1925","1939","1945"],
     ["Who coined form follows function?","Louis Sullivan","Adolf Loos","Le Corbusier","Frank Lloyd Wright"],
     ["Which skyscraper is an Art Deco icon?","The Chrysler Building","The Seagram Building","The Flatiron Building","Willis Tower"]]},

{ t:"Art in the Americas, 1910–1945", s:"Muralists, Kahlo, the Harlem Renaissance, and American scenes",
  sec:[
  ["Mexican muralism",[
    "After the Mexican Revolution (1910–1920), the government, through the education minister José Vasconcelos, commissioned artists to paint murals on public buildings celebrating Mexico's Indigenous heritage, history, workers, and revolutionary ideals, making art accessible to people who could not read. The movement was led by Los Tres Grandes: Diego Rivera, José Clemente Orozco, and David Alfaro Siqueiros.",
    "Diego Rivera (1886–1957) painted vast murals at the National Palace in Mexico City depicting Mexican history from the Aztecs to the present, and the Detroit Industry murals (1932–1933) celebrating auto workers. His mural for the Rockefeller Center in New York was destroyed in 1934 because it included a portrait of Lenin. Orozco painted darker, more tragic visions of history, and Siqueiros experimented with industrial paints and spray guns."]],
  ["Frida Kahlo",[
    "Frida Kahlo (1907–1954), Rivera's wife, became one of the most famous artists of the 20th century. Injured at 18 when a streetcar crashed into her bus, she endured chronic pain and dozens of operations, and began painting during her recovery.",
    "About a third of her roughly 200 paintings are self-portraits, intense, frontal images often with Mexican folk-art elements, Indigenous dress, monkeys, parrots, and symbols of pain and identity, such as The Two Fridas (1939) and The Broken Column (1944). Breton called her a Surrealist, but she said, “I never painted dreams. I painted my own reality.” Her Blue House in Coyoacán is now a museum."]],
  ["The Harlem Renaissance",[
    "In the 1920s and 1930s, the Harlem Renaissance, centered in New York's Harlem neighborhood, was a flowering of African American literature, music, and art, connected to the Great Migration. The philosopher Alain Locke's anthology The New Negro (1925) encouraged artists to draw on African heritage and Black American experience.",
    "Aaron Douglas painted murals in a stylized, geometric silhouette style combining African motifs with modernism. The sculptor Augusta Savage taught and inspired a generation of artists. Jacob Lawrence's Migration Series (1940–1941), 60 small panels with captions, tells the story of the Great Migration. James Van Der Zee photographed Harlem life."]],
  ["American Regionalism and Precisionism",[
    "During the Great Depression, American Regionalists, Grant Wood, Thomas Hart Benton, and John Steuart Curry, painted rural Midwestern life in a realistic style, rejecting European abstraction. Grant Wood's American Gothic (1930), a stern farmer with a pitchfork and a woman before a farmhouse with a Gothic window, became one of the most parodied images in American art.",
    "Precisionists such as Charles Sheeler and Charles Demuth painted factories, skyscrapers, and machines with clean, sharp geometric forms. The Works Progress Administration's Federal Art Project employed thousands of artists during the Depression to make murals, posters, and art for public buildings."]],
  ["O'Keeffe and Hopper",[
    "Georgia O'Keeffe (1887–1986), promoted by the photographer Alfred Stieglitz, whom she married, painted enlarged close-ups of flowers, New York skyscrapers, and, after moving to New Mexico, desert landscapes, bones, and adobe churches, in a style balancing abstraction and realism. Jimson Weed/White Flower No. 1 sold for 44.4 million dollars in 2014, a record for a woman artist at the time.",
    "Edward Hopper (1882–1967) painted scenes of American loneliness and isolation: empty streets, gas stations, hotel rooms, and people sitting alone. Nighthawks (1942), in the Art Institute of Chicago, shows a few figures in a brightly lit all-night diner on a dark, deserted street corner."]],
  ["Photography's documentary eye",[
    "Depression-era photographers documented hardship for the Farm Security Administration. Dorothea Lange's Migrant Mother (1936), showing a worried mother with her children in a California pea pickers' camp, became an icon of the era, and Walker Evans photographed sharecroppers in Alabama for James Agee's book Let Us Now Praise Famous Men.",
    "These artists created distinctly American art, from murals to photographs, that addressed national identity, race, work, and modern life."]]
  ],
  terms:[["Mexican muralism","Public murals celebrating Mexican history and people."],["Los Tres Grandes","Rivera, Orozco, and Siqueiros."],["Frida Kahlo","The Mexican painter of intense self-portraits."],["Harlem Renaissance","The flowering of African American culture in the 1920s–30s."],["Migration Series","Jacob Lawrence's 60 panels on the Great Migration."],["American Gothic","Grant Wood's painting of a farmer and woman."],["Nighthawks","Hopper's painting of a late-night diner."]],
  w:"Between the wars, artists across the Americas created art rooted in their own histories and peoples, from Mexican murals and Kahlo's self-portraits to the Harlem Renaissance and Hopper's America.",
  src:["Mexican muralism","Diego Rivera","Frida Kahlo","Harlem Renaissance","Jacob Lawrence","American Gothic","Nighthawks (Hopper)"],
  q:[["Who were Los Tres Grandes?","Rivera, Orozco, and Siqueiros","Kahlo, Rivera, and Tamayo","Rivera, Kahlo, and Orozco","Siqueiros, Tamayo, and Kahlo"],
     ["Why was Rivera's Rockefeller Center mural destroyed?","It included a portrait of Lenin","It was damaged by fire","It was unfinished","Rivera asked for it"],
     ["Who said I never painted dreams, I painted my own reality?","Frida Kahlo","Leonora Carrington","Remedios Varo","Georgia O'Keeffe"],
     ["Who painted the Migration Series?","Jacob Lawrence","Aaron Douglas","Romare Bearden","Augusta Savage"],
     ["Who painted American Gothic?","Grant Wood","Thomas Hart Benton","Edward Hopper","Andrew Wyeth"],
     ["Who photographed Migrant Mother?","Dorothea Lange","Walker Evans","Margaret Bourke-White","Gordon Parks"]]},

{ t:"Photography in the Twentieth Century", s:"From the decisive moment to the photo essay",
  sec:[
  ["Straight photography",[
    "In the early 20th century, photographers moved away from imitating painting toward “straight” photography that embraced the camera's unique qualities: sharpness, detail, and the record of a moment. Alfred Stieglitz's The Steerage (1907) shows passengers on a ship's lower decks as an arrangement of shapes.",
    "Paul Strand, Edward Weston, whose close-ups of peppers and shells turned everyday objects into sculptural forms, and Ansel Adams, whose majestic black-and-white landscapes of Yosemite and the American West championed wilderness, belonged to Group f/64, named for a small aperture giving maximum sharpness."]],
  ["Modernist experiment",[
    "In Europe, photographers experimented with new viewpoints and techniques. László Moholy-Nagy at the Bauhaus and Alexander Rodchenko in Russia used dramatic angles from above and below, and photograms. Man Ray made solarized portraits and rayographs.",
    "Photomontage became a powerful political tool, and photography was used extensively in advertising and modern magazines."]],
  ["The decisive moment",[
    "The small, portable Leica 35mm camera, introduced in 1925, allowed photographers to capture life spontaneously on the street. Henri Cartier-Bresson (1908–2004), a French photographer, developed the idea of the “decisive moment,” the split second when form and content come together perfectly, as in Behind the Gare Saint-Lazare (1932), showing a man leaping over a puddle.",
    "Brassaï photographed Paris at night, André Kertész captured poetic moments, and in 1947 Cartier-Bresson, Robert Capa, and others founded the cooperative agency Magnum Photos."]],
  ["War and photojournalism",[
    "Picture magazines such as Life (relaunched in 1936) made the photo essay a powerful form. Robert Capa photographed the Spanish Civil War, including the controversial Falling Soldier, and landed with troops on D-Day. Margaret Bourke-White photographed industry, the liberation of concentration camps, and Gandhi.",
    "Iconic war photographs shaped public memory: Joe Rosenthal's Raising the Flag on Iwo Jima (1945), Nick Ut's image of a girl fleeing a napalm attack in Vietnam (1972), and Eddie Adams's Saigon execution (1968) affected opinion about war."]],
  ["Portraits and society",[
    "The German photographer August Sander undertook a vast project, People of the 20th Century, photographing Germans of every class and profession. Diane Arbus, in the 1960s, photographed people on the margins of society with unsettling directness. Gordon Parks, the first African American staff photographer at Life, documented poverty and civil rights; his American Gothic (1942) shows a Black government cleaning woman with a mop and broom before the American flag.",
    "Robert Frank's book The Americans (1958), made on a road trip across the country, showed a lonely, divided America and changed documentary photography."]],
  ["Color and the digital age",[
    "Color photography, available commercially from the 1930s through processes such as Kodachrome (1935), was long considered vulgar by art photographers until William Eggleston's 1976 MoMA exhibition of everyday color photographs. Photographers such as Stephen Shore and later Andreas Gursky, whose huge digitally manipulated prints sell for millions, made color central.",
    "Digital cameras, widespread from the 2000s, and smartphones have made photography universal, with billions of images shared daily, raising new questions about truth, manipulation, and the meaning of images."]]
  ],
  terms:[["Straight photography","Photography using the camera's own qualities without manipulation."],["Group f/64","Photographers committed to sharp, detailed images."],["Decisive moment","Cartier-Bresson's ideal split second."],["Leica","The portable 35mm camera introduced in 1925."],["Photo essay","A story told through a series of photographs."],["Magnum Photos","The photographers' cooperative founded in 1947."]],
  w:"Twentieth-century photography became an art and a powerful witness, shaping how we see society, war, and the world.",
  src:["Straight photography","Group f/64","Ansel Adams","Henri Cartier-Bresson","Robert Capa","Gordon Parks","The Americans (book)"],
  q:[["Whose landscapes of Yosemite championed wilderness?","Ansel Adams","Edward Weston","Paul Strand","Alfred Stieglitz"],
     ["Who developed the idea of the decisive moment?","Henri Cartier-Bresson","Robert Capa","Brassaï","André Kertész"],
     ["When was the Leica camera introduced?","1925","1900","1947","1888"],
     ["Who photographed the D-Day landings?","Robert Capa","Margaret Bourke-White","Dorothea Lange","Joe Rosenthal"],
     ["Who made the book The Americans?","Robert Frank","Walker Evans","Diane Arbus","Garry Winogrand"],
     ["Whose 1976 MoMA show legitimized color photography?","William Eggleston","Stephen Shore","Andreas Gursky","Cindy Sherman"]]}

);


/* ---- from arts-15.js ---- */
/* ARTS FOUNDATIONS, part 15: Unit 9 Postwar and Contemporary, chapters 1-5 */
COURSES.arts.units.push({ t:"Postwar and Contemporary Art", ch:[

{ t:"Abstract Expressionism", s:"New York takes the lead",
  sec:[
  ["A new center",[
    "After World War II, New York replaced Paris as the center of the Western art world. Many European artists had fled there, and a generation of American painters, influenced by Surrealist automatism, Picasso, Jungian ideas of myth, and existentialism, created a bold new art called Abstract Expressionism, also known as the New York School, in the late 1940s and 1950s.",
    "Their large, mostly abstract canvases aimed to express the artist's inner experience and universal emotions. The movement was championed by critics Clement Greenberg and Harold Rosenberg, and, it later emerged, the CIA covertly supported exhibitions abroad as a symbol of American freedom during the Cold War."]],
  ["Action painting: Pollock",[
    "Jackson Pollock (1912–1956) became famous for his “drip” paintings, made from 1947 by laying huge canvases on the floor of his barn studio in East Hampton and dripping, pouring, and flinging household enamel paint with sticks and hardened brushes, moving around and over the canvas. Works such as Autumn Rhythm (Number 30) (1950) are dense, rhythmic webs of lines covering the whole surface, an approach called “all-over” composition.",
    "Rosenberg called this approach “action painting,” seeing the canvas as “an arena in which to act.” Hans Namuth's photographs and film of Pollock at work in 1950 made him a celebrity. Pollock struggled with alcoholism and died in a car crash at 44. His wife, Lee Krasner, was herself an important Abstract Expressionist painter."]],
  ["De Kooning and the gesture",[
    "Willem de Kooning (1904–1997), a Dutch immigrant, painted with violent, slashing brushstrokes. His Woman series (1950–1953), showing aggressive female figures with huge eyes and toothy grins, shocked viewers by bringing the figure back into abstraction.",
    "Franz Kline painted huge black-and-white compositions of powerful strokes resembling magnified calligraphy, and Joan Mitchell, Elaine de Kooning, Grace Hartigan, and Helen Frankenthaler were leading women of the movement. Frankenthaler's Mountains and Sea (1952) invented the “soak-stain” technique of pouring thinned paint into unprimed canvas."]],
  ["Color field painting",[
    "A second tendency, color field painting, used large, flat areas of color to create contemplative, even spiritual experiences. Mark Rothko (1903–1970) painted soft-edged rectangles of luminous color stacked on large canvases, meant to be viewed up close to envelop the viewer and evoke “basic human emotions,” tragedy, ecstasy, doom.",
    "The Rothko Chapel in Houston (1971), a nondenominational space with 14 dark paintings, is a place of meditation. Barnett Newman painted fields of color divided by vertical stripes he called “zips,” as in Vir Heroicus Sublimis, and Clyfford Still painted jagged, flame-like fields. Ad Reinhardt's late “black paintings” reduced color to near invisibility."]],
  ["Sculpture and beyond",[
    "David Smith welded steel sculptures, culminating in his Cubi series of stacked stainless-steel boxes with burnished surfaces. Louise Nevelson built wall-sized assemblages of found wooden pieces painted black, white, or gold.",
    "Abstract Expressionism's influence spread internationally, related to European movements such as Art Informel and Tachisme in France and the Japanese Gutai group, which explored action and materials in performances."]],
  ["Legacy",[
    "Abstract Expressionism was the first American art movement to achieve international influence and established New York's dominance of the art world. Its emphasis on the large canvas, the flat picture plane, and process shaped later art.",
    "Younger artists soon reacted against its heroic seriousness and emphasis on personal emotion, turning to popular culture (Pop Art) and impersonal geometry (Minimalism)."]]
  ],
  terms:[["Abstract Expressionism","The postwar New York movement of expressive abstraction."],["Drip painting","Pollock's technique of pouring and dripping paint."],["Action painting","Rosenberg's term for painting as an act."],["All-over composition","Painting that covers the canvas evenly without a focal point."],["Soak-stain","Frankenthaler's technique of pouring paint into raw canvas."],["Color field painting","Abstraction using large areas of flat color."],["Rothko Chapel","A meditative space with Rothko's dark paintings."]],
  w:"Abstract Expressionism made New York the center of the art world and turned painting into an arena of action and emotion.",
  src:["Abstract expressionism","Jackson Pollock","Willem de Kooning","Helen Frankenthaler","Mark Rothko","Rothko Chapel","Color field"],
  q:[["Which city replaced Paris as the center of the art world after WWII?","New York","London","Berlin","Los Angeles"],
     ["Who created drip paintings on the floor?","Jackson Pollock","Willem de Kooning","Mark Rothko","Franz Kline"],
     ["Who coined the term action painting?","Harold Rosenberg","Clement Greenberg","Leo Steinberg","Meyer Schapiro"],
     ["Who invented the soak-stain technique?","Helen Frankenthaler","Lee Krasner","Joan Mitchell","Grace Hartigan"],
     ["What are Barnett Newman's vertical stripes called?","Zips","Bars","Bands","Lines"],
     ["Where is the Rothko Chapel?","Houston","New York","Los Angeles","Chicago"]]},

{ t:"Pop Art", s:"Art from popular culture",
  sec:[
  ["Origins in Britain",[
    "Pop Art emerged in the mid-1950s in Britain and the early 1960s in the United States as a reaction against the seriousness of Abstract Expressionism. It took its subjects and techniques from popular culture: advertising, comic strips, consumer products, celebrities, television, and mass media.",
    "In London, the Independent Group explored mass culture. Richard Hamilton's small collage Just What Is It That Makes Today's Homes So Different, So Appealing? (1956), showing a muscleman holding a giant lollipop labeled “POP” in a modern living room full of appliances, is often called the first Pop artwork. Hamilton defined Pop as “popular, transient, expendable, low-cost, mass-produced, young, witty, sexy, gimmicky, glamorous, and big business.”"]],
  ["Johns and Rauschenberg",[
    "In the United States, Jasper Johns and Robert Rauschenberg bridged Abstract Expressionism and Pop in the mid-1950s. Johns painted familiar images, flags, targets, numbers, and maps, in encaustic, raising questions about whether Flag (1954–1955) is a painting or a flag.",
    "Rauschenberg made “combines” mixing painting with real objects; Monogram includes a stuffed angora goat with a tire around its middle. He said he wanted to work “in the gap between” art and life. In 1953 he famously erased a drawing by de Kooning, with permission, and exhibited it as Erased de Kooning Drawing."]],
  ["Andy Warhol",[
    "Andy Warhol (1928–1987), a successful commercial illustrator, became the most famous Pop artist. He painted and silkscreened everyday products, Campbell's Soup Cans (1962), 32 canvases, one for each flavor, and Coca-Cola bottles, and celebrities such as Marilyn Monroe, repeated in grids after her death in 1962, Elvis, and Mao, using mechanical methods to mimic mass production and remove the artist's personal touch.",
    "His studio, The Factory, produced art, films, and the band The Velvet Underground. His Death and Disaster series silkscreened news photographs of car crashes and electric chairs. He predicted that “in the future, everyone will be world-famous for 15 minutes.” Shot Sage Blue Marilyn sold for 195 million dollars in 2022."]],
  ["Lichtenstein, Oldenburg, and others",[
    "Roy Lichtenstein (1923–1997) painted enlarged comic-strip panels, such as Whaam! (1963), a fighter plane exploding, and Drowning Girl, imitating the Ben-Day dots of cheap printing by hand. Critics accused him of copying; others saw sharp commentary on mass media and emotion.",
    "Claes Oldenburg made soft sculptures of everyday objects, such as giant toilets and hamburgers, and, with Coosje van Bruggen, colossal public sculptures of clothespins, spoons, and shuttlecocks. James Rosenquist painted billboard-scale collages, and Tom Wesselmann painted Great American Nudes amid consumer goods."]],
  ["Pop around the world",[
    "Pop flourished internationally: in Britain, Peter Blake designed the cover for the Beatles' Sgt. Pepper's Lonely Hearts Club Band (1967), and David Hockney, who moved to Los Angeles, painted sunny swimming pools such as A Bigger Splash (1967). In France, Nouveau Réalisme used real objects.",
    "Women Pop artists such as Marisol, Rosalyn Drexler, Evelyne Axell, and Pauline Boty were long overlooked and have been rediscovered."]],
  ["Meaning and influence",[
    "Pop Art blurred the boundaries between high art and popular culture, and between art and commerce. Critics debated whether it celebrated or critiqued consumer society; often it seems to do both.",
    "Its use of mass-produced imagery and mechanical techniques influenced later art, advertising, and design, and Warhol's ideas about fame, media, and branding seem prophetic in the age of social media."]]
  ],
  terms:[["Pop Art","Art drawing on popular culture and mass media."],["Independent Group","The London group that pioneered Pop."],["Combine","Rauschenberg's mix of painting and real objects."],["Campbell's Soup Cans","Warhol's 32 paintings of soup flavors."],["The Factory","Warhol's studio."],["Ben-Day dots","The dots of cheap color printing imitated by Lichtenstein."],["Soft sculpture","Oldenburg's sculptures of soft materials."]],
  w:"Pop Art brought advertising, comics, and celebrity into art, questioning the line between high and low culture in a consumer society.",
  src:["Pop art","Richard Hamilton (artist)","Jasper Johns","Robert Rauschenberg","Andy Warhol","Campbell's Soup Cans","Roy Lichtenstein"],
  q:[["Which collage is often called the first Pop artwork?","Just What Is It That Makes Today's Homes So Different, So Appealing?","Flag","Monogram","Whaam!"],
     ["Who painted flags and targets in encaustic?","Jasper Johns","Robert Rauschenberg","Andy Warhol","Roy Lichtenstein"],
     ["Whose drawing did Rauschenberg erase?","Willem de Kooning's","Jackson Pollock's","Jasper Johns's","Franz Kline's"],
     ["How many canvases are in Campbell's Soup Cans?","32","12","50","100"],
     ["Who painted comic-strip images like Whaam!?","Roy Lichtenstein","Andy Warhol","James Rosenquist","Tom Wesselmann"],
     ["Who designed the Sgt. Pepper album cover?","Peter Blake","David Hockney","Richard Hamilton","Andy Warhol"]]},

{ t:"Minimalism and Conceptual Art", s:"Less is more, and the idea is the art",
  sec:[
  ["Minimalism",[
    "Minimalism emerged in New York in the 1960s, rejecting Abstract Expressionism's personal gesture and emotion. Minimalists made simple, geometric, often repetitive objects from industrial materials, aiming to present objects as themselves, without symbolism or illusion. As the painter Frank Stella said of his work, “What you see is what you see.”",
    "Minimalism focused attention on the object, the space around it, and the viewer's physical experience of moving around it."]],
  ["Minimalist artists",[
    "Donald Judd (1928–1994) made boxes and “stacks” of metal and Plexiglas, often fabricated by factories, arranged at regular intervals; he later created a permanent installation of his works in Marfa, Texas. Dan Flavin made installations of commercial fluorescent light tubes. Carl Andre laid flat squares of metal or rows of bricks on the floor; in 1976 Britain's Tate Gallery provoked a newspaper outcry over its purchase of Equivalent VIII, 120 firebricks.",
    "Sol LeWitt made modular cube structures and wall drawings executed by assistants following his written instructions. Agnes Martin painted serene grids of faint pencil lines. Richard Serra made massive curving walls of weathering steel that viewers walk through, such as Torqued Ellipses."]],
  ["Conceptual art",[
    "Conceptual art, which developed in the late 1960s, held that the idea or concept behind a work is more important than its physical form or craftsmanship, and that a work might exist only as instructions, text, documentation, or an action. Sol LeWitt wrote in 1967 that “the idea becomes a machine that makes the art.”",
    "Joseph Kosuth's One and Three Chairs (1965) presents a real chair, a photograph of the chair, and a dictionary definition of “chair,” asking which is the real chair. On Kawara painted the date on canvases every day for decades in his Today series. Yoko Ono's book Grapefruit (1964) consisted of instructions such as “Imagine the clouds dripping.”"]],
  ["Art about institutions",[
    "Many conceptual artists critiqued the art world itself, its museums, markets, and power, an approach called institutional critique. Hans Haacke exposed the business and political connections of museum trustees; in 1971 the Guggenheim canceled his exhibition, which documented the real estate holdings of a New York slumlord.",
    "Daniel Buren placed his signature stripes in and outside institutions, and later, artists such as Andrea Fraser and Fred Wilson, whose Mining the Museum (1992) rearranged a historical society's collection to reveal histories of slavery, continued this approach."]],
  ["Arte Povera and Fluxus",[
    "In Italy, Arte Povera (“poor art”), named in 1967, used humble materials such as soil, rags, twigs, and stones; Michelangelo Pistoletto's Venus of the Rags places a classical statue before a heap of old clothes. Jannis Kounellis exhibited live horses in a gallery in 1969.",
    "Fluxus, an international network founded by George Maciunas in the early 1960s and including Yoko Ono, Nam June Paik, and Joseph Beuys, staged playful events and “happenings” blurring art and life. Allan Kaprow coined the term “happening” in 1959."]],
  ["Why it matters",[
    "Minimalism and Conceptual art radically expanded the definition of art, building on Duchamp: art could be an idea, an instruction, a set of industrial boxes, or a critique of the institutions that display it. They are often baffling to the public, provoking the question, “Is it art?”",
    "These movements shaped much of the art of the following decades, including installation, performance, and contemporary art that relies on context and ideas."]]
  ],
  terms:[["Minimalism","Simple geometric art of industrial materials from the 1960s."],["Specific object","Judd's term for objects that are neither painting nor sculpture."],["Equivalent VIII","Carl Andre's arrangement of 120 bricks."],["Conceptual art","Art in which the idea is primary."],["One and Three Chairs","Kosuth's work questioning representation."],["Institutional critique","Art that critiques museums and the art world."],["Arte Povera","Italian art using humble materials."]],
  w:"Minimalism and Conceptual art stripped art to its essentials and its ideas, expanding what art can be and questioning the institutions that define it.",
  src:["Minimalism (visual arts)","Donald Judd","Dan Flavin","Equivalent VIII","Conceptual art","One and Three Chairs","Arte Povera"],
  q:[["Who said What you see is what you see?","Frank Stella","Donald Judd","Carl Andre","Sol LeWitt"],
     ["Who made installations of fluorescent light tubes?","Dan Flavin","Donald Judd","Robert Morris","Richard Serra"],
     ["What is Equivalent VIII made of?","120 firebricks","Steel plates","Fluorescent tubes","Wooden boxes"],
     ["Who made One and Three Chairs?","Joseph Kosuth","Sol LeWitt","On Kawara","Lawrence Weiner"],
     ["Who wrote Grapefruit, a book of instructions?","Yoko Ono","Nam June Paik","George Maciunas","Allan Kaprow"],
     ["What does Arte Povera mean?","Poor art","New art","Free art","Popular art"]]},

{ t:"Performance, the Body, and Feminist Art", s:"Art as action and identity",
  sec:[
  ["Performance art",[
    "Performance art uses the artist's own body and actions, often live, as the medium. It has roots in Futurist and Dada events and became a major form from the 1960s. In Japan, the Gutai group (founded 1954) staged dramatic actions: Kazuo Shiraga painted with his feet while suspended from a rope and wrestled in mud.",
    "Yves Klein in Paris directed nude models covered in his patented International Klein Blue paint to press their bodies against canvases (Anthropometries, 1960). Performances are often ephemeral, surviving only in photographs, videos, and memories."]],
  ["Beuys and Abramović",[
    "The German artist Joseph Beuys (1921–1986) believed that “everyone is an artist” and that art could heal society, a concept he called “social sculpture.” In How to Explain Pictures to a Dead Hare (1965), his face covered in honey and gold leaf, he whispered about paintings to a dead hare; in I Like America and America Likes Me (1974), he spent three days in a gallery with a live coyote.",
    "The Serbian artist Marina Abramović (born 1946) has tested the limits of body and mind. In Rhythm 0 (1974) she stood passive for six hours with 72 objects, including a gun and a bullet, that the audience could use on her as they wished, revealing frightening human behavior. In The Artist Is Present (2010) at MoMA, she sat silently for over 700 hours as visitors took turns sitting across from her."]],
  ["Feminist art",[
    "The feminist art movement of the 1970s challenged the male-dominated art world and history, the exclusion of women artists, and stereotyped images of women. In 1971 the art historian Linda Nochlin published the influential essay “Why Have There Been No Great Women Artists?”, arguing that institutional barriers, not lack of talent, had kept women out.",
    "Judy Chicago's The Dinner Party (1974–1979), now at the Brooklyn Museum, is a triangular banquet table with 39 place settings honoring women from history and myth, with 999 more names on the tiled floor, using crafts such as embroidery and china painting long dismissed as “women's work.” Miriam Schapiro and Faith Ringgold, whose story quilts address race and gender, also championed craft."]],
  ["The body and identity",[
    "Carolee Schneemann's Interior Scroll (1975) and Hannah Wilke's works used the female body to challenge objectification. The Cuban-American Ana Mendieta created Siluetas, imprints of her body in earth, mud, and fire.",
    "The anonymous Guerrilla Girls, founded in New York in 1985 and wearing gorilla masks, used posters to expose sexism and racism in the art world; one famous poster asked, “Do women have to be naked to get into the Met. Museum?” noting that less than 5 percent of artists in the modern art sections were women but 85 percent of the nudes were female."]],
  ["Photography and identity",[
    "Cindy Sherman's Untitled Film Stills (1977–1980), 70 black-and-white photographs of herself posed as female stereotypes from imaginary B movies, examined how media construct femininity. Barbara Kruger combined found photographs with bold slogans in red and white, such as “Your body is a battleground” and “I shop therefore I am.”",
    "Since the 1980s, artists have explored identities of race, sexuality, and postcolonial experience, including Lorna Simpson, Carrie Mae Weems, Glenn Ligon, and Kara Walker, whose cut-paper silhouettes confront the history of slavery."]],
  ["Why it matters",[
    "Performance and feminist art made the body, identity, and lived experience central to art, and they changed museums, which have increasingly worked to collect and show art by women and artists of color.",
    "They also raised lasting questions about who gets to make art, who is represented, and how history is told."]]
  ],
  terms:[["Performance art","Art made through the artist's live actions."],["Gutai","A Japanese group of action-based art founded in 1954."],["Social sculpture","Beuys's idea of art transforming society."],["The Artist Is Present","Abramović's 2010 MoMA performance."],["The Dinner Party","Judy Chicago's installation honoring women."],["Guerrilla Girls","Anonymous feminist artists exposing art-world bias."],["Untitled Film Stills","Cindy Sherman's photographs of female stereotypes."]],
  w:"Performance and feminist art put the body and identity at the center of art and transformed who is included in art history.",
  src:["Performance art","Gutai group","Joseph Beuys","Marina Abramović","Feminist art movement","The Dinner Party","Guerrilla Girls"],
  q:[["Which Japanese group staged action art from 1954?","Gutai","Mono-ha","Fluxus","Hi-Red Center"],
     ["Who spent three days with a coyote in a gallery?","Joseph Beuys","Marina Abramović","Chris Burden","Vito Acconci"],
     ["What was Abramović's 2010 MoMA performance?","The Artist Is Present","Rhythm 0","Balkan Baroque","The Lovers"],
     ["Who wrote Why Have There Been No Great Women Artists?","Linda Nochlin","Lucy Lippard","Griselda Pollock","Judy Chicago"],
     ["Who created The Dinner Party?","Judy Chicago","Miriam Schapiro","Faith Ringgold","Louise Bourgeois"],
     ["Who made the Untitled Film Stills?","Cindy Sherman","Barbara Kruger","Sherrie Levine","Nan Goldin"]]},

{ t:"Land Art and Installation", s:"Art beyond the gallery and the object",
  sec:[
  ["Leaving the gallery",[
    "In the late 1960s and 1970s, some artists left the gallery to make art in the landscape, using earth, rocks, and natural processes, often on a vast scale in remote places. Land art (or Earth art) rejected the art market's treatment of art as a portable commodity.",
    "Robert Smithson's Spiral Jetty (1970), a 460-meter coil of black basalt rocks and earth extending into the reddish waters of the Great Salt Lake in Utah, is the most famous example; it was submerged for decades and reappears as water levels fall."]],
  ["Land art masters",[
    "Michael Heizer's Double Negative (1969–1970) consists of two huge trenches cut into a Nevada mesa, and his City, a mile-long complex of earthen forms in the Nevada desert, opened to limited visitors in 2022 after 50 years of work. Walter De Maria's The Lightning Field (1977) arrays 400 stainless-steel poles across a New Mexico plain to attract lightning.",
    "Nancy Holt's Sun Tunnels (1976) in Utah align four huge concrete tubes with the solstice sunrises and sunsets. James Turrell has spent decades transforming Roden Crater, an extinct volcano in Arizona, into a naked-eye observatory. British artists Richard Long and Andy Goldsworthy make subtler works by walking and arranging leaves, ice, and stones, often documented in photographs."]],
  ["Christo and Jeanne-Claude",[
    "Christo and Jeanne-Claude, a couple born on the same day in 1935, created temporary, monumental projects wrapping buildings and landscapes in fabric, financed by selling preparatory drawings. They wrapped the Reichstag in Berlin (1995) and the Pont Neuf in Paris (1985), and installed The Gates in New York's Central Park (2005), 7,503 saffron fabric gates.",
    "Their projects, which took years of negotiation, existed for only days or weeks; the process, involving the public and authorities, was part of the work. L'Arc de Triomphe, Wrapped was realized in 2021, after Christo's death."]],
  ["Installation art",[
    "Installation art creates immersive environments that viewers enter, rather than objects they look at. It has roots in Kurt Schwitters's Merzbau and Duchamp's exhibition designs and became a dominant contemporary form.",
    "Yayoi Kusama (born 1929), a Japanese artist who worked in New York in the 1960s, creates Infinity Mirror Rooms filled with lights or polka-dotted forms reflected endlessly, drawing huge crowds. Louise Bourgeois (1911–2010) made the Cells, room-like enclosures filled with objects evoking memory and trauma, and Maman, a giant bronze spider nearly 9 meters high, a tribute to her mother, a tapestry restorer."]],
  ["Light, space, and experience",[
    "Light and Space artists in California, such as James Turrell and Robert Irwin, made installations of pure light and perception. Olafur Eliasson's The Weather Project (2003) filled Tate Modern's vast Turbine Hall with a glowing artificial sun and mist, and visitors lay on the floor looking at their reflections in a mirrored ceiling.",
    "Ilya Kabakov created “total installations” evoking Soviet life, and Bill Viola made immersive video installations. Installation art emphasizes the viewer's bodily experience and participation."]],
  ["Site-specific and public art",[
    "Site-specific art is made for a particular place and loses meaning if moved. Richard Serra's Tilted Arc (1981), a 37-meter steel wall in a New York federal plaza, was removed in 1989 after office workers complained it obstructed their path; Serra argued that removing it destroyed it.",
    "Public art today ranges from Anish Kapoor's Cloud Gate in Chicago and Antony Gormley's Angel of the North in England to temporary interventions and community projects, raising questions about who decides what art occupies public space."]]
  ],
  terms:[["Land art","Art made in and from the landscape."],["Spiral Jetty","Smithson's rock coil in the Great Salt Lake."],["The Lightning Field","De Maria's array of steel poles in New Mexico."],["Wrapping","Christo and Jeanne-Claude's temporary fabric projects."],["Installation art","Immersive environments viewers enter."],["Infinity Mirror Room","Kusama's installations of endless reflections."],["Site-specific art","Art made for a particular place."]],
  w:"Land art and installation took art out of the frame and the gallery, turning landscapes and rooms into experiences.",
  src:["Land art","Spiral Jetty","The Lightning Field","Christo and Jeanne-Claude","Installation art","Yayoi Kusama","Tilted Arc"],
  q:[["Who made Spiral Jetty?","Robert Smithson","Michael Heizer","Walter De Maria","Nancy Holt"],
     ["Where is Spiral Jetty?","The Great Salt Lake, Utah","Nevada","New Mexico","Arizona"],
     ["What did Christo and Jeanne-Claude wrap in Berlin in 1995?","The Reichstag","The Brandenburg Gate","The Berlin Wall","The Pergamon Museum"],
     ["Who creates Infinity Mirror Rooms?","Yayoi Kusama","Louise Bourgeois","Olafur Eliasson","Ilya Kabakov"],
     ["Who made the giant spider Maman?","Louise Bourgeois","Kusama","Anish Kapoor","Claes Oldenburg"],
     ["Which steel sculpture was removed from a New York plaza in 1989?","Tilted Arc","Cloud Gate","Torqued Ellipse","Double Negative"]]}

]});


/* ---- from arts-16.js ---- */
/* ARTS FOUNDATIONS, part 16: Unit 9 chapters 6-11 */
COURSES.arts.units[8].ch.push(

{ t:"Postmodernism and the 1980s", s:"Appropriation, painting's return, and art in crisis",
  sec:[
  ["What is postmodernism?",[
    "Postmodernism, which emerged in the 1970s and 1980s, rejected modernism's belief in progress, originality, purity, and a single story of art moving toward abstraction. Postmodern artists mixed styles, borrowed images, embraced irony, pastiche, and popular culture, and questioned ideas of authorship, truth, and originality, influenced by theorists such as Roland Barthes, who announced “the death of the author,” and Jean Baudrillard, who wrote of a world of simulations.",
    "In architecture, postmodernism brought back color, ornament, and historical references, as in Philip Johnson's AT&T Building in New York (1984), topped with a broken pediment like a Chippendale cabinet."]],
  ["Appropriation",[
    "Appropriation artists deliberately copied existing images to question originality and ownership. Sherrie Levine rephotographed Walker Evans's Depression-era photographs and exhibited them as After Walker Evans (1981). Richard Prince rephotographed Marlboro cigarette advertisements showing cowboys, which later sold for millions.",
    "The “Pictures Generation,” including Cindy Sherman, Barbara Kruger, Louise Lawler, and Robert Longo, examined how images from media shape identity and desire. Appropriation has led to legal disputes over copyright and fair use."]],
  ["The return of painting",[
    "Around 1980, after years of Minimalism and Conceptualism, expressive figurative painting returned in force, called Neo-Expressionism. In Germany, Georg Baselitz painted figures upside down, Anselm Kiefer painted huge, scorched landscapes incorporating straw, lead, and ash to confront German history and the Holocaust, and Gerhard Richter moved between blurred photo-paintings and abstraction.",
    "In Italy, the Transavanguardia, and in the United States, Julian Schnabel, who painted on broken plates, and David Salle became art-market stars. The booming market of the 1980s turned young artists into celebrities."]],
  ["Basquiat and Haring",[
    "Jean-Michel Basquiat (1960–1988), of Haitian and Puerto Rican descent, began as a graffiti writer under the tag SAMO© in New York and rose rapidly to fame with raw, energetic paintings combining words, crowns, skulls, anatomical drawings, and references to Black history, jazz, boxing, and street life. He collaborated with Warhol and died of an overdose at 27. An untitled 1982 skull painting sold for about 110.5 million dollars in 2017.",
    "Keith Haring (1958–1990) drew chalk figures on black paper covering unused advertising panels in the New York subway, then developed a joyful, cartoon-like style of radiant babies, barking dogs, and dancing figures, opening his Pop Shop to sell affordable merchandise. He used art for activism against AIDS, which took his life at 31."]],
  ["Art and the AIDS crisis",[
    "The AIDS epidemic devastated the art world in the 1980s and 1990s, killing many artists. Activist collectives such as ACT UP and Gran Fury created graphic campaigns such as Silence = Death, with a pink triangle. Félix González-Torres made poignant minimal works such as Untitled (Portrait of Ross in L.A.) (1991), a pile of individually wrapped candies weighing about 79 kilograms, his partner's healthy body weight, which visitors take from, so the pile diminishes as Ross's body did.",
    "David Wojnarowicz made angry, passionate works about illness, sexuality, and government neglect."]],
  ["Culture wars and the Young British Artists",[
    "In the United States, controversies erupted in 1989–1990 over public funding for works by Andres Serrano and Robert Mapplethorpe, the “culture wars,” leading to debates over censorship and the National Endowment for the Arts.",
    "In Britain in the 1990s, the Young British Artists (YBAs), promoted by the collector Charles Saatchi, gained notoriety with shocking works: Damien Hirst's tiger shark preserved in formaldehyde, The Physical Impossibility of Death in the Mind of Someone Living (1991); Tracey Emin's My Bed (1998), her unmade bed surrounded by debris; and Rachel Whiteread's House (1993), a concrete cast of the interior of an East London terraced house."]]
  ],
  terms:[["Postmodernism","A movement rejecting modernist ideas of originality and progress."],["Appropriation","Deliberately copying existing images."],["Pictures Generation","Artists examining media images in the late 1970s–80s."],["Neo-Expressionism","The return of expressive figurative painting around 1980."],["SAMO©","Basquiat's early graffiti tag."],["Culture wars","Debates over controversial art and public funding."],["Young British Artists","Provocative British artists of the 1990s."]],
  w:"Postmodernism and the 1980s questioned originality, revived painting, and brought art into debates about identity, AIDS, censorship, and money.",
  src:["Postmodern art","Appropriation (art)","Pictures Generation","Neo-expressionism","Jean-Michel Basquiat","Keith Haring","Young British Artists"],
  q:[["Who announced the death of the author?","Roland Barthes","Jean Baudrillard","Michel Foucault","Jacques Derrida"],
     ["Who rephotographed Walker Evans's photographs?","Sherrie Levine","Richard Prince","Cindy Sherman","Louise Lawler"],
     ["Which German painter paints figures upside down?","Georg Baselitz","Anselm Kiefer","Gerhard Richter","Sigmar Polke"],
     ["What was Basquiat's graffiti tag?","SAMO©","TAKI 183","REVS","CRASH"],
     ["Whose candy pile represents his partner's body weight?","Félix González-Torres","David Wojnarowicz","Keith Haring","Robert Gober"],
     ["Who made a shark preserved in formaldehyde?","Damien Hirst","Tracey Emin","Rachel Whiteread","Chris Ofili"]]},

{ t:"Street Art and Graffiti", s:"From subway cars to museums",
  sec:[
  ["Graffiti's long history",[
    "Writing and drawing on walls is ancient: Roman graffiti survives on the walls of Pompeii, including political slogans, insults, and love messages. Modern graffiti writing, however, emerged in Philadelphia and New York in the late 1960s and 1970s, when teenagers began writing their names, called tags, across the city. TAKI 183, a Greek American teenager from Washington Heights, became famous after a 1971 New York Times article.",
    "Writers soon covered entire subway cars with elaborate, colorful “pieces” (masterpieces) in stylized lettering such as “wildstyle,” spreading their names across the city. Graffiti became part of hip-hop culture, alongside DJing, MCing, and breakdancing."]],
  ["Crime or art?",[
    "New York's authorities treated graffiti as vandalism and a symbol of urban decay, spending millions to clean subway cars; by 1989 the subway was declared graffiti-free. At the same time, galleries in the early 1980s began exhibiting graffiti artists such as Lee Quiñones, Lady Pink, Fab 5 Freddy, and Futura 2000 on canvas.",
    "The tension between illegal street practice and the art market remains central to street art."]],
  ["Street art",[
    "From the 1990s, street art expanded beyond lettering to include stencils, stickers, posters, murals, mosaics, and installations. Shepard Fairey's sticker campaign OBEY GIANT featured the face of the wrestler André the Giant, and he later created the Hope poster (2008) of Barack Obama, now in the National Portrait Gallery.",
    "The French artist Invader installs pixelated tile mosaics inspired by the video game Space Invaders on buildings in cities worldwide, and JR pastes huge photographic portraits on walls, rooftops, and border fences, such as on the separation barrier between Israel and the West Bank."]],
  ["Banksy",[
    "Banksy, an anonymous artist from Bristol, England, became the world's most famous street artist with witty, politically charged stencils: a girl releasing a red heart-shaped balloon, a protester throwing a bouquet of flowers, kissing policemen, and rats. He has painted on the West Bank barrier and opened the Walled Off Hotel in Bethlehem (2017).",
    "In 2018, moments after Girl with Balloon sold at Sotheby's for over a million pounds, a shredder hidden in the frame partly shredded it; renamed Love Is in the Bin, it resold in 2021 for about 18.6 million pounds. Banksy's identity remains officially unconfirmed."]],
  ["Murals and communities",[
    "Mural traditions continue worldwide, from the Mexican muralists to political murals in Northern Ireland and community murals in Philadelphia, whose Mural Arts Program, begun in 1984, has created thousands. Wynwood Walls in Miami and festivals in cities around the world invite artists to paint large walls.",
    "Brazilian twins Os Gêmeos paint giant yellow-skinned figures, and Lisbon, Berlin, and Melbourne are famous for street art. The Berlin Wall's eastern side, the East Side Gallery, is covered with murals painted in 1990."]],
  ["Questions",[
    "Street art raises questions about public space, property, legality, and commercialization. Some argue it democratizes art, bringing it to everyone for free; others see it as vandalism. When street works are removed from walls and sold, or when murals contribute to gentrification and rising rents, debates intensify.",
    "In 2018, a U.S. court awarded 6.75 million dollars to graffiti artists whose works at 5Pointz, a Queens warehouse, were whitewashed by the owner, recognizing street art's legal protection under the Visual Artists Rights Act."]]
  ],
  terms:[["Tag","A graffiti writer's stylized signature."],["Piece","A large, elaborate graffiti work."],["Wildstyle","An intricate, interlocking graffiti lettering style."],["Stencil","A cut template for spraying images."],["Banksy","The anonymous Bristol street artist."],["Mural","A large painting on a wall."],["5Pointz","A Queens graffiti site whose destruction led to a landmark ruling."]],
  w:"Street art and graffiti moved from illegal subway tags to global museums, raising questions about public space, ownership, and who art is for.",
  src:["Graffiti","TAKI 183","Street art","Shepard Fairey","Banksy","Love Is in the Bin","5 Pointz"],
  q:[["Where was ancient Roman graffiti preserved?","Pompeii","Athens","Carthage","Alexandria"],
     ["Which teenage tagger became famous after a 1971 New York Times article?","TAKI 183","Lee Quiñones","Futura 2000","Fab 5 Freddy"],
     ["Who created the Obama Hope poster?","Shepard Fairey","Banksy","JR","Invader"],
     ["What happened to Banksy's Girl with Balloon at auction in 2018?","It was partly shredded","It was stolen","It was withdrawn","It sold for one pound"],
     ["Which street artist installs tile mosaics inspired by a video game?","Invader","JR","Os Gêmeos","Blek le Rat"],
     ["What is the painted stretch of the Berlin Wall called?","The East Side Gallery","Checkpoint Charlie","The Wall Museum","The Mauerpark"]]},

{ t:"Global Contemporary Art", s:"Art in a connected world",
  sec:[
  ["A global art world",[
    "Since the 1990s, the art world has become truly global. Biennials, large recurring international exhibitions, have multiplied, from Venice (founded 1895) and São Paulo (1951) to Havana, Istanbul, Gwangju, Dakar, Sharjah, and Shanghai. Documenta in Kassel, Germany, held every five years since 1955, is another major showcase.",
    "Artists from Africa, Asia, Latin America, and the Middle East have gained international prominence, and museums such as Tate Modern (opened 2000 in a former London power station) and new institutions in the Gulf and Asia have broadened their collections. Contemporary art often addresses globalization, migration, identity, colonial history, and the environment."]],
  ["China",[
    "After the Cultural Revolution and the opening of China, a vibrant contemporary art scene emerged. Cai Guo-Qiang makes art with gunpowder explosions and designed fireworks for the 2008 Beijing Olympics. Xu Bing's Book from the Sky (1987–1991) consists of thousands of invented, unreadable Chinese characters printed with hand-carved blocks.",
    "Ai Weiwei (born 1957), artist and activist, filled Tate Modern's Turbine Hall in 2010 with Sunflower Seeds, about 100 million handmade porcelain seeds painted by craftspeople in Jingdezhen. He has criticized the Chinese government, was detained in 2011, and has made works about refugees and human rights."]],
  ["Africa and the diaspora",[
    "The Ghanaian sculptor El Anatsui (born 1944) transforms thousands of flattened aluminum bottle caps, from liquor bottles, linked with copper wire, into shimmering, flexible wall hangings that evoke West African kente cloth and the history of trade, including the slave trade. The Nigerian-British artist Yinka Shonibare uses Dutch wax-print fabrics, associated with Africa but originating in Indonesian batik and European manufacturing, to explore colonialism and identity.",
    "The South African William Kentridge makes animated films from charcoal drawings repeatedly erased and redrawn, addressing apartheid and memory. Kehinde Wiley painted the official portrait of Barack Obama (2018), and Amy Sherald painted Michelle Obama. Julie Mehretu's vast abstract paintings layer architectural plans and maps."]],
  ["Japan, Korea, and South Asia",[
    "Japanese artist Takashi Murakami developed “Superflat,” combining traditional Japanese flat painting with anime, manga, and consumer culture, and collaborated with fashion brands. Yoshitomo Nara paints mischievous children. The Korean artist Do Ho Suh makes translucent fabric replicas of the homes he has lived in, evoking memory and migration.",
    "Indian artists such as Subodh Gupta, who makes sculptures from stainless steel kitchen utensils, and Anish Kapoor, British-Indian, whose reflective Cloud Gate and void works fascinate audiences, have achieved international recognition. Shirin Neshat, an Iranian-born artist, photographed women in chadors with calligraphy inscribed on their skin in her series Women of Allah."]],
  ["Latin America and the Middle East",[
    "Latin American artists have contributed powerfully to contemporary art. Doris Salcedo of Colombia makes works about political violence and mourning, such as Shibboleth (2007), a crack running the length of Tate Modern's Turbine Hall floor. Gabriel Orozco of Mexico, Cildo Meireles and Beatriz Milhazes of Brazil, and Teresa Margolles of Mexico are prominent.",
    "Artists from the Middle East, such as Mona Hatoum, born in Beirut to a Palestinian family, explore displacement, the body, and conflict. The Louvre Abu Dhabi (2017) symbolizes the region's growing role in the art world."]],
  ["Questions for today",[
    "Contemporary art is enormously diverse, with no single dominant style. Key questions include how to tell art history globally rather than from a Western perspective, how to address colonial histories and restitution, how markets and wealthy collectors shape art, and how art can respond to climate change, inequality, and technology.",
    "Many contemporary artists work collaboratively and socially, making “relational” art that creates encounters between people, as when Rirkrit Tiravanija cooked and served Thai curry in galleries."]]
  ],
  terms:[["Biennial","A large international exhibition held every two years."],["Documenta","The major exhibition held every five years in Kassel."],["Tate Modern","London's museum of modern art opened in 2000."],["Sunflower Seeds","Ai Weiwei's installation of 100 million porcelain seeds."],["El Anatsui","A Ghanaian sculptor using bottle caps."],["Superflat","Murakami's fusion of Japanese art and pop culture."],["Relational art","Art creating social encounters."]],
  w:"Global contemporary art reflects a connected world, with artists from every continent addressing identity, history, migration, and power.",
  src:["Contemporary art","Venice Biennale","Documenta","Ai Weiwei","El Anatsui","Takashi Murakami","Doris Salcedo"],
  q:[["When was the Venice Biennale founded?","1895","1955","1951","1972"],
     ["How often is Documenta held?","Every five years","Every two years","Every year","Every ten years"],
     ["Who filled the Turbine Hall with porcelain sunflower seeds?","Ai Weiwei","Cai Guo-Qiang","Xu Bing","Zhang Huan"],
     ["What does El Anatsui use to make his wall hangings?","Bottle caps","Wax-print fabric","Plastic bags","Glass beads"],
     ["Who painted Barack Obama's official portrait?","Kehinde Wiley","Amy Sherald","Kerry James Marshall","Mickalene Thomas"],
     ["Who developed Superflat?","Takashi Murakami","Yoshitomo Nara","Yayoi Kusama","Hiroshi Sugimoto"]]},

{ t:"Video, Digital, and New Media Art", s:"Screens, code, and the internet",
  sec:[
  ["Video art",[
    "Video art began in the 1960s with the arrival of portable video cameras such as the Sony Portapak (1967). The Korean-American artist Nam June Paik, often called the father of video art, manipulated television sets with magnets, made TV Buddha (1974), in which a statue of the Buddha contemplates its own image on a TV, and created Electronic Superhighway, a map of the United States made of hundreds of TV monitors.",
    "Bruce Nauman recorded himself performing repetitive actions in his studio, and Joan Jonas and Vito Acconci explored the body and the camera. Bill Viola created slow-motion, emotionally intense video installations with water and fire, such as The Crossing."]],
  ["Expanded screens",[
    "Contemporary artists use moving images in installations and cinemas. Christian Marclay's The Clock (2010) is a 24-hour montage of thousands of film clips showing clocks and watches, synchronized to the actual time, so it functions as a working clock.",
    "Steve McQueen, a British artist who won the Turner Prize in 1999, also became an Oscar-winning film director with 12 Years a Slave (2013). Pipilotti Rist creates dreamy, colorful video environments, and Arthur Jafa's Love Is the Message, the Message Is Death (2016) edits found footage into a powerful meditation on Black American life."]],
  ["Computer and digital art",[
    "Artists began using computers in the 1960s, writing programs to generate drawings: pioneers included Vera Molnár, Frieder Nake, and Harold Cohen, whose program AARON, begun around 1973, made drawings and paintings for decades. Generative art uses rules, algorithms, or randomness to create works.",
    "Digital tools such as Photoshop (1990) transformed photography and design, and 3D modeling and printing, virtual reality, and video games have become artistic media."]],
  ["Net art and NFTs",[
    "In the 1990s, net art used the internet itself as a medium, as in the collective JODI's chaotic websites. Artists have since explored social media, surveillance, and online identity; Amalia Ulman staged a fictional Instagram life in Excellences & Perfections (2014).",
    "In 2021, non-fungible tokens (NFTs), blockchain certificates of ownership for digital files, created a speculative boom: the digital artist Beeple's collage Everydays: The First 5000 Days sold at Christie's for about 69 million dollars. The NFT market declined sharply afterward, but debates about digital ownership continue."]],
  ["Artificial intelligence",[
    "Artificial intelligence has become a new artistic tool and subject. In 2018 a portrait generated by an algorithm, Edmond de Belamy, created by the French collective Obvious, sold at Christie's for about 432,500 dollars. Artists such as Refik Anadol create immersive data-driven installations, and Holly Herndon has worked with AI-generated voices.",
    "Generative AI image tools, widely available from 2022, raised intense debates about authorship, creativity, copyright, the use of artists' work to train models without permission, and the future of creative work."]],
  ["Old questions, new media",[
    "New media art often revisits questions first raised by photography, film, and Duchamp: what is the role of the artist's hand, what makes a work original, and how technology changes perception.",
    "Preserving new media art is a major challenge, as hardware and software become obsolete; museums now employ specialists to maintain video and digital works."]]
  ],
  terms:[["Video art","Art using video technology, from the 1960s."],["Nam June Paik","The father of video art."],["The Clock","Marclay's 24-hour montage synchronized to real time."],["Generative art","Art made using rules, algorithms, or randomness."],["Net art","Art using the internet as a medium."],["NFT","A blockchain token certifying ownership of a digital file."],["AI art","Art made with artificial intelligence."]],
  w:"Video, digital, and AI art show how artists use each new technology to explore perception, identity, and the meaning of creativity itself.",
  src:["Video art","Nam June Paik","The Clock (2010 film)","Generative art","Net art","Everydays: the First 5000 Days","Artificial intelligence art"],
  q:[["Who is often called the father of video art?","Nam June Paik","Bill Viola","Bruce Nauman","Andy Warhol"],
     ["Which portable video camera appeared in 1967?","The Sony Portapak","The Leica","The Bolex","The Super 8"],
     ["What is Christian Marclay's The Clock?","A 24-hour film montage synchronized to real time","A sculpture","A painting of clocks","A sound installation"],
     ["Which artist won the Turner Prize and an Oscar?","Steve McQueen","Bill Viola","Arthur Jafa","Douglas Gordon"],
     ["What was Harold Cohen's art-making program called?","AARON","DALL-E","Belamy","ELIZA"],
     ["Whose NFT sold for about 69 million dollars in 2021?","Beeple","Refik Anadol","Pak","Obvious"]]},

{ t:"Film as Art: The Silent Era to the Studio Age", s:"The seventh art",
  sec:[
  ["The birth of cinema",[
    "Cinema grew from photography and inventions that created the illusion of motion. On 28 December 1895, the Lumière brothers, Auguste and Louis, held the first public screening of films for a paying audience in Paris, using their Cinématographe; their short films included Workers Leaving the Lumière Factory and the arrival of a train at La Ciotat station. Thomas Edison's company had developed the Kinetoscope, a peephole viewer, a few years earlier.",
    "The Italian critic Ricciotto Canudo called cinema the “seventh art” in 1911, adding it to architecture, sculpture, painting, music, dance, and poetry."]],
  ["Méliès and storytelling",[
    "Georges Méliès, a magician, discovered special effects such as stop-motion substitution and multiple exposures and made fantastical films, most famously A Trip to the Moon (1902), with a rocket landing in the Moon's eye. Edwin S. Porter's The Great Train Robbery (1903) developed narrative editing.",
    "D. W. Griffith developed the language of film, close-ups, crosscutting between scenes, and long shots, but his epic The Birth of a Nation (1915) glorified the Ku Klux Klan and promoted racist stereotypes, provoking protests. Oscar Micheaux, the most important early African American filmmaker, responded with films such as Within Our Gates (1920)."]],
  ["Silent masterpieces",[
    "The 1920s were the golden age of silent film. Charlie Chaplin created the Little Tramp, combining comedy and pathos in The Kid (1921), The Gold Rush (1925), and City Lights (1931). Buster Keaton performed astonishing stunts with a stone face in The General (1926).",
    "In Germany, Expressionist films such as The Cabinet of Dr. Caligari (1920) and F. W. Murnau's Nosferatu (1922) used distorted sets and shadows, and Fritz Lang's Metropolis (1927) imagined a futuristic city divided between rich and workers. In the Soviet Union, Sergei Eisenstein developed montage, the editing of shots to create meaning and emotion, in Battleship Potemkin (1925), whose Odessa Steps sequence is one of the most studied scenes in film history."]],
  ["Sound and the studios",[
    "The Jazz Singer (1927) introduced synchronized dialogue, and within a few years sound films replaced silents. Hollywood's studio system, dominated by companies such as MGM, Paramount, Warner Bros., and 20th Century Fox, produced hundreds of films a year in genres such as the musical, gangster film, western, screwball comedy, and horror, with stars under contract.",
    "Technicolor brought vivid color, as in The Wizard of Oz and Gone with the Wind (both 1939). Walt Disney's Snow White and the Seven Dwarfs (1937) was the first full-length cel-animated feature film in English."]],
  ["Citizen Kane and the auteur",[
    "Orson Welles's Citizen Kane (1941), about a newspaper magnate modeled partly on William Randolph Hearst, used deep-focus cinematography by Gregg Toland, low camera angles, complex flashbacks, and innovative sound; it has often topped critics' lists of the greatest films ever made.",
    "Alfred Hitchcock, the “Master of Suspense,” made films in Britain and Hollywood such as Rear Window, Vertigo (1958), which topped the 2012 Sight and Sound critics' poll, and Psycho (1960). Directors such as John Ford, with westerns like The Searchers, and Howard Hawks showed that studio filmmakers could be artists with personal visions."]],
  ["Why film is art",[
    "Like painting, film uses composition, light, color, and framing; like theater, performance; like literature, narrative; and like music, rhythm and time. Its unique tools include the camera's movement, editing, and the combination of sound and image.",
    "Understanding film form, how shots, cuts, camera angles, lighting, and sound create meaning, deepens appreciation of cinema, the most popular art form of the modern age."]]
  ],
  terms:[["Seventh art","A name for cinema coined in 1911."],["Cinématographe","The Lumière brothers' camera and projector."],["A Trip to the Moon","Méliès's 1902 fantasy film."],["Montage","Editing shots to create meaning, developed by Eisenstein."],["Studio system","Hollywood's system of vertically integrated film production."],["Deep focus","Cinematography keeping near and far objects sharp."],["Auteur","A director with a personal artistic vision."]],
  w:"Film became the defining art of the 20th century, and understanding its history and language reveals how moving images shape stories and emotions.",
  src:["History of film","Auguste and Louis Lumière","A Trip to the Moon","Battleship Potemkin","Classical Hollywood cinema","Citizen Kane","Alfred Hitchcock"],
  q:[["Who held the first public paid film screening in 1895?","The Lumière brothers","Thomas Edison","Georges Méliès","D. W. Griffith"],
     ["Who made A Trip to the Moon?","Georges Méliès","Edwin S. Porter","The Lumières","Fritz Lang"],
     ["Who developed montage in Battleship Potemkin?","Sergei Eisenstein","Dziga Vertov","Fritz Lang","F. W. Murnau"],
     ["Which film introduced synchronized dialogue in 1927?","The Jazz Singer","Metropolis","City Lights","Sunrise"],
     ["Who directed Citizen Kane?","Orson Welles","John Ford","Howard Hawks","Alfred Hitchcock"],
     ["Which film topped the 2012 Sight and Sound critics' poll?","Vertigo","Citizen Kane","Psycho","Tokyo Story"]]},

{ t:"Film as Art: World Cinema and Beyond", s:"New waves, masters, and the modern screen",
  sec:[
  ["Italian Neorealism",[
    "After World War II, Italian Neorealist filmmakers shot on real locations with non-professional actors to depict the struggles of ordinary people in a devastated country. Roberto Rossellini's Rome, Open City (1945) and Vittorio De Sica's Bicycle Thieves (1948), about a poor man searching for his stolen bicycle, needed for his job, became landmarks.",
    "Later Italian masters included Federico Fellini, whose La Dolce Vita (1960) and 8½ (1963) combined spectacle and dreamlike autobiography, and Michelangelo Antonioni, whose films explored alienation."]],
  ["Japanese cinema",[
    "Akira Kurosawa's Rashomon (1950), which tells the story of a crime from contradictory perspectives, won the Golden Lion at Venice and introduced Japanese cinema to the world. His Seven Samurai (1954) influenced countless action films, including Westerns.",
    "Yasujirō Ozu made quiet family dramas with low, static camera positions, such as Tokyo Story (1953), which topped the 2012 Sight and Sound directors' poll, and Kenji Mizoguchi made elegant, long-take historical films. Later, Hayao Miyazaki's Studio Ghibli made animated films such as Spirited Away (2001), which won the Academy Award."]],
  ["The French New Wave",[
    "In the late 1950s, young French critics from the magazine Cahiers du Cinéma, who championed the idea of the director as auteur, began making films with low budgets, handheld cameras, location shooting, and jump cuts. François Truffaut's The 400 Blows (1959) and Jean-Luc Godard's Breathless (1960) launched the Nouvelle Vague (New Wave).",
    "Agnès Varda, sometimes called the grandmother of the New Wave, made Cléo from 5 to 7 (1962). The New Wave's freedom inspired new cinemas worldwide, including the New Hollywood of the late 1960s and 1970s."]],
  ["Masters around the world",[
    "Ingmar Bergman of Sweden explored faith, death, and relationships in The Seventh Seal (1957), with a knight playing chess with Death, and Persona (1966). India's Satyajit Ray made the Apu Trilogy, beginning with Pather Panchali (1955), and India's Bollywood industry produces more films than any other country. Andrei Tarkovsky made meditative Soviet films such as Stalker (1979).",
    "Later decades brought celebrated cinemas from Iran, such as Abbas Kiarostami's films, from China, including Zhang Yimou and Wong Kar-wai of Hong Kong, whose In the Mood for Love (2000) is admired for its visual beauty, and from South Korea, whose Parasite (2019), by Bong Joon-ho, became the first non-English-language film to win the Academy Award for Best Picture."]],
  ["New Hollywood and the blockbuster",[
    "In the late 1960s and 1970s, as the studio system collapsed, directors such as Francis Ford Coppola (The Godfather, 1972), Martin Scorsese (Taxi Driver, 1976), Stanley Kubrick (2001: A Space Odyssey, 1968), and Robert Altman made personal, daring films for major studios.",
    "Steven Spielberg's Jaws (1975) and George Lucas's Star Wars (1977) launched the era of the blockbuster, big-budget spectacles with special effects and merchandising. Computer-generated imagery, pioneered in films like Jurassic Park (1993) and Pixar's Toy Story (1995), the first fully computer-animated feature, transformed filmmaking."]],
  ["Film today",[
    "Digital cameras, streaming services, and global audiences have transformed how films are made and watched. Documentary films, independent cinema, and filmmakers from previously underrepresented groups have gained prominence, while debates about theatrical versus streaming release continue.",
    "Watching films attentively, noticing how directors use framing, editing, light, color, sound, and performance, connects cinema to the long history of visual art covered in this course."]]
  ],
  terms:[["Italian Neorealism","Postwar films of ordinary life shot on location."],["Rashomon","Kurosawa's film of contradictory perspectives."],["French New Wave","The innovative French cinema of the late 1950s–60s."],["Cahiers du Cinéma","The French magazine that championed auteurs."],["Jump cut","An abrupt cut within a continuous shot."],["Blockbuster","A big-budget, mass-market film."],["CGI","Computer-generated imagery."]],
  w:"World cinema's movements and masters show film's power as an international art, from Neorealism and the New Wave to today's global screen.",
  src:["Italian neorealism","Akira Kurosawa","Yasujirō Ozu","French New Wave","Ingmar Bergman","Satyajit Ray","Parasite (2019 film)"],
  q:[["Who directed Bicycle Thieves?","Vittorio De Sica","Roberto Rossellini","Federico Fellini","Luchino Visconti"],
     ["Which Kurosawa film tells a crime from contradictory perspectives?","Rashomon","Seven Samurai","Ikiru","Ran"],
     ["Which film launched the French New Wave with Breathless?","The 400 Blows","Jules and Jim","Hiroshima mon amour","Contempt"],
     ["Who made The Seventh Seal?","Ingmar Bergman","Andrei Tarkovsky","Carl Dreyer","Michelangelo Antonioni"],
     ["Which was the first non-English film to win Best Picture?","Parasite","Roma","Crouching Tiger, Hidden Dragon","Life Is Beautiful"],
     ["What was the first fully computer-animated feature?","Toy Story","Jurassic Park","Shrek","Tron"]]}

);


/* ---- from arts-17.js ---- */
/* ARTS FOUNDATIONS, part 17: Unit 10 Art Beyond Europe, chapters 1-5 */
COURSES.arts.units.push({ t:"Art of Asia, Africa, the Islamic World, and the Americas", ch:[

{ t:"Islamic Art and Architecture", s:"Mosques, palaces, and sacred space",
  sec:[
  ["What is Islamic art?",[
    "Islamic art refers to the art produced in lands where Islam was the dominant religion or rulers were Muslim, from Spain to India and beyond, from the 7th century onward. It includes religious and secular works, made by Muslims and non-Muslims, and spans many regions and dynasties: Umayyad, Abbasid, Fatimid, Seljuk, Mamluk, Nasrid, Timurid, Safavid, Ottoman, and Mughal.",
    "In religious contexts, Islamic art generally avoids depicting people and animals, out of concern about idolatry, focusing instead on calligraphy, geometric patterns, and vegetal ornament called arabesque. Secular art, however, often included figurative images, especially in book painting."]],
  ["The mosque",[
    "The mosque (masjid, “place of prostration”) is the central building of Islam. Its essential features include the qibla wall facing Mecca, with a niche called the mihrab indicating the direction of prayer; a minbar, a pulpit for the Friday sermon; a courtyard with a fountain for ablutions; and often minarets, towers from which the call to prayer is given.",
    "The Dome of the Rock in Jerusalem (completed 691), an octagonal shrine with a golden dome over the rock from which, in Islamic tradition, Muhammad ascended to heaven, is the oldest surviving major Islamic monument, decorated with mosaics and Quranic inscriptions. The Great Mosque of Damascus (705–715) and the hypostyle Great Mosque of Córdoba, begun in 785, with its forest of double-tiered red-and-white arches, are early masterpieces."]],
  ["Persian and Central Asian architecture",[
    "In Iran and Central Asia, architects developed the iwan, a vaulted hall open on one side, often arranged four around a courtyard, and covered buildings with glazed tiles in brilliant blues and turquoise. The Registan in Samarkand, a square framed by three madrasas, reflects the splendor of the Timurid dynasty.",
    "In Isfahan, Shah Abbas I of the Safavid dynasty built a vast square, the Naqsh-e Jahan (about 1598–1629), surrounded by the Shah Mosque, whose dome and portals are covered with tiles, the Sheikh Lotfollah Mosque, and the Ali Qapu palace. Muqarnas, honeycomb-like vaulting of small niches, creates dazzling effects in domes and portals."]],
  ["The Alhambra",[
    "The Alhambra in Granada, Spain, a palace-fortress of the Nasrid dynasty, the last Muslim rulers in Spain, was built mainly in the 14th century. Its plain exterior hides exquisite courtyards and halls, such as the Court of the Lions, with its fountain supported by twelve stone lions, and the Hall of the Two Sisters, with a muqarnas dome of thousands of cells.",
    "Walls are covered with carved stucco, tile mosaics, and calligraphic poetry, and water flows through channels and pools, evoking the gardens of paradise described in the Quran. Granada fell to Ferdinand and Isabella in 1492."]],
  ["Ottoman architecture",[
    "The Ottoman Empire, which conquered Constantinople in 1453, built great domed mosques inspired by Hagia Sophia. The architect Mimar Sinan (about 1490–1588), chief architect to Suleiman the Magnificent and his successors, designed over 300 buildings. The Süleymaniye Mosque in Istanbul (1550–1557) and the Selimiye Mosque in Edirne (1568–1575), whose dome he considered his masterpiece, create vast unified spaces under central domes framed by slender pencil-shaped minarets.",
    "The Blue Mosque (Sultan Ahmed Mosque, 1609–1616) is famous for its blue Iznik tiles. Ottoman decorative arts included Iznik ceramics with tulips and carnations and splendid textiles."]],
  ["The Taj Mahal",[
    "In India, the Mughal dynasty, descended from Timur and Genghis Khan, combined Persian, Central Asian, and Indian traditions. The Taj Mahal in Agra (about 1632–1653), built by the emperor Shah Jahan as a mausoleum for his beloved wife Mumtaz Mahal, who died in childbirth, is perhaps the most famous building in the world.",
    "Its white marble dome, inlaid with semiprecious stones in floral designs (pietra dura) and Quranic verses, rises above a raised platform with four minarets, at the end of a formal garden divided into four parts by water channels, a charbagh symbolizing paradise. It is a UNESCO World Heritage Site."]]
  ],
  terms:[["Arabesque","Flowing vegetal ornament in Islamic art."],["Mihrab","A niche indicating the direction of Mecca."],["Minaret","A tower for the call to prayer."],["Iwan","A vaulted hall open on one side."],["Muqarnas","Honeycomb-like vaulting."],["Alhambra","The Nasrid palace in Granada."],["Charbagh","A four-part paradise garden."]],
  w:"Islamic art and architecture created sacred and courtly spaces of extraordinary beauty across three continents, from Córdoba to the Taj Mahal.",
  src:["Islamic art","Islamic architecture","Dome of the Rock","Mosque–Cathedral of Córdoba","Alhambra","Mimar Sinan","Taj Mahal"],
  q:[["What is the niche indicating the direction of Mecca called?","Mihrab","Minbar","Iwan","Qibla"],
     ["What is the oldest surviving major Islamic monument?","The Dome of the Rock","The Great Mosque of Córdoba","The Kaaba","The Great Mosque of Damascus"],
     ["Which dynasty built the Alhambra?","The Nasrids","The Umayyads","The Almohads","The Abbasids"],
     ["Which architect designed the Süleymaniye Mosque?","Mimar Sinan","Ustad Ahmad Lahauri","Isidore of Miletus","Sedefkar Mehmed Agha"],
     ["Who built the Taj Mahal?","Shah Jahan","Akbar","Aurangzeb","Babur"],
     ["What is honeycomb-like vaulting called?","Muqarnas","Arabesque","Iwan","Pietra dura"]]},

{ t:"Calligraphy, Ornament, and the Book Arts of Islam", s:"The beauty of the written word",
  sec:[
  ["Calligraphy",[
    "Calligraphy, beautiful writing, is the most highly esteemed art in the Islamic world, because it conveys the words of the Quran, believed by Muslims to be the word of God revealed in Arabic. Calligraphers were honored artists, and their scripts decorate buildings, ceramics, metalwork, textiles, and books.",
    "Early Qurans were written in Kufic, an angular, horizontal script. Later, rounded cursive scripts became dominant, systematized by the 10th-century calligrapher Ibn Muqla according to proportional rules based on the rhombic dot made by the pen. Major scripts include Naskh, used for most books; Thuluth, large and elegant, for monuments; and Nastaliq, a flowing, slanting script developed in Persia."]],
  ["Geometry and pattern",[
    "Islamic artists developed complex geometric patterns based on circles, stars, and polygons, which can be extended infinitely, suggesting the infinite nature of God. These patterns cover tilework, carved wood, stucco, and metalwork. Some girih tile patterns in 15th-century Iran show mathematical sophistication resembling quasicrystalline patterns described by modern mathematicians.",
    "Arabesque, scrolling vines, leaves, and flowers, interlaced in endless rhythms, is the other great ornamental mode."]],
  ["Ceramics, metalwork, and textiles",[
    "Islamic potters invented lusterware in 9th-century Iraq, a metallic glaze shimmering like gold, and developed tin-glazed white ceramics imitating Chinese porcelain, as well as Iznik ware in Ottoman Turkey with vivid blue, turquoise, and tomato-red flowers. Mamluk Egypt and Syria produced gilded and enameled glass mosque lamps.",
    "Metalworkers inlaid brass with silver and gold, as in the Baptistère de Saint Louis, a Mamluk basin now in the Louvre. Carpets were among the most prized products; the Ardabil Carpet (1539–1540), from Safavid Iran and now in the Victoria and Albert Museum in London, is among the oldest dated carpets, with about 26 million knots."]],
  ["Persian painting",[
    "In Persia, painters illustrated manuscripts of poetry and history with exquisite small paintings, often called miniatures. Under the Timurids and Safavids, artists created jewel-like images with brilliant colors, flattened perspective, intricate patterns, and many figures, illustrating works such as Ferdowsi's epic Shahnameh (Book of Kings), completed around 1010, and the poetry of Nizami.",
    "The painter Kamal ud-Din Behzad (about 1450–1535), working in Herat, was celebrated as the greatest Persian painter, known for lively, naturalistic figures and complex compositions. The Shahnameh of Shah Tahmasp (about 1520s–1530s), with over 250 paintings, is one of the most lavish illustrated books ever made."]],
  ["Ottoman and Mughal painting",[
    "Ottoman painters created vivid illustrated histories of sultans' campaigns and festivals and portraits of rulers. Mughal painting in India, discussed further in the chapter on South Asia, combined Persian refinement with Indian vitality and European naturalism.",
    "Painting in albums (muraqqa), which combined calligraphy and paintings collected by connoisseurs, flourished in Iran, India, and Turkey."]],
  ["Legacy",[
    "Islamic art profoundly influenced European art: textiles, ceramics, carpets, and glass were prized in medieval Europe, Venetian and Spanish craftsmen imitated Islamic designs, and Arabic-like script called pseudo-Kufic appears in Italian Renaissance paintings.",
    "Modern and contemporary artists from the Islamic world, such as the calligraffiti artist eL Seed, continue to transform calligraphy and pattern in new forms."]]
  ],
  terms:[["Calligraphy","The art of beautiful writing."],["Kufic","An early angular Arabic script."],["Nastaliq","A flowing Persian script."],["Geometric pattern","Infinitely repeatable designs of circles and polygons."],["Lusterware","Ceramics with a metallic glaze, invented in Iraq."],["Persian miniature","A small, detailed manuscript painting."],["Shahnameh","Ferdowsi's Persian Book of Kings."]],
  w:"Calligraphy, pattern, and the book arts express the Islamic world's reverence for the written word and its genius for ornament and refined painting.",
  src:["Islamic calligraphy","Kufic","Islamic geometric patterns","Ardabil Carpet","Persian miniature","Kamāl ud-Dīn Behzād","Shahnameh of Shah Tahmasp"],
  q:[["What is the most esteemed art in the Islamic world?","Calligraphy","Painting","Sculpture","Architecture"],
     ["Which script is angular and was used for early Qurans?","Kufic","Naskh","Nastaliq","Thuluth"],
     ["Where was lusterware invented?","Iraq","Spain","Turkey","Egypt"],
     ["Where is the Ardabil Carpet?","The Victoria and Albert Museum","The Louvre","The Met","Tehran"],
     ["Who wrote the Shahnameh?","Ferdowsi","Nizami","Rumi","Hafez"],
     ["Who was celebrated as the greatest Persian painter?","Behzad","Reza Abbasi","Sultan Muhammad","Mir Sayyid Ali"]]},

{ t:"The Art of India and Southeast Asia", s:"Buddhist and Hindu art from stupas to temples",
  sec:[
  ["Early India",[
    "The Indus Valley Civilization (about 2600–1900 BCE) produced carved stone seals with animals and an undeciphered script, and small sculptures such as the bronze “Dancing Girl” from Mohenjo-daro. Later, the Mauryan emperor Ashoka (reigned about 268–232 BCE), after converting to Buddhism, erected polished stone pillars across his empire; the Lion Capital of Ashoka at Sarnath is now the national emblem of India.",
    "Early Buddhist art centered on the stupa, a dome-shaped mound containing relics of the Buddha, around which worshippers walked in circumambulation. The Great Stupa at Sanchi (3rd century BCE–1st century CE) has four gateways (toranas) carved with stories of the Buddha's lives and nature spirits such as voluptuous yakshis."]],
  ["The image of the Buddha",[
    "Early Buddhist art represented the Buddha only by symbols, such as a footprint, an empty throne, or the Bodhi tree. In the 1st and 2nd centuries CE, images of the Buddha in human form appeared in two regions: Gandhara, in present-day Pakistan and Afghanistan, where Hellenistic influence produced Buddhas with wavy hair and Greek-style drapery, and Mathura in northern India, with more Indian forms.",
    "Buddha images have conventional features: the ushnisha (cranial bump of wisdom), elongated earlobes, and hand gestures called mudras, such as touching the earth to call it as witness to enlightenment. The Gupta period (about 320–550 CE) produced serene, idealized Buddhas regarded as classical, and the painted caves of Ajanta contain magnificent murals."]],
  ["Hindu art",[
    "Hindu art depicts the many deities of Hinduism, such as Vishnu, Shiva, and the goddess Devi, often with multiple arms holding symbolic attributes, expressing their divine powers. Images are not merely representations but are believed to be inhabited by the deity during worship (puja), and the act of seeing and being seen by the deity is called darshan.",
    "Rock-cut temples such as Elephanta Caves, with a colossal three-headed Shiva, and the Kailasa Temple at Ellora (8th century), carved downward from a single mass of rock, are astonishing achievements."]],
  ["Hindu temples",[
    "The Hindu temple is conceived as the home of a god and a model of the cosmos, with a small dark sanctuary, the garbhagriha (“womb chamber”), holding the main image beneath a towering spire. Northern temples have curving towers called shikhara, as at Khajuraho (10th–11th centuries), famous for sculptures including erotic couples; southern temples have pyramidal towers called vimana, as at the Brihadeshvara Temple in Thanjavur (completed 1010) under the Chola dynasty.",
    "Later southern temples have enormous gateway towers called gopurams covered with colorful sculptures, as at Madurai's Meenakshi Temple. The Chola dynasty also produced superb bronzes, especially Shiva Nataraja, the Lord of the Dance, dancing within a ring of fire, symbolizing the cosmic cycle of creation and destruction."]],
  ["Southeast Asia",[
    "Indian religions and art spread across Southeast Asia. Borobudur in Java (about 800 CE), the world's largest Buddhist monument, is a stepped pyramid with about 2,670 relief panels and 504 Buddha statues; pilgrims climb its terraces in a spiral path representing the journey to enlightenment.",
    "Angkor Wat in Cambodia (early 12th century), built by the Khmer king Suryavarman II as a Hindu temple to Vishnu, is the world's largest religious monument, a representation of Mount Meru, the center of the universe, with long galleries of reliefs. Nearby, the Bayon temple at Angkor Thom has towers carved with serene, giant faces. Thailand, Myanmar, and Laos developed their own Buddhist art and architecture, such as the golden Shwedagon Pagoda in Yangon and the temples of Bagan."]],
  ["Himalayan art",[
    "In Tibet, Nepal, and Bhutan, Vajrayana Buddhism produced richly colored thangkas, painted scrolls of deities and mandalas used in meditation, and gilded bronze statues. A mandala is a symbolic diagram of the cosmos, and Tibetan monks create intricate sand mandalas that are ritually swept away upon completion, symbolizing impermanence.",
    "These traditions show how art across South and Southeast Asia served as a means of devotion and spiritual practice."]]
  ],
  terms:[["Stupa","A dome-shaped Buddhist relic mound."],["Mudra","A symbolic hand gesture."],["Darshan","Seeing and being seen by a deity."],["Garbhagriha","The inner sanctuary of a Hindu temple."],["Shiva Nataraja","Shiva as Lord of the Dance."],["Borobudur","The largest Buddhist monument, in Java."],["Mandala","A symbolic diagram of the cosmos."]],
  w:"The art of India and Southeast Asia gave visible form to Buddhist and Hindu devotion, creating some of the world's greatest temples and sculptures.",
  src:["Indian art","Sanchi","Gandhara","Buddhist art","Hindu temple architecture","Nataraja","Borobudur","Angkor Wat"],
  q:[["Which Lion Capital is India's national emblem?","The Lion Capital of Ashoka at Sarnath","The Sanchi gateway","The Mathura Buddha","The Ajanta lion"],
     ["What is a dome-shaped Buddhist relic mound called?","A stupa","A shikhara","A gopuram","A mandala"],
     ["Where did Buddha images with Greek-style drapery appear?","Gandhara","Mathura","Sarnath","Ajanta"],
     ["What is the inner sanctuary of a Hindu temple called?","The garbhagriha","The vimana","The torana","The mandapa"],
     ["Which dynasty made famous bronzes of Shiva Nataraja?","The Chola","The Gupta","The Maurya","The Mughal"],
     ["Which is the world's largest Buddhist monument?","Borobudur","Angkor Wat","Shwedagon","Bodh Gaya"]]},

{ t:"Mughal and Rajput Painting", s:"Courts, epics, and the art of the miniature",
  sec:[
  ["The Mughal workshop",[
    "The Mughal emperors, ruling much of the Indian subcontinent from 1526, were great patrons of painting. Emperor Humayun brought Persian painters back from exile in Iran, and his son Akbar (reigned 1556–1605) established a vast imperial workshop where Persian masters trained Indian artists, both Hindu and Muslim.",
    "Under Akbar, painters illustrated huge projects such as the Hamzanama, about 1,400 large paintings on cloth of the adventures of the hero Amir Hamza, and Persian translations of the Hindu epics, the Mahabharata and Ramayana. Mughal painting combined Persian elegance and color with Indian energy and, after Jesuit missionaries brought European prints, European naturalism and shading."]],
  ["Jahangir and Shah Jahan",[
    "Emperor Jahangir (reigned 1605–1627), a connoisseur, favored individual portraits, natural history studies of animals and birds, and allegorical images. His painter Ustad Mansur painted precise studies of birds and flowers, such as a famous zebra and turkey. Allegorical portraits showed Jahangir with halos, preferring a Sufi sheikh to kings, or embracing the Persian Shah.",
    "Under Shah Jahan, builder of the Taj Mahal, painting became more formal and jewel-like, as in the Padshahnama, the illustrated history of his reign. Mughal painting declined under the austere Aurangzeb but continued at regional courts."]],
  ["Rajput painting",[
    "Rajput painting flourished at the courts of Hindu kingdoms in Rajasthan and the Punjab Hills from the 16th to 19th centuries. Compared with Mughal art, it is generally bolder, flatter, and more poetic, with intense colors and an emphasis on emotion and devotion.",
    "Favorite subjects included the love of the god Krishna and the cowherd Radha, from devotional poetry such as the Gita Govinda; scenes from the Ramayana; ragamala paintings, which visualize musical modes (ragas) as scenes of love and moods; and court life."]],
  ["Pahari painting",[
    "In the Pahari (hill) kingdoms of the Himalayan foothills, painting reached exceptional delicacy in the 18th century. The painter Nainsukh of Guler made sensitive portraits of his patron, Raja Balwant Singh, in intimate moments. The Kangra school produced lyrical images of Radha and Krishna in lush landscapes with flowering trees and moonlit nights.",
    "These paintings, made for private viewing in albums, invite slow, close looking at their details and poetic inscriptions."]],
  ["Company painting and colonial art",[
    "With the rise of the British East India Company in the 18th and 19th centuries, Indian artists produced “Company paintings” for British patrons, depicting Indian flora, fauna, occupations, festivals, and monuments in a hybrid style combining Indian techniques with European watercolor conventions.",
    "In the late 19th century, Raja Ravi Varma painted Hindu gods and epic heroines in a realistic European oil style; his prints of deities spread through mass-produced lithographs into homes across India, shaping popular religious imagery."]],
  ["Modern Indian art",[
    "In the early 20th century, the Bengal School, led by Abanindranath Tagore, rejected European academic styles and revived Indian, Mughal, and Asian traditions as part of the nationalist movement. Amrita Sher-Gil, of Indian and Hungarian parents, combined European modernism with Indian subjects before her death at 28 in 1941.",
    "After independence, the Progressive Artists' Group, founded in Bombay in 1947, including M. F. Husain, S. H. Raza, and F. N. Souza, created modern Indian art engaging with international modernism, and today Indian artists are prominent worldwide."]]
  ],
  terms:[["Mughal painting","The court painting of the Mughal emperors."],["Hamzanama","Akbar's huge illustrated adventure of Amir Hamza."],["Rajput painting","Painting at Hindu courts of Rajasthan and the Punjab Hills."],["Ragamala","Paintings visualizing musical modes."],["Pahari painting","Painting of the Himalayan foothill kingdoms."],["Company painting","Indian painting for British patrons."],["Bengal School","An early 20th-century revival of Indian styles."]],
  w:"Mughal and Rajput painting combined Persian, Indian, and European traditions into exquisite art of courts, epics, and devotion that still shapes Indian visual culture.",
  src:["Mughal painting","Hamzanama","Jahangir","Rajput painting","Pahari painting","Raja Ravi Varma","Bengal School of Art"],
  q:[["Which emperor established the great Mughal painting workshop?","Akbar","Babur","Shah Jahan","Aurangzeb"],
     ["What was the Hamzanama?","About 1,400 paintings of Amir Hamza's adventures","A history of Shah Jahan","A book of birds","A Persian poem"],
     ["Which emperor favored natural history studies like Mansur's zebra?","Jahangir","Akbar","Humayun","Aurangzeb"],
     ["Which god and his beloved are favorite Rajput subjects?","Krishna and Radha","Rama and Sita","Shiva and Parvati","Vishnu and Lakshmi"],
     ["What do ragamala paintings visualize?","Musical modes","Seasons","Battles","Maps"],
     ["Whose prints of deities spread across Indian homes?","Raja Ravi Varma","Abanindranath Tagore","Amrita Sher-Gil","M. F. Husain"]]},

{ t:"Chinese Art: Bronzes, Jade, and Ceramics", s:"Ancient ritual and imperial craft",
  sec:[
  ["Jade and bronze",[
    "Chinese art has one of the world's longest continuous traditions. Neolithic cultures carved jade, prized for its hardness and beauty and associated with virtue and immortality, into ritual discs (bi) and tubes (cong). Jade remained precious throughout Chinese history; Han dynasty princes were buried in suits of jade plaques sewn with gold wire.",
    "The Shang (about 1600–1046 BCE) and Zhou dynasties cast magnificent bronze vessels for ritual offerings of food and wine to ancestors, decorated with the taotie, a stylized mask-like creature. Bronze casting used piece molds, an advanced technique. Inscriptions on vessels are important historical sources."]],
  ["The Terracotta Army and Han art",[
    "Qin Shi Huang, the first emperor of unified China (221 BCE), was buried near Xi'an with an army of about 8,000 life-size terracotta soldiers, along with horses and chariots, each with individualized faces, originally brightly painted. Discovered by farmers digging a well in 1974, it is one of the greatest archaeological finds.",
    "Han dynasty (206 BCE–220 CE) tombs were filled with ceramic models of houses, animals, and servants to serve the dead, and painted silk banners, such as the one from the tomb of Lady Dai at Mawangdui, depicting heaven, earth, and the underworld."]],
  ["Buddhist sculpture",[
    "Buddhism reached China in the 1st century CE and inspired monumental rock-cut cave temples with colossal Buddha statues, such as those at Yungang and Longmen, and the painted caves of Dunhuang along the Silk Road, which also preserved thousands of manuscripts.",
    "The Leshan Giant Buddha (8th century), carved into a cliff in Sichuan, is about 71 meters tall, the largest stone Buddha in the world."]],
  ["The tradition of ceramics",[
    "China led the world in ceramics for over a thousand years. Tang dynasty (618–907) potters made lively tomb figures of horses and camels with three-color (sancai) lead glazes. Song dynasty (960–1279) potters created refined monochrome wares admired for their subtle glazes, such as the pale green celadons of Longquan and the rare Ru ware, made for the imperial court.",
    "True porcelain, a hard, white, translucent ceramic fired at very high temperatures from kaolin clay, was perfected in China; the word “china” for fine tableware reflects this."]],
  ["Blue-and-white and export porcelain",[
    "Under the Yuan dynasty (1271–1368), potters at Jingdezhen, which became the porcelain capital of the world, began making blue-and-white porcelain, painted with cobalt blue imported from Persia under a clear glaze. Ming dynasty (1368–1644) blue-and-white was exported across Asia, the Middle East, Africa, and Europe.",
    "European companies imported millions of pieces, and European potters tried for centuries to discover the secret of porcelain until Meissen in Germany succeeded in 1708–1709. Delftware in the Netherlands imitated Chinese blue-and-white in tin-glazed earthenware. Qing dynasty (1644–1912) potters added brilliant enamels, such as famille rose."]],
  ["Other arts",[
    "Chinese artisans excelled in silk weaving, which gave the Silk Road its name, carved lacquer, cloisonné enamel, and furniture. The Forbidden City in Beijing, the imperial palace complex built from 1406 to 1420, with about 980 buildings and yellow-tiled roofs, displays imperial architecture.",
    "Imperial collections, now divided between the Palace Museum in Beijing and the National Palace Museum in Taipei, hold many of China's greatest treasures."]]
  ],
  terms:[["Bi and cong","Neolithic jade ritual objects."],["Taotie","A mask-like motif on ancient bronzes."],["Terracotta Army","Qin Shi Huang's tomb army of about 8,000 figures."],["Sancai","Tang dynasty three-color glazed ceramics."],["Celadon","Pale green-glazed ceramics."],["Porcelain","Hard, white, translucent ceramic perfected in China."],["Jingdezhen","China's porcelain capital."]],
  w:"China's bronzes, jades, and ceramics represent one of the world's longest artistic traditions, and its porcelain shaped global trade and taste.",
  src:["Chinese art","Chinese jade","Chinese ritual bronzes","Terracotta Army","Leshan Giant Buddha","Chinese ceramics","Blue and white pottery"],
  q:[["Which dynasty cast ritual bronzes decorated with the taotie?","The Shang","The Han","The Tang","The Ming"],
     ["When was the Terracotta Army discovered?","1974","1924","1954","1994"],
     ["What is the largest stone Buddha in the world?","The Leshan Giant Buddha","The Bamiyan Buddhas","The Longmen Buddha","The Tian Tan Buddha"],
     ["Which dynasty made three-color sancai tomb figures?","The Tang","The Song","The Han","The Qing"],
     ["Which city became the porcelain capital of the world?","Jingdezhen","Xi'an","Hangzhou","Nanjing"],
     ["Which European factory first made true porcelain?","Meissen","Sèvres","Delft","Wedgwood"]]}

]});


/* ---- from arts-18.js ---- */
/* ARTS FOUNDATIONS, part 18: Unit 10 chapters 6-10 */
COURSES.arts.units[9].ch.push(

{ t:"Chinese Painting and Calligraphy", s:"Brush, ink, and the scholar's art",
  sec:[
  ["The three perfections",[
    "In China, calligraphy, painting, and poetry were considered the “three perfections,” closely linked arts practiced by educated scholar-officials. Calligraphy was regarded as the highest art, because the brushstroke was thought to reveal the writer's character and cultivation. Wang Xizhi (4th century CE), the “Sage of Calligraphy,” was revered for centuries; his Preface to the Orchid Pavilion Collection survives only in copies.",
    "Painters used the same tools as calligraphers, the “four treasures of the study”: brush, ink stick, ink stone, and paper (or silk). Paintings were often mounted as hanging scrolls or handscrolls, which are unrolled section by section from right to left, so viewers journey through the image over time."]],
  ["Landscape painting",[
    "Landscape (shanshui, “mountain-water”) became the most prestigious genre of Chinese painting, expressing Daoist and Confucian ideas of harmony between humanity and nature. In the Northern Song dynasty (960–1127), monumental landscapes showed towering mountains with tiny human figures: Fan Kuan's Travelers among Mountains and Streams (about 1000), in the National Palace Museum in Taipei, is a masterpiece.",
    "Chinese landscapes do not use single-point perspective; they use shifting viewpoints and “three distances” (high, deep, and level), allowing the viewer's eye to wander. Empty space, often mist or water, is an essential part of the composition. In the Southern Song, painters such as Ma Yuan and Xia Gui created intimate, atmospheric scenes with figures gazing into misty distance, compositions concentrated in one corner."]],
  ["Literati painting",[
    "From the Song dynasty, scholar-amateur painters, the literati (wenren), developed a style that valued personal expression, spontaneity, and learning over technical polish and realism, distinguishing themselves from professional court painters. They painted landscapes, bamboo, plum blossoms, orchids, and rocks, symbols of the scholar's virtues; bamboo, for example, bends but does not break.",
    "During the Mongol Yuan dynasty (1271–1368), when many scholars refused to serve foreign rulers, the Four Masters of the Yuan, including Huang Gongwang, whose Dwelling in the Fuchun Mountains is a famous handscroll, and Ni Zan, known for sparse, lonely landscapes, developed literati painting to new heights."]],
  ["Inscriptions and seals",[
    "Chinese paintings often include poems and inscriptions written by the artist and by later owners and admirers, as well as red seals stamped by collectors. These became part of the work, recording its history and responses to it.",
    "Copying the old masters was considered a way to learn and pay homage, not mere imitation. The Ming theorist Dong Qichang (1555–1636) classified painters into Northern and Southern schools, favoring the literati tradition."]],
  ["Court and later painting",[
    "Emperor Huizong of the Song (reigned 1100–1126) was himself a fine painter and calligrapher who developed the elegant “slender gold” script. Zhang Zeduan's long handscroll Along the River during the Qingming Festival (12th century) depicts the bustling life of a Song city with hundreds of people, boats, and shops.",
    "In the Qing dynasty, individualist painters such as Bada Shanren, a descendant of the Ming royal family, painted eccentric birds and fish with defiant expressions, and the Jesuit missionary Giuseppe Castiglione worked at the court blending European and Chinese styles."]],
  ["Modern Chinese art",[
    "In the 20th century, Chinese artists debated how to modernize traditional ink painting and engage with Western art. Qi Baishi painted lively shrimps and crabs in a fresh, simplified style, and Xu Beihong combined Western realism with Chinese ink in his galloping horses.",
    "Under Mao, Socialist Realism and propaganda posters dominated, and the Cultural Revolution persecuted many artists. Since the 1980s, contemporary Chinese art has flourished, while ink painting continues to evolve."]]
  ],
  terms:[["Three perfections","Calligraphy, painting, and poetry."],["Four treasures of the study","Brush, ink stick, ink stone, and paper."],["Handscroll","A horizontal scroll viewed section by section."],["Shanshui","Chinese landscape painting."],["Literati painting","Scholar-amateur painting valuing personal expression."],["Seal","A red stamp marking ownership or authorship."],["Along the River during the Qingming Festival","A famous Song handscroll of city life."]],
  w:"Chinese painting and calligraphy made the brushstroke an expression of character and created a landscape tradition of profound philosophical depth.",
  src:["Chinese painting","Chinese calligraphy","Wang Xizhi","Shan shui","Travelers among Mountains and Streams","Literati painting","Along the River During the Qingming Festival"],
  q:[["Which art was regarded as highest in China?","Calligraphy","Sculpture","Ceramics","Architecture"],
     ["Who is called the Sage of Calligraphy?","Wang Xizhi","Dong Qichang","Huizong","Mi Fu"],
     ["Who painted Travelers among Mountains and Streams?","Fan Kuan","Ma Yuan","Huang Gongwang","Ni Zan"],
     ["Who were the literati painters?","Scholar-amateurs valuing personal expression","Court professionals","Buddhist monks","Foreign missionaries"],
     ["Which emperor was a fine painter and calligrapher?","Huizong","Kangxi","Qianlong","Taizong"],
     ["Who painted lively shrimps in the 20th century?","Qi Baishi","Xu Beihong","Zhang Daqian","Lin Fengmian"]]},

{ t:"Japanese Art: From Jōmon to Zen", s:"Shrines, temples, and the beauty of imperfection",
  sec:[
  ["Early Japan",[
    "Japan's Jōmon culture (about 14,000–300 BCE) made some of the world's oldest pottery, decorated with cord-marked patterns, and clay figurines called dogū. The Kofun period (about 250–538 CE) built huge keyhole-shaped burial mounds surrounded by clay figures called haniwa.",
    "Shinto, Japan's indigenous religion, honors kami, spirits present in nature, ancestors, and places. The Ise Grand Shrine, Shinto's holiest site, is ritually rebuilt in identical form every 20 years, preserving its ancient design and expressing ideas of renewal and purity."]],
  ["Buddhism arrives",[
    "Buddhism arrived from Korea and China in the 6th century, bringing temples, sculpture, and painting. Hōryū-ji near Nara includes some of the oldest wooden buildings in the world. Tōdai-ji in Nara houses a colossal bronze Buddha (Daibutsu), about 15 meters tall, dedicated in 752, in one of the world's largest wooden buildings.",
    "In the Heian period (794–1185), the imperial court in Kyoto developed a refined aristocratic culture. The Phoenix Hall of Byōdō-in (1053) evokes the Western Paradise of the Amida Buddha, and the Tale of Genji, written by the court lady Murasaki Shikibu, was illustrated in handscrolls (emaki) with “blown-off roof” views into rooms."]],
  ["Kamakura realism",[
    "In the Kamakura period (1185–1333), with the rise of samurai warriors and the shogunate, art became more vigorous and realistic. Sculptors Unkei and Kaikei carved dynamic wooden figures, such as the fierce guardian kings (Niō) at Tōdai-ji's Great South Gate, with crystal eyes.",
    "Handscrolls depicted battles, such as the Night Attack on the Sanjō Palace, and the Great Buddha of Kamakura (1252), a bronze Amida about 11 meters tall, sits in the open air."]],
  ["Zen and ink",[
    "Zen Buddhism, which emphasizes meditation and sudden enlightenment, deeply shaped Japanese art from the 13th century. Zen monks practiced ink painting (sumi-e) influenced by Chinese Song painting, valuing spontaneity, simplicity, and suggestion. Sesshū Tōyō (1420–1506) was the greatest master of Japanese ink landscape.",
    "Zen gardens, such as the dry rock garden (karesansui) at Ryōan-ji in Kyoto, with 15 stones arranged in raked white gravel, invite contemplation. Zen calligraphy and the ensō, a single brushstroke circle, express enlightenment and emptiness."]],
  ["The tea ceremony and wabi-sabi",[
    "The tea ceremony (chanoyu), perfected by the tea master Sen no Rikyū (1522–1591), is a ritualized preparation and serving of powdered green tea in a small, rustic tea house. It shaped Japanese aesthetics, valuing wabi-sabi, the beauty of simplicity, imperfection, transience, and age.",
    "Tea bowls, such as hand-shaped raku ware, with irregular forms and uneven glazes, were prized more than perfect porcelain. Kintsugi, repairing broken ceramics with lacquer and gold, celebrates a bowl's history rather than hiding its damage."]],
  ["Castles and screens",[
    "In the Momoyama period (1573–1615), warlords built castles such as Himeji, the “White Heron Castle,” and decorated their interiors with dazzling folding screens and sliding doors covered in gold leaf, painted with pine trees, tigers, and birds by artists of the Kanō school such as Kanō Eitoku.",
    "Hasegawa Tōhaku's Pine Trees screens, painted in ink with trees emerging from mist, are a contrasting masterpiece of subtle restraint."]]
  ],
  terms:[["Jōmon","Early Japanese culture known for ancient pottery."],["Haniwa","Clay figures placed around ancient burial mounds."],["Kami","Spirits honored in Shinto."],["Emaki","Illustrated narrative handscrolls."],["Zen","Buddhism emphasizing meditation and enlightenment."],["Karesansui","A dry rock garden."],["Wabi-sabi","The beauty of simplicity, imperfection, and transience."],["Kintsugi","Repairing ceramics with gold."]],
  w:"Early Japanese art absorbed Buddhist and Chinese influences and developed distinctive ideals of nature, simplicity, and imperfection that remain central to Japanese culture.",
  src:["Japanese art","Jōmon pottery","Ise Grand Shrine","Tōdai-ji","Sesshū Tōyō","Ryōan-ji","Wabi-sabi"],
  q:[["Which shrine is rebuilt every 20 years?","Ise Grand Shrine","Itsukushima","Fushimi Inari","Meiji Shrine"],
     ["Where is the colossal bronze Buddha dedicated in 752?","Tōdai-ji in Nara","Kamakura","Byōdō-in","Hōryū-ji"],
     ["Who wrote the Tale of Genji?","Murasaki Shikibu","Sei Shōnagon","Sen no Rikyū","Bashō"],
     ["Who was the greatest master of Japanese ink landscape?","Sesshū Tōyō","Kanō Eitoku","Hokusai","Tōhaku"],
     ["Who perfected the tea ceremony?","Sen no Rikyū","Sesshū","Murasaki Shikibu","Unkei"],
     ["What is repairing ceramics with gold called?","Kintsugi","Raku","Wabi-sabi","Ikebana"]]},

{ t:"Japanese Art: Edo to Modern", s:"The floating world and beyond",
  sec:[
  ["The Edo period",[
    "In the Edo period (1603–1868), the Tokugawa shoguns unified Japan, ruled from Edo (modern Tokyo), and largely closed the country to foreigners. Peace and prosperity produced a rich urban culture centered on merchants and townspeople, with kabuki theater, pleasure quarters, and fashions.",
    "The Rinpa school, founded by Hon'ami Kōetsu and Tawaraya Sōtatsu and continued by Ogata Kōrin, created bold, decorative designs on gold-leaf screens, such as Kōrin's Irises screens and Red and White Plum Blossoms, with flat, stylized forms that later influenced Art Nouveau."]],
  ["Ukiyo-e",[
    "Ukiyo-e (“pictures of the floating world”), a term reflecting the Buddhist idea of transience turned toward pleasure-seeking, depicted the world of kabuki actors, beautiful courtesans, and urban entertainment. Woodblock prints, made by teams of designers, carvers, printers, and publishers, were cheap enough for ordinary townspeople to buy.",
    "Full-color prints (nishiki-e, “brocade pictures”) were developed in 1765 by Suzuki Harunobu. Kitagawa Utamaro portrayed elegant women in close-up, and the mysterious Tōshūsai Sharaku made striking actor portraits during just ten months in 1794–1795."]],
  ["Hokusai and Hiroshige",[
    "Katsushika Hokusai (1760–1849) produced an estimated 30,000 works over a long career. His series Thirty-Six Views of Mount Fuji (about 1830–1832) includes The Great Wave off Kanagawa, with a towering claw-like wave about to crash over boats, with Mount Fuji small in the distance, and Fine Wind, Clear Morning (Red Fuji). His Hokusai Manga sketchbooks fill volumes with drawings of everyday life.",
    "Utagawa Hiroshige (1797–1858) made poetic landscape series such as The Fifty-Three Stations of the Tōkaidō and One Hundred Famous Views of Edo, capturing rain, snow, and seasons; Van Gogh copied his Sudden Shower over Shin-Ōhashi Bridge and Plum Park in Kameido."]],
  ["Meiji modernization",[
    "After American warships under Commodore Matthew Perry forced Japan to open in 1853–1854, the Meiji Restoration of 1868 launched rapid modernization and Westernization. Japanese artists studied Western oil painting (yōga), while others developed nihonga, modern painting using traditional Japanese materials and styles, encouraged by figures such as Okakura Kakuzō, author of The Book of Tea (1906).",
    "Japanese art at international exhibitions fueled Japonisme in Europe, influencing the Impressionists, Van Gogh, and Art Nouveau."]],
  ["Modern and contemporary Japan",[
    "After World War II, Japanese artists created bold avant-garde movements. The Gutai group performed experimental actions, and Mono-ha (“School of Things”) arranged natural and industrial materials. Yayoi Kusama, Yoko Ono, and On Kawara worked internationally.",
    "Photography flourished with artists such as Daidō Moriyama and Hiroshi Sugimoto, and the architect Tadao Ando created serene concrete buildings. Takashi Murakami's Superflat movement and the global popularity of manga and anime, from Osamu Tezuka's Astro Boy to Studio Ghibli, made Japanese visual culture influential worldwide."]],
  ["Crafts and design",[
    "Japan values traditional crafts highly and designates master artisans as Living National Treasures, a program begun in 1955, in fields such as ceramics, textiles, lacquer, swordsmithing, and doll-making. The mingei (folk craft) movement, led by Yanagi Sōetsu in the 1920s, celebrated the beauty of anonymous everyday objects.",
    "Japanese design, with its simplicity, attention to materials, and craftsmanship, has influenced modern architecture and design worldwide."]]
  ],
  terms:[["Edo period","Japan's era of Tokugawa rule, 1603–1868."],["Rinpa","A decorative school of painting on gold screens."],["Ukiyo-e","Pictures of the floating world."],["Nishiki-e","Full-color woodblock prints."],["Thirty-Six Views of Mount Fuji","Hokusai's print series."],["Nihonga","Modern painting in traditional Japanese styles."],["Living National Treasure","Japan's title for master artisans."]],
  w:"From Rinpa screens and ukiyo-e prints to manga and contemporary art, Japanese visual culture has repeatedly transformed art around the world.",
  src:["Edo period","Rinpa school","Ukiyo-e","Katsushika Hokusai","Hiroshige","Nihonga","Living National Treasure (Japan)"],
  q:[["Who painted the Irises screens?","Ogata Kōrin","Tawaraya Sōtatsu","Kanō Eitoku","Hokusai"],
     ["What does ukiyo-e mean?","Pictures of the floating world","Pictures of Mount Fuji","Brocade pictures","Pictures of actors"],
     ["Who developed full-color nishiki-e prints in 1765?","Suzuki Harunobu","Kitagawa Utamaro","Sharaku","Hiroshige"],
     ["Which series includes The Great Wave?","Thirty-Six Views of Mount Fuji","One Hundred Famous Views of Edo","Fifty-Three Stations of the Tōkaidō","Hokusai Manga"],
     ["Whose prints did Van Gogh copy?","Hiroshige's","Utamaro's","Sharaku's","Harunobu's"],
     ["What is modern painting in traditional Japanese style called?","Nihonga","Yōga","Mingei","Superflat"]]},

{ t:"Korean Art", s:"Celadon, scholars, and the Korean Wave",
  sec:[
  ["A distinct tradition",[
    "Korea, on a peninsula between China and Japan, developed a distinctive art that absorbed Chinese influences and transmitted Buddhism and crafts to Japan. Korean art is often admired for its naturalness, simplicity, and understated elegance.",
    "The Three Kingdoms period (57 BCE–668 CE) produced gold crowns from Silla tombs, decorated with tree- and antler-shaped uprights and jade ornaments, and the gilt-bronze Pensive Bodhisattva figures, seated with one leg crossed and a hand raised to the cheek in contemplation, among the masterpieces of Buddhist sculpture."]],
  ["Unified Silla and Buddhism",[
    "Under Unified Silla (668–935), Buddhism flourished. The Seokguram Grotto (8th century), an artificial cave temple near Gyeongju, houses a serene granite Buddha surrounded by reliefs of bodhisattvas and guardians, considered one of the finest Buddhist sculptures in East Asia. The nearby Bulguksa Temple is also a UNESCO site.",
    "Silla's capital Gyeongju is sometimes called a “museum without walls” for its tombs and temples."]],
  ["Goryeo celadon",[
    "During the Goryeo dynasty (918–1392), from which the name Korea derives, potters created celadon ceramics with a jade-green glaze so beautiful that a Chinese visitor in 1123 praised its “kingfisher color.” Korean potters invented sanggam, an inlay technique in which designs such as cranes and clouds were carved into the clay and filled with white and black slip before glazing.",
    "Goryeo also produced the Tripitaka Koreana, about 81,000 woodblocks carved in the 13th century with the entire Buddhist canon, preserved at Haeinsa Temple, and the Jikji (1377), the oldest surviving book printed with movable metal type."]],
  ["Joseon art",[
    "The Joseon dynasty (1392–1897) adopted Neo-Confucianism, valuing modesty and restraint. King Sejong introduced the Hangul alphabet in 1443–1446. Joseon potters made white porcelain and buncheong stoneware with lively, freely brushed or stamped decoration; the large, slightly irregular white “moon jars” of the 17th–18th centuries are admired for their quiet, natural beauty.",
    "Joseon scholar-painters practiced literati painting, and in the 18th century, Jeong Seon developed “true-view landscape” painting depicting real Korean scenery, such as the Diamond Mountains, rather than imagined Chinese scenes. Kim Hong-do and Shin Yun-bok painted lively genre scenes of everyday life, wrestlers, dancers, and lovers."]],
  ["Folk art and crafts",[
    "Korean folk paintings (minhwa), made by anonymous artists for ordinary homes, depicted tigers, magpies, symbols of longevity, and chaekgeori, bookshelf paintings showing scholarly objects. Bojagi, patchwork wrapping cloths stitched from leftover fabric, are admired today as abstract compositions.",
    "Korean architecture, such as Gyeongbokgung Palace in Seoul, uses graceful curved roofs and harmonizes buildings with the surrounding landscape."]],
  ["Modern and contemporary Korea",[
    "After Japanese colonial rule (1910–1945) and the Korean War, South Korean artists in the 1970s developed Dansaekhwa (“monochrome painting”), meditative abstract works by artists such as Park Seo-bo and Lee Ufan, which gained international recognition in the 2010s. Nam June Paik pioneered video art.",
    "Contemporary artists such as Do Ho Suh, Haegue Yang, and Lee Bul exhibit globally, and the Korean Wave (Hallyu) of K-pop, film, and drama has made Korean culture influential worldwide."]]
  ],
  terms:[["Pensive Bodhisattva","A contemplative seated Buddhist figure."],["Seokguram","A Silla cave temple with a famous granite Buddha."],["Goryeo celadon","Jade-green Korean ceramics."],["Sanggam","Korean inlaid ceramic decoration."],["Moon jar","A large Joseon white porcelain jar."],["True-view landscape","Jeong Seon's painting of real Korean scenery."],["Dansaekhwa","Korean monochrome painting of the 1970s."]],
  w:"Korean art, from Goryeo celadon to moon jars and Dansaekhwa, expresses a distinctive aesthetic of naturalness and restraint and shaped the art of East Asia.",
  src:["Korean art","Pensive Bodhisattva","Seokguram","Goryeo celadon","Moon jar","Jeong Seon","Dansaekhwa"],
  q:[["Which grotto houses a famous granite Buddha near Gyeongju?","Seokguram","Bulguksa","Haeinsa","Gyeongbokgung"],
     ["What color is Goryeo celadon?","Jade green","Blue and white","Black","Red"],
     ["What is the Korean inlay technique called?","Sanggam","Buncheong","Minhwa","Bojagi"],
     ["What is the oldest surviving book printed with movable metal type?","The Jikji","The Tripitaka Koreana","The Diamond Sutra","The Gutenberg Bible"],
     ["Who developed true-view landscape painting?","Jeong Seon","Kim Hong-do","Shin Yun-bok","Park Seo-bo"],
     ["What is Korean monochrome painting of the 1970s called?","Dansaekhwa","Minhwa","Hallyu","Chaekgeori"]]},

{ t:"African Art: Ancient Kingdoms", s:"Nok, Ife, Benin, and beyond",
  sec:[
  ["A vast continent",[
    "Africa's art is as diverse as its more than 50 countries and thousands of cultures, spanning rock art tens of thousands of years old, ancient Egypt and Nubia, Christian Ethiopia, Islamic architecture, and the sculpture, masks, textiles, and architecture of countless peoples. Much traditional African art was made for use in ritual, governance, and daily life rather than for display.",
    "European views long dismissed African art as “primitive,” while at the same time modern European artists borrowed from it. Today it is recognized as one of the world's great artistic traditions, and its history is increasingly told from African perspectives."]],
  ["Nok",[
    "The Nok culture of central Nigeria (about 900 BCE–300 CE) produced the earliest known large terracotta sculptures in sub-Saharan Africa: heads and figures with elaborate hairstyles, large eyes with triangular or D-shaped pupils, and pierced eyes, nostrils, and ears. Nok people also smelted iron.",
    "Many Nok sculptures have been looted from archaeological sites for the international art market, destroying information about their context and prompting efforts to protect sites."]],
  ["Ife",[
    "The Yoruba city of Ile-Ife, in southwestern Nigeria, considered the place where the world was created in Yoruba belief, produced remarkably naturalistic heads in copper alloy and terracotta between about the 12th and 15th centuries, probably representing rulers (onis). Their serene, idealized faces, often marked with fine vertical striations, astonished European scholars when discovered in the early 20th century, some of whom wrongly attributed them to outside influence.",
    "Ife artists used the lost-wax casting technique with great skill. Yoruba art continues to flourish, including carved wooden figures, beaded crowns, and twin figures (ere ibeji)."]],
  ["The Kingdom of Benin",[
    "The Kingdom of Benin (in present-day Nigeria, distinct from the modern Republic of Benin) produced the famous Benin Bronzes from about the 13th century: thousands of cast brass plaques, commemorative heads, and ivory carvings made by royal guilds for the Oba (king). Plaques that decorated the palace depicted the Oba, warriors, court rituals, and Portuguese traders, with whom Benin traded from the late 15th century.",
    "An ivory pendant mask of Queen Mother Idia, made in the 16th century, is one of the most celebrated works of African art. In 1897 a British punitive expedition sacked Benin City and looted thousands of objects, which were dispersed to museums and collections in Europe and America. Several institutions have since returned Benin Bronzes to Nigeria."]],
  ["Great Zimbabwe and East Africa",[
    "Great Zimbabwe (about 11th–15th centuries), in present-day Zimbabwe, was the capital of a trading kingdom whose stone enclosures, built of granite blocks without mortar, include the Great Enclosure with walls up to about 11 meters high. Carved soapstone birds found there are now national symbols of Zimbabwe. Colonial-era writers falsely claimed foreigners built it, denying African achievement.",
    "In Ethiopia, the rock-hewn churches of Lalibela (12th–13th centuries) were carved downward from solid rock, and Ethiopian Christian art produced illuminated manuscripts and icons. In Mali, the Great Mosque of Djenné, rebuilt in 1907, is the largest mud-brick building in the world, replastered by the community every year."]],
  ["Nubia and Aksum",[
    "South of Egypt, the kingdom of Kush in Nubia (in present-day Sudan) ruled Egypt as its 25th Dynasty in the 8th–7th centuries BCE and later built hundreds of steep pyramids at Meroë. The Ethiopian kingdom of Aksum erected tall carved granite obelisks (stelae) in the early centuries CE; one, taken to Rome by Mussolini's forces in 1937, was returned in 2005.",
    "These ancient kingdoms show the depth and variety of African artistic history long before European contact."]]
  ],
  terms:[["Nok","A Nigerian culture known for ancient terracotta sculptures."],["Ife","A Yoruba city known for naturalistic metal and terracotta heads."],["Benin Bronzes","Brass plaques and sculptures of the Kingdom of Benin."],["Oba","The king of Benin."],["Great Zimbabwe","A medieval stone city in southern Africa."],["Lalibela","Ethiopian churches carved from rock."],["Great Mosque of Djenné","The largest mud-brick building in the world."]],
  w:"Africa's ancient kingdoms created sculpture and architecture of great sophistication, and their history is central to debates about colonial looting and restitution.",
  src:["African art","Nok culture","Ife","Benin Bronzes","Queen Mother Idia","Great Zimbabwe","Great Mosque of Djenné"],
  q:[["Which culture made the earliest large terracotta sculptures in sub-Saharan Africa?","Nok","Ife","Benin","Igbo-Ukwu"],
     ["Which Yoruba city produced naturalistic copper-alloy heads?","Ile-Ife","Oyo","Lagos","Benin City"],
     ["In what year did British forces loot Benin City?","1897","1884","1914","1860"],
     ["Whose ivory pendant mask is a celebrated Benin work?","Queen Mother Idia","Oba Ewuare","Queen Amina","Queen Nzinga"],
     ["What is the largest mud-brick building in the world?","The Great Mosque of Djenné","Great Zimbabwe","Lalibela","The Kaaba"],
     ["Where were hundreds of steep pyramids built in Nubia?","Meroë","Aksum","Lalibela","Kerma"]]}

);


/* ---- from arts-19.js ---- */
/* ARTS FOUNDATIONS, part 19: Unit 10 chapters 11-16 */
COURSES.arts.units[9].ch.push(

{ t:"African Art: Masks, Figures, and Modern Africa", s:"Art in action and its global influence",
  sec:[
  ["Art in use",[
    "Much traditional African sculpture, carved mainly in wood, was made to be used: in initiation, healing, funerals, harvest festivals, governance, divination, and honoring ancestors. Masks, for example, are only one part of a masquerade, which also includes costume, music, dance, and the performer, who may embody a spirit. Seeing a mask in a museum case removes it from the movement and context that gave it meaning.",
    "Artists were often specialists, sometimes known by name in their communities, though Western collectors rarely recorded their names. Scholars today try to identify individual masters, such as the Yoruba sculptor Olowe of Ise (about 1873–1938), famous for carved palace doors and veranda posts."]],
  ["Masks and masquerades",[
    "Masks take many forms. Among the Dogon of Mali, kanaga masks with a double-barred superstructure appear in funeral rites. Among the Mende of Sierra Leone, the Sowei mask, a glossy black helmet with elaborate hairstyles and neck rings representing ideal female beauty, is worn by women of the Sande society, one of the few African traditions in which women wear masks.",
    "The Chi Wara headdresses of the Bamana of Mali, stylized antelopes, honor the mythical being who taught people agriculture and are danced in pairs in the fields. Gelede masquerades of the Yoruba honor the power of women and mothers."]],
  ["Figures and power",[
    "Figure sculptures represent ancestors, spirits, and rulers. Kongo nkisi nkondi (power figures) from Central Africa are studded with nails and blades, each driven in to activate the figure's power to witness oaths, settle disputes, or punish wrongdoers. Luba carvers of the Congo made stools supported by female figures and memory boards (lukasa) covered with beads, used by specialists to recall history.",
    "Kuba royal portrait figures (ndop) represent kings with symbols of their reigns. Akan goldweights from Ghana, small brass figures used to weigh gold dust, depict proverbs, animals, and people. African textiles, such as Asante and Ewe kente cloth, Kuba raffia cloth, and adire indigo cloth, are also major art forms."]],
  ["Influence on modern art",[
    "In the early 20th century, European artists such as Picasso, Matisse, Derain, Vlaminck, and the German Expressionists encountered African sculpture in Paris and Dresden ethnographic museums and markets. They admired its bold simplification and expressive power, and it helped inspire Cubism and Expressionism.",
    "This “primitivism,” however, often misunderstood African art, ignoring its meanings and makers and treating it as raw material for European innovation, while colonial collecting and looting brought many objects to Europe. MoMA's 1984 exhibition on primitivism provoked major debate about these issues."]],
  ["Modern African art",[
    "In the 20th century, African artists developed modern art drawing on both local traditions and international modernism. In Nigeria, the Zaria Art Society's “natural synthesis” and artists such as Ben Enwonwu, Uche Okeke, and Bruce Onobrakpeya created modern Nigerian art. In Ethiopia, Gebre Kristos Desta pioneered abstraction, and in Senegal, President Léopold Sédar Senghor promoted art connected to the philosophy of Négritude.",
    "The Malian photographers Seydou Keïta and Malick Sidibé made celebrated studio and party portraits capturing life in Bamako during and after independence."]],
  ["Contemporary African art",[
    "Today African and diaspora artists are prominent internationally: El Anatsui, William Kentridge, Julie Mehretu, Njideka Akunyili Crosby, Wangechi Mutu, and the photographer Zanele Muholi, among many others. The Zeitz Museum of Contemporary Art Africa (MOCAA) opened in Cape Town in 2017, and biennials such as Dak'Art in Dakar showcase African art.",
    "Debates about the restitution of looted objects, the building of museums in Africa, and telling African art history from African perspectives are reshaping the global art world."]]
  ],
  terms:[["Masquerade","A performance with mask, costume, music, and dance."],["Sowei mask","A Mende mask worn by women of the Sande society."],["Chi Wara","Bamana antelope headdresses honoring agriculture."],["Nkisi nkondi","Kongo power figures studded with nails."],["Kente","A woven Ghanaian cloth."],["Primitivism","Modern Western borrowing from non-Western art."],["Zeitz MOCAA","A contemporary art museum in Cape Town."]],
  w:"African masks, figures, and textiles are art in action, and their influence and history are central to understanding modern art and today's debates about museums.",
  src:["Traditional African masks","Sowei mask","Chiwara","Nkisi","Primitivism","Seydou Keïta","Zeitz Museum of Contemporary Art Africa"],
  q:[["What is a mask performance with costume and dance called?","A masquerade","A ritual stele","A kente","A procession"],
     ["Which mask is worn by women of the Sande society?","The Sowei mask","The kanaga mask","The Chi Wara","The Gelede mask"],
     ["What are Bamana antelope headdresses called?","Chi Wara","Nkisi","Lukasa","Ndop"],
     ["What are Kongo power figures studded with nails called?","Nkisi nkondi","Ere ibeji","Lukasa","Ndop"],
     ["Which Malian photographer made famous studio portraits?","Seydou Keïta","Zanele Muholi","Ben Enwonwu","Samuel Fosso"],
     ["Where did Zeitz MOCAA open in 2017?","Cape Town","Lagos","Dakar","Nairobi"]]},

{ t:"Art of Mesoamerica", s:"Olmec, Maya, Teotihuacan, and Aztec",
  sec:[
  ["Mesoamerica",[
    "Mesoamerica, covering much of Mexico and Central America, was home to a succession of civilizations that shared features such as maize agriculture, pyramid-temples, ball courts, complex calendars, writing systems, and religious beliefs including human sacrifice. Their art served religion and rulership.",
    "The Olmec (about 1200–400 BCE), on the Gulf Coast, are often called the “mother culture” of Mesoamerica. They carved 17 known colossal basalt heads, some about 3 meters tall and weighing many tons, probably portraits of rulers wearing helmet-like headdresses, as well as fine jade figures, including “were-jaguar” beings combining human and jaguar features."]],
  ["Teotihuacan",[
    "Teotihuacan, near present-day Mexico City, was one of the largest cities in the world at its height around 500 CE, with perhaps 100,000 or more inhabitants. It was laid out on a grid along a broad central avenue, the Avenue of the Dead, lined by the Pyramid of the Sun, one of the largest structures in the ancient Americas, and the Pyramid of the Moon.",
    "The Temple of the Feathered Serpent is decorated with carved heads of the serpent deity, later known as Quetzalcoatl. The city was abandoned around 550–650 CE, and the Aztecs later named it “the place where the gods were created.”"]],
  ["The Maya",[
    "The Maya civilization, in southern Mexico, Guatemala, Belize, and Honduras, flourished especially in the Classic period (about 250–900 CE), with city-states such as Tikal, Palenque, Copán, and Calakmul. The Maya developed the most complete writing system of the ancient Americas, a mathematical system with zero, and precise calendars; their glyphs were largely deciphered in the late 20th century.",
    "Maya rulers commissioned stone stelae carved with their portraits and deeds, and temples atop steep pyramids. At Palenque, the Temple of the Inscriptions held the tomb of King Pakal (died 683), with a carved sarcophagus lid and a jade mosaic mask. The murals of Bonampak depict court life and battle in vivid color, and painted cylindrical vases show mythological scenes. Chichén Itzá in Yucatán, with its pyramid El Castillo, flourished later."]],
  ["Ball courts and ritual",[
    "The Mesoamerican ballgame, played with a heavy rubber ball that players struck with their hips, had religious significance and was played on I-shaped courts found across the region; the Great Ball Court at Chichén Itzá is the largest.",
    "Bloodletting rituals by rulers, depicted in Maya carvings such as the Yaxchilán lintels showing Lady Xoc pulling a thorned rope through her tongue, were believed to nourish the gods and connect with ancestors."]],
  ["The Aztecs",[
    "The Aztecs (Mexica) founded their capital, Tenochtitlan, on an island in Lake Texcoco in 1325, and by 1500 it was one of the largest cities in the world. Its sacred precinct was dominated by the Templo Mayor, a twin pyramid dedicated to Huitzilopochtli, god of war and the sun, and Tlaloc, god of rain.",
    "Aztec sculpture was powerful and often fearsome: the colossal statue of the earth goddess Coatlicue, with a skirt of serpents and a necklace of hands and hearts, and the great Sun Stone (about 3.6 meters across), carved with calendar signs, both in Mexico City's National Museum of Anthropology. The discovery in 1978 of a huge stone disk of the dismembered moon goddess Coyolxauhqui led to the excavation of the Templo Mayor. Featherwork, such as the headdress associated with Moctezuma in Vienna, and codices, painted folding books, were also important."]],
  ["Conquest and continuity",[
    "The Spanish conquest (1519–1521) destroyed Tenochtitlan, and Spanish friars burned many codices as idolatrous; only a handful of pre-conquest Maya and Aztec books survive. Mexico City's cathedral was built over the ruins of the sacred precinct.",
    "Yet Indigenous artists continued to work, blending traditions in colonial churches, manuscripts, and featherwork, and millions of Maya and Nahuatl speakers today maintain cultural traditions. Mesoamerican art inspired 20th-century Mexican muralists and modern artists such as Henry Moore."]]
  ],
  terms:[["Mesoamerica","The cultural region of Mexico and Central America."],["Olmec colossal heads","Giant basalt heads of Olmec rulers."],["Teotihuacan","A vast ancient city with the Pyramid of the Sun."],["Stela","A carved upright stone monument."],["Mesoamerican ballgame","A ritual game played with a rubber ball."],["Templo Mayor","The Aztec twin pyramid in Tenochtitlan."],["Codex","A painted folding book."]],
  w:"Mesoamerican art created monumental cities, sculptures, and writing systems that rival any ancient civilization and continue to shape Mexican and Central American identity.",
  src:["Mesoamerica","Olmec colossal heads","Teotihuacan","Maya civilization","Palenque","Aztec Sun Stone","Templo Mayor"],
  q:[["Which civilization carved colossal basalt heads?","The Olmec","The Maya","The Aztecs","The Toltecs"],
     ["Which avenue runs through Teotihuacan?","The Avenue of the Dead","The Avenue of Pyramids","The Sacred Way","The Royal Road"],
     ["Whose tomb was in the Temple of the Inscriptions at Palenque?","King Pakal","Moctezuma","Lady Xoc","Yax Kuk Mo"],
     ["Which Aztec earth goddess wears a skirt of serpents?","Coatlicue","Coyolxauhqui","Tlaloc","Xochiquetzal"],
     ["On what lake was Tenochtitlan founded?","Lake Texcoco","Lake Titicaca","Lake Chapala","Lake Pátzcuaro"],
     ["What are Mesoamerican painted folding books called?","Codices","Stelae","Quipus","Glyphs"]]},

{ t:"Art of the Andes", s:"From Chavín to the Inca",
  sec:[
  ["A challenging land",[
    "The Andean region of South America, including present-day Peru, Bolivia, Ecuador, and northern Chile, produced a series of remarkable civilizations in an environment ranging from coastal desert to high mountains and Amazonian forest. Andean peoples did not develop a writing system as such, but they recorded information using quipus, knotted cords.",
    "Andean art emphasized textiles, metalwork, ceramics, and monumental architecture, and often featured abstract, geometric designs."]],
  ["Early cultures",[
    "Caral, in Peru's Supe Valley, with pyramids built around 2600 BCE, is one of the oldest cities in the Americas. The Chavín culture (about 900–200 BCE), centered on the temple of Chavín de Huántar in the highlands, spread a religious art of complex, interlocking images of fanged deities, jaguars, serpents, and birds, such as the Lanzón, a carved granite pillar deep within the temple's dark galleries.",
    "The Paracas culture (about 800 BCE–100 CE) on the south coast wrapped mummies in layers of magnificent embroidered textiles, with brilliantly colored figures of shamans and supernatural beings, among the finest textiles ever made."]],
  ["Nazca and Moche",[
    "The Nazca (about 100 BCE–800 CE) of the south coast made polychrome pottery and the famous Nazca Lines, enormous designs of animals such as a hummingbird, monkey, and spider, and geometric lines scratched into the desert floor by removing darker surface stones; they are best seen from the air, and their purpose, possibly ritual pathways or water-related ceremonies, is debated.",
    "The Moche (about 100–800 CE) of the north coast made realistic portrait vessels of individuals, stirrup-spout bottles depicting animals, warriors, and daily life, and superb gold, silver, and copper ornaments. The tomb of the Lord of Sipán, discovered intact in 1987, revealed spectacular gold and turquoise jewelry."]],
  ["Tiwanaku, Wari, and Chimú",[
    "Tiwanaku, near Lake Titicaca in Bolivia, was a major ceremonial city (about 500–1000 CE) with precisely cut stone buildings and the Gateway of the Sun, carved from a single block with a central staff-bearing deity. The Wari empire in the highlands produced tapestry tunics with bold, abstract designs.",
    "The Chimú kingdom built Chan Chan on the north coast of Peru, the largest adobe city in the Americas, with walls decorated with relief friezes of fish, birds, and geometric patterns. The Chimú were skilled goldsmiths."]],
  ["The Inca",[
    "The Inca built the largest empire in the Americas in the 15th and early 16th centuries, called Tawantinsuyu, stretching about 4,000 kilometers along the Andes, connected by a road network of about 40,000 kilometers. Their capital, Cusco, had buildings of finely fitted stone blocks without mortar, so precise that a knife blade cannot fit between them; the Twelve-Angled Stone is famous.",
    "Machu Picchu, a royal estate built around 1450 for the emperor Pachacuti on a mountain ridge above the Urubamba River, was unknown to the outside world until Hiram Bingham publicized it in 1911. Inca art valued textiles even above gold; fine tunics (qompi) woven with geometric designs called tocapu signified status. Gold, considered the “sweat of the sun,” adorned temples such as the Coricancha in Cusco."]],
  ["Conquest and colonial art",[
    "Francisco Pizarro's conquest of the Inca from 1532 led to the melting of vast quantities of gold and silver objects into bullion. Spanish churches were built on Inca foundations; in Cusco, the church of Santo Domingo stands on the walls of the Coricancha, which survived earthquakes that damaged the Spanish structures.",
    "The Cuzco School of colonial painting combined European models with Andean features, and Andean textile traditions continue in communities today."]]
  ],
  terms:[["Quipu","An Andean record-keeping device of knotted cords."],["Chavín","An early Andean culture with complex religious imagery."],["Paracas textiles","Embroidered textiles wrapping mummies."],["Nazca Lines","Giant designs drawn on the desert floor."],["Moche portrait vessels","Realistic ceramic portraits."],["Machu Picchu","An Inca royal estate in the mountains."],["Tocapu","Geometric designs on Inca textiles."]],
  w:"Andean civilizations created extraordinary textiles, metalwork, ceramics, and stone architecture in one of the world's most challenging environments.",
  src:["Andean civilizations","Chavín culture","Paracas culture","Nazca Lines","Moche culture","Machu Picchu","Inca Empire"],
  q:[["What were Andean knotted cords for record-keeping called?","Quipus","Tocapus","Codices","Stelae"],
     ["Which culture made the Nazca Lines?","The Nazca","The Moche","The Inca","The Chavín"],
     ["Which tomb discovered in 1987 revealed Moche gold?","The Lord of Sipán","Pakal's tomb","The Paracas necropolis","Tutankhamun's tomb"],
     ["What was the largest adobe city in the Americas?","Chan Chan","Cusco","Tiwanaku","Caral"],
     ["Who publicized Machu Picchu in 1911?","Hiram Bingham","Francisco Pizarro","Max Uhle","Julio Tello"],
     ["What did the Inca value even above gold?","Textiles","Ceramics","Jade","Feathers"]]},

{ t:"Native North American Art", s:"Diverse traditions across a continent",
  sec:[
  ["Many nations",[
    "North America was home to hundreds of distinct Indigenous nations with diverse languages, ways of life, and artistic traditions, from the Arctic to the Southwest. Much of their art was functional and spiritual, integrated into daily life, ceremony, and clothing, including pottery, basketry, beadwork, quillwork, carving, painting, and textiles.",
    "Today, Native artists continue these traditions and create contemporary art, and many museums work with tribal communities on how objects are displayed and whether sacred items should be returned, under laws such as the U.S. Native American Graves Protection and Repatriation Act (NAGPRA) of 1990."]],
  ["Ancient cultures",[
    "The Mound Builders of the Eastern Woodlands created earthworks such as the Great Serpent Mound in Ohio, a sinuous earthen effigy over 400 meters long. Cahokia, near present-day St. Louis, the largest pre-Columbian city north of Mexico (about 1050–1350 CE), centered on Monks Mound, a vast earthen platform. The Hopewell culture made mica cutouts and carved stone pipes.",
    "In the Southwest, the Ancestral Puebloans built cliff dwellings such as Cliff Palace at Mesa Verde and the great houses of Chaco Canyon, and the Mimbres people painted bowls with striking black-and-white figures, often ritually “killed” with a hole and buried with the dead."]],
  ["The Southwest",[
    "Pueblo potters continue ancient traditions. María Martinez of San Ildefonso Pueblo (about 1887–1980), with her husband Julián, revived and developed black-on-black pottery in the early 20th century, achieving international fame. Hopi carvers make katsina (kachina) figures representing spirit beings.",
    "Navajo (Diné) weavers create wool blankets and rugs with bold geometric designs, and Navajo silversmiths make turquoise jewelry. Navajo sandpaintings, made by healers for curing ceremonies, are ritually destroyed afterward."]],
  ["The Northwest Coast",[
    "Peoples of the Pacific Northwest Coast, such as the Tlingit, Haida, Kwakwaka'wakw, and Tsimshian, created monumental carved and painted art in a distinctive formline style, with bold, flowing black and red lines and ovoid shapes. Totem poles, carved from cedar, display family crests and histories, and transformation masks open to reveal another face inside.",
    "Chilkat blankets woven of mountain goat wool and cedar bark were worn at potlatches, ceremonial feasts at which hosts gave away wealth to affirm status, which Canada banned from 1885 to 1951. The Haida artist Bill Reid (1920–1998) revived Haida carving, creating works such as The Spirit of Haida Gwaii."]],
  ["The Plains and Woodlands",[
    "Plains peoples such as the Lakota and Cheyenne painted buffalo hides and tipis with geometric designs and pictographic records of battles and events, decorated clothing with porcupine quills and later glass beads, and made eagle-feather headdresses. After confinement to reservations in the late 19th century, Plains men made ledger drawings, depicting their lives and history in colored pencil on pages of accountants' ledger books.",
    "Woodlands peoples created floral beadwork, birchbark containers, and wampum belts of shell beads used to record treaties and agreements."]],
  ["Contemporary Native art",[
    "In the 20th century, Native artists developed modern and contemporary forms. The Institute of American Indian Arts in Santa Fe, founded in 1962, trained generations of artists. Fritz Scholder and T. C. Cannon painted provocative modern images, and Oscar Howe challenged expectations by bringing abstraction to Native painting.",
    "Contemporary artists such as Jaune Quick-to-See Smith, whose work was acquired by the National Gallery of Art in 2020, Kent Monkman, Wendy Red Star, and Jeffrey Gibson, who represented the United States at the 2024 Venice Biennale as the first Indigenous artist to have a solo show in the U.S. pavilion, address identity, history, and colonialism. Inuit artists in Canada developed printmaking at Cape Dorset (Kinngait) from the late 1950s."]]
  ],
  terms:[["NAGPRA","The 1990 U.S. law on returning Native remains and sacred objects."],["Cahokia","The largest pre-Columbian city north of Mexico."],["Mimbres pottery","Painted black-and-white bowls of the Southwest."],["Formline","The Northwest Coast style of flowing lines and ovoids."],["Totem pole","A carved cedar pole displaying family crests."],["Potlatch","A Northwest Coast ceremonial feast of gift-giving."],["Ledger drawing","Plains drawings on accountants' ledger paper."]],
  w:"Native North American art reflects the diversity and resilience of hundreds of nations, from ancient mounds to contemporary artists shaping today's art world.",
  src:["Visual arts by Indigenous peoples of the Americas","Cahokia","Mimbres pottery","Maria Martinez","Totem pole","Ledger art","Jeffrey Gibson"],
  q:[["What is the largest pre-Columbian city north of Mexico?","Cahokia","Chaco Canyon","Mesa Verde","Serpent Mound"],
     ["Who revived black-on-black pottery at San Ildefonso Pueblo?","María Martinez","Nampeyo","Lucy Lewis","Margaret Tafoya"],
     ["What is the Northwest Coast style of flowing lines called?","Formline","Ledger","Quillwork","Ovoid art"],
     ["What ceremonial feast did Canada ban from 1885 to 1951?","The potlatch","The Sun Dance","The powwow","The Ghost Dance"],
     ["On what did Plains artists draw in the late 19th century?","Ledger book pages","Birchbark","Hides only","Canvas"],
     ["Who represented the U.S. at the 2024 Venice Biennale?","Jeffrey Gibson","Jaune Quick-to-See Smith","Kent Monkman","Wendy Red Star"]]},

{ t:"Art of Oceania and Aboriginal Australia", s:"Islands, ancestors, and the Dreaming",
  sec:[
  ["A world of islands",[
    "Oceania includes Australia, New Guinea, and the thousands of Pacific islands of Melanesia, Micronesia, and Polynesia. Its peoples created art closely tied to ancestors, spirits, status, and the land and sea, in wood, stone, shell, feathers, bark cloth, and the human body itself, through tattoo.",
    "Much Oceanic art was made for ceremonies and exchanges, and some objects were meant to be destroyed or left to decay after use."]],
  ["Aboriginal Australian art",[
    "Aboriginal Australians have one of the world's oldest continuous artistic traditions, with rock art tens of thousands of years old in places such as the Kimberley, Kakadu, and Murujuga (the Burrup Peninsula), which has more than a million petroglyphs. Art expresses the Dreaming (or Dreamtime), the ancestral beings who created the land, laws, and kinship, and the relationship between people and Country.",
    "Arnhem Land artists paint on bark with fine crosshatching (rarrk) and depict ancestral beings, animals in “X-ray” style showing internal organs, and clan designs. Many images and stories are sacred and restricted to initiated people."]],
  ["The Western Desert movement",[
    "In 1971 at Papunya, a government settlement in the Northern Territory, the schoolteacher Geoffrey Bardon encouraged Aboriginal men to paint designs traditionally made in sand, body paint, and ceremonies onto boards and canvas with acrylic paint. The Papunya Tula movement, using dotting, concentric circles, and lines representing places and ancestral journeys, grew into one of the most important contemporary art movements of the late 20th century.",
    "Artists such as Clifford Possum Tjapaltjarri and Emily Kame Kngwarreye, who began painting in her late seventies and produced thousands of vibrant works, gained international acclaim. Concerns about sacred designs led artists to use dots partly to obscure restricted knowledge."]],
  ["New Guinea and Melanesia",[
    "New Guinea and Melanesia have extraordinarily diverse art. The Asmat of southwestern New Guinea carve towering bisj poles honoring the dead. In the Sepik River region, villages built ceremonial men's houses with soaring gables and carved and painted figures, masks, and hooks.",
    "In Vanuatu, slit gongs carved from tree trunks with faces stand upright in villages, and in New Ireland, malagan carvings, intricate openwork figures made for funerary ceremonies, were traditionally abandoned or destroyed after use."]],
  ["Polynesia",[
    "Polynesian art emphasizes mana, spiritual power, and genealogy. On Rapa Nui (Easter Island), people carved nearly 1,000 moai, huge stone figures representing deified ancestors, between about 1250 and 1500 CE, and moved them across the island to stand on platforms facing inland.",
    "The Māori of New Zealand carve meeting houses (wharenui), whose structure represents an ancestor's body, decorated with spiral and curvilinear designs, and create greenstone (pounamu) pendants called hei-tiki. Tattoo (from the Tahitian tatau) was a major art; Māori tā moko facial tattoos express identity and genealogy. Hawaiian featherwork cloaks of millions of tiny feathers signified royal status, and Polynesians made bark cloth (tapa) with printed and painted designs."]],
  ["Oceanic art today",[
    "European contact brought disease, missionaries who sometimes destroyed religious images, and collectors who removed many objects; museums in Europe hold large collections, and repatriation, especially of ancestral remains, is ongoing.",
    "Contemporary Pacific artists, such as the Māori artist Lisa Reihana, whose panoramic video In Pursuit of Venus [infected] reimagines Captain Cook's voyages, and Aboriginal artists such as Gordon Bennett, Tracey Moffatt, and Richard Bell, engage with history, colonialism, and identity, and Pacific art is increasingly shown in major museums."]]
  ],
  terms:[["The Dreaming","The Aboriginal concept of ancestral creation and law."],["Rarrk","Fine crosshatching in Arnhem Land bark painting."],["Papunya Tula","The Western Desert acrylic painting movement begun in 1971."],["Malagan","New Ireland funerary carvings."],["Moai","Monumental stone figures of Rapa Nui."],["Mana","Spiritual power in Polynesian belief."],["Tā moko","Māori facial tattoo."]],
  w:"The art of Oceania and Aboriginal Australia expresses deep connections to ancestors, land, and sea, and includes some of humanity's oldest and most vital living traditions.",
  src:["Oceanic art","Australian Aboriginal art","Papunya Tula","Emily Kame Kngwarreye","Moai","Māori art","Tā moko"],
  q:[["What is the Aboriginal concept of ancestral creation called?","The Dreaming","Mana","Tapu","The Songline"],
     ["Where did the acrylic Western Desert painting movement begin in 1971?","Papunya","Arnhem Land","Uluru","Kakadu"],
     ["Which artist began painting in her late seventies?","Emily Kame Kngwarreye","Tracey Moffatt","Gordon Bennett","Lisa Reihana"],
     ["What are the stone figures of Rapa Nui called?","Moai","Tiki","Malagan","Bisj"],
     ["What are Māori greenstone pendants called?","Hei-tiki","Tapa","Moko","Wharenui"],
     ["Which Polynesian word gave us tattoo?","Tatau","Tapu","Tiki","Mana"]]},

{ t:"Living with Art", s:"How to keep looking, learning, and enjoying",
  sec:[
  ["Connecting the story",[
    "This course has traced art from the cave paintings of Sulawesi and Lascaux through ancient civilizations, the Middle Ages, the Renaissance, Baroque, and modern movements, to the global contemporary art world, and across the traditions of Asia, Africa, the Islamic world, the Americas, and Oceania. Several themes recur: art as devotion, as power, as record, as personal expression, and as a way of seeing.",
    "Each era reacts to what came before: Renaissance artists revived antiquity, the Baroque dramatized the Renaissance, Neoclassicism rejected the Rococo, Impressionism challenged the Academy, and modern movements reacted against one another. Global exchange, from the Silk Road to Japanese prints in Paris, has repeatedly transformed art."]],
  ["Visiting museums",[
    "Museums can be overwhelming. It helps to choose a few galleries rather than trying to see everything, to spend real time with a handful of works, and to return to favorites over the years. Reading labels after looking, rather than before, helps you form your own response first.",
    "Great museums to know include the Louvre, the Musée d'Orsay, and the Centre Pompidou in Paris; the British Museum, National Gallery, and Tate in London; the Prado in Madrid; the Uffizi in Florence; the Vatican Museums; the Rijksmuseum in Amsterdam; the Metropolitan Museum of Art and MoMA in New York; the Art Institute of Chicago; the Hermitage in St. Petersburg; the Palace Museum in Beijing; the National Palace Museum in Taipei; and the Tokyo National Museum. Many local museums hold surprising treasures."]],
  ["Questions to carry",[
    "Whenever you meet a work of art, the questions from the first chapter apply: What do I see? How is it made? How is it organized? When, where, why, and for whom was it made? What did it mean then, and what does it mean to me now?",
    "Also ask whose stories are told and whose are missing, how the work came to be where it is, and how its value has been decided. Art history is constantly revised as new research, discoveries, and voices change the story."]],
  ["Making art",[
    "One of the best ways to understand art is to make it. Drawing, even badly, trains the eye to see shapes, light, and proportion; trying watercolor or clay teaches respect for an artist's skill; and photographing with attention to composition sharpens observation.",
    "Many great artists insisted that learning to see is the foundation of everything. Sketchbooks, classes, and simple daily practice can transform how you notice the world."]],
  ["Where to go next",[
    "These foundations open many branches: deeper study of a period such as the Renaissance or Baroque, a medium such as sculpture, photography, or film, a region such as East Asian, Islamic, African, or Latin American art, or a theme such as women artists, architecture, or the art market.",
    "There is always more to see: new exhibitions, newly discovered works, artists rescued from obscurity, and new art being made every day. The goal is not to finish learning about art, but to keep looking."]]
  ],
  terms:[["Art history","The study of art across time and cultures."],["Recurring themes","Devotion, power, record, expression, and seeing."],["Slow looking","Spending extended time with a single artwork."],["Canon","The works traditionally considered most important, now continually revised."]],
  w:"Bringing these foundations together turns knowledge into a lifelong habit of looking, questioning, and enjoying art wherever you find it.",
  src:["Art history","Museum","List of most-visited art museums","Slow Art Day","Western canon"],
  q:[["What is a good habit when reading museum labels?","Look first, then read the label","Read every label before looking","Ignore labels entirely","Read only the dates"],
     ["Which of these museums is in Madrid?","The Prado","The Uffizi","The Rijksmuseum","The Hermitage"],
     ["Which museum is in Amsterdam?","The Rijksmuseum","The Prado","The Uffizi","The Louvre"],
     ["Which museum is in Florence?","The Uffizi","The Prado","The Hermitage","The Met"],
     ["What did many great artists say is the foundation of art?","Learning to see","Owning expensive materials","Fame","Following rules"],
     ["What has repeatedly transformed art across history?","Global exchange between cultures","Isolation","Government bans","Lack of materials"]]}

);
